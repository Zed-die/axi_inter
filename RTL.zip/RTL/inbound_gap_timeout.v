`timescale 1ns/1ps

// Optional per-message inter-packet timeout. The counter runs only after a
// successfully routed non-EOM packet and pauses while its next packet is being
// received or routed. A zero threshold disables this timer.
module inbound_gap_timeout (
    input  wire        clk,
    input  wire        rst_n,
    input  wire [31:0] timeout_cycles,
    input  wire        store_valid,
    input  wire [2:0]  store_slot,
    input  wire        route_valid,
    input  wire [2:0]  route_slot,
    input  wire        route_eom,
    input  wire        route_error,
    input  wire        abort_valid,
    input  wire [2:0]  abort_slot,
    input  wire        done_valid,
    input  wire [2:0]  done_slot,
    output reg         timeout_valid,
    output reg  [2:0]  timeout_slot,
    output reg  [7:0]  expired
);
    reg [7:0] active;
    reg [7:0] busy;
    reg [31:0] count [0:7];
    integer i;
    integer pick;

    always @* begin
        timeout_valid = 1'b0;
        timeout_slot = 3'd0;
        for (pick = 0; pick < 8; pick = pick + 1) begin
            if (!timeout_valid && active[pick] && !busy[pick] &&
                timeout_cycles != 32'd0 &&
                count[pick] >= timeout_cycles - 32'd1 &&
                !(store_valid && store_slot == pick[2:0]) &&
                !(route_valid && route_slot == pick[2:0]) &&
                !(abort_valid && abort_slot == pick[2:0])) begin
                timeout_valid = 1'b1;
                timeout_slot = pick[2:0];
            end
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            active <= 8'd0;
            busy <= 8'd0;
            expired <= 8'd0;
            for (i = 0; i < 8; i = i + 1) count[i] <= 32'd0;
        end else begin
            for (i = 0; i < 8; i = i + 1) begin
                if (active[i] && !busy[i] && count[i] != 32'hffffffff)
                    count[i] <= count[i] + 32'd1;
            end
            if (timeout_valid) begin
                active[timeout_slot] <= 1'b0;
                expired[timeout_slot] <= 1'b1;
            end
            if (store_valid) begin
                busy[store_slot] <= 1'b1;
                if (!active[store_slot]) count[store_slot] <= 32'd0;
            end
            if (route_valid) begin
                busy[route_slot] <= 1'b0;
                active[route_slot] <= !route_eom && !route_error;
                count[route_slot] <= 32'd0;
            end
            if (abort_valid) begin
                active[abort_slot] <= 1'b0;
                busy[abort_slot] <= 1'b0;
            end
            if (done_valid) begin
                active[done_slot] <= 1'b0;
                busy[done_slot] <= 1'b0;
                expired[done_slot] <= 1'b0;
                count[done_slot] <= 32'd0;
            end
        end
    end
endmodule
