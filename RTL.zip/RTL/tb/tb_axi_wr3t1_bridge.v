`timescale 1ns/1ps

module tb_axi_wr3t1_bridge;
    reg clk = 0;
    always #5 clk = ~clk;
    reg rst_n = 0;
    reg [2:0] s_awvalid = 0;
    wire [2:0] s_awready;
    reg [47:0] s_awaddr = 0;
    reg [23:0] s_awlen = 0;
    reg [8:0] s_awsize = 0;
    reg [5:0] s_awburst = 0;
    reg [5:0] s_awid = 0;
    reg [2:0] s_awlock = 0;
    reg [11:0] s_awcache = 0;
    reg [8:0] s_awprot = 0;
    reg [11:0] s_awqos = 0;
    reg [11:0] s_awregion = 0;
    reg [2:0] s_wvalid = 0;
    wire [2:0] s_wready;
    reg [95:0] s_wdata = 0;
    reg [11:0] s_wstrb = 0;
    reg [2:0] s_wlast = 0;
    reg [2:0] s_bready = 3'b111;
    wire [2:0] s_bvalid;
    wire [5:0] s_bresp;
    wire [5:0] s_bid;
    wire m_awvalid;
    reg m_awready = 1;
    wire [15:0] m_awaddr;
    wire [7:0] m_awlen;
    wire [2:0] m_awsize;
    wire [1:0] m_awburst;
    wire [1:0] m_awid;
    wire m_wvalid;
    reg m_wready = 1;
    wire [31:0] m_wdata;
    wire [3:0] m_wstrb;
    wire m_wlast;
    reg m_bvalid = 0;
    wire m_bready;
    reg [1:0] m_bresp = 0;
    reg [1:0] m_bid = 0;

    axi_wr3t1_bridge #(
        .ADDR_WIDTH (16),
        .DATA_WIDTH (32),
        .ID_WIDTH   (2),
        .TAG_DEPTH  (2)
    ) dut (
        .clk        (clk),
        .rst_n      (rst_n),
        .s_awvalid  (s_awvalid),
        .s_awready  (s_awready),
        .s_awaddr   (s_awaddr),
        .s_awlen    (s_awlen),
        .s_awsize   (s_awsize),
        .s_awburst  (s_awburst),
        .s_awid     (s_awid),
        .s_awlock   (s_awlock),
        .s_awcache  (s_awcache),
        .s_awprot   (s_awprot),
        .s_awqos    (s_awqos),
        .s_awregion (s_awregion),
        .s_wvalid   (s_wvalid),
        .s_wready   (s_wready),
        .s_wdata    (s_wdata),
        .s_wstrb    (s_wstrb),
        .s_wlast    (s_wlast),
        .s_bvalid   (s_bvalid),
        .s_bready   (s_bready),
        .s_bresp    (s_bresp),
        .s_bid      (s_bid),
        .m_awvalid  (m_awvalid),
        .m_awready  (m_awready),
        .m_awaddr   (m_awaddr),
        .m_awlen    (m_awlen),
        .m_awsize   (m_awsize),
        .m_awburst  (m_awburst),
        .m_awid     (m_awid),
        .m_wvalid   (m_wvalid),
        .m_wready   (m_wready),
        .m_wdata    (m_wdata),
        .m_wstrb    (m_wstrb),
        .m_wlast    (m_wlast),
        .m_bvalid   (m_bvalid),
        .m_bready   (m_bready),
        .m_bresp    (m_bresp),
        .m_bid      (m_bid)
    );

    task check_aw;
        input expected_valid;
        input [2:0] expected_ready;
        input [15:0] expected_addr;
        begin
            #1;
            if (m_awvalid !== expected_valid || s_awready !== expected_ready ||
                (expected_valid && m_awaddr !== expected_addr)) begin
                $display("AW mismatch: valid=%b ready=%b addr=%h expected=%b/%b/%h",
                         m_awvalid, s_awready, m_awaddr,
                         expected_valid, expected_ready, expected_addr);
                $fatal(1);
            end
        end
    endtask

    task check_w;
        input [2:0] expected_ready;
        input [31:0] expected_data;
        input expected_last;
        begin
            #1;
            if (!m_wvalid || s_wready !== expected_ready ||
                m_wdata !== expected_data || m_wlast !== expected_last) begin
                $display("W mismatch: valid=%b ready=%b data=%h last=%b",
                         m_wvalid, s_wready, m_wdata, m_wlast);
                $fatal(1);
            end
        end
    endtask

    initial begin
        s_awaddr[15:0] = 16'h1000;
        s_awaddr[31:16] = 16'h2000;
        s_awaddr[47:32] = 16'h3000;
        s_awlen[7:0] = 1;
        s_awlen[15:8] = 0;
        s_awlen[23:16] = 0;
        s_wdata[31:0] = 32'hA0A0A0A0;
        s_wdata[63:32] = 32'hB1B1B1B1;
        s_wdata[95:64] = 32'hC2C2C2C2;
        s_wstrb = 12'hFFF;
        repeat (2) @(posedge clk);
        @(negedge clk);
        rst_n = 1;
        s_awvalid = 3'b011;
        check_aw(1, 3'b001, 16'h1000);
        @(posedge clk); #1;
        @(negedge clk);
        s_awvalid = 3'b110;
        s_wvalid = 3'b011;
        s_wlast = 0;
        check_aw(0, 3'b000, 0); // Next AW waits for first WLAST.
        check_w(3'b001, 32'hA0A0A0A0, 0);
        @(posedge clk); #1;
        @(negedge clk);
        s_wlast[0] = 1;
        check_w(3'b001, 32'hA0A0A0A0, 1);
        @(posedge clk); #1;
        @(negedge clk);
        s_wvalid[0] = 0;
        check_aw(1, 3'b010, 16'h2000); // Rotate after WLAST.
        @(posedge clk); #1;
        @(negedge clk);
        s_awvalid[1] = 0;
        s_awvalid[2] = 1;
        s_wlast[1] = 1;
        check_aw(0, 3'b000, 0);
        check_w(3'b010, 32'hB1B1B1B1, 1);
        @(posedge clk); #1;
        @(negedge clk);
        s_wvalid[1] = 0;
        check_aw(0, 3'b000, 0); // Two AWs are waiting for B: FIFO full.

        m_bvalid = 1;
        m_bresp = 2'b10;
        s_bready[0] = 0;
        #1;
        if (s_bvalid !== 3'b001 || m_bready !== 1'b0)
            $fatal(1, "B backpressure was not forwarded");
        @(posedge clk); #1;
        @(negedge clk);
        s_bready[0] = 1;
        #1;
        if (s_bvalid !== 3'b001 || !m_bready || s_bresp[1:0] !== 2'b10)
            $fatal(1, "First B did not return to source 0");
        @(posedge clk); #1;
        @(negedge clk);
        m_bvalid = 0;
        check_aw(1, 3'b100, 16'h3000);
        @(posedge clk); #1;
        @(negedge clk);
        s_awvalid = 0;
        s_wvalid = 3'b100;
        s_wlast = 3'b100;
        check_w(3'b100, 32'hC2C2C2C2, 1);
        @(posedge clk); #1;
        @(negedge clk);
        s_wvalid = 0;
        m_bvalid = 1;
        #1;
        if (s_bvalid !== 3'b010) $fatal(1, "Second B did not return to source 1");
        @(posedge clk); #1;
        @(negedge clk);
        #1;
        if (s_bvalid !== 3'b100) $fatal(1, "Third B did not return to source 2");
        @(posedge clk); #1;
        @(negedge clk);
        m_bvalid = 0;

        // A pending AW remains on source 2 even when source 0 appears later.
        s_awvalid = 3'b100;
        m_awready = 0;
        check_aw(1, 3'b000, 16'h3000);
        @(posedge clk); #1;
        @(negedge clk);
        s_awvalid = 3'b101;
        #1;
        if (m_awaddr !== 16'h3000) $fatal(1, "AW grant changed under stall");
        m_awready = 1;
        check_aw(1, 3'b100, 16'h3000);
        @(posedge clk); #1;
        @(negedge clk);
        s_awvalid = 0;
        s_wvalid = 3'b100;
        s_wlast = 3'b100;
        check_w(3'b100, 32'hC2C2C2C2, 1);
        @(posedge clk); #1;
        @(negedge clk);
        s_wvalid = 0;
        m_bvalid = 1;
        #1;
        if (s_bvalid !== 3'b100) $fatal(1, "Stalled AW B source mismatch");
        @(posedge clk); #1;
        @(negedge clk);
        m_bvalid = 0;
        $display("PASS tb_axi_wr3t1_bridge");
        $finish;
    end
endmodule
