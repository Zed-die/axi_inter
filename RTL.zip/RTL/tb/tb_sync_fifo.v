`timescale 1ns/1ps
module tb_sync_fifo;
    reg clk = 1'b0;
    always #5 clk = ~clk;
    reg rst_n = 1'b0;
    reg wr_en = 1'b0, rd_en = 1'b0;
    reg [7:0] din = 8'd0;
    wire [7:0] dout;
    wire full, empty;
    wire [3:0] data_count;
    integer i;

    sync_fifo #(
        .DATA_WIDTH (8),
        .ADDR_WIDTH (3)
    ) dut (
        .clk        (clk),
        .rst_n      (rst_n),
        .wr_en      (wr_en),
        .din        (din),
        .rd_en      (rd_en),
        .dout       (dout),
        .full       (full),
        .empty      (empty),
        .data_count (data_count)
    );

    initial begin
        repeat (2) @(negedge clk);
        rst_n = 1'b1;
        if (!empty || full || data_count !== 0 || dout !== 0)
            $fatal(1, "FIFO reset state wrong");
        for (i = 0; i < 8; i = i + 1) begin
            wr_en = 1'b1; din = i;
            @(posedge clk); @(negedge clk);
        end
        wr_en = 1'b0;
        if (!full || empty || data_count !== 8 || dout !== 0)
            $fatal(1, "FIFO full or FWFT head wrong");
        wr_en = 1'b1; din = 8'hff;
        @(posedge clk); @(negedge clk);
        if (data_count !== 8 || dout !== 0)
            $fatal(1, "FIFO overwrote data while full");
        rd_en = 1'b1; din = 8'd8;
        @(posedge clk); @(negedge clk);
        wr_en = 1'b0; rd_en = 1'b0;
        if (!full || data_count !== 8 || dout !== 1)
            $fatal(1, "simultaneous pop/push at full failed");
        for (i = 1; i <= 8; i = i + 1) begin
            if (dout !== i) $fatal(1, "FIFO order mismatch at %d", i);
            rd_en = 1'b1;
            @(posedge clk); @(negedge clk);
        end
        rd_en = 1'b0;
        if (!empty || data_count !== 0 || dout !== 0)
            $fatal(1, "FIFO did not drain");
        wr_en = 1'b1; rd_en = 1'b1; din = 8'd9;
        @(posedge clk); @(negedge clk);
        wr_en = 1'b0; rd_en = 1'b0;
        if (empty || data_count !== 1 || dout !== 9)
            $fatal(1, "empty simultaneous push/pop behavior wrong");
        rst_n = 1'b0;
        @(negedge clk);
        if (!empty || data_count !== 0)
            $fatal(1, "FIFO reset did not clear occupancy");
        $display("tb_sync_fifo PASS");
        $finish;
    end
endmodule
