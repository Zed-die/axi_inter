`timescale 1ns/1ps
module tb_inbound_engine_top;
    reg clk = 0;
    always #5 clk = ~clk;
    reg rst_n = 0;
    reg enable = 0;
    reg [15:0] sq_tail_ptr = 1;
    reg [8:0] cq_head = 0;
    wire [8:0] cq_tail;
    wire [15:0] sq_rd_ptr;
    reg [7:0] irq_clear = 0;
    reg [31:0] message_timeout_cycles = 0;
    reg [31:0] congestion_timeout_cycles = 0;
    wire [7:0] irq_status;
    wire irq_level;
    reg s_awvalid = 0;
    wire s_awready;
    reg [3:0] s_awid = 3;
    reg [127:0] s_awmeta = 128'h55;
    reg [7:0] s_seid = 8'h42;
    reg s_eom = 1;
    reg [7:0] s_awlen = 0;
    reg s_wvalid = 0;
    wire s_wready;
    reg [511:0] s_wdata = {16{32'h12345678}};
    reg [63:0] s_wstrb = 64'hffff;
    reg s_wlast = 1;
    wire s_bvalid;
    reg s_bready = 0;
    wire [3:0] s_bid;
    wire [1:0] s_bresp;
    wire m_arvalid;
    reg m_arready = 0;
    wire [63:0] m_araddr;
    wire [7:0] m_arlen;
    wire [2:0] m_arsize;
    reg m_rvalid = 0;
    wire m_rready;
    reg [511:0] m_rdata = 0;
    reg [1:0] m_rresp = 0;
    reg m_rlast = 1;
    wire m_awvalid;
    reg m_awready = 0;
    wire [63:0] m_awaddr;
    wire [7:0] m_awlen;
    wire [2:0] m_awsize;
    wire m_wvalid;
    reg m_wready = 0;
    wire [511:0] m_wdata;
    wire [63:0] m_wstrb;
    wire m_wlast;
    reg m_bvalid = 0;
    wire m_bready;
    reg [1:0] m_bresp = 0;
    reg [255:0] sqe;
    integer timeout;

    inbound_engine_top dut (
        .clk                  (clk),
        .rst_n                (rst_n),
        .enable               (enable),
        .sq_base_addr         (64'h4000),
        .sq_tail_ptr          (sq_tail_ptr),
        .cq_base_addr         (64'h8000),
        .cq_head              (cq_head),
        .cq_tail              (cq_tail),
        .sq_rd_ptr            (sq_rd_ptr),
        .irq_mask             (8'hff),
        .irq_clear            (irq_clear),
        .message_timeout_cycles(message_timeout_cycles),
        .congestion_timeout_cycles(congestion_timeout_cycles),
        .irq_status           (irq_status),
        .irq_level            (irq_level),
        .filter_enable        (1'b0),
        .rule_enable          (4'd0),
        .rule_drop            (4'd0),
        .rule_value           (32'd0),
        .rule_mask            (32'd0),
        .default_drop         (1'b0),
        .store_bounds_ok      (1'b1),
        .congestion_drop      (1'b0),
        .lookup_timeout       (1'b0),
        .current_timeout      (1'b0),
        .s_awvalid            (s_awvalid),
        .s_awready            (s_awready),
        .s_awid               (s_awid),
        .s_awmeta             (s_awmeta),
        .s_awlen              (s_awlen),
        .s_awsize             (3'd6),
        .s_awburst            (2'b01),
        .s_scope              (8'h01),
        .s_seid               (s_seid),
        .s_to                 (1'b0),
        .s_tag                (3'd1),
        .s_som                (1'b1),
        .s_eom                (s_eom),
        .s_seq                (2'd0),
        .s_wvalid             (s_wvalid),
        .s_wready             (s_wready),
        .s_wdata              (s_wdata),
        .s_wstrb              (s_wstrb),
        .s_wlast              (s_wlast),
        .s_bvalid             (s_bvalid),
        .s_bready             (s_bready),
        .s_bid                (s_bid),
        .s_bresp              (s_bresp),
        .m_axi_arvalid        (m_arvalid),
        .m_axi_arready        (m_arready),
        .m_axi_araddr         (m_araddr),
        .m_axi_arlen          (m_arlen),
        .m_axi_arsize         (m_arsize),
        .m_axi_rvalid         (m_rvalid),
        .m_axi_rready         (m_rready),
        .m_axi_rdata          (m_rdata),
        .m_axi_rresp          (m_rresp),
        .m_axi_rlast          (m_rlast),
        .m_axi_rid            (4'd0),
        .m_axi_awvalid        (m_awvalid),
        .m_axi_awready        (m_awready),
        .m_axi_awaddr         (m_awaddr),
        .m_axi_awlen          (m_awlen),
        .m_axi_awsize         (m_awsize),
        .m_axi_wvalid         (m_wvalid),
        .m_axi_wready         (m_wready),
        .m_axi_wdata          (m_wdata),
        .m_axi_wstrb          (m_wstrb),
        .m_axi_wlast          (m_wlast),
        .m_axi_bvalid         (m_bvalid),
        .m_axi_bready         (m_bready),
        .m_axi_bresp          (m_bresp),
        .m_axi_bid            (4'd0)
    );

    task accept_aw;
        input [63:0] addr;
        input [2:0] size;
        begin
            timeout = 0;
            while (!m_awvalid && timeout < 100) begin
                @(negedge clk); timeout = timeout + 1;
            end
            #1; if (!m_awvalid || m_awaddr !== addr || m_awlen !== 0 || m_awsize !== size)
                $fatal(1, "memory AW mismatch addr=%h size=%d expected=%h/%d", m_awaddr, m_awsize, addr, size);
            m_awready = 1;
            @(posedge clk); @(negedge clk); m_awready = 0;
        end
    endtask
    task accept_w;
        input [63:0] strb;
        begin
            timeout = 0;
            while (!m_wvalid && timeout < 100) begin
                @(negedge clk); timeout = timeout + 1;
            end
            #1; if (!m_wvalid || !m_wlast || m_wstrb !== strb)
                $fatal(1, "memory W mismatch strb=%h expected=%h", m_wstrb, strb);
            m_wready = 1;
            @(posedge clk); @(negedge clk); m_wready = 0;
        end
    endtask
    task send_b;
        begin
            @(negedge clk); m_bvalid = 1;
            #1; if (!m_bready) $fatal(1, "memory B not accepted");
            @(posedge clk); @(negedge clk); m_bvalid = 0;
        end
    endtask
    initial begin
        sqe = 0;
        sqe[255:240] = 16'h1234;
        sqe[191:128] = 64'h1000;
        sqe[95:90] = 6'd1;
        sqe[31:0] = 32'hcafebabe;
        repeat (2) @(posedge clk);
        @(negedge clk); rst_n = 1; enable = 1;
        timeout = 0;
        while (!m_arvalid && timeout < 40) begin
            @(negedge clk); timeout = timeout + 1;
        end
        #1; if (!m_arvalid || m_araddr !== 64'h4000 || m_arlen !== 0 || m_arsize !== 3'd5)
            $fatal(1, "SQE prefetch AR wrong");
        m_arready = 1;
        @(posedge clk); @(negedge clk); m_arready = 0;
        m_rdata = {256'd0, sqe}; m_rvalid = 1;
        #1; if (!m_rready) $fatal(1, "SQE R not accepted");
        @(posedge clk); @(negedge clk); m_rvalid = 0;

        timeout = 0;
        while (!dut.core_i.som_candidate_valid && timeout < 40) begin
            @(negedge clk); timeout = timeout + 1;
        end
        if (!dut.core_i.som_candidate_valid) $fatal(1, "SQE not ready after prefetch");

        @(negedge clk); s_awvalid = 1;
        timeout = 0;
        while (!s_awready && timeout < 50) begin
            @(negedge clk); timeout = timeout + 1;
        end
        if (!s_awready) $fatal(1, "controller AW stalled without SQE");
        @(posedge clk); @(negedge clk); s_awvalid = 0; s_wvalid = 1;
        #1; if (!s_wready) $fatal(1, "controller W not ready");
        @(posedge clk); @(negedge clk); s_wvalid = 0;

        accept_aw(64'h1000, 3'd6);
        accept_w(64'hffff);
        if (s_bvalid) $fatal(1, "controller B preceded Fabric B");

        @(negedge clk); s_awid = 4; s_awmeta = 128'h66;
        s_seid = 8'h43; s_awvalid = 1;
        timeout = 0;
        while (!s_awready && timeout < 30) begin
            @(negedge clk); timeout = timeout + 1;
        end
        if (!s_awready) $fatal(1, "DROP AW could not bypass occupied buffer");
        @(posedge clk); @(negedge clk); s_awvalid = 0; s_wvalid = 1;
        #1; if (!s_wready) $fatal(1, "DROP W not drained");
        @(posedge clk); @(negedge clk); s_wvalid = 0;
        if (s_bvalid) $fatal(1, "later DROP B passed earlier Fabric write");

        send_b();
        timeout = 0;
        while (!s_bvalid && timeout < 30) begin
            @(negedge clk); timeout = timeout + 1;
        end
        if (!s_bvalid || s_bid !== 3 || s_bresp !== 0)
            $fatal(1, "controller B attribution wrong");
        s_bready = 1;
        @(posedge clk); @(negedge clk); s_bready = 0;
        if (!s_bvalid || s_bid !== 4 || s_bresp !== 2'b10)
            $fatal(1, "DROP did not return local ordered SLVERR");
        s_bready = 1;
        @(posedge clk); @(negedge clk); s_bready = 0;

        accept_aw(64'h4000, 3'd5);
        timeout = 0;
        while (!m_wvalid && timeout < 40) begin
            @(negedge clk); timeout = timeout + 1;
        end
        #1; if (m_wdata[255:240] !== 16'h1234 ||
                m_wdata[219:200] !== 15 ||
                m_wdata[31:0] !== 32'hcafebabe)
            $fatal(1, "SQE writeback contents wrong");
        accept_w(64'hffffffff); send_b();

        accept_aw(64'h8000, 3'd4); accept_w(64'h7fff); send_b();
        accept_aw(64'h8000, 3'd4); accept_w(64'h8000); send_b();
        @(negedge clk);
        if (cq_tail !== 1 || sq_rd_ptr !== 1 || !irq_level ||
            !irq_status[7] || !irq_status[2])
            $fatal(1, "CQ publication/IRQ/RD pointer missing tail=%d rd=%d irq=%h", cq_tail, sq_rd_ptr, irq_status);
        irq_clear = 8'h84;
        @(posedge clk); @(negedge clk); irq_clear = 0;
        #1; if (irq_level) $fatal(1, "level IRQ did not clear");

        @(negedge clk); rst_n = 0; enable = 0;
        s_awid = 5; s_awmeta = 128'h77; s_seid = 8'h42;
        repeat (2) @(posedge clk);
        @(negedge clk); rst_n = 1; enable = 1;
        timeout = 0;
        while (!m_arvalid && timeout < 40) begin
            @(negedge clk); timeout = timeout + 1;
        end
        #1; if (!m_arvalid || m_araddr !== 64'h4000) $fatal(1, "error case SQ AR missing");
        m_arready = 1;
        @(posedge clk); @(negedge clk); m_arready = 0;
        m_rvalid = 1;
        @(posedge clk); @(negedge clk); m_rvalid = 0;
        timeout = 0;
        while (!dut.core_i.som_candidate_valid && timeout < 40) begin
            @(negedge clk); timeout = timeout + 1;
        end
        if (!dut.core_i.som_candidate_valid) $fatal(1, "error case SQE not ready");
        @(negedge clk); s_awvalid = 1;
        @(posedge clk); @(negedge clk); s_awvalid = 0; s_wvalid = 1;
        @(posedge clk); @(negedge clk); s_wvalid = 0;
        accept_aw(64'h1000, 3'd6); accept_w(64'hffff);
        m_bresp = 2'b10; send_b(); m_bresp = 0;
        timeout = 0;
        while (!s_bvalid && timeout < 30) begin
            @(negedge clk); timeout = timeout + 1;
        end
        if (!s_bvalid || s_bid !== 5 || s_bresp !== 2'b10)
            $fatal(1, "Fabric SLVERR not returned to Controller");
        s_bready = 1;
        @(posedge clk); @(negedge clk); s_bready = 0;
        accept_aw(64'h4000, 3'd5);
        accept_w(64'hffffffff); send_b();
        accept_aw(64'h8000, 3'd4);
        timeout = 0;
        while (!m_wvalid && timeout < 40) begin
            @(negedge clk); timeout = timeout + 1;
        end
        #1; if (m_wdata[126:112] !== 15'h42)
            $fatal(1, "error CQE status wrong: %h", m_wdata[126:112]);
        accept_w(64'h7fff); send_b();
        accept_aw(64'h8000, 3'd4); accept_w(64'h8000); send_b();
        @(negedge clk);
        if (cq_tail !== 1 || sq_rd_ptr !== 1 || !irq_status[6] || !irq_status[7])
            $fatal(1, "error completion not published");

        @(negedge clk); rst_n = 0; enable = 0;
        s_awid = 6; s_eom = 0; message_timeout_cycles = 4;
        repeat (2) @(posedge clk);
        @(negedge clk); rst_n = 1; enable = 1;
        timeout = 0;
        while (!m_arvalid && timeout < 40) begin
            @(negedge clk); timeout = timeout + 1;
        end
        if (!m_arvalid) $fatal(1, "gap case SQ AR missing");
        m_arready = 1;
        @(posedge clk); @(negedge clk); m_arready = 0;
        m_rvalid = 1;
        @(posedge clk); @(negedge clk); m_rvalid = 0;
        timeout = 0;
        while (!dut.core_i.som_candidate_valid && timeout < 40) begin
            @(negedge clk); timeout = timeout + 1;
        end
        if (!dut.core_i.som_candidate_valid) $fatal(1, "gap case SQE not ready");
        @(negedge clk); s_awvalid = 1;
        @(posedge clk); @(negedge clk); s_awvalid = 0; s_wvalid = 1;
        @(posedge clk); @(negedge clk); s_wvalid = 0;
        accept_aw(64'h1000, 3'd6); accept_w(64'hffff);
        if (dut.core_i.gap_timeout_valid) $fatal(1, "gap timed out before Fabric B");
        send_b();
        timeout = 0;
        while (!s_bvalid && timeout < 30) begin
            @(negedge clk); timeout = timeout + 1;
        end
        if (!s_bvalid || s_bid !== 6 || s_bresp !== 0)
            $fatal(1, "gap case original B wrong");
        s_bready = 1;
        @(posedge clk); @(negedge clk); s_bready = 0;
        accept_aw(64'h4000, 3'd5);
        timeout = 0;
        while (!m_wvalid && timeout < 40) begin
            @(negedge clk); timeout = timeout + 1;
        end
        if (m_wdata[219:200] !== 15)
            $fatal(1, "gap timeout SQE LEN wrong");
        accept_w(64'hffffffff); send_b();
        accept_aw(64'h8000, 3'd4);
        timeout = 0;
        while (!m_wvalid && timeout < 40) begin
            @(negedge clk); timeout = timeout + 1;
        end
        if (m_wdata[119:112] !== 8'h26)
            $fatal(1, "gap timeout CQE status wrong");
        accept_w(64'h7fff); send_b();
        accept_aw(64'h8000, 3'd4); accept_w(64'h8000); send_b();
        @(negedge clk);
        if (cq_tail !== 1 || sq_rd_ptr !== 1 || !irq_status[6] || !irq_status[7])
            $fatal(1, "gap timeout did not publish completion");
        force dut.core_i.cq_fault = 1'b1;
        @(posedge clk); @(negedge clk);
        if (!irq_status[5]) $fatal(1, "CQ fatal fault did not raise IRQ");
        release dut.core_i.cq_fault;
        $display("tb_inbound_engine_top PASS");
        $finish;
    end
endmodule
