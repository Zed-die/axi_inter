`timescale 1ns/1ps
module tb_outbound_payload_reader_sweep;
    reg clk = 0;
    always #5 clk = ~clk;
    reg rst_n = 0;
    reg start_valid = 0;
    wire start_ready;
    reg [63:0] start_addr = 0;
    reg [10:0] start_len = 0;
    wire packet_valid, packet_error;
    wire [10:0] packet_len;
    reg packet_release = 0;
    reg [3:0] read_index = 0;
    wire [511:0] read_data;
    wire arvalid;
    reg arready = 0;
    wire [63:0] araddr;
    wire [7:0] arlen;
    wire [2:0] arsize;
    reg rvalid = 0;
    wire rready;
    reg [511:0] rdata = 0;
    reg rlast = 0;
    integer n, j, b, lane, count, watchdog, size_bytes;
    reg [63:0] beat_addr;
    reg [63:0] case_addr;
    reg [10:0] case_len;

    outbound_payload_reader dut (
        .clk            (clk),
        .rst_n          (rst_n),
        .start_valid    (start_valid),
        .start_ready    (start_ready),
        .start_addr     (start_addr),
        .start_len      (start_len),
        .packet_valid   (packet_valid),
        .packet_error   (packet_error),
        .packet_len     (packet_len),
        .packet_release (packet_release),
        .read_index     (read_index),
        .read_data      (read_data),
        .m_axi_arvalid  (arvalid),
        .m_axi_arready  (arready),
        .m_axi_araddr   (araddr),
        .m_axi_arlen    (arlen),
        .m_axi_arsize   (arsize),
        .m_axi_rvalid   (rvalid),
        .m_axi_rready   (rready),
        .m_axi_rdata    (rdata),
        .m_axi_rresp    (2'b00),
        .m_axi_rlast    (rlast),
        .m_axi_rid      (4'd0)
    );

    initial begin
        repeat (2) @(negedge clk); rst_n = 1;
        for (n = 0; n < 128; n = n + 1) begin
            case_addr = 64'h1000 + (((n*197) & 8191) & ~3);
            if (n % 4 == 0) case_addr = 64'h1fc0 + ((n*4) & 60);
            case_len = 1 + ((n*73) % 1024);
            if (n == 127) case_len = 1024;
            @(negedge clk);
            if (!start_ready) $fatal(1, "case %d reader not ready", n);
            start_addr = case_addr; start_len = case_len; start_valid = 1;
            @(posedge clk); @(negedge clk); start_valid = 0;
            watchdog = 0;
            while (!packet_valid && watchdog < 3000) begin
                if (arvalid) begin
                    count = arlen + 1;
                    size_bytes = 1 << arsize;
                    if (count < 1 || count > 16 ||
                        {1'b0, araddr[11:0]} + count*size_bytes > 4096)
                        $fatal(1, "case %d illegal AR addr=%h len=%d size=%d", n, araddr, arlen, arsize);
                    beat_addr = araddr;
                    arready = 1;
                    @(posedge clk); @(negedge clk); arready = 0;
                    for (b = 0; b < count; b = b + 1) begin
                        rdata = 0;
                        for (j = 0; j < size_bytes; j = j + 1) begin
                            lane = (beat_addr[5:0] + j) & 63;
                            rdata[lane*8 +: 8] = (beat_addr + j) & 8'hff;
                        end
                        rlast = b == count - 1;
                        rvalid = 1;
                        #1; if (!rready) $fatal(1, "case %d R stalled", n);
                        @(posedge clk); @(negedge clk); rvalid = 0;
                        beat_addr = beat_addr + size_bytes;
                    end
                    rlast = 0;
                end else @(negedge clk);
                watchdog = watchdog + 1;
            end
            if (!packet_valid || packet_error || packet_len !== case_len)
                $fatal(1, "case %d failed to finish len=%d", n, case_len);
            for (j = 0; j < case_len; j = j + 1) begin
                read_index = j >> 6;
                #1; if (read_data[(j & 63)*8 +: 8] !== ((case_addr+j) & 8'hff))
                    $fatal(1, "case %d payload mismatch at byte %d", n, j);
            end
            packet_release = 1;
            @(posedge clk); @(negedge clk); packet_release = 0;
        end
        $display("tb_outbound_payload_reader_sweep PASS");
        $finish;
    end
endmodule
