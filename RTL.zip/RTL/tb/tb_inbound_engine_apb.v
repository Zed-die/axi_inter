`timescale 1ns/1ps

module tb_inbound_engine_apb;
    reg clk = 1'b0;
    always #5 clk = ~clk;
    reg rst_n = 1'b0;
    reg psel = 1'b0;
    reg penable = 1'b0;
    reg pwrite = 1'b0;
    reg [7:0] paddr = 8'd0;
    reg [31:0] pwdata = 32'd0;
    wire [31:0] prdata;
    wire pready, pslverr;
    wire m_axi_arvalid;
    reg m_axi_arready = 1'b0;
    wire [63:0] m_axi_araddr;
    wire [2:0] m_axi_arsize;
    reg m_axi_rvalid = 1'b0;
    wire m_axi_rready;
    reg [511:0] m_axi_rdata = 512'd0;
    reg s_awvalid = 1'b0;
    wire s_awready;
    reg [7:0] s_seid = 8'h10;
    wire [63:0] s_aw_hdr_34dw = {16'h0000, 16'h1ab4, 8'h01,
                                  8'h01, s_seid, 1'b1, 1'b1, 2'd0, 1'b0, 3'd1};
    reg s_wvalid = 1'b0;
    wire s_wready;
    reg [255:0] sqe0, sqe1;

    inbound_engine_top #(
        .USE_APB   (1'b1),
        .ENABLE_TX (1'b1)
    ) dut (
        .clk           (clk),
        .rst_n         (rst_n),
        .psel          (psel),
        .penable       (penable),
        .pwrite        (pwrite),
        .paddr         (paddr),
        .pwdata        (pwdata),
        .prdata        (prdata),
        .pready        (pready),
        .pslverr       (pslverr),
        .store_bounds_ok(1'b1),
        .congestion_drop(1'b0),
        .lookup_timeout(1'b0),
        .current_timeout(1'b0),
        .s_awvalid     (s_awvalid),
        .s_awready     (s_awready),
        .s_awid        (4'd1),
        .s_awmisc_info ((64'h12 << 19) | 64'h7f),
        .s_aw_hdr_34dw (s_aw_hdr_34dw),
        .s_awlen       (8'd0),
        .s_awsize      (3'd6),
        .s_awburst     (2'b01),
        .s_wvalid      (s_wvalid),
        .s_wready      (s_wready),
        .s_wdata       (512'h1234),
        .s_wstrb       (64'hffff),
        .s_wlast       (1'b1),
        .s_bready      (1'b0),
        .m_axi_arvalid (m_axi_arvalid),
        .m_axi_arready (m_axi_arready),
        .m_axi_araddr  (m_axi_araddr),
        .m_axi_arsize  (m_axi_arsize),
        .m_axi_rvalid  (m_axi_rvalid),
        .m_axi_rready  (m_axi_rready),
        .m_axi_rdata   (m_axi_rdata),
        .m_axi_rresp   (2'b00),
        .m_axi_rlast   (1'b1),
        .m_axi_rid     (4'd0),
        .m_axi_awready (1'b0),
        .m_axi_wready  (1'b0),
        .m_axi_bvalid  (1'b0)
    );

    task apb_write;
        input [7:0] addr;
        input [31:0] data;
        begin
            @(negedge clk);
            psel = 1'b1;
            penable = 1'b0;
            pwrite = 1'b1;
            paddr = addr;
            pwdata = data;
            @(negedge clk);
            penable = 1'b1;
            if (!pready || pslverr) $fatal(1, "APB write rejected");
            @(negedge clk);
            psel = 1'b0;
            penable = 1'b0;
            pwrite = 1'b0;
        end
    endtask

    integer timeout;
    initial begin
        sqe0 = 256'd0;
        sqe1 = 256'd0;
        sqe0[255:240] = 16'h1000;
        sqe0[191:128] = 64'h1000;
        sqe0[95:90] = 6'd1;
        sqe1[255:240] = 16'h1001;
        sqe1[191:128] = 64'h2000;
        sqe1[95:90] = 6'd1;
        repeat (3) @(negedge clk);
        rst_n = 1'b1;
        apb_write(8'h08, 32'h00004000);
        apb_write(8'h10, 32'd2);
        apb_write(8'h54, 32'd3);
        apb_write(8'h00, 32'd1);
        timeout = 0;
        while (!m_axi_arvalid && timeout < 20) begin
            @(negedge clk);
            timeout = timeout + 1;
        end
        if (!m_axi_arvalid || m_axi_araddr !== 64'h4000 ||
            m_axi_arsize !== 3'd6)
            $fatal(1, "APB configuration did not start SQ prefetch");
        m_axi_arready = 1'b1;
        @(posedge clk); @(negedge clk); m_axi_arready = 1'b0;
        m_axi_rdata = {sqe1, sqe0};
        m_axi_rvalid = 1'b1;
        #1; if (!m_axi_rready) $fatal(1, "SQE pair was not accepted");
        @(posedge clk); @(negedge clk); m_axi_rvalid = 1'b0;
        timeout = 0;
        while (!dut.core_i.som_candidate_valid && timeout < 20) begin
            @(negedge clk); timeout = timeout + 1;
        end
        if (!dut.core_i.som_candidate_valid) $fatal(1, "first SQE not ready");
        @(negedge clk); s_awvalid = 1'b1;
        #1; if (!s_awready) $fatal(1, "first packet AW blocked");
        @(posedge clk); @(negedge clk); s_awvalid = 1'b0; s_wvalid = 1'b1;
        #1; if (!s_wready) $fatal(1, "first packet W blocked");
        @(posedge clk); @(negedge clk); s_wvalid = 1'b0;
        if (dut.core_i.buffer_free) $fatal(1, "first packet did not occupy buffer");
        s_seid = 8'h11;
        s_awvalid = 1'b1;
        #1; if (s_awready) $fatal(1, "second packet bypassed occupied buffer");
        timeout = 0;
        while (!s_awready && timeout < 10) begin
            @(negedge clk); timeout = timeout + 1;
        end
        if (!s_awready || !dut.core_i.auto_congestion_drop)
            $fatal(1, "congestion threshold did not choose DROP");
        @(posedge clk); @(negedge clk); s_awvalid = 1'b0;
        if (!dut.core_i.drop_event_valid || dut.core_i.drop_event_reason !== 4'd10)
            $fatal(1, "congestion DROP reason missing");
        s_wvalid = 1'b1;
        @(posedge clk); @(negedge clk); s_wvalid = 1'b0;
        if (dut.core_i.buffer_free) $fatal(1, "DROP corrupted first packet buffer");
        @(negedge clk); rst_n = 1'b0;
        repeat (2) @(negedge clk); rst_n = 1'b1;
        apb_write(8'h68, 32'h0000a000);
        apb_write(8'h70, 32'd1);
        apb_write(8'h74, 32'd128);
        apb_write(8'h78, 32'h00009000);
        apb_write(8'h60, 32'd1);
        timeout = 0;
        while (!m_axi_arvalid && timeout < 20) begin
            @(negedge clk); timeout = timeout + 1;
        end
        if (!m_axi_arvalid || m_axi_araddr !== 64'ha000 ||
            m_axi_arsize !== 3'd5)
            $fatal(1, "TX APB configuration did not start SQ prefetch");
        $display("tb_inbound_engine_apb PASS");
        $finish;
    end
endmodule
