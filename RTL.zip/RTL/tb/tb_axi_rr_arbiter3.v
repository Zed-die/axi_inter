`timescale 1ns/1ps

module tb_axi_rr_arbiter3;
    reg clk = 0;
    always #5 clk = ~clk;
    reg rst_n = 0;
    reg [2:0] req_i = 0;
    reg advance_i = 0;
    reg [1:0] advance_src_i = 0;
    wire grant_valid_o;
    wire [1:0] grant_idx_o;

    axi_rr_arbiter3 dut (
        .clk           (clk),
        .rst_n         (rst_n),
        .req_i         (req_i),
        .advance_i     (advance_i),
        .advance_src_i (advance_src_i),
        .grant_valid_o (grant_valid_o),
        .grant_idx_o   (grant_idx_o)
    );

    task check_grant;
        input expected_valid;
        input [1:0] expected_idx;
        begin
            #1;
            if (grant_valid_o !== expected_valid ||
                (expected_valid && grant_idx_o !== expected_idx)) begin
                $display("arbiter grant mismatch: valid=%b idx=%d expected=%b/%d",
                         grant_valid_o, grant_idx_o, expected_valid, expected_idx);
                $fatal(1);
            end
        end
    endtask

    task advance;
        input [1:0] src;
        begin
            @(negedge clk);
            advance_src_i = src;
            advance_i = 1;
            @(posedge clk);
            #1;
            @(negedge clk);
            advance_i = 0;
        end
    endtask

    initial begin
        repeat (2) @(posedge clk);
        @(negedge clk);
        rst_n = 1;
        req_i = 3'b111;
        check_grant(1, 0);
        advance(0);
        check_grant(1, 1);
        advance(1);
        check_grant(1, 2);
        advance(2);
        check_grant(1, 0);
        req_i = 3'b100;
        check_grant(1, 2);
        req_i = 0;
        check_grant(0, 0);
        $display("PASS tb_axi_rr_arbiter3");
        $finish;
    end
endmodule
