`timescale 1ns/1ps
module tb_outbound_payload_reader;
    reg clk = 0;
    always #5 clk = ~clk;
    reg rst_n = 0;
    reg start_valid = 0;
    wire start_ready;
    reg [63:0] start_addr = 0;
    reg [10:0] start_len = 0;
    wire packet_valid, packet_error;
    wire [10:0] packet_len;
    reg packet_release = 0;
    reg [3:0] read_index = 0;
    wire [511:0] read_data;
    wire arvalid;
    reg arready = 0;
    wire [63:0] araddr;
    wire [7:0] arlen;
    wire [2:0] arsize;
    wire [1:0] arburst;
    reg rvalid = 0;
    wire rready;
    reg [511:0] rdata = 0;
    reg [1:0] rresp = 0;
    reg rlast = 0;
    integer requests, beats, b, j, lane, cycles;
    reg [63:0] beat_addr;

    outbound_payload_reader dut (
        .clk           (clk),
        .rst_n         (rst_n),
        .start_valid   (start_valid),
        .start_ready   (start_ready),
        .start_addr    (start_addr),
        .start_len     (start_len),
        .packet_valid  (packet_valid),
        .packet_error  (packet_error),
        .packet_len    (packet_len),
        .packet_release(packet_release),
        .read_index    (read_index),
        .read_data     (read_data),
        .m_axi_arvalid (arvalid),
        .m_axi_arready (arready),
        .m_axi_araddr  (araddr),
        .m_axi_arlen   (arlen),
        .m_axi_arsize  (arsize),
        .m_axi_arburst (arburst),
        .m_axi_rvalid  (rvalid),
        .m_axi_rready  (rready),
        .m_axi_rdata   (rdata),
        .m_axi_rresp   (rresp),
        .m_axi_rlast   (rlast),
        .m_axi_rid    (4'd0)
    );

    task start_packet;
        input [63:0] addr;
        input [10:0] len;
        begin
            @(negedge clk);
            start_addr = addr; start_len = len; start_valid = 1;
            #1; if (!start_ready) $fatal(1, "reader not ready");
            @(posedge clk); @(negedge clk); start_valid = 0;
        end
    endtask

    task service_burst;
        input bad_resp;
        begin
            cycles = 0;
            while (!arvalid && cycles < 100) begin
                @(negedge clk); cycles = cycles + 1;
            end
            if (!arvalid || arburst !== 2'b01 ||
                ({1'b0, araddr[11:0]} + ((arlen + 1) << arsize)) > 4096)
                $fatal(1, "illegal payload AR addr=%h len=%d size=%d", araddr, arlen, arsize);
            requests = requests + 1;
            beat_addr = araddr;
            beats = arlen + 1;
            arready = 1;
            @(posedge clk); @(negedge clk); arready = 0;
            for (b = 0; b < beats; b = b + 1) begin
                rdata = 0;
                for (j = 0; j < (1 << arsize); j = j + 1) begin
                    lane = (beat_addr[5:0] + j) & 63;
                    rdata[lane*8 +: 8] = (beat_addr + j) & 8'hff;
                end
                rresp = bad_resp ? 2'b10 : 2'b00;
                rlast = b == beats - 1;
                rvalid = 1;
                #1; if (!rready) $fatal(1, "reader rejected R beat");
                @(posedge clk); @(negedge clk); rvalid = 0;
                beat_addr = beat_addr + (1 << arsize);
            end
            rresp = 0; rlast = 0;
        end
    endtask

    initial begin
        repeat (2) @(negedge clk); rst_n = 1;
        start_packet(64'h1fc4, 11'd128);
        requests = 0;
        service_burst(0);
        if (arsize !== 3'd2 || beats !== 15) $fatal(1, "unaligned head was not narrow");
        service_burst(0);
        if (arsize !== 3'd6 || beats !== 1) $fatal(1, "aligned body was not full width");
        service_burst(0);
        if (requests !== 3 || arsize !== 3'd2 || beats !== 1)
            $fatal(1, "tail burst wrong");
        if (!packet_valid || packet_error || packet_len !== 128)
            $fatal(1, "completed packet missing");
        for (j = 0; j < 128; j = j + 1) begin
            read_index = j >> 6;
            #1; if (read_data[(j & 63)*8 +: 8] !== ((64'h1fc4 + j) & 8'hff))
                $fatal(1, "packed byte mismatch index=%d", j);
        end
        packet_release = 1;
        @(posedge clk); @(negedge clk); packet_release = 0;
        start_packet(64'h3000, 11'd64);
        service_burst(1);
        if (!packet_valid || !packet_error || arvalid)
            $fatal(1, "RRESP error was not reported");
        packet_release = 1;
        @(posedge clk); @(negedge clk); packet_release = 0;
        start_packet(64'h4000, 11'd1024);
        service_burst(0);
        if (arsize !== 3'd6 || beats !== 16 || !packet_valid || packet_error)
            $fatal(1, "1 KiB packet did not use a 16-beat full-width AR");
        read_index = 4'd15;
        #1; if (read_data[7:0] !== 8'hc0 || read_data[511:504] !== 8'hff)
            $fatal(1, "1 KiB packet final row wrong");
        packet_release = 1;
        @(posedge clk); @(negedge clk); packet_release = 0;
        start_packet(64'hffff_ffff_ffff_ffc0, 11'd128);
        if (!packet_valid || !packet_error || arvalid)
            $fatal(1, "payload address overflow was not rejected");
        packet_release = 1;
        @(posedge clk); @(negedge clk); packet_release = 0;
        start_packet(64'hffff_ffff_ffff_ffc0, 11'd64);
        service_burst(0);
        if (!packet_valid || packet_error || araddr !== 64'hffff_ffff_ffff_ffc0)
            $fatal(1, "last legal 64-byte payload was rejected");
        $display("tb_outbound_payload_reader PASS");
        $finish;
    end
endmodule
