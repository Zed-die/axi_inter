`timescale 1ns/1ps

module tb_inbound_router_chain;
    reg clk = 0;
    always #5 clk = ~clk;
    reg rst_n = 0;
    reg enable = 0;
    wire prefetch_req_valid;
    reg prefetch_req_ready = 0;
    reg [4:0] prefetch_accept_num = 0;
    reg prefetch_sq_empty = 1;
    reg [255:0] prefetch_sq_dout = 0;
    wire [19:0] som_key;
    wire [19:0] lookup_key;
    wire som_candidate_valid;
    wire som_conflict;
    wire [2:0] som_slot;
    wire [255:0] som_sqe;
    wire som_bind;
    wire lookup_valid;
    wire [2:0] lookup_slot;
    wire [255:0] lookup_sqe;
    wire [1:0] lookup_next_seq;
    wire lookup_seq_valid;
    wire packet_commit_valid;
    wire packet_commit_ready;
    wire [2:0] packet_commit_slot;
    wire [31:0] packet_commit_bytes;
    wire [1:0] packet_commit_seq;
    wire packet_commit_eom;
    reg s_awvalid = 0;
    wire s_awready;
    reg [7:0] s_awlen = 0;
    reg [7:0] s_seid = 8'h42;
    reg s_som = 1;
    reg s_eom = 0;
    reg [1:0] s_seq = 0;
    wire [63:0] s_aw_hdr_34dw = {16'h0000, 16'h1ab4, 8'h01,
                                  8'h01, s_seid, s_som, s_eom, s_seq, 1'b0, 3'd1};
    reg s_wvalid = 0;
    wire s_wready;
    reg [511:0] s_wdata = 0;
    reg [63:0] s_wstrb = {64{1'b1}};
    reg s_wlast = 0;
    wire packet_valid;
    wire packet_ready;
    wire packet_release;
    wire [4:0] packet_token;
    wire [2:0] packet_slot;
    wire packet_som;
    wire packet_eom;
    wire [1:0] packet_seq;
    wire [10:0] packet_wbytes;
    wire [4:0] packet_beats;
    wire [255:0] packet_sqe;
    wire buf_free;
    wire buf_reserve;
    wire buf_write;
    wire [3:0] buf_wr_addr;
    wire [511:0] buf_wr_data;
    wire [63:0] buf_wr_strb;
    wire buf_finish;
    wire buf_finish_good;
    wire buf_packet_valid;
    wire buf_packet_ready;
    wire buf_packet_release;
    wire [3:0] buf_rd_addr;
    wire [511:0] buf_rd_data;
    wire [63:0] buf_rd_strb;
    wire result_valid;
    reg result_ready = 0;
    wire result_error;
    wire [3:0] result_reason;
    wire m_axi_awvalid;
    reg m_axi_awready = 0;
    wire [63:0] m_axi_awaddr;
    wire [7:0] m_axi_awlen;
    wire m_axi_wvalid;
    reg m_axi_wready = 0;
    wire [63:0] m_axi_wstrb;
    wire m_axi_wlast;
    reg m_axi_bvalid = 0;
    wire m_axi_bready;
    integer commit_count = 0;

    inbound_sq_manager manager_i (
        .clk                       (clk),
        .rst_n                     (rst_n),
        .enable                    (enable),
        .sq_base_addr              (64'h4000),
        .sq_depth                  (16'd256),
        .prefetch_req_valid        (prefetch_req_valid),
        .prefetch_req_ready        (prefetch_req_ready),
        .prefetch_accept_num       (prefetch_accept_num),
        .prefetch_fetch_ptr        (16'd0),
        .prefetch_sq_empty         (prefetch_sq_empty),
        .prefetch_sq_dout          (prefetch_sq_dout),
        .prefetch_sq_ptr           (16'd0),
        .prefetch_sq_error         (1'b0),
        .prefetch_fault            (1'b0),
        .som_key                   (som_key),
        .som_seq                   (s_seq),
        .som_bind                  (som_bind),
        .som_candidate_valid       (som_candidate_valid),
        .som_conflict              (som_conflict),
        .som_slot                  (som_slot),
        .som_sqe                   (som_sqe),
        .lookup_key                (lookup_key),
        .lookup_valid              (lookup_valid),
        .lookup_slot               (lookup_slot),
        .lookup_sqe                (lookup_sqe),
        .lookup_next_seq           (lookup_next_seq),
        .lookup_seq_valid          (lookup_seq_valid),
        .packet_commit_valid       (packet_commit_valid),
        .packet_commit_ready       (packet_commit_ready),
        .packet_commit_slot        (packet_commit_slot),
        .packet_commit_bytes       (packet_commit_bytes),
        .packet_commit_seq         (packet_commit_seq),
        .packet_commit_eom         (packet_commit_eom),
        .message_done_valid        (1'b0),
        .message_done_slot         (3'd0),
        .message_done_update       (256'd0),
        .message_done_status       (8'd0),
        .message_done_abort        (1'b0),
        .m_axi_awready             (1'b0),
        .m_axi_wready              (1'b0),
        .m_axi_bvalid              (1'b0),
        .m_axi_bresp               (2'd0),
        .m_axi_bid                 (4'd0),
        .cq_req_ready              (1'b0),
        .cq_publish_valid          (1'b0),
        .cq_publish_success        (1'b0)
    );

    mctp_decoder decoder_i (
        .clk                  (clk),
        .rst_n                (rst_n),
        .s_axi_awvalid            (s_awvalid),
        .s_axi_awready            (s_awready),
        .s_axi_awmisc_info        ((64'h12 << 19) | 64'h7f),
        .s_axi_aw_hdr_34dw        (s_aw_hdr_34dw),
        .response_credit      (1'b1),
        .response_token       (5'd0),
        .s_axi_awlen              (s_awlen),
        .s_axi_awsize             (3'd6),
        .s_axi_awburst            (2'b01),
        .s_axi_wvalid             (s_wvalid),
        .s_axi_wready             (s_wready),
        .s_axi_wdata              (s_wdata),
        .s_axi_wstrb              (s_wstrb),
        .s_axi_wlast              (s_wlast),
        .filter_enable        (1'b0),
        .rule_enable          (4'd0),
        .rule_drop            (4'd0),
        .rule_value           (32'd0),
        .rule_mask            (32'd0),
        .default_drop         (1'b0),
        .som_key              (som_key),
        .som_candidate_valid  (som_candidate_valid),
        .som_conflict         (som_conflict),
        .som_slot             (som_slot),
        .som_sqe              (som_sqe),
        .som_bind             (som_bind),
        .lookup_key           (lookup_key),
        .lookup_valid         (lookup_valid),
        .lookup_slot          (lookup_slot),
        .lookup_sqe           (lookup_sqe),
        .lookup_seq_valid     (lookup_seq_valid),
        .lookup_next_seq      (lookup_next_seq),
        .lookup_timeout       (1'b0),
        .store_bounds_ok      (1'b1),
        .congestion_drop      (1'b0),
        .current_timeout      (1'b0),
        .packet_valid         (packet_valid),
        .packet_ready         (packet_ready),
        .packet_release       (packet_release),
        .packet_token         (packet_token),
        .packet_slot          (packet_slot),
        .packet_som           (packet_som),
        .packet_eom           (packet_eom),
        .packet_seq           (packet_seq),
        .packet_wbytes        (packet_wbytes),
        .packet_beats         (packet_beats),
        .packet_sqe           (packet_sqe),
        .buf_free             (buf_free),
        .buf_reserve          (buf_reserve),
        .buf_write            (buf_write),
        .buf_wr_addr          (buf_wr_addr),
        .buf_wr_data          (buf_wr_data),
        .buf_wr_strb          (buf_wr_strb),
        .buf_finish           (buf_finish),
        .buf_finish_good      (buf_finish_good),
        .buf_packet_valid     (buf_packet_valid),
        .buf_packet_ready     (buf_packet_ready),
        .buf_packet_release   (buf_packet_release),
        .drop_done_ready      (1'b1)
    );

    inbound_packet_buffer buffer_i (
        .clk                  (clk),
        .rst_n                (rst_n),
        .free                 (buf_free),
        .reserve              (buf_reserve),
        .write_en             (buf_write),
        .write_addr           (buf_wr_addr),
        .write_data           (buf_wr_data),
        .write_strb           (buf_wr_strb),
        .finish               (buf_finish),
        .finish_good          (buf_finish_good),
        .packet_valid         (buf_packet_valid),
        .packet_ready         (buf_packet_ready),
        .packet_release       (buf_packet_release),
        .read_addr            (buf_rd_addr),
        .read_data            (buf_rd_data),
        .read_strb            (buf_rd_strb)
    );

    inbound_router router_i (
        .clk                  (clk),
        .rst_n                (rst_n),
        .packet_valid         (packet_valid),
        .packet_ready         (packet_ready),
        .packet_release       (packet_release),
        .packet_token         (packet_token),
        .packet_slot          (packet_slot),
        .packet_som           (packet_som),
        .packet_eom           (packet_eom),
        .packet_seq           (packet_seq),
        .packet_wbytes        (packet_wbytes),
        .packet_beats         (packet_beats),
        .packet_sqe           (packet_sqe),
        .buf_rd_addr          (buf_rd_addr),
        .buf_rd_data          (buf_rd_data),
        .buf_rd_strb          (buf_rd_strb),
        .packet_commit_valid  (packet_commit_valid),
        .packet_commit_ready  (packet_commit_ready),
        .packet_commit_slot   (packet_commit_slot),
        .packet_commit_bytes  (packet_commit_bytes),
        .packet_commit_seq    (packet_commit_seq),
        .packet_commit_eom    (packet_commit_eom),
        .result_valid         (result_valid),
        .result_ready         (result_ready),
        .result_error         (result_error),
        .result_reason        (result_reason),
        .m_axi_awvalid        (m_axi_awvalid),
        .m_axi_awready        (m_axi_awready),
        .m_axi_awaddr         (m_axi_awaddr),
        .m_axi_awlen          (m_axi_awlen),
        .m_axi_wvalid         (m_axi_wvalid),
        .m_axi_wready         (m_axi_wready),
        .m_axi_wstrb          (m_axi_wstrb),
        .m_axi_wlast          (m_axi_wlast),
        .m_axi_bvalid         (m_axi_bvalid),
        .m_axi_bready         (m_axi_bready),
        .m_axi_bresp          (2'b00),
        .m_axi_bid            (4'd0)
    );

    always @(posedge clk) if (packet_commit_valid && packet_commit_ready)
        commit_count = commit_count + 1;

    function [255:0] rx_sqe;
        input unused;
        begin
            rx_sqe = 0;
            rx_sqe[255:240] = 16'h1234;
            rx_sqe[191:128] = 64'hff0;
            rx_sqe[95:90] = 6'd1;
        end
    endfunction

    task send_aw;
        input [127:0] meta;
        input som;
        input eom;
        input [1:0] seq;
        input [7:0] len;
        integer timeout;
        begin
            @(negedge clk); s_som = som; s_eom = eom;
            s_seq = seq; s_awlen = len; s_awvalid = 1;
            timeout = 0;
            while (!s_awready && timeout < 80) begin
                @(negedge clk); timeout = timeout + 1;
            end
            if (!s_awready) $fatal(1, "controller AW stalled");
            @(posedge clk);
            @(negedge clk); s_awvalid = 0;
        end
    endtask

    task send_w;
        input [63:0] strb;
        input last;
        begin
            @(negedge clk); s_wvalid = 1; s_wdata = {16{32'habcdef01}};
            s_wstrb = strb; s_wlast = last;
            #1; if (!s_wready) $fatal(1, "controller W stalled");
            @(posedge clk);
            @(negedge clk); s_wvalid = 0;
        end
    endtask

    task check_aw;
        input [63:0] addr;
        input [7:0] len;
        integer timeout;
        begin
            timeout = 0;
            while (!m_axi_awvalid && timeout < 80) begin
                @(negedge clk); timeout = timeout + 1;
            end
            #1; if (!m_axi_awvalid || m_axi_awaddr !== addr || m_axi_awlen !== len)
                $fatal(1, "Fabric AW mismatch addr=%h len=%d", m_axi_awaddr, m_axi_awlen);
            m_axi_awready = 1;
            @(posedge clk);
            @(negedge clk); m_axi_awready = 0;
        end
    endtask

    task check_w;
        input [63:0] strb;
        input last;
        integer timeout;
        begin
            timeout = 0;
            while (!m_axi_wvalid && timeout < 40) begin
                @(negedge clk); timeout = timeout + 1;
            end
            #1; if (!m_axi_wvalid || m_axi_wstrb !== strb || m_axi_wlast !== last)
                $fatal(1, "Fabric W mismatch strb=%h last=%b", m_axi_wstrb, m_axi_wlast);
            m_axi_wready = 1;
            @(posedge clk);
            @(negedge clk); m_axi_wready = 0;
        end
    endtask

    task send_b;
        begin
            @(negedge clk); m_axi_bvalid = 1;
            #1; if (!m_axi_bready) $fatal(1, "Fabric B not accepted");
            @(posedge clk);
            @(negedge clk); m_axi_bvalid = 0;
        end
    endtask

    task take_result;
        input [127:0] meta;
        integer timeout;
        begin
            timeout = 0;
            while (!result_valid && timeout < 40) begin
                @(negedge clk); timeout = timeout + 1;
            end
            #1; if (!result_valid || result_error)
                $fatal(1, "route result mismatch");
            result_ready = 1;
            @(posedge clk);
            @(negedge clk); result_ready = 0;
        end
    endtask

    initial begin
        repeat (2) @(posedge clk);
        @(negedge clk); rst_n = 1; enable = 1;
        #1; if (!prefetch_req_valid) $fatal(1, "no SQ prefetch credit");
        prefetch_req_ready = 1; prefetch_accept_num = 1;
        @(posedge clk);
        @(negedge clk); prefetch_req_ready = 0;
        prefetch_sq_dout = rx_sqe(1'b0); prefetch_sq_empty = 0;
        @(posedge clk);
        @(negedge clk); prefetch_sq_empty = 1;

        send_aw(128'ha1, 1, 0, 0, 1);
        send_w({64{1'b1}}, 0); send_w({64{1'b1}}, 1);
        check_aw(64'hfc0, 0); check_w(64'hffff000000000000, 1); send_b();
        check_aw(64'h1000, 1); check_w({64{1'b1}}, 0);
        check_w(64'h0000ffffffffffff, 1); send_b();
        take_result(128'ha1);
        #1; if (commit_count !== 1 || !lookup_seq_valid ||
                 lookup_next_seq !== 1)
            $fatal(1, "first packet not committed to SQ manager");

        send_aw(128'ha2, 0, 1, 1, 0);
        send_w(64'hffffffff, 1);
        check_aw(64'h1040, 1);
        check_w(64'hffff000000000000, 0);
        check_w(64'h000000000000ffff, 1); send_b();
        take_result(128'ha2);
        #1; if (commit_count !== 2 || lookup_valid ||
                manager_i.slot_offset[0] !== 160)
            $fatal(1, "continuation/EOM not committed");
        $display("tb_inbound_router_chain PASS");
        $finish;
    end
endmodule
