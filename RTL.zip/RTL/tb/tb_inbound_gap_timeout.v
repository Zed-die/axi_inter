`timescale 1ns/1ps

module tb_inbound_gap_timeout;
    reg clk = 1'b0;
    always #5 clk = ~clk;
    reg rst_n = 1'b0;
    reg [31:0] timeout_cycles = 32'd3;
    reg store_valid = 1'b0;
    reg [2:0] store_slot = 3'd0;
    reg route_valid = 1'b0;
    reg [2:0] route_slot = 3'd0;
    reg route_eom = 1'b0;
    reg route_error = 1'b0;
    reg abort_valid = 1'b0;
    reg [2:0] abort_slot = 3'd0;
    reg done_valid = 1'b0;
    reg [2:0] done_slot = 3'd0;
    wire timeout_valid;
    wire [2:0] timeout_slot;
    wire [7:0] expired;

    inbound_gap_timeout dut (
        .clk            (clk),
        .rst_n          (rst_n),
        .timeout_cycles (timeout_cycles),
        .store_valid    (store_valid),
        .store_slot     (store_slot),
        .route_valid    (route_valid),
        .route_slot     (route_slot),
        .route_eom      (route_eom),
        .route_error    (route_error),
        .abort_valid    (abort_valid),
        .abort_slot     (abort_slot),
        .done_valid     (done_valid),
        .done_slot      (done_slot),
        .timeout_valid  (timeout_valid),
        .timeout_slot   (timeout_slot),
        .expired        (expired)
    );

    task tick;
        begin
            @(posedge clk);
            #1;
        end
    endtask

    initial begin
        tick();
        rst_n = 1'b1;
        @(negedge clk);
        route_valid = 1'b1;
        route_slot = 3'd2;
        tick();
        route_valid = 1'b0;
        tick();
        if (timeout_valid) $fatal(1, "expired too early");
        @(negedge clk);
        store_valid = 1'b1;
        store_slot = 3'd2;
        tick();
        store_valid = 1'b0;
        repeat (5) tick();
        if (timeout_valid || expired[2]) $fatal(1, "timer ran during packet");
        @(negedge clk);
        route_valid = 1'b1;
        route_slot = 3'd2;
        tick();
        route_valid = 1'b0;
        repeat (2) tick();
        if (!timeout_valid || timeout_slot != 3'd2)
            $fatal(1, "missing gap expiration");
        tick();
        if (!expired[2] || timeout_valid)
            $fatal(1, "expiry must latch once until completion");
        @(negedge clk);
        done_valid = 1'b1;
        done_slot = 3'd2;
        tick();
        if (expired[2]) $fatal(1, "completion did not clear expiry");
        $display("tb_inbound_gap_timeout PASS");
        $finish;
    end
endmodule
