`timescale 1ns/1ps
module tb_apb_interface;
    reg clk = 0;
    always #5 clk = ~clk;
    reg rst_n = 0;
    reg psel = 0;
    reg penable = 0;
    reg pwrite = 0;
    reg [7:0] paddr = 0;
    reg [31:0] pwdata = 0;
    wire pready;
    wire pslverr;
    wire [31:0] prdata;
    wire enable;
    wire [63:0] sq_base_addr, cq_base_addr;
    wire [15:0] sq_tail_ptr;
    wire [8:0] sq_depth;
    wire [8:0] cq_head;
    wire [7:0] irq_mask, irq_clear;
    wire tx_enable;
    wire [63:0] tx_sq_base_addr, tx_target_addr;
    wire [15:0] tx_sq_tail_ptr;
    wire [10:0] tx_tuz_bytes;
    wire [1:0] tx_start_seq;
    wire direct_enable_out, direct_tx_enable_out;
    wire [63:0] direct_sq_base_out;
    wire [7:0] direct_irq_mask_out, direct_irq_clear_out;
    apb_interface #(
        .USE_APB (1'b1)
    ) dut (
        .clk             (clk),
        .rst_n           (rst_n),
        .psel            (psel),
        .penable         (penable),
        .pwrite          (pwrite),
        .paddr           (paddr),
        .pwdata          (pwdata),
        .prdata          (prdata),
        .pready          (pready),
        .pslverr         (pslverr),
        .cfg_enable      (enable),
        .cfg_sq_base_addr(sq_base_addr),
        .cfg_sq_tail_ptr (sq_tail_ptr),
        .cfg_sq_depth    (sq_depth),
        .cfg_cq_base_addr(cq_base_addr),
        .cfg_cq_head     (cq_head),
        .cfg_irq_mask    (irq_mask),
        .cfg_irq_clear   (irq_clear),
        .irq_status      (8'h84),
        .cq_tail         (9'd3),
        .sq_rd_ptr       (16'd7),
        .cfg_tx_enable       (tx_enable),
        .cfg_tx_sq_base_addr (tx_sq_base_addr),
        .cfg_tx_sq_tail_ptr  (tx_sq_tail_ptr),
        .cfg_tx_tuz_bytes    (tx_tuz_bytes),
        .cfg_tx_target_addr  (tx_target_addr),
        .cfg_tx_start_seq    (tx_start_seq),
        .tx_sq_rd_ptr    (16'd9)
    );
    apb_interface #(
        .USE_APB (1'b0)
    ) direct_dut (
        .clk                    (clk),
        .rst_n                  (rst_n),
        .psel                   (psel),
        .penable                (penable),
        .pwrite                 (pwrite),
        .paddr                  (paddr),
        .pwdata                 (pwdata),
        .direct_enable          (1'b1),
        .direct_sq_base_addr    (64'ha000),
        .direct_tx_enable       (1'b1),
        .direct_irq_mask        (8'haa),
        .direct_irq_clear       (8'h55),
        .cfg_enable             (direct_enable_out),
        .cfg_sq_base_addr       (direct_sq_base_out),
        .cfg_tx_enable          (direct_tx_enable_out),
        .cfg_irq_mask           (direct_irq_mask_out),
        .cfg_irq_clear          (direct_irq_clear_out)
    );
    task write_reg;
        input [7:0] addr;
        input [31:0] value;
        begin
            @(negedge clk); psel = 1; penable = 1; pwrite = 1;
            paddr = addr; pwdata = value;
            #1; if (!pready || pslverr) $fatal(1, "APB write rejected");
            @(posedge clk); @(negedge clk); psel = 0; penable = 0; pwrite = 0;
        end
    endtask
    initial begin
        repeat (2) @(posedge clk);
        @(negedge clk); rst_n = 1;
        write_reg(8'h08, 32'h12345000);
        write_reg(8'h0c, 32'h00000001);
        write_reg(8'h10, 32'd1);
        write_reg(8'h14, 32'd64);
        @(negedge clk); psel = 1; penable = 1; pwrite = 1;
        paddr = 8'h14; pwdata = 32'd96;
        #1; if (!pslverr) $fatal(1, "non-power-of-two RX depth accepted");
        @(posedge clk); @(negedge clk); psel = 0; penable = 0; pwrite = 0;
        if (sq_depth !== 9'd64) $fatal(1, "invalid RX depth changed register");
        write_reg(8'h18, 32'h8000);
        write_reg(8'h20, 32'd2);
        write_reg(8'h40, 32'h84);
        write_reg(8'h00, 32'd1);
        write_reg(8'h68, 32'h00004000);
        write_reg(8'h70, 32'd5);
        write_reg(8'h74, 32'd128);
        write_reg(8'h78, 32'h00009000);
        write_reg(8'h80, 32'd3);
        write_reg(8'h60, 32'd1);
        if (!enable || sq_base_addr !== 64'h0000000112345000 ||
            sq_depth !== 9'd64 ||
            sq_tail_ptr !== 1 || cq_base_addr !== 64'h8000 ||
            cq_head !== 2 || irq_mask !== 8'h84)
            $fatal(1, "APB configuration outputs wrong");
        if (!tx_enable || tx_sq_base_addr !== 64'h4000 ||
            tx_sq_tail_ptr !== 5 || tx_tuz_bytes !== 128 ||
            tx_target_addr !== 64'h9000 || tx_start_seq !== 3)
            $fatal(1, "TX APB configuration outputs wrong");
        if (!direct_enable_out || !direct_tx_enable_out ||
            direct_sq_base_out !== 64'ha000 ||
            direct_irq_mask_out !== 8'haa || direct_irq_clear_out !== 8'h55)
            $fatal(1, "direct configuration bypass wrong");
        @(negedge clk); psel = 1; penable = 1; pwrite = 1;
        paddr = 8'h14; pwdata = 32'd128;
        #1; if (!pslverr) $fatal(1, "active RX depth update was accepted");
        @(posedge clk); @(negedge clk); psel = 0; penable = 0; pwrite = 0;
        if (sq_depth !== 9'd64) $fatal(1, "rejected depth update changed RX SQ");
        @(negedge clk); psel = 1; penable = 1; pwrite = 1;
        paddr = 8'h44; pwdata = 32'h80;
        #1; if (irq_clear !== 8'h80) $fatal(1, "IRQ W1C pulse missing");
        @(posedge clk); @(negedge clk); pwrite = 0; paddr = 8'h48;
        #1; if (prdata !== 3) $fatal(1, "CQ tail readback wrong");
        paddr = 8'h4c;
        #1; if (prdata !== 7) $fatal(1, "SQ RD readback wrong");
        paddr = 8'h14;
        #1; if (prdata !== 64) $fatal(1, "RX SQ depth readback wrong");
        paddr = 8'h84;
        #1; if (prdata !== 9) $fatal(1, "TX SQ RD readback wrong");
        psel = 0; penable = 0;
        $display("tb_apb_interface PASS");
        $finish;
    end
endmodule
