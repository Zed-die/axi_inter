`timescale 1ns/1ps
module tb_mctp_engine_top;
    reg clk = 1'b0;
    always #5 clk = ~clk;
    reg rst_n = 1'b0;
    reg psel = 1'b0, penable = 1'b0, pwrite = 1'b0;
    reg [7:0] paddr = 8'd0;
    reg [31:0] pwdata = 32'd0;
    wire [31:0] prdata;
    wire pready, pslverr;
    wire m_axi_arvalid;
    reg m_axi_arready = 1'b0;
    wire [63:0] m_axi_araddr;
    wire [2:0] m_axi_arsize;
    reg seen_rx = 1'b0, seen_tx = 1'b0;
    integer cycles;

    mctp_engine dut (
        .clk             (clk),
        .rst_n           (rst_n),
        .psel            (psel),
        .penable         (penable),
        .pwrite          (pwrite),
        .paddr           (paddr),
        .pwdata          (pwdata),
        .prdata          (prdata),
        .pready          (pready),
        .pslverr         (pslverr),
        .s_awvalid       (1'b0),
        .s_wvalid        (1'b0),
        .s_bready        (1'b1),
        .tx_awready      (1'b0),
        .tx_wready       (1'b0),
        .tx_bvalid       (1'b0),
        .m_axi_arvalid  (m_axi_arvalid),
        .m_axi_arready  (m_axi_arready),
        .m_axi_araddr   (m_axi_araddr),
        .m_axi_arsize   (m_axi_arsize),
        .m_axi_rvalid   (1'b0),
        .m_axi_awready  (1'b0),
        .m_axi_wready   (1'b0),
        .m_axi_bvalid   (1'b0)
    );

    task apb_write;
        input [7:0] addr;
        input [31:0] data;
        begin
            @(negedge clk);
            psel = 1'b1; penable = 1'b0; pwrite = 1'b1;
            paddr = addr; pwdata = data;
            @(negedge clk);
            penable = 1'b1;
            #1; if (!pready || pslverr) $fatal(1, "APB write rejected");
            @(negedge clk);
            psel = 1'b0; penable = 1'b0; pwrite = 1'b0;
        end
    endtask

    always @(posedge clk) begin
        if (rst_n && m_axi_arvalid && m_axi_arready) begin
            if (m_axi_araddr == 64'h4000 && m_axi_arsize == 3'd5)
                seen_rx <= 1'b1;
            else if (m_axi_araddr == 64'ha000 && m_axi_arsize == 3'd5)
                seen_tx <= 1'b1;
            else $fatal(1, "unexpected prefetch AR %h size=%d", m_axi_araddr, m_axi_arsize);
        end
    end

    initial begin
        repeat (3) @(negedge clk);
        rst_n = 1'b1;
        apb_write(8'h08, 32'h4000);
        apb_write(8'h10, 32'd1);
        apb_write(8'h68, 32'ha000);
        apb_write(8'h70, 32'd1);
        apb_write(8'h00, 32'd1);
        apb_write(8'h60, 32'd1);
        @(negedge clk); m_axi_arready = 1'b1;
        cycles = 0;
        while (!(seen_rx && seen_tx) && cycles < 30) begin
            @(negedge clk);
            cycles = cycles + 1;
        end
        if (!(seen_rx && seen_tx))
            $fatal(1, "top did not issue both RX and TX SQ prefetches");

        @(negedge clk); rst_n = 1'b0; m_axi_arready = 1'b0;
        repeat (3) @(negedge clk);
        rst_n = 1'b1;
        apb_write(8'h08, 32'h4000);
        apb_write(8'h14, 32'd64);
        apb_write(8'h10, 32'd63); // The producer index is in [0, depth-1].
        apb_write(8'h00, 32'd1);
        repeat (10) @(negedge clk);
        if (!m_axi_arvalid || m_axi_araddr !== 64'h4000 || m_axi_arsize !== 3'd6)
            $fatal(1, "configured RX depth did not reach prefetch");

        @(negedge clk); rst_n = 1'b0;
        repeat (3) @(negedge clk);
        rst_n = 1'b1;
        apb_write(8'h08, 32'h8000);
        apb_write(8'h14, 32'd512);
        apb_write(8'h10, 32'd1);
        apb_write(8'h00, 32'd1);
        repeat (10) @(negedge clk);
        if (!m_axi_arvalid || m_axi_araddr !== 64'h8000 || m_axi_arsize !== 3'd5)
            $fatal(1, "16-bit RX depth did not propagate through engine top");
        $display("tb_mctp_engine_top PASS");
        $finish;
    end
endmodule
