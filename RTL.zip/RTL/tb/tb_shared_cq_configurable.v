`timescale 1ns/1ps
module tb_shared_cq_configurable;
    reg clk = 0;
    always #5 clk = ~clk;
    reg rst_n = 0;
    reg [15:0] cq_depth = 16'd4;
    reg [15:0] cq_head = 0;
    wire [15:0] cq_tail;
    reg rx_req_valid = 0;
    wire rx_req_ready, rx_publish_valid, rx_publish_success;
    reg [15:0] rx_req_cid = 0;
    wire awvalid, wvalid, bready;
    reg awready = 0, wready = 0, bvalid = 0;
    wire [63:0] awaddr, wstrb;
    wire [511:0] wdata;
    integer n, part, lane, timeout;
    reg expected_phase;

    shared_cq_manager dut (
        .clk                 (clk),
        .rst_n               (rst_n),
        .cq_base_addr        (64'h8000),
        .cq_depth            (cq_depth),
        .cq_head             (cq_head),
        .cq_tail             (cq_tail),
        .rx_req_valid        (rx_req_valid),
        .rx_req_ready        (rx_req_ready),
        .rx_req_cid          (rx_req_cid),
        .rx_req_status       (8'd0),
        .rx_req_candidate_rd (16'd0),
        .rx_publish_valid    (rx_publish_valid),
        .rx_publish_success  (rx_publish_success),
        .tx_req_valid        (1'b0),
        .m_axi_awvalid       (awvalid),
        .m_axi_awready       (awready),
        .m_axi_awaddr        (awaddr),
        .m_axi_wvalid        (wvalid),
        .m_axi_wready        (wready),
        .m_axi_wdata         (wdata),
        .m_axi_wstrb         (wstrb),
        .m_axi_bvalid        (bvalid),
        .m_axi_bready        (bready),
        .m_axi_bresp         (2'b00),
        .m_axi_bid           (4'd0)
    );

    task publish_one;
        input [15:0] expected_tail;
        begin
            @(negedge clk);
            rx_req_cid = expected_tail;
            rx_req_valid = 1;
            #1; if (!rx_req_ready) $fatal(1, "CQ refused tail=%d", expected_tail);
            expected_phase = (expected_tail & cq_depth) == 0;
            @(posedge clk); @(negedge clk); rx_req_valid = 0;
            for (part = 0; part < 2; part = part + 1) begin
                timeout = 0;
                while (!awvalid && timeout < 20) begin
                    @(negedge clk); timeout = timeout + 1;
                end
                if (!awvalid || awaddr !== 64'h8000 + ((expected_tail & (cq_depth - 1)) << 4))
                    $fatal(1, "CQ AW wrong depth=%d tail=%d addr=%h", cq_depth, expected_tail, awaddr);
                lane = (expected_tail & 3) << 4;
                awready = 1;
                @(posedge clk); @(negedge clk); awready = 0;
                if (!wvalid || wstrb !== ((part ? 64'h8000 : 64'h7fff) << lane) ||
                    wdata[lane*8+127] !== expected_phase ||
                    wdata[lane*8+96 +:16] !== expected_tail)
                    $fatal(1, "CQ W wrong depth=%d tail=%d part=%d", cq_depth, expected_tail, part);
                wready = 1;
                @(posedge clk); @(negedge clk); wready = 0;
                if (!bready) $fatal(1, "CQ B not ready");
                bvalid = 1;
                @(posedge clk); @(negedge clk); bvalid = 0;
            end
            if (!rx_publish_valid || !rx_publish_success)
                $fatal(1, "CQ publication missing at tail=%d", expected_tail);
            @(posedge clk); @(negedge clk);
            if (cq_tail !== ((expected_tail + 16'd1) & (cq_depth - 16'd1)))
                $fatal(1, "CQ tail wrap wrong depth=%d tail=%d", cq_depth, cq_tail);
        end
    endtask

    initial begin
        repeat (2) @(negedge clk); rst_n = 1;
        for (n = 0; n < 3; n = n + 1) publish_one(n);
        rx_req_valid = 1;
        #1; if (rx_req_ready) $fatal(1, "depth-4 CQ accepted fourth outstanding entry");
        rx_req_valid = 0;
        for (n = 3; n < 8; n = n + 1) begin
            cq_head = (n - 2) & (cq_depth - 1);
            publish_one(n);
        end
        if (cq_tail !== 0) $fatal(1, "depth-4 CQ failed second wrap");
        cq_head = 16'd4;
        rx_req_valid = 1;
        #1; if (rx_req_ready) $fatal(1, "out-of-range physical CQ head accepted");
        rx_req_valid = 0;

        @(negedge clk); rst_n = 0;
        cq_head = 0;
        cq_depth = 16'd512;
        repeat (2) @(negedge clk); rst_n = 1;
        for (n = 0; n < 511; n = n + 1) publish_one(n);
        rx_req_valid = 1;
        #1; if (rx_req_ready) $fatal(1, "depth-512 CQ accepted 512 outstanding entries");
        rx_req_valid = 0;
        cq_head = 1;
        publish_one(511);
        cq_head = 2;
        publish_one(512);
        if (cq_tail !== 1) $fatal(1, "depth-512 CQ failed slot-zero reuse");

        @(negedge clk); rst_n = 0;
        cq_head = 0;
        cq_depth = 16'd32768;
        repeat (2) @(negedge clk); rst_n = 1;
        // Seed the position to exercise the maximum depth without 32768 writes.
        @(negedge clk); dut.cq_tail = 16'd32767;
        cq_head = 16'd32766;
        publish_one(16'd32767);
        cq_head = 16'd32767;
        publish_one(16'd32768);
        if (cq_tail !== 16'd1) $fatal(1, "maximum-depth CQ tail wrong");
        $display("tb_shared_cq_configurable PASS");
        $finish;
    end
endmodule
