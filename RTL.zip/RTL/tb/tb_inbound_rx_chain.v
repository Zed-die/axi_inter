`timescale 1ns/1ps

module tb_inbound_rx_chain;
    reg clk = 0;
    always #5 clk = ~clk;
    reg rst_n = 0;
    reg enable = 0;
    wire prefetch_req_valid;
    wire [4:0] prefetch_sq_num;
    reg prefetch_req_ready = 0;
    reg [4:0] prefetch_accept_num = 0;
    reg [15:0] prefetch_fetch_ptr = 0;
    reg prefetch_sq_empty = 1;
    reg [255:0] prefetch_sq_dout = 0;
    reg [15:0] prefetch_sq_ptr = 0;
    wire prefetch_sq_rd_en;
    wire [19:0] som_key;
    wire [19:0] lookup_key;
    wire som_candidate_valid;
    wire som_conflict;
    wire [2:0] som_slot;
    wire [255:0] som_sqe;
    wire som_bind;
    wire lookup_valid;
    wire [2:0] lookup_slot;
    wire [255:0] lookup_sqe;
    wire lookup_seq_valid;
    wire [1:0] lookup_next_seq;
    reg packet_commit_valid = 0;
    reg [2:0] packet_commit_slot = 0;
    reg [31:0] packet_commit_bytes = 0;
    reg [1:0] packet_commit_seq = 0;
    reg packet_commit_eom = 0;
    wire packet_commit_ready;
    reg s_awvalid = 0;
    wire s_awready;
    reg [7:0] s_awlen = 0;
    reg [2:0] s_awsize = 3'd6;
    reg [1:0] s_awburst = 2'b01;
    reg [7:0] s_scope = 8'h01;
    reg [7:0] s_seid = 8'h42;
    reg s_to = 0;
    reg [2:0] s_tag = 1;
    reg s_som = 1;
    reg s_eom = 0;
    reg [1:0] s_seq = 0;
    wire [63:0] s_aw_hdr_34dw = {16'h0000, 16'h1ab4, 4'd0, 4'd1,
                                  s_scope, s_seid, s_som, s_eom, s_seq, s_to, s_tag};
    reg s_wvalid = 0;
    wire s_wready;
    reg [511:0] s_wdata = 0;
    reg [63:0] s_wstrb = {64{1'b1}};
    reg s_wlast = 0;
    reg filter_enable = 0;
    reg [3:0] rule_enable = 0;
    reg [3:0] rule_drop = 0;
    reg [31:0] rule_value = 0;
    reg [31:0] rule_mask = 0;
    wire packet_valid;
    reg packet_ready = 0;
    reg packet_release = 0;
    wire [2:0] packet_slot;
    wire [1:0] packet_seq;
    wire packet_eom;
    wire packet_som;
    wire [255:0] packet_sqe;
    wire [10:0] packet_wbytes;
    wire [4:0] packet_beats;
    wire buf_free;
    wire buf_reserve;
    wire buf_write;
    wire [3:0] buf_wr_addr;
    wire [511:0] buf_wr_data;
    wire [63:0] buf_wr_strb;
    wire buf_finish;
    wire buf_finish_good;
    wire buf_packet_valid;
    wire buf_packet_ready;
    wire buf_packet_release;
    reg [3:0] buf_rd_addr = 0;
    wire [511:0] buf_rd_data;
    wire [63:0] buf_rd_strb;
    wire drop_done_valid;
    reg drop_done_ready = 0;
    wire drop_event_valid;
    wire [3:0] drop_event_reason;
    wire abort_event_valid;
    wire [2:0] abort_event_slot;
    integer bind_count = 0;
    integer beat_idx;

    inbound_sq_manager manager_i (
        .clk                       (clk),
        .rst_n                     (rst_n),
        .enable                    (enable),
        .sq_base_addr              (64'h4000),
        .sq_depth                  (16'd256),
        .prefetch_req_valid        (prefetch_req_valid),
        .prefetch_sq_num           (prefetch_sq_num),
        .prefetch_req_ready        (prefetch_req_ready),
        .prefetch_accept_num       (prefetch_accept_num),
        .prefetch_fetch_ptr        (prefetch_fetch_ptr),
        .prefetch_sq_empty         (prefetch_sq_empty),
        .prefetch_sq_dout          (prefetch_sq_dout),
        .prefetch_sq_ptr           (prefetch_sq_ptr),
        .prefetch_sq_error         (1'b0),
        .prefetch_sq_rd_en         (prefetch_sq_rd_en),
        .prefetch_fault            (1'b0),
        .som_key                   (som_key),
        .som_seq                   (s_seq),
        .som_bind                  (som_bind),
        .som_candidate_valid       (som_candidate_valid),
        .som_conflict              (som_conflict),
        .som_slot                  (som_slot),
        .som_sqe                   (som_sqe),
        .lookup_key                (lookup_key),
        .lookup_valid              (lookup_valid),
        .lookup_slot               (lookup_slot),
        .lookup_sqe                (lookup_sqe),
        .lookup_next_seq           (lookup_next_seq),
        .lookup_seq_valid          (lookup_seq_valid),
        .packet_commit_valid       (packet_commit_valid),
        .packet_commit_ready       (packet_commit_ready),
        .packet_commit_slot        (packet_commit_slot),
        .packet_commit_bytes       (packet_commit_bytes),
        .packet_commit_seq         (packet_commit_seq),
        .packet_commit_eom         (packet_commit_eom),
        .message_done_valid        (1'b0),
        .message_done_slot         (3'd0),
        .message_done_update       (256'd0),
        .message_done_status       (8'd0),
        .message_done_abort        (1'b0),
        .m_axi_awready             (1'b0),
        .m_axi_wready              (1'b0),
        .m_axi_bvalid              (1'b0),
        .m_axi_bresp               (2'd0),
        .m_axi_bid                 (4'd0),
        .cq_req_ready              (1'b0),
        .cq_publish_valid          (1'b0),
        .cq_publish_success        (1'b0)
    );

    mctp_decoder decoder_i (
        .clk                  (clk),
        .rst_n                (rst_n),
        .s_axi_awvalid            (s_awvalid),
        .s_axi_awready            (s_awready),
        .s_axi_awmisc_info        ((64'h12 << 19) | 64'h7f),
        .s_axi_aw_hdr_34dw        (s_aw_hdr_34dw),
        .response_credit      (1'b1),
        .response_token       (5'd0),
        .s_axi_awlen              (s_awlen),
        .s_axi_awsize             (s_awsize),
        .s_axi_awburst            (s_awburst),
        .s_axi_wvalid             (s_wvalid),
        .s_axi_wready             (s_wready),
        .s_axi_wdata              (s_wdata),
        .s_axi_wstrb              (s_wstrb),
        .s_axi_wlast              (s_wlast),
        .filter_enable        (filter_enable),
        .rule_enable          (rule_enable),
        .rule_drop            (rule_drop),
        .rule_value           (rule_value),
        .rule_mask            (rule_mask),
        .default_drop         (1'b0),
        .som_key              (som_key),
        .som_candidate_valid  (som_candidate_valid),
        .som_conflict         (som_conflict),
        .som_slot             (som_slot),
        .som_sqe              (som_sqe),
        .som_bind             (som_bind),
        .lookup_key           (lookup_key),
        .lookup_valid         (lookup_valid),
        .lookup_slot          (lookup_slot),
        .lookup_sqe           (lookup_sqe),
        .lookup_seq_valid     (lookup_seq_valid),
        .lookup_next_seq      (lookup_next_seq),
        .lookup_timeout       (1'b0),
        .store_bounds_ok      (1'b1),
        .congestion_drop      (1'b0),
        .current_timeout      (1'b0),
        .packet_valid         (packet_valid),
        .packet_ready         (packet_ready),
        .packet_release       (packet_release),
        .packet_slot          (packet_slot),
        .packet_seq           (packet_seq),
        .packet_eom           (packet_eom),
        .packet_som           (packet_som),
        .packet_sqe           (packet_sqe),
        .packet_wbytes        (packet_wbytes),
        .packet_beats         (packet_beats),
        .buf_free             (buf_free),
        .buf_reserve          (buf_reserve),
        .buf_write            (buf_write),
        .buf_wr_addr          (buf_wr_addr),
        .buf_wr_data          (buf_wr_data),
        .buf_wr_strb          (buf_wr_strb),
        .buf_finish           (buf_finish),
        .buf_finish_good      (buf_finish_good),
        .buf_packet_valid     (buf_packet_valid),
        .buf_packet_ready     (buf_packet_ready),
        .buf_packet_release   (buf_packet_release),
        .drop_done_valid      (drop_done_valid),
        .drop_done_ready      (drop_done_ready),
        .drop_event_valid     (drop_event_valid),
        .drop_event_reason    (drop_event_reason),
        .abort_event_valid    (abort_event_valid),
        .abort_event_slot     (abort_event_slot)
    );

    inbound_packet_buffer buffer_i (
        .clk                  (clk),
        .rst_n                (rst_n),
        .free                 (buf_free),
        .reserve              (buf_reserve),
        .write_en             (buf_write),
        .write_addr           (buf_wr_addr),
        .write_data           (buf_wr_data),
        .write_strb           (buf_wr_strb),
        .finish               (buf_finish),
        .finish_good          (buf_finish_good),
        .packet_valid         (buf_packet_valid),
        .packet_ready         (buf_packet_ready),
        .packet_release       (buf_packet_release),
        .read_addr            (buf_rd_addr),
        .read_data            (buf_rd_data),
        .read_strb            (buf_rd_strb)
    );

    always @(posedge clk) if (som_bind) bind_count = bind_count + 1;

    function [255:0] rx_sqe;
        input [15:0] cid;
        input [63:0] payload_addr;
        begin
            rx_sqe = 0;
            rx_sqe[255:240] = cid;
            rx_sqe[191:128] = payload_addr;
            rx_sqe[95:90] = 6'd1;
        end
    endfunction

    task send_aw;
        input [127:0] meta;
        input som;
        input [7:0] seid;
        input [1:0] seq;
        input [7:0] len;
        integer timeout;
        begin
            @(negedge clk);
            s_som = som; s_seid = seid; s_seq = seq;
            s_awlen = len; s_awvalid = 1;
            timeout = 0;
            while (!s_awready && timeout < 30) begin
                @(negedge clk); timeout = timeout + 1;
            end
            if (!s_awready) $fatal(1, "AW stalled unexpectedly: meta=%h", meta);
            @(posedge clk);
            @(negedge clk); s_awvalid = 0;
        end
    endtask

    task send_w;
        input [31:0] value;
        input last;
        begin
            @(negedge clk); s_wdata = {16{value}}; s_wlast = last; s_wvalid = 1;
            #1; if (!s_wready) $fatal(1, "W stalled unexpectedly");
            @(posedge clk);
            @(negedge clk); s_wvalid = 0;
        end
    endtask

    task release_packet;
        begin
            packet_ready = 1;
            @(posedge clk);
            @(negedge clk); packet_ready = 0; packet_release = 1;
            @(posedge clk);
            @(negedge clk); packet_release = 0;
            #1; if (!buf_free || packet_valid) $fatal(1, "buffer did not release");
        end
    endtask

    task commit_packet;
        input [2:0] slot;
        input [31:0] bytes;
        input [1:0] seq;
        input eom;
        begin
            @(negedge clk); packet_commit_slot = slot; packet_commit_bytes = bytes;
            packet_commit_seq = seq; packet_commit_eom = eom;
            packet_commit_valid = 1;
            #1; if (!packet_commit_ready) $fatal(1, "manager rejected packet commit");
            @(posedge clk);
            @(negedge clk); packet_commit_valid = 0;
        end
    endtask

    task take_drop;
        input [3:0] reason;
        begin
            if (!drop_done_valid)
                $fatal(1, "drop completion missing for reason %d", reason);
            drop_done_ready = 1;
            @(posedge clk);
            @(negedge clk); drop_done_ready = 0;
        end
    endtask

    initial begin
        repeat (2) @(posedge clk);
        @(negedge clk); rst_n = 1; enable = 1;
        #1;
        if (!prefetch_req_valid || prefetch_sq_num !== 8) $fatal(1, "manager did not request 8 slots");
        prefetch_req_ready = 1; prefetch_accept_num = 2; prefetch_fetch_ptr = 0;
        @(posedge clk);
        @(negedge clk); prefetch_req_ready = 0;
        if (prefetch_sq_num !== 6) $fatal(1, "two SQEs not reserved");
        prefetch_sq_ptr = 0; prefetch_sq_dout = rx_sqe(16'h111, 64'hff0); prefetch_sq_empty = 0;
        @(posedge clk);
        @(negedge clk); prefetch_sq_empty = 1;
        prefetch_sq_ptr = 1; prefetch_sq_dout = rx_sqe(16'h222, 64'h2000); prefetch_sq_empty = 0;
        @(posedge clk);
        @(negedge clk); prefetch_sq_empty = 1;

        send_aw(128'ha1, 1, 8'h42, 0, 1);
        if (bind_count != 1 || !lookup_valid || lookup_slot !== 0 || lookup_seq_valid)
            $fatal(1, "first SOM not bound to slot 0");
        send_w(32'h11, 0); send_w(32'h22, 1);
        if (!packet_valid || packet_slot !== 0 ||
            packet_beats !== 2 || packet_wbytes !== 128 || !packet_som ||
            packet_sqe[191:128] !== 64'hff0)
            $fatal(1, "first packet not stored");
        buf_rd_addr = 0; #1; if (buf_rd_data[31:0] !== 32'h11) $fatal(1, "beat 0 corrupted");
        buf_rd_addr = 1; #1; if (buf_rd_data[31:0] !== 32'h22) $fatal(1, "beat 1 corrupted");

        filter_enable = 1; rule_enable = 1; rule_drop = 1;
        rule_value[7:0] = 8'h99; rule_mask[7:0] = 8'hff;
        send_aw(128'hd0, 1, 8'h99, 0, 0);
        if (!drop_event_valid || drop_event_reason !== 1) $fatal(1, "filter reject missing");
        send_w(32'hdead, 1); take_drop(1);
        if (!packet_valid || packet_slot !== 0 || buf_rd_data[31:0] !== 32'h22)
            $fatal(1, "DROP changed ready buffer");
        filter_enable = 0;
        release_packet();

        @(negedge clk); s_som = 0; s_seq = 1; s_seid = 8'h42; s_awvalid = 1;
        #1; if (s_awready) $fatal(1, "continuation accepted before first commit");
        s_awvalid = 0;
        commit_packet(0, 128, 0, 0);
        #1; if (!lookup_seq_valid || lookup_next_seq !== 1)
            $fatal(1, "first packet commit did not update message");

        s_eom = 1;
        send_aw(128'ha2, 0, 8'h42, 1, 0);
        send_w(32'h33, 1);
        if (!packet_valid || packet_slot !== 0 || packet_seq !== 1 || !packet_eom ||
            packet_som || packet_sqe[191:128] !== 64'hff0)
            $fatal(1, "continuation did not use slot 0");
        release_packet();
        commit_packet(0, 64, 1, 1);
        #1; if (lookup_valid || manager_i.slot_offset[0] !== 192)
            $fatal(1, "EOM did not finish message reassembly");

        s_tag = 2;
        send_aw(128'hb1, 1, 8'h43, 0, 15);
        if (bind_count != 2 || packet_slot !== 0 || lookup_slot !== 1)
            $fatal(1, "second SOM not bound independently");
        for (beat_idx = 0; beat_idx < 15; beat_idx = beat_idx + 1)
            send_w(32'h44, 0);
        send_w(32'h55, 1);
        buf_rd_addr = 15; #1;
        if (!packet_valid || packet_slot !== 1 || prefetch_sq_num !== 6 ||
            packet_beats !== 16 || packet_wbytes !== 1024 ||
            buf_rd_data[31:0] !== 32'h55 || packet_sqe[191:128] !== 64'h2000)
            $fatal(1, "second packet/context mismatch");

        send_aw(128'hb2, 1, 8'h43, 0, 0);
        if (!drop_event_valid || drop_event_reason !== 5 ||
            !abort_event_valid || abort_event_slot !== 1 || bind_count != 2)
            $fatal(1, "duplicate SOM did not identify bound slot 1");
        send_w(32'h66, 1); take_drop(5);
        if (!packet_valid || packet_slot !== 1)
            $fatal(1, "duplicate SOM disturbed stored packet");
        release_packet();

        s_tag = 3;
        send_aw(128'hc1, 1, 8'h44, 0, 0);
        if (!drop_event_valid || drop_event_reason !== 2 || bind_count != 2)
            $fatal(1, "no READY SQE did not drop new SOM");
        send_w(32'h77, 1); take_drop(2);
        $display("tb_inbound_rx_chain PASS");
        $finish;
    end
endmodule
