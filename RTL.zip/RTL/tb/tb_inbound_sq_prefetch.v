`timescale 1ns/1ps

module tb_inbound_sq_prefetch;
    reg clk = 0;
    always #5 clk = ~clk;
    reg rst_n = 0;
    reg [63:0] inbound_sq_base_addr = 0;
    reg [15:0] inbound_sq_depth = 16'd256;
    reg [15:0] inbound_tail_ptr = 0;
    reg prefetch_req_valid = 0;
    reg [4:0] prefetch_sq_num = 0;
    wire prefetch_req_ready;
    wire [4:0] prefetch_accept_num;
    wire [15:0] inbound_fetch_ptr;
    wire m_axi_arvalid;
    reg m_axi_arready = 1;
    wire [63:0] m_axi_araddr;
    wire [7:0] m_axi_arlen;
    wire [2:0] m_axi_arsize;
    wire [1:0] m_axi_arburst;
    reg m_axi_rvalid = 0;
    wire m_axi_rready;
    reg [511:0] m_axi_rdata = 0;
    reg [1:0] m_axi_rresp = 0;
    reg m_axi_rlast = 0;
    reg [3:0] m_axi_rid = 0;
    reg sq_rd_en = 0;
    wire [3:0] sq_count;
    wire sq_empty;
    wire [255:0] sq_dout;
    wire [15:0] sq_ptr;
    wire sq_error;
    wire fault;

    inbound_sq_prefetch dut (
        .clk                   (clk),
        .rst_n                 (rst_n),
        .inbound_sq_base_addr  (inbound_sq_base_addr),
        .inbound_sq_depth      (inbound_sq_depth),
        .inbound_tail_ptr      (inbound_tail_ptr),
        .prefetch_req_valid    (prefetch_req_valid),
        .prefetch_sq_num       (prefetch_sq_num),
        .prefetch_req_ready    (prefetch_req_ready),
        .prefetch_accept_num   (prefetch_accept_num),
        .inbound_fetch_ptr     (inbound_fetch_ptr),
        .m_axi_arvalid         (m_axi_arvalid),
        .m_axi_arready         (m_axi_arready),
        .m_axi_araddr          (m_axi_araddr),
        .m_axi_arlen           (m_axi_arlen),
        .m_axi_arsize          (m_axi_arsize),
        .m_axi_arburst         (m_axi_arburst),
        .m_axi_rvalid          (m_axi_rvalid),
        .m_axi_rready          (m_axi_rready),
        .m_axi_rdata           (m_axi_rdata),
        .m_axi_rresp           (m_axi_rresp),
        .m_axi_rlast           (m_axi_rlast),
        .m_axi_rid             (m_axi_rid),
        .sq_rd_en              (sq_rd_en),
        .sq_count              (sq_count),
        .sq_empty              (sq_empty),
        .sq_dout               (sq_dout),
        .sq_ptr                (sq_ptr),
        .sq_error              (sq_error),
        .fault                 (fault)
    );

    function [255:0] sqe;
        input [31:0] value;
        begin sqe = {224'd0, value}; end
    endfunction

    task reset_dut;
        begin
            @(negedge clk); rst_n = 0; prefetch_req_valid = 0;
            m_axi_rvalid = 0; sq_rd_en = 0;
            repeat (2) @(posedge clk);
            @(negedge clk); rst_n = 1;
        end
    endtask

    task request_sqs;
        input [15:0] tail;
        input [4:0] count;
        input [4:0] accepted;
        begin
            @(negedge clk);
            inbound_tail_ptr = tail;
            prefetch_sq_num = count;
            prefetch_req_valid = 1;
            #1;
            if (!prefetch_req_ready || prefetch_accept_num !== accepted)
                $fatal(1, "request ready/count mismatch: %b/%d expected %d",
                       prefetch_req_ready, prefetch_accept_num, accepted);
            @(posedge clk);
            @(negedge clk); prefetch_req_valid = 0;
        end
    endtask

    task expect_ar;
        input [63:0] addr;
        input [7:0] len;
        input [2:0] size;
        integer timeout;
        begin
            timeout = 0;
            while (!m_axi_arvalid && timeout < 20) begin
                @(negedge clk); timeout = timeout + 1;
            end
            if (!m_axi_arvalid || m_axi_araddr !== addr ||
                m_axi_arlen !== len || m_axi_arsize !== size ||
                m_axi_arburst !== 2'b01)
                $fatal(1, "AR mismatch addr=%h len=%d size=%d burst=%b expected %h/%d/%d/INCR",
                       m_axi_araddr, m_axi_arlen, m_axi_arsize,
                       m_axi_arburst, addr, len, size);
            @(posedge clk);
            @(negedge clk);
        end
    endtask

    task send_r;
        input [31:0] lower;
        input [31:0] upper;
        input last;
        input [1:0] resp;
        integer timeout;
        begin
            m_axi_rdata = {sqe(upper), sqe(lower)};
            m_axi_rresp = resp;
            m_axi_rlast = last;
            m_axi_rvalid = 1;
            timeout = 0;
            @(posedge clk);
            while (!m_axi_rready) begin
                @(posedge clk);
                timeout = timeout + 1;
                if (timeout > 20) $fatal(1, "RREADY timeout");
            end
            @(negedge clk); m_axi_rvalid = 0;
        end
    endtask

    task pop_sqe;
        input [15:0] ptr;
        input [31:0] value;
        input err;
        integer timeout;
        begin
            timeout = 0;
            while (sq_empty && timeout < 20) begin
                @(negedge clk); timeout = timeout + 1;
            end
            if (sq_empty || sq_ptr !== ptr || sq_dout[31:0] !== value ||
                sq_error !== err)
                $fatal(1, "SQ mismatch ptr=%d value=%h error=%b expected %d/%h/%b",
                       sq_ptr, sq_dout[31:0], sq_error, ptr, value, err);
            sq_rd_en = 1;
            @(posedge clk);
            @(negedge clk); sq_rd_en = 0;
        end
    endtask

    integer i;
    initial begin
        inbound_sq_base_addr = 64'h1000;
        reset_dut();
        request_sqs(16'd8, 5'd8, 5'd8);
        if (inbound_fetch_ptr !== 16'd8) $fatal(1, "fetch pointer not reserved");
        expect_ar(64'h1000, 8'd3, 3'd6);
        for (i = 0; i < 4; i = i + 1)
            send_r(2*i, 2*i+1, i == 3, 2'b00);
        repeat (3) @(negedge clk);
        if (sq_count !== 4'd8) $fatal(1, "eight SQEs not queued");
        for (i = 0; i < 8; i = i + 1) pop_sqe(i, i, 0);

        reset_dut();
        request_sqs(16'd1, 5'd1, 5'd1);
        expect_ar(64'h1000, 8'd0, 3'd5);
        send_r(0, 999, 1, 0);
        pop_sqe(0, 0, 0);
        request_sqs(16'd6, 5'd5, 5'd5);
        expect_ar(64'h1020, 8'd0, 3'd5);
        send_r(999, 1, 1, 0);
        expect_ar(64'h1040, 8'd1, 3'd6);
        send_r(2, 3, 0, 0);
        send_r(4, 5, 1, 0);
        for (i = 1; i < 6; i = i + 1) pop_sqe(i, i, 0);

        reset_dut();
        inbound_sq_base_addr = 64'h1fc0;
        request_sqs(16'd4, 5'd4, 5'd4);
        expect_ar(64'h1fc0, 8'd0, 3'd6);
        send_r(0, 1, 1, 0);
        expect_ar(64'h2000, 8'd0, 3'd6);
        send_r(2, 3, 1, 2'b10);
        pop_sqe(0, 0, 0);
        pop_sqe(1, 1, 0);
        pop_sqe(2, 2, 1);
        pop_sqe(3, 3, 1);

        reset_dut();
        inbound_sq_base_addr = 64'h3000;
        request_sqs(16'd3, 5'd8, 5'd3); // Tail, not requested count, limits reservation.
        m_axi_arready = 0;
        repeat (3) begin
            @(negedge clk);
            if (!m_axi_arvalid || m_axi_araddr !== 64'h3000 ||
                m_axi_arlen !== 0 || m_axi_arsize !== 3'd6)
                $fatal(1, "AR changed under backpressure");
        end
        m_axi_arready = 1;
        expect_ar(64'h3000, 8'd0, 3'd6);
        send_r(0, 1, 1, 0);
        expect_ar(64'h3040, 8'd0, 3'd5);
        send_r(2, 999, 1, 0);
        pop_sqe(0, 0, 0); pop_sqe(1, 1, 0); pop_sqe(2, 2, 0);

        reset_dut();
        inbound_sq_base_addr = 64'h4000;
        for (i = 0; i < 31; i = i + 1) begin
            request_sqs((i+1)*8, 5'd8, 5'd8);
            expect_ar(64'h4000+i*256, 8'd3, 3'd6);
            send_r(0, 0, 0, 0); send_r(0, 0, 0, 0);
            send_r(0, 0, 0, 0); send_r(0, 0, 1, 0);
            repeat (2) @(negedge clk);
            repeat (8) begin sq_rd_en = 1; @(posedge clk); @(negedge clk); end
            sq_rd_en = 0;
        end
        request_sqs(16'd254, 5'd6, 5'd6);
        expect_ar(64'h5f00, 8'd2, 3'd6);
        send_r(0, 0, 0, 0); send_r(0, 0, 0, 0); send_r(0, 0, 1, 0);
        repeat (2) @(negedge clk);
        repeat (6) begin sq_rd_en = 1; @(posedge clk); @(negedge clk); end
        sq_rd_en = 0;
        request_sqs(16'd2, 5'd4, 5'd4);
        expect_ar(64'h5fc0, 8'd0, 3'd6);
        send_r(254, 255, 1, 0);
        expect_ar(64'h4000, 8'd0, 3'd6);
        send_r(256, 257, 1, 0);
        pop_sqe(254, 254, 0); pop_sqe(255, 255, 0);
        pop_sqe(0, 256, 0); pop_sqe(1, 257, 0);

        reset_dut();
        inbound_sq_base_addr = 64'h4000;
        for (i = 0; i < 64; i = i + 1) begin
            request_sqs(((i+1)*8) & 255, 5'd8, 5'd8);
            expect_ar(64'h4000+((i*8) % 256)*32, 8'd3, 3'd6);
            send_r(0, 0, 0, 0); send_r(0, 0, 0, 0);
            send_r(0, 0, 0, 0); send_r(0, 0, 1, 0);
            repeat (2) @(negedge clk);
            repeat (8) begin sq_rd_en = 1; @(posedge clk); @(negedge clk); end
            sq_rd_en = 0;
        end
        if (inbound_fetch_ptr !== 16'd0) $fatal(1, "fetch index did not wrap at depth");
        request_sqs(16'd4, 5'd4, 5'd4);
        expect_ar(64'h4000, 8'd1, 3'd6);
        send_r(512, 513, 0, 0); send_r(514, 515, 1, 0);
        pop_sqe(0, 512, 0); pop_sqe(1, 513, 0);
        pop_sqe(2, 514, 0); pop_sqe(3, 515, 0);
        if (fault) $fatal(1, "unexpected protocol fault");

        reset_dut();
        inbound_sq_base_addr = 64'h1000;
        request_sqs(16'd4, 5'd4, 5'd4);
        expect_ar(64'h1000, 8'd1, 3'd6);
        send_r(0, 1, 1, 0); // RLAST one beat early is a protocol fault.
        pop_sqe(0, 0, 1); pop_sqe(1, 1, 1);
        if (!fault || prefetch_req_ready)
            $fatal(1, "malformed R did not halt prefetch");

        reset_dut();
        inbound_sq_depth = 16'd64;
        inbound_sq_base_addr = 64'h6000;
        for (i = 0; i < 7; i = i + 1) begin
            request_sqs((i+1)*8, 5'd8, 5'd8);
            expect_ar(64'h6000+i*256, 8'd3, 3'd6);
            send_r(0, 0, 0, 0); send_r(0, 0, 0, 0);
            send_r(0, 0, 0, 0); send_r(0, 0, 1, 0);
            repeat (2) @(negedge clk);
            repeat (8) begin sq_rd_en = 1; @(posedge clk); @(negedge clk); end
            sq_rd_en = 0;
        end
        request_sqs(16'd62, 5'd6, 5'd6);
        expect_ar(64'h6700, 8'd2, 3'd6);
        send_r(0, 0, 0, 0); send_r(0, 0, 0, 0); send_r(0, 0, 1, 0);
        repeat (2) @(negedge clk);
        repeat (6) begin sq_rd_en = 1; @(posedge clk); @(negedge clk); end
        sq_rd_en = 0;
        request_sqs(16'd2, 5'd4, 5'd4);
        expect_ar(64'h67c0, 8'd0, 3'd6);
        send_r(62, 63, 1, 0);
        expect_ar(64'h6000, 8'd0, 3'd6);
        send_r(64, 65, 1, 0);
        pop_sqe(62, 62, 0); pop_sqe(63, 63, 0);
        pop_sqe(0, 64, 0); pop_sqe(1, 65, 0);
        if (inbound_fetch_ptr !== 16'd2 || fault)
            $fatal(1, "64-entry SQ did not wrap correctly");

        reset_dut();
        inbound_sq_depth = 9'd2;
        inbound_sq_base_addr = 64'h7000;
        request_sqs(16'd1, 5'd8, 5'd1);
        expect_ar(64'h7000, 8'd0, 3'd5);
        send_r(0, 999, 1, 0);
        pop_sqe(0, 0, 0);
        request_sqs(16'd0, 5'd8, 5'd1);
        expect_ar(64'h7020, 8'd0, 3'd5);
        send_r(999, 1, 1, 0);
        pop_sqe(1, 1, 0);
        request_sqs(16'd1, 5'd8, 5'd1);
        expect_ar(64'h7000, 8'd0, 3'd5);
        send_r(2, 999, 1, 0);
        pop_sqe(0, 2, 0);
        if (inbound_fetch_ptr !== 16'd1 || fault)
            $fatal(1, "2-entry SQ index wrap failed");

        reset_dut();
        inbound_sq_depth = 16'd2;
        inbound_sq_base_addr = 64'h7000;
        request_sqs(16'd1, 5'd1, 5'd1);
        expect_ar(64'h7000, 8'd0, 3'd5);
        send_r(0, 999, 1, 0);
        pop_sqe(0, 0, 0);
        request_sqs(16'd0, 5'd1, 5'd1); // CPU tail wraps at depth, not 2*depth.
        expect_ar(64'h7020, 8'd0, 3'd5);
        send_r(999, 1, 1, 0);
        pop_sqe(1, 1, 0);
        if (inbound_fetch_ptr !== 16'd0 || fault)
            $fatal(1, "fetch pointer did not wrap at SQ depth");

        reset_dut();
        inbound_sq_depth = 16'd512;
        inbound_sq_base_addr = 64'h8000;
        for (i = 0; i < 32; i = i + 1) begin
            request_sqs((i+1)*8, 5'd8, 5'd8);
            expect_ar(64'h8000+i*256, 8'd3, 3'd6);
            send_r(0, 0, 0, 0); send_r(0, 0, 0, 0);
            send_r(0, 0, 0, 0); send_r(0, 0, 1, 0);
            repeat (2) @(negedge clk);
            repeat (8) begin sq_rd_en = 1; @(posedge clk); @(negedge clk); end
            sq_rd_en = 0;
        end
        request_sqs(16'd264, 5'd8, 5'd8);
        expect_ar(64'ha000, 8'd3, 3'd6);
        send_r(256, 257, 0, 0); send_r(258, 259, 0, 0);
        send_r(260, 261, 0, 0); send_r(262, 263, 1, 0);
        for (i = 256; i < 264; i = i + 1) pop_sqe(i, i, 0);
        if (inbound_fetch_ptr !== 16'd264 || fault)
            $fatal(1, "RX depth above 256 did not preserve SQ index");
        $display("tb_inbound_sq_prefetch PASS");
        $finish;
    end
endmodule
