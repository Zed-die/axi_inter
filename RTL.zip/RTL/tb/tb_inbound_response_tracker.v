`timescale 1ns/1ps
module tb_inbound_response_tracker;
    reg clk = 0;
    always #5 clk = ~clk;
    reg rst_n = 0;
    reg alloc_valid = 0;
    wire alloc_ready;
    wire [4:0] alloc_token;
    reg [3:0] alloc_id = 0;
    reg route_valid = 0;
    reg [4:0] route_token = 0;
    reg [1:0] route_resp = 0;
    reg drop_valid = 0;
    reg [4:0] drop_token = 0;
    wire bvalid;
    reg bready = 0;
    wire [3:0] bid;
    wire [1:0] bresp;
    reg [4:0] token_a;
    reg [4:0] token_b;
    inbound_response_tracker dut (
        .clk         (clk),
        .rst_n       (rst_n),
        .alloc_valid (alloc_valid),
        .alloc_ready (alloc_ready),
        .alloc_token (alloc_token),
        .alloc_id    (alloc_id),
        .route_valid (route_valid),
        .route_token (route_token),
        .route_resp  (route_resp),
        .drop_valid  (drop_valid),
        .drop_token  (drop_token),
        .s_bvalid    (bvalid),
        .s_bready    (bready),
        .s_bid       (bid),
        .s_bresp     (bresp)
    );
    task alloc;
        input [3:0] id;
        output [4:0] token;
        begin
            @(negedge clk); if (!alloc_ready) $fatal(1, "no response credit");
            alloc_id = id; token = alloc_token; alloc_valid = 1;
            @(posedge clk);
            @(negedge clk); alloc_valid = 0;
        end
    endtask
    initial begin
        repeat (2) @(posedge clk);
        @(negedge clk); rst_n = 1;
        alloc(3, token_a); alloc(3, token_b);
        @(negedge clk); route_valid = 1; route_token = token_b; route_resp = 0;
        @(posedge clk); @(negedge clk); route_valid = 0;
        if (bvalid) $fatal(1, "later B passed earlier incomplete transaction");
        drop_valid = 1; drop_token = token_a;
        @(posedge clk); @(negedge clk); drop_valid = 0;
        if (!bvalid || bid !== 3 || bresp !== 2'b10)
            $fatal(1, "first local error response wrong");
        bready = 1;
        @(posedge clk); @(negedge clk);
        if (!bvalid || bid !== 3 || bresp !== 0)
            $fatal(1, "second Fabric response wrong");
        @(posedge clk); @(negedge clk); bready = 0;
        if (bvalid) $fatal(1, "duplicate B returned");
        $display("tb_inbound_response_tracker PASS");
        $finish;
    end
endmodule
