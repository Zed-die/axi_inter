`timescale 1ns/1ps

module tb_axi_rd3t1_bridge;
    reg clk = 0;
    always #5 clk = ~clk;
    reg rst_n = 0;
    reg [2:0] s_arvalid = 0;
    wire [2:0] s_arready;
    reg [47:0] s_araddr = 0;
    reg [23:0] s_arlen = 0;
    reg [8:0] s_arsize = 0;
    reg [5:0] s_arburst = 0;
    reg [5:0] s_arid = 0;
    reg [2:0] s_arlock = 0;
    reg [11:0] s_arcache = 0;
    reg [8:0] s_arprot = 0;
    reg [11:0] s_arqos = 0;
    reg [11:0] s_arregion = 0;
    reg [2:0] s_rready = 3'b111;
    wire [2:0] s_rvalid;
    wire [95:0] s_rdata;
    wire [5:0] s_rresp;
    wire [2:0] s_rlast;
    wire [5:0] s_rid;
    wire m_arvalid;
    reg m_arready = 1;
    wire [15:0] m_araddr;
    wire [7:0] m_arlen;
    wire [2:0] m_arsize;
    wire [1:0] m_arburst;
    wire [1:0] m_arid;
    reg m_rvalid = 0;
    wire m_rready;
    reg [31:0] m_rdata = 0;
    reg [1:0] m_rresp = 0;
    reg m_rlast = 0;
    reg [1:0] m_rid = 0;

    axi_rd3t1_bridge #(
        .ADDR_WIDTH (16),
        .DATA_WIDTH (32),
        .ID_WIDTH   (2),
        .TAG_DEPTH  (2)
    ) dut (
        .clk        (clk),
        .rst_n      (rst_n),
        .s_arvalid  (s_arvalid),
        .s_arready  (s_arready),
        .s_araddr   (s_araddr),
        .s_arlen    (s_arlen),
        .s_arsize   (s_arsize),
        .s_arburst  (s_arburst),
        .s_arid     (s_arid),
        .s_arlock   (s_arlock),
        .s_arcache  (s_arcache),
        .s_arprot   (s_arprot),
        .s_arqos    (s_arqos),
        .s_arregion (s_arregion),
        .s_rvalid   (s_rvalid),
        .s_rready   (s_rready),
        .s_rdata    (s_rdata),
        .s_rresp    (s_rresp),
        .s_rlast    (s_rlast),
        .s_rid      (s_rid),
        .m_arvalid  (m_arvalid),
        .m_arready  (m_arready),
        .m_araddr   (m_araddr),
        .m_arlen    (m_arlen),
        .m_arsize   (m_arsize),
        .m_arburst  (m_arburst),
        .m_arid     (m_arid),
        .m_rvalid   (m_rvalid),
        .m_rready   (m_rready),
        .m_rdata    (m_rdata),
        .m_rresp    (m_rresp),
        .m_rlast    (m_rlast),
        .m_rid      (m_rid)
    );

    task check_ar;
        input expected_valid;
        input [2:0] expected_ready;
        input [15:0] expected_addr;
        begin
            #1;
            if (m_arvalid !== expected_valid || s_arready !== expected_ready ||
                (expected_valid && m_araddr !== expected_addr)) begin
                $display("AR mismatch: valid=%b ready=%b addr=%h expected=%b/%b/%h",
                         m_arvalid, s_arready, m_araddr,
                         expected_valid, expected_ready, expected_addr);
                $fatal(1);
            end
        end
    endtask

    task check_r;
        input [2:0] expected_valid;
        input expected_last;
        begin
            #1;
            if (s_rvalid !== expected_valid ||
                s_rlast[0] === 1'bx ||
                (expected_valid[0] && s_rlast[0] !== expected_last) ||
                (expected_valid[1] && s_rlast[1] !== expected_last) ||
                (expected_valid[2] && s_rlast[2] !== expected_last)) begin
                $display("R mismatch: valid=%b last=%b expected=%b/%b",
                         s_rvalid, s_rlast, expected_valid, expected_last);
                $fatal(1);
            end
        end
    endtask

    initial begin
        s_araddr[15:0] = 16'h1000;
        s_araddr[31:16] = 16'h2000;
        s_araddr[47:32] = 16'h3000;
        s_arlen[7:0] = 8'd1;
        s_arlen[15:8] = 8'd0;
        s_arlen[23:16] = 8'd0;
        repeat (2) @(posedge clk);
        @(negedge clk);
        rst_n = 1;
        s_arvalid = 3'b011;
        check_ar(1, 3'b001, 16'h1000);
        @(posedge clk); #1;
        @(negedge clk);
        s_arvalid = 3'b010;
        check_ar(1, 3'b010, 16'h2000);
        @(posedge clk); #1;
        @(negedge clk);
        s_arvalid = 3'b100;
        check_ar(0, 3'b000, 16'h0000); // Both tags in use.

        m_rvalid = 1;
        m_rdata = 32'h11111111;
        m_rlast = 0;
        s_rready[0] = 0;
        check_r(3'b001, 0);
        if (m_rready !== 1'b0) $fatal(1, "R backpressure was not forwarded");
        @(posedge clk); #1;
        @(negedge clk);
        s_rready[0] = 1;
        check_r(3'b001, 0); // Held R must still belong to source 0.
        @(posedge clk); #1;
        @(negedge clk);
        m_rdata = 32'h22222222;
        m_rlast = 1;
        check_r(3'b001, 1); // Same source for the whole burst.
        @(posedge clk); #1;
        @(negedge clk);
        m_rvalid = 0;
        check_ar(1, 3'b100, 16'h3000);
        @(posedge clk); #1;
        @(negedge clk);
        s_arvalid = 0;
        m_rvalid = 1;
        m_rlast = 1;
        check_r(3'b010, 1);
        @(posedge clk); #1;
        @(negedge clk);
        check_r(3'b100, 1);
        @(posedge clk); #1;
        @(negedge clk);
        m_rvalid = 0;

        // A stalled grant remains selected when a higher-priority request arrives.
        s_arvalid = 3'b100;
        m_arready = 0;
        check_ar(1, 3'b000, 16'h3000);
        @(posedge clk); #1;
        @(negedge clk);
        s_arvalid = 3'b110;
        if (m_araddr !== 16'h3000) $fatal(1, "AR grant changed under stall");
        m_arready = 1;
        check_ar(1, 3'b100, 16'h3000);
        @(posedge clk); #1;
        $display("PASS tb_axi_rd3t1_bridge");
        $finish;
    end
endmodule
