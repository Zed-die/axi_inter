`timescale 1ns/1ps
module tb_outbound_sq_manager;
    reg clk = 0;
    always #5 clk = ~clk;
    reg rst_n = 0, enable = 1;
    reg [3:0] sq_count = 0;
    reg sq_valid = 0, sq_error = 0;
    reg [255:0] sq_dout = 0;
    reg [15:0] sq_ptr = 0;
    wire sq_pop;
    reg prefetch_fault = 0;
    wire prefetch_req_valid;
    wire [4:0] prefetch_sq_num;
    wire gen_desc_valid;
    reg gen_desc_ready = 0;
    wire [255:0] gen_desc_sqe;
    reg gen_done_valid = 0;
    reg [7:0] gen_done_status = 0;
    wire gen_done_ready;
    wire gen_publish_valid, gen_publish_success;
    wire cq_req_valid;
    reg cq_req_ready = 0;
    wire [15:0] cq_req_cid, cq_req_sq_ptr, cq_req_candidate_rd;
    wire [7:0] cq_req_status;
    reg cq_publish_valid = 0, cq_publish_success = 0;
    wire [15:0] sq_rd_ptr;
    wire queue_fault, sqe_read_error_event, sqe_invalid_event;

    outbound_sq_manager dut (
        .clk                   (clk),
        .rst_n                 (rst_n),
        .enable                (enable),
        .sq_count              (sq_count),
        .sq_valid              (sq_valid),
        .sq_dout               (sq_dout),
        .sq_ptr                (sq_ptr),
        .sq_error              (sq_error),
        .sq_pop                (sq_pop),
        .prefetch_fault        (prefetch_fault),
        .prefetch_req_valid    (prefetch_req_valid),
        .prefetch_sq_num       (prefetch_sq_num),
        .gen_desc_valid        (gen_desc_valid),
        .gen_desc_ready        (gen_desc_ready),
        .gen_desc_sqe          (gen_desc_sqe),
        .gen_done_valid        (gen_done_valid),
        .gen_done_status       (gen_done_status),
        .gen_done_ready        (gen_done_ready),
        .gen_publish_valid     (gen_publish_valid),
        .gen_publish_success   (gen_publish_success),
        .cq_req_valid          (cq_req_valid),
        .cq_req_ready          (cq_req_ready),
        .cq_req_cid            (cq_req_cid),
        .cq_req_sq_ptr         (cq_req_sq_ptr),
        .cq_req_status         (cq_req_status),
        .cq_req_candidate_rd   (cq_req_candidate_rd),
        .cq_publish_valid      (cq_publish_valid),
        .cq_publish_success    (cq_publish_success),
        .sq_rd_ptr             (sq_rd_ptr),
        .queue_fault           (queue_fault),
        .sqe_read_error_event  (sqe_read_error_event),
        .sqe_invalid_event     (sqe_invalid_event)
    );

    initial begin
        repeat (2) @(negedge clk); rst_n = 1;
        #1; if (!prefetch_req_valid || prefetch_sq_num !== 8)
            $fatal(1, "prefetch did not request eight entries");
        sq_count = 1; sq_valid = 1; sq_ptr = 0;
        sq_dout[255:240] = 16'h1234;
        sq_dout[95:90] = 6'd0;
        #1; if (!gen_desc_valid || gen_desc_sqe !== sq_dout || sq_pop)
            $fatal(1, "FWFT head not offered");
        gen_desc_ready = 1;
        #1; if (!sq_pop) $fatal(1, "FWFT did not pop on transfer");
        @(posedge clk); @(negedge clk); gen_desc_ready = 0; sq_valid = 0; sq_count = 0;
        if (sq_rd_ptr !== 0) $fatal(1, "FIFO pop advanced software RD");
        gen_done_valid = 1; gen_done_status = 0;
        #1; if (!gen_done_ready) $fatal(1, "completion not accepted");
        @(posedge clk); @(negedge clk); gen_done_valid = 0;
        if (!cq_req_valid || cq_req_cid !== 16'h1234 ||
            cq_req_sq_ptr !== 0 || cq_req_candidate_rd !== 1 || cq_req_status !== 0)
            $fatal(1, "CQ request wrong");
        cq_req_ready = 1;
        @(posedge clk); @(negedge clk); cq_req_ready = 0;
        if (sq_rd_ptr !== 0) $fatal(1, "CQ reservation advanced software RD");
        cq_publish_valid = 1; cq_publish_success = 1;
        #1; if (!gen_publish_valid || !gen_publish_success)
            $fatal(1, "generator publish feedback missing");
        @(posedge clk); @(negedge clk); cq_publish_valid = 0;
        if (sq_rd_ptr !== 1) $fatal(1, "published CQ did not advance RD");

        sq_valid = 1; sq_count = 1; sq_ptr = 1;
        sq_dout[255:240] = 16'h5678; sq_dout[95:90] = 6'd2;
        #1; if (!sq_pop || gen_desc_valid) $fatal(1, "invalid opcode not consumed");
        @(posedge clk); @(negedge clk); sq_valid = 0;
        if (!cq_req_valid || cq_req_status !== 8'h50 || cq_req_cid !== 16'h5678)
            $fatal(1, "invalid opcode completion missing");
        cq_req_ready = 1;
        @(posedge clk); @(negedge clk); cq_req_ready = 0;
        cq_publish_valid = 1; cq_publish_success = 1;
        @(posedge clk); @(negedge clk); cq_publish_valid = 0;
        if (sq_rd_ptr !== 2) $fatal(1, "second CQ did not advance RD");

        sq_valid = 1; sq_error = 1; sq_count = 1; sq_ptr = 2;
        @(posedge clk); @(negedge clk); sq_valid = 0;
        if (!queue_fault || !sqe_read_error_event || cq_req_valid)
            $fatal(1, "SQE read failure did not halt without CQ");
        $display("tb_outbound_sq_manager PASS");
        $finish;
    end
endmodule
