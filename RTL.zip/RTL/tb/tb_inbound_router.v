`timescale 1ns/1ps

module tb_inbound_router;
    reg clk = 0;
    always #5 clk = ~clk;
    reg rst_n = 0;
    wire buffer_free;
    reg buffer_reserve = 0;
    reg buffer_write = 0;
    reg [3:0] buffer_write_addr = 0;
    reg [511:0] buffer_write_data = 0;
    reg [63:0] buffer_write_strb = 0;
    reg buffer_finish = 0;
    wire packet_valid;
    wire packet_ready;
    wire packet_release;
    reg [4:0] packet_token = 5'd7;
    reg [2:0] packet_slot = 0;
    reg packet_som = 0;
    reg packet_eom = 0;
    reg [1:0] packet_seq = 0;
    reg [10:0] packet_wbytes = 0;
    reg [4:0] packet_beats = 0;
    reg [255:0] packet_sqe = 0;
    wire [3:0] buf_rd_addr;
    wire [511:0] buf_rd_data;
    wire [63:0] buf_rd_strb;
    wire packet_commit_valid;
    wire [2:0] packet_commit_slot;
    wire [31:0] packet_commit_bytes;
    wire [1:0] packet_commit_seq;
    wire packet_commit_eom;
    wire result_valid;
    reg result_ready = 0;
    wire [4:0] result_token;
    wire [2:0] result_slot;
    wire result_error;
    wire [3:0] result_reason;
    wire [1:0] result_bresp;
    wire m_axi_awvalid;
    reg m_axi_awready = 0;
    wire [63:0] m_axi_awaddr;
    wire [7:0] m_axi_awlen;
    wire [2:0] m_axi_awsize;
    wire [1:0] m_axi_awburst;
    wire m_axi_wvalid;
    reg m_axi_wready = 0;
    wire [511:0] m_axi_wdata;
    wire [63:0] m_axi_wstrb;
    wire m_axi_wlast;
    reg m_axi_bvalid = 0;
    wire m_axi_bready;
    reg [1:0] m_axi_bresp = 0;
    reg [3:0] m_axi_bid = 0;
    integer commit_count = 0;
    reg [2:0] last_commit_slot = 0;
    reg [31:0] last_commit_bytes = 0;
    integer lane;
    integer beat;

    inbound_packet_buffer buffer_i (
        .clk                  (clk),
        .rst_n                (rst_n),
        .free                 (buffer_free),
        .reserve              (buffer_reserve),
        .write_en             (buffer_write),
        .write_addr           (buffer_write_addr),
        .write_data           (buffer_write_data),
        .write_strb           (buffer_write_strb),
        .finish               (buffer_finish),
        .finish_good          (1'b1),
        .packet_valid         (packet_valid),
        .packet_ready         (packet_ready),
        .packet_release       (packet_release),
        .read_addr            (buf_rd_addr),
        .read_data            (buf_rd_data),
        .read_strb            (buf_rd_strb)
    );

    inbound_router router_i (
        .clk                  (clk),
        .rst_n                (rst_n),
        .packet_valid         (packet_valid),
        .packet_ready         (packet_ready),
        .packet_release       (packet_release),
        .packet_token         (packet_token),
        .packet_slot          (packet_slot),
        .packet_som           (packet_som),
        .packet_eom           (packet_eom),
        .packet_seq           (packet_seq),
        .packet_wbytes        (packet_wbytes),
        .packet_beats         (packet_beats),
        .packet_sqe           (packet_sqe),
        .buf_rd_addr          (buf_rd_addr),
        .buf_rd_data          (buf_rd_data),
        .buf_rd_strb          (buf_rd_strb),
        .packet_commit_valid  (packet_commit_valid),
        .packet_commit_ready  (1'b1),
        .packet_commit_slot   (packet_commit_slot),
        .packet_commit_bytes  (packet_commit_bytes),
        .packet_commit_seq    (packet_commit_seq),
        .packet_commit_eom    (packet_commit_eom),
        .result_valid         (result_valid),
        .result_ready         (result_ready),
        .result_token         (result_token),
        .result_slot          (result_slot),
        .result_error         (result_error),
        .result_reason        (result_reason),
        .result_bresp         (result_bresp),
        .m_axi_awvalid        (m_axi_awvalid),
        .m_axi_awready        (m_axi_awready),
        .m_axi_awaddr         (m_axi_awaddr),
        .m_axi_awlen          (m_axi_awlen),
        .m_axi_awsize         (m_axi_awsize),
        .m_axi_awburst        (m_axi_awburst),
        .m_axi_wvalid         (m_axi_wvalid),
        .m_axi_wready         (m_axi_wready),
        .m_axi_wdata          (m_axi_wdata),
        .m_axi_wstrb          (m_axi_wstrb),
        .m_axi_wlast          (m_axi_wlast),
        .m_axi_bvalid         (m_axi_bvalid),
        .m_axi_bready         (m_axi_bready),
        .m_axi_bresp          (m_axi_bresp),
        .m_axi_bid            (m_axi_bid)
    );

    always @(posedge clk) if (packet_commit_valid) begin
        commit_count = commit_count + 1;
        last_commit_slot = packet_commit_slot;
        last_commit_bytes = packet_commit_bytes;
    end

    function [511:0] pattern_data;
        input [7:0] base;
        input integer source_beat;
        input integer source_offset;
        integer b;
        begin
            pattern_data = 0;
            for (b = 0; b < 64; b = b + 1)
                pattern_data[b*8 +: 8] = base + source_beat*64 + b - source_offset;
        end
    endfunction

    function [63:0] low_mask;
        input integer count;
        begin
            if (count >= 64) low_mask = {64{1'b1}};
            else low_mask = (64'h1 << count) - 64'h1;
        end
    endfunction

    task load_packet;
        input [127:0] meta;
        input [2:0] slot;
        input som;
        input eom;
        input [1:0] seq;
        input [63:0] sq_addr;
        input integer bytes;
        input [7:0] pattern;
        input integer source_offset;
        input malformed_strb;
        integer n;
        integer beats;
        integer b;
        begin
            beats = (source_offset + bytes + 63) / 64;
            @(negedge clk);
            if (!buffer_free) $fatal(1, "buffer not free before load");
            packet_slot = slot; packet_som = som;
            packet_eom = eom; packet_seq = seq;
            packet_wbytes = bytes; packet_beats = beats;
            packet_sqe = 0; packet_sqe[191:128] = sq_addr;
            buffer_reserve = 1;
            @(posedge clk);
            @(negedge clk); buffer_reserve = 0;
            for (n = 0; n < beats; n = n + 1) begin
                buffer_write = 1;
                buffer_write_addr = n;
                buffer_write_data = pattern_data(pattern, n, source_offset);
                buffer_write_strb = 0;
                for (b = 0; b < 64; b = b + 1)
                    if (n*64 + b >= source_offset && n*64 + b < source_offset + bytes)
                        buffer_write_strb[b] = 1;
                if (malformed_strb && n == beats - 1) buffer_write_strb[0] = 0;
                buffer_finish = (n == beats - 1);
                @(posedge clk);
                @(negedge clk);
            end
            buffer_write = 0; buffer_finish = 0;
        end
    endtask

    task expect_aw;
        input [63:0] addr;
        input [7:0] len;
        integer timeout;
        begin
            timeout = 0;
            while (!m_axi_awvalid && timeout < 40) begin
                @(negedge clk); timeout = timeout + 1;
            end
            #1;
            if (!m_axi_awvalid || m_axi_awaddr !== addr || m_axi_awlen !== len ||
                m_axi_awsize !== 3'd6 || m_axi_awburst !== 2'b01)
                $fatal(1, "AW mismatch addr=%h len=%d expected=%h/%d", m_axi_awaddr, m_axi_awlen, addr, len);
            m_axi_awready = 1;
            @(posedge clk);
            @(negedge clk); m_axi_awready = 0;
        end
    endtask

    task expect_w;
        input integer global_beat;
        input integer base_offset;
        input integer bytes;
        input [7:0] pattern;
        input last;
        integer timeout;
        integer logical_byte;
        reg expected_strobe;
        begin
            timeout = 0;
            while (!m_axi_wvalid && timeout < 30) begin
                @(negedge clk); timeout = timeout + 1;
            end
            #1;
            if (!m_axi_wvalid || m_axi_wlast !== last)
                $fatal(1, "WVALID/WLAST mismatch beat=%d", global_beat);
            for (lane = 0; lane < 64; lane = lane + 1) begin
                logical_byte = global_beat*64 + lane - base_offset;
                expected_strobe = logical_byte >= 0 && logical_byte < bytes;
                if (m_axi_wstrb[lane] !== expected_strobe)
                    $fatal(1, "WSTRB mismatch beat=%d lane=%d", global_beat, lane);
                if (expected_strobe && m_axi_wdata[lane*8 +: 8] !== (pattern + logical_byte) % 256)
                    $fatal(1, "WDATA mismatch beat=%d lane=%d value=%h", global_beat, lane, m_axi_wdata[lane*8 +: 8]);
            end
            repeat (2) @(posedge clk);
            @(negedge clk); m_axi_wready = 1;
            @(posedge clk);
            @(negedge clk); m_axi_wready = 0;
        end
    endtask

    task send_b;
        input [1:0] resp;
        begin
            @(negedge clk); m_axi_bvalid = 1; m_axi_bresp = resp;
            #1; if (!m_axi_bready) $fatal(1, "B not accepted");
            @(posedge clk);
            @(negedge clk); m_axi_bvalid = 0;
        end
    endtask

    task take_result;
        input [127:0] meta;
        input error;
        input [3:0] reason;
        integer timeout;
        begin
            timeout = 0;
            while (!result_valid && timeout < 30) begin
                @(negedge clk); timeout = timeout + 1;
            end
            #1;
            if (!result_valid || result_error !== error ||
                result_reason !== reason || result_token !== packet_token)
                $fatal(1, "result mismatch err=%b reason=%d", result_error, result_reason);
            repeat (2) begin
                @(posedge clk);
                if (!result_valid || buffer_free)
                    $fatal(1, "result or buffer changed under backpressure");
            end
            @(negedge clk);
            result_ready = 1;
            @(posedge clk);
            @(negedge clk); result_ready = 0;
            #1; if (!buffer_free) $fatal(1, "buffer not released after result");
        end
    endtask

    initial begin
        repeat (2) @(posedge clk);
        @(negedge clk); rst_n = 1;

        load_packet(128'ha1, 0, 1, 0, 0, 64'h0000_0000_0000_0ff0, 128, 8'h10, 0, 0);
        expect_aw(64'hfc0, 0);
        expect_w(0, 48, 128, 8'h10, 1);
        send_b(0);
        expect_aw(64'h1000, 1);
        expect_w(1, 48, 128, 8'h10, 0);
        expect_w(2, 48, 128, 8'h10, 1);
        send_b(0);
        take_result(128'ha1, 0, 0);
        if (commit_count !== 1 || last_commit_slot !== 0 || last_commit_bytes !== 128)
            $fatal(1, "first packet not committed once");

        load_packet(128'hb0, 1, 1, 1, 0, 64'h2000, 64, 8'h20, 0, 0);
        expect_aw(64'h2000, 0);
        expect_w(0, 0, 64, 8'h20, 1);
        send_b(0);
        take_result(128'hb0, 0, 0);
        if (commit_count !== 2 || last_commit_slot !== 1)
            $fatal(1, "interleaved slot 1 not committed");

        load_packet(128'ha2, 0, 0, 1, 1, 64'hdead, 32, 8'h80, 0, 0);
        expect_aw(64'h1040, 1); // Router uses 0x1070, not SQE's 0xdead.
        expect_w(0, 48, 32, 8'h80, 0);
        expect_w(1, 48, 32, 8'h80, 1);
        send_b(0);
        take_result(128'ha2, 0, 0);
        if (commit_count !== 3 || last_commit_slot !== 0 ||
            last_commit_bytes !== 32 || !packet_commit_eom)
            $fatal(1, "continuation address/commit wrong");

        load_packet(128'hd0, 5, 1, 1, 0, 64'hff0, 64, 8'h60, 32, 0);
        expect_aw(64'hfc0, 0);
        expect_w(0, 48, 64, 8'h60, 1); send_b(0);
        expect_aw(64'h1000, 0);
        expect_w(1, 48, 64, 8'h60, 1); send_b(0);
        take_result(128'hd0, 0, 0);
        if (commit_count !== 4 || last_commit_slot !== 5)
            $fatal(1, "high-lane source packet not committed");

        load_packet(128'he0, 6, 1, 1, 0, 64'h2004, 64, 8'ha0, 48, 0);
        expect_aw(64'h2000, 1);
        expect_w(0, 4, 64, 8'ha0, 0);
        expect_w(1, 4, 64, 8'ha0, 1); send_b(0);
        take_result(128'he0, 0, 0);
        if (commit_count !== 5 || last_commit_slot !== 6)
            $fatal(1, "right-shifted source packet not committed");

        load_packet(128'hb1, 1, 1, 0, 0, 64'h2000, 4, 8'h20, 0, 1);
        take_result(128'hb1, 1, 1);
        if (commit_count !== 5 || m_axi_awvalid) $fatal(1, "invalid strobe reached Fabric");

        load_packet(128'hc1, 2, 1, 0, 0, 64'h3000, 64, 8'h30, 0, 0);
        expect_aw(64'h3000, 0);
        expect_w(0, 0, 64, 8'h30, 1);
        send_b(2'b10);
        take_result(128'hc1, 1, 2);
        if (commit_count !== 5) $fatal(1, "failed Fabric B committed packet");

        load_packet(128'hd1, 3, 1, 1, 0, 64'h4004, 1024, 8'h40, 0, 0);
        expect_aw(64'h4000, 16);
        for (beat = 0; beat < 17; beat = beat + 1)
            expect_w(beat, 4, 1024, 8'h40, beat == 16);
        send_b(0);
        take_result(128'hd1, 0, 0);
        if (commit_count !== 6 || last_commit_bytes !== 1024)
            $fatal(1, "1 KiB unaligned packet not committed");
        $display("tb_inbound_router PASS");
        $finish;
    end
endmodule
