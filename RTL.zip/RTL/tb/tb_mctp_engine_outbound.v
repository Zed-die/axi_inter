`timescale 1ns/1ps
module tb_mctp_engine_outbound;
    reg clk = 0;
    always #5 clk = ~clk;
    reg rst_n = 0;
    wire [15:0] tx_sq_rd_ptr;
    wire [8:0] cq_tail;
    wire [7:0] irq_status;
    wire irq_level;
    wire m_arvalid;
    reg m_arready = 0;
    wire [63:0] m_araddr;
    wire [7:0] m_arlen;
    wire [2:0] m_arsize;
    reg m_rvalid = 0;
    wire m_rready;
    reg [511:0] m_rdata = 0;
    reg [1:0] m_rresp = 0;
    reg m_rlast = 0;
    wire m_awvalid;
    reg m_awready = 0;
    wire [63:0] m_awaddr;
    wire [2:0] m_awsize;
    wire m_wvalid;
    reg m_wready = 0;
    wire [511:0] m_wdata;
    wire [63:0] m_wstrb;
    wire m_wlast;
    reg m_bvalid = 0;
    wire m_bready;
    wire tx_awvalid;
    reg tx_awready = 0;
    wire [63:0] tx_awaddr;
    wire [7:0] tx_awlen;
    wire [255:0] tx_awmeta;
    wire [10:0] tx_packet_bytes;
    wire tx_som, tx_eom;
    wire [1:0] tx_seq, tx_pad_len;
    wire tx_wvalid;
    reg tx_wready = 0;
    wire [511:0] tx_wdata;
    wire [63:0] tx_wstrb;
    wire tx_wlast;
    reg tx_bvalid = 0;
    reg [1:0] tx_bresp = 0;
    reg inject_read_error = 0;
    wire tx_bready;
    reg [255:0] sqe;
    integer timeout, b, j, lane, beats;
    reg [63:0] beat_addr;

    inbound_engine_top #(
        .ENABLE_TX (1'b1)
    ) dut (
        .clk             (clk),
        .rst_n           (rst_n),
        .enable          (1'b0),
        .sq_base_addr    (64'h0000),
        .sq_tail_ptr     (16'd0),
        .tx_enable       (1'b1),
        .tx_sq_base_addr (64'h4000),
        .tx_sq_tail_ptr  (16'd1),
        .tx_sq_rd_ptr    (tx_sq_rd_ptr),
        .tx_tuz_bytes    (11'd128),
        .tx_target_addr  (64'h9000),
        .tx_start_seq    (2'd3),
        .cq_base_addr    (64'h8000),
        .cq_head         (9'd0),
        .cq_tail         (cq_tail),
        .irq_mask        (8'hff),
        .irq_clear       (8'd0),
        .message_timeout_cycles   (32'd0),
        .congestion_timeout_cycles(32'd0),
        .irq_status      (irq_status),
        .irq_level       (irq_level),
        .filter_enable   (1'b0),
        .default_drop    (1'b0),
        .store_bounds_ok (1'b1),
        .congestion_drop (1'b0),
        .lookup_timeout (1'b0),
        .current_timeout(1'b0),
        .s_awvalid       (1'b0),
        .s_wvalid        (1'b0),
        .s_bready        (1'b0),
        .tx_awvalid      (tx_awvalid),
        .tx_awready      (tx_awready),
        .tx_awaddr       (tx_awaddr),
        .tx_awlen        (tx_awlen),
        .tx_awmeta       (tx_awmeta),
        .tx_packet_bytes(tx_packet_bytes),
        .tx_som          (tx_som),
        .tx_eom          (tx_eom),
        .tx_seq          (tx_seq),
        .tx_pad_len      (tx_pad_len),
        .tx_wvalid       (tx_wvalid),
        .tx_wready       (tx_wready),
        .tx_wdata        (tx_wdata),
        .tx_wstrb        (tx_wstrb),
        .tx_wlast        (tx_wlast),
        .tx_bvalid       (tx_bvalid),
        .tx_bready       (tx_bready),
        .tx_bresp        (tx_bresp),
        .tx_bid          (4'd0),
        .m_axi_arvalid   (m_arvalid),
        .m_axi_arready   (m_arready),
        .m_axi_araddr    (m_araddr),
        .m_axi_arlen     (m_arlen),
        .m_axi_arsize    (m_arsize),
        .m_axi_rvalid    (m_rvalid),
        .m_axi_rready    (m_rready),
        .m_axi_rdata     (m_rdata),
        .m_axi_rresp     (m_rresp),
        .m_axi_rlast     (m_rlast),
        .m_axi_rid       (4'd0),
        .m_axi_awvalid   (m_awvalid),
        .m_axi_awready   (m_awready),
        .m_axi_awaddr    (m_awaddr),
        .m_axi_awsize    (m_awsize),
        .m_axi_wvalid    (m_wvalid),
        .m_axi_wready    (m_wready),
        .m_axi_wdata     (m_wdata),
        .m_axi_wstrb     (m_wstrb),
        .m_axi_wlast     (m_wlast),
        .m_axi_bvalid    (m_bvalid),
        .m_axi_bready    (m_bready),
        .m_axi_bresp     (2'b00),
        .m_axi_bid       (4'd0)
    );

    task service_read;
        input [63:0] expected_addr;
        input [2:0] expected_size;
        input [7:0] expected_len;
        input is_sqe;
        begin
            timeout = 0;
            while (!m_arvalid && timeout < 100) begin
                @(negedge clk); timeout = timeout + 1;
            end
            if (!m_arvalid || m_araddr !== expected_addr ||
                m_arsize !== expected_size || m_arlen !== expected_len)
                $fatal(1, "unexpected read AR addr=%h size=%d len=%d", m_araddr, m_arsize, m_arlen);
            beat_addr = m_araddr; beats = m_arlen + 1;
            m_arready = 1;
            @(posedge clk); @(negedge clk); m_arready = 0;
            for (b = 0; b < beats; b = b + 1) begin
                m_rdata = 0;
                m_rresp = (!is_sqe && inject_read_error) ? 2'b10 : 2'b00;
                if (is_sqe) m_rdata[255:0] = sqe;
                else for (j = 0; j < (1 << expected_size); j = j + 1) begin
                    lane = (beat_addr[5:0] + j) & 63;
                    m_rdata[lane*8 +: 8] = (beat_addr + j) & 8'hff;
                end
                m_rlast = b == beats - 1;
                m_rvalid = 1;
                #1; if (!m_rready) $fatal(1, "memory R was not accepted");
                @(posedge clk); @(negedge clk); m_rvalid = 0;
                beat_addr = beat_addr + (1 << expected_size);
            end
            m_rlast = 0; m_rresp = 0;
        end
    endtask

    task send_packet;
        input som;
        input eom;
        input [1:0] seq;
        input [10:0] bytes;
        input [1:0] pad;
        input [63:0] final_strb;
        integer k;
        reg [63:0] source_base;
        begin
            timeout = 0;
            while (!tx_awvalid && timeout < 100) begin
                @(negedge clk); timeout = timeout + 1;
            end
            if (!tx_awvalid || tx_awaddr !== 64'h9000 || tx_awlen !== 1 ||
                tx_som !== som || tx_eom !== eom || tx_seq !== seq ||
                tx_packet_bytes !== bytes || tx_pad_len !== pad ||
                tx_awmeta[7:4] !== {eom, som, seq})
                $fatal(1, "TX packet metadata mismatch");
            tx_awready = 1;
            @(posedge clk); @(negedge clk); tx_awready = 0;
            source_base = som ? 64'h1fc0 : 64'h2040;
            for (j = 0; j < 2; j = j + 1) begin
                if (!tx_wvalid || tx_wlast !== (j == 1) ||
                    tx_wstrb !== (j == 1 ? final_strb : 64'hffffffffffffffff))
                    $fatal(1, "TX W beat mismatch j=%d strb=%h", j, tx_wstrb);
                for (k = 0; k < 64; k = k + 1) begin
                    if (j*64+k < bytes) begin
                        if (tx_wdata[k*8 +: 8] !==
                            ((source_base + j*64+k) & 8'hff))
                            $fatal(1, "TX payload byte mismatch beat=%d byte=%d", j, k);
                    end else if (tx_wdata[k*8 +: 8] !== 8'd0)
                        $fatal(1, "TX padding byte not zero beat=%d byte=%d", j, k);
                end
                tx_wready = 1;
                @(posedge clk); @(negedge clk); tx_wready = 0;
            end
            if (tx_sq_rd_ptr !== 0 || !tx_bready)
                $fatal(1, "TX retired before Controller B");
            tx_bvalid = 1;
            @(posedge clk); @(negedge clk); tx_bvalid = 0;
        end
    endtask

    task cq_write;
        input [63:0] strb;
        input [7:0] expected_status;
        begin
            timeout = 0;
            while (!m_awvalid && timeout < 100) begin
                @(negedge clk); timeout = timeout + 1;
            end
            if (!m_awvalid || m_awaddr !== 64'h8000 || m_awsize !== 3'd4)
                $fatal(1, "CQ AW wrong");
            m_awready = 1;
            @(posedge clk); @(negedge clk); m_awready = 0;
            if (!m_wvalid || m_wstrb !== strb || !m_wlast)
                $fatal(1, "CQ W wrong strb=%h expected=%h", m_wstrb, strb);
            if (strb == 64'h7fff &&
                (m_wdata[119:112] !== expected_status ||
                 m_wdata[111:96] !== 16'h1234 ||
                 m_wdata[95:80] !== 16'd1 || m_wdata[79:64] !== 16'd1))
                $fatal(1, "TX CQE body wrong");
            m_wready = 1;
            @(posedge clk); @(negedge clk); m_wready = 0;
            if (!m_bready) $fatal(1, "CQ B not accepted");
            m_bvalid = 1;
            @(posedge clk); @(negedge clk); m_bvalid = 0;
        end
    endtask

    initial begin
        sqe = 0;
        sqe[255:240] = 16'h1234;
        sqe[219:200] = 20'd200; // 201 bytes, split into 128 + 73.
        sqe[191:128] = 64'h1fc0;
        sqe[95:90] = 6'd0;
        repeat (2) @(negedge clk); rst_n = 1;
        service_read(64'h4000, 3'd5, 8'd0, 1);
        service_read(64'h1fc0, 3'd6, 8'd0, 0);
        service_read(64'h2000, 3'd6, 8'd0, 0);
        send_packet(1, 0, 2'd3, 11'd128, 2'd0, 64'hffffffffffffffff);
        service_read(64'h2040, 3'd6, 8'd0, 0);
        service_read(64'h2080, 3'd2, 8'd1, 0);
        service_read(64'h2088, 3'd0, 8'd0, 0);
        send_packet(0, 1, 2'd0, 11'd73, 2'd3, 64'h0000000000000fff);
        if (tx_sq_rd_ptr !== 0) $fatal(1, "TX RD advanced before CQ");
        cq_write(64'h7fff, 8'h00);
        cq_write(64'h8000, 8'h00);
        @(negedge clk);
        if (tx_sq_rd_ptr !== 1 || cq_tail !== 1 || !irq_status[7] || !irq_level)
            $fatal(1, "TX completion not published rd=%d tail=%d irq=%h", tx_sq_rd_ptr, cq_tail, irq_status);
        rst_n = 0; tx_bresp = 2'b10;
        repeat (2) @(negedge clk); rst_n = 1;
        service_read(64'h4000, 3'd5, 8'd0, 1);
        service_read(64'h1fc0, 3'd6, 8'd0, 0);
        service_read(64'h2000, 3'd6, 8'd0, 0);
        send_packet(1, 0, 2'd3, 11'd128, 2'd0, 64'hffffffffffffffff);
        if (m_arvalid || tx_sq_rd_ptr !== 0)
            $fatal(1, "Controller B error did not stop later payload reads");
        cq_write(64'h7fff, 8'h62);
        cq_write(64'h8000, 8'h62);
        @(negedge clk);
        if (tx_sq_rd_ptr !== 1 || cq_tail !== 1 || !irq_status[6] || !irq_status[7])
            $fatal(1, "TX B error completion not published");
        rst_n = 0; tx_bresp = 0; inject_read_error = 1;
        repeat (2) @(negedge clk); rst_n = 1;
        service_read(64'h4000, 3'd5, 8'd0, 1);
        service_read(64'h1fc0, 3'd6, 8'd0, 0);
        inject_read_error = 0;
        if (m_arvalid || tx_awvalid)
            $fatal(1, "payload read error reached Controller");
        cq_write(64'h7fff, 8'h61);
        cq_write(64'h8000, 8'h61);
        @(negedge clk);
        if (tx_sq_rd_ptr !== 1 || cq_tail !== 1 || !irq_status[6])
            $fatal(1, "TX read error completion not published");
        $display("tb_mctp_engine_outbound PASS");
        $finish;
    end
endmodule
