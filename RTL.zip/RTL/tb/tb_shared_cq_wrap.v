`timescale 1ns/1ps
module tb_shared_cq_wrap;
    reg clk = 0;
    always #5 clk = ~clk;
    reg rst_n = 0;
    reg [15:0] cq_head = 0;
    wire [15:0] cq_tail;
    reg rx_req_valid = 0;
    wire rx_req_ready, rx_publish_valid, rx_publish_success;
    reg [15:0] rx_req_cid = 0;
    wire awvalid, wvalid, bready;
    reg awready = 0, wready = 0, bvalid = 0;
    wire [63:0] awaddr, wstrb;
    wire [511:0] wdata;
    integer n, part, lane, timeout;
    reg expected_phase;

    shared_cq_manager dut (
        .clk                 (clk),
        .rst_n               (rst_n),
        .cq_base_addr        (64'h8000),
        .cq_depth            (16'd256),
        .cq_head             (cq_head),
        .cq_tail             (cq_tail),
        .rx_req_valid        (rx_req_valid),
        .rx_req_ready        (rx_req_ready),
        .rx_req_cid          (rx_req_cid),
        .rx_req_status       (8'd0),
        .rx_req_candidate_rd (16'd0),
        .rx_publish_valid    (rx_publish_valid),
        .rx_publish_success  (rx_publish_success),
        .tx_req_valid        (1'b0),
        .m_axi_awvalid       (awvalid),
        .m_axi_awready       (awready),
        .m_axi_awaddr        (awaddr),
        .m_axi_wvalid        (wvalid),
        .m_axi_wready        (wready),
        .m_axi_wdata         (wdata),
        .m_axi_wstrb         (wstrb),
        .m_axi_bvalid        (bvalid),
        .m_axi_bready        (bready),
        .m_axi_bresp         (2'b00),
        .m_axi_bid           (4'd0)
    );

    task publish_one;
        input [15:0] cid;
        begin
            @(negedge clk);
            rx_req_cid = cid; rx_req_valid = 1;
            #1; if (!rx_req_ready) $fatal(1, "CQ refused entry %d", cid);
            expected_phase = ~cid[8];
            @(posedge clk); @(negedge clk); rx_req_valid = 0;
            for (part = 0; part < 2; part = part + 1) begin
                timeout = 0;
                while (!awvalid && timeout < 20) begin
                    @(negedge clk); timeout = timeout + 1;
                end
                if (!awvalid || awaddr !== 64'h8000 + ((cid & 255) << 4))
                    $fatal(1, "CQ AW wrong CID=%d addr=%h", cid, awaddr);
                lane = (cid & 3) << 4;
                awready = 1;
                @(posedge clk); @(negedge clk); awready = 0;
                if (!wvalid || wstrb !== ((part ? 64'h8000 : 64'h7fff) << lane) ||
                    wdata[lane*8+127] !== expected_phase ||
                    wdata[lane*8+96 +:16] !== cid)
                    $fatal(1, "CQ W wrong CID=%d part=%d", cid, part);
                wready = 1;
                @(posedge clk); @(negedge clk); wready = 0;
                if (!bready) $fatal(1, "CQ B not ready");
                bvalid = 1;
                @(posedge clk); @(negedge clk); bvalid = 0;
            end
            if (!rx_publish_valid || !rx_publish_success)
                $fatal(1, "CQ publication missing CID=%d", cid);
            @(posedge clk); @(negedge clk);
            if (cq_tail !== ((cid + 16'd1) & 16'h00ff))
                $fatal(1, "CQ tail wrong after CID=%d tail=%d", cid, cq_tail);
        end
    endtask

    initial begin
        repeat (2) @(negedge clk); rst_n = 1;
        for (n = 0; n < 255; n = n + 1) publish_one(n);
        rx_req_valid = 1;
        #1;
        if (cq_tail !== 255 || rx_req_ready) $fatal(1, "CQ did not stop at 255 entries");
        rx_req_valid = 0;
        cq_head = 1;
        publish_one(255);
        if (cq_tail !== 0) $fatal(1, "CQ tail did not wrap at depth 256");
        cq_head = 2;
        publish_one(256);
        if (cq_tail !== 1) $fatal(1, "CQ did not reuse slot zero");
        $display("tb_shared_cq_wrap PASS");
        $finish;
    end
endmodule
