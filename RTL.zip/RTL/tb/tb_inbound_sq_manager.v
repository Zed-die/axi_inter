`timescale 1ns/1ps

module tb_inbound_sq_manager;
    reg clk = 0;
    always #5 clk = ~clk;
    reg rst_n = 0;
    reg enable = 0;
    reg [63:0] sq_base_addr = 64'h4000;
    reg [8:0] sq_depth = 9'd256;
    wire prefetch_req_valid;
    wire [4:0] prefetch_sq_num;
    reg prefetch_req_ready = 0;
    reg [4:0] prefetch_accept_num = 0;
    reg [15:0] prefetch_fetch_ptr = 0;
    reg prefetch_sq_empty = 1;
    reg [255:0] prefetch_sq_dout = 0;
    reg [15:0] prefetch_sq_ptr = 0;
    reg prefetch_sq_error = 0;
    wire prefetch_sq_rd_en;
    reg prefetch_fault = 0;
    wire [15:0] sq_rd_ptr;
    wire [3:0] free_count;

    reg [19:0] som_key = 0;
    reg [1:0] som_seq = 0;
    reg som_bind = 0;
    wire som_candidate_valid;
    wire som_conflict;
    wire [2:0] som_slot;
    wire [255:0] som_sqe;
    wire [15:0] som_sq_ptr;
    reg [19:0] lookup_key = 0;
    wire lookup_valid;
    wire [2:0] lookup_slot;
    wire [255:0] lookup_sqe;
    wire [31:0] lookup_offset;
    wire [1:0] lookup_next_seq;
    wire lookup_seq_valid;

    reg packet_commit_valid = 0;
    wire packet_commit_ready;
    reg [2:0] packet_commit_slot = 0;
    reg [31:0] packet_commit_bytes = 0;
    reg [1:0] packet_commit_seq = 0;
    reg packet_commit_eom = 0;
    reg message_done_valid = 0;
    wire message_done_ready;
    reg [2:0] message_done_slot = 0;
    reg [255:0] message_done_update = 0;
    reg [7:0] message_done_status = 0;
    reg message_done_abort = 0;

    wire m_axi_awvalid;
    reg m_axi_awready = 1;
    wire [63:0] m_axi_awaddr;
    wire [7:0] m_axi_awlen;
    wire [2:0] m_axi_awsize;
    wire [1:0] m_axi_awburst;
    wire [3:0] m_axi_awid;
    wire m_axi_wvalid;
    reg m_axi_wready = 1;
    wire [511:0] m_axi_wdata;
    wire [63:0] m_axi_wstrb;
    wire m_axi_wlast;
    reg m_axi_bvalid = 0;
    wire m_axi_bready;
    reg [1:0] m_axi_bresp = 0;
    reg [3:0] m_axi_bid = 0;

    wire cq_req_valid;
    reg cq_req_ready = 0;
    wire [2:0] cq_req_slot;
    wire [15:0] cq_req_cid;
    wire [15:0] cq_req_sq_ptr;
    wire [7:0] cq_req_status;
    wire [15:0] cq_req_candidate_rd;
    reg cq_publish_valid = 0;
    reg cq_publish_success = 0;
    wire queue_fault;
    wire sqe_read_error_event;
    wire sqe_writeback_error_event;
    wire sqe_invalid_event;

    inbound_sq_manager dut (
        .clk                       (clk),
        .rst_n                     (rst_n),
        .enable                    (enable),
        .sq_base_addr              (sq_base_addr),
        .sq_depth                  (sq_depth),
        .prefetch_req_valid        (prefetch_req_valid),
        .prefetch_sq_num           (prefetch_sq_num),
        .prefetch_req_ready        (prefetch_req_ready),
        .prefetch_accept_num       (prefetch_accept_num),
        .prefetch_fetch_ptr        (prefetch_fetch_ptr),
        .prefetch_sq_empty         (prefetch_sq_empty),
        .prefetch_sq_dout          (prefetch_sq_dout),
        .prefetch_sq_ptr           (prefetch_sq_ptr),
        .prefetch_sq_error         (prefetch_sq_error),
        .prefetch_sq_rd_en         (prefetch_sq_rd_en),
        .prefetch_fault            (prefetch_fault),
        .sq_rd_ptr                 (sq_rd_ptr),
        .free_count                (free_count),
        .som_key                   (som_key),
        .som_seq                   (som_seq),
        .som_bind                  (som_bind),
        .som_candidate_valid       (som_candidate_valid),
        .som_conflict              (som_conflict),
        .som_slot                  (som_slot),
        .som_sqe                   (som_sqe),
        .som_sq_ptr                (som_sq_ptr),
        .lookup_key                (lookup_key),
        .lookup_valid              (lookup_valid),
        .lookup_slot               (lookup_slot),
        .lookup_sqe                (lookup_sqe),
        .lookup_offset             (lookup_offset),
        .lookup_next_seq           (lookup_next_seq),
        .lookup_seq_valid          (lookup_seq_valid),
        .packet_commit_valid       (packet_commit_valid),
        .packet_commit_ready       (packet_commit_ready),
        .packet_commit_slot        (packet_commit_slot),
        .packet_commit_bytes       (packet_commit_bytes),
        .packet_commit_seq         (packet_commit_seq),
        .packet_commit_eom         (packet_commit_eom),
        .message_done_valid        (message_done_valid),
        .message_done_ready        (message_done_ready),
        .message_done_slot         (message_done_slot),
        .message_done_update       (message_done_update),
        .message_done_status       (message_done_status),
        .message_done_abort        (message_done_abort),
        .m_axi_awvalid             (m_axi_awvalid),
        .m_axi_awready             (m_axi_awready),
        .m_axi_awaddr              (m_axi_awaddr),
        .m_axi_awlen               (m_axi_awlen),
        .m_axi_awsize              (m_axi_awsize),
        .m_axi_awburst             (m_axi_awburst),
        .m_axi_awid                (m_axi_awid),
        .m_axi_wvalid              (m_axi_wvalid),
        .m_axi_wready              (m_axi_wready),
        .m_axi_wdata               (m_axi_wdata),
        .m_axi_wstrb               (m_axi_wstrb),
        .m_axi_wlast               (m_axi_wlast),
        .m_axi_bvalid              (m_axi_bvalid),
        .m_axi_bready              (m_axi_bready),
        .m_axi_bresp               (m_axi_bresp),
        .m_axi_bid                 (m_axi_bid),
        .cq_req_valid              (cq_req_valid),
        .cq_req_ready              (cq_req_ready),
        .cq_req_slot               (cq_req_slot),
        .cq_req_cid                (cq_req_cid),
        .cq_req_sq_ptr             (cq_req_sq_ptr),
        .cq_req_status             (cq_req_status),
        .cq_req_candidate_rd       (cq_req_candidate_rd),
        .cq_publish_valid          (cq_publish_valid),
        .cq_publish_success        (cq_publish_success),
        .queue_fault               (queue_fault),
        .sqe_read_error_event      (sqe_read_error_event),
        .sqe_writeback_error_event (sqe_writeback_error_event),
        .sqe_invalid_event         (sqe_invalid_event)
    );

    function [255:0] rx_sqe;
        input [15:0] cid;
        input [63:0] payload_addr;
        begin
            rx_sqe = 0;
            rx_sqe[255:240] = cid;
            rx_sqe[191:128] = payload_addr;
            rx_sqe[95:90] = 6'd1;
        end
    endfunction

    task reserve;
        input [4:0] count;
        input [15:0] ptr;
        begin
            @(negedge clk);
            if (!prefetch_req_valid || prefetch_sq_num < count)
                $fatal(1, "manager did not request available slots");
            prefetch_req_ready = 1;
            prefetch_accept_num = count;
            prefetch_fetch_ptr = ptr;
            @(posedge clk);
            @(negedge clk); prefetch_req_ready = 0;
        end
    endtask

    task return_sqe;
        input [15:0] ptr;
        input [255:0] data;
        input error;
        begin
            @(negedge clk);
            prefetch_sq_ptr = ptr;
            prefetch_sq_dout = data;
            prefetch_sq_error = error;
            prefetch_sq_empty = 0;
            #1; if (!prefetch_sq_rd_en) $fatal(1, "manager did not consume SQE result");
            @(posedge clk);
            @(negedge clk); prefetch_sq_empty = 1;
        end
    endtask

    task bind;
        input [19:0] key;
        input [15:0] expected_ptr;
        input [2:0] expected_slot;
        begin
            @(negedge clk); som_key = key; som_seq = 0;
            #1;
            if (!som_candidate_valid || som_sq_ptr !== expected_ptr || som_slot !== expected_slot)
                $fatal(1, "SOM candidate mismatch ptr=%d slot=%d", som_sq_ptr, som_slot);
            som_bind = 1;
            @(posedge clk);
            @(negedge clk); som_bind = 0;
        end
    endtask

    task commit_packet;
        input [2:0] slot;
        input [31:0] bytes;
        input [1:0] seq;
        input eom;
        begin
            @(negedge clk);
            packet_commit_slot = slot; packet_commit_bytes = bytes;
            packet_commit_seq = seq; packet_commit_eom = eom;
            packet_commit_valid = 1;
            #1; if (!packet_commit_ready) $fatal(1, "packet commit refused");
            @(posedge clk);
            @(negedge clk); packet_commit_valid = 0;
        end
    endtask

    task finish_message;
        input [2:0] slot;
        input [19:0] length;
        input [7:0] status;
        begin
            @(negedge clk);
            message_done_slot = slot; message_done_update = 0;
            message_done_update[219:200] = length;
            message_done_update[255:240] = 16'hffff; // Must not overwrite CPU CID.
            message_done_status = status; message_done_abort = 0;
            message_done_valid = 1;
            #1; if (!message_done_ready) $fatal(1, "message done refused");
            @(posedge clk);
            @(negedge clk); message_done_valid = 0;
        end
    endtask

    task finish_writeback;
        input [63:0] addr;
        input [15:0] cid;
        input [19:0] length;
        input upper_lane;
        integer timeout;
        begin
            timeout = 0;
            while (!m_axi_awvalid && timeout < 20) begin @(negedge clk); timeout = timeout + 1; end
            if (!m_axi_awvalid || m_axi_awaddr !== addr || m_axi_awlen !== 0 ||
                m_axi_awsize !== 3'd5 || m_axi_awburst !== 2'b01)
                $fatal(1, "SQE writeback AW mismatch addr=%h", m_axi_awaddr);
            @(posedge clk);
            @(negedge clk);
            if (!m_axi_wvalid || !m_axi_wlast ||
                m_axi_wstrb !== (upper_lane ? {32'hffffffff,32'd0} : {32'd0,32'hffffffff}) ||
                m_axi_wdata[255:240] !== cid || m_axi_wdata[219:200] !== length)
                $fatal(1, "SQE writeback W mismatch");
            @(posedge clk);
            @(negedge clk);
            if (cq_req_valid) $fatal(1, "CQ request escaped before SQE writeback B");
            m_axi_bvalid = 1; m_axi_bresp = 0;
            #1; if (!m_axi_bready) $fatal(1, "SQE writeback B not accepted");
            @(posedge clk);
            @(negedge clk); m_axi_bvalid = 0;
        end
    endtask

    task publish_cq;
        input [2:0] slot;
        input [15:0] candidate;
        input [15:0] cid;
        integer timeout;
        begin
            timeout = 0;
            while (!cq_req_valid && timeout < 20) begin @(negedge clk); timeout = timeout + 1; end
            if (!cq_req_valid || cq_req_slot !== slot || cq_req_candidate_rd !== candidate ||
                cq_req_cid !== cid)
                $fatal(1, "CQ request mismatch slot=%d rd=%d", cq_req_slot, cq_req_candidate_rd);
            cq_req_ready = 1;
            @(posedge clk);
            @(negedge clk); cq_req_ready = 0;
            cq_publish_valid = 1; cq_publish_success = 1;
            @(posedge clk);
            @(negedge clk); cq_publish_valid = 0;
            if (sq_rd_ptr !== candidate) $fatal(1, "RD pointer mismatch: %d", sq_rd_ptr);
        end
    endtask

    initial begin
        repeat (2) @(posedge clk);
        @(negedge clk); rst_n = 1; enable = 1;
        reserve(3, 0);
        if (free_count !== 5) $fatal(1, "reservation did not occupy three slots");
        return_sqe(0, rx_sqe(16'h100, 64'h8000), 0);
        return_sqe(1, rx_sqe(16'h101, 64'h9000), 0);
        return_sqe(2, rx_sqe(16'h102, 64'ha000), 0);
        bind(20'h10001, 0, 0);
        bind(20'h20002, 1, 1);
        bind(20'h30003, 2, 2);
        lookup_key = 20'h20002;
        #1; if (!lookup_valid || lookup_slot !== 1 || lookup_offset !== 0)
            $fatal(1, "parallel message lookup failed");
        som_key = 20'h20002;
        #1; if (!som_conflict || som_candidate_valid) $fatal(1, "duplicate SOM not detected");

        commit_packet(0, 32'd64, 0, 0);
        lookup_key = 20'h10001;
        #1; if (!lookup_valid || lookup_offset !== 64 || !lookup_seq_valid || lookup_next_seq !== 1)
            $fatal(1, "independent A context not updated");
        commit_packet(1, 32'd80, 0, 1);
        finish_message(1, 20'd79, 8'h12);
        finish_writeback(64'h4020, 16'h101, 20'd79, 1);
        publish_cq(1, 0, 16'h101);
        if (free_count !== 5) $fatal(1, "out-of-order completion freed slot early");

        commit_packet(2, 32'd96, 0, 1);
        finish_message(2, 20'd95, 8'h13);
        finish_writeback(64'h4040, 16'h102, 20'd95, 0);
        publish_cq(2, 0, 16'h102);

        commit_packet(0, 32'd32, 1, 1);
        finish_message(0, 20'd95, 8'h11);
        finish_writeback(64'h4000, 16'h100, 20'd95, 0);
        publish_cq(0, 3, 16'h100);
        if (free_count !== 8 || queue_fault) $fatal(1, "slots not released after contiguous retirement");

        reserve(8, 3);
        if (free_count !== 0 || prefetch_req_valid)
            $fatal(1, "ninth RX SQE was requested");

        @(negedge clk); rst_n = 0; enable = 0;
        repeat (2) @(posedge clk);
        @(negedge clk); rst_n = 1; enable = 1;
        reserve(1, 0);
        return_sqe(0, 256'd0, 1);
        if (!queue_fault || !sqe_read_error_event || som_candidate_valid || prefetch_req_valid)
            $fatal(1, "SQE read error did not hold its entry and stop new work");

        @(negedge clk); rst_n = 0; enable = 0;
        repeat (2) @(posedge clk);
        @(negedge clk); rst_n = 1; enable = 1;
        reserve(1, 0);
        return_sqe(0, rx_sqe(16'h123, 64'h8000), 0);
        bind(20'h10001, 0, 0);
        commit_packet(0, 32'd64, 0, 1);
        finish_message(0, 20'd63, 0);
        wait (m_axi_awvalid);
        @(posedge clk);
        wait (m_axi_wvalid);
        @(posedge clk);
        @(negedge clk); m_axi_bvalid = 1; m_axi_bresp = 2'b10;
        @(posedge clk);
        @(negedge clk); m_axi_bvalid = 0;
        if (!queue_fault || !sqe_writeback_error_event || cq_req_valid)
            $fatal(1, "SQE writeback error was published as a normal completion");

        @(negedge clk); rst_n = 0; enable = 0; m_axi_bresp = 0;
        repeat (2) @(posedge clk);
        @(negedge clk); rst_n = 1; enable = 1; sq_depth = 9'd64;
        reserve(1, 64);
        return_sqe(64, rx_sqe(16'h6400, 64'h8000), 0);
        bind(20'h10001, 64, 0);
        commit_packet(0, 32'd64, 0, 1);
        finish_message(0, 20'd63, 0);
        finish_writeback(64'h4000, 16'h6400, 20'd63, 0);
        $display("tb_inbound_sq_manager PASS");
        $finish;
    end
endmodule
