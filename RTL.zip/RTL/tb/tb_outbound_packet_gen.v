`timescale 1ns/1ps
module tb_outbound_packet_gen;
    reg clk = 0;
    always #5 clk = ~clk;
    reg rst_n = 0;
    reg desc_valid = 0;
    wire desc_ready;
    reg [255:0] desc_sqe = 0;
    reg [63:0] target_addr = 64'h9000;
    wire reader_start_valid;
    reg reader_start_ready = 0;
    wire [63:0] reader_start_addr;
    wire [10:0] reader_start_len;
    reg reader_packet_valid = 0, reader_packet_error = 0;
    wire reader_release;
    wire [3:0] reader_index;
    wire tx_awvalid;
    reg tx_awready = 0;
    wire [63:0] tx_awaddr;
    wire [7:0] tx_awlen;
    wire [2:0] tx_awsize;
    wire [255:0] tx_awmeta;
    wire [10:0] tx_packet_bytes;
    wire tx_som, tx_eom;
    wire [1:0] tx_seq, tx_pad_len;
    wire tx_wvalid;
    reg tx_wready = 0;
    wire [511:0] tx_wdata;
    wire [63:0] tx_wstrb;
    wire tx_wlast;
    reg tx_bvalid = 0;
    reg [1:0] tx_bresp = 0;
    wire tx_bready;
    wire done_valid;
    wire [7:0] done_status;
    reg publish_valid = 0, publish_success = 0;
    integer cycles;

    outbound_packet_gen dut (
        .clk                 (clk),
        .rst_n               (rst_n),
        .desc_valid          (desc_valid),
        .desc_ready          (desc_ready),
        .desc_sqe            (desc_sqe),
        .tuz_bytes           (11'd64),
        .target_addr         (target_addr),
        .start_seq           (2'd3),
        .reader_start_valid  (reader_start_valid),
        .reader_start_ready  (reader_start_ready),
        .reader_start_addr   (reader_start_addr),
        .reader_start_len    (reader_start_len),
        .reader_packet_valid (reader_packet_valid),
        .reader_packet_error (reader_packet_error),
        .reader_release      (reader_release),
        .reader_index        (reader_index),
        .reader_data         ({16{32'h12345678}}),
        .tx_awvalid          (tx_awvalid),
        .tx_awready          (tx_awready),
        .tx_awaddr           (tx_awaddr),
        .tx_awlen            (tx_awlen),
        .tx_awsize           (tx_awsize),
        .tx_awmeta           (tx_awmeta),
        .tx_packet_bytes     (tx_packet_bytes),
        .tx_som              (tx_som),
        .tx_eom              (tx_eom),
        .tx_seq              (tx_seq),
        .tx_pad_len          (tx_pad_len),
        .tx_wvalid           (tx_wvalid),
        .tx_wready           (tx_wready),
        .tx_wdata            (tx_wdata),
        .tx_wstrb            (tx_wstrb),
        .tx_wlast            (tx_wlast),
        .tx_bvalid           (tx_bvalid),
        .tx_bready           (tx_bready),
        .tx_bresp            (tx_bresp),
        .tx_bid              (4'd0),
        .done_valid          (done_valid),
        .done_ready          (1'b1),
        .done_status         (done_status),
        .publish_valid       (publish_valid),
        .publish_success     (publish_success)
    );

    task wait_reader;
        input [63:0] addr;
        input [10:0] len;
        begin
            cycles = 0;
            while (!reader_start_valid && cycles < 40) begin
                @(negedge clk); cycles = cycles + 1;
            end
            if (!reader_start_valid || reader_start_addr !== addr ||
                reader_start_len !== len)
                $fatal(1, "reader request wrong addr=%h len=%d", reader_start_addr, reader_start_len);
            reader_start_ready = 1;
            @(posedge clk); @(negedge clk); reader_start_ready = 0;
            reader_packet_valid = 1;
            @(posedge clk); @(negedge clk); reader_packet_valid = 0;
        end
    endtask

    task send_packet;
        input som;
        input eom;
        input [1:0] seq;
        input [1:0] pad;
        input [10:0] bytes;
        input [63:0] strb;
        begin
            cycles = 0;
            while (!tx_awvalid && cycles < 40) begin
                @(negedge clk); cycles = cycles + 1;
            end
            if (!tx_awvalid || tx_awaddr !== 64'h9000 || tx_awlen !== 0 ||
                tx_awsize !== 6 || tx_som !== som || tx_eom !== eom ||
                tx_seq !== seq || tx_pad_len !== pad || tx_packet_bytes !== bytes ||
                tx_awmeta[7:4] !== {eom, som, seq})
                $fatal(1, "packet metadata wrong");
            repeat (2) @(negedge clk);
            if (!tx_awvalid || tx_seq !== seq) $fatal(1, "AW changed while stalled");
            tx_awready = 1;
            @(posedge clk); @(negedge clk); tx_awready = 0;
            if (!tx_wvalid || !tx_wlast || tx_wstrb !== strb ||
                tx_wdata[31:0] !== 32'h12345678)
                $fatal(1, "packet W wrong strb=%h expected=%h", tx_wstrb, strb);
            tx_wready = 1;
            @(posedge clk); @(negedge clk); tx_wready = 0;
            if (!tx_bready || reader_start_valid)
                $fatal(1, "next packet started before B");
            tx_bvalid = 1;
            @(posedge clk); @(negedge clk); tx_bvalid = 0;
        end
    endtask

    initial begin
        repeat (2) @(negedge clk); rst_n = 1;
        desc_sqe[219:200] = 20'd100; // 101 valid bytes.
        desc_sqe[191:128] = 64'h1004;
        desc_sqe[15:8] = 8'h42;
        desc_valid = 1;
        #1; if (!desc_ready) $fatal(1, "descriptor not accepted");
        @(posedge clk); @(negedge clk); desc_valid = 0;
        wait_reader(64'h1004, 11'd64);
        send_packet(1, 0, 2'd3, 0, 11'd64, 64'hffffffffffffffff);
        wait_reader(64'h1044, 11'd37);
        send_packet(0, 1, 2'd0, 2'd3, 11'd37, 64'h000000ffffffffff);
        if (!done_valid || done_status !== 0 || desc_ready)
            $fatal(1, "message completion wrong");
        @(posedge clk); @(negedge clk);
        if (desc_ready) $fatal(1, "next descriptor accepted before CQ");
        publish_valid = 1; publish_success = 1;
        @(posedge clk); @(negedge clk); publish_valid = 0;
        if (!desc_ready) $fatal(1, "CQ publish did not release context");
        target_addr = 64'h9004;
        desc_valid = 1;
        @(posedge clk); @(negedge clk); desc_valid = 0;
        if (!done_valid || done_status !== 8'h64 || reader_start_valid)
            $fatal(1, "misaligned TX target was not rejected before reading");
        @(posedge clk); @(negedge clk);
        publish_valid = 1; publish_success = 1;
        @(posedge clk); @(negedge clk); publish_valid = 0;
        target_addr = 64'h9000;
        desc_sqe[219:200] = 20'd63;
        desc_valid = 1;
        @(posedge clk); @(negedge clk); desc_valid = 0;
        wait_reader(64'h1004, 11'd64);
        tx_bresp = 2'b10;
        send_packet(1, 1, 2'd3, 0, 11'd64, 64'hffffffffffffffff);
        tx_bresp = 0;
        if (!done_valid || done_status !== 8'h62 || reader_start_valid)
            $fatal(1, "Controller B error did not stop message");
        @(posedge clk); @(negedge clk);
        publish_valid = 1; publish_success = 1;
        @(posedge clk); @(negedge clk); publish_valid = 0;
        desc_valid = 1;
        @(posedge clk); @(negedge clk); desc_valid = 0;
        reader_packet_error = 1;
        wait_reader(64'h1004, 11'd64);
        reader_packet_error = 0;
        if (!done_valid || done_status !== 8'h61 || tx_awvalid)
            $fatal(1, "payload read error reached Controller AW");
        @(posedge clk); @(negedge clk);
        publish_valid = 1; publish_success = 1;
        @(posedge clk); @(negedge clk); publish_valid = 0;
        desc_sqe[219:200] = 20'd127;
        desc_valid = 1;
        @(posedge clk); @(negedge clk); desc_valid = 0;
        wait_reader(64'h1004, 11'd64);
        send_packet(1, 0, 2'd3, 0, 11'd64, 64'hffffffffffffffff);
        wait_reader(64'h1044, 11'd64);
        send_packet(0, 1, 2'd0, 0, 11'd64, 64'hffffffffffffffff);
        if (!done_valid || done_status !== 0)
            $fatal(1, "exact TUZ multiple did not finish with full EOM packet");
        $display("tb_outbound_packet_gen PASS");
        $finish;
    end
endmodule
