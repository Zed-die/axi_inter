`timescale 1ns/1ps

module tb_mctp_decoder_rx;
    reg clk = 0;
    always #5 clk = ~clk;
    reg rst_n = 0;
    reg s_awvalid = 0;
    wire s_awready;
    reg [63:0] s_awmisc_info = (64'h12 << 19) | 64'h7f;
    reg [7:0] s_awlen = 0;
    reg [2:0] s_awsize = 3'd6;
    reg [1:0] s_awburst = 2'b01;
    reg [7:0] s_scope = 0;
    reg [7:0] s_seid = 0;
    reg s_to = 0;
    reg [2:0] s_tag = 0;
    reg s_som = 0;
    reg s_eom = 0;
    reg [1:0] s_seq = 0;
    wire [63:0] s_aw_hdr_34dw = {16'h0000, 16'h1ab4, 8'h01,
                                  s_scope, s_seid, s_som, s_eom, s_seq, s_to, s_tag};
    reg s_wvalid = 0;
    wire s_wready;
    reg [511:0] s_wdata = 0;
    reg [63:0] s_wstrb = 64'hffffffffffffffff;
    reg s_wlast = 0;
    reg filter_enable = 0;
    reg [3:0] rule_enable = 0;
    reg [3:0] rule_drop = 0;
    reg [31:0] rule_value = 0;
    reg [31:0] rule_mask = 0;
    reg default_drop = 0;
    wire [19:0] som_key;
    reg som_candidate_valid = 1;
    reg som_conflict = 0;
    reg [2:0] som_slot = 3;
    reg [255:0] som_sqe = 256'h8000 << 128;
    wire som_bind;
    wire [19:0] lookup_key;
    reg lookup_valid = 0;
    reg [2:0] lookup_slot = 2;
    reg [255:0] lookup_sqe = 256'h8000 << 128;
    reg lookup_seq_valid = 1;
    reg [1:0] lookup_next_seq = 1;
    reg lookup_timeout = 0;
    reg store_bounds_ok = 1;
    reg congestion_drop = 0;
    reg current_timeout = 0;
    wire packet_valid;
    reg packet_ready = 0;
    reg packet_release = 0;
    wire [4:0] packet_token;
    wire [2:0] packet_slot;
    wire [1:0] packet_seq;
    wire packet_eom;
    wire packet_som;
    wire [255:0] packet_sqe;
    wire [10:0] packet_wbytes;
    wire [4:0] packet_beats;
    wire buf_free;
    wire buf_reserve;
    wire buf_write;
    wire [3:0] buf_wr_addr;
    wire [511:0] buf_wr_data;
    wire [63:0] buf_wr_strb;
    wire buf_finish;
    wire buf_finish_good;
    wire buf_packet_valid;
    wire buf_packet_ready;
    wire buf_packet_release;
    reg [3:0] buf_rd_addr = 0;
    wire [511:0] buf_rd_data;
    wire [63:0] buf_rd_strb;
    wire drop_done_valid;
    reg drop_done_ready = 0;
    wire [4:0] drop_done_token;
    wire drop_done_slot_valid;
    wire [2:0] drop_done_slot;
    wire drop_event_valid;
    wire [3:0] drop_event_reason;
    wire abort_event_valid;
    wire [2:0] abort_event_slot;
    wire [3:0] abort_event_reason;
    integer buf_write_count = 0;
    integer bind_count = 0;

    mctp_decoder dut (
        .clk                  (clk),
        .rst_n                (rst_n),
        .s_axi_awvalid            (s_awvalid),
        .s_axi_awready            (s_awready),
        .s_axi_awmisc_info        (s_awmisc_info),
        .s_axi_aw_hdr_34dw        (s_aw_hdr_34dw),
        .response_credit      (1'b1),
        .response_token       (5'd3),
        .s_axi_awlen              (s_awlen),
        .s_axi_awsize             (s_awsize),
        .s_axi_awburst            (s_awburst),
        .s_axi_wvalid             (s_wvalid),
        .s_axi_wready             (s_wready),
        .s_axi_wdata              (s_wdata),
        .s_axi_wstrb              (s_wstrb),
        .s_axi_wlast              (s_wlast),
        .filter_enable        (filter_enable),
        .rule_enable          (rule_enable),
        .rule_drop            (rule_drop),
        .rule_value           (rule_value),
        .rule_mask            (rule_mask),
        .default_drop         (default_drop),
        .som_key              (som_key),
        .som_candidate_valid  (som_candidate_valid),
        .som_conflict         (som_conflict),
        .som_slot             (som_slot),
        .som_sqe              (som_sqe),
        .som_bind             (som_bind),
        .lookup_key           (lookup_key),
        .lookup_valid         (lookup_valid),
        .lookup_slot          (lookup_slot),
        .lookup_sqe           (lookup_sqe),
        .lookup_seq_valid     (lookup_seq_valid),
        .lookup_next_seq      (lookup_next_seq),
        .lookup_timeout       (lookup_timeout),
        .store_bounds_ok      (store_bounds_ok),
        .congestion_drop      (congestion_drop),
        .current_timeout      (current_timeout),
        .packet_valid         (packet_valid),
        .packet_ready         (packet_ready),
        .packet_release       (packet_release),
        .packet_token         (packet_token),
        .packet_slot          (packet_slot),
        .packet_seq           (packet_seq),
        .packet_eom           (packet_eom),
        .packet_som           (packet_som),
        .packet_sqe           (packet_sqe),
        .packet_wbytes        (packet_wbytes),
        .packet_beats         (packet_beats),
        .buf_free             (buf_free),
        .buf_reserve          (buf_reserve),
        .buf_write            (buf_write),
        .buf_wr_addr          (buf_wr_addr),
        .buf_wr_data          (buf_wr_data),
        .buf_wr_strb          (buf_wr_strb),
        .buf_finish           (buf_finish),
        .buf_finish_good      (buf_finish_good),
        .buf_packet_valid     (buf_packet_valid),
        .buf_packet_ready     (buf_packet_ready),
        .buf_packet_release   (buf_packet_release),
        .drop_done_valid      (drop_done_valid),
        .drop_done_ready      (drop_done_ready),
        .drop_done_token      (drop_done_token),
        .drop_done_slot_valid (drop_done_slot_valid),
        .drop_done_slot       (drop_done_slot),
        .drop_event_valid     (drop_event_valid),
        .drop_event_reason    (drop_event_reason),
        .abort_event_valid    (abort_event_valid),
        .abort_event_slot     (abort_event_slot),
        .abort_event_reason   (abort_event_reason)
    );

    inbound_packet_buffer buffer_i (
        .clk                  (clk),
        .rst_n                (rst_n),
        .free                 (buf_free),
        .reserve              (buf_reserve),
        .write_en             (buf_write),
        .write_addr           (buf_wr_addr),
        .write_data           (buf_wr_data),
        .write_strb           (buf_wr_strb),
        .finish               (buf_finish),
        .finish_good          (buf_finish_good),
        .packet_valid         (buf_packet_valid),
        .packet_ready         (buf_packet_ready),
        .packet_release       (buf_packet_release),
        .read_addr            (buf_rd_addr),
        .read_data            (buf_rd_data),
        .read_strb            (buf_rd_strb)
    );

    always @(posedge clk) begin
        if (som_bind) bind_count = bind_count + 1;
        if (buf_write) buf_write_count = buf_write_count + 1;
    end

    task send_aw;
        input [127:0] meta;
        input som;
        input [7:0] seid;
        input [7:0] len;
        integer t;
        begin
            @(negedge clk);
            s_som = som; s_seid = seid; s_awlen = len;
            s_awvalid = 1;
            t = 0;
            while (!s_awready && t < 30) begin @(negedge clk); t = t + 1; end
            if (!s_awready) $fatal(1, "AW did not become ready");
            @(posedge clk);
            @(negedge clk); s_awvalid = 0;
        end
    endtask

    task send_w;
        input [31:0] value;
        input last;
        begin
            @(negedge clk);
            s_wdata = {16{value}}; s_wlast = last; s_wvalid = 1;
            #1; if (!s_wready) $fatal(1, "W not accepted");
            @(posedge clk);
            @(negedge clk); s_wvalid = 0;
        end
    endtask

    task take_drop;
        input [127:0] meta;
        input [3:0] reason;
        begin
            if (!drop_done_valid || drop_done_token !== 5'd3)
                $fatal(1, "drop completion missing for reason %d", reason);
            drop_done_ready = 1;
            @(posedge clk);
            @(negedge clk); drop_done_ready = 0;
        end
    endtask

    initial begin
        repeat (2) @(posedge clk);
        @(negedge clk); rst_n = 1;
        s_scope = 8'h9c; s_seid = 8'h42; s_to = 1; s_tag = 3'd5; s_som = 1;
        #1;
        if (s_aw_hdr_34dw !== 64'h0000_1ab4_01_9c_42_8d ||
            som_key !== {8'h9c, 8'h42, 1'b1, 3'd5} ||
            lookup_key !== som_key)
            $fatal(1, "RX sideband byte order or message key mismatch");
        s_awmisc_info[7:0] = 8'd0;
        send_aw(128'h10, 1, 8'h42, 0);
        if (!drop_event_valid || drop_event_reason !== 4'd9 || buf_reserve)
            $fatal(1, "non-MCTP AW sideband was not rejected");
        send_w(32'h10, 1); take_drop(128'h10, 4'd9);
        s_awmisc_info[7:0] = 8'h7f;
        filter_enable = 1; rule_enable = 1; rule_drop = 1;
        rule_value[7:0] = 8'h42; rule_mask[7:0] = 8'hff;

        send_aw(128'h11, 1, 8'h42, 0);
        if (!drop_event_valid || drop_event_reason !== 4'd1 || bind_count != 0)
            $fatal(1, "filtered SOM was not dropped");
        send_w(32'h11, 1);
        take_drop(128'h11, 4'd1);
        if (buf_write_count != 0) $fatal(1, "DROP wrote packet buffer");

        filter_enable = 0; som_candidate_valid = 0;
        send_aw(128'h22, 1, 8'h50, 0);
        if (!drop_event_valid || drop_event_reason !== 4'd2) $fatal(1, "NO_ENTRY missing");
        send_w(32'h22, 1); take_drop(128'h22, 4'd2);

        send_aw(128'h33, 0, 8'h50, 0);
        if (!drop_event_valid || drop_event_reason !== 4'd3) $fatal(1, "ORPHAN missing");
        send_w(32'h33, 1); take_drop(128'h33, 4'd3);

        lookup_valid = 1; lookup_seq_valid = 1; lookup_next_seq = 1;
        s_seq = 2;
        send_aw(128'h44, 0, 8'h50, 0);
        if (!abort_event_valid || abort_event_slot !== 2 || abort_event_reason !== 4'd4)
            $fatal(1, "SEQ error did not abort bound message");
        send_w(32'h44, 1); take_drop(128'h44, 4'd4);

        s_seq = 0; som_candidate_valid = 1; som_conflict = 1;
        send_aw(128'h55, 1, 8'h50, 0);
        if (!drop_event_valid || drop_event_reason !== 4'd5 || !abort_event_valid)
            $fatal(1, "duplicate SOM not handled");
        send_w(32'h55, 1); take_drop(128'h55, 4'd5);

        som_conflict = 0; lookup_valid = 0;
        send_aw(128'h66, 1, 8'h50, 1);
        if (bind_count != 1) $fatal(1, "valid SOM did not bind entry");
        send_w(32'h66, 0);
        if (packet_valid) $fatal(1, "packet became ready before WLAST");
        send_w(32'h77, 1);
        if (!packet_valid || packet_slot !== 3 ||
            packet_token !== 5'd3 ||
            packet_wbytes !== 11'd128 || packet_beats !== 5'd2 ||
            !packet_som || packet_sqe[191:128] !== 64'h8000)
            $fatal(1, "stored packet metadata mismatch");
        buf_rd_addr = 0; #1; if (buf_rd_data[31:0] !== 32'h66) $fatal(1, "buffer beat 0 mismatch");
        buf_rd_addr = 1; #1; if (buf_rd_data[31:0] !== 32'h77) $fatal(1, "buffer beat 1 mismatch");

        filter_enable = 1; rule_value[7:0] = 8'h50;
        send_aw(128'h80, 1, 8'h50, 0);
        send_w(32'h80, 1); take_drop(128'h80, 4'd1);
        if (!packet_valid || packet_slot !== 3)
            $fatal(1, "DROP disturbed a stored packet");
        filter_enable = 0;

        @(negedge clk); s_awlen = 0; s_awvalid = 1;
        #1; if (s_awready) $fatal(1, "STORE AW accepted while buffer occupied");
        s_awvalid = 0;
        congestion_drop = 1;
        send_aw(128'h89, 1, 8'h50, 0);
        send_w(32'h89, 1); take_drop(128'h89, 4'd10);
        if (!packet_valid || packet_slot !== 3)
            $fatal(1, "congestion DROP disturbed stored packet");
        congestion_drop = 0;
        packet_ready = 1;
        @(posedge clk);
        @(negedge clk); packet_ready = 0; packet_release = 1;
        @(posedge clk);
        @(negedge clk); packet_release = 0;

        send_aw(128'h99, 1, 8'h50, 16); // 17 raw 512-bit beats exceed 1 KiB.
        repeat (16) send_w(32'h99, 0);
        send_w(32'h99, 1);
        take_drop(128'h99, 4'd7);

        send_aw(128'haa, 1, 8'h50, 1);
        send_w(32'haa, 1); // WLAST earlier than AWLEN requires buffer cancel.
        take_drop(128'haa, 4'd9);
        if (packet_valid) $fatal(1, "malformed packet exposed to router");

        send_aw(128'hbb, 1, 8'h50, 0);
        current_timeout = 1;
        send_w(32'hbb, 1); current_timeout = 0;
        take_drop(128'hbb, 4'd6);
        if (packet_valid) $fatal(1, "timed-out packet exposed to router");

        store_bounds_ok = 0;
        send_aw(128'hcc, 1, 8'h50, 0);
        send_w(32'hcc, 1);
        if (drop_done_slot_valid) $fatal(1, "rejected SOM claimed an unbound SQE");
        take_drop(128'hcc, 4'd8);
        store_bounds_ok = 1;

        send_aw(128'hdd, 1, 8'h50, 0);
        send_w(32'hdd, 0); send_w(32'hdd, 1);
        take_drop(128'hdd, 4'd9);
        if (packet_valid) $fatal(1, "late WLAST retained malformed buffer");

        send_aw(128'hde, 1, 8'h50, 0);
        @(negedge clk); current_timeout = 1;
        @(posedge clk);
        @(negedge clk); current_timeout = 0;
        send_w(32'hde, 1);
        if (packet_valid) $fatal(1, "timeout pulse during W stall was lost");
        take_drop(128'hde, 4'd6);

        lookup_valid = 1; lookup_seq_valid = 0; s_som = 0; s_seq = 1;
        @(negedge clk); s_awvalid = 1;
        #1; if (s_awready) $fatal(1, "continuation passed before prior commit");
        s_awvalid = 0; lookup_seq_valid = 1;
        store_bounds_ok = 0;
        send_aw(128'hef, 0, 8'h50, 0);
        if (!abort_event_valid || abort_event_slot !== 2)
            $fatal(1, "bound continuation bounds error did not abort slot");
        send_w(32'hef, 1); take_drop(128'hef, 4'd8);
        store_bounds_ok = 1;
        send_aw(128'hee, 0, 8'h50, 0);
        s_wstrb = 64'hff;
        send_w(32'hee, 1);
        buf_rd_addr = 0; #1;
        if (!packet_valid || packet_slot !== 2 || packet_wbytes !== 11'd8 ||
            buf_rd_strb !== 64'hff) $fatal(1, "continuation strobes: addr=%d bytes=%d strb=%h", buf_rd_addr, packet_wbytes, buf_rd_strb);
        $display("tb_mctp_decoder_rx PASS");
        $finish;
    end
endmodule
