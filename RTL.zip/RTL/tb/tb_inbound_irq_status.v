`timescale 1ns/1ps
module tb_inbound_irq_status;
    reg clk = 0;
    always #5 clk = ~clk;
    reg rst_n = 0;
    reg [7:0] event_set = 0;
    reg [7:0] clear = 0;
    reg [7:0] mask = 8'hff;
    wire [7:0] status;
    wire irq;
    inbound_irq_status dut (
        .clk       (clk),
        .rst_n     (rst_n),
        .event_set (event_set),
        .clear     (clear),
        .mask      (mask),
        .status    (status),
        .irq       (irq)
    );
    initial begin
        repeat (2) @(posedge clk);
        @(negedge clk); rst_n = 1; event_set = 8'h05;
        @(posedge clk); @(negedge clk); event_set = 0;
        if (status !== 8'h05 || !irq) $fatal(1, "error IRQ was not latched");
        mask = 0;
        #1; if (irq || status !== 8'h05) $fatal(1, "mask changed status");
        clear = 8'h01;
        @(posedge clk); @(negedge clk); clear = 0; mask = 8'hff;
        #1;
        if (status !== 8'h04 || !irq) $fatal(1, "W1C did not clear bit 0");
        clear = 8'h04; event_set = 8'h04;
        @(posedge clk); @(negedge clk); clear = 0; event_set = 0;
        if (status !== 8'h04 || !irq) $fatal(1, "new event did not win clear");
        $display("tb_inbound_irq_status PASS");
        $finish;
    end
endmodule
