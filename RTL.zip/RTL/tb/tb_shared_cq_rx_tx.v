`timescale 1ns/1ps
module tb_shared_cq_rx_tx;
    reg clk = 0;
    always #5 clk = ~clk;
    reg rst_n = 0;
    reg rx_req_valid = 0, tx_req_valid = 0;
    wire rx_req_ready, tx_req_ready;
    wire rx_publish_valid, tx_publish_valid;
    wire [8:0] cq_tail;
    wire awvalid, wvalid, bready;
    reg awready = 0, wready = 0, bvalid = 0;
    wire [63:0] awaddr, wstrb;
    wire [511:0] wdata;
    integer timeout;

    shared_cq_manager dut (
        .clk                 (clk),
        .rst_n               (rst_n),
        .cq_base_addr        (64'h8000),
        .cq_head             (9'd0),
        .cq_tail             (cq_tail),
        .rx_req_valid        (rx_req_valid),
        .rx_req_ready        (rx_req_ready),
        .rx_req_slot         (3'd0),
        .rx_req_cid          (16'haaaa),
        .rx_req_sq_ptr       (16'd0),
        .rx_req_status       (8'd0),
        .rx_req_candidate_rd (16'd1),
        .rx_publish_valid    (rx_publish_valid),
        .tx_req_valid        (tx_req_valid),
        .tx_req_ready        (tx_req_ready),
        .tx_req_cid          (16'hbbbb),
        .tx_req_sq_ptr       (16'd0),
        .tx_req_status       (8'd0),
        .tx_req_candidate_rd (16'd1),
        .tx_publish_valid    (tx_publish_valid),
        .m_axi_awvalid       (awvalid),
        .m_axi_awready       (awready),
        .m_axi_awaddr        (awaddr),
        .m_axi_wvalid        (wvalid),
        .m_axi_wready        (wready),
        .m_axi_wdata         (wdata),
        .m_axi_wstrb         (wstrb),
        .m_axi_bvalid        (bvalid),
        .m_axi_bready        (bready),
        .m_axi_bresp         (2'b00),
        .m_axi_bid           (4'd0)
    );

    task accept_write;
        input [63:0] addr;
        input [63:0] strb;
        input [15:0] cid;
        input [15:0] sqid;
        integer lane;
        begin
            timeout = 0;
            while (!awvalid && timeout < 80) begin
                @(negedge clk); timeout = timeout + 1;
            end
            if (!awvalid || awaddr !== addr) $fatal(1, "CQ AW address wrong");
            awready = 1;
            @(posedge clk); @(negedge clk); awready = 0;
            lane = addr[5:0];
            if (!wvalid || wstrb !== strb ||
                wdata[lane*8+96 +:16] !== cid ||
                wdata[lane*8+80 +:16] !== sqid)
                $fatal(1, "CQ body/phase data wrong");
            wready = 1;
            @(posedge clk); @(negedge clk); wready = 0;
            if (!bready) $fatal(1, "CQ B was not consumed");
            bvalid = 1;
            @(posedge clk); @(negedge clk); bvalid = 0;
        end
    endtask

    initial begin
        repeat (2) @(negedge clk); rst_n = 1;
        rx_req_valid = 1; tx_req_valid = 1;
        #1; if (!rx_req_ready || tx_req_ready)
            $fatal(1, "first arbitration should select RX");
        @(posedge clk); @(negedge clk); rx_req_valid = 0;
        accept_write(64'h8000, 64'h7fff, 16'haaaa, 16'd0);
        accept_write(64'h8000, 64'h8000, 16'haaaa, 16'd0);
        if (!rx_publish_valid || tx_publish_valid) $fatal(1, "RX publish route wrong");
        @(posedge clk); @(negedge clk);
        #1; if (cq_tail !== 1 || !tx_req_ready)
            $fatal(1, "TX did not receive next CQ slot");
        @(posedge clk); @(negedge clk); tx_req_valid = 0;
        accept_write(64'h8010, 64'h7fff0000, 16'hbbbb, 16'd1);
        accept_write(64'h8010, 64'h80000000, 16'hbbbb, 16'd1);
        if (!tx_publish_valid || rx_publish_valid) $fatal(1, "TX publish route wrong");
        @(posedge clk); @(negedge clk);
        if (cq_tail !== 2) $fatal(1, "shared CQ tail did not advance twice");
        $display("tb_shared_cq_rx_tx PASS");
        $finish;
    end
endmodule
