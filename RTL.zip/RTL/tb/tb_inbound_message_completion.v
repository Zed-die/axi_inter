`timescale 1ns/1ps
module tb_inbound_message_completion;
    reg clk = 0;
    always #5 clk = ~clk;
    reg rst_n = 0;
    reg store_valid = 0;
    reg [2:0] store_slot = 0;
    reg store_som = 0;
    reg route_valid = 0;
    reg [2:0] route_slot = 0;
    reg route_som = 0;
    reg route_eom = 0;
    reg [10:0] route_bytes = 0;
    reg route_error = 0;
    reg [3:0] route_reason = 0;
    reg abort_valid = 0;
    reg [2:0] abort_slot = 0;
    reg [3:0] abort_reason = 0;
    reg timeout_valid = 0;
    reg [2:0] timeout_slot = 0;
    reg drop_valid = 0;
    reg drop_slot_valid = 0;
    reg [2:0] drop_slot = 0;
    reg drop_was_store = 0;
    wire done_valid;
    reg done_ready = 0;
    wire [2:0] done_slot;
    wire [255:0] done_update;
    wire [7:0] done_status;
    wire done_abort;
    inbound_message_completion dut (
        .clk                 (clk),
        .rst_n               (rst_n),
        .store_valid         (store_valid),
        .store_slot          (store_slot),
        .store_som           (store_som),
        .route_valid         (route_valid),
        .route_slot          (route_slot),
        .route_som           (route_som),
        .route_eom           (route_eom),
        .route_bytes         (route_bytes),
        .route_error         (route_error),
        .route_reason        (route_reason),
        .abort_valid         (abort_valid),
        .abort_slot          (abort_slot),
        .abort_reason        (abort_reason),
        .timeout_valid       (timeout_valid),
        .timeout_slot        (timeout_slot),
        .drop_valid          (drop_valid),
        .drop_slot_valid     (drop_slot_valid),
        .drop_slot           (drop_slot),
        .drop_was_store      (drop_was_store),
        .message_done_valid  (done_valid),
        .message_done_ready  (done_ready),
        .message_done_slot   (done_slot),
        .message_done_update (done_update),
        .message_done_status (done_status),
        .message_done_abort  (done_abort)
    );
    task store;
        input [2:0] slot;
        input som;
        begin
            @(negedge clk); store_valid = 1; store_slot = slot; store_som = som;
            @(posedge clk); @(negedge clk); store_valid = 0;
        end
    endtask
    task route;
        input [2:0] slot;
        input som;
        input eom;
        input [10:0] bytes;
        begin
            @(negedge clk); route_valid = 1; route_slot = slot;
            route_som = som; route_eom = eom; route_bytes = bytes;
            @(posedge clk); @(negedge clk); route_valid = 0;
        end
    endtask
    initial begin
        repeat (2) @(posedge clk);
        @(negedge clk); rst_n = 1;
        store(0, 1); route(0, 1, 0, 64);
        if (done_valid) $fatal(1, "message completed before EOM");
        store(0, 0); route(0, 0, 1, 32);
        if (!done_valid || done_slot !== 0 || done_abort ||
            done_update[219:200] !== 95 || done_status !== 0)
            $fatal(1, "successful message completion wrong");
        done_ready = 1;
        @(posedge clk); @(negedge clk); done_ready = 0;
        store(1, 1);
        abort_valid = 1; abort_slot = 1; abort_reason = 4;
        @(posedge clk); @(negedge clk); abort_valid = 0;
        if (done_valid) $fatal(1, "abort completed before accepted W was drained");
        drop_valid = 1; drop_slot_valid = 1; drop_slot = 1; drop_was_store = 1;
        @(posedge clk); @(negedge clk); drop_valid = 0;
        if (!done_valid || done_slot !== 1 || !done_abort || done_status !== 8'h24)
            $fatal(1, "aborted message completion wrong");
        done_ready = 1;
        @(posedge clk); @(negedge clk); done_ready = 0;
        store(2, 1); route(2, 1, 0, 16);
        timeout_valid = 1; timeout_slot = 2;
        @(posedge clk); @(negedge clk); timeout_valid = 0;
        if (!done_valid || done_slot !== 2 || !done_abort ||
            done_status !== 8'h26 || done_update[219:200] !== 15)
            $fatal(1, "gap timeout completion wrong");
        $display("tb_inbound_message_completion PASS");
        $finish;
    end
endmodule
