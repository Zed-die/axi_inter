`timescale 1ns/1ps
module tb_shared_cq_manager;
    reg clk = 0;
    always #5 clk = ~clk;
    reg rst_n = 0;
    reg [8:0] cq_head = 0;
    wire [8:0] cq_tail;
    reg rx_req_valid = 0;
    wire rx_req_ready;
    reg [2:0] rx_req_slot = 0;
    reg [15:0] rx_req_cid = 16'h1234;
    reg [15:0] rx_req_sq_ptr = 0;
    reg [7:0] rx_req_status = 0;
    reg [15:0] rx_req_candidate_rd = 1;
    wire rx_publish_valid;
    wire rx_publish_success;
    wire completion_event;
    wire fault;
    wire awvalid;
    reg awready = 0;
    wire [63:0] awaddr;
    wire [2:0] awsize;
    wire wvalid;
    reg wready = 0;
    wire [511:0] wdata;
    wire [63:0] wstrb;
    reg bvalid = 0;
    wire bready;
    reg [1:0] bresp = 0;
    shared_cq_manager dut (
        .clk                  (clk),
        .rst_n                (rst_n),
        .cq_base_addr         (64'h8000),
        .cq_head              (cq_head),
        .cq_tail              (cq_tail),
        .rx_req_valid         (rx_req_valid),
        .rx_req_ready         (rx_req_ready),
        .rx_req_slot          (rx_req_slot),
        .rx_req_cid           (rx_req_cid),
        .rx_req_sq_ptr        (rx_req_sq_ptr),
        .rx_req_status        (rx_req_status),
        .rx_req_candidate_rd  (rx_req_candidate_rd),
        .rx_publish_valid     (rx_publish_valid),
        .rx_publish_success   (rx_publish_success),
        .tx_req_valid         (1'b0),
        .tx_req_cid           (16'd0),
        .tx_req_sq_ptr        (16'd0),
        .tx_req_status        (8'd0),
        .tx_req_candidate_rd  (16'd0),
        .completion_event     (completion_event),
        .fault                (fault),
        .m_axi_awvalid        (awvalid),
        .m_axi_awready        (awready),
        .m_axi_awaddr         (awaddr),
        .m_axi_awsize         (awsize),
        .m_axi_wvalid         (wvalid),
        .m_axi_wready         (wready),
        .m_axi_wdata          (wdata),
        .m_axi_wstrb          (wstrb),
        .m_axi_bvalid         (bvalid),
        .m_axi_bready         (bready),
        .m_axi_bresp          (bresp),
        .m_axi_bid            (4'd0)
    );
    task accept_aw;
        input [63:0] addr;
        begin
            wait (awvalid);
            #1; if (awaddr !== addr || awsize !== 3'd4) $fatal(1, "CQ AW wrong");
            awready = 1;
            @(posedge clk); @(negedge clk); awready = 0;
        end
    endtask
    task accept_w;
        input [63:0] strb;
        input integer lane_bytes;
        begin
            wait (wvalid);
            #1; if (wstrb !== strb ||
                wdata[lane_bytes*8+96 +: 16] !== 16'h1234 ||
                wdata[lane_bytes*8+64 +: 16] !== 16'd1)
                $fatal(1, "CQ W wrong strb=%h", wstrb);
            wready = 1;
            @(posedge clk); @(negedge clk); wready = 0;
        end
    endtask
    task send_b;
        input [1:0] resp;
        begin
            @(negedge clk); bresp = resp; bvalid = 1;
            #1; if (!bready) $fatal(1, "CQ B not accepted");
            @(posedge clk); @(negedge clk); bvalid = 0;
        end
    endtask
    initial begin
        repeat (2) @(posedge clk);
        @(negedge clk); rst_n = 1; rx_req_valid = 1;
        #1; if (!rx_req_ready) $fatal(1, "RX CQ request refused");
        @(posedge clk); @(negedge clk); rx_req_valid = 0;
        accept_aw(64'h8000); accept_w(64'h7fff, 0); send_b(0);
        accept_aw(64'h8000); accept_w(64'h8000, 0); send_b(0);
        #1; if (!rx_publish_valid || !rx_publish_success || !completion_event ||
                cq_tail !== 0) $fatal(1, "CQ publish event missing");
        @(posedge clk); @(negedge clk);
        if (cq_tail !== 1 || fault) $fatal(1, "CQ tail did not advance");
        rx_req_valid = 1; rx_req_cid = 16'h1234;
        #1; if (!rx_req_ready) $fatal(1, "second CQ request refused");
        @(posedge clk); @(negedge clk); rx_req_valid = 0;
        accept_aw(64'h8010); accept_w(64'h7fff0000, 16); send_b(2'b10);
        #1; if (!rx_publish_valid || rx_publish_success || cq_tail !== 1)
            $fatal(1, "failed CQ write published");
        @(posedge clk); @(negedge clk);
        if (!fault || cq_tail !== 1) $fatal(1, "CQ fault not held");
        $display("tb_shared_cq_manager PASS");
        $finish;
    end
endmodule
