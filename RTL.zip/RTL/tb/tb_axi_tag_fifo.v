`timescale 1ns/1ps

module tb_axi_tag_fifo;
    reg clk = 0;
    always #5 clk = ~clk;
    reg rst_n = 0;
    reg push_i = 0;
    reg [1:0] push_data_i = 0;
    reg pop_i = 0;
    wire [1:0] head_data_o;
    wire full_o;
    wire empty_o;

    axi_tag_fifo #(
        .WIDTH (2),
        .DEPTH (2)
    ) dut (
        .clk         (clk),
        .rst_n       (rst_n),
        .push_i      (push_i),
        .push_data_i (push_data_i),
        .pop_i       (pop_i),
        .head_data_o (head_data_o),
        .full_o      (full_o),
        .empty_o     (empty_o)
    );

    task cycle;
        input do_push;
        input [1:0] data;
        input do_pop;
        begin
            @(negedge clk);
            push_i = do_push;
            push_data_i = data;
            pop_i = do_pop;
            @(posedge clk);
            #1;
            @(negedge clk);
            push_i = 0;
            pop_i = 0;
        end
    endtask

    initial begin
        repeat (2) @(posedge clk);
        @(negedge clk);
        rst_n = 1;
        if (!empty_o) $fatal(1, "FIFO must start empty");
        cycle(1, 2'b00, 0);
        cycle(1, 2'b10, 0);
        if (!full_o || head_data_o !== 2'b00)
            $fatal(1, "FIFO full/head incorrect");
        cycle(0, 0, 1);
        if (head_data_o !== 2'b10 || full_o)
            $fatal(1, "FIFO did not pop first entry");
        cycle(1, 2'b01, 1);
        if (head_data_o !== 2'b01 || empty_o)
            $fatal(1, "FIFO simultaneous push/pop incorrect");
        cycle(0, 0, 1);
        if (!empty_o) $fatal(1, "FIFO did not drain");
        $display("PASS tb_axi_tag_fifo");
        $finish;
    end
endmodule
