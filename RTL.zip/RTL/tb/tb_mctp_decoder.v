`timescale 1ns/1ps

module tb_mctp_decoder;
    reg clk = 0;
    always #5 clk = ~clk;
    reg rst_n = 0;
    reg s_awvalid = 0;
    wire s_awready;
    reg s_wvalid = 0;
    wire s_wready;
    reg s_som = 0;
    reg [7:0] s_seid = 0;
    reg filter_enable = 0;
    reg [3:0] rule_enable = 0;
    reg [3:0] rule_drop = 0;
    reg [31:0] rule_value = 0;
    reg [31:0] rule_mask = 0;
    reg default_drop = 0;
    wire [63:0] s_aw_hdr_34dw = {16'h0000, 16'h1ab4, 8'h01,
                                  8'h00, s_seid, s_som, 1'b1, 2'd0, 1'b0, 3'd0};
    wire buf_reserve, buf_write, som_bind, drop_event_valid, drop_done_valid;
    wire [3:0] drop_event_reason;
    wire [4:0] drop_done_token;

    mctp_decoder dut (
        .clk                 (clk),
        .rst_n               (rst_n),
        .s_axi_awvalid           (s_awvalid),
        .s_axi_awready           (s_awready),
        .s_axi_awmisc_info       ((64'h12 << 19) | 64'h7f),
        .s_axi_aw_hdr_34dw       (s_aw_hdr_34dw),
        .response_credit     (1'b1),
        .response_token      (5'd7),
        .s_axi_awlen             (8'd0),
        .s_axi_awsize            (3'd6),
        .s_axi_awburst           (2'b01),
        .s_axi_wvalid            (s_wvalid),
        .s_axi_wready            (s_wready),
        .s_axi_wdata             (512'd0),
        .s_axi_wstrb             ({64{1'b1}}),
        .s_axi_wlast             (1'b1),
        .filter_enable       (filter_enable),
        .rule_enable         (rule_enable),
        .rule_drop           (rule_drop),
        .rule_value          (rule_value),
        .rule_mask           (rule_mask),
        .default_drop        (default_drop),
        .som_candidate_valid (1'b1),
        .som_conflict        (1'b0),
        .som_slot            (3'd0),
        .som_sqe             (256'd0),
        .lookup_valid        (1'b1),
        .lookup_slot         (3'd0),
        .lookup_sqe          (256'd0),
        .lookup_seq_valid    (1'b1),
        .lookup_next_seq     (2'd0),
        .lookup_timeout      (1'b0),
        .store_bounds_ok     (1'b1),
        .congestion_drop     (1'b0),
        .current_timeout     (1'b0),
        .buf_free            (1'b1),
        .buf_reserve         (buf_reserve),
        .buf_write           (buf_write),
        .buf_packet_valid    (1'b0),
        .packet_ready        (1'b1),
        .packet_release      (1'b1),
        .drop_done_valid     (drop_done_valid),
        .drop_done_ready     (1'b1),
        .drop_done_token     (drop_done_token),
        .drop_event_valid    (drop_event_valid),
        .drop_event_reason   (drop_event_reason),
        .som_bind            (som_bind)
    );

    task send_packet;
        input som;
        input [7:0] seid;
        input drop_expected;
        begin
            @(negedge clk);
            s_som = som;
            s_seid = seid;
            s_awvalid = 1'b1;
            #1;
            if (!s_awready || buf_reserve !== !drop_expected ||
                som_bind !== (som && !drop_expected))
                $fatal(1, "AW decision mismatch for SEID %h", seid);
            @(posedge clk);
            @(negedge clk);
            s_awvalid = 1'b0;
            if (drop_event_valid !== drop_expected ||
                (drop_expected && drop_event_reason !== 4'd1))
                $fatal(1, "filter drop event mismatch for SEID %h", seid);
            s_wvalid = 1'b1;
            #1;
            if (!s_wready || buf_write !== !drop_expected)
                $fatal(1, "W route mismatch for SEID %h", seid);
            @(posedge clk);
            @(negedge clk);
            s_wvalid = 1'b0;
            if (drop_done_valid !== drop_expected ||
                (drop_expected && drop_done_token !== 5'd7))
                $fatal(1, "drop completion mismatch for SEID %h", seid);
        end
    endtask

    initial begin
        #1;
        if (s_awready) $fatal(1, "AW accepted during reset");
        repeat (2) @(posedge clk);
        @(negedge clk);
        rst_n = 1;
        filter_enable = 1;
        rule_enable = 4'b0011;
        rule_drop = 4'b0001;
        rule_value = {16'd0, 8'h40, 8'h42};
        rule_mask = {16'd0, 8'hf0, 8'hff};
        send_packet(1, 8'h42, 1); // Both rules match; rule 0 rejects.
        send_packet(1, 8'h47, 0); // Rule 1 allows.
        send_packet(0, 8'h42, 0); // Continuations bypass EID filtering.
        default_drop = 1;
        send_packet(1, 8'h90, 1);
        filter_enable = 0;
        send_packet(1, 8'h42, 0);
        $display("tb_mctp_decoder PASS");
        $finish;
    end
endmodule
