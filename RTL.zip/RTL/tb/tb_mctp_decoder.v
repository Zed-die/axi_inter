`timescale 1ns/1ps

module tb_mctp_decoder;
    reg clk = 0;
    always #5 clk = ~clk;
    reg rst_n = 0;
    reg s_awvalid = 0;
    wire s_awready;
    reg [127:0] s_awmeta = 0;
    reg [7:0] s_awlen = 0;
    reg [2:0] s_awsize = 3'd6;
    reg [1:0] s_awburst = 2'b01;
    reg [7:0] s_scope = 0;
    reg s_to = 0;
    reg [2:0] s_tag = 0;
    reg s_eom = 1;
    reg [1:0] s_seq = 0;
    reg s_wvalid = 0;
    wire s_wready;
    reg [511:0] s_wdata = 0;
    reg [63:0] s_wstrb = {64{1'b1}};
    reg s_wlast = 1;
    reg s_som = 0;
    reg [7:0] s_seid = 0;
    reg filter_enable = 0;
    reg [3:0] rule_enable = 0;
    reg [3:0] rule_drop = 0;
    reg [31:0] rule_value = 0;
    reg [31:0] rule_mask = 0;
    reg default_drop = 0;
    wire m_decision_valid;
    reg m_decision_ready = 0;
    wire [127:0] m_awmeta;
    wire m_som;
    wire [7:0] m_seid;
    wire m_filter_drop;
    wire m_rule_hit;
    wire [1:0] m_rule_index;
    wire filter_reject_event;
    wire [7:0] filter_reject_seid;
    wire filter_reject_rule_hit;
    wire [1:0] filter_reject_rule_index;

    mctp_decoder dut (
        .clk                      (clk),
        .rst_n                    (rst_n),
        .s_awvalid                (s_awvalid),
        .s_awready                (s_awready),
        .s_awmeta                 (s_awmeta),
        .response_credit          (1'b1),
        .response_token           (5'd0),
        .s_awlen                  (s_awlen),
        .s_awsize                 (s_awsize),
        .s_awburst                (s_awburst),
        .s_scope                  (s_scope),
        .s_som                    (s_som),
        .s_seid                   (s_seid),
        .s_to                     (s_to),
        .s_tag                    (s_tag),
        .s_eom                    (s_eom),
        .s_seq                    (s_seq),
        .s_wvalid                 (s_wvalid),
        .s_wready                 (s_wready),
        .s_wdata                  (s_wdata),
        .s_wstrb                  (s_wstrb),
        .s_wlast                  (s_wlast),
        .filter_enable            (filter_enable),
        .rule_enable              (rule_enable),
        .rule_drop                (rule_drop),
        .rule_value               (rule_value),
        .rule_mask                (rule_mask),
        .default_drop             (default_drop),
        .som_candidate_valid      (1'b1),
        .som_conflict             (1'b0),
        .som_slot                 (3'd0),
        .som_sqe                  (256'd0),
        .lookup_valid             (1'b1),
        .lookup_slot              (3'd0),
        .lookup_sqe               (256'd0),
        .lookup_seq_valid         (1'b1),
        .lookup_next_seq          (2'd0),
        .lookup_timeout           (1'b0),
        .store_bounds_ok          (1'b1),
        .congestion_drop          (1'b0),
        .current_timeout          (1'b0),
        .buf_free                 (1'b1),
        .buf_packet_valid         (1'b0),
        .m_decision_valid         (m_decision_valid),
        .m_decision_ready         (m_decision_ready),
        .m_awmeta                 (m_awmeta),
        .m_som                    (m_som),
        .m_seid                   (m_seid),
        .m_filter_drop            (m_filter_drop),
        .m_rule_hit               (m_rule_hit),
        .m_rule_index             (m_rule_index),
        .filter_reject_event      (filter_reject_event),
        .filter_reject_seid       (filter_reject_seid),
        .filter_reject_rule_hit   (filter_reject_rule_hit),
        .filter_reject_rule_index (filter_reject_rule_index),
        .packet_ready             (1'b1),
        .packet_release           (1'b1),
        .drop_done_ready          (1'b1)
    );

    task send_aw;
        input [127:0] meta;
        input som;
        input [7:0] seid;
        input expected_drop;
        input expected_hit;
        input [1:0] expected_index;
        integer timeout;
        begin
            @(negedge clk);
            s_awmeta = meta; s_som = som; s_seid = seid; s_awvalid = 1;
            timeout = 0;
            while (!s_awready && timeout < 10) begin
                @(negedge clk); timeout = timeout + 1;
            end
            if (!s_awready) $fatal(1, "input AW ready timeout");
            @(posedge clk);
            @(negedge clk); s_awvalid = 0;
            if (filter_reject_event !== expected_drop)
                $fatal(1, "reject event mismatch for SEID %h", seid);
            if (expected_drop && (filter_reject_seid !== seid ||
                filter_reject_rule_hit !== expected_hit ||
                filter_reject_rule_index !== expected_index))
                $fatal(1, "reject event metadata mismatch");
            @(negedge clk); s_wvalid = 1;
            if (!s_wready) $fatal(1, "W not ready after accepted AW");
            @(posedge clk);
            @(negedge clk); s_wvalid = 0;
        end
    endtask

    task pop_decision;
        input [127:0] meta;
        input som;
        input [7:0] seid;
        input expected_drop;
        input expected_hit;
        input [1:0] expected_index;
        begin
            if (!m_decision_valid || m_awmeta !== meta || m_som !== som ||
                m_seid !== seid || m_filter_drop !== expected_drop ||
                m_rule_hit !== expected_hit || m_rule_index !== expected_index)
                $fatal(1, "decision mismatch: valid=%b meta=%h som=%b seid=%h drop=%b hit=%b idx=%d",
                       m_decision_valid, m_awmeta, m_som, m_seid,
                       m_filter_drop, m_rule_hit, m_rule_index);
            m_decision_ready = 1;
            @(posedge clk);
            @(negedge clk); m_decision_ready = 0;
        end
    endtask

    initial begin
        #1;
        if (s_awready || m_decision_valid || filter_reject_event)
            $fatal(1, "decoder accepted work during reset");
        repeat (2) @(posedge clk);
        @(negedge clk); rst_n = 1;
        filter_enable = 1;
        rule_enable = 4'b0011;
        rule_drop = 4'b0001;
        rule_value = {16'd0, 8'h40, 8'h42};
        rule_mask = {16'd0, 8'hf0, 8'hff};

        send_aw(128'h11, 1, 8'h42, 1, 1, 0); // Both match; rule 0 wins.
        repeat (3) begin
            @(negedge clk);
            if (!m_decision_valid || filter_reject_event)
                $fatal(1, "stalled decision changed or event repeated");
        end
        rule_enable = 0; // A captured decision must survive config changes.
        pop_decision(128'h11, 1, 8'h42, 1, 1, 0);

        rule_enable = 4'b0011;
        send_aw(128'h22, 1, 8'h47, 0, 1, 1);
        pop_decision(128'h22, 1, 8'h47, 0, 1, 1);
        send_aw(128'h33, 1, 8'h90, 0, 0, 0);
        pop_decision(128'h33, 1, 8'h90, 0, 0, 0);
        send_aw(128'h44, 0, 8'h42, 0, 0, 0); // Continuation bypasses EID filter.
        pop_decision(128'h44, 0, 8'h42, 0, 0, 0);

        default_drop = 1;
        send_aw(128'h55, 1, 8'h90, 1, 0, 0);
        pop_decision(128'h55, 1, 8'h90, 1, 0, 0);
        filter_enable = 0;
        send_aw(128'h66, 1, 8'h42, 0, 0, 0);
        pop_decision(128'h66, 1, 8'h42, 0, 0, 0);

        filter_enable = 1; default_drop = 0;
        send_aw(128'h77, 1, 8'h42, 1, 1, 0);
        @(negedge clk);
        s_awvalid = 1; s_awmeta = 128'h88; s_som = 1; s_seid = 8'h42;
        repeat (3) begin
            @(negedge clk);
            if (s_awready || filter_reject_event)
                $fatal(1, "input AW accepted or rejection repeated under backpressure");
        end
        s_awvalid = 0;
        pop_decision(128'h77, 1, 8'h42, 1, 1, 0);
        $display("tb_mctp_decoder PASS");
        $finish;
    end
endmodule
