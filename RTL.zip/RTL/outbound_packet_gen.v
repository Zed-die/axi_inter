`timescale 1ns/1ps

// One TX message and one packet at a time. This block owns packet boundaries,
// SOM/EOM, 2-bit sequence number, pad, and Controller AW/W/B completion.
module outbound_packet_gen #(
    parameter [3:0] AWCACHE_VALUE = 4'b0010,
    parameter [2:0] AWPROT_VALUE = 3'b010
) (
    input  wire         clk,
    input  wire         rst_n,
    input  wire         desc_valid,
    output wire         desc_ready,
    input  wire [255:0] desc_sqe,
    input  wire [10:0]  tuz_bytes,
    input  wire [63:0]  target_addr,
    input  wire [1:0]   start_seq,
    output wire         reader_start_valid,
    input  wire         reader_start_ready,
    output wire [63:0]  reader_start_addr,
    output wire [10:0]  reader_start_len,
    input  wire         reader_packet_valid,
    input  wire         reader_packet_error,
    output wire         reader_release,
    output wire [3:0]   reader_index,
    input  wire [511:0] reader_data,
    output wire         m_axi_awvalid,
    input  wire         m_axi_awready,
    output wire [63:0]  m_axi_awaddr,
    output wire [7:0]   m_axi_awlen,
    output wire [2:0]   m_axi_awsize,
    output wire [1:0]   m_axi_awburst,
    output wire [3:0]   m_axi_awid,
    output wire         m_axi_awlock,
    output wire [3:0]   m_axi_awcache,
    output wire [2:0]   m_axi_awprot,
    output wire [3:0]   m_axi_awqos,
    output wire [3:0]   m_axi_awregion,
    output reg  [63:0]  m_axi_awmisc_info_hdr_34dw,
    output wire [20:0]  m_axi_awmisc_info,
    output wire [9:0]   m_axi_awmisc_info_p_tag,
    output wire         m_axi_wvalid,
    input  wire         m_axi_wready,
    output reg  [511:0] m_axi_wdata,
    output reg  [63:0]  m_axi_wstrb,
    output wire         m_axi_wlast,
    input  wire         m_axi_bvalid,
    output wire         m_axi_bready,
    input  wire [1:0]   m_axi_bresp,
    input  wire [3:0]   m_axi_bid,
    output wire         done_valid,
    input  wire         done_ready,
    output reg  [7:0]   done_status,
    input  wire         publish_valid,
    input  wire         publish_success
);
    localparam [3:0] IDLE = 4'd0, PREP = 4'd1, START_READ = 4'd2,
                     WAIT_READ = 4'd3, AW = 4'd4, W = 4'd5,
                     B = 4'd6, DONE = 4'd7, WAIT_PUBLISH = 4'd8,
                     FAULT = 4'd9;
    reg [3:0] state;
    reg [255:0] sqe_q;
    reg [63:0] payload_base, target_q;
    reg [20:0] total_bytes, offset;
    reg [10:0] tuz_q, packet_bytes;
    reg [1:0] seq_q, packet_seq, pad_bytes;
    reg packet_som, packet_eom;
    reg [7:0] awlen_q;
    reg [4:0] beat_index;
    wire [20:0] remaining = total_bytes - offset;
    wire [10:0] planned_len = remaining > {10'd0, tuz_q} ? tuz_q : remaining[10:0];
    wire [1:0] planned_pad = 2'd0 - planned_len[1:0];
    wire [11:0] planned_wire = {1'b0, planned_len} + {10'd0, planned_pad};
    wire [5:0] planned_beats = (planned_wire + 12'd63) >> 6;
    wire [12:0] target_end = {1'b0, target_q[11:0]} +
                             {1'b0, planned_beats, 6'd0};
    wire [11:0] wire_bytes = {1'b0, packet_bytes} + {10'd0, pad_bytes};
    integer i;
    integer absolute_byte;

    assign desc_ready = rst_n && state == IDLE;
    assign reader_start_valid = state == START_READ;
    assign reader_start_addr = payload_base + offset;
    assign reader_start_len = packet_bytes;
    assign reader_release = (state == WAIT_READ && reader_packet_valid &&
                             reader_packet_error) || (state == B && m_axi_bvalid);
    assign reader_index = beat_index[3:0];
    assign m_axi_awvalid = state == AW;
    assign m_axi_awaddr = target_q;
    assign m_axi_awlen = awlen_q;
    assign m_axi_awsize = 3'd6;
    assign m_axi_awburst = 2'b01;
    assign m_axi_awid = 4'd0;
    assign m_axi_awlock = 1'b0;
    assign m_axi_awcache = AWCACHE_VALUE;
    assign m_axi_awprot = AWPROT_VALUE;
    assign m_axi_awqos = 4'd0;
    assign m_axi_awregion = 4'd0;
    // Type-1 VDM with data, routed by ID. Message Code 0x7f identifies
    // MCTP VDM. The controller uses a separate big-endian header sideband.
    assign m_axi_awmisc_info = (21'h7f << 13) | 21'h12;
    assign m_axi_awmisc_info_p_tag = 10'd0;
    assign m_axi_wvalid = state == W;
    assign m_axi_wlast = beat_index == {1'b0, awlen_q[3:0]};
    assign m_axi_bready = state == B;
    assign done_valid = state == DONE;

    always @* begin
        m_axi_awmisc_info_hdr_34dw = sqe_q[63:0];
        // SQE debug bits use EOM/SOM at [7]/[6], while MCTP transport
        // header byte 15 uses SOM/EOM at [7]/[6].
        m_axi_awmisc_info_hdr_34dw[7] = packet_som;
        m_axi_awmisc_info_hdr_34dw[6] = packet_eom;
        m_axi_awmisc_info_hdr_34dw[5:4] = packet_seq;
        m_axi_wdata = reader_data;
        m_axi_wstrb = 64'd0;
        for (i = 0; i < 64; i = i + 1) begin
            absolute_byte = (beat_index << 6) + i;
            if (absolute_byte < wire_bytes) m_axi_wstrb[i] = 1'b1;
            if (absolute_byte >= packet_bytes)
                m_axi_wdata[i*8 +: 8] = 8'd0;
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= IDLE;
            sqe_q <= 256'd0;
            payload_base <= 64'd0;
            target_q <= 64'd0;
            total_bytes <= 21'd0;
            offset <= 21'd0;
            tuz_q <= 11'd0;
            packet_bytes <= 11'd0;
            seq_q <= 2'd0;
            packet_seq <= 2'd0;
            pad_bytes <= 2'd0;
            packet_som <= 1'b0;
            packet_eom <= 1'b0;
            awlen_q <= 8'd0;
            beat_index <= 5'd0;
            done_status <= 8'd0;
        end else begin
            case (state)
                IDLE: if (desc_valid) begin
                    sqe_q <= desc_sqe;
                    payload_base <= {desc_sqe[191:130], 2'b00};
                    target_q <= target_addr;
                    total_bytes <= {1'b0, desc_sqe[219:200]} + 21'd1;
                    offset <= 21'd0;
                    tuz_q <= tuz_bytes;
                    seq_q <= start_seq;
                    done_status <= 8'd0;
                    if (tuz_bytes == 0 || tuz_bytes > 11'd1024) begin
                        done_status <= 8'h63;
                        state <= DONE;
                    end else if (target_addr[5:0] != 0) begin
                        done_status <= 8'h64;
                        state <= DONE;
                    end else state <= PREP;
                end
                PREP: begin
                    packet_bytes <= planned_len;
                    pad_bytes <= planned_pad;
                    packet_som <= offset == 21'd0;
                    packet_eom <= remaining <= {10'd0, tuz_q};
                    packet_seq <= seq_q;
                    awlen_q <= ((planned_wire + 12'd63) >> 6) - 12'd1;
                    beat_index <= 5'd0;
                    if (target_end > 13'd4096) begin
                        done_status <= 8'h64;
                        state <= DONE;
                    end else state <= START_READ;
                end
                START_READ: if (reader_start_ready) state <= WAIT_READ;
                WAIT_READ: if (reader_packet_valid) begin
                    if (reader_packet_error) begin
                        done_status <= 8'h61;
                        state <= DONE;
                    end else state <= AW;
                end
                AW: if (m_axi_awready) state <= W;
                W: if (m_axi_wready) begin
                    if (m_axi_wlast) state <= B;
                    else beat_index <= beat_index + 5'd1;
                end
                B: if (m_axi_bvalid) begin
                    if (m_axi_bresp != 2'b00 || m_axi_bid != 4'd0) begin
                        done_status <= 8'h62;
                        state <= DONE;
                    end else if (packet_eom) begin
                        done_status <= 8'd0;
                        state <= DONE;
                    end else begin
                        offset <= offset + {10'd0, packet_bytes};
                        seq_q <= seq_q + 2'd1;
                        state <= PREP;
                    end
                end
                DONE: if (done_ready) state <= WAIT_PUBLISH;
                WAIT_PUBLISH: if (publish_valid) begin
                    state <= publish_success ? IDLE : FAULT;
                end
                default: state <= FAULT;
            endcase
        end
    end
endmodule
