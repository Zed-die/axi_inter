`timescale 1ns/1ps

// Eight independent RX SQE/message contexts. Prefetch owns FETCH; this module
// owns slot reservation, message binding, SQE writeback, and committed RD.
// The packet router asserts message_done only after all associated Fabric
// writes have completed or an error/timeout has been fully drained.
module inbound_sq_manager #(
    parameter integer   ADDR_WIDTH = 64,
    parameter integer   ID_WIDTH = 4
) (
    input  wire                      clk,
    input  wire                      rst_n,
    input  wire                      enable,
    input  wire [ADDR_WIDTH-1:0]     sq_base_addr,
    input  wire [15:0]               sq_depth,

    output wire                      prefetch_req_valid,
    output wire [4:0]                prefetch_sq_num,
    input  wire                      prefetch_req_ready,
    input  wire [4:0]                prefetch_accept_num,
    input  wire [15:0]               prefetch_fetch_ptr,
    input  wire                      prefetch_sq_empty,
    input  wire [255:0]              prefetch_sq_dout,
    input  wire [15:0]               prefetch_sq_ptr,
    input  wire                      prefetch_sq_error,
    output wire                      prefetch_sq_rd_en,
    input  wire                      prefetch_fault,
    output reg  [15:0]               sq_rd_ptr,

    input  wire [19:0]               som_key,
    input  wire [1:0]                som_seq,
    input  wire                      som_bind,
    output reg                       som_candidate_valid,
    output reg                       som_conflict,
    output reg  [2:0]                som_slot,
    output wire [255:0]              som_sqe,
    input  wire [19:0]               lookup_key,
    output reg                       lookup_valid,
    output reg  [2:0]                lookup_slot,
    output wire [255:0]              lookup_sqe,
    output wire [1:0]                lookup_next_seq,
    output wire                      lookup_seq_valid,

    input  wire                      packet_commit_valid,
    output wire                      packet_commit_ready,
    input  wire [2:0]                packet_commit_slot,
    input  wire [31:0]               packet_commit_bytes,
    input  wire [1:0]                packet_commit_seq,
    input  wire                      packet_commit_eom,
    input  wire                      message_done_valid,
    output wire                      message_done_ready,
    input  wire [2:0]                message_done_slot,
    input  wire [255:0]              message_done_update,
    input  wire [7:0]                message_done_status,
    input  wire                      message_done_abort,

    output wire                      m_axi_awvalid,
    input  wire                      m_axi_awready,
    output wire [ADDR_WIDTH-1:0]     m_axi_awaddr,
    output wire [7:0]                m_axi_awlen,
    output wire [2:0]                m_axi_awsize,
    output wire [1:0]                m_axi_awburst,
    output wire                      m_axi_wvalid,
    input  wire                      m_axi_wready,
    output wire [511:0]              m_axi_wdata,
    output wire [63:0]               m_axi_wstrb,
    output wire                      m_axi_wlast,
    input  wire                      m_axi_bvalid,
    output wire                      m_axi_bready,
    input  wire [1:0]                m_axi_bresp,
    input  wire [ID_WIDTH-1:0]       m_axi_bid,

    output wire                      cq_req_valid,
    input  wire                      cq_req_ready,
    output wire [15:0]               cq_req_cid,
    output wire [7:0]                cq_req_status,
    output wire [15:0]               cq_req_candidate_rd,
    input  wire                      cq_publish_valid,
    input  wire                      cq_publish_success,

    output reg                       queue_fault,
    output reg                       sqe_read_error_event,
    output reg                       sqe_writeback_error_event,
    output reg                       sqe_invalid_event
);
    localparam [3:0] FREE = 4'd0, FETCHING = 4'd1, READY = 4'd2,
                     ACTIVE = 4'd3, DRAIN = 4'd4, DONE = 4'd5,
                     WB_BUSY = 4'd6, CQ_READY = 4'd7, CQ_WAIT = 4'd8,
                     RETIRING = 4'd9, ERROR_HOLD = 4'd10;
    localparam [1:0] WB_IDLE = 2'd0, WB_AW = 2'd1, WB_W = 2'd2, WB_B = 2'd3;

    reg [3:0] slot_state [0:7];
    reg [3:0] free_count;
    reg [15:0] slot_seq [0:7];
    reg [255:0] slot_sqe [0:7];
    reg [19:0] slot_key [0:7];
    reg [31:0] slot_offset [0:7];
    reg [1:0] slot_next_seq [0:7];
    reg slot_seq_valid [0:7];
    reg [7:0] slot_status [0:7];

    integer i;
    integer j;
    integer reserve_idx;
    reg [4:0] reserve_count;
    reg [7:0] reserve_slot_mask;
    reg [2:0] reserve_slot_rank [0:7];
    reg [15:0] best_distance;
    reg [15:0] distance;
    reg prefetch_match;
    reg [2:0] prefetch_match_slot;
    reg wb_pick_valid;
    reg [2:0] wb_pick_slot;
    reg [2:0] wb_rr_ptr;
    reg cq_pick_valid;
    reg [2:0] cq_pick_slot;
    reg [2:0] cq_rr_ptr;
    integer scan_idx;
    wire [15:0] sq_index_mask = sq_depth - 16'd1;

    function [15:0] ring_distance;
        input [15:0] first;
        input [15:0] last;
        input [15:0] mask;
        begin ring_distance = (last - first) & mask; end
    endfunction

    integer integer_idx;

    always @* begin
        free_count = 4'd0;
        prefetch_match = 1'b0;
        prefetch_match_slot = 3'd0;
        som_candidate_valid = 1'b0;
        som_conflict = 1'b0;
        som_slot = 3'd0;
        best_distance = 16'hffff;
        distance = 16'hffff;
        lookup_valid = 1'b0;
        lookup_slot = 3'd0;
        for (integer_idx = 0; integer_idx < 8; integer_idx = integer_idx + 1) begin
            if (slot_state[integer_idx] == FREE) 
                free_count = free_count + 4'd1;
            if (!prefetch_match && slot_state[integer_idx] == FETCHING &&
                slot_seq[integer_idx] == prefetch_sq_ptr) begin
                prefetch_match = 1'b1;
                prefetch_match_slot = integer_idx[2:0];
            end
            if (slot_state[integer_idx] == READY) begin
                distance = ring_distance(sq_rd_ptr, slot_seq[integer_idx], sq_index_mask);
                if (distance < best_distance) begin
                    best_distance = distance;
                    som_candidate_valid = 1'b1;
                    som_slot = integer_idx[2:0];
                end
            end
            if (slot_state[integer_idx] == ACTIVE && slot_key[integer_idx] == som_key)
                som_conflict = 1'b1;
            if (!lookup_valid && slot_state[integer_idx] == ACTIVE &&
                slot_key[integer_idx] == lookup_key) begin
                lookup_valid = 1'b1;
                lookup_slot = integer_idx[2:0];
            end
        end
        if (som_conflict || queue_fault || !enable) som_candidate_valid = 1'b0;
    end

    assign som_sqe = som_candidate_valid ? slot_sqe[som_slot] : 256'd0;
    assign lookup_sqe = lookup_valid ? slot_sqe[lookup_slot] : 256'd0;
    assign lookup_next_seq = lookup_valid ? slot_next_seq[lookup_slot] : 2'd0;
    assign lookup_seq_valid = lookup_valid && slot_seq_valid[lookup_slot];

    assign prefetch_req_valid = rst_n && enable && !queue_fault && (free_count != 0);
    assign prefetch_sq_num = {1'b0, free_count};
    assign prefetch_sq_rd_en = rst_n && !prefetch_sq_empty;
    wire reserve_fire = prefetch_req_valid && prefetch_req_ready && (prefetch_accept_num != 0);
    always @* begin
        reserve_count = 5'd0;
        reserve_slot_mask = 8'd0;
        for (reserve_idx = 0; reserve_idx < 8; reserve_idx = reserve_idx + 1) begin
            reserve_slot_rank[reserve_idx] = reserve_count[2:0];
            if (slot_state[reserve_idx] == FREE && reserve_count < prefetch_accept_num) begin
                reserve_slot_mask[reserve_idx] = 1'b1;
                reserve_count = reserve_count + 5'd1;
            end
        end
    end
    assign packet_commit_ready = (slot_state[packet_commit_slot] == ACTIVE);
    assign message_done_ready = (slot_state[message_done_slot] == DRAIN ||
                                 (message_done_abort && slot_state[message_done_slot] == ACTIVE)) &&
                                !(packet_commit_valid && packet_commit_ready &&
                                  packet_commit_slot == message_done_slot);

    always @* begin
        wb_pick_valid = 1'b0;
        wb_pick_slot = 3'd0;
        cq_pick_valid = 1'b0;
        cq_pick_slot = 3'd0;
        for (scan_idx = 0; scan_idx < 8; scan_idx = scan_idx + 1) begin
            if (!wb_pick_valid && slot_state[(wb_rr_ptr + scan_idx) & 3'h7] == DONE) begin
                wb_pick_valid = 1'b1;
                wb_pick_slot = (wb_rr_ptr + scan_idx) & 3'h7;
            end
            if (!cq_pick_valid && slot_state[(cq_rr_ptr + scan_idx) & 3'h7] == CQ_READY) begin
                cq_pick_valid = 1'b1;
                cq_pick_slot = (cq_rr_ptr + scan_idx) & 3'h7;
            end
        end
    end

    reg [15:0] candidate_rd;
    reg candidate_hit;
    integer step;
    integer search;
    always @* begin
        candidate_rd = sq_rd_ptr;
        candidate_hit = 1'b0;
        for (step = 0; step < 8; step = step + 1) begin
            candidate_hit = 1'b0;
            for (search = 0; search < 8; search = search + 1) begin
                if ((slot_state[search] == RETIRING ||
                    (cq_pick_valid && search == cq_pick_slot && slot_state[search] == CQ_READY)) &&
                    slot_seq[search] == candidate_rd) candidate_hit = 1'b1;
            end
            if (candidate_hit) candidate_rd = (candidate_rd + 16'd1) & sq_index_mask;
        end
    end

    reg [1:0] wb_state;
    reg [2:0] wb_slot;
    reg [2:0] cq_pending_slot;
    reg [15:0] cq_pending_rd;
    reg cq_busy;
    reg [ADDR_WIDTH-1:0] wb_addr;
    reg [255:0] wb_data;

    assign m_axi_awvalid = (wb_state == WB_AW);
    assign m_axi_awaddr = wb_addr;
    assign m_axi_awlen = 8'd0;
    assign m_axi_awsize = 3'd5;
    assign m_axi_awburst = 2'b01;
    assign m_axi_wvalid = (wb_state == WB_W);
    assign m_axi_wdata = {2{wb_data}};
    assign m_axi_wstrb = wb_addr[5] ? {32'hffffffff, 32'd0} : {32'd0, 32'hffffffff};
    assign m_axi_wlast = 1'b1;
    assign m_axi_bready = (wb_state == WB_B);

    assign cq_req_valid = !cq_busy && cq_pick_valid;
    assign cq_req_cid = cq_pick_valid ? slot_sqe[cq_pick_slot][255:240] : 16'd0;
    assign cq_req_status = cq_pick_valid ? slot_status[cq_pick_slot] : 8'd0;
    assign cq_req_candidate_rd = candidate_rd;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            sq_rd_ptr <= 16'd0;
            wb_state <= WB_IDLE;
            wb_slot <= 3'd0;
            wb_rr_ptr <= 3'd0;
            wb_addr <= {ADDR_WIDTH{1'b0}};
            wb_data <= 256'd0;
            cq_busy <= 1'b0;
            cq_pending_slot <= 3'd0;
            cq_pending_rd <= 16'd0;
            cq_rr_ptr <= 3'd0;
            queue_fault <= 1'b0;
            sqe_read_error_event <= 1'b0;
            sqe_writeback_error_event <= 1'b0;
            sqe_invalid_event <= 1'b0;
            for (i = 0; i < 8; i = i + 1) begin
                slot_state[i] <= FREE;
                slot_seq[i] <= 16'd0;
                slot_sqe[i] <= 256'd0;
                slot_key[i] <= 20'd0;
                slot_offset[i] <= 32'd0;
                slot_next_seq[i] <= 2'd0;
                slot_seq_valid[i] <= 1'b0;
                slot_status[i] <= 8'd0;
            end
        end else begin
            sqe_read_error_event <= 1'b0;
            sqe_writeback_error_event <= 1'b0;
            sqe_invalid_event <= 1'b0;
            if (prefetch_fault) queue_fault <= 1'b1;

            if (reserve_fire) begin
                if (prefetch_accept_num > {1'b0, free_count}) queue_fault <= 1'b1;
                for (i = 0; i < 8; i = i + 1) begin
                    if (reserve_slot_mask[i]) begin
                        slot_state[i] <= FETCHING;
                        slot_seq[i] <= (prefetch_fetch_ptr + reserve_slot_rank[i]) & sq_index_mask;
                        slot_sqe[i] <= 256'd0;
                    end
                end
            end

            if (prefetch_sq_rd_en) begin
                if (!prefetch_match) begin
                    queue_fault <= 1'b1;
                end else if (prefetch_sq_error) begin
                    slot_state[prefetch_match_slot] <= ERROR_HOLD;
                    sqe_read_error_event <= 1'b1;
                    queue_fault <= 1'b1;
                end else if (prefetch_sq_dout[95:90] != 6'd1) begin
                    slot_sqe[prefetch_match_slot] <= prefetch_sq_dout;
                    slot_state[prefetch_match_slot] <= ERROR_HOLD;
                    sqe_invalid_event <= 1'b1;
                    queue_fault <= 1'b1;
                end else begin
                    slot_sqe[prefetch_match_slot] <= prefetch_sq_dout;
                    slot_state[prefetch_match_slot] <= READY;
                end
            end

            if (som_bind && som_candidate_valid) begin
                slot_state[som_slot] <= ACTIVE;
                slot_key[som_slot] <= som_key;
                slot_offset[som_slot] <= 32'd0;
                slot_next_seq[som_slot] <= som_seq + 2'd1;
                slot_seq_valid[som_slot] <= 1'b0;
            end

            if (packet_commit_valid && packet_commit_ready) begin
                if (slot_offset[packet_commit_slot] > 32'hffffffff - packet_commit_bytes) begin
                    slot_state[packet_commit_slot] <= ERROR_HOLD;
                    queue_fault <= 1'b1;
                end else begin
                    slot_offset[packet_commit_slot] <= slot_offset[packet_commit_slot] + packet_commit_bytes;
                    slot_next_seq[packet_commit_slot] <= packet_commit_seq + 2'd1;
                    slot_seq_valid[packet_commit_slot] <= 1'b1;
                    if (packet_commit_eom) slot_state[packet_commit_slot] <= DRAIN;
                end
            end

            if (message_done_valid && message_done_ready) begin
                // The completion controller currently supplies only RX LEN.
                slot_sqe[message_done_slot][219:200] <= message_done_update[219:200];
                slot_status[message_done_slot] <= message_done_status;
                slot_state[message_done_slot] <= DONE;
            end

            case (wb_state)
                WB_IDLE: if (wb_pick_valid) begin
                    wb_slot <= wb_pick_slot;
                    wb_rr_ptr <= wb_pick_slot + 3'd1;
                    wb_addr <= sq_base_addr +
                        ({{(ADDR_WIDTH-16){1'b0}},
                          (slot_seq[wb_pick_slot] & sq_index_mask)} << 5);
                    wb_data <= slot_sqe[wb_pick_slot];
                    slot_state[wb_pick_slot] <= WB_BUSY;
                    wb_state <= WB_AW;
                end
                WB_AW: if (m_axi_awready) wb_state <= WB_W;
                WB_W: if (m_axi_wready) wb_state <= WB_B;
                WB_B: if (m_axi_bvalid) begin
                    if (m_axi_bresp == 2'b00 && m_axi_bid == {ID_WIDTH{1'b0}}) begin
                        slot_state[wb_slot] <= CQ_READY;
                    end else begin
                        slot_state[wb_slot] <= ERROR_HOLD;
                        sqe_writeback_error_event <= 1'b1;
                        queue_fault <= 1'b1;
                    end
                    wb_state <= WB_IDLE;
                end
            endcase

            if (cq_req_valid && cq_req_ready) begin
                cq_busy <= 1'b1;
                cq_pending_slot <= cq_pick_slot;
                cq_pending_rd <= candidate_rd;
                cq_rr_ptr <= cq_pick_slot + 3'd1;
                slot_state[cq_pick_slot] <= CQ_WAIT;
            end
            if (cq_publish_valid && cq_busy) begin
                cq_busy <= 1'b0;
                if (cq_publish_success) begin
                    sq_rd_ptr <= cq_pending_rd;
                    for (j = 0; j < 8; j = j + 1) begin
                        if ((slot_state[j] == RETIRING ||
                            (j == cq_pending_slot && slot_state[j] == CQ_WAIT)) &&
                            ring_distance(sq_rd_ptr, slot_seq[j], sq_index_mask) <
                            ring_distance(sq_rd_ptr, cq_pending_rd, sq_index_mask))
                            slot_state[j] <= FREE;
                    end
                    if (ring_distance(sq_rd_ptr, slot_seq[cq_pending_slot], sq_index_mask) >=
                        ring_distance(sq_rd_ptr, cq_pending_rd, sq_index_mask))
                        slot_state[cq_pending_slot] <= RETIRING;
                end else begin
                    slot_state[cq_pending_slot] <= ERROR_HOLD;
                    queue_fault <= 1'b1;
                end
            end
        end
    end
endmodule
