`timescale 1ns/1ps

// Sticky status with write-one-to-clear and level-sensitive IRQ.
// New events win when set and clear target the same bit in one cycle.
module inbound_irq_status (
    input  wire       clk,
    input  wire       rst_n,
    input  wire [7:0] event_set,
    input  wire [7:0] clear,
    input  wire [7:0] mask,
    output reg  [7:0] status,
    output wire       irq
);
    assign irq = |(status & mask);
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) status <= 8'd0;
        else status <= (status & ~clear) | event_set;
    end
endmodule
