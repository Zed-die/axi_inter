`timescale 1ns/1ps

// Per-slot receive completion. The SQ manager owns the actual SQE writeback;
// this module waits until a terminal packet is resolved and supplies LEN/status.
module inbound_message_completion (
    input  wire         clk,
    input  wire         rst_n,
    input  wire         store_valid,
    input  wire [2:0]   store_slot,
    input  wire         store_som,
    input  wire         route_valid,
    input  wire [2:0]   route_slot,
    input  wire         route_som,
    input  wire         route_eom,
    input  wire [10:0]  route_bytes,
    input  wire         route_error,
    input  wire [3:0]   route_reason,
    input  wire         abort_valid,
    input  wire [2:0]   abort_slot,
    input  wire [3:0]   abort_reason,
    input  wire         timeout_valid,
    input  wire [2:0]   timeout_slot,
    input  wire         drop_valid,
    input  wire         drop_slot_valid,
    input  wire [2:0]   drop_slot,
    input  wire         drop_was_store,
    output reg          message_done_valid,
    input  wire         message_done_ready,
    output reg  [2:0]   message_done_slot,
    output reg  [255:0] message_done_update,
    output reg  [7:0]   message_done_status,
    output reg          message_done_abort
);
    reg store_pending [0:7];
    reg abort_pending [0:7];
    reg end_pending [0:7];
    reg [31:0] total_bytes [0:7];
    reg [7:0] error_status [0:7];
    integer i;
    integer pick;

    always @* begin
        message_done_valid = 1'b0;
        message_done_slot = 3'd0;
        message_done_update = 256'd0;
        message_done_status = 8'd0;
        message_done_abort = 1'b0;
        for (pick = 0; pick < 8; pick = pick + 1) begin
            if (!message_done_valid && !store_pending[pick] &&
                (abort_pending[pick] || end_pending[pick])) begin
                message_done_valid = 1'b1;
                message_done_slot = pick[2:0];
                message_done_abort = abort_pending[pick];
                message_done_status = abort_pending[pick] ? error_status[pick] : 8'd0;
                message_done_update[219:200] =
                    total_bytes[pick] == 0 ? 20'd0 : total_bytes[pick] - 32'd1;
            end
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            for (i = 0; i < 8; i = i + 1) begin
                store_pending[i] <= 1'b0;
                abort_pending[i] <= 1'b0;
                end_pending[i] <= 1'b0;
                total_bytes[i] <= 32'd0;
                error_status[i] <= 8'd0;
            end
        end else begin
            if (store_valid) begin
                store_pending[store_slot] <= 1'b1;
                if (store_som) begin
                    total_bytes[store_slot] <= 32'd0;
                    abort_pending[store_slot] <= 1'b0;
                    end_pending[store_slot] <= 1'b0;
                    error_status[store_slot] <= 8'd0;
                end
            end
            if (route_valid) begin
                store_pending[route_slot] <= 1'b0;
                if (route_error) begin
                    abort_pending[route_slot] <= 1'b1;
                    error_status[route_slot] <= 8'h40 + {4'd0, route_reason};
                end else begin
                    total_bytes[route_slot] <= route_som ?
                        {21'd0, route_bytes} :
                        total_bytes[route_slot] + {21'd0, route_bytes};
                    if (route_eom) end_pending[route_slot] <= 1'b1;
                end
            end
            if (drop_valid && drop_slot_valid && drop_was_store)
                store_pending[drop_slot] <= 1'b0;
            if (timeout_valid) begin
                abort_pending[timeout_slot] <= 1'b1;
                error_status[timeout_slot] <= 8'h26;
            end
            if (abort_valid) begin
                abort_pending[abort_slot] <= 1'b1;
                error_status[abort_slot] <= 8'h20 + {4'd0, abort_reason};
            end
            if (message_done_valid && message_done_ready) begin
                abort_pending[message_done_slot] <= 1'b0;
                end_pending[message_done_slot] <= 1'b0;
                store_pending[message_done_slot] <= 1'b0;
            end
        end
    end
endmodule
