`timescale 1ns/1ps

// SQ/CQ MCTP Engine top. RX and TX share the internal memory-side BIU and CQ.
// The external PCIe decoder and system bridges remain outside this module.
module mctp_engine #(
    parameter USE_APB = 1'b1,
    parameter ENABLE_TX = 1'b1
) (
    input  wire         clk,
    input  wire         rst_n,
    input  wire         enable,
    input  wire [63:0]  sq_base_addr,
    input  wire [15:0]  sq_tail_ptr,
    input  wire [63:0]  cq_base_addr,
    input  wire [8:0]   cq_head,
    output wire [8:0]   cq_tail,
    output wire [15:0]  sq_rd_ptr,
    input  wire         tx_enable,
    input  wire [63:0]  tx_sq_base_addr,
    input  wire [15:0]  tx_sq_tail_ptr,
    output wire [15:0]  tx_sq_rd_ptr,
    input  wire [10:0]  tx_tuz_bytes,
    input  wire [63:0]  tx_target_addr,
    input  wire [1:0]   tx_start_seq,
    input  wire [7:0]   irq_mask,
    input  wire [7:0]   irq_clear,
    input  wire [31:0]  message_timeout_cycles,
    input  wire [31:0]  congestion_timeout_cycles,
    output wire [7:0]   irq_status,
    output wire         irq_level,
    input  wire         psel,
    input  wire         penable,
    input  wire         pwrite,
    input  wire [7:0]   paddr,
    input  wire [31:0]  pwdata,
    output wire [31:0]  prdata,
    output wire         pready,
    output wire         pslverr,
    input  wire         filter_enable,
    input  wire [3:0]   rule_enable,
    input  wire [3:0]   rule_drop,
    input  wire [31:0]  rule_value,
    input  wire [31:0]  rule_mask,
    input  wire         default_drop,
    input  wire         store_bounds_ok,
    input  wire         congestion_drop,
    input  wire         lookup_timeout,
    input  wire         current_timeout,
    input  wire         s_awvalid,
    output wire         s_awready,
    input  wire [3:0]   s_awid,
    input  wire [127:0] s_awmeta,
    input  wire [7:0]   s_awlen,
    input  wire [2:0]   s_awsize,
    input  wire [1:0]   s_awburst,
    input  wire [7:0]   s_scope,
    input  wire [7:0]   s_seid,
    input  wire         s_to,
    input  wire [2:0]   s_tag,
    input  wire         s_som,
    input  wire         s_eom,
    input  wire [1:0]   s_seq,
    input  wire         s_wvalid,
    output wire         s_wready,
    input  wire [511:0] s_wdata,
    input  wire [63:0]  s_wstrb,
    input  wire         s_wlast,
    output wire         s_bvalid,
    input  wire         s_bready,
    output wire [3:0]   s_bid,
    output wire [1:0]   s_bresp,
    output wire         tx_awvalid,
    input  wire         tx_awready,
    output wire [63:0]  tx_awaddr,
    output wire [7:0]   tx_awlen,
    output wire [2:0]   tx_awsize,
    output wire [1:0]   tx_awburst,
    output wire [3:0]   tx_awid,
    output wire [255:0] tx_awmeta,
    output wire [10:0]  tx_packet_bytes,
    output wire         tx_som,
    output wire         tx_eom,
    output wire [1:0]   tx_seq,
    output wire [1:0]   tx_pad_len,
    output wire         tx_wvalid,
    input  wire         tx_wready,
    output wire [511:0] tx_wdata,
    output wire [63:0]  tx_wstrb,
    output wire         tx_wlast,
    input  wire         tx_bvalid,
    output wire         tx_bready,
    input  wire [1:0]   tx_bresp,
    input  wire [3:0]   tx_bid,
    output wire         m_axi_arvalid,
    input  wire         m_axi_arready,
    output wire [63:0]  m_axi_araddr,
    output wire [7:0]   m_axi_arlen,
    output wire [2:0]   m_axi_arsize,
    output wire [1:0]   m_axi_arburst,
    output wire [3:0]   m_axi_arid,
    output wire         m_axi_arlock,
    output wire [3:0]   m_axi_arcache,
    output wire [2:0]   m_axi_arprot,
    output wire [3:0]   m_axi_arqos,
    output wire [3:0]   m_axi_arregion,
    input  wire         m_axi_rvalid,
    output wire         m_axi_rready,
    input  wire [511:0] m_axi_rdata,
    input  wire [1:0]   m_axi_rresp,
    input  wire         m_axi_rlast,
    input  wire [3:0]   m_axi_rid,
    output wire         m_axi_awvalid,
    input  wire         m_axi_awready,
    output wire [63:0]  m_axi_awaddr,
    output wire [7:0]   m_axi_awlen,
    output wire [2:0]   m_axi_awsize,
    output wire [1:0]   m_axi_awburst,
    output wire [3:0]   m_axi_awid,
    output wire         m_axi_awlock,
    output wire [3:0]   m_axi_awcache,
    output wire [2:0]   m_axi_awprot,
    output wire [3:0]   m_axi_awqos,
    output wire [3:0]   m_axi_awregion,
    output wire         m_axi_wvalid,
    input  wire         m_axi_wready,
    output wire [511:0] m_axi_wdata,
    output wire [63:0]  m_axi_wstrb,
    output wire         m_axi_wlast,
    input  wire         m_axi_bvalid,
    output wire         m_axi_bready,
    input  wire [1:0]   m_axi_bresp,
    input  wire [3:0]   m_axi_bid
);
    wire enable_i, filter_enable_i, default_drop_i, tx_enable_cfg;
    wire [63:0] sq_base_i, cq_base_i, tx_sq_base_i, tx_target_i;
    wire [15:0] sq_tail_i, tx_sq_tail_i;
    wire [8:0] sq_depth_i;
    wire [8:0] cq_head_i;
    wire [3:0] rule_enable_i, rule_drop_i;
    wire [31:0] rule_value_i, rule_mask_i;
    wire [7:0] irq_mask_i, irq_clear_i;
    wire [31:0] message_timeout_i, congestion_timeout_i;
    wire [10:0] tx_tuz_i;
    wire [1:0] tx_start_seq_i;
    wire tx_enable_i = ENABLE_TX && tx_enable_cfg;
    apb_interface #(
        .USE_APB (USE_APB)
    ) apb_i (
        .clk                              (clk),
        .rst_n                            (rst_n),
        .psel                             (psel),
        .penable                          (penable),
        .pwrite                           (pwrite),
        .paddr                            (paddr),
        .pwdata                           (pwdata),
        .prdata                           (prdata),
        .pready                           (pready),
        .pslverr                          (pslverr),
        .direct_enable                    (enable),
        .direct_sq_base_addr              (sq_base_addr),
        .direct_sq_tail_ptr               (sq_tail_ptr),
        .direct_cq_base_addr              (cq_base_addr),
        .direct_cq_head                   (cq_head),
        .direct_filter_enable             (filter_enable),
        .direct_default_drop              (default_drop),
        .direct_rule_enable               (rule_enable),
        .direct_rule_drop                 (rule_drop),
        .direct_rule_value                (rule_value),
        .direct_rule_mask                 (rule_mask),
        .direct_irq_mask                  (irq_mask),
        .direct_irq_clear                 (irq_clear),
        .direct_message_timeout_cycles    (message_timeout_cycles),
        .direct_congestion_timeout_cycles (congestion_timeout_cycles),
        .direct_tx_enable                 (tx_enable),
        .direct_tx_sq_base_addr           (tx_sq_base_addr),
        .direct_tx_sq_tail_ptr            (tx_sq_tail_ptr),
        .direct_tx_tuz_bytes              (tx_tuz_bytes),
        .direct_tx_target_addr            (tx_target_addr),
        .direct_tx_start_seq              (tx_start_seq),
        .irq_status                       (irq_status),
        .cq_tail                          (cq_tail),
        .sq_rd_ptr                        (sq_rd_ptr),
        .tx_sq_rd_ptr                     (tx_sq_rd_ptr),
        .cfg_enable                       (enable_i),
        .cfg_sq_base_addr                 (sq_base_i),
        .cfg_sq_tail_ptr                  (sq_tail_i),
        .cfg_sq_depth                     (sq_depth_i),
        .cfg_cq_base_addr                 (cq_base_i),
        .cfg_cq_head                      (cq_head_i),
        .cfg_filter_enable                (filter_enable_i),
        .cfg_default_drop                 (default_drop_i),
        .cfg_rule_enable                  (rule_enable_i),
        .cfg_rule_drop                    (rule_drop_i),
        .cfg_rule_value                   (rule_value_i),
        .cfg_rule_mask                    (rule_mask_i),
        .cfg_irq_mask                     (irq_mask_i),
        .cfg_irq_clear                    (irq_clear_i),
        .cfg_message_timeout_cycles       (message_timeout_i),
        .cfg_congestion_timeout_cycles    (congestion_timeout_i),
        .cfg_tx_enable                    (tx_enable_cfg),
        .cfg_tx_sq_base_addr              (tx_sq_base_i),
        .cfg_tx_sq_tail_ptr               (tx_sq_tail_i),
        .cfg_tx_tuz_bytes                 (tx_tuz_i),
        .cfg_tx_target_addr               (tx_target_i),
        .cfg_tx_start_seq                 (tx_start_seq_i)
    );
    wire prefetch_req_valid, prefetch_req_ready;
    wire [4:0] prefetch_sq_num, prefetch_accept_num;
    wire [15:0] prefetch_fetch_ptr, prefetch_sq_ptr;
    wire prefetch_sq_empty, prefetch_sq_error, prefetch_sq_rd_en, prefetch_fault;
    wire [255:0] prefetch_sq_dout;
    wire pf_arvalid, pf_arready, pf_rvalid, pf_rready, pf_rlast;
    wire [63:0] pf_araddr;
    wire [7:0] pf_arlen;
    wire [2:0] pf_arsize;
    wire [511:0] pf_rdata;
    wire [1:0] pf_rresp;
    wire [3:0] pf_rid;
    wire [2:0] rd_arready, rd_rvalid, rd_rready, rd_rlast;
    wire [1535:0] rd_rdata;
    wire [5:0] rd_rresp;
    wire [11:0] rd_rid;
    wire tx_pf_req_valid, tx_pf_req_ready, tx_pf_arvalid, tx_pf_arready;
    wire tx_pf_rvalid, tx_pf_rready, tx_pf_rlast, tx_pf_fault;
    wire [4:0] tx_pf_sq_num, tx_pf_accept_num;
    wire [15:0] tx_pf_fetch_ptr, tx_pf_sq_ptr;
    wire [63:0] tx_pf_araddr;
    wire [7:0] tx_pf_arlen;
    wire [2:0] tx_pf_arsize;
    wire [1:0] tx_pf_arburst;
    wire [511:0] tx_pf_rdata;
    wire [1:0] tx_pf_rresp;
    wire [3:0] tx_pf_rid, tx_pf_sq_count;
    wire tx_pf_sq_valid, tx_pf_sq_error, tx_pf_sq_pop;
    wire [255:0] tx_pf_sq_dout;
    wire tx_gen_desc_valid, tx_gen_desc_ready, tx_gen_done_valid;
    wire [255:0] tx_gen_desc_sqe;
    wire [7:0] tx_gen_done_status;
    wire tx_gen_done_ready, tx_gen_publish_valid, tx_gen_publish_success;
    wire tx_cq_req_valid, tx_cq_req_ready, tx_cq_publish_valid;
    wire tx_cq_publish_success, tx_queue_fault, tx_sqe_read_error_event;
    wire tx_sqe_invalid_event;
    wire [15:0] tx_cq_req_cid, tx_cq_req_sq_ptr, tx_cq_req_candidate_rd;
    wire [7:0] tx_cq_req_status;
    wire tx_reader_start_valid, tx_reader_start_ready;
    wire [63:0] tx_reader_start_addr;
    wire [10:0] tx_reader_start_len, tx_reader_packet_len;
    wire tx_reader_packet_valid, tx_reader_packet_error, tx_reader_release;
    wire [3:0] tx_reader_index;
    wire [511:0] tx_reader_data;
    wire tx_rd_arvalid, tx_rd_arready, tx_rd_rvalid, tx_rd_rready, tx_rd_rlast;
    wire [63:0] tx_rd_araddr;
    wire [7:0] tx_rd_arlen;
    wire [2:0] tx_rd_arsize;
    wire [1:0] tx_rd_arburst, tx_rd_rresp;
    wire [511:0] tx_rd_rdata;
    wire [3:0] tx_rd_rid;

    wire [19:0] som_key, lookup_key;
    wire som_candidate_valid, som_conflict, som_bind;
    wire [2:0] som_slot, lookup_slot;
    wire [255:0] som_sqe, lookup_sqe;
    wire lookup_valid, lookup_seq_valid;
    wire [1:0] lookup_next_seq;
    wire [3:0] free_count;
    wire manager_queue_fault, sqe_read_error_event, sqe_writeback_error_event;
    wire sqe_invalid_event;
    wire packet_commit_valid, packet_commit_ready, packet_commit_eom;
    wire [2:0] packet_commit_slot;
    wire [31:0] packet_commit_bytes;
    wire [1:0] packet_commit_seq;
    wire message_done_valid, message_done_ready, message_done_abort;
    wire [2:0] message_done_slot;
    wire [255:0] message_done_update;
    wire [7:0] message_done_status;

    wire buffer_free, buf_reserve, buf_write, buf_finish, buf_finish_good;
    wire buf_packet_valid, buf_packet_ready, buf_packet_release;
    wire [3:0] buf_wr_addr, buf_rd_addr;
    wire [511:0] buf_wr_data, buf_rd_data;
    wire [63:0] buf_wr_strb, buf_rd_strb;
    wire packet_valid, packet_ready, packet_release, packet_som, packet_eom;
    wire [127:0] packet_meta;
    wire [4:0] packet_token;
    wire [2:0] packet_slot;
    wire [1:0] packet_seq;
    wire [10:0] packet_wbytes;
    wire [4:0] packet_beats;
    wire [255:0] packet_sqe;
    wire drop_done_valid, drop_done_slot_valid, drop_done_was_store;
    wire [127:0] drop_done_meta;
    wire [4:0] drop_done_token;
    wire [2:0] drop_done_slot;
    wire [3:0] drop_done_reason;
    wire drop_event_valid, abort_event_valid;
    wire [3:0] drop_event_reason, abort_event_reason;
    wire [2:0] abort_event_slot;
    wire response_credit;
    wire [4:0] response_token;
    wire controller_aw_fire = s_awvalid && s_awready;
    wire gap_timeout_valid;
    wire [2:0] gap_timeout_slot;
    wire [7:0] gap_expired;
    reg [31:0] congestion_wait;
    wire auto_congestion_drop = congestion_timeout_i != 32'd0 &&
        congestion_wait >= congestion_timeout_i - 32'd1;
    wire congestion_drop_i = congestion_drop || auto_congestion_drop;
    wire lookup_timeout_i = lookup_timeout ||
        (lookup_valid && gap_expired[lookup_slot]) ||
        (lookup_valid && gap_timeout_valid && lookup_slot == gap_timeout_slot);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) congestion_wait <= 32'd0;
        else if (s_awvalid && !s_awready && !s_wready && !buffer_free &&
                 congestion_wait != 32'hffffffff)
            congestion_wait <= congestion_wait + 32'd1;
        else if (!s_awvalid || s_awready || buffer_free)
            congestion_wait <= 32'd0;
    end

    wire route_result_valid, route_result_error, route_result_som;
    wire route_result_eom;
    wire [127:0] route_result_meta;
    wire [4:0] route_result_token;
    wire [2:0] route_result_slot;
    wire [10:0] route_result_bytes;
    wire [3:0] route_result_reason;
    wire [1:0] route_result_bresp;

    wire rx_cq_req_valid, rx_cq_req_ready, rx_cq_publish_valid;
    wire rx_cq_publish_success, cq_completion_event, cq_fault;
    wire [2:0] rx_cq_req_slot;
    wire [15:0] rx_cq_req_cid, rx_cq_req_sq_ptr;
    wire [7:0] rx_cq_req_status;
    wire [15:0] rx_cq_candidate_rd;

    wire router_awvalid, router_awready, router_wvalid, router_wready;
    wire router_wlast, router_bvalid, router_bready;
    wire [63:0] router_awaddr;
    wire [7:0] router_awlen;
    wire [2:0] router_awsize;
    wire [1:0] router_awburst, router_bresp;
    wire [511:0] router_wdata;
    wire [63:0] router_wstrb;
    wire [3:0] router_bid;
    wire sq_awvalid, sq_awready, sq_wvalid, sq_wready, sq_wlast;
    wire sq_bvalid, sq_bready;
    wire [63:0] sq_awaddr;
    wire [7:0] sq_awlen;
    wire [2:0] sq_awsize;
    wire [1:0] sq_awburst, sq_bresp;
    wire [511:0] sq_wdata;
    wire [63:0] sq_wstrb;
    wire [3:0] sq_bid;
    wire cq_awvalid, cq_awready, cq_wvalid, cq_wready, cq_wlast;
    wire cq_bvalid, cq_bready;
    wire [63:0] cq_awaddr;
    wire [7:0] cq_awlen;
    wire [2:0] cq_awsize;
    wire [1:0] cq_awburst, cq_bresp;
    wire [511:0] cq_wdata;
    wire [63:0] cq_wstrb;
    wire [3:0] cq_bid;
    wire [2:0] wr_awready, wr_wready, wr_bvalid, wr_bready;
    wire [11:0] wr_bid;
    wire [5:0] wr_bresp;

    inbound_sq_prefetch prefetch_i (
        .clk                      (clk),
        .rst_n                    (rst_n),
        .inbound_sq_base_addr     (sq_base_i),
        .inbound_sq_depth         (sq_depth_i),
        .inbound_tail_ptr        (sq_tail_i),
        .prefetch_req_valid      (prefetch_req_valid),
        .prefetch_sq_num         (prefetch_sq_num),
        .prefetch_req_ready      (prefetch_req_ready),
        .prefetch_accept_num     (prefetch_accept_num),
        .inbound_fetch_ptr       (prefetch_fetch_ptr),
        .m_axi_arvalid           (pf_arvalid),
        .m_axi_arready           (pf_arready),
        .m_axi_araddr            (pf_araddr),
        .m_axi_arlen             (pf_arlen),
        .m_axi_arsize            (pf_arsize),
        .m_axi_rvalid            (pf_rvalid),
        .m_axi_rready            (pf_rready),
        .m_axi_rdata             (pf_rdata),
        .m_axi_rresp             (pf_rresp),
        .m_axi_rlast             (pf_rlast),
        .m_axi_rid               (pf_rid),
        .sq_rd_en                (prefetch_sq_rd_en),
        .sq_empty                (prefetch_sq_empty),
        .sq_dout                 (prefetch_sq_dout),
        .sq_ptr                  (prefetch_sq_ptr),
        .sq_error                (prefetch_sq_error),
        .fault                   (prefetch_fault)
    );

    inbound_sq_manager manager_i (
        .clk                       (clk),
        .rst_n                     (rst_n),
        .enable                    (enable_i),
        .sq_base_addr              (sq_base_i),
        .sq_depth                  (sq_depth_i),
        .prefetch_req_valid        (prefetch_req_valid),
        .prefetch_sq_num           (prefetch_sq_num),
        .prefetch_req_ready        (prefetch_req_ready),
        .prefetch_accept_num       (prefetch_accept_num),
        .prefetch_fetch_ptr        (prefetch_fetch_ptr),
        .prefetch_sq_empty         (prefetch_sq_empty),
        .prefetch_sq_dout          (prefetch_sq_dout),
        .prefetch_sq_ptr           (prefetch_sq_ptr),
        .prefetch_sq_error         (prefetch_sq_error),
        .prefetch_sq_rd_en         (prefetch_sq_rd_en),
        .prefetch_fault            (prefetch_fault),
        .sq_rd_ptr                 (sq_rd_ptr),
        .free_count                (free_count),
        .som_key                   (som_key),
        .som_seq                   (s_seq),
        .som_bind                  (som_bind),
        .som_candidate_valid       (som_candidate_valid),
        .som_conflict              (som_conflict),
        .som_slot                  (som_slot),
        .som_sqe                   (som_sqe),
        .lookup_key                (lookup_key),
        .lookup_valid              (lookup_valid),
        .lookup_slot               (lookup_slot),
        .lookup_sqe                (lookup_sqe),
        .lookup_next_seq           (lookup_next_seq),
        .lookup_seq_valid          (lookup_seq_valid),
        .packet_commit_valid       (packet_commit_valid),
        .packet_commit_ready       (packet_commit_ready),
        .packet_commit_slot        (packet_commit_slot),
        .packet_commit_bytes       (packet_commit_bytes),
        .packet_commit_seq         (packet_commit_seq),
        .packet_commit_eom         (packet_commit_eom),
        .message_done_valid        (message_done_valid),
        .message_done_ready        (message_done_ready),
        .message_done_slot         (message_done_slot),
        .message_done_update       (message_done_update),
        .message_done_status       (message_done_status),
        .message_done_abort        (message_done_abort),
        .m_axi_awvalid             (sq_awvalid),
        .m_axi_awready             (sq_awready),
        .m_axi_awaddr              (sq_awaddr),
        .m_axi_awlen               (sq_awlen),
        .m_axi_awsize              (sq_awsize),
        .m_axi_awburst             (sq_awburst),
        .m_axi_wvalid              (sq_wvalid),
        .m_axi_wready              (sq_wready),
        .m_axi_wdata               (sq_wdata),
        .m_axi_wstrb               (sq_wstrb),
        .m_axi_wlast               (sq_wlast),
        .m_axi_bvalid              (sq_bvalid),
        .m_axi_bready              (sq_bready),
        .m_axi_bresp               (sq_bresp),
        .m_axi_bid                 (sq_bid),
        .cq_req_valid              (rx_cq_req_valid),
        .cq_req_ready              (rx_cq_req_ready),
        .cq_req_slot               (rx_cq_req_slot),
        .cq_req_cid                (rx_cq_req_cid),
        .cq_req_sq_ptr             (rx_cq_req_sq_ptr),
        .cq_req_status             (rx_cq_req_status),
        .cq_req_candidate_rd       (rx_cq_candidate_rd),
        .cq_publish_valid          (rx_cq_publish_valid),
        .cq_publish_success        (rx_cq_publish_success),
        .queue_fault               (manager_queue_fault),
        .sqe_read_error_event      (sqe_read_error_event),
        .sqe_writeback_error_event (sqe_writeback_error_event),
        .sqe_invalid_event         (sqe_invalid_event)
    );

    mctp_decoder decoder_i (
        .clk                  (clk),
        .rst_n                (rst_n),
        .s_awvalid            (s_awvalid),
        .s_awready            (s_awready),
        .s_awmeta             (s_awmeta),
        .response_credit      (response_credit),
        .response_token       (response_token),
        .s_awlen              (s_awlen),
        .s_awsize             (s_awsize),
        .s_awburst            (s_awburst),
        .s_scope              (s_scope),
        .s_seid               (s_seid),
        .s_to                 (s_to),
        .s_tag                (s_tag),
        .s_som                (s_som),
        .s_eom                (s_eom),
        .s_seq                (s_seq),
        .s_wvalid             (s_wvalid),
        .s_wready             (s_wready),
        .s_wdata              (s_wdata),
        .s_wstrb              (s_wstrb),
        .s_wlast              (s_wlast),
        .filter_enable        (filter_enable_i),
        .rule_enable          (rule_enable_i),
        .rule_drop            (rule_drop_i),
        .rule_value           (rule_value_i),
        .rule_mask            (rule_mask_i),
        .default_drop         (default_drop_i),
        .som_key              (som_key),
        .som_candidate_valid  (som_candidate_valid),
        .som_conflict         (som_conflict),
        .som_slot             (som_slot),
        .som_sqe              (som_sqe),
        .som_bind             (som_bind),
        .lookup_key           (lookup_key),
        .lookup_valid         (lookup_valid),
        .lookup_slot          (lookup_slot),
        .lookup_sqe           (lookup_sqe),
        .lookup_seq_valid     (lookup_seq_valid),
        .lookup_next_seq      (lookup_next_seq),
        .lookup_timeout       (lookup_timeout_i),
        .store_bounds_ok      (store_bounds_ok),
        .congestion_drop      (congestion_drop_i),
        .current_timeout      (current_timeout),
        .m_decision_ready     (1'b1),
        .packet_valid         (packet_valid),
        .packet_ready         (packet_ready),
        .packet_release       (packet_release),
        .packet_meta          (packet_meta),
        .packet_token         (packet_token),
        .packet_slot          (packet_slot),
        .packet_seq           (packet_seq),
        .packet_eom           (packet_eom),
        .packet_som           (packet_som),
        .packet_sqe           (packet_sqe),
        .packet_wbytes        (packet_wbytes),
        .packet_beats         (packet_beats),
        .buf_free             (buffer_free),
        .buf_reserve          (buf_reserve),
        .buf_write            (buf_write),
        .buf_wr_addr          (buf_wr_addr),
        .buf_wr_data          (buf_wr_data),
        .buf_wr_strb          (buf_wr_strb),
        .buf_finish           (buf_finish),
        .buf_finish_good      (buf_finish_good),
        .buf_packet_valid     (buf_packet_valid),
        .buf_packet_ready     (buf_packet_ready),
        .buf_packet_release   (buf_packet_release),
        .drop_done_valid      (drop_done_valid),
        .drop_done_ready      (1'b1),
        .drop_done_meta       (drop_done_meta),
        .drop_done_token      (drop_done_token),
        .drop_done_reason     (drop_done_reason),
        .drop_done_slot_valid (drop_done_slot_valid),
        .drop_done_was_store  (drop_done_was_store),
        .drop_done_slot       (drop_done_slot),
        .drop_event_valid     (drop_event_valid),
        .drop_event_reason    (drop_event_reason),
        .abort_event_valid    (abort_event_valid),
        .abort_event_slot     (abort_event_slot),
        .abort_event_reason   (abort_event_reason)
    );

    inbound_packet_buffer buffer_i (
        .clk                  (clk),
        .rst_n                (rst_n),
        .free                 (buffer_free),
        .reserve              (buf_reserve),
        .write_en             (buf_write),
        .write_addr           (buf_wr_addr),
        .write_data           (buf_wr_data),
        .write_strb           (buf_wr_strb),
        .finish               (buf_finish),
        .finish_good          (buf_finish_good),
        .packet_valid         (buf_packet_valid),
        .packet_ready         (buf_packet_ready),
        .packet_release       (buf_packet_release),
        .read_addr            (buf_rd_addr),
        .read_data            (buf_rd_data),
        .read_strb            (buf_rd_strb)
    );

    inbound_router router_i (
        .clk                  (clk),
        .rst_n                (rst_n),
        .packet_valid         (packet_valid),
        .packet_ready         (packet_ready),
        .packet_release       (packet_release),
        .packet_meta          (packet_meta),
        .packet_token         (packet_token),
        .packet_slot          (packet_slot),
        .packet_som           (packet_som),
        .packet_eom           (packet_eom),
        .packet_seq           (packet_seq),
        .packet_wbytes        (packet_wbytes),
        .packet_beats         (packet_beats),
        .packet_sqe           (packet_sqe),
        .buf_rd_addr          (buf_rd_addr),
        .buf_rd_data          (buf_rd_data),
        .buf_rd_strb          (buf_rd_strb),
        .packet_commit_valid  (packet_commit_valid),
        .packet_commit_ready  (packet_commit_ready),
        .packet_commit_slot   (packet_commit_slot),
        .packet_commit_bytes  (packet_commit_bytes),
        .packet_commit_seq    (packet_commit_seq),
        .packet_commit_eom    (packet_commit_eom),
        .result_valid         (route_result_valid),
        .result_ready         (1'b1),
        .result_meta          (route_result_meta),
        .result_token         (route_result_token),
        .result_slot          (route_result_slot),
        .result_som           (route_result_som),
        .result_eom           (route_result_eom),
        .result_bytes         (route_result_bytes),
        .result_error         (route_result_error),
        .result_reason        (route_result_reason),
        .result_bresp         (route_result_bresp),
        .m_axi_awvalid        (router_awvalid),
        .m_axi_awready        (router_awready),
        .m_axi_awaddr         (router_awaddr),
        .m_axi_awlen          (router_awlen),
        .m_axi_awsize         (router_awsize),
        .m_axi_awburst        (router_awburst),
        .m_axi_wvalid         (router_wvalid),
        .m_axi_wready         (router_wready),
        .m_axi_wdata          (router_wdata),
        .m_axi_wstrb          (router_wstrb),
        .m_axi_wlast          (router_wlast),
        .m_axi_bvalid         (router_bvalid),
        .m_axi_bready         (router_bready),
        .m_axi_bresp          (router_bresp),
        .m_axi_bid            (router_bid)
    );

    inbound_response_tracker response_i (
        .clk         (clk),
        .rst_n       (rst_n),
        .alloc_valid (controller_aw_fire),
        .alloc_ready (response_credit),
        .alloc_token (response_token),
        .alloc_id    (s_awid),
        .route_valid (route_result_valid),
        .route_token (route_result_token),
        .route_resp  (route_result_bresp),
        .drop_valid  (drop_done_valid),
        .drop_token  (drop_done_token),
        .s_bvalid    (s_bvalid),
        .s_bready    (s_bready),
        .s_bid       (s_bid),
        .s_bresp     (s_bresp)
    );

    inbound_message_completion completion_i (
        .clk                 (clk),
        .rst_n               (rst_n),
        .store_valid         (buf_reserve),
        .store_slot          (s_som ? som_slot : lookup_slot),
        .store_som           (s_som),
        .route_valid         (route_result_valid),
        .route_slot          (route_result_slot),
        .route_som           (route_result_som),
        .route_eom           (route_result_eom),
        .route_bytes         (route_result_bytes),
        .route_error         (route_result_error),
        .route_reason        (route_result_reason),
        .abort_valid         (abort_event_valid),
        .abort_slot          (abort_event_slot),
        .abort_reason        (abort_event_reason),
        .timeout_valid       (gap_timeout_valid),
        .timeout_slot        (gap_timeout_slot),
        .drop_valid          (drop_done_valid),
        .drop_slot_valid     (drop_done_slot_valid),
        .drop_slot           (drop_done_slot),
        .drop_was_store      (drop_done_was_store),
        .message_done_valid  (message_done_valid),
        .message_done_ready  (message_done_ready),
        .message_done_slot   (message_done_slot),
        .message_done_update (message_done_update),
        .message_done_status (message_done_status),
        .message_done_abort  (message_done_abort)
    );

    inbound_gap_timeout gap_timeout_i (
        .clk            (clk),
        .rst_n          (rst_n),
        .timeout_cycles (message_timeout_i),
        .store_valid    (buf_reserve),
        .store_slot     (s_som ? som_slot : lookup_slot),
        .route_valid    (route_result_valid),
        .route_slot     (route_result_slot),
        .route_eom      (route_result_eom),
        .route_error    (route_result_error),
        .abort_valid    (abort_event_valid),
        .abort_slot     (abort_event_slot),
        .done_valid     (message_done_valid && message_done_ready),
        .done_slot      (message_done_slot),
        .timeout_valid  (gap_timeout_valid),
        .timeout_slot   (gap_timeout_slot),
        .expired        (gap_expired)
    );

    outbound_sq_prefetch tx_prefetch_i (
        .clk                 (clk),
        .rst_n               (rst_n),
        .sq_base_addr        (tx_sq_base_i),
        .sq_tail_ptr         (tx_sq_tail_i),
        .prefetch_req_valid  (tx_pf_req_valid),
        .prefetch_sq_num     (tx_pf_sq_num),
        .prefetch_req_ready  (tx_pf_req_ready),
        .prefetch_accept_num (tx_pf_accept_num),
        .fetch_ptr           (tx_pf_fetch_ptr),
        .m_axi_arvalid       (tx_pf_arvalid),
        .m_axi_arready       (tx_pf_arready),
        .m_axi_araddr        (tx_pf_araddr),
        .m_axi_arlen         (tx_pf_arlen),
        .m_axi_arsize        (tx_pf_arsize),
        .m_axi_arburst       (tx_pf_arburst),
        .m_axi_rvalid        (tx_pf_rvalid),
        .m_axi_rready        (tx_pf_rready),
        .m_axi_rdata         (tx_pf_rdata),
        .m_axi_rresp         (tx_pf_rresp),
        .m_axi_rlast         (tx_pf_rlast),
        .m_axi_rid           (tx_pf_rid),
        .sq_pop              (tx_pf_sq_pop),
        .sq_count            (tx_pf_sq_count),
        .sq_valid            (tx_pf_sq_valid),
        .sq_dout             (tx_pf_sq_dout),
        .sq_ptr              (tx_pf_sq_ptr),
        .sq_error            (tx_pf_sq_error),
        .fault               (tx_pf_fault)
    );

    outbound_sq_manager tx_manager_i (
        .clk                  (clk),
        .rst_n                (rst_n),
        .enable               (tx_enable_i),
        .sq_count             (tx_pf_sq_count),
        .sq_valid             (tx_pf_sq_valid),
        .sq_dout              (tx_pf_sq_dout),
        .sq_ptr               (tx_pf_sq_ptr),
        .sq_error             (tx_pf_sq_error),
        .sq_pop               (tx_pf_sq_pop),
        .prefetch_fault       (tx_pf_fault),
        .prefetch_req_valid   (tx_pf_req_valid),
        .prefetch_sq_num      (tx_pf_sq_num),
        .gen_desc_valid       (tx_gen_desc_valid),
        .gen_desc_ready       (tx_gen_desc_ready),
        .gen_desc_sqe         (tx_gen_desc_sqe),
        .gen_done_valid       (tx_gen_done_valid),
        .gen_done_status      (tx_gen_done_status),
        .gen_done_ready       (tx_gen_done_ready),
        .gen_publish_valid    (tx_gen_publish_valid),
        .gen_publish_success  (tx_gen_publish_success),
        .cq_req_valid         (tx_cq_req_valid),
        .cq_req_ready         (tx_cq_req_ready),
        .cq_req_cid           (tx_cq_req_cid),
        .cq_req_sq_ptr        (tx_cq_req_sq_ptr),
        .cq_req_status        (tx_cq_req_status),
        .cq_req_candidate_rd  (tx_cq_req_candidate_rd),
        .cq_publish_valid     (tx_cq_publish_valid),
        .cq_publish_success   (tx_cq_publish_success),
        .sq_rd_ptr            (tx_sq_rd_ptr),
        .queue_fault          (tx_queue_fault),
        .sqe_read_error_event (tx_sqe_read_error_event),
        .sqe_invalid_event    (tx_sqe_invalid_event)
    );

    outbound_payload_reader tx_reader_i (
        .clk            (clk),
        .rst_n          (rst_n),
        .start_valid    (tx_reader_start_valid),
        .start_ready    (tx_reader_start_ready),
        .start_addr     (tx_reader_start_addr),
        .start_len      (tx_reader_start_len),
        .packet_valid   (tx_reader_packet_valid),
        .packet_error   (tx_reader_packet_error),
        .packet_len     (tx_reader_packet_len),
        .packet_release (tx_reader_release),
        .read_index     (tx_reader_index),
        .read_data      (tx_reader_data),
        .m_axi_arvalid  (tx_rd_arvalid),
        .m_axi_arready  (tx_rd_arready),
        .m_axi_araddr   (tx_rd_araddr),
        .m_axi_arlen    (tx_rd_arlen),
        .m_axi_arsize   (tx_rd_arsize),
        .m_axi_arburst  (tx_rd_arburst),
        .m_axi_rvalid   (tx_rd_rvalid),
        .m_axi_rready   (tx_rd_rready),
        .m_axi_rdata    (tx_rd_rdata),
        .m_axi_rresp    (tx_rd_rresp),
        .m_axi_rlast    (tx_rd_rlast),
        .m_axi_rid      (tx_rd_rid)
    );

    outbound_packet_gen tx_generator_i (
        .clk                 (clk),
        .rst_n               (rst_n),
        .desc_valid          (tx_gen_desc_valid),
        .desc_ready          (tx_gen_desc_ready),
        .desc_sqe            (tx_gen_desc_sqe),
        .tuz_bytes           (tx_tuz_i),
        .target_addr         (tx_target_i),
        .start_seq           (tx_start_seq_i),
        .reader_start_valid  (tx_reader_start_valid),
        .reader_start_ready  (tx_reader_start_ready),
        .reader_start_addr   (tx_reader_start_addr),
        .reader_start_len    (tx_reader_start_len),
        .reader_packet_valid (tx_reader_packet_valid),
        .reader_packet_error (tx_reader_packet_error),
        .reader_release      (tx_reader_release),
        .reader_index        (tx_reader_index),
        .reader_data         (tx_reader_data),
        .tx_awvalid          (tx_awvalid),
        .tx_awready          (tx_awready),
        .tx_awaddr           (tx_awaddr),
        .tx_awlen            (tx_awlen),
        .tx_awsize           (tx_awsize),
        .tx_awburst          (tx_awburst),
        .tx_awid             (tx_awid),
        .tx_awmeta           (tx_awmeta),
        .tx_packet_bytes     (tx_packet_bytes),
        .tx_som              (tx_som),
        .tx_eom              (tx_eom),
        .tx_seq              (tx_seq),
        .tx_pad_len          (tx_pad_len),
        .tx_wvalid           (tx_wvalid),
        .tx_wready           (tx_wready),
        .tx_wdata            (tx_wdata),
        .tx_wstrb            (tx_wstrb),
        .tx_wlast            (tx_wlast),
        .tx_bvalid           (tx_bvalid),
        .tx_bready           (tx_bready),
        .tx_bresp            (tx_bresp),
        .tx_bid              (tx_bid),
        .done_valid          (tx_gen_done_valid),
        .done_ready          (tx_gen_done_ready),
        .done_status         (tx_gen_done_status),
        .publish_valid       (tx_gen_publish_valid),
        .publish_success     (tx_gen_publish_success)
    );

    shared_cq_manager cq_i (
        .clk                  (clk),
        .rst_n                (rst_n),
        .cq_base_addr         (cq_base_i),
        .cq_head              (cq_head_i),
        .cq_tail              (cq_tail),
        .rx_req_valid         (rx_cq_req_valid),
        .rx_req_ready         (rx_cq_req_ready),
        .rx_req_slot          (rx_cq_req_slot),
        .rx_req_cid           (rx_cq_req_cid),
        .rx_req_sq_ptr        (rx_cq_req_sq_ptr),
        .rx_req_status        (rx_cq_req_status),
        .rx_req_candidate_rd  (rx_cq_candidate_rd),
        .rx_publish_valid     (rx_cq_publish_valid),
        .rx_publish_success   (rx_cq_publish_success),
        .tx_req_valid         (tx_cq_req_valid),
        .tx_req_ready         (tx_cq_req_ready),
        .tx_req_cid           (tx_cq_req_cid),
        .tx_req_sq_ptr        (tx_cq_req_sq_ptr),
        .tx_req_status        (tx_cq_req_status),
        .tx_req_candidate_rd  (tx_cq_req_candidate_rd),
        .tx_publish_valid     (tx_cq_publish_valid),
        .tx_publish_success   (tx_cq_publish_success),
        .completion_event     (cq_completion_event),
        .fault                (cq_fault),
        .m_axi_awvalid        (cq_awvalid),
        .m_axi_awready        (cq_awready),
        .m_axi_awaddr         (cq_awaddr),
        .m_axi_awlen          (cq_awlen),
        .m_axi_awsize         (cq_awsize),
        .m_axi_awburst        (cq_awburst),
        .m_axi_wvalid         (cq_wvalid),
        .m_axi_wready         (cq_wready),
        .m_axi_wdata          (cq_wdata),
        .m_axi_wstrb          (cq_wstrb),
        .m_axi_wlast          (cq_wlast),
        .m_axi_bvalid         (cq_bvalid),
        .m_axi_bready         (cq_bready),
        .m_axi_bresp          (cq_bresp),
        .m_axi_bid            (cq_bid)
    );

    wire other_rx_error = drop_event_valid && drop_event_reason != 4'd1 &&
                          drop_event_reason != 4'd2 && drop_event_reason != 4'd3;
    reg cq_fault_prev, manager_fault_prev, tx_fault_prev;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            cq_fault_prev <= 1'b0;
            manager_fault_prev <= 1'b0;
            tx_fault_prev <= 1'b0;
        end else begin
            cq_fault_prev <= cq_fault;
            manager_fault_prev <= manager_queue_fault;
            tx_fault_prev <= tx_queue_fault;
        end
    end
    wire [7:0] irq_events = {
        cq_completion_event,
        other_rx_error || (route_result_valid && route_result_error) ||
            sqe_invalid_event || gap_timeout_valid ||
            (manager_queue_fault && !manager_fault_prev) ||
            (tx_queue_fault && !tx_fault_prev) || tx_sqe_invalid_event ||
            (tx_gen_done_valid && tx_gen_done_ready && tx_gen_done_status != 0),
        (rx_cq_publish_valid && !rx_cq_publish_success) ||
            (tx_cq_publish_valid && !tx_cq_publish_success) ||
            (cq_fault && !cq_fault_prev),
        sqe_writeback_error_event,
        sqe_read_error_event || tx_sqe_read_error_event,
        drop_event_valid && drop_event_reason == 4'd2,
        drop_event_valid && drop_event_reason == 4'd1,
        drop_event_valid && drop_event_reason == 4'd3
    };
    inbound_irq_status irq_i (
        .clk       (clk),
        .rst_n     (rst_n),
        .event_set (irq_events),
        .clear     (irq_clear_i),
        .mask      (irq_mask_i),
        .status    (irq_status),
        .irq       (irq_level)
    );

    axi_rd3t1_bridge #(
        .ADDR_WIDTH (64),
        .DATA_WIDTH (512),
        .ID_WIDTH   (4)
    ) read_bridge_i (
        .clk         (clk),
        .rst_n       (rst_n),
        .s_arid      (12'd0),
        .s_araddr    ({tx_rd_araddr, tx_pf_araddr, pf_araddr}),
        .s_arlen     ({tx_rd_arlen, tx_pf_arlen, pf_arlen}),
        .s_arsize    ({tx_rd_arsize, tx_pf_arsize, pf_arsize}),
        .s_arburst   ({tx_rd_arburst, tx_pf_arburst, 2'b01}),
        .s_arlock    (3'd0),
        .s_arcache   ({3{4'b0010}}),
        .s_arprot    ({3{3'b010}}),
        .s_arqos     (12'd0),
        .s_arregion  (12'd0),
        .s_arvalid   ({tx_rd_arvalid, tx_pf_arvalid, pf_arvalid}),
        .s_arready   (rd_arready),
        .s_rid       (rd_rid),
        .s_rdata     (rd_rdata),
        .s_rresp     (rd_rresp),
        .s_rlast     (rd_rlast),
        .s_rvalid    (rd_rvalid),
        .s_rready    ({tx_rd_rready, tx_pf_rready, pf_rready}),
        .m_arid      (m_axi_arid),
        .m_araddr    (m_axi_araddr),
        .m_arlen     (m_axi_arlen),
        .m_arsize    (m_axi_arsize),
        .m_arburst   (m_axi_arburst),
        .m_arlock    (m_axi_arlock),
        .m_arcache   (m_axi_arcache),
        .m_arprot    (m_axi_arprot),
        .m_arqos     (m_axi_arqos),
        .m_arregion  (m_axi_arregion),
        .m_arvalid   (m_axi_arvalid),
        .m_arready   (m_axi_arready),
        .m_rid       (m_axi_rid),
        .m_rdata     (m_axi_rdata),
        .m_rresp     (m_axi_rresp),
        .m_rlast     (m_axi_rlast),
        .m_rvalid    (m_axi_rvalid),
        .m_rready    (m_axi_rready)
    );
    assign pf_arready = rd_arready[0];
    assign pf_rvalid = rd_rvalid[0];
    assign pf_rlast = rd_rlast[0];
    assign pf_rdata = rd_rdata[511:0];
    assign pf_rresp = rd_rresp[1:0];
    assign pf_rid = rd_rid[3:0];
    assign tx_pf_arready = rd_arready[1];
    assign tx_pf_rvalid = rd_rvalid[1];
    assign tx_pf_rlast = rd_rlast[1];
    assign tx_pf_rdata = rd_rdata[1023:512];
    assign tx_pf_rresp = rd_rresp[3:2];
    assign tx_pf_rid = rd_rid[7:4];
    assign tx_rd_arready = rd_arready[2];
    assign tx_rd_rvalid = rd_rvalid[2];
    assign tx_rd_rlast = rd_rlast[2];
    assign tx_rd_rdata = rd_rdata[1535:1024];
    assign tx_rd_rresp = rd_rresp[5:4];
    assign tx_rd_rid = rd_rid[11:8];

    axi_wr3t1_bridge #(
        .ADDR_WIDTH (64),
        .DATA_WIDTH (512),
        .ID_WIDTH   (4)
    ) write_bridge_i (
        .clk         (clk),
        .rst_n       (rst_n),
        .s_awid      (12'd0),
        .s_awaddr    ({cq_awaddr, sq_awaddr, router_awaddr}),
        .s_awlen     ({cq_awlen, sq_awlen, router_awlen}),
        .s_awsize    ({cq_awsize, sq_awsize, router_awsize}),
        .s_awburst   ({cq_awburst, sq_awburst, router_awburst}),
        .s_awlock    (3'd0),
        .s_awcache   ({3{4'b0010}}),
        .s_awprot    ({3{3'b010}}),
        .s_awqos     (12'd0),
        .s_awregion  (12'd0),
        .s_awvalid   ({cq_awvalid, sq_awvalid, router_awvalid}),
        .s_awready   (wr_awready),
        .s_wdata     ({cq_wdata, sq_wdata, router_wdata}),
        .s_wstrb     ({cq_wstrb, sq_wstrb, router_wstrb}),
        .s_wlast     ({cq_wlast, sq_wlast, router_wlast}),
        .s_wvalid    ({cq_wvalid, sq_wvalid, router_wvalid}),
        .s_wready    (wr_wready),
        .s_bid       (wr_bid),
        .s_bresp     (wr_bresp),
        .s_bvalid    (wr_bvalid),
        .s_bready    ({cq_bready, sq_bready, router_bready}),
        .m_awid      (m_axi_awid),
        .m_awaddr    (m_axi_awaddr),
        .m_awlen     (m_axi_awlen),
        .m_awsize    (m_axi_awsize),
        .m_awburst   (m_axi_awburst),
        .m_awlock    (m_axi_awlock),
        .m_awcache   (m_axi_awcache),
        .m_awprot    (m_axi_awprot),
        .m_awqos     (m_axi_awqos),
        .m_awregion  (m_axi_awregion),
        .m_awvalid   (m_axi_awvalid),
        .m_awready   (m_axi_awready),
        .m_wdata     (m_axi_wdata),
        .m_wstrb     (m_axi_wstrb),
        .m_wlast     (m_axi_wlast),
        .m_wvalid    (m_axi_wvalid),
        .m_wready    (m_axi_wready),
        .m_bid       (m_axi_bid),
        .m_bresp     (m_axi_bresp),
        .m_bvalid    (m_axi_bvalid),
        .m_bready    (m_axi_bready)
    );
    assign router_awready = wr_awready[0];
    assign router_wready = wr_wready[0];
    assign router_bvalid = wr_bvalid[0];
    assign router_bid = wr_bid[3:0];
    assign router_bresp = wr_bresp[1:0];
    assign sq_awready = wr_awready[1];
    assign sq_wready = wr_wready[1];
    assign sq_bvalid = wr_bvalid[1];
    assign sq_bid = wr_bid[7:4];
    assign sq_bresp = wr_bresp[3:2];
    assign cq_awready = wr_awready[2];
    assign cq_wready = wr_wready[2];
    assign cq_bvalid = wr_bvalid[2];
    assign cq_bid = wr_bid[11:8];
    assign cq_bresp = wr_bresp[5:4];
endmodule
