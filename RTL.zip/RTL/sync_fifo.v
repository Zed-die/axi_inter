`timescale 1ns/1ps

// Same-clock, first-word-fall-through FIFO. DOUT is the current head whenever
// EMPTY is low; RD_EN removes that head at the next rising clock edge.
module sync_fifo #(
    parameter integer DATA_WIDTH = 256,
    parameter integer ADDR_WIDTH = 3
) (
    input  wire                       clk,
    input  wire                       rst_n,
    input  wire                       wr_en,
    input  wire [DATA_WIDTH-1:0]      din,
    input  wire                       rd_en,
    output wire [DATA_WIDTH-1:0]      dout,
    output wire                       full,
    output wire                       empty,
    output wire [ADDR_WIDTH:0]        data_count
);
    localparam integer DEPTH = 1 << ADDR_WIDTH;
    reg [DATA_WIDTH-1:0] mem [0:DEPTH-1];
    reg [ADDR_WIDTH-1:0] wr_ptr;
    reg [ADDR_WIDTH-1:0] rd_ptr;
    reg [ADDR_WIDTH:0] count;
    wire rd_fire = rd_en && !empty;
    wire wr_fire = wr_en && (!full || rd_fire);

    assign full = count == DEPTH;
    assign empty = count == 0;
    assign data_count = count;
    assign dout = empty ? {DATA_WIDTH{1'b0}} : mem[rd_ptr];

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            wr_ptr <= {ADDR_WIDTH{1'b0}};
            rd_ptr <= {ADDR_WIDTH{1'b0}};
            count <= {(ADDR_WIDTH+1){1'b0}};
        end else begin
            if (wr_fire) begin
                mem[wr_ptr] <= din;
                wr_ptr <= wr_ptr + 1'b1;
            end
            if (rd_fire) rd_ptr <= rd_ptr + 1'b1;
            case ({wr_fire, rd_fire})
                2'b10: count <= count + 1'b1;
                2'b01: count <= count - 1'b1;
                default: count <= count;
            endcase
        end
    end
endmodule
