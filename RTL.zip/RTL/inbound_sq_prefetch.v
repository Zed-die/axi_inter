`timescale 1ns/1ps

// RX SQ prefetcher: APB-selected power-of-two ring depth from 2 to 256.
// One slot is reserved; low log2(depth)+1 pointer bits encode index and phase.
// The 16-bit fetch sequence also identifies each returned SQE to the manager.
module inbound_sq_prefetch #(
    parameter integer   ADDR_WIDTH    = 64,
    parameter integer   ID_WIDTH      = 4,
    parameter [3:0]     ARCACHE_VALUE = 4'b0010,
    parameter [2:0]     ARPROT_VALUE  = 3'b010
) (
    input  wire                      clk,
    input  wire                      rst_n,
    input  wire [ADDR_WIDTH-1:0]     inbound_sq_base_addr,
    input  wire [8:0]                inbound_sq_depth,
    input  wire [15:0]               inbound_tail_ptr,
    input  wire                      prefetch_req_valid,
    input  wire [4:0]                prefetch_sq_num,
    output wire                      prefetch_req_ready,
    output reg  [4:0]                prefetch_accept_num,
    output reg  [15:0]               inbound_fetch_ptr,

    output wire                      m_axi_arvalid,
    input  wire                      m_axi_arready,
    output reg  [ADDR_WIDTH-1:0]     m_axi_araddr,
    output reg  [7:0]                m_axi_arlen,
    output reg  [2:0]                m_axi_arsize,
    output wire [1:0]                m_axi_arburst,
    output wire [ID_WIDTH-1:0]       m_axi_arid,
    output wire                      m_axi_arlock,
    output wire [3:0]                m_axi_arcache,
    output wire [2:0]                m_axi_arprot,
    output wire [3:0]                m_axi_arqos,
    output wire [3:0]                m_axi_arregion,
    input  wire                      m_axi_rvalid,
    output wire                      m_axi_rready,
    input  wire [511:0]              m_axi_rdata,
    input  wire [1:0]                m_axi_rresp,
    input  wire                      m_axi_rlast,
    input  wire [ID_WIDTH-1:0]       m_axi_rid,

    input  wire                      sq_rd_en,
    output wire [3:0]                sq_count,
    output wire                      sq_empty,
    output wire [255:0]              sq_dout,
    output wire [15:0]               sq_ptr,
    output wire                      sq_error,
    output reg                       fault
);
    localparam [2:0] IDLE = 3'd0, 
                     PLAN = 3'd1, 
                     ISSUE_AR = 3'd2,
                     RECEIVE_R = 3'd3, 
                     EMIT = 3'd4, 
                     FAULT = 3'd5;
    
    reg [2:0] state;

    reg [ADDR_WIDTH-1:0] base_q;
    reg [15:0] issue_ptr;
    reg [15:0] read_ptr;
    reg [4:0] batch_left;
    reg [4:0] burst_entries;
    reg [7:0] beats_left;

    reg [511:0] beat_data;
    reg [15:0] beat_ptr;
    reg [2:0] beat_size;
    reg beat_error;
    reg beat_last;
    reg beat_protocol_error;
    reg [1:0] emit_left;

    wire [272:0] fifo_dout;
    wire [3:0] fifo_count;
    wire fifo_full;
    wire fifo_pop = sq_rd_en && !sq_empty;
    wire fifo_push = (state == EMIT) && (emit_left != 0) &&
                     (!fifo_full || fifo_pop);
    wire [15:0] emit_ptr = beat_ptr + ((beat_size == 3'd6 && emit_left == 1) ? 16'd1 : 16'd0);
    wire [255:0] emit_data = (beat_size == 3'd6) ?
        ((emit_left == 2) ? beat_data[255:0] : beat_data[511:256]) :
        (beat_ptr[0] ? beat_data[511:256] : beat_data[255:0]);

    assign sq_count = fifo_count;
    assign sq_dout = fifo_dout[255:0];
    assign sq_ptr = fifo_dout[271:256];
    assign sq_error = fifo_dout[272];

    sync_fifo #(
        .DATA_WIDTH (273),
        .ADDR_WIDTH (3  )
    ) result_fifo_i (
        .clk        (clk        ),
        .rst_n      (rst_n      ),
        .wr_en      (fifo_push  ),
        .din        ({beat_error, emit_ptr, emit_data}),
        .rd_en      (sq_rd_en   ),
        .dout       (fifo_dout  ),
        .full       (fifo_full  ),
        .empty      (sq_empty   ),
        .data_count (fifo_count )
    );

    // Power-of-two depth: low log2(depth)+1 bits encode index and wrap phase.
    wire depth_valid = inbound_sq_depth >= 9'd2 && inbound_sq_depth <= 9'd256 &&
                       (inbound_sq_depth & (inbound_sq_depth - 9'd1)) == 0;
    wire [8:0] ring_mask = ({inbound_sq_depth, 1'b0} - 10'd1);
    wire [7:0] index_mask = inbound_sq_depth[7:0] - 8'd1;
    wire [8:0] available = ((inbound_tail_ptr[8:0] & ring_mask) -
                            (inbound_fetch_ptr[8:0] & ring_mask)) & ring_mask;
    wire [4:0] free_entries = 5'd8 - {1'b0, fifo_count};
    wire valid_window = (available != 0 && available < inbound_sq_depth);
    wire valid_base = (inbound_sq_base_addr[5:0] == 6'd0);
    assign prefetch_req_ready = (state == IDLE) && !fault && depth_valid &&
                                valid_window && valid_base &&
                                (prefetch_sq_num != 0) && (free_entries != 0);
    always @* begin
        prefetch_accept_num = prefetch_sq_num;
        if (prefetch_accept_num > 5'd8) prefetch_accept_num = 5'd8;
        if (prefetch_accept_num > free_entries) prefetch_accept_num = free_entries;
        if ({4'd0, prefetch_accept_num} > available) prefetch_accept_num = available[4:0];
        if (!prefetch_req_ready) prefetch_accept_num = 0;
    end
    wire request_fire = prefetch_req_valid && prefetch_req_ready;

    assign m_axi_arvalid = (state == ISSUE_AR);
    assign m_axi_arburst = 2'b01; // INCR, never WRAP at the SQ ring boundary.
    assign m_axi_arid = {ID_WIDTH{1'b0}};
    assign m_axi_arlock = 1'b0;
    assign m_axi_arcache = ARCACHE_VALUE;
    assign m_axi_arprot = ARPROT_VALUE;
    assign m_axi_arqos = 4'b0000;
    assign m_axi_arregion = 4'b0000;
    assign m_axi_rready = (state == RECEIVE_R) || (state == FAULT);

    // Use 64-byte beats for SQE pairs and one 32-byte beat for an odd/lone SQE.
    // No uncommitted SQE is read solely to fill the bus width.
    reg [ADDR_WIDTH-1:0] next_addr;
    reg [4:0] next_entries;
    reg [7:0] next_beats;
    reg [2:0] next_size;
    reg [8:0] ring_entries;
    reg [12:0] page_bytes;
    reg [4:0] pairs;
    wire [7:0] issue_index = issue_ptr[7:0] & index_mask;
    always @* begin
        next_addr = base_q + ({ {(ADDR_WIDTH-8){1'b0}}, issue_index} << 5);
        ring_entries = inbound_sq_depth - {1'b0, issue_index};
        page_bytes = 13'd4096 - {1'b0, next_addr[11:0]};
        pairs = batch_left >> 1;
        if (pairs > (ring_entries >> 1)) pairs = ring_entries >> 1;
        if (pairs > (page_bytes >> 6)) pairs = page_bytes >> 6;
        if (!issue_ptr[0] && pairs != 0) begin
            next_size = 3'd6;
            next_beats = {3'd0, pairs};
            next_entries = pairs << 1;
        end else begin
            next_size = 3'd5;
            next_beats = 8'd1;
            next_entries = 5'd1;
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= IDLE;
            fault <= 1'b0;
            inbound_fetch_ptr <= 16'd0;
            base_q <= {ADDR_WIDTH{1'b0}};
            issue_ptr <= 16'd0;
            read_ptr <= 16'd0;
            batch_left <= 5'd0;
            burst_entries <= 5'd0;
            beats_left <= 8'd0;
            m_axi_araddr <= {ADDR_WIDTH{1'b0}};
            m_axi_arlen <= 8'd0;
            m_axi_arsize <= 3'd0;
            beat_data <= 512'd0;
            beat_ptr <= 16'd0;
            beat_size <= 3'd0;
            beat_error <= 1'b0;
            beat_last <= 1'b0;
            beat_protocol_error <= 1'b0;
            emit_left <= 2'd0;
        end else begin
            case (state)
                IDLE: begin
                    if (prefetch_req_valid && (!depth_valid || !valid_base ||
                        available >= inbound_sq_depth)) begin
                        fault <= 1'b1;
                        state <= FAULT;
                    end else if (request_fire) begin
                        base_q <= inbound_sq_base_addr;
                        issue_ptr <= inbound_fetch_ptr;
                        inbound_fetch_ptr <= inbound_fetch_ptr + prefetch_accept_num;
                        batch_left <= prefetch_accept_num;
                        state <= PLAN;
                    end
                end
                PLAN: begin
                    m_axi_araddr <= next_addr;
                    m_axi_arlen <= next_beats - 8'd1;
                    m_axi_arsize <= next_size;
                    burst_entries <= next_entries;
                    state <= ISSUE_AR;
                end
                ISSUE_AR: if (m_axi_arready) begin
                    issue_ptr <= issue_ptr + burst_entries;
                    read_ptr <= issue_ptr;
                    batch_left <= batch_left - burst_entries;
                    beats_left <= m_axi_arlen + 8'd1;
                    state <= RECEIVE_R;
                end
                RECEIVE_R: if (m_axi_rvalid) begin
                    beat_data <= m_axi_rdata;
                    beat_ptr <= read_ptr;
                    beat_size <= m_axi_arsize;
                    beat_error <= (m_axi_rresp != 2'b00) || (m_axi_rlast != (beats_left == 8'd1)) ||
                                  (m_axi_rid != {ID_WIDTH{1'b0}});
                    beat_last <= m_axi_rlast;
                    beat_protocol_error <= (m_axi_rlast != (beats_left == 8'd1)) ||
                                           (m_axi_rid != {ID_WIDTH{1'b0}});
                    emit_left <= (m_axi_arsize == 3'd6) ? 2'd2 : 2'd1;
                    read_ptr <= read_ptr + ((m_axi_arsize == 3'd6) ? 16'd2 : 16'd1);
                    beats_left <= beats_left - 8'd1;
                    state <= EMIT;
                end
                EMIT: if (fifo_push) begin
                    emit_left <= emit_left - 2'd1;
                    if (emit_left == 2'd1) begin
                        if (beat_protocol_error) begin
                            fault <= 1'b1;
                            state <= FAULT;
                        end else if (beat_last) begin
                            state <= (batch_left == 0) ? IDLE : PLAN;
                        end else begin
                            state <= RECEIVE_R;
                        end
                    end
                end
                FAULT: state <= FAULT; // Queue manager must reset after a protocol/configuration fault.
                default: state <= FAULT;
            endcase
        end
    end

endmodule
