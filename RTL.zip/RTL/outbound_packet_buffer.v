`timescale 1ns/1ps

// One packed 1 KiB TX packet buffer. The reader writes valid bytes from each
// AXI R beat; the generator reads 64-byte rows from byte offset zero.
module outbound_packet_buffer (
    input  wire         clk,
    input  wire         write_en,
    input  wire [10:0]  write_base,
    input  wire [5:0]   write_lane,
    input  wire [2:0]   write_size,
    input  wire [511:0] write_data,
    input  wire [10:0]  packet_len,
    input  wire [3:0]   read_index,
    output reg  [511:0] read_data
);
    reg [7:0] bytes [0:1023];
    integer i;
    integer lane;
    integer j;
    always @(posedge clk) begin
        if (write_en) begin
            for (i = 0; i < 64; i = i + 1) begin
                if (i < (1 << write_size) && write_base + i < 1024) begin
                    lane = (write_lane + i) & 63;
                    bytes[write_base + i] <= write_data[lane*8 +: 8];
                end
            end
        end
    end
    always @* begin
        read_data = 512'd0;
        for (j = 0; j < 64; j = j + 1) begin
            if ({read_index, 6'd0} + j < packet_len)
                read_data[j*8 +: 8] = bytes[{read_index, 6'd0} + j];
        end
    end
endmodule
