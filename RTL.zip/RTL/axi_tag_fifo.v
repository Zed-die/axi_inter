`timescale 1ns/1ps

// Small, fall-through FIFO for AXI source tags. No push is accepted while
// full, even if a pop occurs in the same cycle; callers must gate requests.
module axi_tag_fifo #(
    parameter integer WIDTH = 2,
    parameter integer DEPTH = 8
) (
    input  wire             clk,
    input  wire             rst_n,
    input  wire             push_i,
    input  wire [WIDTH-1:0] push_data_i,
    input  wire             pop_i,
    output wire [WIDTH-1:0] head_data_o,
    output wire             full_o,
    output wire             empty_o
);
    function integer clog2;
        input integer value;
        integer temp;
        begin
            temp = value - 1;
            for (clog2 = 0; temp > 0; clog2 = clog2 + 1)
                temp = temp >> 1;
            if (clog2 == 0)
                clog2 = 1;
        end
    endfunction

    localparam integer PTR_WIDTH = clog2(DEPTH);
    localparam integer CNT_WIDTH = clog2(DEPTH + 1);
    reg [WIDTH-1:0] mem [0:DEPTH-1];
    reg [PTR_WIDTH-1:0] wr_ptr;
    reg [PTR_WIDTH-1:0] rd_ptr;
    reg [CNT_WIDTH-1:0] count;
    wire push_fire = push_i && !full_o;
    wire pop_fire = pop_i && !empty_o;

    assign full_o = (count == DEPTH);
    assign empty_o = (count == 0);
    assign head_data_o = empty_o ? {WIDTH{1'b0}} : mem[rd_ptr];

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            wr_ptr <= {PTR_WIDTH{1'b0}};
            rd_ptr <= {PTR_WIDTH{1'b0}};
            count <= {CNT_WIDTH{1'b0}};
        end else begin
            if (push_fire) begin
                mem[wr_ptr] <= push_data_i;
                wr_ptr <= (wr_ptr == DEPTH-1) ? {PTR_WIDTH{1'b0}} : wr_ptr + 1'b1;
            end
            if (pop_fire)
                rd_ptr <= (rd_ptr == DEPTH-1) ? {PTR_WIDTH{1'b0}} : rd_ptr + 1'b1;
            case ({push_fire, pop_fire})
                2'b10: count <= count + 1'b1;
                2'b01: count <= count - 1'b1;
                default: count <= count;
            endcase
        end
    end
endmodule
