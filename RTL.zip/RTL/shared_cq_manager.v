`timescale 1ns/1ps

// One 256-entry CQ shared by RX and TX; one physical slot is reserved.
// The last CQE byte, containing phase, is written only after body B succeeds.
module shared_cq_manager #(
    parameter integer ADDR_WIDTH = 64,
    parameter integer ID_WIDTH = 4,
    parameter [3:0] AWCACHE_VALUE = 4'b0010,
    parameter [2:0] AWPROT_VALUE = 3'b010
) (
    input  wire                  clk,
    input  wire                  rst_n,
    input  wire [ADDR_WIDTH-1:0] cq_base_addr,
    input  wire [8:0]            cq_head,
    output reg  [8:0]            cq_tail,
    input  wire                  rx_req_valid,
    output wire                  rx_req_ready,
    input  wire [2:0]            rx_req_slot,
    input  wire [15:0]           rx_req_cid,
    input  wire [15:0]           rx_req_sq_ptr,
    input  wire [7:0]            rx_req_status,
    input  wire [15:0]           rx_req_candidate_rd,
    output wire                  rx_publish_valid,
    output wire                  rx_publish_success,
    input  wire                  tx_req_valid,
    output wire                  tx_req_ready,
    input  wire [15:0]           tx_req_cid,
    input  wire [15:0]           tx_req_sq_ptr,
    input  wire [7:0]            tx_req_status,
    input  wire [15:0]           tx_req_candidate_rd,
    output wire                  tx_publish_valid,
    output wire                  tx_publish_success,
    output wire                  completion_event,
    output reg                   fault,
    output wire                  m_axi_awvalid,
    input  wire                  m_axi_awready,
    output wire [ADDR_WIDTH-1:0] m_axi_awaddr,
    output wire [7:0]            m_axi_awlen,
    output wire [2:0]            m_axi_awsize,
    output wire [1:0]            m_axi_awburst,
    output wire [ID_WIDTH-1:0]   m_axi_awid,
    output wire                  m_axi_awlock,
    output wire [3:0]            m_axi_awcache,
    output wire [2:0]            m_axi_awprot,
    output wire [3:0]            m_axi_awqos,
    output wire [3:0]            m_axi_awregion,
    output wire                  m_axi_wvalid,
    input  wire                  m_axi_wready,
    output wire [511:0]          m_axi_wdata,
    output wire [63:0]           m_axi_wstrb,
    output wire                  m_axi_wlast,
    input  wire                  m_axi_bvalid,
    output wire                  m_axi_bready,
    input  wire [1:0]            m_axi_bresp,
    input  wire [ID_WIDTH-1:0]   m_axi_bid
);
    localparam [3:0] IDLE = 4'd0, BODY_AW = 4'd1, BODY_W = 4'd2,
                     BODY_B = 4'd3, PHASE_AW = 4'd4, PHASE_W = 4'd5,
                     PHASE_B = 4'd6, PUBLISH = 4'd7, FAULT = 4'd8;
    reg [3:0] state;
    reg last_was_rx;
    reg selected_rx;
    reg publish_success;
    reg [127:0] cqe;
    reg [ADDR_WIDTH-1:0] cqe_addr;
    reg [5:0] lane_bytes;
    wire full = (cq_tail[7:0] + 8'd1) == cq_head[7:0];
    wire base_ok = cq_base_addr[5:0] == 0;
    wire choose_rx = rx_req_valid && (!tx_req_valid || !last_was_rx);
    wire choose_tx = tx_req_valid && (!rx_req_valid || last_was_rx);
    wire accept_enable = rst_n && state == IDLE && !fault && !full && base_ok;
    assign rx_req_ready = accept_enable && choose_rx;
    assign tx_req_ready = accept_enable && choose_tx;
    wire rx_fire = rx_req_valid && rx_req_ready;
    wire tx_fire = tx_req_valid && tx_req_ready;
    wire body_phase = state == BODY_AW || state == BODY_W || state == BODY_B;

    assign m_axi_awvalid = rst_n && (state == BODY_AW || state == PHASE_AW);
    assign m_axi_awaddr = cqe_addr;
    assign m_axi_awlen = 8'd0;
    assign m_axi_awsize = 3'd4;
    assign m_axi_awburst = 2'b01;
    assign m_axi_awid = {ID_WIDTH{1'b0}};
    assign m_axi_awlock = 1'b0;
    assign m_axi_awcache = AWCACHE_VALUE;
    assign m_axi_awprot = AWPROT_VALUE;
    assign m_axi_awqos = 4'd0;
    assign m_axi_awregion = 4'd0;
    assign m_axi_wvalid = rst_n && (state == BODY_W || state == PHASE_W);
    assign m_axi_wdata = {384'd0, cqe} << {lane_bytes, 3'b000};
    assign m_axi_wstrb = (body_phase ? 64'h7fff : 64'h8000) << lane_bytes;
    assign m_axi_wlast = 1'b1;
    assign m_axi_bready = rst_n && (state == BODY_B || state == PHASE_B);
    assign rx_publish_valid = rst_n && state == PUBLISH && selected_rx;
    assign rx_publish_success = publish_success;
    assign tx_publish_valid = rst_n && state == PUBLISH && !selected_rx;
    assign tx_publish_success = publish_success;
    assign completion_event = rst_n && state == PUBLISH && publish_success;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= IDLE;
            cq_tail <= 9'd0;
            fault <= 1'b0;
            last_was_rx <= 1'b0;
            selected_rx <= 1'b0;
            publish_success <= 1'b0;
            cqe <= 128'd0;
            cqe_addr <= {ADDR_WIDTH{1'b0}};
            lane_bytes <= 6'd0;
        end else begin
            case (state)
                IDLE: begin
                    if ((rx_req_valid || tx_req_valid) && !base_ok) begin
                        fault <= 1'b1;
                        state <= FAULT;
                    end else if (rx_fire || tx_fire) begin
                        selected_rx <= rx_fire;
                        last_was_rx <= rx_fire;
                        cqe <= {
                            ~cq_tail[8],
                            7'd0,
                            rx_fire ? rx_req_status : tx_req_status,
                            rx_fire ? rx_req_cid : tx_req_cid,
                            rx_fire ? 16'd0 : 16'd1,
                            rx_fire ? rx_req_candidate_rd : tx_req_candidate_rd,
                            64'd0
                        };
                        cqe_addr <= cq_base_addr +
                            {{(ADDR_WIDTH-12){1'b0}}, cq_tail[7:0], 4'd0};
                        lane_bytes <= {cq_tail[1:0], 4'd0};
                        publish_success <= 1'b0;
                        state <= BODY_AW;
                    end
                end
                BODY_AW: if (m_axi_awready) state <= BODY_W;
                BODY_W: if (m_axi_wready) state <= BODY_B;
                BODY_B: if (m_axi_bvalid) begin
                    if (m_axi_bresp == 0 && m_axi_bid == {ID_WIDTH{1'b0}})
                        state <= PHASE_AW;
                    else state <= PUBLISH;
                end
                PHASE_AW: if (m_axi_awready) state <= PHASE_W;
                PHASE_W: if (m_axi_wready) state <= PHASE_B;
                PHASE_B: if (m_axi_bvalid) begin
                    publish_success <= m_axi_bresp == 0 &&
                                       m_axi_bid == {ID_WIDTH{1'b0}};
                    state <= PUBLISH;
                end
                PUBLISH: begin
                    if (publish_success) begin
                        cq_tail <= cq_tail + 9'd1;
                        state <= IDLE;
                    end else begin
                        fault <= 1'b1;
                        state <= FAULT;
                    end
                end
                default: state <= FAULT;
            endcase
        end
    end
endmodule
