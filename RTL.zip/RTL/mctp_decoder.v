`timescale 1ns/1ps

// Inbound packet frontend. One controller AW describes one complete packet.
// An accepted AW owns the W channel until WLAST; AXI4 has no WID.
module mctp_decoder (
    input  wire                     clk,
    input  wire                     rst_n,
    input  wire                     s_axi_awvalid,
    output wire                     s_axi_awready,
    input  wire [63:0]              s_axi_awmisc_info,
    // Controller mstr_awmisc_info_hdr_34dw: header bytes 8..15 in
    // big-endian presentation. Byte 15 is bits [7:0].
    input  wire [63:0]              s_axi_aw_hdr_34dw,
    input  wire                     response_credit,
    input  wire [4:0]               response_token,
    input  wire [7:0]               s_axi_awlen,
    input  wire [2:0]               s_axi_awsize,
    input  wire [1:0]               s_axi_awburst,
    input  wire                     s_axi_wvalid,
    output wire                     s_axi_wready,
    input  wire [511:0]             s_axi_wdata,
    input  wire [63:0]              s_axi_wstrb,
    input  wire                     s_axi_wlast,
    input  wire                     filter_enable,
    input  wire [3:0]               rule_enable,
    input  wire [3:0]               rule_drop,
    input  wire [31:0]              rule_value,
    input  wire [31:0]              rule_mask,
    input  wire                     default_drop,
    output wire [19:0]              som_key,
    input  wire                     som_candidate_valid,
    input  wire                     som_conflict,
    input  wire [2:0]               som_slot,
    input  wire [255:0]             som_sqe,
    output wire                     som_bind,
    output wire [19:0]              lookup_key,
    input  wire                     lookup_valid,
    input  wire [2:0]               lookup_slot,
    input  wire [255:0]             lookup_sqe,
    input  wire                     lookup_seq_valid,
    input  wire [1:0]               lookup_next_seq,
    input  wire                     lookup_timeout,
    input  wire                     store_bounds_ok,
    input  wire                     congestion_drop,
    input  wire                     current_timeout,
    output wire                     packet_valid,
    input  wire                     packet_ready,
    input  wire                     packet_release,
    output reg  [4:0]               packet_token,
    output reg  [2:0]               packet_slot,
    output reg  [1:0]               packet_seq,
    output reg                      packet_eom,
    output reg                      packet_som,
    output reg  [255:0]             packet_sqe,
    output reg  [10:0]              packet_wbytes,
    output reg  [4:0]               packet_beats,
    input  wire                     buf_free,
    output wire                     buf_reserve,
    output wire                     buf_write,
    output wire [3:0]               buf_wr_addr,
    output wire [511:0]             buf_wr_data,
    output wire [63:0]              buf_wr_strb,
    output wire                     buf_finish,
    output wire                     buf_finish_good,
    input  wire                     buf_packet_valid,
    output wire                     buf_packet_ready,
    output wire                     buf_packet_release,
    output reg                      drop_done_valid,
    input  wire                     drop_done_ready,
    output reg  [4:0]               drop_done_token,
    output reg                      drop_done_slot_valid,
    output reg                      drop_done_was_store,
    output reg  [2:0]               drop_done_slot,
    output reg                      drop_event_valid,
    output reg  [3:0]               drop_event_reason,
    output reg                      abort_event_valid,
    output reg  [2:0]               abort_event_slot,
    output reg  [3:0]               abort_event_reason
);
    localparam [3:0] DROP_NONE = 4'd0, DROP_FILTER = 4'd1,
                     DROP_NO_ENTRY = 4'd2, DROP_ORPHAN = 4'd3,
                     DROP_SEQ = 4'd4, DROP_DUP_SOM = 4'd5,
                     DROP_TIMEOUT = 4'd6, DROP_OVERSIZE = 4'd7,
                     DROP_BOUNDS = 4'd8, DROP_MALFORMED = 4'd9,
                     DROP_CONGESTION = 4'd10;
    reg rx_active;
    reg rx_storing;
    reg [3:0] rx_reason;
    reg [7:0] rx_awlen;
    reg [8:0] rx_beat_count;
    reg [10:0] rx_wbytes;
    reg [4:0] rx_token;
    reg [2:0] rx_slot;
    reg rx_slot_valid;
    reg [1:0] rx_seq;
    reg rx_eom;
    reg rx_som;
    reg [255:0] rx_sqe;

    reg filter_drop;
    reg [3:0] aw_reason;
    reg aw_slot_valid;
    reg [2:0] aw_slot;
    reg wait_context;
    integer i;
    wire [7:0] hdr_deid = s_axi_aw_hdr_34dw[23:16];
    wire [7:0] hdr_seid = s_axi_aw_hdr_34dw[15:8];
    wire hdr_som = s_axi_aw_hdr_34dw[7];
    wire hdr_eom = s_axi_aw_hdr_34dw[6];
    wire [1:0] hdr_seq = s_axi_aw_hdr_34dw[5:4];
    wire hdr_to = s_axi_aw_hdr_34dw[3];
    wire [2:0] hdr_tag = s_axi_aw_hdr_34dw[2:0];
    wire [4:0] msg_type = s_axi_awmisc_info[23:19];
    wire mctp_sideband_valid = s_axi_awmisc_info[7:0] == 8'h7f &&
                               s_axi_aw_hdr_34dw[47:32] == 16'h1ab4 &&
                               (msg_type == 5'b10000 || msg_type == 5'b10010 ||
                                msg_type == 5'b10011);

    function [6:0] count_strb;
        input [63:0] strobe;
        integer bit_idx;
        begin
            count_strb = 7'd0;
            for (bit_idx = 0; bit_idx < 64; bit_idx = bit_idx + 1)
                count_strb = count_strb + strobe[bit_idx];
        end
    endfunction

    assign som_key = {hdr_deid, hdr_seid, hdr_to, hdr_tag};
    assign lookup_key = {hdr_deid, hdr_seid, hdr_to, hdr_tag};

    // The lowest enabled matching rule wins. Continuations bypass this filter.
    always @* begin
        filter_drop = 1'b0;
        if (mctp_sideband_valid && filter_enable && hdr_som) begin
            filter_drop = default_drop;
            for (i = 3; i >= 0; i = i - 1) begin
                if (rule_enable[i] &&
                    ((hdr_seid & rule_mask[i*8 +: 8]) ==
                     (rule_value[i*8 +: 8] & rule_mask[i*8 +: 8]))) begin
                    filter_drop = rule_drop[i];
                end
            end
        end
    end

    // A missing SQE is a drop; a valid continuation whose previous packet has
    // not committed waits so that its expected sequence cannot be misread.
    always @* begin
        aw_reason = DROP_NONE;
        aw_slot_valid = 1'b0;
        aw_slot = 3'd0;
        wait_context = 1'b0;
        if (!mctp_sideband_valid) aw_reason = DROP_MALFORMED;
        else if (hdr_som) begin
            if (filter_drop) aw_reason = DROP_FILTER;
            else if (som_conflict) aw_reason = DROP_DUP_SOM;
            else if (!som_candidate_valid) aw_reason = DROP_NO_ENTRY;
            else begin
                aw_slot_valid = 1'b1;
                aw_slot = som_slot;
            end
            if (som_conflict && lookup_valid) begin
                aw_slot_valid = 1'b1;
                aw_slot = lookup_slot;
            end
        end else begin
            if (!lookup_valid) aw_reason = DROP_ORPHAN;
            else begin
                aw_slot_valid = 1'b1;
                aw_slot = lookup_slot;
                if (lookup_timeout) aw_reason = DROP_TIMEOUT;
                else if (!lookup_seq_valid) wait_context = 1'b1;
                else if (hdr_seq != lookup_next_seq) aw_reason = DROP_SEQ;
            end
        end
        if (aw_reason == DROP_NONE && !wait_context) begin
            if (s_axi_awlen > 8'd15 || s_axi_awsize > 3'd6 || s_axi_awburst != 2'b01)
                aw_reason = DROP_OVERSIZE;
            else if (!store_bounds_ok) aw_reason = DROP_BOUNDS;
            else if (!buf_free && congestion_drop)
                aw_reason = DROP_CONGESTION;
        end
        // A rejected new SOM never bound its candidate SQE. Only an existing
        // conflicting message may be named in that packet's drop record.
        if (hdr_som && aw_reason != DROP_NONE && !som_conflict)
            aw_slot_valid = 1'b0;
    end

    assign s_axi_awready = rst_n && response_credit && !rx_active && !wait_context &&
                       (!drop_done_valid || drop_done_ready) &&
                       (aw_reason != DROP_NONE || buf_free);
    assign s_axi_wready = rst_n && rx_active;
    wire aw_fire = s_axi_awvalid && s_axi_awready;
    wire w_fire = s_axi_wvalid && s_axi_wready;
    assign som_bind = aw_fire && hdr_som && aw_reason == DROP_NONE;

    wire w_bad_length = (s_axi_wlast && rx_beat_count != {1'b0, rx_awlen}) ||
                        (!s_axi_wlast && rx_beat_count == {1'b0, rx_awlen});
    wire [3:0] finish_reason = (rx_reason != DROP_NONE) ? rx_reason :
                               current_timeout ? DROP_TIMEOUT :
                               w_bad_length ? DROP_MALFORMED : DROP_NONE;
    assign buf_reserve = aw_fire && aw_reason == DROP_NONE;
    assign buf_write = w_fire && rx_storing && rx_reason == DROP_NONE &&
                       !current_timeout && !w_bad_length &&
                       rx_beat_count < 9'd16;
    assign buf_wr_addr = rx_beat_count[3:0];
    assign buf_wr_data = s_axi_wdata;
    assign buf_wr_strb = s_axi_wstrb;
    assign buf_finish = w_fire && s_axi_wlast && rx_storing;
    assign buf_finish_good = finish_reason == DROP_NONE;
    assign packet_valid = buf_packet_valid;
    assign buf_packet_ready = packet_ready;
    assign buf_packet_release = packet_release;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            rx_active <= 1'b0;
            rx_storing <= 1'b0;
            rx_reason <= DROP_NONE;
            rx_awlen <= 8'd0;
            rx_beat_count <= 9'd0;
            rx_wbytes <= 11'd0;
            rx_token <= 5'd0;
            rx_slot <= 3'd0;
            rx_slot_valid <= 1'b0;
            rx_seq <= 2'd0;
            rx_eom <= 1'b0;
            rx_som <= 1'b0;
            rx_sqe <= 256'd0;
            packet_token <= 5'd0;
            packet_slot <= 3'd0;
            packet_seq <= 2'd0;
            packet_eom <= 1'b0;
            packet_som <= 1'b0;
            packet_sqe <= 256'd0;
            packet_wbytes <= 11'd0;
            packet_beats <= 5'd0;
            drop_done_valid <= 1'b0;
            drop_done_token <= 5'd0;
            drop_done_slot_valid <= 1'b0;
            drop_done_was_store <= 1'b0;
            drop_done_slot <= 3'd0;
            drop_event_valid <= 1'b0;
            drop_event_reason <= DROP_NONE;
            abort_event_valid <= 1'b0;
            abort_event_slot <= 3'd0;
            abort_event_reason <= DROP_NONE;
        end else begin
            drop_event_valid <= 1'b0;
            abort_event_valid <= 1'b0;
            if (drop_done_valid && drop_done_ready) drop_done_valid <= 1'b0;

            if (aw_fire) begin
                rx_active <= 1'b1;
                rx_storing <= (aw_reason == DROP_NONE);
                rx_reason <= aw_reason;
                rx_awlen <= s_axi_awlen;
                rx_beat_count <= 9'd0;
                rx_wbytes <= 11'd0;
                rx_token <= response_token;
                rx_slot <= aw_slot;
                rx_slot_valid <= aw_slot_valid;
                rx_seq <= hdr_seq;
                rx_eom <= hdr_eom;
                rx_som <= hdr_som;
                rx_sqe <= hdr_som ? som_sqe : lookup_sqe;
                if (aw_reason != DROP_NONE) begin
                    drop_event_valid <= 1'b1;
                    drop_event_reason <= aw_reason;
                    if (aw_slot_valid && (!hdr_som || som_conflict)) begin
                        abort_event_valid <= 1'b1;
                        abort_event_slot <= aw_slot;
                        abort_event_reason <= aw_reason;
                    end
                end
            end

            if (rx_active && current_timeout && rx_reason == DROP_NONE)
                rx_reason <= DROP_TIMEOUT;

            if (w_fire) begin
                rx_beat_count <= rx_beat_count + 9'd1;
                if (buf_write) begin
                    rx_wbytes <= rx_wbytes + count_strb(s_axi_wstrb);
                end
                if (rx_reason == DROP_NONE && !current_timeout && !s_axi_wlast &&
                    rx_beat_count == {1'b0, rx_awlen})
                    rx_reason <= DROP_MALFORMED;

                if (s_axi_wlast) begin
                    rx_active <= 1'b0;
                    if (finish_reason == DROP_NONE) begin
                        packet_token <= rx_token;
                        packet_slot <= rx_slot;
                        packet_seq <= rx_seq;
                        packet_eom <= rx_eom;
                        packet_som <= rx_som;
                        packet_sqe <= rx_sqe;
                        packet_wbytes <= rx_wbytes + count_strb(s_axi_wstrb);
                        packet_beats <= rx_beat_count[4:0] + 5'd1;
                    end else begin
                        drop_done_valid <= 1'b1;
                        drop_done_token <= rx_token;
                        drop_done_slot_valid <= rx_slot_valid;
                        drop_done_was_store <= rx_storing;
                        drop_done_slot <= rx_slot;
                        if (rx_reason == DROP_NONE) begin
                            drop_event_valid <= 1'b1;
                            drop_event_reason <= finish_reason;
                            if (rx_slot_valid) begin
                                abort_event_valid <= 1'b1;
                                abort_event_slot <= rx_slot;
                                abort_event_reason <= finish_reason;
                            end
                        end
                    end
                end
            end
        end
    end
endmodule
