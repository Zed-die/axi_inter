`timescale 1ns/1ps

// AXI4 read-channel 3-to-1 bridge. All three sources must use the same ARID;
// responses with that ID must return in AR acceptance order. Optional USER
// sidebands are not part of this baseline memory-side interface.
module axi_rd3t1_bridge #(
    parameter integer ADDR_WIDTH = 64,
    parameter integer DATA_WIDTH = 256,
    parameter integer ID_WIDTH = 4,
    parameter integer TAG_DEPTH = 8
) (
    input  wire                         clk,
    input  wire                         rst_n,
    input  wire [3*ID_WIDTH-1:0]        s_arid,
    input  wire [3*ADDR_WIDTH-1:0]      s_araddr,
    input  wire [23:0]                  s_arlen,
    input  wire [8:0]                   s_arsize,
    input  wire [5:0]                   s_arburst,
    input  wire [2:0]                   s_arlock,
    input  wire [11:0]                  s_arcache,
    input  wire [8:0]                   s_arprot,
    input  wire [11:0]                  s_arqos,
    input  wire [11:0]                  s_arregion,
    input  wire [2:0]                   s_arvalid,
    output wire [2:0]                   s_arready,
    output wire [3*ID_WIDTH-1:0]        s_rid,
    output wire [3*DATA_WIDTH-1:0]      s_rdata,
    output wire [5:0]                   s_rresp,
    output wire [2:0]                   s_rlast,
    output wire [2:0]                   s_rvalid,
    input  wire [2:0]                   s_rready,
    output wire [ID_WIDTH-1:0]          m_arid,
    output wire [ADDR_WIDTH-1:0]        m_araddr,
    output wire [7:0]                   m_arlen,
    output wire [2:0]                   m_arsize,
    output wire [1:0]                   m_arburst,
    output wire                         m_arlock,
    output wire [3:0]                   m_arcache,
    output wire [2:0]                   m_arprot,
    output wire [3:0]                   m_arqos,
    output wire [3:0]                   m_arregion,
    output wire                         m_arvalid,
    input  wire                         m_arready,
    input  wire [ID_WIDTH-1:0]          m_rid,
    input  wire [DATA_WIDTH-1:0]        m_rdata,
    input  wire [1:0]                   m_rresp,
    input  wire                         m_rlast,
    input  wire                         m_rvalid,
    output wire                         m_rready
);
    wire grant_valid;
    wire [1:0] grant_idx;
    reg held;
    reg [1:0] held_idx;
    wire [1:0] ar_src = held ? held_idx : grant_idx;
    wire ar_src_valid = held ? s_arvalid[held_idx] : grant_valid;
    wire ar_fire;
    wire [1:0] r_src;
    wire tags_full;
    wire tags_empty;
    wire r_fire_last;

    axi_rr_arbiter3 u_arbiter (
        .clk           (clk),
        .rst_n         (rst_n),
        .req_i         (s_arvalid),
        .advance_i     (ar_fire),
        .advance_src_i (ar_src),
        .grant_valid_o (grant_valid),
        .grant_idx_o   (grant_idx)
    );

    axi_tag_fifo #(
        .WIDTH (2),
        .DEPTH (TAG_DEPTH)
    ) u_source_fifo (
        .clk         (clk),
        .rst_n       (rst_n),
        .push_i      (ar_fire),
        .push_data_i (ar_src),
        .pop_i       (r_fire_last),
        .head_data_o (r_src),
        .full_o      (tags_full),
        .empty_o     (tags_empty)
    );

    assign m_arvalid = rst_n && !tags_full && ar_src_valid;
    assign ar_fire = m_arvalid && m_arready;
    assign s_arready = ar_fire ? (3'b001 << ar_src) : 3'b000;

    assign m_arid     = s_arid[ar_src*ID_WIDTH +: ID_WIDTH];
    assign m_araddr   = s_araddr[ar_src*ADDR_WIDTH +: ADDR_WIDTH];
    assign m_arlen    = s_arlen[ar_src*8 +: 8];
    assign m_arsize   = s_arsize[ar_src*3 +: 3];
    assign m_arburst  = s_arburst[ar_src*2 +: 2];
    assign m_arlock   = s_arlock[ar_src];
    assign m_arcache  = s_arcache[ar_src*4 +: 4];
    assign m_arprot   = s_arprot[ar_src*3 +: 3];
    assign m_arqos    = s_arqos[ar_src*4 +: 4];
    assign m_arregion = s_arregion[ar_src*4 +: 4];

    // When ARVALID is stalled, a newly asserted request may have higher
    // priority; retain the chosen source until this AR handshakes.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            held <= 1'b0;
            held_idx <= 2'd0;
        end else if (ar_fire) begin
            held <= 1'b0;
        end else if (m_arvalid && !m_arready) begin
            held <= 1'b1;
            held_idx <= ar_src;
        end
    end

    assign s_rid   = {3{m_rid}};
    assign s_rdata = {3{m_rdata}};
    assign s_rresp = {3{m_rresp}};
    assign s_rlast = {3{m_rlast}};
    assign s_rvalid = (rst_n && !tags_empty && m_rvalid)
                    ? (3'b001 << r_src) : 3'b000;
    assign m_rready = rst_n && !tags_empty && s_rready[r_src];
    assign r_fire_last = m_rvalid && m_rready && m_rlast;
endmodule
