# MCTP Engine 微架构规格（MAS）

> 版本：2026-11-08。本文以当前 `RTL/` 实现及近期确定的架构约定为准；旧版补充材料仅作背景。本文描述的是当前微架构，末章单列尚未收口的实现问题。接口信号的最终时序仍以 RTL 和集成仿真为准。

## 1. 范围与系统位置

MCTP Engine 位于 PCIe EP Controller 与 SoC Fabric 之间。Controller 对 Engine 提供接收 MCTP packet 的 AXI 写接口；Engine 对 Controller 发起发送 packet 的 AXI 写；Engine 还通过一套 Fabric AXI 主接口读取 SQE/载荷，并写入 RX 载荷、SQE 与 CQE。软件通过 APB 配置寄存器，接收电平中断。

系统图中的外部 `1t2 decoder` 与 `2t1 bridge` 不属于本 Engine 的 RTL 开发范围。Engine 内部包含连接三个读源、三个写源的 `axi_rd3t1_bridge` 与 `axi_wr3t1_bridge`。

```mermaid
flowchart LR
    SW[CPU / DDR 中的 RX SQ、TX SQ、共享 CQ] -->|APB 配置与 doorbell| APB
    CTL[PCIe EP Controller] -->|RX AXI AW/W + sideband| DEC
    DEC --> RESP[RX B 响应跟踪]
    DEC --> BUF[RX 1 KiB packet buffer]
    PREFR[RX SQ 预取] --> SQMR[8 个 RX SQ/message 上下文]
    SQMR --> DEC
    BUF --> ROUTER[RX router / 4 KiB 分段]
    SQMR --> ROUTER
    ROUTER --> COMP[RX 完成控制]
    COMP --> SQMR
    PREFT[TX SQ 预取] --> SQMT[TX SQ FIFO / 单 message 上下文]
    SQMT --> GEN[packet generator]
    GEN --> READER[TX payload reader + 1 KiB buffer]
    GEN -->|TX AXI AW/W + sideband| CTL
    SQMR --> CQ[共享 CQ Manager]
    SQMT --> CQ
    CQ --> IRQ[Interrupt Control]
    APB[APB 寄存器] --> PREFR & PREFT & DEC & SQMR & SQMT & GEN & CQ & IRQ
    PREFR & PREFT & READER --> RD[Fabric RD 3:1]
    ROUTER & SQMR & CQ --> WR[Fabric WR 3:1]
    RD & WR <--> FAB[SoC Fabric]
    RESP --> CTL
```

### 1.1 对外接口与时钟

| 接口 | 方向 | 内容 |
| --- | --- | --- |
| `clk`、低有效 `rst_n` | 输入 | 各模块使用同一时钟域；复位清空片上队列、上下文、指针和中断状态。 |
| APB | 从接口 | 32 bit 数据、8 bit 地址；`pready=1`，非法地址、未对齐或非法深度/指针写入由 `pslverr` 指示。 |
| Controller RX AXI | Engine 从接口 | 64 bit AW 地址、512 bit W 数据及 WSTRB、B 响应；AW 伴随 `s_awmisc_info` 与 `s_aw_hdr_34dw`。 |
| Controller TX AXI | Engine 主接口 | AW/W/B 及三个 Controller AW sideband：`tx_awmisc_info_hdr_34dw[63:0]`、`tx_awmisc_info[20:0]`、`tx_awmisc_info_p_tag[9:0]`。 |
| Fabric AXI | Engine 主接口 | 512 bit 数据宽度，AR/R 与 AW/W/B；内部各读写源统一使用 Fabric ID 0。 |
| `irq_level` | 输出 | `IRQ_STATUS & IRQ_MASK` 非零时保持高电平，直至软件清除相应状态。 |

Controller 对 MCTP 的选择由 Engine 外部的 `1t2 decoder` 完成；非 MCTP 写走外部旁路，不进入本文描述的 RX 缓存。MCTP 与非 MCTP 的 B 路由及两类流量之间的顺序约束由外部 decoder/bridge 承担。进入 Engine 的一笔 RX AW 对应一个完整 packet；AW 与 W 属于同一笔 AXI 写，W 通道没有 WID，直到 WLAST 才能释放其占用。

## 2. 数据对象与队列约定

### 2.1 三个软件队列

RX SQ 与 TX SQ 分开；RX 和 TX 共用一个 CQ。SQE 为 32 B，CQE 为 16 B，均位于软件分配的 Fabric 可访问内存中。RX SQ 和 CQ 深度通过 APB 配置，必须是可由 16 bit 表示的 2 的幂，范围为 2～32768；复位默认 256。TX SQ 当前固定深度 256，没有单独的深度寄存器。

队列指针是**物理槽位下标**，范围 `0 .. depth-1`，不把 phase 放在指针中。队列采用留一个空槽位的空满判定：

```text
next(p)  = (p + 1) & (depth - 1)
empty    = head == tail
full     = next(tail) == head
capacity = depth - 1
```

因此深度 256 时最多放 255 条未消费记录。CPU 先写 SQE，再更新对应 Tail doorbell；硬件只读取 Tail 之前的已提交 SQE。CPU 消费 CQE 后更新 CQ Head。寄存器值和基地址在队列运行中改变可能破坏当前 DMA 地址，软件应先停用并排空相关队列。

RX SQ 的 `fetch_ptr` 是下一条待预取下标；`rd_ptr` 是最早尚不可由软件回收的 SQE 下标。这两个指针可以不同：被预取或正在处理的 SQE 已越过 `fetch_ptr`，但只有连续完成且对应 CQE 发布成功后，`rd_ptr` 才能前进。CQE 中上报的 RX `RD_PTR` 与该可回收边界一致；后完成的 message 可以先写 CQE，但不得越过更早未完成的 SQE 更新 `RD_PTR`。

### 2.2 当前 SQE 位定义

| SQE 位段 | 宽度 | 当前用途 |
| --- | ---: | --- |
| `[255:240]` | 16 | CID，原样带入 CQE。 |
| `[219:200]` | 20 | 长度，编码为字节数减一。TX 以该字段确定 message 载荷长度；RX 完成时只回写该字段。 |
| `[191:128]` | 64 | 载荷地址。RX 为 Fabric 写目标起始地址；TX 为 Fabric 读源地址。当前实现使用 DWORD 对齐地址。 |
| `[95:90]` | 6 | 操作码：RX 要求 1，TX 要求 0。 |
| `[63:0]` | 64 | TX Controller 的 `hdr_34dw` 模板；packet generator 覆盖其中 SOM、EOM、序号位。 |
| 其余位 | — | 当前路径不解码；RX SQE 回写时保留原值。 |

RX 完成写回采用单个 32 B AXI 写：`AWSIZE=5`、`AWLEN=0`，在 512 bit WDATA 相应半边置 WSTRB。只有 Fabric B 成功，RX SQE 才进入可提交 CQE 的状态。

### 2.3 当前 CQE 位定义

| CQE 位段 | 宽度 | 含义 |
| --- | ---: | --- |
| `[127]` | 1 | Phase。初始为 1，CQ Tail 回绕时翻转。 |
| `[126:120]` | 7 | 保留，写零。 |
| `[119:112]` | 8 | Completion Code。 |
| `[111:96]` | 16 | 原 SQE 的 CID。 |
| `[95:80]` | 16 | SQID：0 为 RX，1 为 TX。 |
| `[79:64]` | 16 | 该 CQE 发布时允许软件看到的 SQ RD_PTR。 |
| `[63:0]` | 64 | 保留，写零。 |

CQE 的发布有两个独立 AXI 写：先用 `WSTRB=0x7fff` 写低 15 字节，确认 B 成功；再用 `WSTRB=0x8000` 写包含 Phase 的最后 1 字节，并再次确认 B 成功。最后才更新 CQ Tail、产生完成事件并通知对应 SQ Manager。这样 Phase 所在字节作为该 CQE 的发布标志。软件仍要维护自己的 CQ 读取指针，并仅消费本轮待读的槽位；Phase 用于识别槽位数据是否属于本轮，而不是替代软件指针。写 CQE 前若 `next(tail)==head`，硬件等待软件释放空间。

## 3. 软件可见寄存器

除特别注明外，寄存器只使用低有效位，高位读零。基地址拆成高、低 32 bit。APB 写操作在访问周期生效，非法访问 `pslverr=1`。

| 偏移 | 名称 | R/W | 说明 |
| --- | --- | --- | --- |
| `0x00` | RX_ENABLE | R/W | bit0 使能 RX。 |
| `0x08/0x0C` | RX_SQ_BASE_LO/HI | R/W | RX SQ 基地址；当前预取模块要求 64 B 对齐。 |
| `0x10` | RX_SQ_TAIL | R/W | RX SQ 软件提交尾指针。 |
| `0x14` | RX_SQ_DEPTH | R/W | 深度 2～32768、2 的幂；只可在从未启用 RX 且当前关闭时修改。 |
| `0x18/0x1C` | CQ_BASE_LO/HI | R/W | 共享 CQ 基地址，当前 CQ Manager 要求 64 B 对齐。 |
| `0x20` | CQ_HEAD | R/W | 软件已消费的 CQ 头指针。 |
| `0x24` | CQ_DEPTH | R/W | 深度 2～32768、2 的幂；只可在从未启用 RX/TX 且两方向均关闭时修改。 |
| `0x28` | FILTER_CTRL | R/W | bit0 使能过滤，bit1 默认丢弃。 |
| `0x2C` | FILTER_RULE_CTRL | R/W | `[3:0]` 各规则使能，`[7:4]` 各规则匹配后的丢弃动作。 |
| `0x30` | FILTER_RULE_VALUE | R/W | 4 个 8 bit Source EID 比较值。 |
| `0x34` | FILTER_RULE_MASK | R/W | 4 个 8 bit Source EID 掩码。 |
| `0x40` | IRQ_MASK | R/W | bit=1 允许对应状态驱动中断电平。 |
| `0x44` | IRQ_STATUS / CLEAR | R/W1C | 读粘滞状态，写 1 清对应位；同周期事件置位优先。 |
| `0x48` | CQ_TAIL | R | 硬件已发布的共享 CQ 尾指针。 |
| `0x4C` | RX_SQ_RD_PTR | R | RX SQ 连续可回收边界。 |
| `0x50` | MESSAGE_TIMEOUT | R/W | RX message 后续 packet 间隔超时周期数；0 禁用。 |
| `0x54` | CONGESTION_TIMEOUT | R/W | RX 因 packet buffer 占用而阻塞的超时周期数；0 禁用。 |
| `0x60` | TX_ENABLE | R/W | bit0 使能 TX。 |
| `0x68/0x6C` | TX_SQ_BASE_LO/HI | R/W | TX SQ 基地址；复用的预取模块要求 64 B 对齐。 |
| `0x70` | TX_SQ_TAIL | R/W | TX SQ 软件提交尾指针。 |
| `0x74` | TX_TUZ_BYTES | R/W | 每个 TX packet 的最大载荷字节数；默认 512，有效 1～1024。 |
| `0x78/0x7C` | TX_TARGET_ADDR_LO/HI | R/W | 发往 Controller 的 AXI 目标地址。 |
| `0x80` | TX_START_SEQ | R/W | 2 bit 发送起始 packet 序号。 |
| `0x84` | TX_SQ_RD_PTR | R | TX SQ 可回收边界；当前存在回绕问题，见 §12。 |

软件初始化建议顺序：先停用 RX/TX，配置内存与深度、基地址、过滤/超时、TUZ/目标地址与 IRQ；清除 IRQ；写入 SQE；更新 SQ Tail；最后使能方向。CQ Head 必须在 CQE 消费之后写入。深度寄存器有 sticky lock：启用过相应方向后，单纯清除 ENABLE 不能解除深度修改限制，需复位。

## 4. Inbound 数据流与模块设计

### 4.1 RX SQ 预取 `inbound_sq_prefetch`

模块接收 RX SQ 基地址、深度、软件 Tail，以及 SQ Manager 请求的预取条数。它本地维护 `fetch_ptr`，按 `available=(tail-fetch_ptr)&(depth-1)` 计算已提交而未预取的 SQE 数；一次接受量取请求量、8 个片上 FIFO 剩余空间和 available 的最小值。接受预取前，SQ Manager 同步预留对应的上下文槽位，保证返回数据有确定归属。

读请求按三个边界拆分：当前环形队列尾部、4 KiB 页边界、可用 SQE 数。当前索引为偶数且至少有两个连续 SQE 时，用 `ARSIZE=6` 的 64 B beat 读取一对 32 B SQE；奇数索引、首尾单条或不足一对时，使用 `ARSIZE=5` 的 32 B 窄读。突发为 AXI `INCR`，不依赖 `WRAP` 跨队列回绕。一次只保持一笔 AR/R 在途；收到 R 后按 32 B 拆分写入 8 深度同步 FIFO，同时附带原 SQ 下标和读取错误标记。读取或协议异常进入故障路径，不把错误 SQE 当成有效 descriptor。

### 4.2 8 个 RX 上下文 `inbound_sq_manager`

8 个 slot 并行保存 `slot_seq`、原始 SQE、20 bit message key、累计有效字节、期望的下一个 2 bit packet 序号、状态与完成码。预取请求先占用 FREE slot 为 FETCHING；返回 SQE 依据其物理 SQ 下标 `slot_seq` 放入预留 slot，正确操作码转 READY。新的 SOM 从 READY 中选取距离当前 RX `rd_ptr` 最近的一条；绑定后进入 ACTIVE。后续 packet 用 key 查 ACTIVE slot。多个 message 的 packet 可以交织，但一个 packet 的 AW/W 必须完整结束后才能接收下一个 packet 的 W。

| Slot 状态 | 含义与下一步 |
| --- | --- |
| FREE | 可供新预取请求预留。 |
| FETCHING | 已为某个 SQ 下标预留，等待预取 FIFO 返回。 |
| READY | SQE 已取得，等待新 SOM 绑定。 |
| ACTIVE | message 已绑定，后续 packet 可按 key 匹配。 |
| DRAIN | 已见 EOM，等待路由与完成控制收口。 |
| DONE | 已形成 message 结果，等待 SQE 写回。 |
| WB_BUSY | 对 Fabric 发起 SQE 写回并等待 B。 |
| CQ_READY / CQ_WAIT | 可提交 CQE / CQ 请求已被接受，等待 CQE 发布结果。 |
| RETIRING | 该条已发布 CQE，但更早 SQE 未结束，暂不能推进连续 RD_PTR。 |
| ERROR_HOLD | SQE 读取、写回或 CQ 发布失败，保留故障现场，不释放槽位。 |

SQE 写回与 CQ 提交是分开的事务：message 完成并更新长度字段 → 写回原 SQE → 等待 Fabric B 成功 → 形成 CQ 请求 → CQE 两次写入并得到 B → 更新可回收边界。即使某个后序 message 先完成，也可先提交其 CQE；CQE 的 `RD_PTR` 只越过从旧 `rd_ptr` 起连续已完成、已发布的 SQE。若前序未完成，后序 slot 暂留 `RETIRING`，其 CQE 报旧 RD_PTR。

### 4.3 Controller AW 解析与过滤 `mctp_decoder`

`s_axi_awmisc_info[7:0]` 必须是 Message Code `0x7F`，`[23:19]` 必须为允许的 Type-1 VDM 路由类型，`hdr_34dw[47:32]` 必须为 Vendor ID `0x1AB4`。`hdr_34dw` 低 24 bit 包含 DEID `[23:16]`、SEID `[15:8]`、SOM `[7]`、EOM `[6]`、序号 `[5:4]`、TO `[3]`、Tag `[2:0]`。message key 为 `{DEID,SEID,TO,Tag}`，共 20 bit；当前代码的 `som_key` 与 `lookup_key` 只是分别连接 SOM 和续包查询，组合值相同。

EID 过滤只在新 SOM 上执行，比较 Source EID。每条规则计算 `(SEID & mask)==(value & mask)`；匹配时由对应 `rule_drop` 决定丢弃/放行。多条规则匹配时低索引优先；无匹配采用 `default_drop`。过滤使能关闭时直接放行。续包依靠已绑定上下文，跳过这组过滤规则。

AW 判定得到 packet 对应 slot 与接收结果。合法 packet 且 buffer 空闲时接受 AW 并预留 buffer；需要丢弃的 AW 可以直接接受并占用 W 通道，完整数完该笔 W 后返回错误，不写 buffer。若上一包正处于 Fabric 转发中，合法 packet 的 AW 反压等待；若续包所需的前一 packet 尚未完成提交，则暂缓 AW，避免依据尚未稳定的 expected sequence 作误判。AW 接收还受 RX B 响应表 credit 约束。

| Inbound 场景 | 处理动作 | 后续影响 |
| --- | --- | --- |
| 新 SOM、EID 放行、有 READY SQE、无 key 冲突、buffer 空闲 | 分配该 SQE 的 ACTIVE slot，接收 W 入 buffer。 | router 转发后继续等待续包或 EOM。 |
| 新 SOM 被 EID 规则拒绝 | 接收并丢弃 W，不绑定新 SQE。 | 对该 packet 返回错误 B，置过滤错误中断；没有可对应的 CQE。 |
| 新 SOM 没有 READY slot | 接收并丢弃 W。 | 错误 B 与“无可用 entry”中断；没有可对应的 CQE。 |
| 新 SOM 与 ACTIVE key 重复 | 丢弃该 packet；已有 message 被标记异常终止。 | 已绑定 message 可产生错误 CQE。 |
| 非 SOM 找不到 ACTIVE key | 接收并丢弃 W。 | 错误 B 与“孤立续包”中断；没有可对应的 CQE。 |
| 非 SOM 的序号不等于期望值 | 接收并丢弃 W，终止对应 message。 | 错误 B；已有 SQE 后续写回并产生错误 CQE。 |
| 已绑定 message 等待续包超时 | 标记该 slot 超时并结束 message。 | 对应 SQE 写回与错误 CQE；后到续包被拒绝。 |
| AWLEN/AWSIZE/ARBURST 不支持、W 数不符或 sideband 不合法 | 丢弃并数完 W。 | 错误 B；若已绑定 slot，则可导致错误 CQE。 |
| packet buffer 长时间占用 | 可在配置的拥塞阈值后丢弃等待中的 packet。 | 错误 B；有 slot 时可形成错误 CQE。 |
| Fabric 转发 B 出错或 BID 不符 | 停止该 packet 正常提交。 | 错误 B；对应 message 形成路由错误 CQE。 |

丢弃原因在 decoder 内以 4 bit 编码：1 过滤、2 无 entry、3 孤立续包、4 序号错、5 重复 SOM、6 超时、7 包尺寸/突发不支持、8 目的边界失败、9 格式错误、10 拥塞；0 表示正常。对已绑定 message，原因会送完成控制并转换为 CQ Completion Code。无法关联 SQE 的丢弃只保留错误 B/中断事件。

### 4.4 RX packet buffer 与响应跟踪

`inbound_packet_buffer` 是**单 bank、1 KiB**存储转发缓存，最多容纳 16 个 512 bit W beat 与各自 64 bit WSTRB。状态按空闲、填充、可读、转发占用推进；decoder 先完整接收 WLAST 才向 router 提供 packet 元数据和只读数据。router 给出 release 后才能接收下一条正常 packet。当前没有 ping-pong buffer，因此该缓存限制了 packet 级吞吐，与 8 个并行 message 上下文是两个不同容量概念。

`inbound_response_tracker` 在 Controller AW 握手时分配 16 项响应表 token，保存原始 AWID；router 真实完成或 decoder 丢弃数完 W 后，按 token 标记结果。向 Controller 只返回一次 B，且按 AW 接收顺序全局出队。这比 AXI 对同 ID 的顺序要求更严格。当前实现没有“收到完整 W 就立即成功 B”的 early response：正常 packet 等待 Fabric 路由结果，丢弃 packet 返回 SLVERR。B 完成不等于整条 message 的 CQ 完成；它只确认当前 packet 的本地处理结果。

### 4.5 RX router、地址递增与 4 KiB 拆分

`inbound_router` 从缓存读取完整 packet，先检查 WSTRB 所表示的有效字节是否构成连续字节流，长度必须为 1～1024 B，输入 beat 数最多 16。SOM 的 Fabric 写起始地址来自 SQE `[191:128]`，低 2 bit 清零；续包使用该 slot 保留的 `next_addr`。写出时将源 byte stream 重排到目标 64 B 对齐的 WDATA/WSTRB，保持有效字节及其原顺序。

目标写采用 `AWSIZE=6`、`INCR`，每个 AXI 突发至多覆盖当前 4 KiB 页内的 64 B beat。若一个 packet 跨 4 KiB 边界，router 在边界前结束一笔 AW/W，等待其 Fabric B 成功后再对下一页发 AW。全部段成功后，才发 `packet_commit`，累计本 packet 的有效字节并更新该 slot 的 `next_addr=base_addr+packet_bytes` 与期望序号。任一 B 失败或 BID 异常即返回错误结果并终止该 packet。这里 4 KiB 拆分发生在**输出 Fabric AXI**，不要求 Controller 输入 packet 自身按 4 KiB 分段。

router 内部错误原因：1 WSTRB/形状错误，2 Fabric BRESP 错误，3 BID 不符，4 缺少续包上下文，5 地址溢出；0 正常。router 成功才更新 SQ Manager 的 packet 累计状态。

### 4.6 message 完成、超时与写回

`inbound_message_completion` 对 8 个 slot 分别记录已提交的有效载荷字节、待转发 packet、EOM 与 abort 状态。EOM 所在 packet 路由完成后，或异常 slot 已无未完成 packet 后，输出 `message_done`。它生成 RX 长度字段 `total_bytes-1`、Completion Code，并交给 SQ Manager 写回 SQE。

`inbound_gap_timeout` 监测已成功转发的非 EOM packet 到下一 packet 之间的等待间隔。若超过 `MESSAGE_TIMEOUT`，结束对应 ACTIVE message，产生错误 CQE；0 禁用。`CONGESTION_TIMEOUT` 只面向因单 bank buffer 占用导致的入口等待，触发时允许 decoder 将新 packet 走丢弃路径；0 禁用。这两个计时器针对不同阶段，不能笼统理解为 Fabric 必须在固定时间内返回 B。系统顶层将 decoder 的 `current_timeout` 测试输入固定为 0，未实现独立的“已接收 AW 后 W 长时间不来”定时器。

## 5. Outbound 数据流与模块设计

### 5.1 TX SQ 预取与上下文

`outbound_sq_prefetch` 复用 SQ 预取逻辑，维护 8 深度、32 B 宽的 FWFT FIFO，Fabric 读回时附带 SQ 下标与错误信息；其深度输入目前固定为 256。空位出现便补充预取，软件可在内存 TX SQ 中提交更多 SQE。8 是**预取待发送 SQE 数量上限**，并不代表 8 个 TX message 同时发送。

`outbound_sq_manager` 只有一个正在发送的 message 上下文。它从 FIFO 头取 SQE，要求操作码为 0；有效 SQE交给 packet generator。Generator 报 done 后，Manager 请求共享 CQ，等待 CQE 成功发布，才更新 TX `RD_PTR` 并取下一条。无效操作码生成 `0x50` CQE；SQE 读取错误使队列进入故障保持，当前不生成该条 CQE。

TX 不回写原 SQE。与 RX 的“载荷写入 → SQE 写回 → CQE 发布”不同，TX 的完成路径是“载荷读取 → Controller packet 写入 → CQE 发布”；TX `RD_PTR` 仍以 CQE 成功发布为回收点。

### 5.2 载荷读取与单包缓存

`outbound_packet_gen` 将 SQE 长度字段加 1 得到 message 字节数，把每次 packet 载荷限制为 `min(remaining,TUZ)`；最后一包可以短于 TUZ。它向 `outbound_payload_reader` 发出起始地址与本包长度。Reader 通过 Fabric AR/R 读满一包，写入独立的 `outbound_packet_buffer` 1 KiB 存储；同一时间只保留一包。Reader 对 64 B 对齐整 beat 使用 `ARSIZE=6`，处理非对齐头尾时退化为 4 B 或 1 B 读取，每笔 AR 不跨 4 KiB，核对 RRESP/RID/RLAST；错误时报告 generator。

### 5.3 packet 生成与 Controller AXI

Generator 对一条 message 连续生成 packet。首包 SOM=1，最后一包 EOM=1，中间包两个标志均为 0；2 bit 序号从 `TX_START_SEQ` 起，每包加一并自然回绕。Header 模板取 SQE `[63:0]`，只覆盖 `[7]` SOM、`[6]` EOM、`[5:4]` 序号。`tx_awmisc_info` 采用 Message Code `0x7F` 与 route-by-ID 类型 `0x12`，`p_tag=0`。实际 payload 经 WDATA 输出，不放在 sideband。

每包补零至 4 B 整数倍，WSTB 标记载荷与补齐字节；AW 对目标 Controller 地址发 `AWSIZE=6`、`INCR` 突发。一个 packet 的 AW/W 不允许跨 4 KiB 边界；当前 generator **不会把单个 packet 再拆成多个 Controller AW**，若目标窗口不足以容纳该 packet 则以 `0x64` 结束 message。`TX_TARGET_ADDR` 对所有 packet 保持同一地址，作为 Controller 的发送窗口，而不是每包按载荷字节数递增。每包先 AW、再 W、再等 Controller B；所有 packet 成功后才输出 `done_status=0`。这个 B 只表明 Controller 本地 AXI 写完成，不证明远端 MCTP endpoint 已确认。

Generator 的状态包括 IDLE、PREP、START_READ、WAIT_READ、AW、W、B、DONE、WAIT_PUBLISH、FAULT。它在 DONE 之后继续持有 descriptor，直至对应 CQE 发布结果返回；CQ 发布失败进入 FAULT，不悄悄重发 packet。

## 6. Fabric AXI 汇聚

| 方向 | 三个内部源 | 仲裁推进点 | 响应路由 |
| --- | --- | --- | --- |
| 读 `axi_rd3t1_bridge` | RX SQ 预取、TX SQ 预取、TX payload reader | AR 握手后轮转。 | AR 接受时把源编号压入 2 bit tag FIFO；R 按 FIFO 头路由，RLAST 握手弹出。 |
| 写 `axi_wr3t1_bridge` | RX router、RX SQE 写回、共享 CQE 写入 | 当前笔 WLAST 握手后轮转。 | AW 接受时记录源编号；对应 B 按 tag FIFO 头回送。 |

两个 bridge 使用公平轮询仲裁器与同款 tag FIFO。Fabric 侧统一使用 AXI ID 0，所以要求同 ID 返回顺序；tag FIFO 深度为 8，并以握手顺序跟踪。写桥需保持 AW 选中源直到本笔 WLAST，避免 AXI4 无 WID 时发生 W 归属错误；等待 B 的更早写事务仍由响应 FIFO 跟踪。读写回压必须贯通到内部源。不同源不能因为共享 ID 而擅自依赖乱序 R/B 返回。

## 7. CQ Manager 与中断

`shared_cq_manager` 同时接受 RX、TX 完成请求。两方向均有效时按上一次服务方向轮流选择。它检查 CQ 深度、Head 范围与 64 B 基地址对齐；队列满则等待。一次只构造/发布一个 CQE；两阶段 CQ 写及 B 校验完成后，向原请求方发 publish result，并使 CQ Tail 前进。任何 CQ 写入或 BID 错误会让 Manager 进入故障保持，防止软件看到未完整发布的 CQE 被当成成功完成。

中断状态是粘滞位，`IRQ_LEVEL = |(IRQ_STATUS & IRQ_MASK)`。Mask 只控制输出电平，不阻止状态记录；软件读状态、处理原因后向 `0x44` 写 1 清位。若对应条件持续或新事件到来，电平会维持/重新拉高。

| IRQ bit | 当前事件来源 |
| ---: | --- |
| 0 | 非 SOM packet 找不到匹配 ACTIVE slot。 |
| 1 | 新 SOM 被 EID filter 拒绝。 |
| 2 | 新 SOM 无 READY SQE/entry 可分配。 |
| 3 | RX 或 TX SQE 读取失败。 |
| 4 | RX SQE 写回失败。 |
| 5 | CQE 写入或发布失败、CQ Manager fault。 |
| 6 | 其他 RX 丢弃/路由错误、message 间隔超时、无效 SQE、Manager fault，或 TX generator 非零完成码。 |
| 7 | 任意 RX/TX CQE 成功发布。 |

单个错误可能既对应错误 CQE，也对应中断。无可关联 SQE 的错误（例如孤立续包、新 SOM 过滤失败、无 RX entry）不能凭空造出合法 CID，因此只通过 packet B、IRQ 状态记录。中断 bit6 是合并异常位；软件若需要精确定位，必须同时查 CQE code 与相关状态。

## 8. Completion Code 定义

当前实现把一字节 code 放在 CQE `[119:112]`。下表列出 RTL 中的编码映射；部分丢弃原因没有可关联的 SQE，因此通常只表现为错误 B/IRQ，不会实际写出对应 CQE。未列编码保留。错误码表示 Engine 的本地处理结果。

| Code | 来源 | 含义 |
| --- | --- | --- |
| `0x00` | RX/TX | message 正常完成，相关本地 AXI B 已成功。 |
| `0x21` | RX abort | 已绑定 message 因过滤原因终止；通常过滤在新 SOM 前发生，故此码并非所有过滤错误都会有 CQE。 |
| `0x22` | RX abort | 已绑定 message 的无 entry 错误；通常无 entry 时未绑定 SQE。 |
| `0x23` | RX abort | 孤立续包；通常无绑定 SQE。 |
| `0x24` | RX abort | packet 序号不连续。 |
| `0x25` | RX abort | 重复 SOM / key 冲突。 |
| `0x26` | RX abort/超时 | 等待续包超时，或已绑定 packet 的超时。 |
| `0x27` | RX abort | packet 超出允许的 AW 尺寸/突发范围。 |
| `0x28` | RX abort | 目的边界检查不通过；系统顶层目前未启用实际容量检查。 |
| `0x29` | RX abort | sideband 或 W beat 格式错误。 |
| `0x2A` | RX abort | buffer 拥塞丢弃。 |
| `0x41`～`0x45` | RX router | 依次为 packet 格式、Fabric BRESP、BID、续包地址上下文、目的地址溢出。 |
| `0x50` | TX SQ Manager | TX SQE 操作码错误。 |
| `0x61` | TX generator | Fabric payload 读取失败。 |
| `0x62` | TX generator | Controller 发送写 B/BID 异常。 |
| `0x63` | TX generator | TUZ 非法：0 或大于 1024 B。 |
| `0x64` | TX generator | Controller 目标地址未 64 B 对齐或 packet 会跨 4 KiB。 |

RX `0x20 + drop_reason` 与 `0x40 + route_reason` 是两类独立来源；一个未绑定 SQE 的错误只产生错误 B 和 IRQ，不能保证出现表中的 CQE。SQE 预取或写回、CQE 写入等基础设施故障目前用 sticky fault/IRQ 保持，不应误解释为已经写出了对应 Completion Code。

## 9. 关键时序示例

### 9.1 两条交织的 RX message

1. RX 预取 SQ 下标 0、1，对应两个 READY slot；Controller 收到 A 的 SOM，绑定槽 0。
2. A 的首包完整写入 1 KiB buffer，router 分段写 Fabric，B 成功后更新槽 0 期望序号和目的地址。
3. Controller 收到 B 的 SOM，绑定槽 1；B 首包按自己的 SQE 地址转发。
4. A 的续包通过 `{DEID,SEID,TO,Tag}` 找槽 0，检查 2 bit 序号，再转发到槽 0 的 `next_addr`。A/B 的上下文互不覆盖。
5. 若 B 先 EOM 且写回成功，可先写 B 的 CQE；CQE `RD_PTR` 仍指向下标 0。待 A 也成功发布 CQE，连续可回收边界再前进至 2。

### 9.2 RX packet 跨 4 KiB 目标边界

假设目的地址为 `0x...FF0`，packet 有 128 B 有效载荷。router 将数据重排为覆盖地址 `0x...FC0`、`0x...1000`、`0x...1040` 的 64 B beat，分别设置首尾 WSTRB。它先发送页末的单 beat AW/W 并等 B，再发送下一页的两个 beat AW/W 并等 B；两次成功后才认为该 packet 转发成功，更新 message 的累计字节数 128。软件可见的目的地址没有因 64 B 对齐而丢失低 6 bit 偏移。

### 9.3 CQ 深度 256 的回绕

当 `head=0, tail=255` 时，`next(tail)=0=head`，CQ 已占用 255 个可用槽，Manager 不再提交新 CQE。CPU 消费槽 0 并写 `head=1` 后，Manager 才能写槽 255；其后 Tail 回到 0，Phase 翻转。软件继续按自身 CQ 读取指针与期望 Phase 判断新旧数据。

## 10. 性能、背压与顺序边界

| 资源 | 当前容量/限制 | 直接影响 |
| --- | --- | --- |
| RX message 上下文 | 8 个 | 同时跟踪最多 8 条已预取/活动/待回收 RX SQE；是否都 ACTIVE 取决于软件提交与处理状态。 |
| RX packet buffer | 1 × 1 KiB | 正常 packet 存储转发，上一包释放前下一正常包 AW 被反压。 |
| RX B 跟踪 | 16 项 | Controller AW credit 上限；B 按 AW 全局顺序返回。 |
| TX 预取 FIFO | 8 条 SQE | 可提前装入 8 条待发送 SQE。 |
| TX 正在发送上下文 | 1 条 message | 发送按 FIFO 头顺序逐条推进。 |
| TX packet buffer | 1 × 1 KiB | 每次读取并发送一个 packet。 |
| 共享 CQ | `depth-1` 条 | RX/TX 共用容量，CQ 满时双方完成提交被反压。 |
| Fabric 读/写 tag FIFO | 各 8 项 | 限制合并总线在途请求标签数；同 ID 返回按序路由。 |

RX packet B、RX SQE 写回 B、CQE 写入 B 属于不同完成层级。packet B 成功不能让软件回收 SQE；SQE 写回 B 成功也不能让软件认为 CQE 已发布。只有 CQE 最后一个字节写入获得成功 B，才推进 CQ Tail 并通知 SQ Manager。

## 11. 验证关注点

功能仿真应覆盖以下约束；仓库已有针对预取、decoder、SQ Manager、router、response tracker、gap timeout、共享 CQ、TX reader/generator、3:1 bridge 及 Engine top 的独立 testbench，见 [`RTL/tb/`](RTL/tb/)：

截至本版文档编写时，以 Icarus Verilog 的 Verilog 2005 模式编译并运行仓库中的 29 个 `tb_*.v`，结果为 **29/29 通过**。部分 testbench 使用 `bind` 作任务名，故不应直接用 `-g2012` 将其作为 SystemVerilog 编译；此结果不代表下列待收口事项已解决。

| 类别 | 核心检查 |
| --- | --- |
| 队列回绕 | RX SQ/CQ 深度 2、256、32768 的空满、跨尾预取、Phase 翻转及读回指针；TX 固定 256 的回绕缺口需单独关闭。 |
| AXI | AW/W 绑定、VALID 被反压时输出稳定、WSTRB/地址对齐、同 ID R/B 路由、4 KiB 不跨界。 |
| RX | 8 个交织 message、重复 SOM、孤立续包、序号错误、EID 规则优先级、buffer 满、掉包与 B/CQ/IRQ 对应。 |
| 完成顺序 | 后序 RX message 先完成，先发布其 CQE 但 RD_PTR 不越过前序；SQE B 失败不能发布 CQE。 |
| TX | 非对齐载荷 AR、TUZ 最后一包、SOM/EOM/序号回绕、4 B padding、Controller B 失败与 CQ code。 |
| 故障恢复 | SQE/CQE DMA B 失败、FIFO credit 耗尽、复位清状态、IRQ W1C 与电平持续性。 |

## 12. 当前实现待收口事项

1. **RX 目的缓存容量未内建校验。** Decoder 有 `store_bounds_ok` 输入，但系统顶层将其固定为 1；因此 `0x28` 路径目前不能真实拦截 SQE 指向的目的区域越界。需定义 SQE 中目的区域容量或独立保护边界，再把检查做到 Engine 内。
2. **TX RD_PTR 缺少深度 256 回绕。** TX 预取固定深度 256，但 `outbound_sq_manager` 当前用 16 bit 自然加一更新 `sq_rd_ptr` 与 CQE candidate RD_PTR；从 255 前进会成为 256，而不是 0。与软件 Tail 的 0～255 环形语义不一致，投产前必须修正并回归回绕测试。
3. **当前没有 RX early response。** Controller B 等 packet 完整收取并经 Fabric router 完成，或者丢弃路径完整吸收 W 后才返回。若系统级性能要求 early B，需要重新规定“B 成功”的承诺点以及后续 Fabric 失败如何通过 CQ/IRQ 上报。
4. **单 bank buffer 决定 packet 级串行。** 当前 RX/TX 各只有一个 1 KiB packet buffer；8 个 RX slot 是 message 跟踪能力，不是 8 包同时接收能力。吞吐评估应按此计算。
5. **TX Controller 目标窗口边界。** 当前一包只能对应一笔 Controller AW，目标地址固定不递增。TUZ/目标地址组合若会跨 4 KiB，返回 `0x64`；如目标 Controller 要求分包或地址递增，需另行调整契约。
6. **基础设施错误的恢复策略。** SQE 读/写、CQE 发布失败进入 fault/hold，无自动重试或软件可在不复位情况下恢复的完整协议；需明确软件复位与重新初始化流程。
7. **运行时配置一致性。** APB 对部分基地址、Tail、过滤和 TUZ 在 ENABLE 后仍可写；硬件没有为每笔在途事务统一锁存全部配置。软件应只在明确安全点修改，必要时增加寄存器写保护或配置快照。
8. **RX 长度零值歧义。** 当前 RX 完成控制对累计 0 字节写回 0；长度字段采用 `bytes-1` 时，该值也表示 1 字节。异常终止后的长度解释应结合 Completion Code 规范化。

## 13. 各模块接口与微架构

本节以 `mctp_engine` 的**实际例化层级**为范围；未被该顶层例化的实验/旧版模块不属于当前 MAS 的模块清单。方向均以**该模块自身**为参照；`I` 为输入、`O` 为输出。方括号给出位宽，省略位宽时为 1 bit。表中把同一握手通道的信号放在一行，但每个端口均按 RTL 原名列出。AXI 的一次传输以 `VALID && READY` 握手为准；`LEN` 编码为 beat 数减一，`SIZE` 编码为每 beat 字节数的以 2 为底对数。除纯存储体 `outbound_packet_buffer` 外，各时序模块均有输入 `clk` 与低有效输入 `rst_n`，本节表格不重复列这两个公共端口。

### 13.1 `mctp_engine`：系统顶层

**作用与方案：** 作为集成边界，例化 `mctp_engine_core`，选择 APB 配置，将内部测试钩子固定为系统值；把 Controller RX、Controller TX、Fabric AXI 和电平 IRQ 暴露给 SoC。顶层本身不维护队列状态。

| 接口信号 | 方向 | 作用与连接 |
| --- | --- | --- |
| `clk`、`rst_n` | I | Engine 唯一时钟与低有效复位。 |
| `psel`、`penable`、`pwrite`、`paddr[7:0]`、`pwdata[31:0]` | I | APB 配置/doorbell 写入。 |
| `prdata[31:0]`、`pready`、`pslverr` | O | APB 读数、完成与错误。 |
| `irq_level` | O | 经 mask 后的持续中断电平。 |
| `s_awvalid`、`s_awid[3:0]`、`s_awmisc_info[63:0]`、`s_aw_hdr_34dw[63:0]`、`s_awlen[7:0]`、`s_awsize[2:0]`、`s_awburst[1:0]` | I | Controller RX packet 的 AW 与两个 MCTP sideband。 |
| `s_awready` | O | RX AW 能否进入 Engine，受响应表、上下文和 buffer credit 控制。 |
| `s_wvalid`、`s_wdata[511:0]`、`s_wstrb[63:0]`、`s_wlast` | I | Controller RX packet 的 W beat。 |
| `s_wready` | O | 已接受 AW 后接收当前 packet 的 W。 |
| `s_bvalid`、`s_bid[3:0]`、`s_bresp[1:0]` | O | 当前 packet 的一次 B 响应。 |
| `s_bready` | I | Controller 接收 B。 |
| `tx_awvalid`、`tx_awaddr[63:0]`、`tx_awlen[7:0]`、`tx_awsize[2:0]`、`tx_awburst[1:0]`、`tx_awid[3:0]`、`tx_awlock`、`tx_awcache[3:0]`、`tx_awprot[2:0]`、`tx_awqos[3:0]`、`tx_awregion[3:0]` | O | 发往 Controller 的 TX packet AW。 |
| `tx_awmisc_info_hdr_34dw[63:0]`、`tx_awmisc_info[20:0]`、`tx_awmisc_info_p_tag[9:0]` | O | 与 TX AW 同步握手的 Controller sideband。 |
| `tx_awready` | I | Controller 接受 TX AW。 |
| `tx_wvalid`、`tx_wdata[511:0]`、`tx_wstrb[63:0]`、`tx_wlast` | O | 发送 packet 的 payload 与零 padding。 |
| `tx_wready`、`tx_bvalid`、`tx_bresp[1:0]`、`tx_bid[3:0]` | I | Controller W credit 与写入结果。 |
| `tx_bready` | O | Engine 接收 Controller B。 |
| `m_axi_arvalid`、`m_axi_araddr[63:0]`、`m_axi_arlen[7:0]`、`m_axi_arsize[2:0]`、`m_axi_arburst[1:0]`、`m_axi_arid[3:0]`、`m_axi_arlock`、`m_axi_arcache[3:0]`、`m_axi_arprot[2:0]`、`m_axi_arqos[3:0]`、`m_axi_arregion[3:0]` | O | Fabric 合并后的 SQE/载荷读请求。 |
| `m_axi_arready`、`m_axi_rvalid`、`m_axi_rdata[511:0]`、`m_axi_rresp[1:0]`、`m_axi_rlast`、`m_axi_rid[3:0]` | I | Fabric 读请求接受与数据响应。 |
| `m_axi_rready` | O | Engine 对 Fabric R 的回压。 |
| `m_axi_awvalid`、`m_axi_awaddr[63:0]`、`m_axi_awlen[7:0]`、`m_axi_awsize[2:0]`、`m_axi_awburst[1:0]`、`m_axi_awid[3:0]`、`m_axi_awlock`、`m_axi_awcache[3:0]`、`m_axi_awprot[2:0]`、`m_axi_awqos[3:0]`、`m_axi_awregion[3:0]` | O | Fabric 合并后的 RX payload、SQE 回写与 CQE 写入 AW。 |
| `m_axi_awready`、`m_axi_wready`、`m_axi_bvalid`、`m_axi_bresp[1:0]`、`m_axi_bid[3:0]` | I | Fabric 写请求接受与 B。 |
| `m_axi_wvalid`、`m_axi_wdata[511:0]`、`m_axi_wstrb[63:0]`、`m_axi_wlast`、`m_axi_bready` | O | Fabric W 数据与 B 接收回压。 |

### 13.2 `mctp_engine_core`：通路集成

**作用与方案：** 直接例化本节其余数据通路模块，连接 RX/TX SQ、共享 CQ、IRQ、读写 3:1 bridge。`USE_APB=1` 时所有运行配置来自 `apb_interface`；`USE_APB=0` 时由 direct 输入提供测试配置。`ENABLE_TX` 可在综合时关闭 TX。系统顶层只使用 APB 模式。

| 接口信号 | 方向 | 作用与连接 |
| --- | --- | --- |
| `clk`、`rst_n` | I | 公共时钟与复位。 |
| `enable`、`sq_base_addr[63:0]`、`sq_tail_ptr[15:0]`、`cq_base_addr[63:0]`、`cq_head[15:0]` | I | direct 模式的 RX SQ/共享 CQ 配置。 |
| `tx_enable`、`tx_sq_base_addr[63:0]`、`tx_sq_tail_ptr[15:0]`、`tx_tuz_bytes[10:0]`、`tx_target_addr[63:0]`、`tx_start_seq[1:0]` | I | direct 模式的 TX 配置。 |
| `filter_enable`、`rule_enable[3:0]`、`rule_drop[3:0]`、`rule_value[31:0]`、`rule_mask[31:0]`、`default_drop` | I | direct 模式的 EID 规则配置。 |
| `irq_mask[7:0]`、`irq_clear[7:0]`、`message_timeout_cycles[31:0]`、`congestion_timeout_cycles[31:0]` | I | direct 模式的中断与超时配置。 |
| `store_bounds_ok`、`congestion_drop`、`lookup_timeout`、`current_timeout` | I | 测试/诊断钩子；系统顶层只将 `store_bounds_ok` 固定高，其余固定低，内部拥塞和 gap timeout 仍正常工作。 |
| `cq_tail[15:0]`、`sq_rd_ptr[15:0]`、`tx_sq_rd_ptr[15:0]`、`irq_status[7:0]`、`irq_level` | O | 队列与中断状态，可供 direct 测试及 APB 读回。 |
| `psel`、`penable`、`pwrite`、`paddr[7:0]`、`pwdata[31:0]`、`prdata[31:0]`、`pready`、`pslverr` | I/O | APB 接口，方向与 §13.1 相同。 |
| 全部 `s_*`、`tx_*`、`m_axi_*` AXI 端口 | I/O | 与 §13.1 同名同宽同方向，core 不增加额外系统 AXI 通道。 |

### 13.3 `apb_interface`：寄存器组

**作用与方案：** APB 访问周期单拍完成；读 mux 输出寄存器值；合法写入在时钟沿更新。校验地址和队列深度，深度配置被 sticky lock 保护。`USE_APB` 决定 `cfg_*` 来自 APB 寄存器还是 direct 输入。完整偏移与软件语义见 §3。

| 接口信号 | 方向 | 作用 |
| --- | --- | --- |
| `psel`、`penable`、`pwrite`、`paddr[7:0]`、`pwdata[31:0]` | I | APB 访问控制、地址、写数据。 |
| `prdata[31:0]`、`pready`、`pslverr` | O | 读数据、固定完成和非法访问错误。 |
| `direct_enable`、`direct_sq_base_addr[63:0]`、`direct_sq_tail_ptr[15:0]`、`direct_cq_base_addr[63:0]`、`direct_cq_head[15:0]` | I | direct RX SQ/CQ 配置。 |
| `direct_filter_enable`、`direct_default_drop`、`direct_rule_enable[3:0]`、`direct_rule_drop[3:0]`、`direct_rule_value[31:0]`、`direct_rule_mask[31:0]` | I | direct EID 规则。 |
| `direct_irq_mask[7:0]`、`direct_irq_clear[7:0]`、`direct_message_timeout_cycles[31:0]`、`direct_congestion_timeout_cycles[31:0]` | I | direct IRQ/计时配置。 |
| `direct_tx_enable`、`direct_tx_sq_base_addr[63:0]`、`direct_tx_sq_tail_ptr[15:0]`、`direct_tx_tuz_bytes[10:0]`、`direct_tx_target_addr[63:0]`、`direct_tx_start_seq[1:0]` | I | direct TX 配置。 |
| `irq_status[7:0]`、`cq_tail[15:0]`、`sq_rd_ptr[15:0]`、`tx_sq_rd_ptr[15:0]` | I | 硬件状态，映射为 APB 只读寄存器。 |
| `cfg_enable`、`cfg_sq_base_addr[63:0]`、`cfg_sq_tail_ptr[15:0]`、`cfg_sq_depth[15:0]`、`cfg_cq_base_addr[63:0]`、`cfg_cq_head[15:0]`、`cfg_cq_depth[15:0]` | O | 供 RX 与 CQ 模块使用的最终配置。 |
| `cfg_filter_enable`、`cfg_default_drop`、`cfg_rule_enable[3:0]`、`cfg_rule_drop[3:0]`、`cfg_rule_value[31:0]`、`cfg_rule_mask[31:0]` | O | 供 decoder 使用的最终 EID 规则。 |
| `cfg_irq_mask[7:0]`、`cfg_irq_clear[7:0]`、`cfg_message_timeout_cycles[31:0]`、`cfg_congestion_timeout_cycles[31:0]` | O | IRQ 与 RX 计时器最终配置。 |
| `cfg_tx_enable`、`cfg_tx_sq_base_addr[63:0]`、`cfg_tx_sq_tail_ptr[15:0]`、`cfg_tx_tuz_bytes[10:0]`、`cfg_tx_target_addr[63:0]`、`cfg_tx_start_seq[1:0]` | O | TX 最终配置。 |

### 13.4 `inbound_sq_prefetch`：RX SQ DMA 预取

**作用与方案：** 依据软件 Tail 和本地 `inbound_fetch_ptr` 预取 32 B SQE；按当前物理索引、环末和 4 KiB 边界规划 32/64 B INCR 读；R beat 拆分为 SQE 后放入 8 深度 FIFO。预取请求的接受与 AR 完成是两个阶段，Manager 必须依据 `prefetch_accept_num` 预留 slot，不能把 `prefetch_req_valid` 当作“数据已返回”。

| 接口信号 | 方向 | 作用 |
| --- | --- | --- |
| `inbound_sq_base_addr[ADDR_WIDTH-1:0]`、`inbound_sq_depth[15:0]`、`inbound_tail_ptr[15:0]` | I | SQ 内存地址、环深度和软件已提交 Tail。 |
| `prefetch_req_valid`、`prefetch_sq_num[4:0]` | I | SQ Manager 请求预留的 SQE 数量。 |
| `prefetch_req_ready`、`prefetch_accept_num[4:0]` | O | 本周期可接受请求及实际接受条数；两者与 valid 同时成立才预留。 |
| `inbound_fetch_ptr[15:0]` | O | 已预留预取的环形尾指针，供 Manager 给 slot 赋 SQ 下标。 |
| `m_axi_arvalid`、`m_axi_araddr[ADDR_WIDTH-1:0]`、`m_axi_arlen[7:0]`、`m_axi_arsize[2:0]`、`m_axi_arburst[1:0]` | O | Fabric SQE AR，INCR；偶数索引成对时 SIZE=6，单条 SIZE=5。 |
| `m_axi_arready`、`m_axi_rvalid`、`m_axi_rdata[511:0]`、`m_axi_rresp[1:0]`、`m_axi_rlast`、`m_axi_rid[ID_WIDTH-1:0]` | I | Fabric AR 接受与 R 返回。 |
| `m_axi_rready` | O | 预取接收 R 的能力。 |
| `sq_rd_en` | I | Manager 消费 FIFO 头。 |
| `sq_count[3:0]`、`sq_empty`、`sq_dout[255:0]`、`sq_ptr[15:0]`、`sq_error` | O | FIFO 占用数、空标志、SQE、对应 SQ 下标和该 SQE 的 R 错误标志。 |
| `fault` | O | 深度/基地址/协议错误后粘滞故障。 |

### 13.5 `sync_fifo`：预取结果 FIFO

**作用与方案：** 同步计数式 FIFO，容量 `2^ADDR_WIDTH`，组合读出当前头部，时钟沿处理读写；RX 与 TX 预取器均例化它。预取器实际配置为 `DATA_WIDTH=273`、`ADDR_WIDTH=3`，一条保存 `{sq_error, sq_ptr, sq_dout}`。

| 接口信号 | 方向 | 作用 |
| --- | --- | --- |
| `wr_en`、`din[DATA_WIDTH-1:0]` | I | 入队使能与数据。 |
| `rd_en` | I | 出队使能。 |
| `dout[DATA_WIDTH-1:0]` | O | 当前队头，供 Manager FWFT 读取。 |
| `full`、`empty`、`data_count[ADDR_WIDTH:0]` | O | 空满与占用计数。 |

### 13.6 `inbound_sq_manager`：8 路 RX 上下文

**作用与方案：** 并行管理 8 个 slot 的预取归属、SOM 绑定、续包查询、包提交、SQE 写回、CQ 请求以及 RD_PTR 连续退休。模块内部 SQE 写回一次只处理一个 slot；写回成功前不发 CQ 请求。其状态转移见 §4.2。

| 接口信号 | 方向 | 作用 |
| --- | --- | --- |
| `enable`、`sq_base_addr[ADDR_WIDTH-1:0]`、`sq_depth[15:0]` | I | RX 队列使能与内存布局。 |
| `prefetch_req_valid`、`prefetch_sq_num[4:0]`、`prefetch_sq_rd_en` | O | 向 prefetch 要求填满 FREE slot，并消费结果 FIFO。 |
| `prefetch_req_ready`、`prefetch_accept_num[4:0]`、`prefetch_fetch_ptr[15:0]`、`prefetch_sq_empty`、`prefetch_sq_dout[255:0]`、`prefetch_sq_ptr[15:0]`、`prefetch_sq_error`、`prefetch_fault` | I | 预取接受量、预留起点、SQE 及读错误/故障。 |
| `sq_rd_ptr[15:0]` | O | 已连续退休的 RX SQ 物理下标。 |
| `som_key[19:0]`、`som_seq[1:0]`、`som_bind`、`lookup_key[19:0]` | I | decoder 的新 message 候选 key/序号、绑定脉冲和续包查询 key。 |
| `som_candidate_valid`、`som_conflict`、`som_slot[2:0]`、`som_sqe[255:0]` | O | READY SQE 候选、ACTIVE key 冲突与候选内容。 |
| `lookup_valid`、`lookup_slot[2:0]`、`lookup_sqe[255:0]`、`lookup_next_seq[1:0]`、`lookup_seq_valid` | O | 续包命中的 ACTIVE slot、SQE 和期望序号；未完成前包时 `lookup_seq_valid=0`。 |
| `packet_commit_valid`、`packet_commit_slot[2:0]`、`packet_commit_bytes[31:0]`、`packet_commit_seq[1:0]`、`packet_commit_eom` | I | router 全段 B 成功后的包提交信息。 |
| `packet_commit_ready` | O | 对应 slot 为 ACTIVE 时接受包提交。 |
| `message_done_valid`、`message_done_slot[2:0]`、`message_done_update[255:0]`、`message_done_status[7:0]`、`message_done_abort` | I | 完成控制产生的 SQE 长度更新与最终状态。 |
| `message_done_ready` | O | 对应 slot 可收口，且与同 slot packet commit 不冲突。 |
| `m_axi_awvalid`、`m_axi_awaddr[ADDR_WIDTH-1:0]`、`m_axi_awlen[7:0]`、`m_axi_awsize[2:0]`、`m_axi_awburst[1:0]`、`m_axi_wvalid`、`m_axi_wdata[511:0]`、`m_axi_wstrb[63:0]`、`m_axi_wlast`、`m_axi_bready` | O | RX SQE 写回 Fabric 的 AW/W 与 B 接收控制。 |
| `m_axi_awready`、`m_axi_wready`、`m_axi_bvalid`、`m_axi_bresp[1:0]`、`m_axi_bid[ID_WIDTH-1:0]` | I | 写回接受与结果。 |
| `cq_req_valid`、`cq_req_cid[15:0]`、`cq_req_status[7:0]`、`cq_req_candidate_rd[15:0]` | O | 向共享 CQ 提交 CID、Code 与可退休边界候选。 |
| `cq_req_ready`、`cq_publish_valid`、`cq_publish_success` | I | CQ 请求被接受及最后一个发布写的结果。 |
| `queue_fault`、`sqe_read_error_event`、`sqe_writeback_error_event`、`sqe_invalid_event` | O | 故障保持与 IRQ 事件。 |

### 13.7 `mctp_decoder`：RX AW/sideband 判定与 W 接收

**作用与方案：** AW 时从 sideband 确定 MCTP 头、EID 过滤和 slot；接收该 AW 后独占 W 至 WLAST。合法包写 RX buffer，丢弃包只数完 W 并产生 `drop_done`。`packet_*` 元数据与 buffer 数据在完整包可读时一同交给 router；详细场景见 §4.3。

| 接口信号 | 方向 | 作用 |
| --- | --- | --- |
| `s_axi_awvalid`、`s_axi_awmisc_info[63:0]`、`s_axi_aw_hdr_34dw[63:0]`、`s_axi_awlen[7:0]`、`s_axi_awsize[2:0]`、`s_axi_awburst[1:0]` | I | Controller RX AW 与 packet MCTP sideband。 |
| `s_axi_awready` | O | 响应 credit、上下文稳定且合法包有 buffer 或可丢弃时接受 AW。 |
| `s_axi_wvalid`、`s_axi_wdata[511:0]`、`s_axi_wstrb[63:0]`、`s_axi_wlast` | I | 当前 AW 的 W 流。 |
| `s_axi_wready` | O | 已接收 AW 后吸收 W，包括丢弃包。 |
| `response_credit`、`response_token[4:0]` | I | Response tracker 的空位与本 AW token。 |
| `filter_enable`、`rule_enable[3:0]`、`rule_drop[3:0]`、`rule_value[31:0]`、`rule_mask[31:0]`、`default_drop` | I | 新 SOM 的 Source EID 匹配规则。 |
| `som_key[19:0]`、`lookup_key[19:0]`、`som_bind` | O | 两种查询共用的 `{DEID,SEID,TO,Tag}` key 与 SOM 正式绑定脉冲。 |
| `som_candidate_valid`、`som_conflict`、`som_slot[2:0]`、`som_sqe[255:0]`、`lookup_valid`、`lookup_slot[2:0]`、`lookup_sqe[255:0]`、`lookup_seq_valid`、`lookup_next_seq[1:0]` | I | SQ Manager 的新 SQE 候选、续包上下文及期望序号。 |
| `lookup_timeout`、`store_bounds_ok`、`congestion_drop`、`current_timeout` | I | 超时、目的边界与拥塞判定；系统顶层对部分信号固定值，见 §12。 |
| `buf_free`、`buf_packet_valid` | I | buffer 空闲与已收满状态。 |
| `buf_reserve`、`buf_write`、`buf_wr_addr[3:0]`、`buf_wr_data[511:0]`、`buf_wr_strb[63:0]`、`buf_finish`、`buf_finish_good` | O | 预留、逐 beat 写入与 WLAST 完成控制。 |
| `buf_packet_ready`、`buf_packet_release` | O | 将 router 的接收/release 传给 buffer。 |
| `packet_valid`、`packet_token[4:0]`、`packet_slot[2:0]`、`packet_seq[1:0]`、`packet_eom`、`packet_som`、`packet_sqe[255:0]`、`packet_wbytes[10:0]`、`packet_beats[4:0]` | O | 交给 router 的完整 packet 元数据；valid 来自 buffer 可读状态。 |
| `packet_ready`、`packet_release` | I | router 接受与释放当前 packet。 |
| `drop_done_valid`、`drop_done_token[4:0]`、`drop_done_slot_valid`、`drop_done_was_store`、`drop_done_slot[2:0]` | O | 丢弃 packet 已完整吸收 W，可结束响应表 token 与完成控制等待。 |
| `drop_done_ready` | I | 丢弃完成事件消费者的接收能力；core 当前固定高。 |
| `drop_event_valid`、`drop_event_reason[3:0]`、`abort_event_valid`、`abort_event_slot[2:0]`、`abort_event_reason[3:0]` | O | 全局丢弃 IRQ 事件与已绑定 message 的终止事件。 |

### 13.8 `inbound_packet_buffer`：RX 存储转发缓存

**作用与方案：** 一组 16×(512 bit 数据 + 64 bit WSTRB) 的原始 beat RAM。状态 FREE→FILL→READY→DRAIN→FREE；`finish_good=0` 时由 FILL 直接释放。只保存一包，不修改字节顺序或 AW 地址。

| 接口信号 | 方向 | 作用 |
| --- | --- | --- |
| `free` | O | 当前可接受 `reserve`。 |
| `reserve`、`write_en`、`write_addr[3:0]`、`write_data[511:0]`、`write_strb[63:0]` | I | decoder 的预留与 beat 写入。 |
| `finish`、`finish_good` | I | WLAST 已到及 packet 是否可供 router 使用。 |
| `packet_valid` | O | READY 状态下拉高，表明完整包可读。 |
| `packet_ready`、`packet_release` | I | router 开始处理与结束释放。 |
| `read_addr[3:0]` | I | router 指定读取 beat 序号。 |
| `read_data[511:0]`、`read_strb[63:0]` | O | 对应 beat 的原始 WDATA/WSTRB。 |

### 13.9 `inbound_router`：RX packet 到 Fabric 的写调度

**作用与方案：** 接受完整 packet，检验连续 WSTRB；依据 SQE 地址或该 slot `next_addr` 重排 64 B beat，并按 4 KiB 切割成一或多笔 Fabric AW/W。每段等 B，全部成功才提交 packet 并输出结果，随后释放 RX buffer。

| 接口信号 | 方向 | 作用 |
| --- | --- | --- |
| `packet_valid`、`packet_token[4:0]`、`packet_slot[2:0]`、`packet_som`、`packet_eom`、`packet_seq[1:0]`、`packet_wbytes[10:0]`、`packet_beats[4:0]`、`packet_sqe[255:0]` | I | decoder 提供的完整包属性、响应 token 与目标 SQE。 |
| `packet_ready`、`packet_release` | O | router 空闲时接收包、结果被消费后释放 buffer。 |
| `buf_rd_addr[3:0]` | O | 读取原始 W beat。 |
| `buf_rd_data[511:0]`、`buf_rd_strb[63:0]` | I | buffer 的原始 payload。 |
| `packet_commit_valid`、`packet_commit_slot[2:0]`、`packet_commit_bytes[31:0]`、`packet_commit_seq[1:0]`、`packet_commit_eom` | O | 全部 Fabric B 成功后的 message 进度更新。 |
| `packet_commit_ready` | I | SQ Manager 接受该 slot 的提交。 |
| `result_valid`、`result_token[4:0]`、`result_slot[2:0]`、`result_som`、`result_eom`、`result_bytes[10:0]`、`result_error`、`result_reason[3:0]`、`result_bresp[1:0]` | O | packet 最终结果，同时送响应表、完成控制和 timeout。 |
| `result_ready` | I | 下游接收结果；当前 core 固定为 1。 |
| `m_axi_awvalid`、`m_axi_awaddr[ADDR_WIDTH-1:0]`、`m_axi_awlen[7:0]`、`m_axi_awsize[2:0]`、`m_axi_awburst[1:0]`、`m_axi_wvalid`、`m_axi_wdata[511:0]`、`m_axi_wstrb[63:0]`、`m_axi_wlast`、`m_axi_bready` | O | Fabric 目的地址写 AW/W/B 控制。 |
| `m_axi_awready`、`m_axi_wready`、`m_axi_bvalid`、`m_axi_bresp[1:0]`、`m_axi_bid[ID_WIDTH-1:0]` | I | Fabric 写接受与每段 B。 |

### 13.10 `inbound_response_tracker`：Controller RX B 响应表

**作用与方案：** 16 项环形表，在 AW 握手时分配 token 和原 AWID，随后由 router 成功/错误结果或 decoder 丢弃结果标记完成。B 仅从表头按 AW 全局顺序出队；token 的高位是代数位，防止环回后误命中旧项。

| 接口信号 | 方向 | 作用 |
| --- | --- | --- |
| `alloc_valid`、`alloc_id[ID_WIDTH-1:0]` | I | 新 RX AW 已握手及其原始 AWID。 |
| `alloc_ready`、`alloc_token[4:0]` | O | 响应表 credit 与本 AW 分配的 token。 |
| `route_valid`、`route_token[4:0]`、`route_resp[1:0]` | I | router 已完成该 packet 及其真实本地结果。 |
| `drop_valid`、`drop_token[4:0]` | I | decoder 已吸收完被丢弃 packet 的 W，结果按 SLVERR 标记。 |
| `s_bvalid`、`s_bid[ID_WIDTH-1:0]`、`s_bresp[1:0]` | O | 返回 Controller 的有序 B。 |
| `s_bready` | I | Controller 消费 B，表头释放。 |

### 13.11 `inbound_message_completion`：RX message 收口

**作用与方案：** 每 slot 维护 pending packet、累计字节、EOM/abort 标志及错误码。只有该 slot 没有尚待 router 处理的已存储 packet，才交付 message_done。它只生成 SQE 长度更新与状态，不直接访问 Fabric/CQ。

| 接口信号 | 方向 | 作用 |
| --- | --- | --- |
| `store_valid`、`store_slot[2:0]`、`store_som` | I | decoder 预留正常包，标记该 slot 有包待转发；SOM 重置累计。 |
| `route_valid`、`route_slot[2:0]`、`route_som`、`route_eom`、`route_bytes[10:0]`、`route_error`、`route_reason[3:0]` | I | router 完成结果，累计长度或记录 `0x40+reason`。 |
| `abort_valid`、`abort_slot[2:0]`、`abort_reason[3:0]` | I | decoder 发现已绑定 message 的错误，记录 `0x20+reason`。 |
| `timeout_valid`、`timeout_slot[2:0]` | I | gap timeout 结束 message，Code 为 `0x26`。 |
| `drop_valid`、`drop_slot_valid`、`drop_slot[2:0]`、`drop_was_store` | I | 丢弃已预留包后清除该 slot 的 store_pending。 |
| `message_done_valid`、`message_done_slot[2:0]`、`message_done_update[255:0]`、`message_done_status[7:0]`、`message_done_abort` | O | 最终 slot、SQE LEN 更新、Completion Code 与异常标志。 |
| `message_done_ready` | I | SQ Manager 接受该结果后清除 pending。 |

### 13.12 `inbound_gap_timeout`：RX 续包间隔计时

**作用与方案：** 8 个独立计数器。成功转发非 EOM 后开始等待；同 slot 新 packet 在接收/路由期间暂停；完成、错误或 abort 时停止。只处理 message 的**包间隔**，不是 AXI B 延迟超时。

| 接口信号 | 方向 | 作用 |
| --- | --- | --- |
| `timeout_cycles[31:0]` | I | 每 slot 包间隔门限；0 禁用。 |
| `store_valid`、`store_slot[2:0]` | I | 该 slot 新正常 packet 进入 buffer，停止/暂停间隔计时。 |
| `route_valid`、`route_slot[2:0]`、`route_eom`、`route_error` | I | packet 转发结束；非 EOM 且无错时重新计时。 |
| `abort_valid`、`abort_slot[2:0]`、`done_valid`、`done_slot[2:0]` | I | 终止或回收该 slot 的计时状态。 |
| `timeout_valid`、`timeout_slot[2:0]` | O | 本周期超时事件及对应 slot。 |
| `expired[7:0]` | O | 每 slot 已超时锁存位，供 decoder 拒绝迟到续包。 |

### 13.13 `outbound_sq_prefetch`：TX SQ 预取封装

**作用与方案：** 例化 `inbound_sq_prefetch`，把深度固定为 256，提供 8 条 FIFO 预取能力；`sq_valid` 由 FIFO 非空产生。只负责获取 descriptor，不分配并行 TX message 上下文。

| 接口信号 | 方向 | 作用 |
| --- | --- | --- |
| `sq_base_addr[63:0]`、`sq_tail_ptr[15:0]` | I | TX SQ 内存基址与软件 Tail。 |
| `prefetch_req_valid`、`prefetch_sq_num[4:0]` | I | TX Manager 请求补充 FIFO 的条数。 |
| `prefetch_req_ready`、`prefetch_accept_num[4:0]` | O | 预取请求握手与接受条数。 |
| `m_axi_arvalid`、`m_axi_araddr[63:0]`、`m_axi_arlen[7:0]`、`m_axi_arsize[2:0]`、`m_axi_arburst[1:0]` | O | 读 Fabric TX SQE 的 AR。 |
| `m_axi_arready`、`m_axi_rvalid`、`m_axi_rdata[511:0]`、`m_axi_rresp[1:0]`、`m_axi_rlast`、`m_axi_rid[3:0]` | I | Fabric AR/R 返回。 |
| `m_axi_rready` | O | 预取 R 接收能力。 |
| `sq_pop` | I | TX Manager 消费 FIFO 头。 |
| `sq_count[3:0]`、`sq_valid`、`sq_dout[255:0]`、`sq_ptr[15:0]`、`sq_error` | O | 待发送 SQE 数、队头内容及来源下标/错误。 |
| `fault` | O | 预取配置/协议故障。 |

### 13.14 `outbound_sq_manager`：TX 顺序调度

**作用与方案：** FIFO 头一次仅进入一个 TX message 上下文。完成一次 message 后申请 CQE，直到 CQ publish success 才更新 TX RD_PTR 并弹出下一条的执行资格；预取 FIFO 可在执行期间继续填充。状态为 IDLE、RUN、CQ_REQ、CQ_WAIT、FAULT。

| 接口信号 | 方向 | 作用 |
| --- | --- | --- |
| `enable`、`sq_count[3:0]`、`sq_valid`、`sq_dout[255:0]`、`sq_ptr[15:0]`、`sq_error`、`prefetch_fault` | I | TX 使能、FIFO 队头与读取故障。 |
| `sq_pop` | O | 取走 FIFO 头；与软件可回收 RD_PTR 更新不是同一事件。 |
| `prefetch_req_valid`、`prefetch_sq_num[4:0]` | O | 按 FIFO 空位要求继续预取。 |
| `gen_desc_valid`、`gen_desc_sqe[255:0]` | O | 向 packet generator 提交新 descriptor。 |
| `gen_desc_ready`、`gen_done_valid`、`gen_done_status[7:0]` | I | Generator 接受 descriptor、完成发送及结果。 |
| `gen_done_ready`、`gen_publish_valid`、`gen_publish_success` | O | 接受 generator 完成，并反馈 CQE 发布结果以释放其 descriptor。 |
| `cq_req_valid`、`cq_req_cid[15:0]`、`cq_req_sq_ptr[15:0]`、`cq_req_status[7:0]`、`cq_req_candidate_rd[15:0]` | O | 提交共享 CQ 的标识、结果和预计 RD_PTR；`cq_req_sq_ptr` 当前未被 CQ Manager 使用。 |
| `cq_req_ready`、`cq_publish_valid`、`cq_publish_success` | I | CQ 请求被接受及发布结果。 |
| `sq_rd_ptr[15:0]`、`queue_fault`、`sqe_read_error_event`、`sqe_invalid_event` | O | 软件可读 TX RD_PTR、故障保持与 IRQ 事件。 |

### 13.15 `outbound_payload_reader`：Fabric 载荷 DMA 读取

**作用与方案：** 按 generator 指定的单包起始地址和字节数，规划 64 B/4 B/1 B INCR 读；每笔不跨 4 KiB，一次一笔 AR 在途；把有效字节紧凑写入 `outbound_packet_buffer`。RRESP/RID/RLAST 不符则报告 `packet_error`，必要时进入 DRAIN 消耗异常 R 流。

| 接口信号 | 方向 | 作用 |
| --- | --- | --- |
| `start_valid`、`start_addr[63:0]`、`start_len[10:0]` | I | Generator 的一包载荷读取请求，长度单位为字节。 |
| `start_ready` | O | Reader 空闲可接收新包。 |
| `packet_valid`、`packet_error`、`packet_len[10:0]` | O | 一包已完整读到片上、错误标志及锁存的请求长度。 |
| `packet_release`、`read_index[3:0]` | I | Generator 释放缓存和选取 64 B 行。 |
| `read_data[511:0]` | O | 从 packed buffer 读出的发送 payload。 |
| `m_axi_arvalid`、`m_axi_araddr[63:0]`、`m_axi_arlen[7:0]`、`m_axi_arsize[2:0]`、`m_axi_arburst[1:0]` | O | Fabric payload AR。 |
| `m_axi_arready`、`m_axi_rvalid`、`m_axi_rdata[511:0]`、`m_axi_rresp[1:0]`、`m_axi_rlast`、`m_axi_rid[3:0]` | I | Fabric 请求接受与 R。 |
| `m_axi_rready` | O | Reader 可接收或排空 R。 |

`packet_len` 是 Reader 与内部 buffer 的实际有效长度；core 虽然引出该信号，目前 generator 不直接使用，generator 用自身的 `packet_bytes` 控制 WSTRB。

### 13.16 `outbound_packet_buffer`：TX 1 KiB 字节存储体

**作用与方案：** 以 1024×8 bit 组织单包缓存。写端从 Fabric 512 bit R beat 中按实际 ARSIZE 和源 lane 抽取字节，连续写入 `write_base`；读端以 64 B 行号组合输出，不足 `packet_len` 的字节补零。缓存无自己的 valid/ready 状态机，生命周期由 Reader 管理。

| 接口信号 | 方向 | 作用 |
| --- | --- | --- |
| `clk` | I | 同步写时钟；本模块无独立复位端口。 |
| `write_en`、`write_base[10:0]`、`write_lane[5:0]`、`write_size[2:0]`、`write_data[511:0]` | I | Reader 写入字节的目标偏移、源 lane、AXI beat 大小和数据。 |
| `packet_len[10:0]`、`read_index[3:0]` | I | 有效字节范围与 generator 读取的 64 B 行号。 |
| `read_data[511:0]` | O | 当前行有效字节，越过 `packet_len` 的字节为零。 |

### 13.17 `outbound_packet_gen`：MCTP TX packet 化

**作用与方案：** 锁存一条 TX SQE，按 TUZ 切成多包；逐包发起 Reader 请求、生成 header SOM/EOM/序号与零 padding，向 Controller 完成 AW→W→B。末包 B 成功后向 Manager 报 done；直到 CQ publish result 到来才释放 descriptor。状态机与边界检查见 §5.3。

| 接口信号 | 方向 | 作用 |
| --- | --- | --- |
| `desc_valid`、`desc_sqe[255:0]`、`tuz_bytes[10:0]`、`target_addr[63:0]`、`start_seq[1:0]` | I | Manager 提交 SQE、单包最大有效载荷、Controller 地址与首包序号。 |
| `desc_ready` | O | IDLE 时接收下一条 SQE。 |
| `reader_start_valid`、`reader_start_addr[63:0]`、`reader_start_len[10:0]` | O | 向 Reader 请求读取当前 packet 的有效载荷。 |
| `reader_start_ready`、`reader_packet_valid`、`reader_packet_error`、`reader_data[511:0]` | I | Reader 接受、包完成/出错以及所选 64 B 行。 |
| `reader_release`、`reader_index[3:0]` | O | 释放已发送或读取失败的缓存，选择 WDATA 行。 |
| `m_axi_awvalid`、`m_axi_awaddr[63:0]`、`m_axi_awlen[7:0]`、`m_axi_awsize[2:0]`、`m_axi_awburst[1:0]`、`m_axi_awid[3:0]`、`m_axi_awlock`、`m_axi_awcache[3:0]`、`m_axi_awprot[2:0]`、`m_axi_awqos[3:0]`、`m_axi_awregion[3:0]` | O | Controller 的一包 AW 属性。 |
| `m_axi_awmisc_info_hdr_34dw[63:0]`、`m_axi_awmisc_info[20:0]`、`m_axi_awmisc_info_p_tag[9:0]` | O | 与 AW 同步的三路 Controller sideband。 |
| `m_axi_awready` | I | Controller 接受 AW。 |
| `m_axi_wvalid`、`m_axi_wdata[511:0]`、`m_axi_wstrb[63:0]`、`m_axi_wlast` | O | 包 payload、零 padding 和 WLAST。 |
| `m_axi_wready`、`m_axi_bvalid`、`m_axi_bresp[1:0]`、`m_axi_bid[3:0]` | I | Controller W credit 与本包 B。 |
| `m_axi_bready` | O | 接受 Controller B。 |
| `done_valid`、`done_status[7:0]` | O | 整条 message 的本地发送结果，送 TX Manager。 |
| `done_ready`、`publish_valid`、`publish_success` | I | Manager 接受 done，并反馈 CQE 是否完成发布。 |

### 13.18 `shared_cq_manager`：RX/TX 共用 CQ 发布

**作用与方案：** 两路请求公平轮询，检查深度、head、base 和空满；构造 16 B CQE，先写低 15 B、等 B，再写含 Phase 的最后 1 B、等 B，成功才向原方向反馈并推进 `cq_tail`。状态为 IDLE、BODY_AW/W/B、PHASE_AW/W/B、PUBLISH、FAULT。

| 接口信号 | 方向 | 作用 |
| --- | --- | --- |
| `cq_base_addr[ADDR_WIDTH-1:0]`、`cq_depth[15:0]`、`cq_head[15:0]` | I | CQ 内存位置、深度与软件释放边界。 |
| `cq_tail[15:0]` | O | 已成功发布 CQE 的物理尾指针。 |
| `rx_req_valid`、`rx_req_cid[15:0]`、`rx_req_status[7:0]`、`rx_req_candidate_rd[15:0]` | I | RX Manager 的完成请求。 |
| `rx_req_ready`、`rx_publish_valid`、`rx_publish_success` | O | RX 请求握手与最终 CQE 发布回执。 |
| `tx_req_valid`、`tx_req_cid[15:0]`、`tx_req_status[7:0]`、`tx_req_candidate_rd[15:0]` | I | TX Manager 的完成请求。 |
| `tx_req_ready`、`tx_publish_valid`、`tx_publish_success` | O | TX 请求握手与最终发布回执。 |
| `completion_event`、`fault` | O | 发布成功 IRQ 事件与粘滞故障。 |
| `m_axi_awvalid`、`m_axi_awaddr[ADDR_WIDTH-1:0]`、`m_axi_awlen[7:0]`、`m_axi_awsize[2:0]`、`m_axi_awburst[1:0]`、`m_axi_wvalid`、`m_axi_wdata[511:0]`、`m_axi_wstrb[63:0]`、`m_axi_wlast`、`m_axi_bready` | O | 写 CQE 的两次 Fabric AW/W/B 控制。 |
| `m_axi_awready`、`m_axi_wready`、`m_axi_bvalid`、`m_axi_bresp[1:0]`、`m_axi_bid[ID_WIDTH-1:0]` | I | Fabric 接受写入与 B 结果。 |

### 13.19 `inbound_irq_status`：中断状态与电平

**作用与方案：** 每 bit 为 sticky 事件锁存，软件 W1C 清除，事件置位优先于同周期清除。输出为状态与 mask 的按位与之或，不产生单周期中断脉冲。

| 接口信号 | 方向 | 作用 |
| --- | --- | --- |
| `event_set[7:0]` | I | 来自 RX/TX/CQ 组合的单周期事件。 |
| `clear[7:0]` | I | APB 写 1 清除对应状态位。 |
| `mask[7:0]` | I | 控制哪些状态可驱动 SoC IRQ。 |
| `status[7:0]` | O | 软件可读粘滞错误/完成状态。 |
| `irq` | O | `|(status & mask)` 的持续电平。 |

### 13.20 `axi_rd3t1_bridge`：Fabric 读 3:1 合流

**作用与方案：** 在 RX 预取、TX 预取和 TX payload Reader 的 AR 间轮询；AR 握手后将 2 bit 来源号压 tag FIFO，并推进仲裁起点。R 依据 FIFO 队头路由至原源，只有 RLAST 握手才弹标签。ARVALID 被反压时锁住已选源；所有源使用同一 ARID。

| 接口信号 | 方向 | 作用 |
| --- | --- | --- |
| `s_arvalid[2:0]`、`s_arid[3*ID_WIDTH-1:0]`、`s_araddr[3*ADDR_WIDTH-1:0]`、`s_arlen[23:0]`、`s_arsize[8:0]`、`s_arburst[5:0]`、`s_arlock[2:0]`、`s_arcache[11:0]`、`s_arprot[8:0]`、`s_arqos[11:0]`、`s_arregion[11:0]` | I | 三路打包 AR；每路字段按源编号切片。 |
| `s_arready[2:0]` | O | 仅对当前 AR 握手的源返回 ready。 |
| `s_rready[2:0]` | I | 三个源各自的 R 接收能力。 |
| `s_rvalid[2:0]`、`s_rid[3*ID_WIDTH-1:0]`、`s_rdata[3*DATA_WIDTH-1:0]`、`s_rresp[5:0]`、`s_rlast[2:0]` | O | 按标签选通的 R valid；数据/属性复制到各切片，只有选中源 valid。 |
| `m_arvalid`、`m_arid[ID_WIDTH-1:0]`、`m_araddr[ADDR_WIDTH-1:0]`、`m_arlen[7:0]`、`m_arsize[2:0]`、`m_arburst[1:0]`、`m_arlock`、`m_arcache[3:0]`、`m_arprot[2:0]`、`m_arqos[3:0]`、`m_arregion[3:0]` | O | 送 Fabric 的仲裁后 AR。 |
| `m_arready`、`m_rvalid`、`m_rid[ID_WIDTH-1:0]`、`m_rdata[DATA_WIDTH-1:0]`、`m_rresp[1:0]`、`m_rlast` | I | Fabric 请求接受及 R。 |
| `m_rready` | O | 当前标签指定源的 R ready。 |

### 13.21 `axi_wr3t1_bridge`：Fabric 写 3:1 合流

**作用与方案：** 在 RX router、RX SQE 写回和 CQE 写入之间轮询 AW。AW 接受后记住 W 源，直到 WLAST 握手才允许选下一笔 AW，并推进仲裁起点；B 来源另以 FIFO 按 AW 接受顺序保存，允许更早事务等待 B。AWVALID 反压时锁住已选源；所有源使用同一 AWID。

| 接口信号 | 方向 | 作用 |
| --- | --- | --- |
| `s_awvalid[2:0]`、`s_awid[3*ID_WIDTH-1:0]`、`s_awaddr[3*ADDR_WIDTH-1:0]`、`s_awlen[23:0]`、`s_awsize[8:0]`、`s_awburst[5:0]`、`s_awlock[2:0]`、`s_awcache[11:0]`、`s_awprot[8:0]`、`s_awqos[11:0]`、`s_awregion[11:0]` | I | 三路打包 AW。 |
| `s_awready[2:0]` | O | 当前 AW 被 Fabric 接受时只通知其源。 |
| `s_wvalid[2:0]`、`s_wdata[3*DATA_WIDTH-1:0]`、`s_wstrb[3*(DATA_WIDTH/8)-1:0]`、`s_wlast[2:0]` | I | 当前 AW 源的 W 数据。 |
| `s_wready[2:0]` | O | 仅当前 AW 源得到 W ready。 |
| `s_bready[2:0]` | I | 各源接收 B 的能力。 |
| `s_bvalid[2:0]`、`s_bid[3*ID_WIDTH-1:0]`、`s_bresp[5:0]` | O | 根据 B 标签选通 valid，并复制 BID/BRESP。 |
| `m_awvalid`、`m_awid[ID_WIDTH-1:0]`、`m_awaddr[ADDR_WIDTH-1:0]`、`m_awlen[7:0]`、`m_awsize[2:0]`、`m_awburst[1:0]`、`m_awlock`、`m_awcache[3:0]`、`m_awprot[2:0]`、`m_awqos[3:0]`、`m_awregion[3:0]` | O | 送 Fabric 的仲裁后 AW。 |
| `m_awready`、`m_wready`、`m_bvalid`、`m_bid[ID_WIDTH-1:0]`、`m_bresp[1:0]` | I | Fabric 写接受与 B。 |
| `m_wvalid`、`m_wdata[DATA_WIDTH-1:0]`、`m_wstrb[DATA_WIDTH/8-1:0]`、`m_wlast`、`m_bready` | O | 所选源的 W 与相应 B 接收 ready。 |

### 13.22 `axi_rr_arbiter3`：三请求公平轮询

**作用与方案：** 维护下次优先搜索的源编号。组合逻辑从该编号起查找 `req_i`，`advance_i` 时把起点移到 `advance_src_i` 的下一源；读桥在 AR 握手推进，写桥在 WLAST 握手推进。该模块不直接观察 AXI 通道。

| 接口信号 | 方向 | 作用 |
| --- | --- | --- |
| `req_i[2:0]` | I | 三个请求有效位。 |
| `advance_i`、`advance_src_i[1:0]` | I | 当前源的服务完成通知及源编号。 |
| `grant_valid_o`、`grant_idx_o[1:0]` | O | 是否有请求、当前选中源。 |

### 13.23 `axi_tag_fifo`：读/写返回源标签

**作用与方案：** 小型同步 FIFO，默认 `WIDTH=2`、`DEPTH=8`，保持 AR 或 AW 接受顺序。读桥在 RLAST 握手弹出，写桥在 B 握手弹出。满时不接受新 push，调用方必须用 `full_o` 阻止新 AR/AW。

| 接口信号 | 方向 | 作用 |
| --- | --- | --- |
| `push_i`、`push_data_i[WIDTH-1:0]` | I | 记录刚被 Fabric 接受的源编号。 |
| `pop_i` | I | 当前事务 RLAST/B 被原源消费后移除队头。 |
| `head_data_o[WIDTH-1:0]` | O | 当前返回应路由到的源编号。 |
| `full_o`、`empty_o` | O | 请求 credit 与非法返回保护。 |

## 14. 对应 RTL 文件

| 功能 | 主要文件 |
| --- | --- |
| 系统顶层与内部连接 | [`mctp_engine.v`](RTL/mctp_engine.v)、[`mctp_engine_core.v`](RTL/mctp_engine_core.v) |
| APB | [`apb_interface.v`](RTL/apb_interface.v) |
| RX | [`inbound_sq_prefetch.v`](RTL/inbound_sq_prefetch.v)、[`inbound_sq_manager.v`](RTL/inbound_sq_manager.v)、[`mctp_decoder.v`](RTL/mctp_decoder.v)、[`inbound_packet_buffer.v`](RTL/inbound_packet_buffer.v)、[`inbound_router.v`](RTL/inbound_router.v)、[`inbound_message_completion.v`](RTL/inbound_message_completion.v)、[`inbound_gap_timeout.v`](RTL/inbound_gap_timeout.v)、[`inbound_response_tracker.v`](RTL/inbound_response_tracker.v) |
| TX | [`outbound_sq_prefetch.v`](RTL/outbound_sq_prefetch.v)、[`outbound_sq_manager.v`](RTL/outbound_sq_manager.v)、[`outbound_payload_reader.v`](RTL/outbound_payload_reader.v)、[`outbound_packet_buffer.v`](RTL/outbound_packet_buffer.v)、[`outbound_packet_gen.v`](RTL/outbound_packet_gen.v) |
| 预取 FIFO | [`sync_fifo.v`](RTL/sync_fifo.v) |
| 共享完成/中断 | [`shared_cq_manager.v`](RTL/shared_cq_manager.v)、[`inbound_irq_status.v`](RTL/inbound_irq_status.v) |
| Fabric 仲裁 | [`axi_rd3t1_bridge.v`](RTL/axi_rd3t1_bridge.v)、[`axi_wr3t1_bridge.v`](RTL/axi_wr3t1_bridge.v)、[`axi_rr_arbiter3.v`](RTL/axi_rr_arbiter3.v)、[`axi_tag_fifo.v`](RTL/axi_tag_fifo.v) |
| Controller sideband 位定义 | [`sideband_format.md`](RTL/sideband_format.md) |

