`timescale 1ns/1ps

// Three-request round-robin selector. The caller decides when a transaction
// has completed and reports that source through advance_src_i.
module axi_rr_arbiter3 (
    input  wire       clk,
    input  wire       rst_n,
    input  wire [2:0] req_i,
    input  wire       advance_i,
    input  wire [1:0] advance_src_i,
    output reg        grant_valid_o,
    output reg  [1:0] grant_idx_o
);
    reg [1:0] next_idx;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            next_idx <= 2'd0;
        else if (advance_i) begin
            case (advance_src_i)
                2'd0: next_idx <= 2'd1;
                2'd1: next_idx <= 2'd2;
                default: next_idx <= 2'd0;
            endcase
        end
    end

    always @* begin
        grant_valid_o = |req_i;
        grant_idx_o = 2'd0;
        case (next_idx)
            2'd0: begin
                if (req_i[0]) grant_idx_o = 2'd0;
                else if (req_i[1]) grant_idx_o = 2'd1;
                else if (req_i[2]) grant_idx_o = 2'd2;
            end
            2'd1: begin
                if (req_i[1]) grant_idx_o = 2'd1;
                else if (req_i[2]) grant_idx_o = 2'd2;
                else if (req_i[0]) grant_idx_o = 2'd0;
            end
            default: begin
                if (req_i[2]) grant_idx_o = 2'd2;
                else if (req_i[0]) grant_idx_o = 2'd0;
                else if (req_i[1]) grant_idx_o = 2'd1;
            end
        endcase
    end
endmodule
