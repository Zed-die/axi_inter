`timescale 1ns/1ps

// APB register bank and direct/APB configuration selection for both directions.
// APB transfers complete in one access cycle; USE_APB selects the control source.
module apb_interface #(
    parameter USE_APB = 1'b0
) (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        psel,
    input  wire        penable,
    input  wire        pwrite,
    input  wire [7:0]  paddr,
    input  wire [31:0] pwdata,
    output reg  [31:0] prdata,
    output wire        pready,
    output wire        pslverr,
    input  wire        direct_enable,
    input  wire [63:0] direct_sq_base_addr,
    input  wire [15:0] direct_sq_tail_ptr,
    input  wire [63:0] direct_cq_base_addr,
    input  wire [8:0]  direct_cq_head,
    input  wire        direct_filter_enable,
    input  wire        direct_default_drop,
    input  wire [3:0]  direct_rule_enable,
    input  wire [3:0]  direct_rule_drop,
    input  wire [31:0] direct_rule_value,
    input  wire [31:0] direct_rule_mask,
    input  wire [7:0]  direct_irq_mask,
    input  wire [7:0]  direct_irq_clear,
    input  wire [31:0] direct_message_timeout_cycles,
    input  wire [31:0] direct_congestion_timeout_cycles,
    input  wire        direct_tx_enable,
    input  wire [63:0] direct_tx_sq_base_addr,
    input  wire [15:0] direct_tx_sq_tail_ptr,
    input  wire [10:0] direct_tx_tuz_bytes,
    input  wire [63:0] direct_tx_target_addr,
    input  wire [1:0]  direct_tx_start_seq,
    input  wire [7:0]  irq_status,
    input  wire [8:0]  cq_tail,
    input  wire [15:0] sq_rd_ptr,
    input  wire [15:0] tx_sq_rd_ptr,
    output wire        cfg_enable,
    output wire [63:0] cfg_sq_base_addr,
    output wire [15:0] cfg_sq_tail_ptr,
    output wire [8:0]  cfg_sq_depth,
    output wire [63:0] cfg_cq_base_addr,
    output wire [8:0]  cfg_cq_head,
    output wire        cfg_filter_enable,
    output wire        cfg_default_drop,
    output wire [3:0]  cfg_rule_enable,
    output wire [3:0]  cfg_rule_drop,
    output wire [31:0] cfg_rule_value,
    output wire [31:0] cfg_rule_mask,
    output wire [7:0]  cfg_irq_mask,
    output wire [7:0]  cfg_irq_clear,
    output wire [31:0] cfg_message_timeout_cycles,
    output wire [31:0] cfg_congestion_timeout_cycles,
    output wire        cfg_tx_enable,
    output wire [63:0] cfg_tx_sq_base_addr,
    output wire [15:0] cfg_tx_sq_tail_ptr,
    output wire [10:0] cfg_tx_tuz_bytes,
    output wire [63:0] cfg_tx_target_addr,
    output wire [1:0]  cfg_tx_start_seq
);
    reg enable, filter_enable, default_drop, tx_enable;
    reg [63:0] sq_base_addr, cq_base_addr, tx_sq_base_addr, tx_target_addr;
    reg [15:0] sq_tail_ptr, tx_sq_tail_ptr;
    reg [8:0] sq_depth;
    reg sq_depth_locked;
    reg [8:0] cq_head;
    reg [3:0] rule_enable, rule_drop;
    reg [31:0] rule_value, rule_mask;
    reg [7:0] irq_mask;
    reg [31:0] message_timeout_cycles, congestion_timeout_cycles;
    reg [10:0] tx_tuz_bytes;
    reg [1:0] tx_start_seq;
    wire [7:0] irq_clear;
    assign cfg_enable = USE_APB ? enable : direct_enable;
    assign cfg_sq_base_addr = USE_APB ? sq_base_addr : direct_sq_base_addr;
    assign cfg_sq_tail_ptr = USE_APB ? sq_tail_ptr : direct_sq_tail_ptr;
    assign cfg_sq_depth = USE_APB ? sq_depth : 9'd256;
    assign cfg_cq_base_addr = USE_APB ? cq_base_addr : direct_cq_base_addr;
    assign cfg_cq_head = USE_APB ? cq_head : direct_cq_head;
    assign cfg_filter_enable = USE_APB ? filter_enable : direct_filter_enable;
    assign cfg_default_drop = USE_APB ? default_drop : direct_default_drop;
    assign cfg_rule_enable = USE_APB ? rule_enable : direct_rule_enable;
    assign cfg_rule_drop = USE_APB ? rule_drop : direct_rule_drop;
    assign cfg_rule_value = USE_APB ? rule_value : direct_rule_value;
    assign cfg_rule_mask = USE_APB ? rule_mask : direct_rule_mask;
    assign cfg_irq_mask = USE_APB ? irq_mask : direct_irq_mask;
    assign cfg_irq_clear = USE_APB ? irq_clear : direct_irq_clear;
    assign cfg_message_timeout_cycles = USE_APB ?
        message_timeout_cycles : direct_message_timeout_cycles;
    assign cfg_congestion_timeout_cycles = USE_APB ?
        congestion_timeout_cycles : direct_congestion_timeout_cycles;
    assign cfg_tx_enable = USE_APB ? tx_enable : direct_tx_enable;
    assign cfg_tx_sq_base_addr = USE_APB ? tx_sq_base_addr : direct_tx_sq_base_addr;
    assign cfg_tx_sq_tail_ptr = USE_APB ? tx_sq_tail_ptr : direct_tx_sq_tail_ptr;
    assign cfg_tx_tuz_bytes = USE_APB ? tx_tuz_bytes : direct_tx_tuz_bytes;
    assign cfg_tx_target_addr = USE_APB ? tx_target_addr : direct_tx_target_addr;
    assign cfg_tx_start_seq = USE_APB ? tx_start_seq : direct_tx_start_seq;
    wire access = psel && penable;
    wire write_access = access && pwrite;
    wire depth_write = write_access && paddr == 8'h14;
    wire depth_value_valid = pwdata[31:9] == 0 && pwdata[8:0] >= 9'd2 &&
                             pwdata[8:0] <= 9'd256 &&
                             (pwdata[8:0] & (pwdata[8:0] - 9'd1)) == 0;
    reg valid_addr;
    assign pready = 1'b1;
    assign pslverr = access && (!valid_addr || paddr[1:0] != 0 ||
                     (depth_write && (enable || sq_depth_locked || !depth_value_valid)));
    assign irq_clear = write_access && paddr == 8'h44 ? pwdata[7:0] : 8'd0;

    always @* begin
        valid_addr = 1'b1;
        prdata = 32'd0;
        case (paddr)
            8'h00: prdata = {31'd0, enable};
            8'h08: prdata = sq_base_addr[31:0];
            8'h0c: prdata = sq_base_addr[63:32];
            8'h10: prdata = {16'd0, sq_tail_ptr};
            8'h14: prdata = {23'd0, sq_depth};
            8'h18: prdata = cq_base_addr[31:0];
            8'h1c: prdata = cq_base_addr[63:32];
            8'h20: prdata = {23'd0, cq_head};
            8'h28: prdata = {30'd0, default_drop, filter_enable};
            8'h2c: prdata = {24'd0, rule_drop, rule_enable};
            8'h30: prdata = rule_value;
            8'h34: prdata = rule_mask;
            8'h40: prdata = {24'd0, irq_mask};
            8'h44: prdata = {24'd0, irq_status};
            8'h48: prdata = {23'd0, cq_tail};
            8'h4c: prdata = {16'd0, sq_rd_ptr};
            8'h50: prdata = message_timeout_cycles;
            8'h54: prdata = congestion_timeout_cycles;
            8'h60: prdata = {31'd0, tx_enable};
            8'h68: prdata = tx_sq_base_addr[31:0];
            8'h6c: prdata = tx_sq_base_addr[63:32];
            8'h70: prdata = {16'd0, tx_sq_tail_ptr};
            8'h74: prdata = {21'd0, tx_tuz_bytes};
            8'h78: prdata = tx_target_addr[31:0];
            8'h7c: prdata = tx_target_addr[63:32];
            8'h80: prdata = {30'd0, tx_start_seq};
            8'h84: prdata = {16'd0, tx_sq_rd_ptr};
            default: valid_addr = 1'b0;
        endcase
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            enable <= 1'b0;
            sq_base_addr <= 64'd0;
            sq_tail_ptr <= 16'd0;
            sq_depth <= 9'd256;
            sq_depth_locked <= 1'b0;
            cq_base_addr <= 64'd0;
            cq_head <= 9'd0;
            filter_enable <= 1'b0;
            default_drop <= 1'b0;
            rule_enable <= 4'd0;
            rule_drop <= 4'd0;
            rule_value <= 32'd0;
            rule_mask <= 32'd0;
            irq_mask <= 8'd0;
            message_timeout_cycles <= 32'd0;
            congestion_timeout_cycles <= 32'd0;
            tx_enable <= 1'b0;
            tx_sq_base_addr <= 64'd0;
            tx_sq_tail_ptr <= 16'd0;
            tx_tuz_bytes <= 11'd512;
            tx_target_addr <= 64'd0;
            tx_start_seq <= 2'd0;
        end else begin
            if (enable) sq_depth_locked <= 1'b1;
            if (write_access && !pslverr) begin
            case (paddr)
                8'h00: enable <= pwdata[0];
                8'h08: sq_base_addr[31:0] <= pwdata;
                8'h0c: sq_base_addr[63:32] <= pwdata;
                8'h10: sq_tail_ptr <= pwdata[15:0];
                8'h14: sq_depth <= pwdata[8:0];
                8'h18: cq_base_addr[31:0] <= pwdata;
                8'h1c: cq_base_addr[63:32] <= pwdata;
                8'h20: cq_head <= pwdata[8:0];
                8'h28: begin
                    filter_enable <= pwdata[0];
                    default_drop <= pwdata[1];
                end
                8'h2c: begin
                    rule_enable <= pwdata[3:0];
                    rule_drop <= pwdata[7:4];
                end
                8'h30: rule_value <= pwdata;
                8'h34: rule_mask <= pwdata;
                8'h40: irq_mask <= pwdata[7:0];
                8'h50: message_timeout_cycles <= pwdata;
                8'h54: congestion_timeout_cycles <= pwdata;
                8'h60: tx_enable <= pwdata[0];
                8'h68: tx_sq_base_addr[31:0] <= pwdata;
                8'h6c: tx_sq_base_addr[63:32] <= pwdata;
                8'h70: tx_sq_tail_ptr <= pwdata[15:0];
                8'h74: tx_tuz_bytes <= pwdata[10:0];
                8'h78: tx_target_addr[31:0] <= pwdata;
                8'h7c: tx_target_addr[63:32] <= pwdata;
                8'h80: tx_start_seq <= pwdata[1:0];
                default: begin end
            endcase
            end
        end
    end
endmodule
