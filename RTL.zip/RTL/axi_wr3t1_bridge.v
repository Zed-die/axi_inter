`timescale 1ns/1ps

// AXI4 write-channel 3-to-1 bridge. At most one accepted AW has unfinished
// W data. Older writes may still await B, tracked by the source-tag FIFO.
// All three sources must use the same AWID; B responses must return in order.
module axi_wr3t1_bridge #(
    parameter integer ADDR_WIDTH = 64,
    parameter integer DATA_WIDTH = 256,
    parameter integer ID_WIDTH = 4,
    parameter integer TAG_DEPTH = 8
) (
    input  wire                         clk,
    input  wire                         rst_n,
    input  wire [3*ID_WIDTH-1:0]        s_awid,
    input  wire [3*ADDR_WIDTH-1:0]      s_awaddr,
    input  wire [23:0]                  s_awlen,
    input  wire [8:0]                   s_awsize,
    input  wire [5:0]                   s_awburst,
    input  wire [2:0]                   s_awlock,
    input  wire [11:0]                  s_awcache,
    input  wire [8:0]                   s_awprot,
    input  wire [11:0]                  s_awqos,
    input  wire [11:0]                  s_awregion,
    input  wire [2:0]                   s_awvalid,
    output wire [2:0]                   s_awready,
    input  wire [3*DATA_WIDTH-1:0]      s_wdata,
    input  wire [3*(DATA_WIDTH/8)-1:0]  s_wstrb,
    input  wire [2:0]                   s_wlast,
    input  wire [2:0]                   s_wvalid,
    output wire [2:0]                   s_wready,
    output wire [3*ID_WIDTH-1:0]        s_bid,
    output wire [5:0]                   s_bresp,
    output wire [2:0]                   s_bvalid,
    input  wire [2:0]                   s_bready,
    output wire [ID_WIDTH-1:0]          m_awid,
    output wire [ADDR_WIDTH-1:0]        m_awaddr,
    output wire [7:0]                   m_awlen,
    output wire [2:0]                   m_awsize,
    output wire [1:0]                   m_awburst,
    output wire                         m_awlock,
    output wire [3:0]                   m_awcache,
    output wire [2:0]                   m_awprot,
    output wire [3:0]                   m_awqos,
    output wire [3:0]                   m_awregion,
    output wire                         m_awvalid,
    input  wire                         m_awready,
    output wire [DATA_WIDTH-1:0]        m_wdata,
    output wire [(DATA_WIDTH/8)-1:0]    m_wstrb,
    output wire                         m_wlast,
    output wire                         m_wvalid,
    input  wire                         m_wready,
    input  wire [ID_WIDTH-1:0]          m_bid,
    input  wire [1:0]                   m_bresp,
    input  wire                         m_bvalid,
    output wire                         m_bready
);
    wire grant_valid;
    wire [1:0] grant_idx;
    reg held;
    reg [1:0] held_idx;
    wire [1:0] aw_src = held ? held_idx : grant_idx;
    wire aw_src_valid = held ? s_awvalid[held_idx] : grant_valid;
    reg w_active;
    reg [1:0] w_src;
    wire aw_fire;
    wire w_fire_last;
    wire [1:0] b_src;
    wire b_tags_full;
    wire b_tags_empty;
    wire b_fire;

    axi_rr_arbiter3 u_arbiter (
        .clk           (clk),
        .rst_n         (rst_n),
        .req_i         (s_awvalid),
        .advance_i     (w_fire_last),
        .advance_src_i (w_src),
        .grant_valid_o (grant_valid),
        .grant_idx_o   (grant_idx)
    );

    axi_tag_fifo #(
        .WIDTH (2),
        .DEPTH (TAG_DEPTH)
    ) u_b_source_fifo (
        .clk         (clk),
        .rst_n       (rst_n),
        .push_i      (aw_fire),
        .push_data_i (aw_src),
        .pop_i       (b_fire),
        .head_data_o (b_src),
        .full_o      (b_tags_full),
        .empty_o     (b_tags_empty)
    );

    assign m_awvalid = rst_n && !w_active && !b_tags_full && aw_src_valid;
    assign aw_fire = m_awvalid && m_awready;
    assign s_awready = aw_fire ? (3'b001 << aw_src) : 3'b000;

    assign m_awid     = s_awid[aw_src*ID_WIDTH +: ID_WIDTH];
    assign m_awaddr   = s_awaddr[aw_src*ADDR_WIDTH +: ADDR_WIDTH];
    assign m_awlen    = s_awlen[aw_src*8 +: 8];
    assign m_awsize   = s_awsize[aw_src*3 +: 3];
    assign m_awburst  = s_awburst[aw_src*2 +: 2];
    assign m_awlock   = s_awlock[aw_src];
    assign m_awcache  = s_awcache[aw_src*4 +: 4];
    assign m_awprot   = s_awprot[aw_src*3 +: 3];
    assign m_awqos    = s_awqos[aw_src*4 +: 4];
    assign m_awregion = s_awregion[aw_src*4 +: 4];

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            held <= 1'b0;
            held_idx <= 2'd0;
            w_active <= 1'b0;
            w_src <= 2'd0;
        end else begin
            if (aw_fire) begin
                held <= 1'b0;
                w_active <= 1'b1;
                w_src <= aw_src;
            end else if (m_awvalid && !m_awready) begin
                held <= 1'b1;
                held_idx <= aw_src;
            end
            if (w_fire_last)
                w_active <= 1'b0;
        end
    end

    assign m_wdata  = s_wdata[w_src*DATA_WIDTH +: DATA_WIDTH];
    assign m_wstrb  = s_wstrb[w_src*(DATA_WIDTH/8) +: (DATA_WIDTH/8)];
    assign m_wlast  = s_wlast[w_src];
    assign m_wvalid = rst_n && w_active && s_wvalid[w_src];
    assign s_wready = (rst_n && w_active && m_wready)
                    ? (3'b001 << w_src) : 3'b000;
    assign w_fire_last = m_wvalid && m_wready && m_wlast;

    assign s_bid    = {3{m_bid}};
    assign s_bresp  = {3{m_bresp}};
    assign s_bvalid = (rst_n && !b_tags_empty && m_bvalid)
                    ? (3'b001 << b_src) : 3'b000;
    assign m_bready = rst_n && !b_tags_empty && s_bready[b_src];
    assign b_fire = m_bvalid && m_bready;
endmodule
