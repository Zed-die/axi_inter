`timescale 1ns/1ps

// Reads one packet's payload into a packed 1 KiB byte store. Each AXI burst
// stays inside one 4 KiB page; only one AR is outstanding at a time.
module outbound_payload_reader (
    input  wire         clk,
    input  wire         rst_n,
    input  wire         start_valid,
    output wire         start_ready,
    input  wire [63:0]  start_addr,
    input  wire [10:0]  start_len,
    output wire         packet_valid,
    output wire         packet_error,
    output reg  [10:0]  packet_len,
    input  wire         packet_release,
    input  wire [3:0]   read_index,
    output wire [511:0] read_data,
    output wire         m_axi_arvalid,
    input  wire         m_axi_arready,
    output reg  [63:0]  m_axi_araddr,
    output reg  [7:0]   m_axi_arlen,
    output reg  [2:0]   m_axi_arsize,
    output wire [1:0]   m_axi_arburst,
    input  wire         m_axi_rvalid,
    output wire         m_axi_rready,
    input  wire [511:0] m_axi_rdata,
    input  wire [1:0]   m_axi_rresp,
    input  wire         m_axi_rlast,
    input  wire [3:0]   m_axi_rid
);
    localparam [2:0] IDLE = 3'd0, PLAN = 3'd1, AR = 3'd2,
                     RECEIVE = 3'd3, DRAIN = 3'd4,
                     READY = 3'd5, ERROR = 3'd6;
    reg [2:0] state;
    reg [63:0] base_addr;
    reg [10:0] byte_count;
    reg [63:0] beat_addr;
    reg [7:0] beats_left;
    reg bad_seen;
    reg [63:0] next_addr;
    reg [10:0] remaining;
    reg [12:0] page_left;
    reg [10:0] beat_limit;
    reg [10:0] next_beats;
    reg [2:0] next_size;
    wire [10:0] beat_bytes = 11'd1 << m_axi_arsize;
    wire [64:0] start_end_exclusive = {1'b0, start_addr} + {54'd0, start_len};
    wire start_addr_overflow = start_end_exclusive > {1'b1, 64'd0};
    wire last_expected = beats_left == 8'd1;
    wire bad_response = m_axi_rresp != 2'b00 || m_axi_rid != 4'd0 ||
                        m_axi_rlast != last_expected;

    assign start_ready = rst_n && state == IDLE;
    assign packet_valid = state == READY || state == ERROR;
    assign packet_error = state == ERROR;
    assign m_axi_arvalid = state == AR;
    assign m_axi_arburst = 2'b01;
    assign m_axi_rready = state == RECEIVE || state == DRAIN;

    always @* begin
        next_addr = base_addr + byte_count;
        remaining = packet_len - byte_count;
        page_left = 13'd4096 - {1'b0, next_addr[11:0]};
        beat_limit = 11'd0;
        if (next_addr[5:0] == 0 && remaining >= 11'd64) begin
            next_size = 3'd6;
            next_beats = remaining >> 6;
            if (next_beats > (page_left >> 6)) next_beats = page_left >> 6;
        end else if (next_addr[1:0] == 0 && remaining >= 11'd4) begin
            next_size = 3'd2;
            beat_limit = 11'd64 - {5'd0, next_addr[5:0]};
            next_beats = remaining >> 2;
            if (next_beats > (beat_limit >> 2)) next_beats = beat_limit >> 2;
            if (next_beats > (page_left >> 2)) next_beats = page_left >> 2;
        end else begin
            next_size = 3'd0;
            beat_limit = 11'd64 - {5'd0, next_addr[5:0]};
            next_beats = remaining;
            if (next_beats > beat_limit) next_beats = beat_limit;
            if (next_beats > page_left) next_beats = page_left;
        end
    end

    outbound_packet_buffer buffer_i (
        .clk         (clk),
        .write_en    (state == RECEIVE && m_axi_rvalid && m_axi_rready),
        .write_base  (byte_count),
        .write_lane  (beat_addr[5:0]),
        .write_size  (m_axi_arsize),
        .write_data  (m_axi_rdata),
        .packet_len  (packet_len),
        .read_index  (read_index),
        .read_data   (read_data)
    );

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= IDLE;
            base_addr <= 64'd0;
            packet_len <= 11'd0;
            byte_count <= 11'd0;
            beat_addr <= 64'd0;
            beats_left <= 8'd0;
            bad_seen <= 1'b0;
            m_axi_araddr <= 64'd0;
            m_axi_arlen <= 8'd0;
            m_axi_arsize <= 3'd0;
        end else begin
            case (state)
                IDLE: if (start_valid) begin
                    base_addr <= start_addr;
                    packet_len <= start_len;
                    byte_count <= 11'd0;
                    bad_seen <= 1'b0;
                    state <= (start_len == 0 || start_len > 11'd1024 ||
                              start_addr_overflow) ? ERROR : PLAN;
                end
                PLAN: begin
                    m_axi_araddr <= next_addr;
                    m_axi_arlen <= next_beats[7:0] - 8'd1;
                    m_axi_arsize <= next_size;
                    state <= AR;
                end
                AR: if (m_axi_arready) begin
                    beat_addr <= m_axi_araddr;
                    beats_left <= m_axi_arlen + 8'd1;
                    state <= RECEIVE;
                end
                RECEIVE: if (m_axi_rvalid) begin
                    byte_count <= byte_count + beat_bytes;
                    beat_addr <= beat_addr + beat_bytes;
                    beats_left <= beats_left - 8'd1;
                    if (bad_response) bad_seen <= 1'b1;
                    if (m_axi_rlast) begin
                        if (bad_seen || bad_response) state <= ERROR;
                        else if (byte_count + beat_bytes == packet_len) state <= READY;
                        else state <= PLAN;
                    end else if (last_expected) state <= DRAIN;
                end
                DRAIN: if (m_axi_rvalid && m_axi_rlast) state <= ERROR;
                READY: if (packet_release) state <= IDLE;
                ERROR: if (packet_release) state <= IDLE;
                default: state <= ERROR;
            endcase
        end
    end
endmodule
