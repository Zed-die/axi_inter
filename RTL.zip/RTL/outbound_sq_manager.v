`timescale 1ns/1ps

// The prefetched SQE output is FWFT. Only its head can enter the single TX
// context; FIFO pop and software-visible SQ retirement are separate events.
module outbound_sq_manager (
    input  wire         clk,
    input  wire         rst_n,
    input  wire         enable,
    input  wire [3:0]   sq_count,
    input  wire         sq_valid,
    input  wire [255:0] sq_dout,
    input  wire [15:0]  sq_ptr,
    input  wire         sq_error,
    output wire         sq_pop,
    input  wire         prefetch_fault,
    output wire         prefetch_req_valid,
    output wire [4:0]   prefetch_sq_num,
    output wire         gen_desc_valid,
    input  wire         gen_desc_ready,
    output wire [255:0] gen_desc_sqe,
    input  wire         gen_done_valid,
    input  wire [7:0]   gen_done_status,
    output wire         gen_done_ready,
    output wire         gen_publish_valid,
    output wire         gen_publish_success,
    output wire         cq_req_valid,
    input  wire         cq_req_ready,
    output wire [15:0]  cq_req_cid,
    output wire [15:0]  cq_req_sq_ptr,
    output wire [7:0]   cq_req_status,
    output wire [15:0]  cq_req_candidate_rd,
    input  wire         cq_publish_valid,
    input  wire         cq_publish_success,
    output reg  [15:0]  sq_rd_ptr,
    output reg          queue_fault,
    output reg          sqe_read_error_event,
    output reg          sqe_invalid_event
);
    localparam [2:0] IDLE = 3'd0, RUN = 3'd1, CQ_REQ = 3'd2,
                     CQ_WAIT = 3'd3, FAULT = 3'd4;
    reg [2:0] state;
    reg [15:0] active_seq;
    reg [15:0] active_cid;
    reg [7:0] active_status;
    wire head_bad = sq_error || sq_dout[95:90] != 6'd0;
    wire head_fire = rst_n && enable && !queue_fault && state == IDLE && sq_valid;

    assign prefetch_req_valid = rst_n && enable && !queue_fault && sq_count < 4'd8;
    assign prefetch_sq_num = 5'd8 - {1'b0, sq_count};
    assign gen_desc_valid = head_fire && !head_bad;
    assign gen_desc_sqe = sq_dout;
    assign sq_pop = head_fire && (head_bad || gen_desc_ready);
    assign gen_done_ready = state == RUN;
    assign cq_req_valid = state == CQ_REQ;
    assign cq_req_cid = active_cid;
    assign cq_req_sq_ptr = active_seq;
    assign cq_req_status = active_status;
    assign cq_req_candidate_rd = active_seq + 16'd1;
    assign gen_publish_valid = state == CQ_WAIT && cq_publish_valid;
    assign gen_publish_success = cq_publish_success;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= IDLE;
            active_seq <= 16'd0;
            active_cid <= 16'd0;
            active_status <= 8'd0;
            sq_rd_ptr <= 16'd0;
            queue_fault <= 1'b0;
            sqe_read_error_event <= 1'b0;
            sqe_invalid_event <= 1'b0;
        end else begin
            sqe_read_error_event <= 1'b0;
            sqe_invalid_event <= 1'b0;
            if (prefetch_fault) queue_fault <= 1'b1;
            case (state)
                IDLE: if (head_fire) begin
                    if (sq_error) begin
                        queue_fault <= 1'b1;
                        sqe_read_error_event <= 1'b1;
                        state <= FAULT;
                    end else if (sq_dout[95:90] != 6'd0) begin
                        active_seq <= sq_ptr;
                        active_cid <= sq_dout[255:240];
                        active_status <= 8'h50;
                        sqe_invalid_event <= 1'b1;
                        state <= CQ_REQ;
                    end else if (gen_desc_ready) begin
                        active_seq <= sq_ptr;
                        active_cid <= sq_dout[255:240];
                        active_status <= 8'd0;
                        state <= RUN;
                    end
                end
                RUN: if (gen_done_valid) begin
                    active_status <= gen_done_status;
                    state <= CQ_REQ;
                end
                CQ_REQ: if (cq_req_ready) state <= CQ_WAIT;
                CQ_WAIT: if (cq_publish_valid) begin
                    if (cq_publish_success) begin
                        sq_rd_ptr <= active_seq + 16'd1;
                        state <= IDLE;
                    end else begin
                        queue_fault <= 1'b1;
                        state <= FAULT;
                    end
                end
                default: state <= FAULT;
            endcase
        end
    end
endmodule
