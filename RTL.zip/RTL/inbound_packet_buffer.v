`timescale 1ns/1ps

// One raw 1 KiB inbound packet store: 16 x (512-bit WDATA + 64-bit WSTRB).
// The decoder owns W beat numbering and packet validation. The router owns
// the read address and releases the buffer after consuming every W beat.
module inbound_packet_buffer (
    input  wire         clk,
    input  wire         rst_n,
    output wire         free,
    input  wire         reserve,
    input  wire         write_en,
    input  wire [3:0]   write_addr,
    input  wire [511:0] write_data,
    input  wire [63:0]  write_strb,
    input  wire         finish,
    input  wire         finish_good,
    output wire         packet_valid,
    input  wire         packet_ready,
    input  wire         packet_release,
    input  wire [3:0]   read_addr,
    output wire [511:0] read_data,
    output wire [63:0]  read_strb
);
    localparam [1:0] FREE = 2'd0, FILL = 2'd1,
                     READY = 2'd2, DRAIN = 2'd3;
    reg [1:0] state;
    reg [511:0] data_ram [0:15];
    reg [63:0] strb_ram [0:15];

    assign free = state == FREE;
    assign packet_valid = state == READY;
    assign read_data = data_ram[read_addr];
    assign read_strb = strb_ram[read_addr];

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) state <= FREE;
        else begin
            case (state)
                FREE: if (reserve) state <= FILL;
                FILL: if (finish) state <= finish_good ? READY : FREE;
                READY: if (packet_ready) state <= DRAIN;
                DRAIN: if (packet_release) state <= FREE;
                default: state <= FREE;
            endcase
        end
    end

    always @(posedge clk) begin
        if (rst_n && state == FILL && write_en) begin
            data_ram[write_addr] <= write_data;
            strb_ram[write_addr] <= write_strb;
        end
    end
endmodule
