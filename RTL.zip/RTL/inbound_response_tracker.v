`timescale 1ns/1ps

// One B response per accepted controller AW, globally ordered by AW acceptance.
// The five-bit token is the 16-entry ring index plus a wrap generation bit.
module inbound_response_tracker #(
    parameter integer ID_WIDTH = 4
) (
    input  wire                clk,
    input  wire                rst_n,
    input  wire                alloc_valid,
    output wire                alloc_ready,
    output wire [4:0]          alloc_token,
    input  wire [ID_WIDTH-1:0] alloc_id,
    input  wire                route_valid,
    input  wire [4:0]          route_token,
    input  wire [1:0]          route_resp,
    input  wire                drop_valid,
    input  wire [4:0]          drop_token,
    output wire                s_bvalid,
    input  wire                s_bready,
    output wire [ID_WIDTH-1:0] s_bid,
    output wire [1:0]          s_bresp
);
    reg [4:0] head;
    reg [4:0] tail;
    reg [4:0] count;
    reg entry_valid [0:15];
    reg entry_done [0:15];
    reg entry_gen [0:15];
    reg [ID_WIDTH-1:0] entry_id [0:15];
    reg [1:0] entry_resp [0:15];
    integer i;
    wire alloc_fire = alloc_valid && alloc_ready;
    wire b_fire = s_bvalid && s_bready;

    assign alloc_ready = rst_n && count < 5'd16;
    assign alloc_token = tail;
    assign s_bvalid = rst_n && count != 0 && entry_valid[head[3:0]] &&
                      entry_gen[head[3:0]] == head[4] && entry_done[head[3:0]];
    assign s_bid = entry_id[head[3:0]];
    assign s_bresp = entry_resp[head[3:0]];

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            head <= 5'd0;
            tail <= 5'd0;
            count <= 5'd0;
            for (i = 0; i < 16; i = i + 1) begin
                entry_valid[i] <= 1'b0;
                entry_done[i] <= 1'b0;
                entry_gen[i] <= 1'b0;
                entry_id[i] <= {ID_WIDTH{1'b0}};
                entry_resp[i] <= 2'b00;
            end
        end else begin
            if (alloc_fire) begin
                entry_valid[tail[3:0]] <= 1'b1;
                entry_done[tail[3:0]] <= 1'b0;
                entry_gen[tail[3:0]] <= tail[4];
                entry_id[tail[3:0]] <= alloc_id;
                entry_resp[tail[3:0]] <= 2'b00;
                tail <= tail + 5'd1;
            end
            if (route_valid && entry_valid[route_token[3:0]] &&
                entry_gen[route_token[3:0]] == route_token[4]) begin
                entry_done[route_token[3:0]] <= 1'b1;
                entry_resp[route_token[3:0]] <= route_resp;
            end
            if (drop_valid && entry_valid[drop_token[3:0]] &&
                entry_gen[drop_token[3:0]] == drop_token[4]) begin
                entry_done[drop_token[3:0]] <= 1'b1;
                entry_resp[drop_token[3:0]] <= 2'b10;
            end
            if (b_fire) begin
                entry_valid[head[3:0]] <= 1'b0;
                entry_done[head[3:0]] <= 1'b0;
                head <= head + 5'd1;
            end
            case ({alloc_fire, b_fire})
                2'b10: count <= count + 5'd1;
                2'b01: count <= count - 5'd1;
                default: count <= count;
            endcase
        end
    end
endmodule
