`timescale 1ns/1ps

// Moves one stored RX packet to Fabric. Source WSTRB must describe one
// contiguous byte stream; its first valid byte may start in any source lane.
// Destination W beats are 64-byte aligned and AW bursts never cross 4 KiB.
module inbound_router #(
    parameter integer ADDR_WIDTH = 64,
    parameter integer ID_WIDTH = 4,
    parameter integer META_WIDTH = 128,
    parameter [3:0] AWCACHE_VALUE = 4'b0010,
    parameter [2:0] AWPROT_VALUE = 3'b010
) (
    input  wire                     clk,
    input  wire                     rst_n,
    input  wire                     packet_valid,
    output wire                     packet_ready,
    output wire                     packet_release,
    input  wire [META_WIDTH-1:0]    packet_meta,
    input  wire [4:0]               packet_token,
    input  wire [2:0]               packet_slot,
    input  wire                     packet_som,
    input  wire                     packet_eom,
    input  wire [1:0]               packet_seq,
    input  wire [10:0]              packet_wbytes,
    input  wire [4:0]               packet_beats,
    input  wire [255:0]             packet_sqe,
    output wire [3:0]               buf_rd_addr,
    input  wire [511:0]             buf_rd_data,
    input  wire [63:0]              buf_rd_strb,
    output wire                     packet_commit_valid,
    input  wire                     packet_commit_ready,
    output wire [2:0]               packet_commit_slot,
    output wire [31:0]              packet_commit_bytes,
    output wire [1:0]               packet_commit_seq,
    output wire                     packet_commit_eom,
    output wire                     result_valid,
    input  wire                     result_ready,
    output wire [META_WIDTH-1:0]    result_meta,
    output wire [4:0]               result_token,
    output wire [2:0]               result_slot,
    output wire                     result_som,
    output wire                     result_eom,
    output wire [10:0]              result_bytes,
    output wire                     result_error,
    output wire [3:0]               result_reason,
    output wire [1:0]               result_bresp,
    output wire                     m_axi_awvalid,
    input  wire                     m_axi_awready,
    output wire [ADDR_WIDTH-1:0]    m_axi_awaddr,
    output wire [7:0]               m_axi_awlen,
    output wire [2:0]               m_axi_awsize,
    output wire [1:0]               m_axi_awburst,
    output wire [ID_WIDTH-1:0]      m_axi_awid,
    output wire                     m_axi_awlock,
    output wire [3:0]               m_axi_awcache,
    output wire [2:0]               m_axi_awprot,
    output wire [3:0]               m_axi_awqos,
    output wire [3:0]               m_axi_awregion,
    output wire                     m_axi_wvalid,
    input  wire                     m_axi_wready,
    output wire [511:0]             m_axi_wdata,
    output wire [63:0]              m_axi_wstrb,
    output wire                     m_axi_wlast,
    input  wire                     m_axi_bvalid,
    output wire                     m_axi_bready,
    input  wire [1:0]               m_axi_bresp,
    input  wire [ID_WIDTH-1:0]      m_axi_bid
);
    localparam [2:0] IDLE = 3'd0, VALIDATE = 3'd1, AW = 3'd2,
                     W = 3'd3, WAIT_B = 3'd4, COMMIT = 3'd5,
                     RESULT = 3'd6, PRELOAD = 3'd7;
    localparam [3:0] ERR_NONE = 4'd0, ERR_FORMAT = 4'd1,
                     ERR_BRESP = 4'd2, ERR_BID = 4'd3,
                     ERR_NO_CONTEXT = 4'd4, ERR_OVERFLOW = 4'd5;

    reg [2:0] state;
    reg [META_WIDTH-1:0] job_meta;
    reg [4:0] job_token;
    reg [2:0] job_slot;
    reg job_som;
    reg job_eom;
    reg [1:0] job_seq;
    reg [10:0] job_bytes;
    reg [4:0] job_beats;
    reg [ADDR_WIDTH-1:0] base_addr;
    reg [4:0] total_out_beats;
    reg [4:0] check_idx;
    reg [4:0] out_idx;
    reg [4:0] segment_left;
    reg [5:0] source_offset;
    reg [511:0] prev_data;
    reg [63:0] prev_strb;
    reg [3:0] error_reason;
    reg [1:0] response_code;
    reg [ADDR_WIDTH-1:0] next_addr [0:7];
    reg next_addr_valid [0:7];
    integer slot_idx;
    integer lane_idx;
    reg first_lane_found;
    reg [5:0] first_lane;

    function [63:0] low_mask;
        input [6:0] count;
        begin
            if (count >= 7'd64) low_mask = {64{1'b1}};
            else low_mask = (64'h1 << count) - 64'h1;
        end
    endfunction

    wire [ADDR_WIDTH-1:0] input_base = packet_som ?
        (packet_sqe[191:128] & ~64'd3) : next_addr[packet_slot];
    wire [ADDR_WIDTH:0] input_end = {1'b0, input_base} + packet_wbytes;
    wire [11:0] input_span = {6'd0, input_base[5:0]} + {1'b0, packet_wbytes};
    wire [4:0] input_out_beats = (input_span + 12'd63) >> 6;
    wire bad_packet_shape = packet_wbytes == 0 || packet_wbytes > 11'd1024 ||
                            packet_beats == 0 || packet_beats > 5'd16;

    always @* begin
        first_lane_found = 1'b0;
        first_lane = 6'd0;
        for (lane_idx = 0; lane_idx < 64; lane_idx = lane_idx + 1) begin
            if (!first_lane_found && buf_rd_strb[lane_idx]) begin
                first_lane_found = 1'b1;
                first_lane = lane_idx[5:0];
            end
        end
    end
    wire [5:0] check_source_offset = check_idx == 0 ? first_lane : source_offset;
    wire [11:0] source_span = {6'd0, check_source_offset} + {1'b0, job_bytes};
    wire [4:0] expected_source_beats = (source_span + 12'd63) >> 6;
    wire [11:0] last_source_count = source_span -
        ({7'd0, job_beats} - 12'd1) * 12'd64;
    wire [63:0] expected_strb =
        (check_idx == 0 ? ({64{1'b1}} << check_source_offset) : {64{1'b1}}) &
        (check_idx == job_beats - 5'd1 ? low_mask(last_source_count[6:0]) :
                                             {64{1'b1}});

    wire [ADDR_WIDTH-1:0] aligned_base = {base_addr[ADDR_WIDTH-1:6], 6'd0};
    wire [ADDR_WIDTH-1:0] beat_addr = aligned_base +
                                      {{(ADDR_WIDTH-11){1'b0}}, out_idx, 6'd0};
    wire [5:0] remaining_beats = {1'b0, total_out_beats} - {1'b0, out_idx};
    wire [6:0] boundary_beats = 7'd64 - {1'b0, beat_addr[11:6]};
    wire [5:0] next_segment_beats =
        remaining_beats < boundary_beats ? remaining_beats : boundary_beats[5:0];

    assign packet_ready = rst_n && state == IDLE;
    assign packet_release = rst_n && state == RESULT && result_ready;
    wire right_shift = source_offset > base_addr[5:0];
    wire [5:0] shift_bytes = right_shift ? source_offset - base_addr[5:0] :
                                          base_addr[5:0] - source_offset;
    wire [5:0] source_idx = {1'b0, out_idx} + (right_shift ? 6'd1 : 6'd0);
    assign buf_rd_addr = state == VALIDATE ? check_idx[3:0] :
                         (state == W && source_idx < {1'b0, job_beats}) ?
                         source_idx[3:0] : 4'd0;
    wire [511:0] source_data = source_idx < {1'b0, job_beats} ? buf_rd_data : 512'd0;
    wire [63:0] source_strb = source_idx < {1'b0, job_beats} ? buf_rd_strb : 64'd0;
    wire [9:0] shift_bits = {1'b0, shift_bytes, 3'b000};
    assign m_axi_wdata = shift_bytes == 0 ? source_data :
                         right_shift ?
                         ((prev_data >> shift_bits) |
                          (source_data << (10'd512 - shift_bits))) :
                         ((source_data << shift_bits) |
                          (prev_data >> (10'd512 - shift_bits)));
    assign m_axi_wstrb = shift_bytes == 0 ? source_strb :
                         right_shift ?
                         ((prev_strb >> shift_bytes) |
                          (source_strb << (7'd64 - {1'b0, shift_bytes}))) :
                         ((source_strb << shift_bytes) |
                          (prev_strb >> (7'd64 - {1'b0, shift_bytes})));

    assign m_axi_awvalid = rst_n && state == AW;
    assign m_axi_awaddr = beat_addr;
    assign m_axi_awlen = {2'd0, next_segment_beats} - 8'd1;
    assign m_axi_awsize = 3'd6;
    assign m_axi_awburst = 2'b01;
    assign m_axi_awid = {ID_WIDTH{1'b0}};
    assign m_axi_awlock = 1'b0;
    assign m_axi_awcache = AWCACHE_VALUE;
    assign m_axi_awprot = AWPROT_VALUE;
    assign m_axi_awqos = 4'd0;
    assign m_axi_awregion = 4'd0;
    assign m_axi_wvalid = rst_n && state == W;
    assign m_axi_wlast = segment_left == 5'd1;
    assign m_axi_bready = rst_n && state == WAIT_B;

    assign packet_commit_valid = rst_n && state == COMMIT;
    assign packet_commit_slot = job_slot;
    assign packet_commit_bytes = {21'd0, job_bytes};
    assign packet_commit_seq = job_seq;
    assign packet_commit_eom = job_eom;
    assign result_valid = rst_n && state == RESULT;
    assign result_meta = job_meta;
    assign result_token = job_token;
    assign result_slot = job_slot;
    assign result_som = job_som;
    assign result_eom = job_eom;
    assign result_bytes = job_bytes;
    assign result_error = error_reason != ERR_NONE;
    assign result_reason = error_reason;
    assign result_bresp = response_code;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= IDLE;
            job_meta <= {META_WIDTH{1'b0}};
            job_token <= 5'd0;
            job_slot <= 3'd0;
            job_som <= 1'b0;
            job_eom <= 1'b0;
            job_seq <= 2'd0;
            job_bytes <= 11'd0;
            job_beats <= 5'd0;
            base_addr <= {ADDR_WIDTH{1'b0}};
            total_out_beats <= 5'd0;
            check_idx <= 5'd0;
            out_idx <= 5'd0;
            segment_left <= 5'd0;
            source_offset <= 6'd0;
            prev_data <= 512'd0;
            prev_strb <= 64'd0;
            error_reason <= ERR_NONE;
            response_code <= 2'b00;
            for (slot_idx = 0; slot_idx < 8; slot_idx = slot_idx + 1) begin
                next_addr[slot_idx] <= {ADDR_WIDTH{1'b0}};
                next_addr_valid[slot_idx] <= 1'b0;
            end
        end else begin
            case (state)
                IDLE: if (packet_valid) begin
                    job_meta <= packet_meta;
                    job_token <= packet_token;
                    job_slot <= packet_slot;
                    job_som <= packet_som;
                    job_eom <= packet_eom;
                    job_seq <= packet_seq;
                    job_bytes <= packet_wbytes;
                    job_beats <= packet_beats;
                    base_addr <= input_base;
                    total_out_beats <= input_out_beats;
                    check_idx <= 5'd0;
                    out_idx <= 5'd0;
                    prev_data <= 512'd0;
                    prev_strb <= 64'd0;
                    source_offset <= 6'd0;
                    error_reason <= ERR_NONE;
                    response_code <= 2'b00;
                    if (!packet_som && !next_addr_valid[packet_slot]) begin
                        error_reason <= ERR_NO_CONTEXT;
                        response_code <= 2'b10;
                        state <= RESULT;
                    end else if (bad_packet_shape) begin
                        error_reason <= ERR_FORMAT;
                        response_code <= 2'b10;
                        state <= RESULT;
                    end else if (input_end[ADDR_WIDTH]) begin
                        error_reason <= ERR_OVERFLOW;
                        response_code <= 2'b10;
                        state <= RESULT;
                    end else state <= VALIDATE;
                end
                VALIDATE: begin
                    if (check_idx == 0) source_offset <= first_lane;
                    if ((check_idx == 0 && !first_lane_found) ||
                        job_beats != expected_source_beats ||
                        buf_rd_strb != expected_strb) begin
                        error_reason <= ERR_FORMAT;
                        response_code <= 2'b10;
                        state <= RESULT;
                    end else if (check_idx == job_beats - 5'd1)
                        state <= check_source_offset > base_addr[5:0] ? PRELOAD : AW;
                    else check_idx <= check_idx + 5'd1;
                end
                PRELOAD: begin
                    prev_data <= buf_rd_data;
                    prev_strb <= buf_rd_strb;
                    state <= AW;
                end
                AW: if (m_axi_awready) begin
                    segment_left <= next_segment_beats[4:0];
                    state <= W;
                end
                W: if (m_axi_wready) begin
                    prev_data <= source_data;
                    prev_strb <= source_strb;
                    out_idx <= out_idx + 5'd1;
                    if (segment_left == 5'd1) state <= WAIT_B;
                    else segment_left <= segment_left - 5'd1;
                end
                WAIT_B: if (m_axi_bvalid) begin
                    if (m_axi_bid != {ID_WIDTH{1'b0}}) begin
                        error_reason <= ERR_BID;
                        response_code <= 2'b10;
                        state <= RESULT;
                    end else if (m_axi_bresp != 2'b00) begin
                        error_reason <= ERR_BRESP;
                        response_code <= m_axi_bresp;
                        state <= RESULT;
                    end else if (out_idx == total_out_beats) state <= COMMIT;
                    else state <= AW;
                end
                COMMIT: if (packet_commit_ready) begin
                    next_addr[job_slot] <= base_addr + job_bytes;
                    next_addr_valid[job_slot] <= !job_eom;
                    state <= RESULT;
                end
                RESULT: if (result_ready) begin
                    if (error_reason != ERR_NONE)
                        next_addr_valid[job_slot] <= 1'b0;
                    state <= IDLE;
                end
                default: state <= IDLE;
            endcase
        end
    end
endmodule
