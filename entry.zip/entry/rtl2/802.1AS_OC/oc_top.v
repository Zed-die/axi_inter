`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: wanghaoyu
// 
// Create Date: 2025/04/21 15:26:03
// Design Name: 
// Module Name: oc_top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////
 module oc_top(
    input            clk,
    input            rst_n,
    input   [1:0]    port_num,

    input   [7:0]    gmii_rxd,
    input            gmii_rx_dv,
    output  [7:0]    gmii_txd,
    output           gmii_tx_en,
    input   [63:0]   test_time,
    
    //时钟配置信息
    input   [7:0]    Priority1              ,         
    input   [7:0]    clockClass             ,        
    input   [7:0]    clockAccuracy          ,     
    input   [15:0]   offsetScaledLogVariance,   
    input   [7:0]    Priority2              ,        
    input   [63:0]   clockIdentity          ,  
    input   [31:0]   oc_error_time          ,
    input   [31:0]   oc_error_type          ,

    //报文发送周期
    input   [7:0]    LogInterval_sync       , 
    input   [7:0]    LogInterval_pdelay     ,
    input   [7:0]    LogInterval_announce   ,

    output           sys_sync               ,
    output  [79:0]   sys_time               ,
    
    //时间戳生成
    input            timestamp_tx_Pdelay_valid_cdc ,
    input            timestamp_tx_Sync_valid_cdc   ,
    input            timestamp_tx_Presp_valid_cdc  ,
    input            timestamp_rx_Pdelay_valid_cdc ,
    input            timestamp_rx_Sync_valid_cdc   ,
    input            timestamp_rx_Presp_valid_cdc  ,
    output           sync_pulse                    , 

    //上报同步寄存器
    output [31:0]       upload_port_state ,       //端口状态
    output [31:0]       upload_sys_time_ns,       //系统ns级时间
    output [31:0]       upload_offset,            //纠偏值
    output reg [31:0]   upload_delay              //路径时延             


);

wire [79:0]  Message_sourcePortIdentity     ;
wire [7:0]   Message_Priority1              ;
wire [7:0]   Message_clockClass             ;
wire [7:0]   Message_clockAccuracy          ;
wire [15:0]  Message_offsetScaledLogVariance;
wire [7:0]   Message_Priority2              ;
wire [63:0]  Message_clockIdentity          ;
wire [15:0]  Message_stepsRemoved           ;
wire         Message_Announce_valid         ;


wire [3:0]   port_state;            //端口状态
wire         portstate_valid;

wire [79:0]  timer;


wire [79:0]  Pdelay_Req_rx_ts;            //本地接收Pdelay帧的时间点，用于组Presp帧
wire         Pdelay_Req_rx_ts_valid; 

wire [79:0]  Pdelay_Req_tx_ts;           //本地发送Pdelay帧的时间点，用于计算时延
wire         Pdelay_Req_tx_ts_valid;
 
wire [79:0]  Pdelay_Resp_rx_ts;         //本地接收Presp帧的时间点，用于计算时延
wire         Pdelay_Resp_rx_ts_valid;

wire [79:0]  Pdelay_opposite_rx_ts;        //对端接收Pdelay帧的时间点，由Presp帧中提取，用于计算时延
wire         Pdelay_opposite_rx_ts_valid;

wire [79:0]  Pdelay_Resp_tx_ts;             //对端发送Presp帧的时间点，用于计算时延
wire         Pdelay_Resp_tx_ts_valid;

wire [79:0]  Sync_tx_ts;
wire [63:0]  Sync_correction_field;
wire         Sync_ts_valid;

wire [79:0]  Sync_rx_ts;                //本地接收Sync帧的时间点，用于时钟同步
wire         Sync_rx_ts_valid;

wire [79:0]offset;
wire valid ;
wire sign  ;


wire Pdelay_Req_en;
wire Sync_en      ;
wire Announce_en  ;

(*DOUT_TOUCH = "TRUE"*)wire [79:0]  link_delay;
(*DOUT_TOUCH = "TRUE"*)wire         link_delay_valid;

wire pdelay_valid;      
wire [79:0] pdelay_portIdentity;

wire [15:0] currentUtcOffset = 16'h0;

reg [3:0] port_state_reg;

reg  [7:0]    Priority1_reg;              
reg  [7:0]    clockClass_reg;             
reg  [7:0]    clockAccuracy_reg;          
reg  [15:0]   offsetScaledLogVariance_reg;
reg  [7:0]    Priority2_reg;              
reg  [63:0]   clockIdentity_reg;  
reg clock_message_change;               


assign upload_offset      = offset[31:0];
assign upload_sys_time_ns = sys_time[63:32];

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        upload_delay <= 32'b0;
    end
    else begin
        if(link_delay_valid) 
            upload_delay <= link_delay[31:0];
        else 
            upload_delay <= upload_delay;
    end
end

always@(posedge clk or negedge rst_n)begin
    if(!rst_n) begin
        Priority1_reg <= 8'h0;
        clockClass_reg <= 8'h0;
        clockAccuracy_reg <= 8'h0;
        offsetScaledLogVariance_reg <= 16'h0;
        Priority2_reg <= 8'h0;
        clockIdentity_reg <= 64'h0;
    end
    else begin
        Priority1_reg <= Priority1;
        clockClass_reg <= clockClass;
        clockAccuracy_reg <= clockAccuracy;
        offsetScaledLogVariance_reg <= offsetScaledLogVariance;
        Priority2_reg <= Priority2;
        clockIdentity_reg <= clockIdentity;
    end
 end

always@(posedge clk or negedge rst_n)begin
    if(!rst_n) 
        clock_message_change <= 1'b0;
    else if(Priority1_reg != Priority1 || clockClass_reg != clockClass || clockAccuracy_reg != clockAccuracy || offsetScaledLogVariance_reg != offsetScaledLogVariance || Priority2_reg != Priority2 || clockIdentity_reg != clockIdentity)
        clock_message_change <= 1'b1;
    else
        clock_message_change <= 1'b0;
 end


time_management U_time_management(
    .clk                            (clk                            ),
    .rst_n                          (rst_n                          ), 
    .Pdelay_Req_en                  (Pdelay_Req_en                  ), 
    .Sync_en                        (Sync_en                        ),
    .Announce_en                    (Announce_en                    ),
    .clock_message_change           (clock_message_change           ),
                         
    .timer                          (timer                          ),
    .sys_sync                       (sys_sync                       ),
                         
    .LogInterval_sync               (LogInterval_sync               ), 
    .LogInterval_pdelay             (LogInterval_pdelay             ),
    .LogInterval_announce           (LogInterval_announce           ),
                     
    .port_state                     (port_state                     ),
    .portstate_valid                (portstate_valid                ),
    .upload_port_state              (upload_port_state              ),
                     
    .offset                         (offset                         ),
    .sign                           (sign                           ),
    .valid                          (valid                          ),
    .sys_time                       (sys_time                       ),
    .pulse                          (sync_pulse                     )
);

frame_gen_OC U_frame_gen(
    .clk                            (clk                                               ),        
    .rst_n                          (rst_n                                             ),  
    .test_time                      (test_time                                         ),  
    .oc_error_time                  (oc_error_time                                     ),
    .oc_error_type                  (oc_error_type                                     ), //一致性测试下的故障帧生成

    .sync_gen                       (Sync_en                                           ),
    .pdelay_gen                     (Pdelay_Req_en                                     ),   
    .announce_gen                   (Announce_en                                       ), 
    .two_step_flag                  (1'b1                                              ), 
    .timer                          (timer                                             ), 
    .sys_time                       (sys_time                                          ), 
    .clockIdentity                  ({16'h0,clockIdentity}                             ), 
    .LogInterval_sync               (LogInterval_sync                                  ), 
    .LogInterval_pdelay             (LogInterval_pdelay                                ), 
    .LogInterval_announce           (LogInterval_announce                              ), 
    .pdelay_valid                   (pdelay_valid                                      ),
    .pdelay_portIdentity            (pdelay_portIdentity                               ), 
    .currentUtcOffset               (currentUtcOffset                                  ), 
    .grandmasterPriority1           (Priority1                                         ), 
    .grandmasterClockQuality        ({clockClass,clockAccuracy,offsetScaledLogVariance}), 
    .grandmasterPriority2           (Priority2                                         ), 
    .grandmasterIdentity            (clockIdentity                                     ), 
    .timestamp_tx_Sync_valid_cdc    (timestamp_tx_Sync_valid_cdc                       ),
    .timestamp_rx_Pdelay_valid_cdc  (timestamp_rx_Pdelay_valid_cdc                     ),
    .timestamp_tx_Presp_valid_cdc   (timestamp_tx_Presp_valid_cdc                      ),
    .dout                           (gmii_txd                                          ), 
    .dout_valid                     (gmii_tx_en                                        )
);

frame_analysis  U_frame_analysis(
    .clk                            (clk                            ),
    .rst_n                          (rst_n                          ),
    .port_num                       (port_num                       ),
    .data_i                         (gmii_rxd                       ),
    .valid_i                        (gmii_rx_dv                     ),
    .pdelay_valid                   (pdelay_valid                   ),
    .pdelay_portIdentity            (pdelay_portIdentity            ),
    .Message_sourcePortIdentity     (Message_sourcePortIdentity     ),
    .Message_Priority1              (Message_Priority1              ),         
    .Message_clockClass             (Message_clockClass             ),        
    .Message_clockAccuracy          (Message_clockAccuracy          ),     
    .Message_offsetScaledLogVariance(Message_offsetScaledLogVariance),   
    .Message_Priority2              (Message_Priority2              ),        
    .Message_clockIdentity          (Message_clockIdentity          ),  
    .Message_stepsRemoved           (Message_stepsRemoved           ),
    .Message_Announce_valid         (Message_Announce_valid         ),

    .Pdelay_Resp_tx_ts              (Pdelay_Resp_tx_ts              ),          // 对端发送Presp的时间点，由Presp_follow帧中提取
    .Pdelay_Resp_tx_ts_valid        (Pdelay_Resp_tx_ts_valid        ),
    .Pdelay_opposite_rx_ts          (Pdelay_opposite_rx_ts          ),          //对端接收Pdelay帧的时间点，由Presp帧中提取
    .Pdelay_opposite_rx_ts_valid    (Pdelay_opposite_rx_ts_valid    ),
    .Sync_tx_ts                     (Sync_tx_ts                     ),
    .Sync_correction_field          (Sync_correction_field          ),
    .Sync_ts_valid                  (Sync_ts_valid                  )
);

BMCA U_BMCA(
    .clk                            (clk                            ),
    .rst_n                          (rst_n                          ),
    .Disable_cmd                    (1'b0                           ),
    .Passive_cmd                    (1'b0                           ),
    .Priority1                      (Priority1                      ),
    .clockClass                     (clockClass                     ),
    .clockAccuracy                  (clockAccuracy                  ),         
    .offsetScaledLogVariance        (offsetScaledLogVariance        ),
    .Priority2                      (Priority2                      ),
    .clockIdentity                  (clockIdentity                  ), 
    .message_sourcePortIdentity     (Message_sourcePortIdentity     ), 
    .message_Priority1              (Message_Priority1              ),
    .message_clockClass             (Message_clockClass             ),
    .message_clockAccuracy          (Message_clockAccuracy          ),
    .message_offsetScaledLogVariance(Message_offsetScaledLogVariance),
    .message_Priority2              (Message_Priority2              ),
    .message_clockIdentity          (Message_clockIdentity          ),
    .message_stepsRemoved           (Message_stepsRemoved           ),
    .Announce_valid                 (Message_Announce_valid         ),
    .portstate                      (port_state                     ),
    .portstate_valid                (portstate_valid                )
);

compute U_compute(
    .clk                            (clk                            ),
    .rst                            (~rst_n                         ),       
    .timestamp_tx_Pdelay_valid_cdc  (timestamp_tx_Pdelay_valid_cdc  ),     //本地发送Preq的时间点，用于计算时延
    .timestamp_rx_Presp_valid_cdc   (timestamp_rx_Presp_valid_cdc   ),     //本地接收Presp帧的时间点，用于计算时延

    .Pdelay_opposite_rx_ts          (Pdelay_opposite_rx_ts          ),     //对端接收Pdelay帧的时间点，由Presp帧中提取，用于计算时延
    .Pdelay_opposite_rx_ts_valid    (Pdelay_opposite_rx_ts_valid    ),
    .Pdelay_Resp_tx_ts              (Pdelay_Resp_tx_ts              ),     //对端发送Presp帧的时间点，由followup帧中提取，用于计算时延
    .Pdelay_Resp_tx_ts_valid        (Pdelay_Resp_tx_ts_valid        ),

    .Sync_tx_ts                     (Sync_tx_ts                     ),     //对端发送Sync帧的时间点，由followup帧中提取，用于时钟同步
    .Sync_correction_field          (Sync_correction_field          ),
    .Sync_ts_valid                  (Sync_ts_valid                  ),
    
    .timestamp_rx_Sync_valid_cdc    (timestamp_rx_Sync_valid_cdc    ),      
    .timer                          (timer                          ),
    .offset                         (offset                         ),
    .valid                          (valid                          ),
    .sign                           (sign                           ),
    .sys_time                       (sys_time                       ),
    .link_delay_out                 (link_delay                     ),
    .link_delay_valid_out           (link_delay_valid               )
);

`ifdef DEBUG
ila_oc_data debug_oc_data(
	.clk                            (clk                            ), // input wire clk
    .probe0                         (gmii_rxd                       ), // input wire [7:0]  probe0  
	.probe1                         (gmii_rx_dv                     ), // input wire [0:0]  probe1 
	.probe2                         (gmii_txd                       ), // input wire [7:0]  probe2 
	.probe3                         (gmii_tx_en                     ), // input wire [0:0]  probe3 
	.probe4                         (timestamp_tx_Pdelay_valid_cdc  ), // input wire [0:0]  probe4 
	.probe5                         (timestamp_tx_Sync_valid_cdc    ), // input wire [0:0]  probe5 
	.probe6                         (timestamp_tx_Presp_valid_cdc   ), // input wire [0:0]  probe6 
	.probe7                         (timestamp_rx_Pdelay_valid_cdc  ), // input wire [0:0]  probe7 
	.probe8                         (timestamp_rx_Sync_valid_cdc    ), // input wire [0:0]  probe8 
	.probe9                         (timestamp_rx_Presp_valid_cdc   ), // input wire [0:0]  probe9 
	.probe10                        (port_state                     ), // input wire [3:0]  probe10 
	.probe11                        (portstate_valid                ), // input wire [0:0]  probe11 
	.probe12                        (offset                         ), // input wire [79:0] probe12 
	.probe13                        (valid                          ), // input wire [0:0]  probe13 
	.probe14                        (sign                           ), // input wire [0:0]  probe14 
	.probe15                        (link_delay                     ), // input wire [79:0] probe15 
	.probe16                        (link_delay_valid               )  // input wire [0:0]  probe16
);
`endif

endmodule
