`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/04/24 19:17:07
// Module Name: BMCA
// Description: Pipelined Best Master Clock Algorithm (IEEE 802.1AS)
//////////////////////////////////////////////////////////////////////////////////

module BMCA #(
    parameter [15:0] MY_PORT_NUMBER = 16'h0001 // 本地端口号，用于比较向量末尾
)(
    input          clk,
    input          rst_n,
    input          Disable_cmd,
    input          Passive_cmd,

    // --- 本地时钟属性 (Local Attributes) ---
    input  [7:0]   Priority1,
    input  [7:0]   clockClass,
    input  [7:0]   clockAccuracy,
    input  [15:0]  offsetScaledLogVariance,
    input  [7:0]   Priority2,
    input  [63:0]  clockIdentity, // 本地 Global Clock ID

    // --- 接收到的 Announce 报文属性 (Message Attributes) ---
    input  [79:0]  message_sourcePortIdentity, 
    input  [7:0]   message_Priority1,
    input  [7:0]   message_clockClass,
    input  [7:0]   message_clockAccuracy,
    input  [15:0]  message_offsetScaledLogVariance,
    input  [7:0]   message_Priority2,
    input  [63:0]  message_clockIdentity, // 报文 Body 中的 GM ID
    input  [15:0]  message_stepsRemoved,
    
    (*mark_debug = "true"*) input          Announce_valid,
    (*mark_debug = "true"*) output [3:0]   portstate,
    (*mark_debug = "true"*) output         portstate_valid
);

    // --- 状态机定义 ---
    localparam IDLE    = 7'b000_0001;
    localparam JUDGE   = 7'b000_0010;
    localparam COMPARE = 7'b000_0100;
    localparam PASSIVE = 7'b000_1000;
    localparam DISABLE = 7'b001_0000;
    localparam MASTER  = 7'b010_0000;
    localparam SLAVE   = 7'b100_0000;

    reg [6:0] cstate, nstate;
    reg [3:0] portstate_reg;
    reg       portstate_valid_reg;

    // --- 寄存器定义：用于锁存输入的 Message ---
    reg [7:0]   message_Priority1_reg;
    reg [7:0]   message_clockClass_reg;
    reg [7:0]   message_clockAccuracy_reg;
    reg [15:0]  message_offsetScaledLogVariance_reg;
    reg [7:0]   message_Priority2_reg;
    reg [63:0]  message_clockIdentity_reg;
    reg [15:0]  message_stepsRemoved_reg;
    reg [79:0]  message_sourcePortIdentity_reg; // 新增

    // --- 比较结果信号 ---
    reg Master_cmd;
    reg Slave_cmd;
    reg compare_error;

    // --- 流水线控制 ---
    reg [1:0] pipe_cnt; // 计数器，确保流水线走完 3 级
    
    // --- 定义比较向量 ---
    // 总位宽 224 bits:
    // SysIdentity(112) + Steps(16) + SourcePortIdentity(80) + RecvPortNumber(16)
    wire [223:0] vec_local;
    wire [223:0] vec_msg;

    // =========================================================================
    // 1. 输入锁存逻辑 (Input Latching)
    // =========================================================================
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            message_Priority1_reg               <= 8'b0;
            message_clockClass_reg              <= 8'b0;
            message_clockAccuracy_reg           <= 8'b0;
            message_offsetScaledLogVariance_reg <= 16'b0;
            message_Priority2_reg               <= 8'b0;
            message_clockIdentity_reg           <= 64'b0;
            message_stepsRemoved_reg            <= 16'b0;
            message_sourcePortIdentity_reg      <= 80'b0;
        end
        else if(Announce_valid) begin
            message_Priority1_reg               <= message_Priority1;
            message_clockClass_reg              <= message_clockClass;
            message_clockAccuracy_reg           <= message_clockAccuracy;
            message_offsetScaledLogVariance_reg <= message_offsetScaledLogVariance;
            message_Priority2_reg               <= message_Priority2;
            message_clockIdentity_reg           <= message_clockIdentity;
            message_stepsRemoved_reg            <= message_stepsRemoved;
            message_sourcePortIdentity_reg      <= message_sourcePortIdentity;
        end
    end

    // =========================================================================
    // 2. 构建优先级向量 (Priority Vector Construction)
    // =========================================================================
    
    // Message 向量: 来自报文内容
    assign vec_msg = {
        // [223:112] Root System Identity (112 bits)
        message_Priority1_reg,
        message_clockClass_reg,
        message_clockAccuracy_reg,
        message_offsetScaledLogVariance_reg,
        message_Priority2_reg,
        message_clockIdentity_reg,        //GrandMaster的clockIdentity
        
        // [111:96] Steps Removed (16 bits)
        message_stepsRemoved_reg,

        // [95:16] Source Port Identity (80 bits) 
        message_sourcePortIdentity_reg,   //发送给本地的源PortIdentity

        // [15:0] Receiving Port Number (16 bits) - 本地接收端口号
        MY_PORT_NUMBER 
    };

    // Local 向量: 假设我自己做 Master (Best Master if I win)
    assign vec_local = {
        // [223:112] Root System Identity (我的属性)
        Priority1,
        clockClass,
        clockAccuracy,
        offsetScaledLogVariance,
        Priority2,
        clockIdentity, // My Global ID
        
        // [111:96] Steps Removed (如果是自己，距离为0)
        16'h0000,

        // [95:16] Source Port Identity (如果是我发的包，Source就是我)
        clockIdentity,  // My Global ID (64b)
        MY_PORT_NUMBER, // My Port Num (16b)

        // [15:0] Receiving Port Number (最后一位通常填自己占位)
        MY_PORT_NUMBER
    };

    // =========================================================================
    // 3. 流水线比较逻辑 (Pipelined Comparison)
    // =========================================================================
    
    // 定义流水线寄存器
    // Stage 1 Result: 00=Equal, 01=Msg<Local(Slave), 10=Msg>Local(Master)
    reg [1:0] stage1_res; 
    reg [1:0] stage2_res;
    
    // --- Stage 1: 比较高 112 bits (System Identity) ---
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) stage1_res <= 2'b00;
        else if(cstate == COMPARE) begin
            if (vec_msg[223:112] < vec_local[223:112])
                stage1_res <= 2'b01; // Message Better -> Slave
            else if (vec_msg[223:112] > vec_local[223:112])
                stage1_res <= 2'b10; // Local Better -> Master
            else
                stage1_res <= 2'b00; // Equal
        end
        else stage1_res <= 2'b00;
    end

    // --- Stage 2: 比较中段 96 bits (Steps + SourcePortID) ---
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) stage2_res <= 2'b00;
        else if(cstate == COMPARE) begin
            if (stage1_res != 2'b00) begin
                // 如果 Stage 1 已经分出胜负，直接传递结果
                stage2_res <= stage1_res;
            end
            else begin
                // Stage 1 平手，比较 Stage 2
                if (vec_msg[111:16] < vec_local[111:16])
                    stage2_res <= 2'b01;
                else if (vec_msg[111:16] > vec_local[111:16])
                    stage2_res <= 2'b10;
                else
                    stage2_res <= 2'b00;
            end
        end
        else stage2_res <= 2'b00;
    end

    // --- Stage 3: 比较低 16 bits (Recv Port) & 生成最终指令 ---
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            Master_cmd    <= 1'b0;
            Slave_cmd     <= 1'b0;
            compare_error <= 1'b0;
        end
        else if(cstate == COMPARE) begin
            // 只有当 pipe_cnt 计数达到 2 (即第3个周期) 时，输出才有效
            if (pipe_cnt == 2'd2) begin
                if (stage2_res == 2'b01) begin
                    Slave_cmd <= 1'b1; Master_cmd <= 1'b0;
                end
                else if (stage2_res == 2'b10) begin
                    Master_cmd <= 1'b1; Slave_cmd <= 1'b0;
                end
                else begin
                    // Stage 1 & 2 都平手，最后比端口号
                    if (vec_msg[15:0] < vec_local[15:0]) begin
                         Slave_cmd <= 1'b1; Master_cmd <= 1'b0;
                    end
                    else if (vec_msg[15:0] > vec_local[15:0]) begin
                         Master_cmd <= 1'b1; Slave_cmd <= 1'b0;
                    end
                    else begin
                         // 完全相等 (理论上不可能，除非收到了自己发出的包)
                         Master_cmd <= 1'b0; Slave_cmd <= 1'b0; compare_error <= 1'b1;
                    end
                end
            end
        end
        else begin
            Master_cmd    <= 1'b0;
            Slave_cmd     <= 1'b0;
            compare_error <= 1'b0;
        end
    end

    // =========================================================================
    // 4. 状态机控制逻辑 (FSM)
    // =========================================================================
    
    // 计数器逻辑：用于在 COMPARE 状态停留，等待流水线完成
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) pipe_cnt <= 2'd0;
        else if(cstate == COMPARE) begin
            if(pipe_cnt < 2'd3) 
                pipe_cnt <= pipe_cnt + 1'b1;
        end
        else pipe_cnt <= 2'd0;
    end

    // 状态跳转逻辑
    always @(*) begin
        case(cstate)
            IDLE: begin
                if(Announce_valid) nstate = JUDGE;
                else nstate = IDLE;
            end
            JUDGE: begin
                // 初步过滤：如果是自己发的包(SourceID=Self)则忽略，防止自环
                // 注意：这里简单判断 ClockIdentity 是否为自己
                if(message_clockIdentity_reg != clockIdentity && message_stepsRemoved_reg <= 16'd254)
                    nstate = COMPARE;
                else
                    nstate = IDLE;
            end
            COMPARE: begin
                // 优先响应外部强制指令
                if(Passive_cmd)       nstate = PASSIVE;
                else if(Disable_cmd)  nstate = DISABLE;
                // 等待流水线结果有效 (pipe_cnt >= 2)
                else if(pipe_cnt >= 2'd2) begin
                    if(Master_cmd)        nstate = MASTER;
                    else if(Slave_cmd)    nstate = SLAVE;
                    else if(compare_error)nstate = IDLE;
                    else                  nstate = COMPARE; // 等待结果
                end
                else begin
                    nstate = COMPARE; // 流水线未走完，保持
                end
            end
            PASSIVE, DISABLE, MASTER, SLAVE: begin
                nstate = IDLE; // 完成一次决策后返回 IDLE
            end
            default: nstate = IDLE;
        endcase
    end

    // 状态寄存器更新
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) cstate <= IDLE;
        else cstate <= nstate;
    end

    // 输出逻辑
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            portstate_reg <= 4'b0;
            portstate_valid_reg <= 1'b0;
        end
        else begin
            case(cstate)
                PASSIVE: begin portstate_reg <= 4'b0001; portstate_valid_reg <= 1'b1; end
                DISABLE: begin portstate_reg <= 4'b0010; portstate_valid_reg <= 1'b1; end
                MASTER:  begin portstate_reg <= 4'b0100; portstate_valid_reg <= 1'b1; end
                SLAVE:   begin portstate_reg <= 4'b1000; portstate_valid_reg <= 1'b1; end
                default: begin portstate_reg <= 4'b0000; portstate_valid_reg <= 1'b0; end
            endcase
        end
    end

    assign portstate = portstate_reg;
    assign portstate_valid = portstate_valid_reg;

endmodule