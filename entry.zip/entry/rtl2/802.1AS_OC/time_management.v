`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: XIDIAN university
// Engineer:wanghaoyu
// 
// Create Date: 2025/04/27 20:18:36
// Design Name: 
// Module Name: time_management
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// Engineer: 
// 
// Create Date: 2025/04/27 20:18:36
// Design Name: 
// Module Name: time_management
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module time_management (
        input  clk,
        input  rst_n, 
        //配置信息
        input   [7:0]    LogInterval_sync     ,
        input   [7:0]    LogInterval_pdelay   ,
        input   [7:0]    LogInterval_announce ,
        input   [3:0]    port_state,
        input            portstate_valid,  

        //时钟纠偏信号
        input   [79:0]   offset,
        input            valid ,
        input            sign  ,
        input            clock_message_change,

        output  reg      Pdelay_Req_en , 
        output  reg      Sync_en ,
        output  reg      Announce_en ,
        
    
        output  [79:0]   timer ,//本地时钟，低32位为ns
        output  reg      sys_sync ,

        output  [31:0]   upload_port_state,
        output  [79:0]   sys_time,
        output           pulse
 
);

// --- Port State Definitions ---
localparam P_PASSIVE = 4'b0001;
localparam P_DISABLE = 4'b0010;
localparam P_MASTER  = 4'b0100;
localparam P_SLAVE   = 4'b1000;
localparam P_LISTEN  = 4'b1111;

//Paramter(s)
parameter  period_ns_decimal   = 16'h0000;
parameter  period_ns           = 8'h08;

reg  [47:0] timer_s ;
reg  [31:0] timer_ns ;

//本地参与纠偏时钟
reg  [47:0] sys_time_s ;
reg  [31:0] sys_time_ns ;
reg  [15:0] sys_time_ns_decimal;
wire [31:0] offset_ns;
wire [47:0] offset_s ;

wire [95:0] system_time_decimal;

reg [31:0] interval_ns_sync_val;
reg [31:0] interval_ns_pdelay_val;
reg [31:0] interval_ns_announce_val;

//取SLAVE口的offset
assign offset_ns = offset [31:0] ;
assign offset_s  = offset [79:32] ;

//ila
reg     pulse_out;
assign  pulse=pulse_out;

//端口状态寄存
reg [3:0] port_state_reg;
reg [63:0] announceReceiptTimeout;
assign upload_port_state = {28'b0, port_state_reg};

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        port_state_reg <= P_LISTEN;
    end
    else if((port_state_reg == P_SLAVE && announceReceiptTimeout >= 3*interval_ns_announce_val) || clock_message_change)begin
        port_state_reg <= P_LISTEN;
    end
    else if (portstate_valid) begin
        port_state_reg <= port_state;
    end   
    else begin
        port_state_reg <= port_state_reg;
    end
end

//Announce watch dog
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        announceReceiptTimeout <= 64'b0;
    end
    else if (portstate_valid) begin
        announceReceiptTimeout <= 64'b0;
    end   
    else begin
        announceReceiptTimeout <= announceReceiptTimeout + 64'd8;
    end
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        sys_time_ns_decimal <= 15'd0 ;
    end
    else if ((sys_time_ns_decimal + period_ns_decimal) >= 'd10000) begin
        sys_time_ns_decimal <= sys_time_ns_decimal + period_ns_decimal - 'd10000 ;
    end   
    else begin
        sys_time_ns_decimal <= sys_time_ns_decimal + period_ns_decimal ;
    end
end

//纠偏时钟ns部分计数
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        sys_time_ns <= 32'd0 ;
    end
    else if (valid) begin
        if (sign == 1'b0) begin
            if ((sys_time_ns_decimal + period_ns_decimal) >= 'd10000) begin
                if (sys_time_ns + period_ns + 'd1 >= offset_ns) begin
                    if (sys_time_ns + period_ns + 'd1 - offset_ns >= 32'd1000000000) begin
                        sys_time_ns <= sys_time_ns + period_ns + 'd1 - offset_ns - 32'd1000000000 ;                     
                    end
                    else begin
                        sys_time_ns <= sys_time_ns + period_ns + 'd1 - offset_ns ;                     
                    end                 
                end
                else if (sys_time_ns + period_ns + 'd1 < offset_ns) begin
                    sys_time_ns <= sys_time_ns + period_ns + 'd1 + 32'd1000000000 - offset_ns ;    
                end             
            end
            else if ((sys_time_ns_decimal + period_ns_decimal) < 'd10000) begin
                if (sys_time_ns + period_ns >= offset_ns) begin
                    if (sys_time_ns + period_ns - offset_ns >= 32'd1000000000) begin
                        sys_time_ns <= sys_time_ns + period_ns - offset_ns - 32'd1000000000 ;                     
                    end
                    else begin
                        sys_time_ns <= sys_time_ns + period_ns - offset_ns ;                     
                    end                 
                end
                else if (sys_time_ns + period_ns < offset_ns) begin
                    sys_time_ns <= sys_time_ns + period_ns + 32'd1000000000 - offset_ns ;    
                end      
            end     
        end
        else if (sign == 1'b1) begin
            if ((sys_time_ns_decimal + period_ns_decimal) >= 'd10000) begin
                if (sys_time_ns + period_ns + 'd1 + offset_ns >= 32'd1000000000) begin
                    sys_time_ns <= sys_time_ns + period_ns + 'd1 + offset_ns -32'd1000000000 ;
                end
                else begin
                    sys_time_ns <= sys_time_ns + period_ns + 'd1 + offset_ns ;            
                end        
            end
            else if ((sys_time_ns_decimal + period_ns_decimal) < 'd10000) begin
                if (sys_time_ns + period_ns + offset_ns >= 32'd1000000000) begin
                    sys_time_ns <= sys_time_ns + period_ns + offset_ns -32'd1000000000 ;
                end
                else begin
                    sys_time_ns <= sys_time_ns + period_ns + offset_ns ;            
                end                 
            end    
        end    
    end
    else begin//!valid
        if ((sys_time_ns_decimal + period_ns_decimal) >= 'd10000) begin
            if ((sys_time_ns + period_ns + 'd1)>= 'd1000000000) begin
                sys_time_ns <= sys_time_ns + period_ns +'d1 - 'd1000000000 ;  
            end
            else begin
                sys_time_ns <= sys_time_ns + period_ns + 'd1 ;
            end
        end
        else begin
            if ((sys_time_ns + period_ns) >= 'd1000000000) begin
                sys_time_ns <= sys_time_ns + period_ns - 'd1000000000 ;                  
            end 
            else begin
                sys_time_ns <= sys_time_ns + period_ns ;      
            end   
        end  
    end
end

//纠偏时钟s部分计数
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        sys_time_s <= 48'd0 ;
    end
    else if (valid) begin
            if (sign == 1'b0) begin
                if ((sys_time_ns_decimal + period_ns_decimal) >= 'd10000) begin
                    if (sys_time_ns + period_ns + 'd1 >= offset_ns) begin
                        if (sys_time_ns + period_ns + 'd1 - offset_ns >= 32'd1000000000) begin
                            sys_time_s <= sys_time_s + 'd1 - offset_s ;                  
                        end
                        else begin
                            sys_time_s <= sys_time_s - offset_s ;                                     
                        end                 
                    end
                    else if (sys_time_ns + period_ns + 'd1 < offset_ns) begin
                            sys_time_s <= sys_time_s - 'd1 -offset_s ;        
                    end                    
                end
                else if ((sys_time_ns_decimal + period_ns_decimal) < 'd10000) begin
                    if (sys_time_ns + period_ns >= offset_ns) begin
                        if (sys_time_ns + period_ns - offset_ns >= 32'd1000000000) begin
                            sys_time_s <= sys_time_s + 'd1 - offset_s ;                  
                        end
                        else begin
                            sys_time_s <= sys_time_s - offset_s ;                                     
                        end                 
                    end
                    else if (sys_time_ns + period_ns  < offset_ns) begin
                            sys_time_s <= sys_time_s - 'd1 -offset_s ;        
                    end                    
                end                    
            end
            else if (sign == 1'b1) begin
                if ((sys_time_ns_decimal + period_ns_decimal) >= 'd10000) begin
                    if (sys_time_ns + period_ns + 'd1 + offset_ns >= 32'd1000000000) begin
                        sys_time_s <= sys_time_s + 'd1 + offset_s ;
                    end
                    else begin
                        sys_time_s <= sys_time_s + offset_s ;          
                    end        
                end
                else if ((sys_time_ns_decimal + period_ns_decimal) < 'd10000) begin
                    if (sys_time_ns + period_ns + offset_ns >= 32'd1000000000) begin
                        sys_time_s <= sys_time_s + 'd1 + offset_s ;                
                    end
                    else begin
                        sys_time_s <= sys_time_s + offset_s ;             
                    end                 
                end                    
            end
        end
    else begin//!valid
        if ((sys_time_ns_decimal + period_ns_decimal) >= 'd10000) begin
            if ((sys_time_ns + period_ns + 'd1)>= 'd1000000000) begin
                sys_time_s <= sys_time_s + 'd1 ;      
            end 
            else begin
                sys_time_s <= sys_time_s ;   
            end   
        end
        else begin
            if ((sys_time_ns + period_ns) >= 'd1000000000) begin
                sys_time_s <= sys_time_s + 'd1 ;                   
            end 
            else begin
                sys_time_s <= sys_time_s ;
            end   
        end  
    end   
end


assign system_time_decimal = {sys_time_s[47:0],sys_time_ns[31:0],sys_time_ns_decimal[15:0]};
assign sys_time = system_time_decimal[95:16];


//本地脉冲生成
reg [7:0]pulse_cnt;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        pulse_out <= 1'b0;
    end
    else if (sys_time_ns == 32'b0) begin
        pulse_out <= 1'b1;
    end
    else if(pulse_cnt==8'd125)begin
        pulse_out <= 1'b0;
    end
    else
        pulse_out <= pulse_out;
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        pulse_cnt <=8'b0;
    end
    else if (pulse_out) begin
        pulse_cnt <= pulse_cnt+1'b1;
    end
    else begin
        pulse_cnt <= 8'b0;
    end
end

//本地不参与纠偏时钟
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        timer_ns <= 32'h0;
        timer_s  <= 48'h0;
    end
    else if (timer_ns + 'd8 == 32'd10_0000_0000) begin
        timer_ns <= 32'b0 ;
        timer_s  <= timer_s + 'd1 ;
    end
    else begin
        timer_ns <= timer_ns + 'd8 ;
        timer_s  <= timer_s ;
    end
end

//80位本地时间
assign timer = {timer_s[47:0],timer_ns[31:0]};



//   Sync,Pdelay_req,Announce帧产生使能
// ============================================================
//   Frame Interval Generation Logic
// ============================================================

// 1. Interval Decode: 将 LogInterval 转换为纳秒计数值
// ------------------------------------------------------------

// 解码函数：根据 802.1AS log值转换为 ns
// 支持 -4(62.5ms) 到 +1(2s) 的常见范围
function [31:0] log2ns;
    input [7:0] log_val;
    begin
        case(log_val)
            8'hFC: log2ns = 32'd62_500_000   ;   // -4: 62.5ms
            8'hFD: log2ns = 32'd125_000_000  ;   // -3: 125ms (Default Sync)
            8'hFE: log2ns = 32'd250_000_000  ;   // -2: 250ms
            8'hFF: log2ns = 32'd100_0000     ;   // -1: 500ms
            8'h00: log2ns = 32'd1_000_000_000;   //  0: 1s (Default Pdelay/Announce)
            8'h01: log2ns = 32'd2_000_000_000;   // +1: 2s
            default: log2ns = 32'd1_000_000_000; // Default to 1s
        endcase
    end
endfunction

always @(*) begin
    interval_ns_sync_val     = log2ns(LogInterval_sync)    ;
    interval_ns_pdelay_val   = log2ns(LogInterval_pdelay)  ;
    interval_ns_announce_val = log2ns(LogInterval_announce);
end

// 2. Counters & Enable Generation
// ------------------------------------------------------------
reg [31:0] cnt_sync_ns;
reg [31:0] cnt_pdelay_ns;
reg [31:0] cnt_announce_ns;

// --- A. Sync Message Generation ---
// 条件：只有在 MASTER 状态下发送
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        cnt_sync_ns <= 32'd0;
        Sync_en     <= 1'b0;
    end
    else begin
        // 计数器累加
        if (cnt_sync_ns >= interval_ns_sync_val) begin
            cnt_sync_ns <= period_ns; // Reset to current step
            // 只有 Master 才发 Sync
            if (port_state_reg == P_MASTER) 
                Sync_en <= 1'b1;
            else 
                Sync_en <= 1'b0;
        end
        else begin
            cnt_sync_ns <= cnt_sync_ns + period_ns;
            Sync_en     <= 1'b0;
        end
    end
end

// --- B. Pdelay_Req Message Generation ---
// 条件：只要端口没有 DISABLE 就可以发送 (Master/Slave/Passive 都需要测距)
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        cnt_pdelay_ns <= 32'd0;
        Pdelay_Req_en <= 1'b0;
    end
    else begin
        if (cnt_pdelay_ns >= interval_ns_pdelay_val) begin
            cnt_pdelay_ns <= period_ns;
            // Disable 状态不发包，其他状态通常都发送
            if (port_state_reg != P_DISABLE) 
                Pdelay_Req_en <= 1'b1;
            else 
                Pdelay_Req_en <= 1'b0;
        end
        else begin
            cnt_pdelay_ns <= cnt_pdelay_ns + period_ns;
            Pdelay_Req_en <= 1'b0;
        end
    end
end

// --- C. Announce Message Generation ---
// 条件：只有在 MASTER 状态下发送
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        cnt_announce_ns <= 32'd0;
        Announce_en     <= 1'b0;
    end
    else begin
        if (cnt_announce_ns >= interval_ns_announce_val) begin
            cnt_announce_ns <= period_ns;
            // 只有 Master 才发 Announce
            if (port_state_reg == P_MASTER || port_state_reg == P_LISTEN) 
                Announce_en <= 1'b1;
            else 
                Announce_en <= 1'b0;
        end
        else begin
            cnt_announce_ns <= cnt_announce_ns + period_ns;
            Announce_en     <= 1'b0;
        end
    end
end

// 同步信号产生
// ============================================================
//  System Sync Status Generation (sys_sync)
// ============================================================
// Master: 发送 3 帧 Sync 后拉高 (表示网络应已同步)
// Slave:  连续 5 次纠偏 Offset < 1000ns 后拉高 (表示本地已锁定)
// ============================================================

// 参数定义
localparam LOCK_THRESHOLD_NS   = 32'd1000;  // Slave锁定阈值：1us
localparam UNLOCK_THRESHOLD_NS = 32'd2000;  // Slave失锁阈值：2us
localparam SLAVE_STABILITY_TGT = 4'd5;      // Slave稳定性计数目标
localparam MASTER_SYNC_TGT     = 4'd3;      // Master发送Sync帧数目标

reg [3:0]  lock_stability_cnt;              // Slave用的稳定性计数器
reg [3:0]  master_sync_sent_cnt;            // Master用的发送计数器

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        lock_stability_cnt   <= 4'd0;
        master_sync_sent_cnt <= 4'd0;
        sys_sync             <= 1'b0;
    end
    else begin
        // ----------------------------------------------------
        // Case 1: MASTER 模式
        // 逻辑：统计 Sync_en 脉冲，发送满 3 帧后拉高 sys_sync
        // ----------------------------------------------------
        if (port_state_reg == P_MASTER) begin
            // 每次 Sync_en 为高(发送Sync帧)，计数器加 1
            if (Sync_en) begin
                if (master_sync_sent_cnt < MASTER_SYNC_TGT)
                    master_sync_sent_cnt <= master_sync_sent_cnt + 1'b1;
            end

            // 判断是否达到目标
            if (master_sync_sent_cnt >= MASTER_SYNC_TGT)
                sys_sync <= 1'b1;
            else
                sys_sync <= 1'b0;

            // 清零 Slave 的计数器，防止状态切换残留
            lock_stability_cnt <= 4'd0; 
        end
        
        // ----------------------------------------------------
        // Case 2: SLAVE 模式
        // 逻辑：基于 offset 的收敛情况判断
        // ----------------------------------------------------
        else if (port_state_reg == P_SLAVE) begin
            // 清零 Master 的计数器
            master_sync_sent_cnt <= 4'd0;

            if (valid) begin // 当收到新的纠偏值时进行判断
                // A. 尝试锁定
                if (sys_sync == 1'b0) begin
                    if (offset_ns < LOCK_THRESHOLD_NS) begin
                        if (lock_stability_cnt < SLAVE_STABILITY_TGT)
                            lock_stability_cnt <= lock_stability_cnt + 1'b1;
                        else
                            sys_sync <= 1'b1; // 锁定
                    end
                    else begin
                        lock_stability_cnt <= 4'd0; // 只要有一次超标，清零重来
                    end
                end
                // B. 失锁监控 (滞回)
                else begin
                    if (offset_ns > UNLOCK_THRESHOLD_NS) begin
                        sys_sync           <= 1'b0;
                        lock_stability_cnt <= 4'd0;
                    end
                end
            end
        end
        // ----------------------------------------------------
        // Case 3: 异常/其他状态 (DISABLE, LISTENING)
        // ----------------------------------------------------
        else begin
            sys_sync             <= 1'b0;
            lock_stability_cnt   <= 4'd0;
            master_sync_sent_cnt <= 4'd0;
        end
    end
end

`ifdef DEBUG
ila_time_manager U_ila_time_manager (
	.clk                    (clk                    ), // input wire clk
	.probe0                 (port_state_reg         ), // input wire [3:0]  probe0  
	.probe1                 (clock_message_change   ), // input wire [0:0]  probe1 
	.probe2                 (Announce_en            ), // input wire [0:0]  probe2 
	.probe3                 (LogInterval_announce   ) // input wire [7:0]  probe3
);
`endif
endmodule
