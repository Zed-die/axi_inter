`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2022/07/12 09:12:46
// Design Name: 
// Module Name: 325t_top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module GMII_top(
    input           sys_clk_p     , // 100M
    input           sys_clk_n     ,
    input           gtrefclk_p    , // 125M
    input           gtrefclk_n    ,
    input           clk_200m_n    , // 200M
    input           clk_200m_p    ,

    output          ui_clk        ,
    input           rst_n         ,
 
    input           rxn_1         ,
    input           rxp_1         ,
    input           rxn_2         ,
    input           rxp_2         ,
    input           rxn_3         ,
    input           rxp_3         ,
    input           rxn_4         ,
    input           rxp_4         ,
        
    output          txn_1         ,
    output          txp_1         ,
    output          txn_2         ,
    output          txp_2         ,
    output          txn_3         ,
    output          txp_3         ,
    output          txn_4         ,
    output          txp_4         ,
    output          Link_1        ,
    output          Link_2        ,
    output          Link_3        ,
    output          Link_4        ,

    /* 
     * GMII Tx Rx
     */
    output          clk_125M      ,
    output          userclk2_out  ,
    input   [7:0]   gmii_txd_A    ,
    input           gmii_tx_en_A  ,
    input   [7:0]   gmii_txd_B    ,
    input           gmii_tx_en_B  ,
    input   [7:0]   gmii_txd_C    ,
    input           gmii_tx_en_C  ,
    input   [7:0]   gmii_txd_D    ,
    input           gmii_tx_en_D  ,
    output  [7:0]   gmii_rxd_A    ,
    output          gmii_rx_en_A  ,
    output  [7:0]   gmii_rxd_B    ,
    output          gmii_rx_en_B  ,
    output  [7:0]   gmii_rxd_C    ,
    output          gmii_rx_en_C  ,
    output  [7:0]   gmii_rxd_D    ,
    output          gmii_rx_en_D  ,

    output      [3:0]       timestamp_tx_Pdelay_valid_cdc,
    output      [3:0]       timestamp_tx_Sync_valid_cdc  ,
    output      [3:0]       timestamp_tx_Presp_valid_cdc ,
    output      [3:0]       timestamp_rx_Pdelay_valid_cdc,
    output      [3:0]       timestamp_rx_Sync_valid_cdc  ,
    output      [3:0]       timestamp_rx_Presp_valid_cdc ,
    output      [3:0]       timestamp_rx_Sync_follow_valid_cdc ,
    output      [3:0]       timestamp_rx_Presp_follow_valid_cdc,
    output      [3:0]       timestamp_rx_Announce_valid_cdc    ,

    //CPU配置
    input                   wen_phy   ,
    input       [31:0]      waddr_phy ,
    input       [31:0]      wdata_phy ,

    //axis interface
    output     [63:0]       m_axis_up_load_data1 ,
    output                  m_axis_up_load_last1 ,
    output                  m_axis_up_load_valid1,
    input                   m_axis_up_load_ready1,
    output     [7:0]        m_axis_up_load_keep1 ,
    input                   card_upload_ren_1    ,
    output     reg          card_upload_flag_1   ,

    //DDR3 interface
    // Inouts
    inout [63:0]       ddr3_dq,
    inout [7:0]        ddr3_dqs_n,
    inout [7:0]        ddr3_dqs_p,
   
    // Outputs
    output [14:0]      ddr3_addr,
    output [2:0]       ddr3_ba,
    output             ddr3_ras_n,
    output             ddr3_cas_n,
    output             ddr3_we_n,
    output             ddr3_reset_n,
    output [0:0]       ddr3_ck_p,
    output [0:0]       ddr3_ck_n,
    output [0:0]       ddr3_cke,
    output [0:0]       ddr3_cs_n,
    output [7:0]       ddr3_dm,
    output [0:0]       ddr3_odt
);


wire clk;
wire clk_200m;
wire locked;

reg    sync_125m_rst;
reg    sync_125m_rst_f;
reg    sync_200m_rst;
reg    sync_200m_rst_f;
wire   sync_125m_rst_global;

assign clk_125M = clk;

wire card_upload_ren_sys ;
wire card_upload_flag_sys;
reg  card_upload_flag_sys1;

//rst for 125m
always @(posedge clk or negedge rst_n)
begin
    if (~rst_n)
      sync_125m_rst <= 1'b1 ;
    else if (locked)
      sync_125m_rst <= 1'b0 ;   //同步释放
    else 
      sync_125m_rst <= sync_125m_rst ;
end

always @(posedge clk or negedge rst_n)
begin
    if (~rst_n)
      sync_125m_rst_f <= 1'b1 ;
    else 
      sync_125m_rst_f <= sync_125m_rst ;
end

BUFG u_bufg_rst (
    .I(sync_125m_rst_f),       // 输入：原始复位
    .O(sync_125m_rst_global)    // 输出：驱动全局的复位
);

//rst for pcs_pma 200m
always @(posedge clk_200m or negedge rst_n)
begin
    if (~rst_n)
      sync_200m_rst <= 1'b1 ;
    else if (locked)
      sync_200m_rst <= 1'b0 ;
    else 
      sync_200m_rst <= sync_200m_rst ;
end

always @(posedge clk_200m or negedge rst_n)
begin
    if (~rst_n)
      sync_200m_rst_f <= 1'b1 ;
    else 
      sync_200m_rst_f <= sync_200m_rst ;
end

clk_wiz_0 U_clk_gen
 (
  // Clock out ports
  .clk_out1(clk),          // 125m user clock
  .clk_out2(clk_200m),     // 200m ip clk
  // Status and control signals
  .reset(~rst_n), // input reset
  .locked(locked),       // output locked
 // Clock in ports
  .clk_in1_p(sys_clk_p),   
  .clk_in1_n(sys_clk_n)
);  


pcs_pma U_pcs_pma(
    .clk                                (clk)                     ,
    .clk_200M                           (clk_200m)                ,
    .clk_200m_n                         (clk_200m_n)              ,
    .clk_200m_p                         (clk_200m_p)              ,
    .ui_clk                             (ui_clk)                  ,    //DDR的用户时钟
    .rst                                (sync_125m_rst_global)    ,
    .rst_200m                           (sync_200m_rst_f)         ,
    .gtrefclk_p                         (gtrefclk_p)              ,
    .gtrefclk_n                         (gtrefclk_n)              ,
    .rxn_1                              (rxn_1)                   ,
    .rxp_1                              (rxp_1)                   ,
    .rxn_2                              (rxn_2)                   ,
    .rxp_2                              (rxp_2)                   ,
    .rxn_3                              (rxn_3)                   ,
    .rxp_3                              (rxp_3)                   ,
    .rxn_4                              (rxn_4)                   ,
    .rxp_4                              (rxp_4)                   ,
    .gmii_txd_1                         (gmii_txd_A)              ,
    .gmii_tx_en_1                       (gmii_tx_en_A)            ,
    .gmii_txd_2                         (gmii_txd_B)              ,
    .gmii_tx_en_2                       (gmii_tx_en_B)            ,
    .gmii_txd_3                         (gmii_txd_C)              ,
    .gmii_tx_en_3                       (gmii_tx_en_C)            ,
    .gmii_txd_4                         (gmii_txd_D)              ,
    .gmii_tx_en_4                       (gmii_tx_en_D)            ,
    .txn_1                              (txn_1)                   ,
    .txp_1                              (txp_1)                   ,
    .txn_2                              (txn_2)                   ,
    .txp_2                              (txp_2)                   ,
    .txn_3                              (txn_3)                   ,
    .txp_3                              (txp_3)                   ,
    .txn_4                              (txn_4)                   ,
    .txp_4                              (txp_4)                   ,
    .gmii_rxd_1                         (gmii_rxd_A)              ,
    .gmii_rx_dv_1                       (gmii_rx_en_A)            ,
    .gmii_rxd_2                         (gmii_rxd_B)              ,
    .gmii_rx_dv_2                       (gmii_rx_en_B)            ,
    .gmii_rxd_3                         (gmii_rxd_C)              ,
    .gmii_rx_dv_3                       (gmii_rx_en_C)            ,
    .gmii_rxd_4                         (gmii_rxd_D)              ,
    .gmii_rx_dv_4                       (gmii_rx_en_D)            ,
    .userclk2_out                       (userclk2_out)            ,
    .Link_1                             (Link_1)                  ,              
    .Link_2                             (Link_2)                  ,
    .Link_3                             (Link_3)                  ,
    .Link_4                             (Link_4)                  ,
    .timestamp_tx_Pdelay_valid_cdc      (timestamp_tx_Pdelay_valid_cdc      ),
    .timestamp_tx_Sync_valid_cdc        (timestamp_tx_Sync_valid_cdc        ),
    .timestamp_tx_Presp_valid_cdc       (timestamp_tx_Presp_valid_cdc       ),
    .timestamp_rx_Pdelay_valid_cdc      (timestamp_rx_Pdelay_valid_cdc      ),
    .timestamp_rx_Sync_valid_cdc        (timestamp_rx_Sync_valid_cdc        ),
    .timestamp_rx_Presp_valid_cdc       (timestamp_rx_Presp_valid_cdc       ),
    .timestamp_rx_Sync_follow_valid_cdc (timestamp_rx_Sync_follow_valid_cdc ),
    .timestamp_rx_Presp_follow_valid_cdc(timestamp_rx_Presp_follow_valid_cdc),
    .timestamp_rx_Announce_valid_cdc    (timestamp_rx_Announce_valid_cdc    ),

    .wen_phy                            (wen_phy               ),
    .waddr_phy                          (waddr_phy             ),
    .wdata_phy                          (wdata_phy             ),

    .m_axis_up_load_data1               (m_axis_up_load_data1  ),    
    .m_axis_up_load_last1               (m_axis_up_load_last1  ),    
    .m_axis_up_load_valid1              (m_axis_up_load_valid1 ),    
    .m_axis_up_load_ready1              (m_axis_up_load_ready1 ),    
    .m_axis_up_load_keep1               (m_axis_up_load_keep1  ), 
    .card_upload_ren_1                  (card_upload_ren_sys   ),
    .card_upload_flag_1                 (card_upload_flag_sys  ),   

    //DDR3 interface
    .ddr3_dq                            (ddr3_dq               ),
    .ddr3_dqs_n                         (ddr3_dqs_n            ),
    .ddr3_dqs_p                         (ddr3_dqs_p            ),
    .ddr3_addr                          (ddr3_addr             ),
    .ddr3_ba                            (ddr3_ba               ),
    .ddr3_ras_n                         (ddr3_ras_n            ),
    .ddr3_cas_n                         (ddr3_cas_n            ),
    .ddr3_we_n                          (ddr3_we_n             ),
    .ddr3_reset_n                       (ddr3_reset_n          ),
    .ddr3_ck_p                          (ddr3_ck_p             ),
    .ddr3_ck_n                          (ddr3_ck_n             ),
    .ddr3_cke                           (ddr3_cke              ),
    .ddr3_cs_n                          (ddr3_cs_n             ),
    .ddr3_dm                            (ddr3_dm               ),
    .ddr3_odt                           (ddr3_odt              )
);

always@(posedge userclk2_out or negedge rst_n)begin
    if(~rst_n)begin
      card_upload_flag_sys1 <= 1'b0;
      card_upload_flag_1    <= 1'b0;
    end
    else begin
      card_upload_flag_sys1 <= card_upload_flag_sys;
      card_upload_flag_1    <= card_upload_flag_sys1;
    end
end


xpm_cdc_pulse #(
   .DEST_SYNC_FF(2),   // DECIMAL; range: 2-10
   .INIT_SYNC_FF(1),   // DECIMAL; 0=disable simulation init values, 1=enable simulation init values
   .REG_OUTPUT(0),     // DECIMAL; 0=disable registered output, 1=enable registered output
   .RST_USED(1),       // DECIMAL; 0=no reset, 1=implement reset
   .SIM_ASSERT_CHK(0)  // DECIMAL; 0=disable simulation messages, 1=enable simulation messages
)
xpm_cdc_pulse_inst1 (
   .dest_pulse(card_upload_ren_sys), // 1-bit output: Outputs a pulse the size of one dest_clk period when a pulse
                            // transfer is correctly initiated on src_pulse input. This output is
                            // combinatorial unless REG_OUTPUT is set to 1.
   .dest_clk(userclk2_out),     // 1-bit input: Destination clock.
   .dest_rst(1'b0),     // 1-bit input: optional; required when RST_USED = 1
   .src_clk(clk_125M),       // 1-bit input: Source clock.
   .src_pulse(card_upload_ren_1),   // 1-bit input: Rising edge of this signal initiates a pulse transfer to the
                            // destination clock domain. The minimum gap between each pulse transfer must be
                            // at the minimum 2*(larger(src_clk period, dest_clk period)). This is measured
                            // between the falling edge of a src_pulse to the rising edge of the next
                            // src_pulse. This minimum gap will guarantee that each rising edge of src_pulse
                            // will generate a pulse the size of one dest_clk period in the destination
                            // clock domain. When RST_USED = 1, pulse transfers will not be guaranteed while
                            // src_rst and/or dest_rst are asserted.
   .src_rst(1'b0)        // 1-bit input: optional; required when RST_USED = 1
);



endmodule
