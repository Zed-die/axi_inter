`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2022/07/11 21:03:45
// Design Name: 
// Module Name: pcs_pma
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////



//4port new connect
module pcs_pma(
    input   wire                  clk                 ,    //user clock
    input   wire                  clk_200M            ,    //to pcs_pma ip
    input                         clk_200m_n          ,
    input                         clk_200m_p          ,
    output                        ui_clk              ,
    input   wire                  rst                 ,
    input   wire                  rst_200m            ,
    input           [1:0]         port_mode           ,

    input   wire                  gtrefclk_p          ,    //to master
    input   wire                  gtrefclk_n          ,    //to master
    input   wire                  rxn_1               ,    //to master
    input   wire                  rxp_1               ,    //to master
    input   wire                  rxn_2               ,    //to slave   
    input   wire                  rxp_2               ,    //to slave
    input   wire                  rxn_3               ,    //to slave
    input   wire                  rxp_3               ,    //to slave
    input   wire                  rxn_4               ,    //to slave   
    input   wire                  rxp_4               ,    //to slave
    input   wire    [7:0]         gmii_txd_1          ,    //to master   
    input   wire                  gmii_tx_en_1        ,    //to master
    input   wire    [7:0]         gmii_txd_2          ,    //to slave
    input   wire                  gmii_tx_en_2        ,    //to slave
    input   wire    [7:0]         gmii_txd_3          ,    //to slave   
    input   wire                  gmii_tx_en_3        ,    //to slave
    input   wire    [7:0]         gmii_txd_4          ,    //to slave
    input   wire                  gmii_tx_en_4        ,    //to slave

    output                        userclk2_out        ,    //from master to slave              ,
    output                        Link_1              ,
    output                        Link_2              ,
    output                        Link_3              ,
    output                        Link_4              ,
    output  wire                  txn_1               ,    //from master
    output  wire                  txp_1               ,    //from master
    output  wire                  txn_2               ,    //from slave
    output  wire                  txp_2               ,    //from slave
    output  wire                  txn_3               ,    //from slave
    output  wire                  txp_3               ,    //from slave
    output  wire                  txn_4               ,    //from slave
    output  wire                  txp_4               ,    //from slave
    output  wire    [7:0]         gmii_rxd_1          ,    //from master
    output  wire                  gmii_rx_dv_1        ,    //from master
    output  wire                  gmii_rx_er_1        ,    //from master
    output  wire    [7:0]         gmii_rxd_2          ,    //from slave
    output  wire                  gmii_rx_dv_2        ,    //from slave
    output  wire                  gmii_rx_er_2        ,     //from slave
    output  wire    [7:0]         gmii_rxd_3          ,    //from slave
    output  wire                  gmii_rx_dv_3        ,    //from slave
    output  wire                  gmii_rx_er_3        ,    //from master
    output  wire    [7:0]         gmii_rxd_4          ,    //from slave
    output  wire                  gmii_rx_dv_4        ,    //from slave
    output  wire                  gmii_rx_er_4,             //from slave
    output          [3:0]         timestamp_tx_Pdelay_valid_cdc,
    output          [3:0]         timestamp_tx_Sync_valid_cdc  ,
    output          [3:0]         timestamp_tx_Presp_valid_cdc ,
    output          [3:0]         timestamp_rx_Pdelay_valid_cdc,
    output          [3:0]         timestamp_rx_Sync_valid_cdc  ,
    output          [3:0]         timestamp_rx_Presp_valid_cdc ,
    output          [3:0]         timestamp_rx_Sync_follow_valid_cdc ,
    output          [3:0]         timestamp_rx_Presp_follow_valid_cdc,
    output          [3:0]         timestamp_rx_Announce_valid_cdc    ,

    //CPU配置
    input                  wen_phy   ,
    input       [31:0]     waddr_phy ,
    input       [31:0]     wdata_phy ,
    
    //DDR3 interface
    // Inouts
    inout       [63:0]     ddr3_dq,
    inout       [7:0]      ddr3_dqs_n,
    inout       [7:0]      ddr3_dqs_p,
   
    // Outputs
    output      [14:0]     ddr3_addr,
    output      [2:0]      ddr3_ba,
    output                 ddr3_ras_n,
    output                 ddr3_cas_n,
    output                 ddr3_we_n,
    output                 ddr3_reset_n,
    output      [0:0]      ddr3_ck_p,
    output      [0:0]      ddr3_ck_n,
    output      [0:0]      ddr3_cke,
    output      [0:0]      ddr3_cs_n,
    output      [7:0]      ddr3_dm,
    output      [0:0]      ddr3_odt,

    //axis interface
    output     [63:0]      m_axis_up_load_data1 ,
    output                 m_axis_up_load_last1 ,
    output                 m_axis_up_load_valid1,
    input                  m_axis_up_load_ready1,
    output     [7:0]       m_axis_up_load_keep1 ,
    input                  card_upload_ren_1    ,
    output                 card_upload_flag_1

);



wire gtrefclk_out               ;    //from master to slave
wire gtrefclk_bufg_out          ;    //from master to slave
wire userclk_out                ;    //from master to slave

wire pma_reset_out              ;    //from master to slave
wire mmcm_locked_out            ;    //from master to slave
wire recclk_mmcm_locked_out     ;
wire gt0_qplloutclk_out         ;    //from master to slave
wire gt0_qplloutrefclk_out      ;    //from master to slave
wire rxoutclk1                  ;    //from slave   
wire rxuserclk_buf1             ;    //bufg from rxoutclk

wire rxoutclk2                  ;    //from slave   
wire rxuserclk_buf2             ;    //bufg from rxoutclk

wire rxoutclk3                   ;    //from slave   
wire rxuserclk_buf3              ;    //bufg from rxoutclk

wire [15:0] status_vector_master;
wire [15:0] status_vector_slave1;
wire [15:0] status_vector_slave2;
wire [15:0] status_vector_slave3;

wire resetdone_master;
wire resetdone_slave1;
wire resetdone_slave2;
wire resetdone_slave3;


wire [7:0]    gmii_txd_in_1     ;    //from fifo to master
wire          gmii_tx_en_in_1   ;    //from fifo to master
wire [7:0]    gmii_txd_in_2     ;    //from fifo to slave
wire          gmii_tx_en_in_2   ;    //from fifo to slave
wire [7:0]    gmii_rxd_out_1    ;   
wire          gmii_rx_en_out_1  ;   
wire [7:0]    gmii_rxd_out_2    ;  
wire          gmii_rx_en_out_2  ;  
wire [7:0]    gmii_txd_in_3     ;    //from fifo to master
wire          gmii_tx_en_in_3   ;    //from fifo to master
wire [7:0]    gmii_txd_in_4     ;    //from fifo to slave
wire          gmii_tx_en_in_4   ;    //from fifo to slave
wire [7:0]    gmii_rxd_out_3    ;   
wire          gmii_rx_en_out_3  ;   
wire [7:0]    gmii_rxd_out_4    ;  
wire          gmii_rx_en_out_4  ;  


wire [7:0]  pcs_pma_txd1  ;
wire        pcs_pma_tx_en1;
wire [7:0]  pcs_pma_txd2  ;
wire        pcs_pma_tx_en2;
wire [7:0]  pcs_pma_txd3  ;
wire        pcs_pma_tx_en3;
wire [7:0]  pcs_pma_txd4  ;
wire        pcs_pma_tx_en4;

wire [7:0]  probe_tx_data1;
wire        probe_tx_en1  ;
wire [7:0]  probe_tx_data2;
wire        probe_tx_en2  ;
wire [7:0]  probe_tx_data3;
wire        probe_tx_en3  ;
wire [7:0]  probe_tx_data4;
wire        probe_tx_en4  ;

assign Link_1 = ~(status_vector_master[0]&&resetdone_master);
assign Link_2 = ~(status_vector_slave1[0]&&status_vector_slave1);
assign Link_3 = ~(status_vector_slave2[0]&&status_vector_slave2);
assign Link_4 = ~(status_vector_slave3[0]&&status_vector_slave3);


//四端口轮询
wire request1;
wire request2;
wire request3;
wire request4;

wire        port_frame_rd1;
wire        port_frame_rd2;
wire        port_frame_rd3;
wire        port_frame_rd4;
wire [63:0] port_frame_data1;
wire [63:0] port_frame_data2;
wire [63:0] port_frame_data3;
wire [63:0] port_frame_data4;

wire lock_port;
wire init_calib_complete;


wire     [1:0]       port0_mode;
wire     [1:0]       port1_mode;
wire     [1:0]       port2_mode;
wire     [1:0]       port3_mode;

wire                 port0_probe_glb_ctrl        ;
wire     [31:0]      port0_probe_fault_sel       ;
wire     [47:0]      port0_probe_dmac            ;
wire     [15:0]      port0_probe_ethtype         ;
wire     [3:0]       port0_probe_msgtype         ;
wire     [3:0]       port0_probe_transpec        ;
wire     [3:0]       port0_probe_verptp          ;
wire     [15:0]      port0_probe_msglength       ;
wire     [7:0]       port0_probe_domainnumber    ;
wire     [15:0]      port0_probe_flagfield       ;
wire     [79:0]      port0_probe_sourceportid    ;
wire     [15:0]      port0_probe_sequenceid      ;
wire     [7:0]       port0_probe_controlfield    ;
wire     [7:0]       port0_probe_logmsginterval  ;
wire     [63:0]      port0_probe_correction      ;

wire                 port1_probe_glb_ctrl        ;
wire     [31:0]      port1_probe_fault_sel       ;
wire     [47:0]      port1_probe_dmac            ;
wire     [15:0]      port1_probe_ethtype         ;
wire     [3:0]       port1_probe_msgtype         ;
wire     [3:0]       port1_probe_transpec        ;
wire     [3:0]       port1_probe_verptp          ;
wire     [15:0]      port1_probe_msglength       ;
wire     [7:0]       port1_probe_domainnumber    ;
wire     [15:0]      port1_probe_flagfield       ;
wire     [79:0]      port1_probe_sourceportid    ;
wire     [15:0]      port1_probe_sequenceid      ;
wire     [7:0]       port1_probe_controlfield    ;
wire     [7:0]       port1_probe_logmsginterval  ;
wire     [63:0]      port1_probe_correction      ;

wire                 port2_probe_glb_ctrl        ;
wire     [31:0]      port2_probe_fault_sel       ;
wire     [47:0]      port2_probe_dmac            ;
wire     [15:0]      port2_probe_ethtype         ;
wire     [3:0]       port2_probe_msgtype         ;
wire     [3:0]       port2_probe_transpec        ;
wire     [3:0]       port2_probe_verptp          ;
wire     [15:0]      port2_probe_msglength       ;
wire     [7:0]       port2_probe_domainnumber    ;
wire     [15:0]      port2_probe_flagfield       ;
wire     [79:0]      port2_probe_sourceportid    ;
wire     [15:0]      port2_probe_sequenceid      ;
wire     [7:0]       port2_probe_controlfield    ;
wire     [7:0]       port2_probe_logmsginterval  ;
wire     [63:0]      port2_probe_correction      ;

wire                 port3_probe_glb_ctrl        ;
wire     [31:0]      port3_probe_fault_sel       ;
wire     [47:0]      port3_probe_dmac            ;
wire     [15:0]      port3_probe_ethtype         ;
wire     [3:0]       port3_probe_msgtype         ;
wire     [3:0]       port3_probe_transpec        ;
wire     [3:0]       port3_probe_verptp          ;
wire     [15:0]      port3_probe_msglength       ;
wire     [7:0]       port3_probe_domainnumber    ;
wire     [15:0]      port3_probe_flagfield       ;
wire     [79:0]      port3_probe_sourceportid    ;
wire     [15:0]      port3_probe_sequenceid      ;
wire     [7:0]       port3_probe_controlfield    ;
wire     [7:0]       port3_probe_logmsginterval  ;
wire     [63:0]      port3_probe_correction      ;

//探针模式输出仲裁
probe_config U_probe_config(
    .clk                       (userclk2_out                 ),
    .rst                       (rst                          ),
    .wen_phy                   (wen_phy                      ),
    .waddr_phy                 (waddr_phy                    ),
    .wdata_phy                 (wdata_phy                    ),

    //端口模式
    .port0_mode                (port0_mode                   ),
    .port1_mode                (port1_mode                   ),
    .port2_mode                (port2_mode                   ),
    .port3_mode                (port3_mode                   ),   
    //端口1配置
    .port0_probe_glb_ctrl      (port0_probe_glb_ctrl         ),
    .port0_probe_fault_sel     (port0_probe_fault_sel        ),
    .port0_probe_dmac          (port0_probe_dmac             ),
    .port0_probe_ethtype       (port0_probe_ethtype          ),
    .port0_probe_msgtype       (port0_probe_msgtype          ),
    .port0_probe_transpec      (port0_probe_transpec         ),
    .port0_probe_verptp        (port0_probe_verptp           ),
    .port0_probe_msglength     (port0_probe_msglength        ),
    .port0_probe_domainnumber  (port0_probe_domainnumber     ),
    .port0_probe_flagfield     (port0_probe_flagfield        ),
    .port0_probe_sourceportid  (port0_probe_sourceportid     ),
    .port0_probe_sequenceid    (port0_probe_sequenceid       ),
    .port0_probe_controlfield  (port0_probe_controlfield     ),
    .port0_probe_logmsginterval(port0_probe_logmsginterval   ),
    .port0_probe_correction    (port0_probe_correction       ),
    //端口2配置
    .port1_probe_glb_ctrl      (port1_probe_glb_ctrl         ),
    .port1_probe_fault_sel     (port1_probe_fault_sel        ),
    .port1_probe_dmac          (port1_probe_dmac             ),
    .port1_probe_ethtype       (port1_probe_ethtype          ),
    .port1_probe_msgtype       (port1_probe_msgtype          ),
    .port1_probe_transpec      (port1_probe_transpec         ),
    .port1_probe_verptp        (port1_probe_verptp           ),
    .port1_probe_msglength     (port1_probe_msglength        ),
    .port1_probe_domainnumber  (port1_probe_domainnumber     ),
    .port1_probe_flagfield     (port1_probe_flagfield        ),
    .port1_probe_sourceportid  (port1_probe_sourceportid     ),
    .port1_probe_sequenceid    (port1_probe_sequenceid       ),
    .port1_probe_controlfield  (port1_probe_controlfield     ),
    .port1_probe_logmsginterval(port1_probe_logmsginterval   ),
    .port1_probe_correction    (port1_probe_correction       ),
    //端口3配置
    .port2_probe_glb_ctrl      (port2_probe_glb_ctrl         ),
    .port2_probe_fault_sel     (port2_probe_fault_sel        ),
    .port2_probe_dmac          (port2_probe_dmac             ),
    .port2_probe_ethtype       (port2_probe_ethtype          ),
    .port2_probe_msgtype       (port2_probe_msgtype          ),
    .port2_probe_transpec      (port2_probe_transpec         ),
    .port2_probe_verptp        (port2_probe_verptp           ),
    .port2_probe_msglength     (port2_probe_msglength        ),
    .port2_probe_domainnumber  (port2_probe_domainnumber     ),
    .port2_probe_flagfield     (port2_probe_flagfield        ),
    .port2_probe_sourceportid  (port2_probe_sourceportid     ),
    .port2_probe_sequenceid    (port2_probe_sequenceid       ),
    .port2_probe_controlfield  (port2_probe_controlfield     ),
    .port2_probe_logmsginterval(port2_probe_logmsginterval   ),
    .port2_probe_correction    (port2_probe_correction       ),
    //端口4配置
    .port3_probe_glb_ctrl      (port3_probe_glb_ctrl         ),
    .port3_probe_fault_sel     (port3_probe_fault_sel        ),
    .port3_probe_dmac          (port3_probe_dmac             ),
    .port3_probe_ethtype       (port3_probe_ethtype          ),
    .port3_probe_msgtype       (port3_probe_msgtype          ),
    .port3_probe_transpec      (port3_probe_transpec         ),
    .port3_probe_verptp        (port3_probe_verptp           ),
    .port3_probe_msglength     (port3_probe_msglength        ),
    .port3_probe_domainnumber  (port3_probe_domainnumber     ),
    .port3_probe_flagfield     (port3_probe_flagfield        ),
    .port3_probe_sourceportid  (port3_probe_sourceportid     ),
    .port3_probe_sequenceid    (port3_probe_sequenceid       ),
    .port3_probe_controlfield  (port3_probe_controlfield     ),
    .port3_probe_logmsginterval(port3_probe_logmsginterval   ),
    .port3_probe_correction    (port3_probe_correction       )
);

probe_modify U_probe_modify(
    .clk                       (userclk2_out                 ),
    .rst                       (rst                          ),
    //端口接收数据
    .phy_rx_data1              (gmii_rxd_out_1               ),
    .phy_rx_en1                (gmii_rx_en_out_1             ),
    .phy_rx_data2              (gmii_rxd_out_2               ),
    .phy_rx_en2                (gmii_rx_en_out_2             ),
    .phy_rx_data3              (gmii_rxd_out_3               ),
    .phy_rx_en3                (gmii_rx_en_out_3             ),
    .phy_rx_data4              (gmii_rxd_out_4               ),
    .phy_rx_en4                (gmii_rx_en_out_4             ), 

    //探针注入后数据
    .probe_tx_data1            (probe_tx_data1               ),
    .probe_tx_en1              (probe_tx_en1                 ),
    .probe_tx_data2            (probe_tx_data2               ),
    .probe_tx_en2              (probe_tx_en2                 ),
    .probe_tx_data3            (probe_tx_data3               ),
    .probe_tx_en3              (probe_tx_en3                 ),
    .probe_tx_data4            (probe_tx_data4               ),
    .probe_tx_en4              (probe_tx_en4                 ), 

    //端口1配置
    .port0_probe_glb_ctrl      (port0_probe_glb_ctrl         ),
    .port0_probe_fault_sel     (port0_probe_fault_sel        ),
    .port0_probe_dmac          (port0_probe_dmac             ),
    .port0_probe_ethtype       (port0_probe_ethtype          ),
    .port0_probe_msgtype       (port0_probe_msgtype          ),
    .port0_probe_transpec      (port0_probe_transpec         ),
    .port0_probe_verptp        (port0_probe_verptp           ),
    .port0_probe_msglength     (port0_probe_msglength        ),
    .port0_probe_domainnumber  (port0_probe_domainnumber     ),
    .port0_probe_flagfield     (port0_probe_flagfield        ),
    .port0_probe_sourceportid  (port0_probe_sourceportid     ),
    .port0_probe_sequenceid    (port0_probe_sequenceid       ),
    .port0_probe_controlfield  (port0_probe_controlfield     ),
    .port0_probe_logmsginterval(port0_probe_logmsginterval   ),
    .port0_probe_correction    (port0_probe_correction       ),
    //端口2配置
    .port1_probe_glb_ctrl      (port1_probe_glb_ctrl         ),
    .port1_probe_fault_sel     (port1_probe_fault_sel        ),
    .port1_probe_dmac          (port1_probe_dmac             ),
    .port1_probe_ethtype       (port1_probe_ethtype          ),
    .port1_probe_msgtype       (port1_probe_msgtype          ),
    .port1_probe_transpec      (port1_probe_transpec         ),
    .port1_probe_verptp        (port1_probe_verptp           ),
    .port1_probe_msglength     (port1_probe_msglength        ),
    .port1_probe_domainnumber  (port1_probe_domainnumber     ),
    .port1_probe_flagfield     (port1_probe_flagfield        ),
    .port1_probe_sourceportid  (port1_probe_sourceportid     ),
    .port1_probe_sequenceid    (port1_probe_sequenceid       ),
    .port1_probe_controlfield  (port1_probe_controlfield     ),
    .port1_probe_logmsginterval(port1_probe_logmsginterval   ),
    .port1_probe_correction    (port1_probe_correction       ),
    //端口3配置
    .port2_probe_glb_ctrl      (port2_probe_glb_ctrl         ),
    .port2_probe_fault_sel     (port2_probe_fault_sel        ),
    .port2_probe_dmac          (port2_probe_dmac             ),
    .port2_probe_ethtype       (port2_probe_ethtype          ),
    .port2_probe_msgtype       (port2_probe_msgtype          ),
    .port2_probe_transpec      (port2_probe_transpec         ),
    .port2_probe_verptp        (port2_probe_verptp           ),
    .port2_probe_msglength     (port2_probe_msglength        ),
    .port2_probe_domainnumber  (port2_probe_domainnumber     ),
    .port2_probe_flagfield     (port2_probe_flagfield        ),
    .port2_probe_sourceportid  (port2_probe_sourceportid     ),
    .port2_probe_sequenceid    (port2_probe_sequenceid       ),
    .port2_probe_controlfield  (port2_probe_controlfield     ),
    .port2_probe_logmsginterval(port2_probe_logmsginterval   ),
    .port2_probe_correction    (port2_probe_correction       ),
    //端口4配置
    .port3_probe_glb_ctrl      (port3_probe_glb_ctrl         ),
    .port3_probe_fault_sel     (port3_probe_fault_sel        ),
    .port3_probe_dmac          (port3_probe_dmac             ),
    .port3_probe_ethtype       (port3_probe_ethtype          ),
    .port3_probe_msgtype       (port3_probe_msgtype          ),
    .port3_probe_transpec      (port3_probe_transpec         ),
    .port3_probe_verptp        (port3_probe_verptp           ),
    .port3_probe_msglength     (port3_probe_msglength        ),
    .port3_probe_domainnumber  (port3_probe_domainnumber     ),
    .port3_probe_flagfield     (port3_probe_flagfield        ),
    .port3_probe_sourceportid  (port3_probe_sourceportid     ),
    .port3_probe_sequenceid    (port3_probe_sequenceid       ),
    .port3_probe_controlfield  (port3_probe_controlfield     ),
    .port3_probe_logmsginterval(port3_probe_logmsginterval   ),
    .port3_probe_correction    (port3_probe_correction       )
);

probe_select U_probe_select(
    .clk                       (userclk2_out       ),
    .rst                       (rst                ),
    .port0_mode                (port0_mode         ),
    .port1_mode                (port1_mode         ),
    .port2_mode                (port2_mode         ),
    .port3_mode                (port3_mode         ),
    // 探针篡改数据
    .probe_tx_data1            (probe_tx_data1     ),
    .probe_tx_en1              (probe_tx_en1       ),
    .probe_tx_data2            (probe_tx_data2     ),
    .probe_tx_en2              (probe_tx_en2       ),
    .probe_tx_data3            (probe_tx_data3     ),
    .probe_tx_en3              (probe_tx_en3       ),
    .probe_tx_data4            (probe_tx_data4     ),
    .probe_tx_en4              (probe_tx_en4       ),
    //端口待发送数据
    .gmii_txd_in_1             (gmii_txd_in_1      ),
    .gmii_tx_en_in_1           (gmii_tx_en_in_1    ),
    .gmii_txd_in_2             (gmii_txd_in_2      ),
    .gmii_tx_en_in_2           (gmii_tx_en_in_2    ),
    .gmii_txd_in_3             (gmii_txd_in_3      ),
    .gmii_tx_en_in_3           (gmii_tx_en_in_3    ),
    .gmii_txd_in_4             (gmii_txd_in_4      ),
    .gmii_tx_en_in_4           (gmii_tx_en_in_4    ),
    //给入pcs_pma ip的发送接口(输出仲裁)
    .pcs_pma_txd1              (pcs_pma_txd1       ),
    .pcs_pma_tx_en1            (pcs_pma_tx_en1     ),
    .pcs_pma_txd2              (pcs_pma_txd2       ),
    .pcs_pma_tx_en2            (pcs_pma_tx_en2     ),
    .pcs_pma_txd3              (pcs_pma_txd3       ),
    .pcs_pma_tx_en3            (pcs_pma_tx_en3     ),
    .pcs_pma_txd4              (pcs_pma_txd4       ),
    .pcs_pma_tx_en4            (pcs_pma_tx_en4     )
);

inport_ccd_1000M_tx_SFP u_sfp_tx_1(
    .rx_clk               (clk                    ), //输入用户时钟
    .clk                  (userclk2_out           ), //输出sfp发送时钟
    .rst                  (rst                    ),
    .rxd_i                (gmii_txd_1             ),
    .rx_dv_i              (gmii_tx_en_1           ),
    .rx_er_i              (1'b0                   ),
    .rxd_o                (gmii_txd_in_1          ),
    .rx_dv_o              (gmii_tx_en_in_1        ),
    .rx_er_o              (                       ),
    .timestamp_tx_Pdelay_valid_cdc(timestamp_tx_Pdelay_valid_cdc[0]),
    .timestamp_tx_Sync_valid_cdc  (timestamp_tx_Sync_valid_cdc[0]  ),
    .timestamp_tx_Presp_valid_cdc (timestamp_tx_Presp_valid_cdc[0] )  
);

inport_ccd_1000M_tx_SFP u_sfp_tx_2(
    .rx_clk               (clk                    ), //输入用户时钟
    .clk                  (userclk2_out           ), //输出sfp发送时钟
    .rst                  (rst                    ),
    .rxd_i                (gmii_txd_2             ),
    .rx_dv_i              (gmii_tx_en_2           ),
    .rx_er_i              (1'b0                   ),
    .rxd_o                (gmii_txd_in_2          ),
    .rx_dv_o              (gmii_tx_en_in_2        ),
    .rx_er_o              (                       ),
    .timestamp_tx_Pdelay_valid_cdc(timestamp_tx_Pdelay_valid_cdc[1]),
    .timestamp_tx_Sync_valid_cdc  (timestamp_tx_Sync_valid_cdc[1]  ),
    .timestamp_tx_Presp_valid_cdc (timestamp_tx_Presp_valid_cdc[1] )  
);

inport_ccd_1000M_tx_SFP u_sfp_tx_3(
    .rx_clk               (clk                    ), //输入用户时钟
    .clk                  (userclk2_out           ), //输出sfp发送时钟
    .rst                  (rst                    ),
    .rxd_i                (gmii_txd_3             ),
    .rx_dv_i              (gmii_tx_en_3           ),
    .rx_er_i              (1'b0                   ),
    .rxd_o                (gmii_txd_in_3          ),
    .rx_dv_o              (gmii_tx_en_in_3        ),
    .rx_er_o              (                       ),
    .timestamp_tx_Pdelay_valid_cdc(timestamp_tx_Pdelay_valid_cdc[2]),
    .timestamp_tx_Sync_valid_cdc  (timestamp_tx_Sync_valid_cdc[2]  ),
    .timestamp_tx_Presp_valid_cdc (timestamp_tx_Presp_valid_cdc[2] )  
);

inport_ccd_1000M_tx_SFP u_sfp_tx_4(
    .rx_clk               (clk                    ), //输入用户时钟
    .clk                  (userclk2_out           ), //输出sfp发送时钟
    .rst                  (rst                    ),
    .rxd_i                (gmii_txd_4             ),
    .rx_dv_i              (gmii_tx_en_4           ),
    .rx_er_i              (1'b0                   ),
    .rxd_o                (gmii_txd_in_4          ),
    .rx_dv_o              (gmii_tx_en_in_4        ),
    .rx_er_o              (                       ),
    .timestamp_tx_Pdelay_valid_cdc(timestamp_tx_Pdelay_valid_cdc[3]),
    .timestamp_tx_Sync_valid_cdc  (timestamp_tx_Sync_valid_cdc[3]  ),
    .timestamp_tx_Presp_valid_cdc (timestamp_tx_Presp_valid_cdc[3] )  
);

inport_ccd_1000M_rx_SFP u_sfp_rx_1(
    .rx_clk               (userclk2_out             ), //输入用户时钟
    .clk                  (clk                      ), //输出sfp发送时钟
    .rst                  (rst                      ),
    .rxd_i                (gmii_rxd_out_1           ),
    .rx_dv_i              (gmii_rx_en_out_1         ),
    .rx_er_i              (1'b0                     ),
    .rxd_o                (gmii_rxd_1               ),
    .rx_dv_o              (gmii_rx_dv_1             ),
    .rx_er_o              (gmii_rx_er_1             ),
    .timestamp_rx_Pdelay_valid_cdc      (timestamp_rx_Pdelay_valid_cdc[0]      ),
    .timestamp_rx_Sync_valid_cdc        (timestamp_rx_Sync_valid_cdc[0]        ),
    .timestamp_rx_Presp_valid_cdc       (timestamp_rx_Presp_valid_cdc[0]       ),
    .timestamp_rx_Sync_follow_valid_cdc (timestamp_rx_Sync_follow_valid_cdc[0] ),
    .timestamp_rx_Presp_follow_valid_cdc(timestamp_rx_Presp_follow_valid_cdc[0]),
    .timestamp_rx_Announce_valid_cdc    (timestamp_rx_Announce_valid_cdc[0]    )
);

inport_ccd_1000M_rx_SFP u_sfp_rx_2(
    .rx_clk               (userclk2_out             ),
    .clk                  (clk                      ),
    .rst                  (rst                      ),
    .rxd_i                (gmii_rxd_out_2           ),
    .rx_dv_i              (gmii_rx_en_out_2         ),
    .rx_er_i              (1'b0                     ),
    .rxd_o                (gmii_rxd_2               ),
    .rx_dv_o              (gmii_rx_dv_2             ),
    .rx_er_o              (gmii_rx_er_2             ),
    .timestamp_rx_Pdelay_valid_cdc      (timestamp_rx_Pdelay_valid_cdc[1]      ),
    .timestamp_rx_Sync_valid_cdc        (timestamp_rx_Sync_valid_cdc[1]        ),
    .timestamp_rx_Presp_valid_cdc       (timestamp_rx_Presp_valid_cdc[1]       ),
    .timestamp_rx_Sync_follow_valid_cdc (timestamp_rx_Sync_follow_valid_cdc[1] ),
    .timestamp_rx_Presp_follow_valid_cdc(timestamp_rx_Presp_follow_valid_cdc[1]),
    .timestamp_rx_Announce_valid_cdc    (timestamp_rx_Announce_valid_cdc[1]    )  
);

inport_ccd_1000M_rx_SFP u_sfp_rx_3(
    .rx_clk               (userclk2_out            ),
    .clk                  (clk                     ),
    .rst                  (rst                     ),
    .rxd_i                (gmii_rxd_out_3          ),
    .rx_dv_i              (gmii_rx_en_out_3        ),
    .rx_er_i              (1'b0                    ),
    .rxd_o                (gmii_rxd_3              ),
    .rx_dv_o              (gmii_rx_dv_3            ),
    .rx_er_o              (gmii_rx_er_3            ),
    .timestamp_rx_Pdelay_valid_cdc      (timestamp_rx_Pdelay_valid_cdc[2]      ),
    .timestamp_rx_Sync_valid_cdc        (timestamp_rx_Sync_valid_cdc[2]        ),
    .timestamp_rx_Presp_valid_cdc       (timestamp_rx_Presp_valid_cdc[2]       ),
    .timestamp_rx_Sync_follow_valid_cdc (timestamp_rx_Sync_follow_valid_cdc[2] ),
    .timestamp_rx_Presp_follow_valid_cdc(timestamp_rx_Presp_follow_valid_cdc[2]),
    .timestamp_rx_Announce_valid_cdc    (timestamp_rx_Announce_valid_cdc[2]    )  
);

inport_ccd_1000M_rx_SFP u_sfp_rx_4(
    .rx_clk               (userclk2_out            ),
    .clk                  (clk                     ),
    .rst                  (rst                     ),
    .rxd_i                (gmii_rxd_out_4          ),
    .rx_dv_i              (gmii_rx_en_out_4        ),
    .rx_er_i              (1'b0                    ),
    .rxd_o                (gmii_rxd_4              ),
    .rx_dv_o              (gmii_rx_dv_4            ),
    .rx_er_o              (gmii_rx_er_4            ),
    .timestamp_rx_Pdelay_valid_cdc      (timestamp_rx_Pdelay_valid_cdc[3]      ),
    .timestamp_rx_Sync_valid_cdc        (timestamp_rx_Sync_valid_cdc[3]        ),
    .timestamp_rx_Presp_valid_cdc       (timestamp_rx_Presp_valid_cdc[3]       ),
    .timestamp_rx_Sync_follow_valid_cdc (timestamp_rx_Sync_follow_valid_cdc[3] ),
    .timestamp_rx_Presp_follow_valid_cdc(timestamp_rx_Presp_follow_valid_cdc[3]),
    .timestamp_rx_Announce_valid_cdc    (timestamp_rx_Announce_valid_cdc[3]    ) 
);

gig_ethernet_pcs_pma_0 master (
  .gtrefclk_p(gtrefclk_p),                            // input wire gtrefclk_p    connect with pin
  .gtrefclk_n(gtrefclk_n),                            // input wire gtrefclk_n    connect with pin
  .gtrefclk_out(gtrefclk_out),                        // output wire gtrefclk_out  connect with slave  125M reference clock
  .gtrefclk_bufg_out(gtrefclk_bufg_out),              // output wire gtrefclk_bufg_out connect with slave   reference clock
  .txn(txn_1),                                        // output wire txn
  .txp(txp_1),                                        // output wire txp
  .rxn(rxn_1),                                        // input wire rxn
  .rxp(rxp_1),                                        // input wire rxp
  .independent_clock_bufg(clk_200M),  // input wire independent_clock_bufg         stable clock 200M
  .userclk_out(userclk_out),                        // output wire userclk_out     connect to slave 62.5M/156.25M
  .userclk2_out(userclk2_out),                      // output wire userclk2_out    connect to slave 125M/312.5M    gmii_txd_clk
  .rxuserclk_out(rxuserclk_out),                    // output wire rxuserclk_out   connect nothing   
  .rxuserclk2_out(rxuserclk2_out),                  // output wire rxuserclk2_out  connect nothing   gmii_rxd_clk
  .resetdone(resetdone_master),                            // output wire resetdone
  .pma_reset_out(pma_reset_out),                    // output wire pma_reset_out   connect nothing
  .mmcm_locked_out(mmcm_locked_out),                // output wire mmcm_locked_out    connect slave
  //.recclk_mmcm_locked_out(recclk_mmcm_locked_out),  // output wire recclk_mmcm_locked_out  enabled when rx clk source is rxoutclk
  .gmii_txd(pcs_pma_txd1),                              // input wire [7 : 0] gmii_txd  
  .gmii_tx_en(pcs_pma_tx_en1),                          // input wire gmii_tx_en
  .gmii_tx_er(1'b0),                          // input wire gmii_tx_er
  .gmii_rxd(gmii_rxd_out_1),                              // output wire [7 : 0] gmii_rxd
  .gmii_rx_dv(gmii_rx_en_out_1),                          // output wire gmii_rx_dv
  .gmii_rx_er(),                          // output wire gmii_rx_er
  // .gmii_isolate(gmii_isolate),                      // output wire gmii_isolate
  .configuration_vector(5'b10000),      // input wire [4 : 0] configuration_vector
  .an_interrupt(),                      // output wire an_interrupt    enabled when an
  .an_adv_config_vector(16'b0000000000100000),      // input wire [15 : 0] an_adv_config_vector    enabled when an
  .an_restart_config(1'b0),            // input wire an_restart_config    enabled when an
  .status_vector(status_vector_master),                    // output wire [15 : 0] status_vector   connect nothing 
  .reset(rst_200m),                                    // input wire reset
  .signal_detect(1'b1),                    // input wire signal_detect
  .gt0_qplloutclk_out(gt0_qplloutclk_out),          // output wire gt0_qplloutclk_out   connect nothing
  .gt0_qplloutrefclk_out(gt0_qplloutrefclk_out)    // output wire gt0_qplloutrefclk_out    connect nothing 
);



BUFG BUFG_SFP1 (
   .O(rxuserclk_buf1), // 1-bit output: Clock output
   .I(rxoutclk1)  // 1-bit input: Clock input
);


gig_ethernet_pcs_pma_1 slave1 (
  .gtrefclk_bufg(gtrefclk_bufg_out),                    // input wire gtrefclk_bufg
  .gtrefclk(gtrefclk_out),                              // input wire gtrefclk
  .txn(txn_2),                                        // output wire txn
  .txp(txp_2),                                        // output wire txp
  .rxn(rxn_2),                                        // input wire rxn
  .rxp(rxp_2),                                        // input wire rxp
  .independent_clock_bufg(clk_200M),  // input wire independent_clock_bufg
  // .txoutclk(txoutclk),                              // output wire txoutclk
  .rxoutclk(rxoutclk1),                              // output wire rxoutclk
  .resetdone(resetdone_slave1),                            // output wire resetdone
  // .cplllock(cplllock),                              // output wire cplllock
  // .mmcm_reset(mmcm_reset),                          // output wire mmcm_reset
  .userclk(userclk_out),                                // input wire userclk
  .userclk2(userclk2_out),                              // input wire userclk2
  .pma_reset(pma_reset_out),                            // input wire pma_reset
  .mmcm_locked(mmcm_locked_out),                        // input wire mmcm_locked 
  // .recclk_mmcm_locked(mmcm_locked_out),          // input wire recclk_mmcm_locked  enabled when rx clk source is rxoutclk    
  .rxuserclk(rxuserclk_buf1),                            // input wire rxuserclk
  .rxuserclk2(rxuserclk_buf1),                          // input wire rxuserclk2
  .gmii_txd(pcs_pma_txd2),                              // input wire [7 : 0] gmii_txd
  .gmii_tx_en(pcs_pma_tx_en2),                          // input wire gmii_tx_en
  .gmii_tx_er(1'b0),                          // input wire gmii_tx_er
  .gmii_rxd(gmii_rxd_out_2),                              // output wire [7 : 0] gmii_rxd
  .gmii_rx_dv(gmii_rx_en_out_2),                          // output wire gmii_rx_dv
  .gmii_rx_er(),                          // output wire gmii_rx_er
  // .gmii_isolate(gmii_isolate),                      // output wire gmii_isolate
  .configuration_vector(5'b10000),      // input wire [4 : 0] configuration_vector
  .an_interrupt(),                      // output wire an_interrupt     enabled when an
  .an_adv_config_vector(16'b0000000000100000),      // input wire [15 : 0] an_adv_config_vector     enabled when an
  .an_restart_config(1'b0),            // input wire an_restart_config     enabled when an
  .status_vector(status_vector_slave1),                    // output wire [15 : 0] status_vector
  .reset(rst_200m),                                    // input wire reset
  .signal_detect(1'b1),                    // input wire signal_detect
  .gt0_qplloutclk_in(gt0_qplloutclk_out),            // input wire gt0_qplloutclk_in
  .gt0_qplloutrefclk_in(gt0_qplloutrefclk_out)      // input wire gt0_qplloutrefclk_in
);



BUFG BUFG_SFP2 (
   .O(rxuserclk_buf2), // 1-bit output: Clock output
   .I(rxoutclk2)  // 1-bit input: Clock input
);


gig_ethernet_pcs_pma_1 slave2 (
  .gtrefclk_bufg(gtrefclk_bufg_out),                    // input wire gtrefclk_bufg
  .gtrefclk(gtrefclk_out),                              // input wire gtrefclk
  .txn(txn_3),                                        // output wire txn
  .txp(txp_3),                                        // output wire txp
  .rxn(rxn_3),                                        // input wire rxn
  .rxp(rxp_3),                                        // input wire rxp
  .independent_clock_bufg(clk_200M),  // input wire independent_clock_bufg
  // .txoutclk(txoutclk),                              // output wire txoutclk
  .rxoutclk(rxoutclk2),                              // output wire rxoutclk
  .resetdone(resetdone_slave2),                            // output wire resetdone
  // .cplllock(cplllock),                              // output wire cplllock
  // .mmcm_reset(mmcm_reset),                          // output wire mmcm_reset
  .userclk(userclk_out),                                // input wire userclk
  .userclk2(userclk2_out),                              // input wire userclk2
  .pma_reset(pma_reset_out),                            // input wire pma_reset
  .mmcm_locked(mmcm_locked_out),                        // input wire mmcm_locked 
  // .recclk_mmcm_locked(mmcm_locked_out),          // input wire recclk_mmcm_locked  enabled when rx clk source is rxoutclk    
  .rxuserclk(rxuserclk_buf2),                            // input wire rxuserclk
  .rxuserclk2(rxuserclk_buf2),                          // input wire rxuserclk2
  .gmii_txd(pcs_pma_txd3),                              // input wire [7 : 0] gmii_txd
  .gmii_tx_en(pcs_pma_tx_en3),                          // input wire gmii_tx_en
  .gmii_tx_er(1'b0),                          // input wire gmii_tx_er
  .gmii_rxd(gmii_rxd_out_3),                              // output wire [7 : 0] gmii_rxd
  .gmii_rx_dv(gmii_rx_en_out_3),                          // output wire gmii_rx_dv
  .gmii_rx_er(),                          // output wire gmii_rx_er
  // .gmii_isolate(gmii_isolate),                      // output wire gmii_isolate
  .configuration_vector(5'b10000),      // input wire [4 : 0] configuration_vector
  .an_interrupt(),                      // output wire an_interrupt     enabled when an
  .an_adv_config_vector(16'b0000000000100000),      // input wire [15 : 0] an_adv_config_vector     enabled when an
  .an_restart_config(1'b0),            // input wire an_restart_config     enabled when an
  .status_vector(status_vector_slave2),                    // output wire [15 : 0] status_vector
  .reset(rst_200m),                                    // input wire reset
  .signal_detect(1'b1),                    // input wire signal_detect
  .gt0_qplloutclk_in(gt0_qplloutclk_out),            // input wire gt0_qplloutclk_in
  .gt0_qplloutrefclk_in(gt0_qplloutrefclk_out)      // input wire gt0_qplloutrefclk_in
);

BUFG BUFG_SFP3 (
   .O(rxuserclk_buf3), // 1-bit output: Clock output
   .I(rxoutclk3)  // 1-bit input: Clock input
);


gig_ethernet_pcs_pma_1 slave3 (
  .gtrefclk_bufg(gtrefclk_bufg_out),                    // input wire gtrefclk_bufg
  .gtrefclk(gtrefclk_out),                              // input wire gtrefclk
  .txn(txn_4),                                        // output wire txn
  .txp(txp_4),                                        // output wire txp
  .rxn(rxn_4),                                        // input wire rxn
  .rxp(rxp_4),                                        // input wire rxp
  .independent_clock_bufg(clk_200M),  // input wire independent_clock_bufg
  // .txoutclk(txoutclk),                              // output wire txoutclk
  .rxoutclk(rxoutclk3),                              // output wire rxoutclk
  .resetdone(resetdone_slave3),                            // output wire resetdone
  // .cplllock(cplllock),                              // output wire cplllock
  // .mmcm_reset(mmcm_reset),                          // output wire mmcm_reset
  .userclk(userclk_out),                                // input wire userclk
  .userclk2(userclk2_out),                              // input wire userclk2
  .pma_reset(pma_reset_out),                            // input wire pma_reset
  .mmcm_locked(mmcm_locked_out),                        // input wire mmcm_locked 
  // .recclk_mmcm_locked(mmcm_locked_out),          // input wire recclk_mmcm_locked  enabled when rx clk source is rxoutclk    
  .rxuserclk(rxuserclk_buf3),                            // input wire rxuserclk
  .rxuserclk2(rxuserclk_buf3),                          // input wire rxuserclk2
  .gmii_txd(pcs_pma_txd4),                              // input wire [7 : 0] gmii_txd
  .gmii_tx_en(pcs_pma_tx_en4),                          // input wire gmii_tx_en
  .gmii_tx_er(1'b0),                          // input wire gmii_tx_er
  .gmii_rxd(gmii_rxd_out_4),                              // output wire [7 : 0] gmii_rxd
  .gmii_rx_dv(gmii_rx_en_out_4),                          // output wire gmii_rx_dv
  .gmii_rx_er(),                          // output wire gmii_rx_er
  // .gmii_isolate(gmii_isolate),                      // output wire gmii_isolate
  .configuration_vector(5'b10000),      // input wire [4 : 0] configuration_vector
  .an_interrupt(),                      // output wire an_interrupt     enabled when an
  .an_adv_config_vector(16'b0000000000100000),      // input wire [15 : 0] an_adv_config_vector     enabled when an
  .an_restart_config(1'b0),            // input wire an_restart_config     enabled when an
  .status_vector(status_vector_slave3),                    // output wire [15 : 0] status_vector
  .reset(rst_200m),                                    // input wire reset
  .signal_detect(1'b1),                    // input wire signal_detect
  .gt0_qplloutclk_in(gt0_qplloutclk_out),            // input wire gt0_qplloutclk_in
  .gt0_qplloutrefclk_in(gt0_qplloutrefclk_out)      // input wire gt0_qplloutrefclk_in
);

`ifdef DDR_INIT
//完整帧存储
port_frame_save PORT1_frame_save(
    .rst_n                  (~rst               ),  
    .clk                    (userclk2_out       ), 
    .ui_clk                 (ui_clk             ),
    .port_num               (4'b0001            ), 
    .txd                    (pcs_pma_txd1       ),  
    .tx_dval                (pcs_pma_tx_en1     ),  
    .rxd                    (gmii_rxd_out_1     ),  
    .rx_dval                (gmii_rx_en_out_1   ),
    .lock_port              (lock_port          ),
    .frame_save_flag        (1'b1               ),
    .init_calib_complete    (init_calib_complete),
    .port_frame_rd          (port_frame_rd1     ),
    .port_frame_data        (port_frame_data1   ),
    .request                (request1           )
);

port_frame_save PORT2_frame_save(
    .rst_n                  (~rst               ),  
    .clk                    (userclk2_out       ),  
    .ui_clk                 (ui_clk             ),
    .port_num               (4'b0010            ), 
    .txd                    (pcs_pma_txd2       ),  
    .tx_dval                (pcs_pma_tx_en2     ),  
    .rxd                    (gmii_rxd_out_2     ),  
    .rx_dval                (gmii_rx_en_out_2   ),
    .lock_port              (lock_port          ),
    .frame_save_flag        (1'b1               ),
    .init_calib_complete    (init_calib_complete),
    .port_frame_rd          (port_frame_rd2     ),
    .port_frame_data        (port_frame_data2   ),
    .request                (request2           )
);

port_frame_save PORT3_frame_save(
    .rst_n                  (~rst               ),  
    .clk                    (userclk2_out       ), 
    .ui_clk                 (ui_clk             ), 
    .port_num               (4'b0100            ), 
    .txd                    (pcs_pma_txd3       ),  
    .tx_dval                (pcs_pma_tx_en3     ),  
    .rxd                    (gmii_rxd_out_3     ),  
    .rx_dval                (gmii_rx_en_out_3   ),
    .lock_port              (lock_port          ),
    .frame_save_flag        (1'b0               ),
    .init_calib_complete    (init_calib_complete),
    .port_frame_rd          (port_frame_rd3     ),
    .port_frame_data        (port_frame_data3   ),
    .request                (request3           )
);

port_frame_save PORT4_frame_save(   
    .rst_n                  (~rst               ),  
    .clk                    (userclk2_out       ),  
    .ui_clk                 (ui_clk             ),
    .port_num               (4'b1000            ), 
    .txd                    (pcs_pma_txd4       ),  
    .tx_dval                (pcs_pma_tx_en4     ),  
    .rxd                    (gmii_rxd_out_4     ),  
    .rx_dval                (gmii_rx_en_out_4   ),
    .lock_port              (lock_port          ),
    .frame_save_flag        (1'b0               ),
    .init_calib_complete    (init_calib_complete),
    .port_frame_rd          (port_frame_rd4     ),
    .port_frame_data        (port_frame_data4   ),
    .request                (request4           )
);

DDR_interface U_DDR_interface(
    .sys_rst                (rst                   ),  
    .sys_clk_p              (clk_200m_p            ),
    .sys_clk_n              (clk_200m_n            ),  
    .ui_clk                 (ui_clk                ),  
    .request1               (request1              ),
    .request2               (request2              ),
    .request3               (request3              ),
    .request4               (request4              ),
    .port_frame_data1       (port_frame_data1      ),
    .port_frame_data2       (port_frame_data2      ),
    .port_frame_data3       (port_frame_data3      ),
    .port_frame_data4       (port_frame_data4      ),
    .port_frame_rd1         (port_frame_rd1        ),
    .port_frame_rd2         (port_frame_rd2        ), 
    .port_frame_rd3         (port_frame_rd3        ), 
    .port_frame_rd4         (port_frame_rd4        ),
    .lock_port              (lock_port             ),
    .init_calib_complete    (init_calib_complete   ),
    .ddr3_dq                (ddr3_dq               ),
    .ddr3_dqs_n             (ddr3_dqs_n            ),
    .ddr3_dqs_p             (ddr3_dqs_p            ),
    .ddr3_addr              (ddr3_addr             ),
    .ddr3_ba                (ddr3_ba               ),
    .ddr3_ras_n             (ddr3_ras_n            ),
    .ddr3_cas_n             (ddr3_cas_n            ),
    .ddr3_we_n              (ddr3_we_n             ),
    .ddr3_reset_n           (ddr3_reset_n          ),
    .ddr3_ck_p              (ddr3_ck_p             ),
    .ddr3_ck_n              (ddr3_ck_n             ),
    .ddr3_cke               (ddr3_cke              ),
    .ddr3_cs_n              (ddr3_cs_n             ),
    .ddr3_dm                (ddr3_dm               ),
    .ddr3_odt               (ddr3_odt              ),
    .s_axis_c2h_tdata_sys0  (m_axis_up_load_data1  ),
    .s_axis_c2h_tlast_sys0  (m_axis_up_load_last1  ),
    .s_axis_c2h_tvalid_sys0 (m_axis_up_load_valid1 ),
    .s_axis_c2h_tready_sys0 (m_axis_up_load_ready1 ),
    .s_axis_c2h_tkeep_sys0  (m_axis_up_load_keep1  )
);

`else
port_frame_save PORT1_frame_save(
    .rst_n                  (~rst               ),  
    .clk                    (userclk2_out       ),  
    .ui_clk                 (userclk2_out       ),
    .port_num               (4'b0001            ), 
    .txd                    (pcs_pma_txd1       ),  
    .tx_dval                (pcs_pma_tx_en1     ),  
    .rxd                    (gmii_rxd_out_1     ),  
    .rx_dval                (gmii_rx_en_out_1   ),
    .lock_port              (1'b0               ),
    .frame_save_flag        (1'b1               ),
    .init_calib_complete    (1'b1               ),
    .port_frame_rd          (port_frame_rd1     ),
    .port_frame_data        (port_frame_data1   ), 
    .request                (request1           )
);

port_frame_save PORT2_frame_save(
    .rst_n                  (~rst               ),  
    .clk                    (userclk2_out       ),  
    .ui_clk                 (userclk2_out       ),
    .port_num               (4'b0010            ), 
    .txd                    (pcs_pma_txd2       ),  
    .tx_dval                (pcs_pma_tx_en2     ),  
    .rxd                    (gmii_rxd_out_2     ),  
    .rx_dval                (gmii_rx_en_out_2   ),
    .lock_port              (1'b0               ),
    .frame_save_flag        (1'b1               ),
    .init_calib_complete    (1'b1               ),
    .port_frame_rd          (port_frame_rd2     ),
    .port_frame_data        (port_frame_data2   ),
    .request                (request2           )
);

port_frame_save PORT3_frame_save(
    .rst_n                  (~rst               ),  
    .clk                    (userclk2_out       ),  
    .ui_clk                 (userclk2_out       ), 
    .port_num               (4'b0100            ), 
    .txd                    (pcs_pma_txd3       ),  
    .tx_dval                (pcs_pma_tx_en3     ),  
    .rxd                    (gmii_rxd_out_3     ),  
    .rx_dval                (gmii_rx_en_out_3   ),
    .lock_port              (1'b0               ),
    .frame_save_flag        (1'b1               ),
    .init_calib_complete    (1'b1               ),
    .port_frame_rd          (port_frame_rd3     ),
    .port_frame_data        (port_frame_data3   ),
    .request                (request3           )
);

port_frame_save PORT4_frame_save(   
    .rst_n                  (~rst               ),  
    .clk                    (userclk2_out       ),  
    .ui_clk                 (userclk2_out       ),
    .port_num               (4'b1000            ), 
    .txd                    (pcs_pma_txd4       ),  
    .tx_dval                (pcs_pma_tx_en4     ),  
    .rxd                    (gmii_rxd_out_4     ),  
    .rx_dval                (gmii_rx_en_out_4   ),
    .lock_port              (1'b0               ),
    .frame_save_flag        (1'b1               ),
    .init_calib_complete    (1'b1               ),
    .port_frame_rd          (port_frame_rd4     ),
    .port_frame_data        (port_frame_data4   ),
    .request                (request4           )
);

frame_upload_DDRoff u_frame_upload_DDRoff (
    .clk                    (userclk2_out          ), 
    .rst_n                  (~rst                  ), 
    // --- 端口 1 接口 (连接 port1_frame_save) ---
    .request1               (request1              ), 
    .port_frame_data1       (port_frame_data1      ), 
    .port_frame_rd1         (port_frame_rd1        ), 
    // --- 端口 2 接口 (连接 port2_frame_save) ---
    .request2               (request2              ), 
    .port_frame_data2       (port_frame_data2      ), 
    .port_frame_rd2         (port_frame_rd2        ), 
    // --- 端口 3 接口 (连接 port3_frame_save) ---
    .request3               (request3              ), 
    .port_frame_data3       (port_frame_data3      ), 
    .port_frame_rd3         (port_frame_rd3        ), 
    // --- 端口 4 接口 (连接 port4_frame_save) ---
    .request4               (request4              ), 
    .port_frame_data4       (port_frame_data4      ), 
    .port_frame_rd4         (port_frame_rd4        ), 
    // --- AXI-Stream 上传接 (连接到下游 DMA / DDR) -
    .m_axis_tdata_bigend    (m_axis_up_load_data1  ), 
    .m_axis_tkeep_bigend    (m_axis_up_load_keep1  ), 
    .m_axis_up_load_valid   (m_axis_up_load_valid1 ), 
    .m_axis_up_load_last    (m_axis_up_load_last1  ), 
    .m_axis_up_load_ready   (m_axis_up_load_ready1 ), 
    // --- 控制与状态接口 --
    .card_upload_ren_1      (card_upload_ren_1     ), 
    .card_upload_flag_1     (card_upload_flag_1    )  
);

`endif

`ifdef DEBUG_ON
ila_phydata U_ila_phydata (
	.clk        (userclk2_out           ), // input wire clk
	.probe0     (pcs_pma_txd1           ), // input wire [7:0]  probe0  
	.probe1     (pcs_pma_tx_en1         ), // input wire [0:0]  probe1 
	.probe2     (gmii_rxd_out_1         ), // input wire [7:0]  probe2 
	.probe3     (gmii_rx_en_out_1       ), // input wire [0:0]  probe3 
	.probe4     (pcs_pma_txd2           ), // input wire [7:0]  probe4 
	.probe5     (pcs_pma_tx_en2         ), // input wire [0:0]  probe5 
	.probe6     (gmii_rxd_out_2         ), // input wire [7:0]  probe6 
	.probe7     (gmii_rx_en_out_2       ), // input wire [0:0]  probe7 
	.probe8     (pcs_pma_txd3           ), // input wire [7:0]  probe8 
	.probe9     (pcs_pma_tx_en3         ), // input wire [0:0]  probe9 
	.probe10    (gmii_rxd_out_3         ), // input wire [7:0]  probe10 
	.probe11    (gmii_rx_en_out_3       ), // input wire [0:0]  probe11 
	.probe12    (pcs_pma_txd4           ), // input wire [7:0]  probe12 
	.probe13    (pcs_pma_tx_en4         ), // input wire [0:0]  probe13 
	.probe14    (gmii_rxd_out_4         ), // input wire [7:0]  probe14 
	.probe15    (gmii_rx_en_out_4       )  // input wire [0:0]  probe15
);
`endif





endmodule

