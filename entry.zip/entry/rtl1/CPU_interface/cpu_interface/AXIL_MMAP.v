//**********************************************
//COPYRIGHT(c)2022, Xidian University    
//All rights reserved.                   
//                                       
//File name     : AXIL_MMAP.v
//Module name   : AXIL_MMAP
//Full name     :                        
//Author 		: xmw                     
//Email 		:                         
//                                       
//Version 		:                         
//This File is  Created on 2022-7-9 0:16:38
//------------------Discription-----------------
//                                              
//----------------------------------------------
//-------------Modification history-------------
//Last Modified by 	: xmw                    
//Last Modified time: 2022-7-9 0:16:38
//Discription 	:                                
//----------------------------------------------
//TIMESCALE                                     
`timescale 1ns / 1ps                            
//DEFINES                                       
//`include ".v"                               
//----------------------------------------------
module AXIL_MMAP #(
    // Width of AXI lite data bus in bits
    parameter AXIL_DATA_WIDTH = 32,
    // Width of AXI lite address bus in bits
    parameter AXIL_ADDR_WIDTH = 32,
    // Width of AXI lite wstrb (width of data bus in words)
    parameter AXIL_STRB_WIDTH = (AXIL_DATA_WIDTH/8)
)
(
	input  	wire                                         clk			,
    input  	wire                                         rst_n			,

	/*
     * AXI Lite Slave output
     */
    input 	wire [AXIL_ADDR_WIDTH-1:0]                   s_axil_awaddr	,
    input 	wire                                         s_axil_awvalid	,
    output  reg                                          s_axil_awready	,

    input   wire [AXIL_DATA_WIDTH-1:0]                   s_axil_wdata	,
    input   wire [AXIL_STRB_WIDTH-1:0]                   s_axil_wstrb	,
    input   wire                                         s_axil_wvalid	,
    output  wire                                         s_axil_wready	,

    output  wire [1:0]                                   s_axil_bresp	,
    output  reg                                          s_axil_bvalid	,
    input 	wire                                         s_axil_bready	,

    input 	wire [AXIL_ADDR_WIDTH-1:0]                   s_axil_araddr	,
    input 	wire                                         s_axil_arvalid	,
    output  reg                                          s_axil_arready	,

    output  reg  [AXIL_DATA_WIDTH-1:0]                   s_axil_rdata	,
    output  wire [1:0]                                   s_axil_rresp	,
    output  reg                                          s_axil_rvalid	,
    input 	wire                                         s_axil_rready	,

    /*
     * RAM mmap interface
     */
    output 	reg  [AXIL_DATA_WIDTH-1:0]				 	 wr_data_o		,
    output 	reg  [AXIL_ADDR_WIDTH-1:0]					 wr_addr_o		,
    output 	reg  										 wr_en_o 		,

    output 	reg  [AXIL_ADDR_WIDTH-1:0]					 rd_addr_o		,
    output 	reg  										 rd_en_o 		,
    input   wire [AXIL_DATA_WIDTH-1:0]				 	 rd_data_i		,
    input   wire 										 rd_valid_i     
);

localparam AILANS = $clog2((AXIL_DATA_WIDTH/8));

reg [AXIL_ADDR_WIDTH-1:0]	wr_addr_reg;	// AXIL写地址寄存
reg 						ram_data_valid;	// RAM读数据有效信号

//===============================================================
//					AXI-Lite Write operate
//===============================================================
assign s_axil_bresp = 2'd0;
assign s_axil_rresp = 2'd0;
assign s_axil_wready = s_axil_wvalid;

always @(posedge clk or negedge rst_n) begin
	if (rst_n == 1'b0) begin
		s_axil_awready <= 1'b1;
	end
	else if( s_axil_awvalid & s_axil_awready ) begin
		s_axil_awready <= 1'b0;
	end
	else if( s_axil_bvalid & s_axil_bready ) begin
		s_axil_awready <= 1'b1;
	end
	else begin
		s_axil_awready <= s_axil_awready;
	end
end

always @(posedge clk or negedge rst_n) begin
	if (rst_n == 1'b0) begin
		wr_addr_reg <= 'd0;
	end
	else if( s_axil_awvalid & s_axil_awready ) begin
		wr_addr_reg <= {11'd0, s_axil_awaddr[20:0]};	// 2MB BAR空间
	end
	else begin
		wr_addr_reg <= wr_addr_reg;
	end
end

always @(posedge clk or negedge rst_n) begin
	if (rst_n == 1'b0) begin
		wr_data_o	<= 'd0;
		wr_addr_o	<= 'd0;
		wr_en_o		<= 1'b0;
	end
	else if( s_axil_wvalid & s_axil_wready ) begin
		// wr_data_o   <= { s_axil_wdata[7:0], s_axil_wdata[15:8], s_axil_wdata[23:16], s_axil_wdata[31:24] };
		wr_data_o   <= s_axil_wdata;
		wr_addr_o	<= wr_addr_reg;
		wr_en_o		<= 1'b1;
	end
	else begin
		wr_data_o	<= 'd0;
		wr_addr_o	<= 'd0;
		wr_en_o		<= 1'b0;
	end
end

always @(posedge clk or negedge rst_n) begin
	if (rst_n == 1'b0) begin
		s_axil_bvalid <= 1'b0;
	end
	else if( s_axil_wvalid & s_axil_wready ) begin
		s_axil_bvalid <= 1'b1;
	end
	else if( ~s_axil_bready ) begin
		s_axil_bvalid <= s_axil_bvalid;
	end
	else begin
		s_axil_bvalid <= 1'b0;
	end
end
//===============================================================
//					AXI-Lite Read operate
//===============================================================
always @(posedge clk or negedge rst_n) begin
	if (rst_n == 1'b0) begin
		s_axil_arready <= 1'b1;
	end
	else if( s_axil_arvalid & s_axil_arready ) begin
		s_axil_arready <= 1'b0;
	end
	else if( s_axil_rvalid & s_axil_rready ) begin
		s_axil_arready <= 1'b1;
	end
	else begin
		s_axil_arready <= s_axil_arready;
	end
end

always @(posedge clk or negedge rst_n) begin
	if (rst_n == 1'b0) begin
		ram_data_valid <= 1'b0;
	end
	else if( rd_en_o == 1'b1 ) begin
		ram_data_valid <= 1'b1;
	end
	else begin
		ram_data_valid <= 1'b0;
	end
end

always @(posedge clk or negedge rst_n) begin
	if (rst_n == 1'b0) begin
		rd_addr_o	<= 'd0;
		rd_en_o		<= 'd0;
	end
	else if( s_axil_arvalid & s_axil_arready ) begin
		rd_addr_o	<= {11'd0, s_axil_araddr[20:0]};	// 2MB BAR空间
		rd_en_o		<= 1'b1;
	end
	else begin
		rd_addr_o	<= 'd0;
		rd_en_o		<= 'd0;
	end
end

always @(posedge clk or negedge rst_n) begin
	if (rst_n == 1'b0) begin
		s_axil_rdata	<= 'd0;
		s_axil_rvalid	<= 'd0;
	end
	else if( rd_valid_i == 1'b1 /*ram_data_valid == 1'b1*/ ) begin
		// s_axil_rdata	<= { rd_data_i[7:0], rd_data_i[15:8], rd_data_i[23:16], rd_data_i[31:24] };
		s_axil_rdata    <= rd_data_i;
		s_axil_rvalid	<= 1'b1;
	end
	else if( ~s_axil_rready ) begin
		s_axil_rdata	<= s_axil_rdata;
		s_axil_rvalid	<= s_axil_rvalid;
	end
	else begin
		s_axil_rdata	<= 'd0;
		s_axil_rvalid	<= 'd0;
	end
end


endmodule
