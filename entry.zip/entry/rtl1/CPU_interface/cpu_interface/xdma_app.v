//-----------------------------------------------------------------------------
//
// (c) Copyright 2012-2012 Xilinx, Inc. All rights reserved.
//
// This file contains confidential and proprietary information
// of Xilinx, Inc. and is protected under U.S. and
// international copyright and other intellectual property
// laws.
//
// DISCLAIMER
// This disclaimer is not a license and does not grant any
// rights to the materials distributed herewith. Except as
// otherwise provided in a valid license issued to you by
// Xilinx, and to the maximum extent permitted by applicable
// law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
// WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
// AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
// BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
// INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
// (2) Xilinx shall not be liable (whether in contract or tort,
// including negligence, or under any other theory of
// liability) for any loss or damage of any kind or nature
// related to, arising under or in connection with these
// materials, including for any direct, or any indirect,
// special, incidental, or consequential loss or damage
// (including loss of data, profits, goodwill, or any type of
// loss or damage suffered as a result of any action brought
// by a third party) even if such damage or loss was
// reasonably foreseeable or Xilinx had been advised of the
// possibility of the same.
//
// CRITICAL APPLICATIONS
// Xilinx products are not designed or intended to be fail-
// safe, or for use in any application requiring fail-safe
// performance, such as life-support or safety devices or
// systems, Class III medical devices, nuclear facilities,
// applications related to the deployment of airbags, or any
// other applications that could lead to death, personal
// injury, or severe property or environmental damage
// (individually and collectively, "Critical
// Applications"). Customer assumes the sole risk and
// liability of any use of Xilinx products in Critical
// Applications, subject only to applicable laws and
// regulations governing limitations on product liability.
//
// THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
// PART OF THIS FILE AT ALL TIMES.
//
//-----------------------------------------------------------------------------
//
// Project    : The Xilinx PCI Express DMA 
// File       : xdma_app.v
// Version    : 4.1
//-----------------------------------------------------------------------------

`timescale 1ps / 1ps
module xdma_app #(
  parameter TCQ                         = 1,
  parameter C_M_AXI_ID_WIDTH            = 4,
  parameter PL_LINK_CAP_MAX_LINK_WIDTH  = 1,
  parameter C_DATA_WIDTH                = 64,
  parameter C_M_AXI_DATA_WIDTH          = C_DATA_WIDTH,
  parameter C_S_AXI_DATA_WIDTH          = C_DATA_WIDTH,
  parameter C_S_AXIS_DATA_WIDTH         = C_DATA_WIDTH,
  parameter C_M_AXIS_DATA_WIDTH         = C_DATA_WIDTH,
  parameter C_M_AXIS_RQ_USER_WIDTH      = ((C_DATA_WIDTH == 512) ? 137 : 62),
  parameter C_S_AXIS_CQP_USER_WIDTH     = ((C_DATA_WIDTH == 512) ? 183 : 88),
  parameter C_M_AXIS_RC_USER_WIDTH      = ((C_DATA_WIDTH == 512) ? 161 : 75),
  parameter C_S_AXIS_CC_USER_WIDTH      = ((C_DATA_WIDTH == 512) ?  81 : 33),
  parameter C_S_KEEP_WIDTH              = C_S_AXI_DATA_WIDTH / 32,
  parameter C_M_KEEP_WIDTH              = (C_M_AXI_DATA_WIDTH / 32),
  parameter C_XDMA_NUM_CHNL             = 1
)
(

  // AXI Lite Master Interface connections
  (*mark_debug = "true"*)input  wire  [31:0]  s_axil_awaddr,
  (*mark_debug = "true"*)input  wire          s_axil_awvalid,
  (*mark_debug = "true"*)output wire          s_axil_awready,
  (*mark_debug = "true"*)input  wire  [31:0]  s_axil_wdata,
  (*mark_debug = "true"*)input  wire   [3:0]  s_axil_wstrb,
  (*mark_debug = "true"*)input  wire          s_axil_wvalid,
  (*mark_debug = "true"*)output wire          s_axil_wready,
  (*mark_debug = "true"*)output wire   [1:0]  s_axil_bresp,
  (*mark_debug = "true"*)output wire          s_axil_bvalid,
  (*mark_debug = "true"*)input  wire          s_axil_bready,
  (*mark_debug = "true"*)input  wire  [31:0]  s_axil_araddr,
  (*mark_debug = "true"*)input  wire          s_axil_arvalid,
  (*mark_debug = "true"*)output wire          s_axil_arready,
  (*mark_debug = "true"*)output wire  [31:0]  s_axil_rdata,
  output wire   [1:0] s_axil_rresp, 
  (*mark_debug = "true"*)output wire          s_axil_rvalid,
  (*mark_debug = "true"*)input  wire          s_axil_rready,


//VU9P_TUL_EX_String= FALSE


  // AXI streaming ports
  // output wire [C_DATA_WIDTH-1:0]              s_axis_c2h_tdata_0,  
  // output wire                                 s_axis_c2h_tlast_0,
  // output wire                                 s_axis_c2h_tvalid_0,
  // input  wire                                 s_axis_c2h_tready_0,
  // output wire [C_DATA_WIDTH/8-1:0]            s_axis_c2h_tkeep_0,

  // input  wire [C_DATA_WIDTH-1:0]              m_axis_h2c_tdata_0,
  // input  wire                                 m_axis_h2c_tlast_0,
  // input  wire                                 m_axis_h2c_tvalid_0,
  // output wire                                 m_axis_h2c_tready_0,
  // input  wire [C_DATA_WIDTH/8-1:0]            m_axis_h2c_tkeep_0,

  // input  wire [C_DATA_WIDTH-1:0]              m_axis_h2c_tdata_1,
  // input  wire                                 m_axis_h2c_tlast_1,
  // input  wire                                 m_axis_h2c_tvalid_1,
  // output wire                                 m_axis_h2c_tready_1,
  // input  wire [C_DATA_WIDTH/8-1:0]            m_axis_h2c_tkeep_1,

  // System IO signals
  input  wire         user_resetn,
  input  wire         sys_rst_n,

  input  wire         user_clk,
  (*mark_debug = "true"*)input  wire         user_lnk_up,
  output wire   [3:0] leds,

  // RAM接口
  (*DONT_TOUCH = "true"*)(*mark_debug = "true"*)output wire                       wr_en_o             ,
  (*DONT_TOUCH = "true"*)(*mark_debug = "true"*)output wire   [31:0]              wr_data_o           ,
  (*DONT_TOUCH = "true"*)(*mark_debug = "true"*)output wire   [31:0]              wr_addr_o           ,
                        
  (*DONT_TOUCH = "true"*)(*mark_debug = "true"*)output wire                       rd_en_o             ,
  (*DONT_TOUCH = "true"*)(*mark_debug = "true"*)output wire   [31:0]              rd_addr_o           ,
  (*DONT_TOUCH = "true"*)(*mark_debug = "true"*)input  wire   [31:0]              rd_data_i           ,
  (*DONT_TOUCH = "true"*)(*mark_debug = "true"*)input  wire                       rd_valid_i
);
  // wire/reg declarations
  wire            sys_reset;
  reg  [25:0]     user_clk_heartbeat;

  // The sys_rst_n input is active low based on the core configuration
  assign sys_resetn = sys_rst_n;

  // Create a Clock Heartbeat
  always @(posedge user_clk) begin
    if(!sys_resetn) begin
      user_clk_heartbeat <= #TCQ 26'd0;
    end else begin
      user_clk_heartbeat <= #TCQ user_clk_heartbeat + 1'b1;
    end
  end

  // LEDs for observation
  assign leds[0] = sys_resetn;
  assign leds[1] = user_resetn;
  assign leds[2] = user_lnk_up;
  assign leds[3] = user_clk_heartbeat[25];

  // AXI streaming ports
 /* assign s_axis_c2h_tdata_0 =  m_axis_h2c_tdata_0;   
  assign s_axis_c2h_tlast_0 =  m_axis_h2c_tlast_0;   
  assign s_axis_c2h_tvalid_0 =  m_axis_h2c_tvalid_0;   
  assign s_axis_c2h_tkeep_0 =  m_axis_h2c_tkeep_0;  
  assign m_axis_h2c_tready_0 = s_axis_c2h_tready_0;
  assign m_axis_h2c_tready_1 = 1'b1;*/



AXIL_MMAP #(
  .AXIL_DATA_WIDTH(32),
  .AXIL_ADDR_WIDTH(32)
) U_AXIL_MMAP (
  .clk            (user_clk),
  .rst_n          (user_resetn),

  .s_axil_awaddr  (s_axil_awaddr),
  .s_axil_awvalid (s_axil_awvalid),
  .s_axil_awready (s_axil_awready),
  .s_axil_wdata   (s_axil_wdata),
  .s_axil_wstrb   (s_axil_wstrb),
  .s_axil_wvalid  (s_axil_wvalid),
  .s_axil_wready  (s_axil_wready),
  .s_axil_bresp   (s_axil_bresp),
  .s_axil_bvalid  (s_axil_bvalid),
  .s_axil_bready  (s_axil_bready),

  .s_axil_araddr  (s_axil_araddr),
  .s_axil_arvalid (s_axil_arvalid),
  .s_axil_arready (s_axil_arready),
  .s_axil_rdata   (s_axil_rdata),
  .s_axil_rresp   (s_axil_rresp),
  .s_axil_rvalid  (s_axil_rvalid),
  .s_axil_rready  (s_axil_rready),

  .wr_data_o      (wr_data_o),
  .wr_addr_o      (wr_addr_o),
  .wr_en_o        (wr_en_o),

  .rd_addr_o      (rd_addr_o),
  .rd_en_o        (rd_en_o),
  .rd_data_i      (rd_data_i),
  .rd_valid_i     (rd_valid_i)
);


endmodule
