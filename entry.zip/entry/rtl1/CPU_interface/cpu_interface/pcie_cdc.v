//**********************************************
//COPYRIGHT(c)2022, Xidian University    
//All rights reserved.                   
//                                       
//File name     : cpu_cdc.v
//Module name   : cpu_cdc
//Full name     :                        
//Author 		: xmw                     
//Email 		:                         
//                                       
//Version 		:                         
//This File is  Created on 2022-7-18 20:28:18
//------------------Discription-----------------
//         PCIe RAM接口跨时钟域（慢跨快）                             
//----------------------------------------------
//-------------Modification history-------------
//Last Modified by 	: xmw                    
//Last Modified time: 2022-7-18 20:28:18
//Discription 	:                                
//----------------------------------------------
//TIMESCALE                                     
`timescale 1ns / 1ps                            
//DEFINES                                                               
//----------------------------------------------
module pcie_cdc(
	input							clk62p5m	,	// pcie 62.5MHz
	input							clk125m 	,	// user 125MHz
	input							rst_n   	,

	/*
	 * PCIe ram interface 62.5MHz
	 */
	input    	[  31:   0]   		wdata_cpu   ,
	input    	              		wen_cpu     ,
	input    	[  31:   0]   		waddr_cpu   ,
	input                     		ren_cpu     ,
	input       [  31:   0]   		raddr_cpu   ,
	output reg 	[  31:   0]   		rdata_cpu   ,
	output reg 	               		rvalid_cpu  ,

	/*
	 * User ram interface 125MHz
	 */
	output reg                  	wen_sys     ,
	output reg  [  31:   0]   		waddr_sys   ,
	output reg  [  31:   0]   		wdata_sys   ,
	output reg                		ren_sys     ,
	output reg  [  31:   0]   		raddr_sys   ,
	input       [  31:   0]   		rdata_sys   ,
	input                       	rvalid_sys  
);

wire [64:0]		wr_fifo_wrdata;
wire [64:0]		wr_fifo_data;
wire 			wr_fifo_ren;
wire 			wr_fifo_empty;

wire [32:0]		rd_req_fifo_wrdata;
wire [32:0]		rd_req_fifo_data;
wire 			rd_req_fifo_ren;
wire 			rd_req_fifo_empty;

wire [32:0]		rd_cpl_fifo_data;
wire 			rd_cpl_fifo_ren;
wire 			rd_cpl_fifo_empty;

wire            wen_sys_int   ;
wire [31:0]   	waddr_sys_int ;
wire [31:0]   	wdata_sys_int ;
wire         	ren_sys_int   ;
wire [31:0]   	raddr_sys_int ;

wire [31:0]   	rdata_cpu_int ;
wire 	        rvalid_cpu_int;

reg wen_sys_int_ff  	;
reg ren_sys_int_ff  	;
reg rvalid_cpu_int_ff   ;


assign wr_fifo_wrdata = wen_cpu ? { wen_cpu, waddr_cpu, wdata_cpu } : 65'd0;
assign { wen_sys_int, waddr_sys_int, wdata_sys_int } = wr_fifo_data;
assign wr_fifo_ren = ~wr_fifo_empty;

assign rd_req_fifo_wrdata = ren_cpu ? { ren_cpu, raddr_cpu } : 33'd0;
assign { ren_sys_int, raddr_sys_int } = rd_req_fifo_data;
assign rd_req_fifo_ren = ~rd_req_fifo_empty;

assign { rvalid_cpu_int, rdata_cpu_int } = rd_cpl_fifo_data;
assign rd_cpl_fifo_ren = ~rd_cpl_fifo_empty;


reg 			wen_cpu_ff;
reg 			ren_cpu_ff;
reg 			rvalid_sys_ff;

always @(posedge clk62p5m or negedge rst_n) begin
	if (rst_n == 1'b0) begin
		wen_cpu_ff <= 1'b0;
		ren_cpu_ff <= 1'b0;
	end
	else begin
		wen_cpu_ff <= wen_cpu;
		ren_cpu_ff <= ren_cpu;
	end
end

always @(posedge clk125m or negedge rst_n) begin
	if (rst_n == 1'b0) begin
		rvalid_sys_ff <= 1'b0;
	end
	else begin
		rvalid_sys_ff <= rvalid_sys;
	end
end

always @(posedge clk125m or negedge rst_n) begin
	if (rst_n == 1'b0) begin
		wen_sys_int_ff		<= 'd0;
		ren_sys_int_ff		<= 'd0;
	end
	else begin
		wen_sys_int_ff		<= wen_sys_int;
		ren_sys_int_ff		<= ren_sys_int;
	end
end

always @(posedge clk125m or negedge rst_n) begin
	if (rst_n == 1'b0) begin
		wen_sys  	<= 'd0;
		waddr_sys	<= 'd0;
		wdata_sys	<= 'd0;	
	end
	else if( wen_sys_int & ~wen_sys_int_ff ) begin
		wen_sys  	<= 1'b1;
		waddr_sys	<= waddr_sys_int;
		wdata_sys	<= wdata_sys_int;
	end
	else begin
		wen_sys  	<= 'd0;
		waddr_sys	<= 'd0;
		wdata_sys	<= 'd0;	
	end
end

always @(posedge clk125m or negedge rst_n) begin
	if (rst_n == 1'b0) begin
		ren_sys  	<= 'd0;
		raddr_sys	<= 'd0;
	end
	else if( ren_sys_int & ~ren_sys_int_ff ) begin
		ren_sys  	<= 1'b1;
		raddr_sys	<= raddr_sys_int;
	end
	else begin
		ren_sys  	<= 'd0;
		raddr_sys	<= 'd0;
	end
end

always @(posedge clk62p5m or negedge rst_n) begin
	if (rst_n == 1'b0) begin
		rvalid_cpu_int_ff <= 1'b0;
	end
	else begin
		rvalid_cpu_int_ff <= rvalid_cpu_int;
	end
end

always @(posedge clk62p5m or negedge rst_n) begin
	if (rst_n == 1'b0) begin
		rdata_cpu  <= 'd0;
		rvalid_cpu <= 'd0;
	end
	else if( rvalid_cpu_int & ~rvalid_cpu_int_ff ) begin
		rdata_cpu  <= rdata_cpu_int;
		rvalid_cpu <= 1'b1;
	end
	else begin
		rdata_cpu  <= 'd0;
		rvalid_cpu <= 'd0;
	end
end


// wr fifo
asFIFO_wr U_asFIFO_wr (
  .wr_clk	(clk62p5m),  // input wire wr_clk
  .rd_clk	(clk125m),  // input wire rd_clk
  .din		(wr_fifo_wrdata),        // input wire [64 : 0] din
  .wr_en	(wen_cpu | wen_cpu_ff),    // input wire wr_en
  .rd_en	(wr_fifo_ren),    // input wire rd_en
  .dout		(wr_fifo_data),      // output wire [64 : 0] dout
  .full		( ),      // output wire full
  .empty 	(wr_fifo_empty)    // output wire empty
);


// rd req fifo
asFIFO_rd_req U_asFIFO_rd_req (
  .wr_clk	(clk62p5m),  // input wire wr_clk
  .rd_clk	(clk125m),  // input wire rd_clk
  .din		(rd_req_fifo_wrdata),        // input wire [64 : 0] din
  .wr_en	(ren_cpu | ren_cpu_ff),    // input wire wr_en
  .rd_en	(rd_req_fifo_ren),    // input wire rd_en
  .dout		(rd_req_fifo_data),      // output wire [64 : 0] dout
  .full		( ),      // output wire full
  .empty 	(rd_req_fifo_empty)    // output wire empty
);


// rd cpl fifo
asFIFO_rd_cpl U_asFIFO_rd_cpl (
  .wr_clk(clk125m),  // input wire wr_clk
  .rd_clk(clk62p5m),  // input wire rd_clk
  .din({ rvalid_sys, rdata_sys }),        // input wire [32 : 0] din
  .wr_en(rvalid_sys | rvalid_sys_ff),    // input wire wr_en
  .rd_en(rd_cpl_fifo_ren),    // input wire rd_en
  .dout(rd_cpl_fifo_data),      // output wire [32 : 0] dout
  .full( ),      // output wire full
  .empty(rd_cpl_fifo_empty)    // output wire empty
);


endmodule
