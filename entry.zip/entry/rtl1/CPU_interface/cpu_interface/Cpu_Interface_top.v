`timescale 1ns / 1ps
// **************************************************************        
// COPYRIGHT(c)2021, Xidian University
// All rights reserved.
//
// IP LIB INDEX   : 
// IP Name        : 
//                
// File name      :  Cpu_interface_top.v
// Module name    :  CPU_INTERFACE_TOP
// Full name      : 
//
// Author         :  Wang-Qianjiang 
// Email          :  qjwang618@163.com

// Version        :  V 1.0 
// 
//Abstract        : 
//Called by       :  Father Module
// 
// This File is  Created on 2021/9/29
// Modification history
// ---------------------------------------------------------------------------------

//3.3V

module CPU_INTERFACE_TOP #(
    parameter PL_LINK_CAP_MAX_LINK_WIDTH          = 1,
    parameter C_DATA_WIDTH                        = 64
)(
    output [(PL_LINK_CAP_MAX_LINK_WIDTH - 1) : 0]   pci_exp_txp         ,
    output [(PL_LINK_CAP_MAX_LINK_WIDTH - 1) : 0]   pci_exp_txn         ,
    input  [(PL_LINK_CAP_MAX_LINK_WIDTH - 1) : 0]   pci_exp_rxp         ,
    input  [(PL_LINK_CAP_MAX_LINK_WIDTH - 1) : 0]   pci_exp_rxn         ,

    //VU9P_TUL_EX_String= FALSE
    input                                           sys_clk_p           ,
    input                                           sys_clk_n           ,
    input                                           ui_clk              ,
    input                                           sys_rst_n           ,


    input                                           clk                 ,   // 125MHz用户时钟
    input                                           userclk2_out        ,   // 125MHz物理时钟
    output                                          pcie_core_clk       ,   // 62.5MHz PCIe恢复时钟
    output                                          pcie_core_rstn      ,
    output                                          pcie_link_up        ,

    //写
    (*DONT_TOUCH = "true"*)output                        wen_sys             ,
    (*DONT_TOUCH = "true"*)output        [  31:   0]     waddr_sys           ,
    (*DONT_TOUCH = "true"*)output        [  31:   0]     wdata_sys           ,
    //读                 
    (*DONT_TOUCH = "true"*)output                        ren_sys             ,
    (*DONT_TOUCH = "true"*)output        [  31:   0]     raddr_sys           ,
    (*DONT_TOUCH = "true"*)input         [  31:   0]     rdata_sys           ,
    (*DONT_TOUCH = "true"*)input                         rvalid_sys          ,

    //PHY 写
    (*DONT_TOUCH = "true"*)output                        wen_phy             ,
    (*DONT_TOUCH = "true"*)output        [  31:   0]     waddr_phy           ,
    (*DONT_TOUCH = "true"*)output        [  31:   0]     wdata_phy           ,

    //DDR数据上报
    input             wire [C_DATA_WIDTH-1:0]            s_axis_c2h_tdata_0  , 
    input             wire                               s_axis_c2h_tlast_0  ,
    input             wire                               s_axis_c2h_tvalid_0 ,
    output            wire                               s_axis_c2h_tready_0 ,
    input             wire [C_DATA_WIDTH/8-1:0]          s_axis_c2h_tkeep_0  ,
    
    //一致性数据上报
    input             wire [C_DATA_WIDTH-1:0]            s_axis_c2h_tdata_1  ,
    input             wire                               s_axis_c2h_tlast_1  ,
    input             wire                               s_axis_c2h_tvalid_1 ,
    output            wire                               s_axis_c2h_tready_1 ,
    input             wire [C_DATA_WIDTH/8-1:0]          s_axis_c2h_tkeep_1  
);         


//写
wire           wen      ;
wire  [31:0]   waddr    ;
wire  [31:0]   wdata    ;
//读
wire           ren      ;
wire  [31:0]   raddr    ;
wire  [31:0]   rdata    ;  
wire           rvalid   ; 

wire [C_DATA_WIDTH-1:0]    s_axis_c2h_tdata_0_cdc ;
wire                       s_axis_c2h_tlast_0_cdc ;
wire                       s_axis_c2h_tvalid_0_cdc;
wire                       s_axis_c2h_tready_0_cdc;
wire [C_DATA_WIDTH/8-1:0]  s_axis_c2h_tkeep_0_cdc ;

wire [C_DATA_WIDTH-1:0]    s_axis_c2h_tdata_1_cdc ;
wire                       s_axis_c2h_tlast_1_cdc ;
wire                       s_axis_c2h_tvalid_1_cdc;
wire                       s_axis_c2h_tready_1_cdc;
wire [C_DATA_WIDTH/8-1:0]  s_axis_c2h_tkeep_1_cdc ;


xilinx_dma_pcie_ep U_xilinx_dma_pcie_ep (
    .pci_exp_txp            (pci_exp_txp            ),
    .pci_exp_txn            (pci_exp_txn            ),
    .pci_exp_rxp            (pci_exp_rxp            ),
    .pci_exp_rxn            (pci_exp_rxn            ),

    .sys_clk_p              (sys_clk_p              ),
    .sys_clk_n              (sys_clk_n              ),
    .sys_rst_n              (sys_rst_n              ),

    .pcie_core_clk          (pcie_core_clk          ),
    .pcie_core_rstn         (pcie_core_rstn         ),
    .pcie_link_up           (pcie_link_up           ),

    .wr_en_o                (wen                    ),
    .wr_data_o              (wdata                  ),
    .wr_addr_o              (waddr                  ),

    .rd_en_o                (ren                    ),
    .rd_addr_o              (raddr                  ),
    .rd_data_i              (rdata                  ),
    .rd_valid_i             (rvalid                 ),

    .s_axis_c2h_tdata_0     (s_axis_c2h_tdata_0_cdc ),
    .s_axis_c2h_tlast_0     (s_axis_c2h_tlast_0_cdc ),
    .s_axis_c2h_tvalid_0    (s_axis_c2h_tvalid_0_cdc),
    .s_axis_c2h_tready_0    (s_axis_c2h_tready_0_cdc),
    .s_axis_c2h_tkeep_0     (s_axis_c2h_tkeep_0_cdc ),

    .s_axis_c2h_tdata_1     (s_axis_c2h_tdata_1_cdc ),                     
    .s_axis_c2h_tlast_1     (s_axis_c2h_tlast_1_cdc ),                     
    .s_axis_c2h_tvalid_1    (s_axis_c2h_tvalid_1_cdc),                     
    .s_axis_c2h_tready_1    (s_axis_c2h_tready_1_cdc),                     
    .s_axis_c2h_tkeep_1     (s_axis_c2h_tkeep_1_cdc )                      
);



// 跨时钟域 PCIe 62.5M 跨 User 125M
pcie_cdc PCIE_CDC_USER(
    .clk62p5m   (pcie_core_clk ),
    .clk125m    (clk           ),
    .rst_n      (pcie_core_rstn),

    .wdata_cpu  (wdata         ),
    .wen_cpu    (wen           ),
    .waddr_cpu  (waddr         ),
    .ren_cpu    (ren           ),
    .raddr_cpu  (raddr         ),
    .rdata_cpu  (rdata         ),
    .rvalid_cpu (rvalid        ),

    //CDC输出
    .wen_sys    (wen_sys       ),
    .waddr_sys  (waddr_sys     ),
    .wdata_sys  (wdata_sys     ),
    .ren_sys    (ren_sys       ),
    .raddr_sys  (raddr_sys     ),
    .rdata_sys  (rdata_sys     ),
    .rvalid_sys (rvalid_sys    )
);

// 跨时钟域 PCIe 62.5M 跨 Phy侧 125M
pcie_cdc PCIE_CDC_PHY(
    .clk62p5m   (pcie_core_clk ),
    .clk125m    (userclk2_out  ),
    .rst_n      (pcie_core_rstn),

    .wdata_cpu  (wdata         ),
    .wen_cpu    (wen           ),
    .waddr_cpu  (waddr         ),

    //CDC输出
    .wen_sys    (wen_phy       ),
    .waddr_sys  (waddr_phy     ),
    .wdata_sys  (wdata_phy     )
);

//AXIS 跨时钟域
axis_dma_cdc_fifo_64x64 OC_axis_dma_cdc_fifo_64x64 (
  .s_axis_aresetn(pcie_core_rstn         ),  // input wire s_axis_aresetn
  /*
   * 用户DMA数据输入
  */
  .s_axis_aclk   (clk                    ),    // input wire s_axis_aclk
  .s_axis_tvalid (s_axis_c2h_tvalid_0    ),    // input wire s_axis_tvalid
  .s_axis_tready (s_axis_c2h_tready_0    ),    // output wire s_axis_tready
  .s_axis_tdata  (s_axis_c2h_tdata_0     ),    // input wire [63 : 0] s_axis_tdata
  .s_axis_tkeep  (s_axis_c2h_tkeep_0     ),    // input wire [7 : 0] s_axis_tkeep
  .s_axis_tlast  (s_axis_c2h_tlast_0     ),    // input wire s_axis_tlast
  /*
   * 数据输出 to XDMA
  */
  .m_axis_aclk   (pcie_core_clk          ),    // input wire m_axis_aclk
  .m_axis_tvalid (s_axis_c2h_tvalid_0_cdc),    // output wire m_axis_tvalid
  .m_axis_tready (s_axis_c2h_tready_0_cdc),    // input wire m_axis_tready
  .m_axis_tdata  (s_axis_c2h_tdata_0_cdc ),    // output wire [63 : 0] m_axis_tdata
  .m_axis_tkeep  (s_axis_c2h_tkeep_0_cdc ),    // output wire [7 : 0] m_axis_tkeep
  .m_axis_tlast  (s_axis_c2h_tlast_0_cdc )     // output wire m_axis_tlast
); 

axis_dma_cdc_fifo_64x64 PHY_axis_dma_cdc_fifo_64x64   (
  .s_axis_aresetn(pcie_core_rstn         ),  // input wire s_axis_aresetn
  /*
   * 完整帧DMA数据输入
  */
  .s_axis_aclk   (userclk2_out           ),    // input wire s_axis_aclk
  .s_axis_tvalid (s_axis_c2h_tvalid_1    ),    // input wire s_axis_tvalid
  .s_axis_tready (s_axis_c2h_tready_1    ),    // output wire s_axis_tready
  .s_axis_tdata  (s_axis_c2h_tdata_1     ),    // input wire [63 : 0] s_axis_tdata
  .s_axis_tkeep  (s_axis_c2h_tkeep_1     ),    // input wire [7 : 0] s_axis_tkeep
  .s_axis_tlast  (s_axis_c2h_tlast_1     ),    // input wire s_axis_tlast
  /*
   * 数据输出 to XDMA
  */
  .m_axis_aclk   (pcie_core_clk          ),    // input wire m_axis_aclk
  .m_axis_tvalid (s_axis_c2h_tvalid_1_cdc),    // output wire m_axis_tvalid
  .m_axis_tready (s_axis_c2h_tready_1_cdc),    // input wire m_axis_tready
  .m_axis_tdata  (s_axis_c2h_tdata_1_cdc ),    // output wire [63 : 0] m_axis_tdata
  .m_axis_tkeep  (s_axis_c2h_tkeep_1_cdc ),    // output wire [7 : 0] m_axis_tkeep
  .m_axis_tlast  (s_axis_c2h_tlast_1_cdc )     // output wire m_axis_tlast
); 



endmodule
