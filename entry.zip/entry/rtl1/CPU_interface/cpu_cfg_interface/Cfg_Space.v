`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company:XIDIAN
// Engineer: wanghaoyu
// 
// Create Date: 2025/7/12 23:19:49
// Design Name: 
// Module Name: CFG_SPACE
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

`include "../../../include/cpu_define.v"
module CFG_SPACE(
    input    clk  ,
    input    LREST,
    //写
    input                    wen        ,
    input           [31:0]   waddr      ,
    input           [31:0]   wdata      ,
    //读
    input                    ren        ,
    input           [31:0]   raddr      ,
    output   reg    [31:0]   rdata      ,
    output   reg             rvalid     ,
    //多板卡同步
    output   reg     sync_register1     ,
    input            sync_register2     ,
    output   reg     sync_register3     ,
    input            sync_register4     ,
    output   reg     Test_sync_register1,
    input            Test_sync_register2,
    output   reg     Test_sync_register3,
    input            Test_sync_register4,
    //端口状态
    output   reg    [1:0]    port0_mode                   ,
    output   reg    [1:0]    port1_mode                   ,
    output   reg    [1:0]    port2_mode                   ,
    output   reg    [1:0]    port3_mode                   ,
    input           [31:0]   ga_data_in                   ,

    //端节点配置
    output   reg    [7:0 ]   oc0_Priority1                ,
    output   reg    [7:0 ]   oc0_clockClass               ,
    output   reg    [7:0 ]   oc0_clockAccuracy            ,
    output   reg    [15:0]   oc0_offsetScaledLogVariance  ,
    output   reg    [7:0 ]   oc0_Priority2                ,
    output   reg    [63:0]   oc0_clockIdentity            ,
    output   reg    [7:0]    oc0_LogInterval_sync         ,
    output   reg    [7:0]    oc0_LogInterval_pdelay       ,
    output   reg    [7:0]    oc0_LogInterval_announce     ,
    output   reg    [31:0]   oc0_error_time               ,
    output   reg    [31:0]   oc0_error_type               ,

    output   reg    [7:0 ]   oc1_Priority1                ,
    output   reg    [7:0 ]   oc1_clockClass               ,
    output   reg    [7:0 ]   oc1_clockAccuracy            ,
    output   reg    [15:0]   oc1_offsetScaledLogVariance  ,
    output   reg    [7:0 ]   oc1_Priority2                ,
    output   reg    [63:0]   oc1_clockIdentity            ,
    output   reg    [7:0]    oc1_LogInterval_sync         ,
    output   reg    [7:0]    oc1_LogInterval_pdelay       ,
    output   reg    [7:0]    oc1_LogInterval_announce     ,
    output   reg    [31:0]   oc1_error_time               ,
    output   reg    [31:0]   oc1_error_type               ,

    output   reg    [7:0 ]   oc2_Priority1                ,
    output   reg    [7:0 ]   oc2_clockClass               ,
    output   reg    [7:0 ]   oc2_clockAccuracy            ,
    output   reg    [15:0]   oc2_offsetScaledLogVariance  ,
    output   reg    [7:0 ]   oc2_Priority2                ,
    output   reg    [63:0]   oc2_clockIdentity            ,
    output   reg    [7:0]    oc2_LogInterval_sync         ,
    output   reg    [7:0]    oc2_LogInterval_pdelay       ,
    output   reg    [7:0]    oc2_LogInterval_announce     ,
    output   reg    [31:0]   oc2_error_time               ,
    output   reg    [31:0]   oc2_error_type               ,

    output   reg    [7:0 ]   oc3_Priority1                ,
    output   reg    [7:0 ]   oc3_clockClass               ,
    output   reg    [7:0 ]   oc3_clockAccuracy            ,
    output   reg    [15:0]   oc3_offsetScaledLogVariance  ,
    output   reg    [7:0 ]   oc3_Priority2                ,
    output   reg    [63:0]   oc3_clockIdentity            ,
    output   reg    [7:0]    oc3_LogInterval_sync         ,
    output   reg    [7:0]    oc3_LogInterval_pdelay       ,
    output   reg    [7:0]    oc3_LogInterval_announce     ,
    output   reg    [31:0]   oc3_error_time               ,
    output   reg    [31:0]   oc3_error_type               ,

    //测试时长及启动标识
    output   reg             test_start                   ,
    output   reg    [31:0]   config_time                  ,
    output   reg             test_rst                     ,

    //上报OC端寄存器
    input   [31:0]       port0_upload_port_state          ,
    input   [31:0]       port0_upload_sys_time_ns         ,
    input   [31:0]       port0_upload_offset              ,
    input   [31:0]       port0_upload_delay               ,
    input   [31:0]       port1_upload_port_state          ,
    input   [31:0]       port1_upload_sys_time_ns         ,
    input   [31:0]       port1_upload_offset              ,
    input   [31:0]       port1_upload_delay               ,
    input   [31:0]       port2_upload_port_state          ,
    input   [31:0]       port2_upload_sys_time_ns         ,
    input   [31:0]       port2_upload_offset              ,
    input   [31:0]       port2_upload_delay               ,
    input   [31:0]       port3_upload_port_state          ,
    input   [31:0]       port3_upload_sys_time_ns         ,
    input   [31:0]       port3_upload_offset              ,
    input   [31:0]       port3_upload_delay               ,
    //上报帧间隔
    input   [31:0]       port0_sync_interval              ,
    input   [31:0]       port0_announce_interval          ,
    input   [31:0]       port0_pdelay_interval            ,
    input   [31:0]       port0_pdelay_resp_interval       ,
          
    input   [31:0]       port1_sync_interval              ,
    input   [31:0]       port1_announce_interval          ,
    input   [31:0]       port1_pdelay_interval            ,
    input   [31:0]       port1_pdelay_resp_interval       ,
          
    input   [31:0]       port2_sync_interval              ,
    input   [31:0]       port2_announce_interval          ,
    input   [31:0]       port2_pdelay_interval            ,
    input   [31:0]       port2_pdelay_resp_interval       ,
          
    input   [31:0]       port3_sync_interval              ,
    input   [31:0]       port3_announce_interval          ,
    input   [31:0]       port3_pdelay_interval            ,
    input   [31:0]       port3_pdelay_resp_interval       ,
    
    //上报主机交互
    output  reg          card_upload_ren_0                ,
    input                card_upload_flag_0               ,
    output  reg          card_upload_ren_1                ,
    input                card_upload_flag_1               ,

    input   [31:0]       monitior_error             

);

//多板卡同步
always @(posedge clk or negedge LREST) begin
    if (LREST==1'b0) begin
        sync_register1 <= 1'b0;
    end
    else if ( wen == 1'b1 && waddr == `SYNC_BOARD1_REGISTER1) begin
        sync_register1 <= 1'b1;
    end
    else  begin
        sync_register1 <= 1'b0;
    end
end

always @(posedge clk or negedge LREST) begin
    if (LREST==1'b0) begin
        sync_register3 <= 1'b0;
    end
    else if ( wen == 1'b1 && waddr == `SYNC_BOARD1_REGISTER3) begin
        sync_register3 <= 1'b1;
    end
    else  begin
        sync_register3 <= 1'b0;
    end
end

always @(posedge clk or negedge LREST) begin
    if (LREST==1'b0) begin
        Test_sync_register1 <= 1'b0;
    end
    else if ( wen == 1'b1 && waddr == `TESTSYNC_BOARD1_REGISTER1) begin
        Test_sync_register1 <= 1'b1;
    end
    else  begin
        Test_sync_register1 <= 1'b0;
    end
end

always @(posedge clk or negedge LREST) begin
    if (LREST==1'b0) begin
        Test_sync_register3 <= 1'b0;
    end
    else if ( wen == 1'b1 && waddr == `TESTSYNC_BOARD1_REGISTER3) begin
        Test_sync_register3 <= 1'b1;
    end
    else  begin
        Test_sync_register3 <= 1'b0;
    end
end

//-------------------------AXI-Lite写-------------------------//
always @(posedge clk or negedge LREST) begin
    if (!LREST) begin
        oc0_Priority1               <=  8'b0 ;
        oc0_clockClass              <=  8'b0 ;
        oc0_clockAccuracy           <=  8'b0 ;
        oc0_offsetScaledLogVariance <=  16'b0;
        oc0_Priority2               <=  8'b0 ;
        oc0_clockIdentity           <=  64'b0;
        oc0_LogInterval_sync        <=  8'b0 ;
        oc0_LogInterval_pdelay      <=  8'b0 ;
        oc0_LogInterval_announce    <=  8'b0 ;
        oc0_error_time              <=  32'b0;
        oc0_error_type              <=  32'b0;

        oc1_Priority1               <=  8'b0 ;
        oc1_clockClass              <=  8'b0 ;
        oc1_clockAccuracy           <=  8'b0 ;
        oc1_offsetScaledLogVariance <=  16'b0;
        oc1_Priority2               <=  8'b0 ;
        oc1_clockIdentity           <=  64'b0;
        oc1_LogInterval_sync        <=  8'b0 ;
        oc1_LogInterval_pdelay      <=  8'b0 ;
        oc1_LogInterval_announce    <=  8'b0 ;
        oc1_error_time              <=  32'b0;
        oc1_error_type              <=  32'b0;

        oc2_Priority1               <=  8'b0 ;
        oc2_clockClass              <=  8'b0 ;
        oc2_clockAccuracy           <=  8'b0 ;
        oc2_offsetScaledLogVariance <=  16'b0;
        oc2_Priority2               <=  8'b0 ;
        oc2_clockIdentity           <=  64'b0;
        oc2_LogInterval_sync        <=  8'b0 ;
        oc2_LogInterval_pdelay      <=  8'b0 ;
        oc2_LogInterval_announce    <=  8'b0 ;
        oc2_error_time              <=  32'b0;
        oc2_error_type              <=  32'b0;

        oc3_Priority1               <=  8'b0 ;
        oc3_clockClass              <=  8'b0 ;
        oc3_clockAccuracy           <=  8'b0 ;
        oc3_offsetScaledLogVariance <=  16'b0;
        oc3_Priority2               <=  8'b0 ;
        oc3_clockIdentity           <=  64'b0;
        oc3_LogInterval_sync        <=  8'b0 ;
        oc3_LogInterval_pdelay      <=  8'b0 ;
        oc3_LogInterval_announce    <=  8'b0 ;
        oc3_error_time              <=  32'b0;
        oc3_error_type              <=  32'b0;

        port0_mode                  <=  2'b0 ;
        port1_mode                  <=  2'b0 ;
        port2_mode                  <=  2'b0 ;
        port3_mode                  <=  2'b0 ;
        card_upload_ren_0           <=  1'b0 ;
        card_upload_ren_1           <=  1'b0 ;

        test_start                  <=  1'b0 ;
        config_time                 <=  32'b0;
        test_rst                    <=  1'b0 ;
    end

    else if (wen == 1'b1)begin
        case (waddr)
            `OC0_PRIORITY1              :oc0_Priority1               <= wdata[7:0 ];
            `OC0_CLOCKCLASS             :oc0_clockClass              <= wdata[7:0 ];
            `OC0_CLOCKACCURACY          :oc0_clockAccuracy           <= wdata[7:0 ];
            `OC0_OFFSETSCALEDLOGVARIANCE:oc0_offsetScaledLogVariance <= wdata[15:0];
            `OC0_PRIORITY2              :oc0_Priority2               <= wdata[7:0 ];
            `OC0_CLOCKIDENTITY1         :oc0_clockIdentity[31:0]     <= wdata[31:0];
            `OC0_CLOCKIDENTITY2         :oc0_clockIdentity[63:32]    <= wdata[31:0];
            `OC0_LOGINTERVAL_SYNC       :oc0_LogInterval_sync        <= wdata[7:0 ];
            `OC0_LOGINTERVAL_PDELAY     :oc0_LogInterval_pdelay      <= wdata[7:0 ];
            `OC0_LOGINTERVAL_ANNOUNCE   :oc0_LogInterval_announce    <= wdata[7:0 ];
            `OC0_ERROR_TIME             :oc0_error_time              <= wdata[31:0];
            `OC0_ERROR_TYPE             :oc0_error_type              <= wdata[31:0];  

            `OC1_PRIORITY1              :oc1_Priority1               <= wdata[7:0 ];
            `OC1_CLOCKCLASS             :oc1_clockClass              <= wdata[7:0 ];
            `OC1_CLOCKACCURACY          :oc1_clockAccuracy           <= wdata[7:0 ];
            `OC1_OFFSETSCALEDLOGVARIANCE:oc1_offsetScaledLogVariance <= wdata[15:0];
            `OC1_PRIORITY2              :oc1_Priority2               <= wdata[7:0 ];
            `OC1_CLOCKIDENTITY1         :oc1_clockIdentity[31:0]     <= wdata[31:0];
            `OC1_CLOCKIDENTITY2         :oc1_clockIdentity[63:32]    <= wdata[31:0];
            `OC1_LOGINTERVAL_SYNC       :oc1_LogInterval_sync        <= wdata[7:0 ];
            `OC1_LOGINTERVAL_PDELAY     :oc1_LogInterval_pdelay      <= wdata[7:0 ];
            `OC1_LOGINTERVAL_ANNOUNCE   :oc1_LogInterval_announce    <= wdata[7:0 ];
            `OC1_ERROR_TIME             :oc1_error_time              <= wdata[31:0];
            `OC1_ERROR_TYPE             :oc1_error_type              <= wdata[31:0];  

            `OC2_PRIORITY1              :oc2_Priority1               <= wdata[7:0 ];
            `OC2_CLOCKCLASS             :oc2_clockClass              <= wdata[7:0 ];
            `OC2_CLOCKACCURACY          :oc2_clockAccuracy           <= wdata[7:0 ];
            `OC2_OFFSETSCALEDLOGVARIANCE:oc2_offsetScaledLogVariance <= wdata[15:0];
            `OC2_PRIORITY2              :oc2_Priority2               <= wdata[7:0 ];
            `OC2_CLOCKIDENTITY1         :oc2_clockIdentity[31:0]     <= wdata[31:0];
            `OC2_CLOCKIDENTITY2         :oc2_clockIdentity[63:32]    <= wdata[31:0];
            `OC2_LOGINTERVAL_SYNC       :oc2_LogInterval_sync        <= wdata[7:0 ];
            `OC2_LOGINTERVAL_PDELAY     :oc2_LogInterval_pdelay      <= wdata[7:0 ];
            `OC2_LOGINTERVAL_ANNOUNCE   :oc2_LogInterval_announce    <= wdata[7:0 ];
            `OC2_ERROR_TIME             :oc2_error_time              <= wdata[31:0];
            `OC2_ERROR_TYPE             :oc2_error_type              <= wdata[31:0];  


            `OC3_PRIORITY1              :oc3_Priority1               <= wdata[7:0 ];
            `OC3_CLOCKCLASS             :oc3_clockClass              <= wdata[7:0 ];
            `OC3_CLOCKACCURACY          :oc3_clockAccuracy           <= wdata[7:0 ];
            `OC3_OFFSETSCALEDLOGVARIANCE:oc3_offsetScaledLogVariance <= wdata[15:0];
            `OC3_PRIORITY2              :oc3_Priority2               <= wdata[7:0 ];
            `OC3_CLOCKIDENTITY1         :oc3_clockIdentity[31:0]     <= wdata[31:0];
            `OC3_CLOCKIDENTITY2         :oc3_clockIdentity[63:32]    <= wdata[31:0];
            `OC3_LOGINTERVAL_SYNC       :oc3_LogInterval_sync        <= wdata[7:0 ];
            `OC3_LOGINTERVAL_PDELAY     :oc3_LogInterval_pdelay      <= wdata[7:0 ];
            `OC3_LOGINTERVAL_ANNOUNCE   :oc3_LogInterval_announce    <= wdata[7:0 ];
            `OC3_ERROR_TIME             :oc3_error_time              <= wdata[31:0];
            `OC3_ERROR_TYPE             :oc3_error_type              <= wdata[31:0];

            `PORT0_MODE                 :port0_mode                  <= wdata[1:0 ];
            `PORT1_MODE                 :port1_mode                  <= wdata[1:0 ];
            `PORT2_MODE                 :port2_mode                  <= wdata[1:0 ];
            `PORT3_MODE                 :port3_mode                  <= wdata[1:0 ];

            `CARD_UPLOAD_REN0           :card_upload_ren_0           <= wdata[0]   ;
            `CARD_UPLOAD_REN1           :card_upload_ren_1           <= wdata[0]   ;

            `TEST_START_FLAG            :test_start                  <= wdata[0]   ;
            `TEST_CONFIG_TIME           :config_time                 <= wdata[31:0];
            `TEST_RST                   :test_rst                    <= wdata[0]   ;

        endcase
    end
    else begin
        card_upload_ren_0 <= 1'b0;
        card_upload_ren_1 <= 1'b0;
        test_start        <= 1'b0;
        test_rst          <= 1'b0;
    end
end

//-------------------------AXI-Lite读-------------------------//
always @(posedge clk or negedge LREST) begin
    if (!LREST) 
        rdata <= 32'd0 ;
    else if (ren) begin
        case (raddr)
            //oc状态读取
            `PORT0_UPLOAD_PORT_STATE   :rdata <= port0_upload_port_state    ;
            `PORT0_UPLOAD_SYS_TIME_NS  :rdata <= port0_upload_sys_time_ns   ;
            `PORT0_UPLOAD_OFFSET       :rdata <= port0_upload_offset        ;
            `PORT0_UPLOAD_DELAY        :rdata <= port0_upload_delay         ;
            `PORT1_UPLOAD_PORT_STATE   :rdata <= port1_upload_port_state    ;
            `PORT1_UPLOAD_SYS_TIME_NS  :rdata <= port1_upload_sys_time_ns   ;
            `PORT1_UPLOAD_OFFSET       :rdata <= port1_upload_offset        ;
            `PORT1_UPLOAD_DELAY        :rdata <= port1_upload_delay         ;
            `PORT2_UPLOAD_PORT_STATE   :rdata <= port2_upload_port_state    ;
            `PORT2_UPLOAD_SYS_TIME_NS  :rdata <= port2_upload_sys_time_ns   ;
            `PORT2_UPLOAD_OFFSET       :rdata <= port2_upload_offset        ;
            `PORT2_UPLOAD_DELAY        :rdata <= port2_upload_delay         ;
            `PORT3_UPLOAD_PORT_STATE   :rdata <= port3_upload_port_state    ;
            `PORT3_UPLOAD_SYS_TIME_NS  :rdata <= port3_upload_sys_time_ns   ;
            `PORT3_UPLOAD_OFFSET       :rdata <= port3_upload_offset        ;
            `PORT3_UPLOAD_DELAY        :rdata <= port3_upload_delay         ;
            //时间间隔
            `PORT0_SYNC_INTERVAL       :rdata <= port0_sync_interval        ;
            `PORT0_ANNOUNCE_INTERVAL   :rdata <= port0_announce_interval    ;    
            `PORT0_PDELAY_INTERVAL     :rdata <= port0_pdelay_interval      ;
            `PORT0_PDELAY_RESP_INTERVAL:rdata <= port0_pdelay_resp_interval ;    
            `PORT1_SYNC_INTERVAL       :rdata <= port1_sync_interval        ;
            `PORT1_ANNOUNCE_INTERVAL   :rdata <= port1_announce_interval    ;    
            `PORT1_PDELAY_INTERVAL     :rdata <= port1_pdelay_interval      ;
            `PORT1_PDELAY_RESP_INTERVAL:rdata <= port1_pdelay_resp_interval ;    
            `PORT2_SYNC_INTERVAL       :rdata <= port2_sync_interval        ;
            `PORT2_ANNOUNCE_INTERVAL   :rdata <= port2_announce_interval    ;    
            `PORT2_PDELAY_INTERVAL     :rdata <= port2_pdelay_interval      ;
            `PORT2_PDELAY_RESP_INTERVAL:rdata <= port2_pdelay_resp_interval ;    
            `PORT3_SYNC_INTERVAL       :rdata <= port3_sync_interval        ;
            `PORT3_ANNOUNCE_INTERVAL   :rdata <= port3_announce_interval    ;    
            `PORT3_PDELAY_INTERVAL     :rdata <= port3_pdelay_interval      ;
            `PORT3_PDELAY_RESP_INTERVAL:rdata <= port3_pdelay_resp_interval ;    

            `SYNC_BOARD1_REGISTER2    :rdata <= {31'd0,sync_register2}      ;
            `SYNC_BOARD1_REGISTER4    :rdata <= {31'd0,sync_register4}      ;
            `TESTSYNC_BOARD1_REGISTER2:rdata <= {31'd0,Test_sync_register2} ;
            `TESTSYNC_BOARD1_REGISTER4:rdata <= {31'd0,Test_sync_register4} ;
            `BOARD_ADDRESS_INFO       :rdata <= ga_data_in                  ;
            `CARD_UPLOAD_FLAG0        :rdata <= {31'b0, card_upload_flag_0} ;
            `CARD_UPLOAD_FLAG1        :rdata <= {31'b0, card_upload_flag_1} ;
            `MONITIOR_ERROR           :rdata <= monitior_error              ;
            default: rdata <= 32'hdeadbeef;
        endcase
    end
    else 
        rdata <= rdata ;
end

always @(posedge clk or negedge LREST) begin
    if (!LREST) 
        rvalid <= 1'b0;
    else if (ren) 
        rvalid <= 1'b1;
    else
        rvalid <= 1'b0;
end


endmodule
