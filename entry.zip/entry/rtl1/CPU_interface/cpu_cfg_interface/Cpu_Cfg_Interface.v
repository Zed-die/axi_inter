`timescale 1ns/100ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: WQJ
// 
// Create Date: 2021/11/26 23:35:08
// Design Name: 
// Module Name: CPU_CFG_INTERFACE
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

`include "../../../include/cpu_define.v"

module CPU_CFG_INTERFACE(

    input                LREST           ,
    input                clk             ,
    //写
    input                wen_sys         ,
    input   [31:0]       waddr_sys       ,
    input   [31:0]       wdata_sys       ,
    //读        
    input                ren_sys         ,
    input   [31:0]       raddr_sys       ,
    output  [31:0]       rdata_sys       ,
    output               rvalid_sys      ,   
    
    //板卡同步
    output               sync_register1      ,
    input                sync_register2      ,
    output               sync_register3      ,
    input                sync_register4      ,
    output               Test_sync_register1 ,
    input                Test_sync_register2 ,
    output               Test_sync_register3 ,
    input                Test_sync_register4 ,

    //端口模式
    output      [1:0]    port0_mode          ,
    output      [1:0]    port1_mode          ,
    output      [1:0]    port2_mode          ,
    output      [1:0]    port3_mode          ,
    input       [31:0]   ga_data_in          ,

    //oc端配置
    output      [7:0 ]   oc0_Priority1                ,
    output      [7:0 ]   oc0_clockClass               ,
    output      [7:0 ]   oc0_clockAccuracy            ,
    output      [15:0]   oc0_offsetScaledLogVariance  ,
    output      [7:0 ]   oc0_Priority2                ,
    output      [63:0]   oc0_clockIdentity            ,
    output      [7:0]    oc0_LogInterval_sync         ,
    output      [7:0]    oc0_LogInterval_pdelay       ,
    output      [7:0]    oc0_LogInterval_announce     ,
    output      [31:0]   oc0_error_time               ,
    output      [31:0]   oc0_error_type               ,

    output      [7:0 ]   oc1_Priority1                ,
    output      [7:0 ]   oc1_clockClass               ,
    output      [7:0 ]   oc1_clockAccuracy            ,
    output      [15:0]   oc1_offsetScaledLogVariance  ,
    output      [7:0 ]   oc1_Priority2                ,
    output      [63:0]   oc1_clockIdentity            ,
    output      [7:0]    oc1_LogInterval_sync         ,
    output      [7:0]    oc1_LogInterval_pdelay       ,
    output      [7:0]    oc1_LogInterval_announce     ,
    output      [31:0]   oc1_error_time               ,
    output      [31:0]   oc1_error_type               ,

    output      [7:0 ]   oc2_Priority1                ,
    output      [7:0 ]   oc2_clockClass               ,
    output      [7:0 ]   oc2_clockAccuracy            ,
    output      [15:0]   oc2_offsetScaledLogVariance  ,
    output      [7:0 ]   oc2_Priority2                ,
    output      [63:0]   oc2_clockIdentity            ,
    output      [7:0]    oc2_LogInterval_sync         ,
    output      [7:0]    oc2_LogInterval_pdelay       ,
    output      [7:0]    oc2_LogInterval_announce     ,
    output      [31:0]   oc2_error_time               ,
    output      [31:0]   oc2_error_type               ,

    output      [7:0 ]   oc3_Priority1                ,
    output      [7:0 ]   oc3_clockClass               ,
    output      [7:0 ]   oc3_clockAccuracy            ,
    output      [15:0]   oc3_offsetScaledLogVariance  ,
    output      [7:0 ]   oc3_Priority2                ,
    output      [63:0]   oc3_clockIdentity            ,
    output      [7:0]    oc3_LogInterval_sync         ,
    output      [7:0]    oc3_LogInterval_pdelay       ,
    output      [7:0]    oc3_LogInterval_announce     ,
    output      [31:0]   oc3_error_time               ,
    output      [31:0]   oc3_error_type               ,

    //上报OC寄存器
    input   [31:0]       port0_upload_port_state  ,
    input   [31:0]       port0_upload_sys_time_ns ,
    input   [31:0]       port0_upload_offset      ,
    input   [31:0]       port0_upload_delay       ,
        
    input   [31:0]       port1_upload_port_state  ,
    input   [31:0]       port1_upload_sys_time_ns ,
    input   [31:0]       port1_upload_offset      ,
    input   [31:0]       port1_upload_delay       ,
       
    input   [31:0]       port2_upload_port_state  ,      
    input   [31:0]       port2_upload_sys_time_ns ,      
    input   [31:0]       port2_upload_offset      ,      
    input   [31:0]       port2_upload_delay       , 
       
    input   [31:0]       port3_upload_port_state  , 
    input   [31:0]       port3_upload_sys_time_ns , 
    input   [31:0]       port3_upload_offset      , 
    input   [31:0]       port3_upload_delay       ,

    //上报帧间隔
    input   [31:0]       port0_sync_interval       ,
    input   [31:0]       port0_announce_interval   ,
    input   [31:0]       port0_pdelay_interval     ,
    input   [31:0]       port0_pdelay_resp_interval,

    input   [31:0]       port1_sync_interval       ,
    input   [31:0]       port1_announce_interval   ,
    input   [31:0]       port1_pdelay_interval     ,
    input   [31:0]       port1_pdelay_resp_interval,

    input   [31:0]       port2_sync_interval       ,
    input   [31:0]       port2_announce_interval   ,
    input   [31:0]       port2_pdelay_interval     ,
    input   [31:0]       port2_pdelay_resp_interval,

    input   [31:0]       port3_sync_interval       ,
    input   [31:0]       port3_announce_interval   ,
    input   [31:0]       port3_pdelay_interval     ,
    input   [31:0]       port3_pdelay_resp_interval,

    //错帧配表
    output               port0_wen  ,
    output      [31:0]   port0_wdata,  
    output               port1_wen  ,
    output      [31:0]   port1_wdata,    
    output               port2_wen  ,
    output      [31:0]   port2_wdata,        
    output               port3_wen  ,
    output      [31:0]   port3_wdata,

    //测试时长及启动标识
    output               test_start ,
    output      [31:0]   config_time,
    output               test_rst   ,


    //上报主机交互
    output               card_upload_ren_0,
    input                card_upload_flag_0,

    output               card_upload_ren_1,
    input                card_upload_flag_1,

    input  [31:0]        monitior_error
);

//配表信号分流
reg          cfg_space_wen    ;
reg  [31:0]  cfg_space_waddr  ;
reg  [31:0]  cfg_space_wdata  ;
reg          frame_table_wen  ;
reg  [31:0]  frame_table_waddr;
reg  [31:0]  frame_table_wdata;


always @(posedge clk or negedge LREST) begin
    if (!LREST) begin
        cfg_space_wen     <= 1'd0 ; 
        cfg_space_waddr   <= 32'd0;
        cfg_space_wdata   <= 32'd0;
        frame_table_wen   <= 1'd0 ;
        frame_table_waddr <= 32'd0;
        frame_table_wdata <= 32'd0;
    end    
    else if (wen_sys) begin
        if (waddr_sys == `TEST_CONFIG_TIME) begin
            frame_table_wen   <= 1'd0 ;
            frame_table_waddr <= 32'd0;
            frame_table_wdata <= 32'd0;
            cfg_space_wen     <= 1'b1 ; 
            cfg_space_waddr   <= waddr_sys;
            cfg_space_wdata   <= wdata_sys;
        end
        else if (waddr_sys[19:16] >= 4'h0 && waddr_sys[19:16] <= 4'h3)begin
            frame_table_wen   <= 1'b1; 
            frame_table_waddr <= waddr_sys;
            frame_table_wdata <= wdata_sys;
            cfg_space_wen     <= 1'd0;
            cfg_space_waddr   <= 32'd0;
            cfg_space_wdata   <= 32'd0;
        end
        else begin
            frame_table_wen   <= 1'd0 ;
            frame_table_waddr <= 32'd0;
            frame_table_wdata <= 32'd0;
            cfg_space_wen     <= 1'b1 ; 
            cfg_space_waddr   <= waddr_sys;
            cfg_space_wdata   <= wdata_sys;
        end
    end
    else begin
        cfg_space_wen     <= 1'd0 ; 
        cfg_space_waddr   <= 32'd0;
        cfg_space_wdata   <= 32'd0;
        frame_table_wen   <= 1'd0 ;
        frame_table_waddr <= 32'd0;
        frame_table_wdata <= 32'd0;
    end
end

CFG_SPACE U_CFG_SPACE(
    .LREST                                  (LREST                      ),
    .clk                                    (clk                        ),
    //写            
    .wen                                    (cfg_space_wen              ),
    .waddr                                  (cfg_space_waddr            ),
    .wdata                                  (cfg_space_wdata            ),
    //读                
    .ren                                    (ren_sys                    ),
    .raddr                                  (raddr_sys                  ),
    .rdata                                  (rdata_sys                  ),
    .rvalid                                 (rvalid_sys                 ),
    .sync_register1                         (sync_register1             ),
    .sync_register2                         (sync_register2             ),
    .sync_register3                         (sync_register3             ),
    .sync_register4                         (sync_register4             ),
    .Test_sync_register1                    (Test_sync_register1        ),
    .Test_sync_register2                    (Test_sync_register2        ),
    .Test_sync_register3                    (Test_sync_register3        ),
    .Test_sync_register4                    (Test_sync_register4        ),
    .port0_mode                             (port0_mode                 ),
    .port1_mode                             (port1_mode                 ),
    .port2_mode                             (port2_mode                 ),
    .port3_mode                             (port3_mode                 ),
    .ga_data_in                             (ga_data_in                 ),

    .oc0_Priority1                          (oc0_Priority1              ), 
    .oc0_clockClass                         (oc0_clockClass             ), 
    .oc0_clockAccuracy                      (oc0_clockAccuracy          ), 
    .oc0_offsetScaledLogVariance            (oc0_offsetScaledLogVariance), 
    .oc0_Priority2                          (oc0_Priority2              ), 
    .oc0_clockIdentity                      (oc0_clockIdentity          ), 
    .oc0_LogInterval_sync                   (oc0_LogInterval_sync       ), 
    .oc0_LogInterval_pdelay                 (oc0_LogInterval_pdelay     ), 
    .oc0_LogInterval_announce               (oc0_LogInterval_announce   ), 
    .oc0_error_time                         (oc0_error_time             ),
    .oc0_error_type                         (oc0_error_type             ),

    .oc1_Priority1                          (oc1_Priority1              ), 
    .oc1_clockClass                         (oc1_clockClass             ), 
    .oc1_clockAccuracy                      (oc1_clockAccuracy          ), 
    .oc1_offsetScaledLogVariance            (oc1_offsetScaledLogVariance), 
    .oc1_Priority2                          (oc1_Priority2              ), 
    .oc1_clockIdentity                      (oc1_clockIdentity          ), 
    .oc1_LogInterval_sync                   (oc1_LogInterval_sync       ), 
    .oc1_LogInterval_pdelay                 (oc1_LogInterval_pdelay     ), 
    .oc1_LogInterval_announce               (oc1_LogInterval_announce   ), 
    .oc1_error_time                         (oc1_error_time             ),
    .oc1_error_type                         (oc1_error_type             ),

    .oc2_Priority1                          (oc2_Priority1              ), 
    .oc2_clockClass                         (oc2_clockClass             ), 
    .oc2_clockAccuracy                      (oc2_clockAccuracy          ), 
    .oc2_offsetScaledLogVariance            (oc2_offsetScaledLogVariance), 
    .oc2_Priority2                          (oc2_Priority2              ), 
    .oc2_clockIdentity                      (oc2_clockIdentity          ), 
    .oc2_LogInterval_sync                   (oc2_LogInterval_sync       ), 
    .oc2_LogInterval_pdelay                 (oc2_LogInterval_pdelay     ), 
    .oc2_LogInterval_announce               (oc2_LogInterval_announce   ),
    .oc2_error_time                         (oc2_error_time             ),
    .oc2_error_type                         (oc2_error_type             ), 

    .oc3_Priority1                          (oc3_Priority1              ), 
    .oc3_clockClass                         (oc3_clockClass             ), 
    .oc3_clockAccuracy                      (oc3_clockAccuracy          ), 
    .oc3_offsetScaledLogVariance            (oc3_offsetScaledLogVariance), 
    .oc3_Priority2                          (oc3_Priority2              ), 
    .oc3_clockIdentity                      (oc3_clockIdentity          ), 
    .oc3_LogInterval_sync                   (oc3_LogInterval_sync       ), 
    .oc3_LogInterval_pdelay                 (oc3_LogInterval_pdelay     ), 
    .oc3_LogInterval_announce               (oc3_LogInterval_announce   ), 
    .oc3_error_time                         (oc3_error_time             ),
    .oc3_error_type                         (oc3_error_type             ),

    //上报OC端寄存器            
    .port0_upload_port_state                (port0_upload_port_state    ), 
    .port0_upload_sys_time_ns               (port0_upload_sys_time_ns   ), 
    .port0_upload_offset                    (port0_upload_offset        ), 
    .port0_upload_delay                     (port0_upload_delay         ), 
    .port1_upload_port_state                (port1_upload_port_state    ), 
    .port1_upload_sys_time_ns               (port1_upload_sys_time_ns   ), 
    .port1_upload_offset                    (port1_upload_offset        ), 
    .port1_upload_delay                     (port1_upload_delay         ), 
    .port2_upload_port_state                (port2_upload_port_state    ), 
    .port2_upload_sys_time_ns               (port2_upload_sys_time_ns   ), 
    .port2_upload_offset                    (port2_upload_offset        ), 
    .port2_upload_delay                     (port2_upload_delay         ), 
    .port3_upload_port_state                (port3_upload_port_state    ), 
    .port3_upload_sys_time_ns               (port3_upload_sys_time_ns   ), 
    .port3_upload_offset                    (port3_upload_offset        ), 
    .port3_upload_delay                     (port3_upload_delay         ),

    .test_start                             (test_start                 ),
    .config_time                            (config_time                ),
    .test_rst                               (test_rst                   ),             

    //上报帧间隔            
    .port0_sync_interval                    (port0_sync_interval        ),
    .port0_announce_interval                (port0_announce_interval    ),
    .port0_pdelay_interval                  (port0_pdelay_interval      ),
    .port0_pdelay_resp_interval             (port0_pdelay_resp_interval ),

    .port1_sync_interval                    (port1_sync_interval        ),
    .port1_announce_interval                (port1_announce_interval    ),
    .port1_pdelay_interval                  (port1_pdelay_interval      ),
    .port1_pdelay_resp_interval             (port1_pdelay_resp_interval ),

    .port2_sync_interval                    (port2_sync_interval        ),
    .port2_announce_interval                (port2_announce_interval    ),
    .port2_pdelay_interval                  (port2_pdelay_interval      ),
    .port2_pdelay_resp_interval             (port2_pdelay_resp_interval ),

    .port3_sync_interval                    (port3_sync_interval        ),
    .port3_announce_interval                (port3_announce_interval    ),
    .port3_pdelay_interval                  (port3_pdelay_interval      ),
    .port3_pdelay_resp_interval             (port3_pdelay_resp_interval ),

    .card_upload_ren_0                      (card_upload_ren_0          ),  
    .card_upload_flag_0                     (card_upload_flag_0         ),

    .card_upload_ren_1                      (card_upload_ren_1          ),
    .card_upload_flag_1                     (card_upload_flag_1         ),
    
    .monitior_error                         (monitior_error             )
);

FRAME_TABLE U_FRAME_TABLE(
    .LREST                                  (LREST                      ),
    .clk                                    (clk                        ),
    .wen                                    (frame_table_wen            ),
    .waddr                                  (frame_table_waddr          ),
    .wdata                                  (frame_table_wdata          ),
    .port0_wen                              (port0_wen                  ),
    .port0_wdata                            (port0_wdata                ),
    .port1_wen                              (port1_wen                  ),
    .port1_wdata                            (port1_wdata                ),
    .port2_wen                              (port2_wen                  ),
    .port2_wdata                            (port2_wdata                ),
    .port3_wen                              (port3_wen                  ),
    .port3_wdata                            (port3_wdata                )
);              

endmodule
