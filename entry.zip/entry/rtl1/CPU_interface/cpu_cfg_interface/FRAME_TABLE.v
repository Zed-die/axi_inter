`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: why
// 
// Create Date: 2025/9/4 10:19:49
// Design Name: 
// Module Name: SYNC_TABLE_CFG
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

`include "../../../include/cpu_define.v"
module  FRAME_TABLE(
    input            clk   ,
    input            LREST ,
    //写表
    input            wen   ,
    input   [31:0]   waddr ,
    input   [31:0]   wdata ,

    output  reg           port0_wen  ,
    output  reg  [31:0]   port0_wdata,  
    output  reg           port1_wen  ,
    output  reg  [31:0]   port1_wdata,    
    output  reg           port2_wen  ,
    output  reg  [31:0]   port2_wdata,        
    output  reg           port3_wen  ,
    output  reg  [31:0]   port3_wdata   

);

always@(posedge clk or negedge LREST)begin
    if(~LREST)begin
        port0_wen    <= 1'b0 ;
        port0_wdata  <= 32'b0;
        port1_wen    <= 1'b0 ;
        port1_wdata  <= 32'b0;
        port2_wen    <= 1'b0 ;
        port2_wdata  <= 32'b0;
        port3_wen    <= 1'b0 ;
        port3_wdata  <= 32'b0;
    end
    else if(wen)begin 
        case(waddr[19:16])
            4'h0:begin
                port0_wen    <= wen  ;
                port0_wdata  <= wdata;
                port1_wen    <= 1'b0 ;
                port1_wdata  <= 32'b0;
                port2_wen    <= 1'b0 ;
                port2_wdata  <= 32'b0;
                port3_wen    <= 1'b0 ;
                port3_wdata  <= 32'b0;
            end
            4'h1:begin
                port0_wen    <= 1'b0 ;
                port0_wdata  <= 32'b0;
                port1_wen    <= wen  ;
                port1_wdata  <= wdata;
                port2_wen    <= 1'b0 ;
                port2_wdata  <= 32'b0;
                port3_wen    <= 1'b0 ;
                port3_wdata  <= 32'b0;
            end
            4'h2:begin
                port0_wen    <= 1'b0 ;
                port0_wdata  <= 32'b0;
                port1_wen    <= 1'b0 ;
                port1_wdata  <= 32'b0;
                port2_wen    <= wen  ;
                port2_wdata  <= wdata;
                port3_wen    <= 1'b0 ;
                port3_wdata  <= 32'b0;
            end
            4'h3:begin
                port0_wen    <= 1'b0 ;
                port0_wdata  <= 32'b0;
                port1_wen    <= 1'b0 ;
                port1_wdata  <= 32'b0;
                port2_wen    <= 1'b0 ;
                port2_wdata  <= 32'b0;
                port3_wen    <= wen  ;
                port3_wdata  <= wdata;
            end
            default:begin
                port0_wen    <= 1'b0 ;
                port0_wdata  <= 32'b0;
                port1_wen    <= 1'b0 ;
                port1_wdata  <= 32'b0;
                port2_wen    <= 1'b0 ;
                port2_wdata  <= 32'b0;
                port3_wen    <= 1'b0 ;
                port3_wdata  <= 32'b0;
            end
        endcase
    end
    else begin
        port0_wen    <= 1'b0 ;
        port0_wdata  <= 32'b0;
        port1_wen    <= 1'b0 ;
        port1_wdata  <= 32'b0;
        port2_wen    <= 1'b0 ;
        port2_wdata  <= 32'b0;
        port3_wen    <= 1'b0 ;
        port3_wdata  <= 32'b0;
    end
end

endmodule
