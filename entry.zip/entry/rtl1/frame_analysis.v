`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: wanghaoyu
// 
// Create Date: 2025/04/23 22:36:35
// Design Name: 
// Module Name: frame_analysis
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


 module frame_analysis(
            input           clk    ,
            input           rst_n  ,
            input   [7:0]   data_i ,
            input           valid_i,

            output          pdelay_valid                  ,
            output  [79:0]  pdelay_portIdentity           ,
            //BMCA
            output  [79:0]  Message_sourcePortIdentity     ,
            output  [15:0]  Message_currentUtcOffset       ,
            output  [7:0]   Message_Priority1              ,         
            output  [7:0]   Message_clockClass             ,        
            output  [7:0]   Message_clockAccuracy          ,     
            output  [15:0]  Message_offsetScaledLogVariance,   
            output  [7:0]   Message_Priority2              ,        
            output  [63:0]  Message_clockIdentity          ,  
            output  [15:0]  Message_stepsRemoved           ,
            output  [7:0]   Message_timeSource             , 
            output          Message_Announce_valid         ,

            //接收时间戳标记,时间戳提取
            output  [79:0]  Pdelay_Resp_tx_ts              ,  //对端发送Presp的时间点，由Presp_follow帧中提取
            output          Pdelay_Resp_tx_ts_valid        , 
    
            output  [79:0]  Pdelay_opposite_rx_ts          ,  //对端接收Pdelay帧的时间点，由Presp帧中提取
            output          Pdelay_opposite_rx_ts_valid    ,

            output  [63:0]  onestep_Presp_CorrectionField      , 
            output          onestep_Presp_CorrectionField_valid,

            output  [79:0]  onestep_sync_timestamp             ,
            output  [63:0]  onestep_sync_CorrectionField       ,
            output          onestep_sync_timestamp_valid       ,

            output  [79:0]  twostep_sync_timestamp             ,  //对端发送Sync帧的时间点，由Sync_follow帧中提取
            output  [63:0]  twostep_sync_CorrectionField       ,  //对端发送Sync_follow中的修正域，由Sync_follow帧中提取
            output          twostep_sync_timestamp_valid       


          
);

parameter IDLE         = 10'b00_0000_0001;
parameter FRAME_START  = 10'b00_0000_0010;
parameter MESSAGE_TYPE = 10'b00_0000_0100;
parameter FRAME_SELECT = 10'b00_0000_1000;
parameter SYNC         = 10'b00_0001_0000;
parameter PDELAY       = 10'b00_0010_0000;
parameter PRESP        = 10'b00_0100_0000;
parameter PRESP_FOLLOW = 10'b00_1000_0000;
parameter SYNC_FOLLOW  = 10'b01_0000_0000;
parameter ANNOUNCE     = 10'b10_0000_0000;

         
reg [9:0] cstate, nstate;

reg [7:0] cnt;
reg [7:0] data_ff0;
reg [3:0] frame_type;


reg  [7:0] Sync_data_reg ;
reg        Sync_valid_reg;

reg  [7:0] Pdelay_data_reg ;
reg        Pdelay_valid_reg;

reg  [7:0] Presp_data_reg ;
reg        Presp_valid_reg;

reg  [7:0] Sync_follow_data_reg ;
reg        Sync_follow_valid_reg;

reg  [7:0] Presp_follow_data_reg ;
reg        Presp_follow_valid_reg;

reg  [7:0] Announce_data_reg ;
reg        Announce_valid_reg;

reg valid_i_ff;

assign onestep_Presp_CorrectionField_valid = Pdelay_opposite_rx_ts_valid;

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        data_ff0 <= 8'b0;
        valid_i_ff <= 1'b0;
    end
    else begin
        data_ff0 <= data_i;
        valid_i_ff<=valid_i;
    end
end

//帧解析
always @(posedge clk or negedge rst_n) begin
    if(!rst_n) 
        cstate <= IDLE;
    else 
        cstate <= nstate;
end

always@(*)begin
    case(cstate)
    IDLE:
    begin
        if(data_i == 8'hd5 && data_ff0 == 8'h55 && valid_i)
            nstate = FRAME_START;
        else
            nstate = IDLE;
    end

    FRAME_START:
    begin
        if(cnt == 8'd14 && valid_i)
            nstate = MESSAGE_TYPE;
        else
            nstate = FRAME_START;
    end

    MESSAGE_TYPE:nstate = FRAME_SELECT;

    FRAME_SELECT:
    begin
        if(frame_type == 4'h0 && valid_i)
            nstate = SYNC;
        else if(frame_type == 4'h2 && valid_i)
            nstate = PDELAY;
        else if(frame_type == 4'h3 && valid_i)
            nstate = PRESP;
        else if(frame_type == 4'ha && valid_i)
            nstate = PRESP_FOLLOW;
        else if(frame_type == 4'h8 && valid_i)
            nstate = SYNC_FOLLOW;
        else if(frame_type == 4'hb && valid_i)
            nstate = ANNOUNCE;
        else
            nstate = IDLE;
    end

    SYNC:
    begin
        if(!valid_i_ff)
            nstate = IDLE;
        else
            nstate = SYNC;
    end

    PDELAY:
    begin
        if(!valid_i_ff)
            nstate = IDLE;
        else
            nstate = PDELAY;
    end

    PRESP:
    begin
        if(!valid_i_ff)
            nstate = IDLE;
        else
            nstate = PRESP;
    end

    PRESP_FOLLOW:
    begin
        if(!valid_i_ff)
            nstate = IDLE;
        else
            nstate = PRESP_FOLLOW;
    end

    SYNC_FOLLOW:
    begin
        if(!valid_i_ff)
            nstate = IDLE;
        else
            nstate = SYNC_FOLLOW;
    end

    ANNOUNCE:
    begin
        if(!valid_i_ff)
            nstate = IDLE;
        else
            nstate = ANNOUNCE;
    end
    default : nstate = IDLE;
    endcase 
end 


always @(posedge clk or negedge rst_n) begin
    if(!rst_n) 
        frame_type <= 4'b0;
    else if(cstate==MESSAGE_TYPE)begin
        frame_type <= data_i[3:0];
    end
    else
        frame_type <= 4'b0;
end

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        Sync_data_reg           <=     8'b0;
        Sync_valid_reg          <=     1'b0;
        Pdelay_data_reg         <=     8'b0;
        Pdelay_valid_reg        <=     1'b0;
        Presp_data_reg          <=     8'b0;
        Presp_valid_reg         <=     1'b0;
        Sync_follow_data_reg    <=     8'b0;
        Sync_follow_valid_reg   <=     1'b0;
        Presp_follow_data_reg   <=     8'b0;
        Presp_follow_valid_reg  <=     1'b0;
        Announce_data_reg       <=     8'b0;
        Announce_valid_reg      <=     1'b0;
    end
    else if(cstate==SYNC)begin
        Sync_data_reg <= data_i;
        Sync_valid_reg<= valid_i;
    end
    else if(cstate==PDELAY)begin
        Pdelay_data_reg <= data_i;
        Pdelay_valid_reg<= valid_i;
    end
    else if(cstate==PRESP)begin
        Presp_data_reg <= data_i;
        Presp_valid_reg<= valid_i;
    end
    else if(cstate==SYNC_FOLLOW)begin
        Sync_follow_data_reg <= data_i;
        Sync_follow_valid_reg<= valid_i;
    end
    else if(cstate==PRESP_FOLLOW)begin
        Presp_follow_data_reg <= data_i;
        Presp_follow_valid_reg<= valid_i;
    end
    else if(cstate==ANNOUNCE)begin
        Announce_data_reg <= data_i;
        Announce_valid_reg<= valid_i;
    end
    else begin
        Sync_data_reg          <= 8'b0;
        Sync_valid_reg         <= 1'b0;
        Pdelay_data_reg        <= 8'b0;
        Pdelay_valid_reg       <= 1'b0;
        Presp_data_reg         <= 8'b0;
        Presp_valid_reg        <= 1'b0;
        Sync_follow_data_reg   <= 8'b0;
        Sync_follow_valid_reg  <= 1'b0;
        Presp_follow_data_reg  <= 8'b0;
        Presp_follow_valid_reg <= 1'b0;
        Announce_data_reg      <= 8'b0;
        Announce_valid_reg     <= 1'b0;
    end
end


always @(posedge clk or negedge rst_n) begin
    if(!rst_n) 
        cnt <= 1'b0;
    else if(nstate != IDLE && valid_i)
        cnt <= cnt + 1'b1;
    else 
        cnt <= 1'b0;
end


Sync_analysis U_Sync_analysis(
        .clk                                 (clk                                ),          
        .rst_n                               (rst_n                              ),   
        .data_i                              (Sync_data_reg                      ),
        .valid_i                             (Sync_valid_reg                     ),
        .MsgLength                           (                                   ),
        .DomainNumber                        (                                   ),
        .FlagField                           (                                   ),
        .CorrectionField                     (onestep_sync_CorrectionField       ),
        .sourcePortIdentity                  (                                   ),
        .SequenceID                          (                                   ),
        .ControlField                        (                                   ),
        .logMessage                          (                                   ),
        .timestamp_tx_Sync                   (onestep_sync_timestamp             ),
        .message_valid                       (onestep_sync_timestamp_valid       )
);

Pdelay_analysis U_Pdelay_analysis( 
        .clk                                 (clk                                ),          
        .rst_n                               (rst_n                              ),   
        .data_i                              (Pdelay_data_reg                    ),
        .valid_i                             (Pdelay_valid_reg                   ),
        .MsgLength                           (                                   ),
        .DomainNumber                        (                                   ),
        .FlagField                           (                                   ),
        .CorrectionField                     (                                   ),
        .sourcePortIdentity                  (pdelay_portIdentity                ),
        .SequenceID                          (                                   ),
        .ControlField                        (                                   ),
        .logMessage                          (                                   ),
        .message_valid                       (pdelay_valid                       )
);

Presp_analysis U_Presp_analysis(
        .clk                                 (clk                                ),          
        .rst_n                               (rst_n                              ),   
        .data_i                              (Presp_data_reg                     ),
        .valid_i                             (Presp_valid_reg                    ),
        .MsgLength                           (                                   ),
        .DomainNumber                        (                                   ),
        .FlagField                           (                                   ),
        .CorrectionField                     (onestep_Presp_CorrectionField      ),
        .sourcePortIdentity                  (                                   ),
        .SequenceID                          (                                   ),
        .ControlField                        (                                   ),
        .logMessage                          (                                   ),
        .Pdelay_RX_timestamp                 (Pdelay_opposite_rx_ts              ),
        .Pdelay_PortIdentity                 (                                   ),
        .message_valid                       (Pdelay_opposite_rx_ts_valid        )
);

Sync_follow_analysis U_Sync_follow_analysis(
        .clk                                 (clk                                ),          
        .rst_n                               (rst_n                              ),   
        .data_i                              (Sync_follow_data_reg               ),
        .valid_i                             (Sync_follow_valid_reg              ),
        .MsgLength                           (                                   ),
        .DomainNumber                        (                                   ),
        .FlagField                           (                                   ),
        .CorrectionField                     (twostep_sync_CorrectionField       ),
        .sourcePortIdentity                  (                                   ),
        .SequenceID                          (                                   ),
        .ControlField                        (                                   ),
        .logMessage                          (                                   ),
        .Sync_TX_timesamp                    (twostep_sync_timestamp             ),
        .message_valid                       (twostep_sync_timestamp_valid       )
);                              

 
Presp_follow_analysis U_Presp_follow_analysis(
        .clk                                 (clk                                ),          
        .rst_n                               (rst_n                              ),   
        .data_i                              (Presp_follow_data_reg              ),
        .valid_i                             (Presp_follow_valid_reg             ),
        .MsgLength                           (                                   ),
        .DomainNumber                        (                                   ),
        .FlagField                           (                                   ),
        .CorrectionField                     (                                   ),
        .sourcePortIdentity                  (                                   ),
        .SequenceID                          (                                   ),
        .ControlField                        (                                   ),
        .logMessage                          (                                   ),
        .Pdelay_PortIdentity                 (                                   ),
        .Presp_TX_timestamp                  (Pdelay_Resp_tx_ts                  ),
        .message_valid                       (Pdelay_Resp_tx_ts_valid            )
);

Announce_analysis U_Announce_analysis(
        .clk                                 (clk                                ),          
        .rst_n                               (rst_n                              ),   
        .data_i                              (Announce_data_reg                  ),
        .valid_i                             (Announce_valid_reg                 ),
        .MsgLength                           (                                   ),
        .DomainNumber                        (                                   ),
        .FlagField                           (                                   ),
        .CorrectionField                     (                                   ),
        .sourcePortIdentity                  (Message_sourcePortIdentity         ),
        .SequenceID                          (                                   ),
        .ControlField                        (                                   ),
        .logMessage                          (                                   ),
        .Message_currentUtcOffset            (Message_currentUtcOffset           ),
        .Message_Priority1                   (Message_Priority1                  ),
        .Message_clockClass                  (Message_clockClass                 ),
        .Message_clockAccuracy               (Message_clockAccuracy              ),
        .Message_offsetScaledLogVariance     (Message_offsetScaledLogVariance    ),
        .Message_Priority2                   (Message_Priority2                  ),
        .Message_clockIdentity               (Message_clockIdentity              ),
        .Message_stepsRemoved                (Message_stepsRemoved               ),
        .Message_timeSource                  (Message_timeSource                 ),
        .message_valid                       (Message_Announce_valid             )
        
);

endmodule
