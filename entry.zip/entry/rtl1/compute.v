// **************************************************************
// COPYRIGHT(c)2019, Xidian University
// All rights reserved.
//
// IP LIB INDEX :  
// IP Name      : Di_Xintao    
// File name    :  
// Module name  : 
// Full name    :  
//
// Author       :  
// Email        : 158573425@qq.com 
// Data         : 
// Version      : 
// 
// Abstract     : 
// Called by    :  
// 
// Modification history
// -----------------------------------------------------------------
// 
// 
//
// *****************************************************************

// *******************
// TIMESCALE
// ******************* 
`timescale 1ns/1ps 

// *******************
// INFORMATION
// *******************
module compute (
                input          clk              ,
                input          rst              ,
                input          two_step_flag    ,
                input  [63:0]  onestep_Presp_CorrectionField      , 
                input          onestep_Presp_CorrectionField_valid,
   
                //时间戳输入
                input          timestamp_tx_Pdelay_valid_cdc,
                input          timestamp_rx_Presp_valid_cdc,

                input  [79:0]  Pdelay_opposite_rx_ts,         //对端接收Pdelay帧的时间点，由Presp帧中提取，用于计算时延
                input          Pdelay_opposite_rx_ts_valid,

                input  [79:0]  Pdelay_Resp_tx_ts,             //对端发送Presp帧的时间点，用于计算时延
                input          Pdelay_Resp_tx_ts_valid,

                input  [79:0]  Sync_tx_ts,
                input  [63:0]  Sync_correction_field,
                input          Sync_ts_valid,
    
                  
                input          timestamp_rx_Sync_valid_cdc,    //本地接收Sync帧的时间点，用于时钟同步

                input  [79:0]  timer,

                output      reg [79:0]  offset ,
                output      reg         valid ,
                output      reg         sign,

                input       [79:0]      sys_time,
                output      [79:0]      link_delay_out,
                output                  link_delay_valid_out

    );


reg [79:0] a;
reg [79:0] b;
reg [79:0] c;
reg      link_delay_compute_ff1 ;
reg      link_delay_compute_ff2 ;
reg [79:0] d ;
reg        d_valid ;

reg link_delay_compute ;
reg [79:0] t1;
reg [79:0] t2;
reg [79:0] t3;
reg [79:0] t4;
reg [63:0] t3_t2;
reg [79:0] link_delay_value;
reg [79:0] Sync_rx_ts_value;
reg link_flag;



reg [79:0]  link_delay;
reg         link_delay_valid;


assign  link_delay_out        = link_delay;
assign  link_delay_valid_out  = link_delay_valid;


//WIRES
//*********************
//INSTANTCE MODULE
//*********************
//计算link_delay
parameter IDLE              = 6'b00_0001;
parameter PDELAY_TX         = 6'b00_0010;
parameter PRESP_RX          = 6'b00_0100;
parameter PRESP_TS_RX       = 6'b00_1000;
parameter PRESP_FOLLOW_RX   = 6'b01_0000;
parameter FINISH            = 6'b10_0000;

reg [5:0] cstate,nstate;

always @(posedge clk or posedge rst) begin
    if (rst == 1'b1) begin
        cstate <= IDLE;
    end else begin
        cstate <= nstate;
    end
end

always @(*) begin   
    case (cstate)
        IDLE: begin
        if (timestamp_tx_Pdelay_valid_cdc) 
                nstate = PDELAY_TX;
            else 
                nstate = IDLE;
        end
        PDELAY_TX: begin
            if (timestamp_rx_Presp_valid_cdc) 
                nstate = PRESP_RX;
            else 
                nstate = PDELAY_TX;
        end

        PRESP_RX: begin
            if (Pdelay_opposite_rx_ts_valid && two_step_flag) 
                nstate = PRESP_TS_RX;
            else if (Pdelay_opposite_rx_ts_valid && !two_step_flag) 
                nstate = FINISH;
            else if (timestamp_tx_Pdelay_valid_cdc) 
                nstate = PDELAY_TX;
            else 
                nstate = PRESP_RX;
        end

        PRESP_TS_RX: begin
            if (Pdelay_Resp_tx_ts_valid) 
                nstate = PRESP_FOLLOW_RX;
            else if (timestamp_tx_Pdelay_valid_cdc) 
                nstate = PDELAY_TX;
            else 
                nstate = PRESP_TS_RX;
        end

        PRESP_FOLLOW_RX: 
            nstate = FINISH;

        FINISH: begin
            nstate = IDLE;
        end
        
        default: begin
            nstate = IDLE;
        end
    endcase
end

always @(posedge clk or posedge rst) begin
    if (rst == 1'b1) begin
        t1<=80'b0;
        t2<=80'b0;
        t3<=80'b0;
        t4<=80'b0;
    end 
    else if(timestamp_tx_Pdelay_valid_cdc)
        t1 <= timer;
    else if(timestamp_rx_Presp_valid_cdc)
        t4 <= timer;
    else if(Pdelay_opposite_rx_ts_valid)
        t2 <= Pdelay_opposite_rx_ts;
    else if(Pdelay_Resp_tx_ts_valid)
        t3 <= Pdelay_Resp_tx_ts;
    else begin
        t1<=t1;
        t2<=t2;
        t3<=t3;
        t4<=t4;
    end
end

always @(posedge clk or posedge rst) begin
    if (rst == 1'b1) begin
        t3_t2 <= 64'b0;
    end 
    else if(onestep_Presp_CorrectionField_valid)
        t3_t2 <= onestep_Presp_CorrectionField;
end


always @(posedge clk or posedge rst) begin
    if (rst == 1'b1) begin
        link_delay_compute<=1'b0;
    end 
    else if(cstate == FINISH)
        link_delay_compute<=1'b1;
    else
        link_delay_compute<=1'b0;
end

always @(posedge clk or posedge rst) begin
    if (rst == 1'b1) begin
        link_delay_compute_ff1 <= 1'b0 ;
        link_delay_compute_ff2 <= 1'b0 ;
    end
    else begin
        link_delay_compute_ff1 <= link_delay_compute;
        link_delay_compute_ff2 <= link_delay_compute_ff1;
    end
end

//前32位代表秒，后32位代表ns的格式相减。
//Pdelay_Req_tx_ts,Pdelay发送时间点，rx_Pdelay_Resp_rsd代表接收对端发送的Pdelay_resp帧解析出的接收时间点，Pdelay_Resp_rx_ts表示接收到Delay_resp的时间点
always @(posedge clk or posedge rst) begin
    if (rst == 1'b1) begin
        a <= 80'd0 ;
    end
    else if (link_delay_compute) begin
        if (t4[31:0] < t1[31:0]) begin
            a[31:0] <= t4[31:0] + 32'd1000000000 - t1[31:0] ;
            a[79:32] <= t4[79:32] - 48'd1 - t1[79:32] ;
        end
        else begin
            a[31:0] <= t4[31:0] - t1[31:0] ;
            a[79:32] <= t4[79:32] - t1[79:32] ;            
        end
    end
    else begin
        a <= a ;
    end
end

always @(posedge clk or posedge rst) begin
    if (rst == 1'b1) begin
        b <= 80'd0 ;
    end
    else if (link_delay_compute && two_step_flag) begin
        if (t3[31:0] < t2[31:0]) begin
            b[31:0]  <= t3[31:0] + 32'd1000000000 - t2[31:0] ;
            b[79:32] <= t3[79:32] - 48'd1 - t2[79:32] ;
        end
        else begin
            b[31:0]  <= t3[31:0] - t2[31:0] ;
            b[79:32] <= t3[79:32] - t2[79:32] ;            
        end
    end
    else if (link_delay_compute && !two_step_flag) begin
            b[79:64] <= 16'b0;
            b[63:0]  <= t3_t2;
    end
    else begin
        b <= b ;
    end
end

always @(posedge clk or posedge rst) begin
    if (rst == 1'b1) begin
        c <= 80'd0 ;
    end
    else if (link_delay_compute_ff1) begin
        if (a[31:0] < b[31:0]) begin
            c[31:0]  <= a[31:0]  + 32'd1000000000 - b[31:0] ;
            c[79:32] <= a[79:32] - 48'd1 - b[79:32] ;
        end
        else begin
            c[31:0]  <= a[31:0] -  b[31:0] ;
            c[79:32] <= a[79:32] - b[79:32] ;            
        end
    end
    else begin
        c <= c ;
    end
end

//完成除以2的操作
always @(posedge clk or posedge rst) begin
    if (rst == 1'b1) begin
        link_delay <= 80'd0 ;
    end
    else if (link_delay_compute_ff2) begin
        if (c[32] == 1'b1) begin
            link_delay[31:0]  <= (c[31:0] >> 1) + 32'd5_0000_0000 ;
            link_delay[79:32] <= c[79:32] >> 1 ;
        end    
        else begin
            link_delay[31:0]  <= c[31:0]  >> 1 ;
            link_delay[79:32] <= c[79:32] >> 1 ;
        end
    end
end

always @(posedge clk or posedge rst) begin
    if (rst == 1'b1) begin
        link_delay_valid <= 1'b0 ;
        link_flag        <= 1'b0 ;
    end
    else if (link_delay_compute_ff2) begin
        link_delay_valid <= 1'b1 ;
        link_flag        <= 1'b1 ;
    end
    else begin
        link_delay_valid <= 1'b0 ;
        link_flag        <= link_flag;
    end
end

//开始计算offset
always @(posedge clk or posedge rst) begin
    if (rst == 1'b1) 
        link_delay_value <= 80'd0 ;
    else if (link_delay_valid) 
        link_delay_value <= link_delay;
    else
        link_delay_value <= link_delay_value ;
end

always @(posedge clk or posedge rst) begin
    if (rst == 1'b1) 
        Sync_rx_ts_value <= 80'd0 ;
    else if (timestamp_rx_Sync_valid_cdc) 
        Sync_rx_ts_value <= sys_time;
    else
        Sync_rx_ts_value <= Sync_rx_ts_value ;
end

always @(posedge clk or posedge rst) begin
    if (rst == 1'b1) begin
        d <= 80'd0 ;
        d_valid <= 1'b0 ;
    end
    else if (Sync_ts_valid && link_flag) begin
        if (Sync_tx_ts[31:0] + link_delay_value[31:0] >= 32'd1000000000) begin
            d[31:0]  <= Sync_tx_ts[31:0] + link_delay_value[31:0] - 32'd1000000000 ;
            d[79:32] <= Sync_tx_ts[79:32] + 1'b1 + link_delay_value[79:32] ;
        end
        else begin
            d[31:0]  <= Sync_tx_ts[31:0] +  link_delay_value[31:0] ;
            d[79:32] <= Sync_tx_ts[79:32] + link_delay_value[79:32] ;            
        end
        d_valid <= 1'b1 ;
    end
    else begin
        d <= 80'b0 ;
        d_valid <= 1'b0 ;
    end
end

always @(posedge clk or posedge rst) begin
    if (rst == 1'b1) begin
        offset <= 80'd0 ;
        sign <= 1'b0 ;
        valid <= 1'b0 ;
    end
    else if (d_valid) begin
        if (Sync_rx_ts_value[79:32] > d[79:32]) begin
            if (Sync_rx_ts_value[31:0] >= d[31:0]) begin
                offset[31:0]  <= Sync_rx_ts_value[31:0]  - d[31:0] ;
                offset[79:32] <= Sync_rx_ts_value[79:32] - d[79:32] ;
                sign <= 1'b0 ;        
            end
            else begin
                offset[31:0]  <= Sync_rx_ts_value[31:0]  + 32'd1000000000 - d[31:0] ;
                offset[79:32] <= Sync_rx_ts_value[79:32] - 48'd1 - d[79:32] ;
                sign <= 1'b0 ;                            
            end    
        end
        else if (Sync_rx_ts_value[79:32] == d[79:32]) begin
            if (Sync_rx_ts_value[31:0] >= d[31:0]) begin
                offset[31:0]  <= Sync_rx_ts_value[31:0]  - d[31:0] ;
                offset[79:32] <= Sync_rx_ts_value[79:32] - d[79:32];
                sign <= 1'b0 ;                   
             end 
             else begin
                offset[31:0]  <= d[31:0] -  Sync_rx_ts_value[31:0] ;
                offset[79:32] <= d[79:32] - Sync_rx_ts_value[79:32];
                sign <= 1'b1 ;                    
             end
        end
        else if (Sync_rx_ts_value[79:32] < d[79:32]) begin
            if (Sync_rx_ts_value[31:0] > d[31:0]) begin
                offset[31:0]  <= d[31:0] + 32'd1000000000 - Sync_rx_ts_value[31:0] ;
                offset[79:32] <= d[79:32] - 48'd1 - Sync_rx_ts_value[79:32] ;
                sign <= 1'b1 ;                     
            end
            else begin
                offset[31:0]  <= d[31:0]  - Sync_rx_ts_value[31:0] ;
                offset[79:32] <= d[79:32] - Sync_rx_ts_value[79:32] ;
                sign <= 1'b1 ;                     
            end    
        end
        valid <= 1'b1 ;
    end
    else begin
            offset <= offset ;
            sign   <= sign ;
            valid  <= 1'b0 ;         
    end
end

endmodule    