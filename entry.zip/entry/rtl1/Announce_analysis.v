`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/04/24 17:03:28
// Design Name: 
// Module Name: Announce_analysis
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module Announce_analysis(
    input           clk,
    input           rst_n,
    input   [7:0]   data_i          ,
    input           valid_i         ,


    output  reg  [15:0]  MsgLength           ,
    output  reg  [7:0]   DomainNumber        ,
    output  reg  [15:0]  FlagField           ,
    output  reg  [63:0]  CorrectionField     ,
    output  reg  [79:0]  sourcePortIdentity  ,
    output  reg  [15:0]  SequenceID          ,
    output  reg  [7:0]   ControlField        ,
    output  reg  [7:0]   logMessage          ,


    output  reg  [15:0]  Message_currentUtcOffset       ,
    output  reg  [7:0]   Message_Priority1              ,         
    output  reg  [7:0]   Message_clockClass             ,        
    output  reg  [7:0]   Message_clockAccuracy          ,     
    output  reg  [15:0]  Message_offsetScaledLogVariance,   
    output  reg  [7:0]   Message_Priority2              ,        
    output  reg  [63:0]  Message_clockIdentity          ,  
    output  reg  [15:0]  Message_stepsRemoved           ,
    output  reg  [7:0]   Message_timeSource             ,

    output               message_valid                   
);


       
reg [7:0]  cnt;


assign  message_valid =(cnt==62)?1'b1:1'b0;

always @(posedge clk or negedge rst_n) begin
    if(!rst_n)
        cnt<=8'b0;
    else if(!valid_i)
        cnt<=8'b0;
    else
        cnt<=cnt+1;
end

always @(posedge clk or negedge rst_n) begin
    if(!rst_n)begin
        MsgLength                      <= 16'b0;
        DomainNumber                   <= 8'b0 ;
        FlagField                      <= 16'b0;
        CorrectionField                <= 64'b0;
        sourcePortIdentity             <= 80'b0;
        SequenceID                     <= 16'b0;
        ControlField                   <= 8'b0 ;
        logMessage                     <= 8'b0 ; 
        Message_currentUtcOffset       <= 16'b0;
        Message_Priority1              <= 8'b0 ;
        Message_clockClass             <= 8'b0 ;
        Message_clockAccuracy          <= 8'b0 ;
        Message_offsetScaledLogVariance<= 16'b0;
        Message_Priority2              <= 8'b0 ;
        Message_clockIdentity          <= 64'b0;
        Message_stepsRemoved           <= 16'b0;
        Message_timeSource             <= 8'b0 ;

    end
    else begin
        case(cnt)
            8'd0: MsgLength[15:8]                       <= data_i;
            8'd1: MsgLength[7:0]                        <= data_i;
            8'd2: DomainNumber                          <= data_i;
            8'd4: FlagField[15:8]                       <= data_i;
            8'd5: FlagField[7:0]                        <= data_i;
            8'd6: CorrectionField[63:56]                <= data_i;
            8'd7: CorrectionField[55:48]                <= data_i;
            8'd8: CorrectionField[47:40]                <= data_i;
            8'd9: CorrectionField[39:32]                <= data_i;
            8'd10:CorrectionField[31:24]                <= data_i;
            8'd11:CorrectionField[23:16]                <= data_i;
            8'd12:CorrectionField[15:8]                 <= data_i;
            8'd13:CorrectionField[7:0]                  <= data_i;
            8'd18:sourcePortIdentity[79:72]             <= data_i;
            8'd19:sourcePortIdentity[71:64]             <= data_i;
            8'd20:sourcePortIdentity[63:56]             <= data_i;
            8'd21:sourcePortIdentity[55:48]             <= data_i;
            8'd22:sourcePortIdentity[47:40]             <= data_i;
            8'd23:sourcePortIdentity[39:32]             <= data_i;
            8'd24:sourcePortIdentity[31:24]             <= data_i;
            8'd25:sourcePortIdentity[23:16]             <= data_i;
            8'd26:sourcePortIdentity[15:8 ]             <= data_i;
            8'd27:sourcePortIdentity[7:0  ]             <= data_i;
            8'd28:SequenceID[15:8]                      <= data_i;
            8'd29:SequenceID[7:0]                       <= data_i;
            8'd30:ControlField                          <= data_i;
            8'd31:logMessage                            <= data_i;
            8'd42:Message_currentUtcOffset[15:8]        <= data_i;
            8'd43:Message_currentUtcOffset[7:0]         <= data_i;
            8'd45:Message_Priority1                     <= data_i;
            8'd46:Message_clockClass                    <= data_i;
            8'd47:Message_clockAccuracy                 <= data_i;
            8'd48:Message_offsetScaledLogVariance[15:8] <= data_i;
            8'd49:Message_offsetScaledLogVariance[7:0]  <= data_i;
            8'd50:Message_Priority2                     <= data_i;
            8'd51:Message_clockIdentity[63:56]          <= data_i;
            8'd52:Message_clockIdentity[55:48]          <= data_i;
            8'd53:Message_clockIdentity[47:40]          <= data_i;
            8'd54:Message_clockIdentity[39:32]          <= data_i;
            8'd55:Message_clockIdentity[31:24]          <= data_i;
            8'd56:Message_clockIdentity[23:16]          <= data_i;
            8'd57:Message_clockIdentity[15:8]           <= data_i;
            8'd58:Message_clockIdentity[7:0]            <= data_i;
            8'd59:Message_stepsRemoved[15:8]            <= data_i;
            8'd60:Message_stepsRemoved[7:0]             <= data_i;
            8'd61:Message_timeSource                    <= data_i;
            default:begin
                MsgLength                       <= MsgLength                      ;
                DomainNumber                    <= DomainNumber                   ;
                FlagField                       <= FlagField                      ;
                CorrectionField                 <= CorrectionField                ;
                sourcePortIdentity              <= sourcePortIdentity             ;
                SequenceID                      <= SequenceID                     ;
                ControlField                    <= ControlField                   ;
                logMessage                      <= logMessage                     ;
                Message_currentUtcOffset        <= Message_currentUtcOffset       ;
                Message_Priority1               <= Message_Priority1              ;
                Message_clockClass              <= Message_clockClass             ;
                Message_clockAccuracy           <= Message_clockAccuracy          ;
                Message_offsetScaledLogVariance <= Message_offsetScaledLogVariance;
                Message_Priority2               <= Message_Priority2              ;
                Message_clockIdentity           <= Message_clockIdentity          ;
                Message_stepsRemoved            <= Message_stepsRemoved           ;
                Message_timeSource              <= Message_timeSource             ;
            end
        endcase
    end
end


endmodule
