`timescale 1ns / 1ps

module bc_top #( 
    parameter PORT_NUM = 4
)
(
    input   clk,
    input   rst_n,

    input   [PORT_NUM*8-1:0]   gmii_rxd,    //小端序{4，3，2，1}
    input   [PORT_NUM-1:0  ]   gmii_rx_dv,
 
    output  [PORT_NUM*8-1:0]   gmii_txd,
    output  [PORT_NUM-1:0  ]   gmii_tx_en,
    
    //本地时钟配置信息
    input   [7:0]    Priority1              ,         
    input   [7:0]    clockClass             ,        
    input   [7:0]    clockAccuracy          ,     
    input   [15:0]   offsetScaledLogVariance,   
    input   [7:0]    Priority2              ,        
    input   [63:0]   clockIdentity          ,  

    //报文发送周期
    input   [7:0]    LogInterval_sync       , 
    input   [7:0]    LogInterval_pdelay     ,
    input   [7:0]    LogInterval_announce   ,

    output           sys_sync               ,
    output  [79:0]   sys_time               ,
    //时间戳生成
    input   [PORT_NUM-1:0]   timestamp_tx_Pdelay_valid_cdc,
    input   [PORT_NUM-1:0]   timestamp_tx_Sync_valid_cdc  ,
    input   [PORT_NUM-1:0]   timestamp_tx_Presp_valid_cdc ,
    input   [PORT_NUM-1:0]   timestamp_rx_Pdelay_valid_cdc,
    input   [PORT_NUM-1:0]   timestamp_rx_Sync_valid_cdc  ,
    input   [PORT_NUM-1:0]   timestamp_rx_Presp_valid_cdc ,

    output       pulse
);

wire [3:0]   port_state;            //端口状态
wire         portstate_valid;
wire [79:0]  timer;

logic  [79:0]  Pdelay_Resp_tx_ts             [PORT_NUM];         //对端发送Presp帧的时间点
logic          Pdelay_Resp_tx_ts_valid       [PORT_NUM];
logic  [79:0]  Pdelay_opposite_rx_ts         [PORT_NUM];         //对端接收Pdelay帧的时间点
logic          Pdelay_opposite_rx_ts_valid   [PORT_NUM];
logic  [79:0]  Sync_tx_ts                    [PORT_NUM];
logic  [63:0]  Sync_correction_field         [PORT_NUM];
logic          Sync_ts_valid                 [PORT_NUM];

wire [79:0] offset [0:PORT_NUM-1];
wire [PORT_NUM-1:0] valid ;
wire [PORT_NUM-1:0] sign  ;

logic [PORT_NUM-1:0] Pdelay_Req_en;
logic [PORT_NUM-1:0] Sync_en      ;
logic [PORT_NUM-1:0] Announce_en  ;

wire [79:0] link_delay [0:PORT_NUM-1];
wire [PORT_NUM-1:0] link_delay_valid;

// 结构体映射拆解为独立信号数组
logic   [79:0]   Message_sourcePortIdentity       [PORT_NUM];
logic   [15:0]   Message_currentUtcOffset         [PORT_NUM];
logic   [7:0]    Message_Priority1                [PORT_NUM];
logic   [7:0]    Message_clockClass               [PORT_NUM];
logic   [7:0]    Message_clockAccuracy            [PORT_NUM];
logic   [15:0]   Message_offsetScaledLogVariance  [PORT_NUM];
logic   [7:0]    Message_Priority2                [PORT_NUM];
logic   [63:0]   Message_clockIdentity            [PORT_NUM];
logic   [15:0]   Message_stepsRemoved             [PORT_NUM];
logic   [PORT_NUM - 1 :0]   Message_Announce_valid;

//Announce报文 GM信息
logic [15:0] GM_currentUtcOffset;
logic [7:0]  GM_priority1;              
logic [7:0]  GM_clockClass;             
logic [7:0]  GM_clockAccuracy;          
logic [15:0] GM_offsetScaledLogVariance;
logic [7:0]  GM_priority2;              
logic [63:0] GM_clockIdentity;          
logic [15:0] GM_stepsRemoved;           

//接收Pdelay帧完成标识
logic [PORT_NUM-1:0] pdelay_valid;
logic [79:0] pdelay_portIdentity [PORT_NUM];

// BMCA 输入数组 (Index 0=Local, Index 1~N=Ports)
logic [15:0] announce_in_currentUtcOffset        [PORT_NUM + 1];
logic [7:0]  announce_in_priority1               [PORT_NUM + 1];
logic [7:0]  announce_in_clockClass              [PORT_NUM + 1];
logic [7:0]  announce_in_clockAccuracy           [PORT_NUM + 1];
logic [15:0] announce_in_offsetScaledLogVariance [PORT_NUM + 1];
logic [7:0]  announce_in_priority2               [PORT_NUM + 1];
logic [63:0] announce_in_clockIdentity           [PORT_NUM + 1];
logic [15:0] announce_in_stepsRemoved            [PORT_NUM + 1];

// BMCA 输出最佳信息
logic [15:0] best_announce_currentUtcOffset;
logic [7:0]  best_announce_priority1;
logic [7:0]  best_announce_clockClass;
logic [7:0]  best_announce_clockAccuracy;
logic [15:0] best_announce_offsetScaledLogVariance;
logic [7:0]  best_announce_priority2;
logic [63:0] best_announce_clockIdentity;
logic [15:0] best_announce_stepsRemoved;

// 本地 Announce 信息拆解
// currentUtcOffset 默认为0，stepsRemoved 默认为0
wire [15:0] local_announce_currentUtcOffset        = 16'b0;
wire [7:0]  local_announce_priority1               = Priority1;
wire [7:0]  local_announce_clockClass              = clockClass;
wire [7:0]  local_announce_clockAccuracy           = clockAccuracy;
wire [15:0] local_announce_offsetScaledLogVariance = offsetScaledLogVariance;
wire [7:0]  local_announce_priority2               = Priority2;
wire [63:0] local_announce_clockIdentity           = clockIdentity;
wire [15:0] local_announce_stepsRemoved            = 16'b0;

// 用于检测本地配置变化的打拍信号
logic [7:0]  local_announce_priority1_d;
logic [7:0]  local_announce_clockClass_d;
logic [7:0]  local_announce_clockAccuracy_d;
logic [15:0] local_announce_offsetScaledLogVariance_d;
logic [7:0]  local_announce_priority2_d;
logic [63:0] local_announce_clockIdentity_d;
logic        local_announce_valid;

logic [PORT_NUM:0]   announce_valid;
logic [63:0] local_time;
logic [79:0] best_offest;
logic best_valid;
logic best_sign;
logic best_port_valid;
logic [$clog2(PORT_NUM+1)-1:0] best_index;

//------------------------------------------------------------------------------
// 时钟偏移选择逻辑
//------------------------------------------------------------------------------
always_ff@(posedge clk or negedge rst_n)begin
    if(!rst_n)begin
        best_offest <= 80'b0;
        best_valid  <= 1'b0 ;
        best_sign   <= 1'b0 ;
    end
    else if(|valid)begin
        for(int i=0 ; i < PORT_NUM ; i=i+1)begin
            if(valid[i])begin 
                best_offest <= offset[i];
                best_valid  <= valid[i] ;
                best_sign   <= sign[i]  ;
            end
        end
    end
    else begin
        best_offest <= 80'b0;
        best_valid  <= 1'b0;
        best_sign   <= 1'b0;
    end
end

//------------------------------------------------------------------------------
// GM 信息更新逻辑 (拆解后)
//------------------------------------------------------------------------------
always_ff@(posedge clk or negedge rst_n)begin
    if(!rst_n)begin
        GM_currentUtcOffset         <= 16'b0;
        GM_priority1                <= 8'b0;           
        GM_clockClass               <= 8'b0;          
        GM_clockAccuracy            <= 8'b0;         
        GM_offsetScaledLogVariance  <= 16'b0;
        GM_priority2                <= 8'b0;             
        GM_clockIdentity            <= 64'b0;         
        GM_stepsRemoved             <= 16'b0;        
    end
    else if(best_port_valid && best_index != 0)begin
        // 如果最佳主时钟来自外部端口，StepsRemoved + 1
       GM_currentUtcOffset        <= best_announce_currentUtcOffset;
       GM_priority1               <= best_announce_priority1;
       GM_clockClass              <= best_announce_clockClass;
       GM_clockAccuracy           <= best_announce_clockAccuracy;
       GM_offsetScaledLogVariance <= best_announce_offsetScaledLogVariance;
       GM_priority2               <= best_announce_priority2;
       GM_clockIdentity           <= best_announce_clockIdentity;
       GM_stepsRemoved            <= best_announce_stepsRemoved + 16'b1; 
    end
    else if(best_port_valid)begin
        // 如果最佳主时钟是本地 (best_index == 0)
       GM_currentUtcOffset        <= best_announce_currentUtcOffset;
       GM_priority1               <= best_announce_priority1;
       GM_clockClass              <= best_announce_clockClass;
       GM_clockAccuracy           <= best_announce_clockAccuracy;
       GM_offsetScaledLogVariance <= best_announce_offsetScaledLogVariance;
       GM_priority2               <= best_announce_priority2;
       GM_clockIdentity           <= best_announce_clockIdentity;
       GM_stepsRemoved            <= best_announce_stepsRemoved;
    end
end

    
//------------------------------------------------------------------------------
// 检测 Local Announce 变化
//------------------------------------------------------------------------------
always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        local_announce_priority1_d               <= '0;
        local_announce_clockClass_d              <= '0;
        local_announce_clockAccuracy_d           <= '0;
        local_announce_offsetScaledLogVariance_d <= '0;
        local_announce_priority2_d               <= '0;
        local_announce_clockIdentity_d           <= '0;
        local_announce_valid                     <= 1'b0; 
    end else begin
        local_announce_priority1_d               <= local_announce_priority1;
        local_announce_clockClass_d              <= local_announce_clockClass;
        local_announce_clockAccuracy_d           <= local_announce_clockAccuracy;
        local_announce_offsetScaledLogVariance_d <= local_announce_offsetScaledLogVariance;
        local_announce_priority2_d               <= local_announce_priority2;
        local_announce_clockIdentity_d           <= local_announce_clockIdentity;

        // 任意配置字段改变则触发 Valid
        if (local_announce_priority1               != local_announce_priority1_d               ||
            local_announce_clockClass              != local_announce_clockClass_d              ||
            local_announce_clockAccuracy           != local_announce_clockAccuracy_d           ||
            local_announce_offsetScaledLogVariance != local_announce_offsetScaledLogVariance_d ||
            local_announce_priority2               != local_announce_priority2_d               ||
            local_announce_clockIdentity           != local_announce_clockIdentity_d
           ) begin
            local_announce_valid <= 1'b1;
        end else begin
            local_announce_valid <= 1'b0;
        end
    end
end


time_management_BC #(
    .PORT_NUM(PORT_NUM)
)  U_time_management_BC(
        .clk                (clk        ),
        .rst_n              (rst_n      ), 
        .timer              (timer      ),
        .offset             (best_offest),
        .valid              (best_valid ),
        .sign               (best_sign  ),
        .integration_cycle  (32'd10000  ),
        .sys_time           (sys_time   ),
        .pulse              (pulse      ),  
        .local_clk_l        (local_clk_l)
);


//帧生成
genvar i;
generate 
    for(i = 0; i < PORT_NUM ; i = i + 1)begin:frame_gen
        frame_gen_BC U_frame_gen_BC(
            .clk                                (clk                                                 ),        
            .rst_n                              (rst_n                                               ),      
            .sync_gen                           (Sync_en[i]                                          ),
            .pdelay_gen                         (Pdelay_Req_en[i]                                    ),   
            .announce_gen                       (Announce_en[i]                                      ), 
            .two_step_flag                      (1'b1                                                ), 
            .timer                              (timer                                               ), 
            .sys_time                           (sys_time                                            ), 
            .clockIdentity                      ({i[15:0],clockIdentity}                             ), 
            .LogInterval_sync                   (LogInterval_sync                                    ), 
            .LogInterval_pdelay                 (LogInterval_pdelay                                  ), 
            .LogInterval_announce               (LogInterval_announce                                ), 
            .pdelay_valid                       (pdelay_valid[i]                                     ),
            .pdelay_portIdentity                (pdelay_portIdentity[i]                              ), 
        
            //BMCA主时钟信息
            .currentUtcOffset                   (GM_currentUtcOffset                                 ), 
            .grandmasterPriority1               (GM_priority1                                        ), 
            .grandmasterClockQuality            ({GM_clockClass,GM_clockAccuracy,GM_offsetScaledLogVariance}), 
            .grandmasterPriority2               (GM_priority2                                        ), 
            .grandmasterIdentity                (GM_clockIdentity                                    ), 
            .grandmasterStepsRemoved            (GM_stepsRemoved                                     ),
        
            .timestamp_tx_Sync_valid_cdc        (timestamp_tx_Sync_valid_cdc[i]                      ),
            .timestamp_rx_Pdelay_valid_cdc      (timestamp_rx_Pdelay_valid_cdc[i]                    ),
            .timestamp_tx_Presp_valid_cdc       (timestamp_tx_Presp_valid_cdc[i]                     ),
            .dout                               (gmii_txd[i*8 +: 8]                                  ), 
            .dout_valid                         (gmii_tx_en[i]                                       )
        );
    end
endgenerate


//帧解析
genvar j;
generate 
    for(j = 0; j < PORT_NUM ; j = j + 1)begin:frame_ananlysis
        frame_analysis  U0_frame_analysis(
            .clk                             (clk                              ),
            .rst_n                           (rst_n                            ),
            .data_i                          (gmii_rxd[j*8 +: 8]               ),    //小端序
            .valid_i                         (gmii_rx_dv[j]                    ),
            .pdelay_valid                    (pdelay_valid[j]                  ),
            .pdelay_portIdentity             (pdelay_portIdentity[j]           ),
        
            //BMCA算法相关字段提取
            .Message_sourcePortIdentity      (Message_sourcePortIdentity[j]     ),
            .Message_currentUtcOffset        (Message_currentUtcOffset[j]       ),
            .Message_Priority1               (Message_Priority1[j]              ),         
            .Message_clockClass              (Message_clockClass[j]             ),        
            .Message_clockAccuracy           (Message_clockAccuracy[j]          ),     
            .Message_offsetScaledLogVariance (Message_offsetScaledLogVariance[j]),   
            .Message_Priority2               (Message_Priority2[j]              ),        
            .Message_clockIdentity           (Message_clockIdentity[j]          ),  
            .Message_stepsRemoved            (Message_stepsRemoved[j]           ),
            .Message_Announce_valid          (Message_Announce_valid[j]         ),   //接收Announce报文脉冲
        
            .Pdelay_Resp_tx_ts               (Pdelay_Resp_tx_ts[j]              ),   //对端发送Presp的时间点
            .Pdelay_Resp_tx_ts_valid         (Pdelay_Resp_tx_ts_valid[j]        ),
            .Pdelay_opposite_rx_ts           (Pdelay_opposite_rx_ts[j]          ),   //对端接收Pdelay帧的时间点
            .Pdelay_opposite_rx_ts_valid     (Pdelay_opposite_rx_ts_valid[j]    ),
            .Sync_tx_ts                      (Sync_tx_ts[j]                     ),
            .Sync_correction_field           (Sync_correction_field[j]          ),
            .Sync_ts_valid                   (Sync_ts_valid[j]                  )
        );
        
        // 构建 BMCA 的输入数组 (Port 1 ~ Port N)
        assign announce_in_currentUtcOffset[j+1]        = Message_currentUtcOffset[j];
        assign announce_in_priority1[j+1]               = Message_Priority1[j];
        assign announce_in_clockClass[j+1]              = Message_clockClass[j];
        assign announce_in_clockAccuracy[j+1]           = Message_clockAccuracy[j];
        assign announce_in_offsetScaledLogVariance[j+1] = Message_offsetScaledLogVariance[j];
        assign announce_in_priority2[j+1]               = Message_Priority2[j];
        assign announce_in_clockIdentity[j+1]           = Message_clockIdentity[j];
        assign announce_in_stepsRemoved[j+1]            = Message_stepsRemoved[j];
    end
endgenerate
         
// 构建 BMCA 的输入数组 (Port 0 - Local)
assign announce_in_currentUtcOffset[0]        = local_announce_currentUtcOffset;
assign announce_in_priority1[0]               = local_announce_priority1;
assign announce_in_clockClass[0]              = local_announce_clockClass;
assign announce_in_clockAccuracy[0]           = local_announce_clockAccuracy;
assign announce_in_offsetScaledLogVariance[0] = local_announce_offsetScaledLogVariance;
assign announce_in_priority2[0]               = local_announce_priority2;
assign announce_in_clockIdentity[0]           = local_announce_clockIdentity;
assign announce_in_stepsRemoved[0]            = local_announce_stepsRemoved;

assign announce_valid = {Message_Announce_valid, local_announce_valid};    //小端序：[N...1, 0]  ，0代表自身

//全端口BMCA算法
BMCA_BC #(
        .PORT_NUM(PORT_NUM)
) U_BMCA_BC (
    .clk                                  (clk                                  ),
    .rst_n                                (rst_n                                ),
    
    // 输入打散的数组
    .announce_in_currentUtcOffset         (announce_in_currentUtcOffset         ),
    .announce_in_priority1                (announce_in_priority1                ),
    .announce_in_clockClass               (announce_in_clockClass               ),
    .announce_in_clockAccuracy            (announce_in_clockAccuracy            ),
    .announce_in_offsetScaledLogVariance  (announce_in_offsetScaledLogVariance  ),
    .announce_in_priority2                (announce_in_priority2                ),
    .announce_in_clockIdentity            (announce_in_clockIdentity            ),
    .announce_in_stepsRemoved             (announce_in_stepsRemoved             ),
    
    .announce_valid                       (announce_valid                       ),    //小端序
    
    .best_port_index                      (best_index                           ),
    .best_valid                           (best_port_valid                      ),
    
    // 输出打散的最佳信息
    .best_announce_currentUtcOffset       (best_announce_currentUtcOffset       ),
    .best_announce_priority1              (best_announce_priority1              ),
    .best_announce_clockClass             (best_announce_clockClass             ),
    .best_announce_clockAccuracy          (best_announce_clockAccuracy          ),
    .best_announce_offsetScaledLogVariance(best_announce_offsetScaledLogVariance),
    .best_announce_priority2              (best_announce_priority2              ),
    .best_announce_clockIdentity          (best_announce_clockIdentity          ),
    .best_announce_stepsRemoved           (best_announce_stepsRemoved           )
);

//计算模块
genvar k;
generate 
    for(k = 0; k < PORT_NUM ; k = k + 1)begin:compute
        compute U0_compute(
            .clk                             (clk                               ),
            .rst                             (~rst_n                            ),       
            .timestamp_tx_Pdelay_valid_cdc   (timestamp_tx_Pdelay_valid_cdc[k]  ),      
            .timestamp_rx_Presp_valid_cdc    (timestamp_rx_Presp_valid_cdc[k]   ),      
        
            .Pdelay_opposite_rx_ts           (Pdelay_opposite_rx_ts[k]          ),      
            .Pdelay_opposite_rx_ts_valid     (Pdelay_opposite_rx_ts_valid[k]    ),
            .Pdelay_Resp_tx_ts               (Pdelay_Resp_tx_ts[k]              ),      
            .Pdelay_Resp_tx_ts_valid         (Pdelay_Resp_tx_ts_valid[k]        ),
        
            .Sync_tx_ts                      (Sync_tx_ts[k]                     ),      
            .Sync_correction_field           (Sync_correction_field[k]          ),
            .Sync_ts_valid                   (Sync_ts_valid[k]                  ),
            
            .timestamp_rx_Sync_valid_cdc     (timestamp_rx_Sync_valid_cdc[k]    ),      
            .timer                           (timer                             ),
            .offset                          (offset[k]                         ),
            .valid                           (valid[k]                          ),
            .sign                            (sign[k]                           ),
            .sys_time                        (sys_time                          ),
            .link_delay_out                  (link_delay[k]                     ),
            .link_delay_valid_out            (link_delay_valid[k]               )
        );
    end
endgenerate


port_manager #(
    .PORT_NUM (PORT_NUM)
    )
U_port_manager(
    .clk                 (clk                 ),
    .rst_n               (rst_n               ),
    .best_index          (best_index          ),
    .best_valid          (best_port_valid     ),
    .receive_sync        (best_valid          ),
    .best_offest         (best_offest         ),
    .sys_time            (sys_time            ),
    .local_time          (local_time          ),
    .LogInterval_sync    (LogInterval_sync    ),   
    .LogInterval_pdelay  (LogInterval_pdelay  ),   
    .LogInterval_announce(LogInterval_announce),   
    .Pdelay_Req_en       (Pdelay_Req_en       ),
    .Sync_en             (Sync_en             ),
    .Announce_en         (Announce_en         ),
    .sys_sync            (sys_sync            )
);


ila_bc_mor U_ila_bc_mor (
    .clk(clk), // input wire clk
    .probe0 (best_offest         ), // input wire [79:0] probe0  
    .probe1 (best_valid          ), // input wire [0:0]  probe1 
    .probe2 (best_sign           ), // input wire [0:0]  probe2 
    .probe3 (sys_sync            ), // input wire [0:0]  probe3 
    .probe4 (link_delay[0]       ), // input wire [79:0] probe4 
    .probe5 (link_delay_valid[0] ), // input wire [0:0]  probe5 
    .probe6 (link_delay[1]       ), // input wire [79:0] probe6 
    .probe7 (link_delay_valid[1] ), // input wire [0:0]  probe7 
    .probe8 (link_delay[2]       ), // input wire [79:0] probe8 
    .probe9 (link_delay_valid[2] ), // input wire [0:0]  probe9 
    .probe10(link_delay[3]       ), // input wire [79:0] probe10 
    .probe11(link_delay_valid[3] ), // input wire [0:0]  probe11
    .probe12(best_index          ), // input wire [2:0]  probe12 
    .probe13(best_port_valid     )  // input wire [0:0]  probe13
);

endmodule