`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/06/10 15:04:14
// Design Name: 
// Module Name: time_management_BC
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////



module time_management_BC #( 
    parameter PORT_NUM = 4
)(
        input  clk,
        input  rst_n, 
    
        output  [79:0]    timer ,//本地时钟，低32位为ns

        //时钟纠偏信号
        input   [79:0]    offset,
        input             valid ,
        input             sign  ,
        input   [31:0]    integration_cycle,

        output  [79:0]    sys_time,
        output            pulse,
        output  [31:0]    local_clk_l 
 
);

//Paramter(s)
parameter  period_ns_decimal   = 16'h0000;
parameter  period_ns           = 8'h08;

reg  [47:0] timer_s ;
reg  [31:0] timer_ns ;

//本地参与纠偏时钟
reg  [47:0] sys_time_s ;
reg  [31:0] sys_time_ns ;
reg  [15:0] sys_time_ns_decimal;
wire [31:0] offset_ns;
wire [47:0] offset_s ;

wire [95:0]system_time_decimal;

//取SLAVE口的offset
assign offset_ns = offset [31:0] ;
assign offset_s  = offset [79:32] ;

//ila
reg     pulse_out;
assign  pulse = pulse_out;
reg     pulse_ila;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        pulse_ila <= 1'd0 ;
    end
    else begin
        pulse_ila <= pulse_out;
    end   
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        sys_time_ns_decimal <= 15'd0 ;
    end
    else if ((sys_time_ns_decimal + period_ns_decimal) >= 'd10000) begin
        sys_time_ns_decimal <= sys_time_ns_decimal + period_ns_decimal - 'd10000 ;
    end   
    else begin
        sys_time_ns_decimal <= sys_time_ns_decimal + period_ns_decimal ;
    end
end

//纠偏时钟ns部分计数
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        sys_time_ns <= 32'd0 ;
    end
    else if (valid) begin
        if (sign == 1'b0) begin
            if ((sys_time_ns_decimal + period_ns_decimal) >= 'd10000) begin
                if (sys_time_ns + period_ns + 'd1 >= offset_ns) begin
                    if (sys_time_ns + period_ns + 'd1 - offset_ns >= 32'd1000000000) begin
                        sys_time_ns <= sys_time_ns + period_ns + 'd1 - offset_ns - 32'd1000000000 ;                     
                    end
                    else begin
                        sys_time_ns <= sys_time_ns + period_ns + 'd1 - offset_ns ;                     
                    end                 
                end
                else if (sys_time_ns + period_ns + 'd1 < offset_ns) begin
                    sys_time_ns <= sys_time_ns + period_ns + 'd1 + 32'd1000000000 - offset_ns ;    
                end             
            end
            else if ((sys_time_ns_decimal + period_ns_decimal) < 'd10000) begin
                if (sys_time_ns + period_ns >= offset_ns) begin
                    if (sys_time_ns + period_ns - offset_ns >= 32'd1000000000) begin
                        sys_time_ns <= sys_time_ns + period_ns - offset_ns - 32'd1000000000 ;                     
                    end
                    else begin
                        sys_time_ns <= sys_time_ns + period_ns - offset_ns ;                     
                    end                 
                end
                else if (sys_time_ns + period_ns < offset_ns) begin
                    sys_time_ns <= sys_time_ns + period_ns + 32'd1000000000 - offset_ns ;    
                end      
            end     
        end
        else if (sign == 1'b1) begin
            if ((sys_time_ns_decimal + period_ns_decimal) >= 'd10000) begin
                if (sys_time_ns + period_ns + 'd1 + offset_ns >= 32'd1000000000) begin
                    sys_time_ns <= sys_time_ns + period_ns + 'd1 + offset_ns -32'd1000000000 ;
                end
                else begin
                    sys_time_ns <= sys_time_ns + period_ns + 'd1 + offset_ns ;            
                end        
            end
            else if ((sys_time_ns_decimal + period_ns_decimal) < 'd10000) begin
                if (sys_time_ns + period_ns + offset_ns >= 32'd1000000000) begin
                    sys_time_ns <= sys_time_ns + period_ns + offset_ns -32'd1000000000 ;
                end
                else begin
                    sys_time_ns <= sys_time_ns + period_ns + offset_ns ;            
                end                 
            end    
        end    
    end
    else begin//!valid
        if ((sys_time_ns_decimal + period_ns_decimal) >= 'd10000) begin
            if ((sys_time_ns + period_ns + 'd1)>= 'd1000000000) begin
                sys_time_ns <= sys_time_ns + period_ns +'d1 - 'd1000000000 ;  
            end
            else begin
                sys_time_ns <= sys_time_ns + period_ns + 'd1 ;
            end
        end
        else begin
            if ((sys_time_ns + period_ns) >= 'd1000000000) begin
                sys_time_ns <= sys_time_ns + period_ns - 'd1000000000 ;                  
            end 
            else begin
                sys_time_ns <= sys_time_ns + period_ns ;      
            end   
        end  
    end
end

//纠偏时钟s部分计数
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        sys_time_s <= 48'd0 ;
    end
    else if (valid) begin
            if (sign == 1'b0) begin
                if ((sys_time_ns_decimal + period_ns_decimal) >= 'd10000) begin
                    if (sys_time_ns + period_ns + 'd1 >= offset_ns) begin
                        if (sys_time_ns + period_ns + 'd1 - offset_ns >= 32'd1000000000) begin
                            sys_time_s <= sys_time_s + 'd1 - offset_s ;                  
                        end
                        else begin
                            sys_time_s <= sys_time_s - offset_s ;                                     
                        end                 
                    end
                    else if (sys_time_ns + period_ns + 'd1 < offset_ns) begin
                            sys_time_s <= sys_time_s - 'd1 -offset_s ;        
                    end                    
                end
                else if ((sys_time_ns_decimal + period_ns_decimal) < 'd10000) begin
                    if (sys_time_ns + period_ns >= offset_ns) begin
                        if (sys_time_ns + period_ns - offset_ns >= 32'd1000000000) begin
                            sys_time_s <= sys_time_s + 'd1 - offset_s ;                  
                        end
                        else begin
                            sys_time_s <= sys_time_s - offset_s ;                                     
                        end                 
                    end
                    else if (sys_time_ns + period_ns  < offset_ns) begin
                            sys_time_s <= sys_time_s - 'd1 -offset_s ;        
                    end                    
                end                    
            end
            else if (sign == 1'b1) begin
                if ((sys_time_ns_decimal + period_ns_decimal) >= 'd10000) begin
                    if (sys_time_ns + period_ns + 'd1 + offset_ns >= 32'd1000000000) begin
                        sys_time_s <= sys_time_s + 'd1 + offset_s ;
                    end
                    else begin
                        sys_time_s <= sys_time_s + offset_s ;          
                    end        
                end
                else if ((sys_time_ns_decimal + period_ns_decimal) < 'd10000) begin
                    if (sys_time_ns + period_ns + offset_ns >= 32'd1000000000) begin
                        sys_time_s <= sys_time_s + 'd1 + offset_s ;                
                    end
                    else begin
                         sys_time_s <= sys_time_s + offset_s ;             
                    end                 
                end                    
            end
        end
    else begin//!valid
        if ((sys_time_ns_decimal + period_ns_decimal) >= 'd10000) begin
            if ((sys_time_ns + period_ns + 'd1)>= 'd1000000000) begin
                sys_time_s <= sys_time_s + 'd1 ;      
            end 
            else begin
                sys_time_s <= sys_time_s ;   
            end   
        end
        else begin
            if ((sys_time_ns + period_ns) >= 'd1000000000) begin
                 sys_time_s <= sys_time_s + 'd1 ;                   
            end 
            else begin
                 sys_time_s <= sys_time_s ;
            end   
        end  
    end   
end


assign system_time_decimal = {sys_time_s[47:0],sys_time_ns[31:0],sys_time_ns_decimal[15:0]};
assign sys_time = system_time_decimal[95:16];


//本地脉冲生成
reg [7:0]pulse_cnt;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        pulse_out <= 1'b0;
    end
    else if (sys_time_ns == 32'b0) begin
        pulse_out <= 1'b1;
    end
    else if(pulse_cnt==8'd125)begin
        pulse_out <= 1'b0;
    end
    else
        pulse_out <= pulse_out;
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        pulse_cnt <=8'b0;
    end
    else if (pulse_out) begin
        pulse_cnt <= pulse_cnt+1'b1;
    end
    else begin
        pulse_cnt <= 8'b0;
    end
end


//本地不参与纠偏时钟
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        timer_ns <= 32'h0;
        timer_s  <= 48'h0;
    end
    else if (timer_ns + 'd8 == 32'd10_0000_0000) begin
        timer_ns <= 32'b0 ;
        timer_s  <= timer_s + 'd1 ;
    end
    else begin
        timer_ns <= timer_ns + 'd8 ;
        timer_s  <= timer_s ;
    end
end


//80位本地时间
assign timer = {timer_s[47:0],timer_ns[31:0]};




mod_calculator_pipelined U_mod_calculator_pipelined(
    .clk        (clk                ),
    .rst_n      (rst_n              ),
    .dividend   (sys_time_ns        ),
    .divisor    (integration_cycle  ), 
    .remainder  (local_clk_l        )
);






endmodule
