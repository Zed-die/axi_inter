`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: wanghaoyu
// 
// Create Date: 2025/06/06 10:49:14
// Design Name: 
// Module Name: gPTP_bc_top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module gPTP_bc_top(
            input            pxie_clk100m_p    ,
            input            pxie_clk100m_n    ,
            input            sys_rst_n         ,

            input            gtrefclk_p        ,
            input            gtrefclk_n        ,

            output           SFP1_TX_DISABLE    ,
            output           SFP2_TX_DISABLE    ,
            output           SFP3_TX_DISABLE    ,
            output           SFP4_TX_DISABLE    ,

            output           txp_1              ,       
            output           txn_1              ,       
            input            rxp_1              ,       	
            input            rxn_1              ,

            output           txp_2              ,       
            output           txn_2              ,       
            input            rxp_2              ,       
            input            rxn_2              ,

            output           txp_3              ,       
            output           txn_3              ,       
            input            rxp_3              ,           
            input            rxn_3              ,

            output           txp_4              ,       
            output           txn_4              ,       
            input            rxp_4              ,       
            input            rxn_4              ,


            output           Link_1             ,
            output           Link_2             ,
            output           Link_3             ,
            output           Link_4             ,
            output           pulse         
);


wire  [7:0]   sync_tx_data1;
wire          sync_tx_valid1;
wire  [7:0]   sync_rx_data1;
wire          sync_rx_valid1;

wire  [7:0]   sync_tx_data2;
wire          sync_tx_valid2;
wire  [7:0]   sync_rx_data2;
wire          sync_rx_valid2;

wire  [7:0]   sync_tx_data3;
wire          sync_tx_valid3;
wire  [7:0]   sync_rx_data3;
wire          sync_rx_valid3;

wire  [7:0]   sync_tx_data4;
wire          sync_tx_valid4;
wire  [7:0]   sync_rx_data4;
wire          sync_rx_valid4;


//用户侧时钟
wire   clk_125M;


wire  [3:0]  timestamp_tx_Pdelay_valid_cdc;
wire  [3:0]  timestamp_tx_Sync_valid_cdc  ;
wire  [3:0]  timestamp_tx_Presp_valid_cdc ;
wire  [3:0]  timestamp_rx_Pdelay_valid_cdc;
wire  [3:0]  timestamp_rx_Sync_valid_cdc  ;
wire  [3:0]  timestamp_rx_Presp_valid_cdc ;

assign SFP1_TX_DISABLE  = 1'b0	;
assign SFP2_TX_DISABLE  = 1'b0	;
assign SFP3_TX_DISABLE  = 1'b0	;
assign SFP4_TX_DISABLE  = 1'b0	;



//vio
wire    [7:0]     Priority1_vio               ;
wire    [7:0]     clockClass_vio              ;
wire    [7:0]     clockAccuracy_vio           ;
wire    [15:0]    offsetScaledLogVariance_vio ;
wire    [7:0]     Priority2_vio               ;
wire    [63:0]    clockIdentity_vio           ;
wire    [31:0]    Sync_period_vio             ;
wire    [31:0]    Pdelay_req_period_vio       ;
wire    [31:0]    Announce_period_vio         ;

wire [31:0]sync_rx_data;
wire [3:0]sync_rx_valid;
wire [31:0]sync_tx_data;
wire [3:0]sync_tx_valid;

GMII_top inst_GMII_top(
    .sys_clk_p    (pxie_clk100m_p    ),  // 100M
    .sys_clk_n    (pxie_clk100m_n    ),

    .gtrefclk_p   (gtrefclk_p      ), // 125M
    .gtrefclk_n   (gtrefclk_n      ),

    .rst_n        (/*pcie_core_rstn*/ sys_rst_n  ),

    .rxn_1        (rxn_1            ),
    .rxp_1        (rxp_1            ),        
    .rxn_2        (rxn_2            ),
    .rxp_2        (rxp_2            ),
    .rxn_3        (rxn_3            ),
    .rxp_3        (rxp_3            ),        
    .rxn_4        (rxn_4            ),
    .rxp_4        (rxp_4            ),
            
    .txn_1        (txn_1            ),
    .txp_1        (txp_1            ),       
    .txn_2        (txn_2            ),
    .txp_2        (txp_2            ),
    .txn_3        (txn_3            ),
    .txp_3        (txp_3            ),       
    .txn_4        (txn_4            ),
    .txp_4        (txp_4            ),
    .Link_1       (Link_1           ),
    .Link_2       (Link_2           ),
    .Link_3       (Link_3           ),
    .Link_4       (Link_4           ),

    .clk_125M     (clk_125M),   // 用户时钟
    .gmii_txd_A   (sync_tx_data[7:0]  ),
    .gmii_tx_en_A (sync_tx_valid[0]   ),
    .gmii_txd_B   (sync_tx_data[15:8] ),
    .gmii_tx_en_B (sync_tx_valid[1]   ),
    .gmii_txd_C   (sync_tx_data[23:16]),
    .gmii_tx_en_C (sync_tx_valid[2]   ),
    .gmii_txd_D   (sync_tx_data[31:24]),
    .gmii_tx_en_D (sync_tx_valid[3]   ),

    .gmii_rxd_A   (sync_rx_data1  ),
    .gmii_rx_en_A (sync_rx_valid1 ),
    .gmii_rxd_B   (sync_rx_data2  ),
    .gmii_rx_en_B (sync_rx_valid2 ),
    .gmii_rxd_C   (sync_rx_data3  ),
    .gmii_rx_en_C (sync_rx_valid3 ),
    .gmii_rxd_D   (sync_rx_data4  ),
    .gmii_rx_en_D (sync_rx_valid4 ),
    .timestamp_tx_Pdelay_valid_cdc(timestamp_tx_Pdelay_valid_cdc),
    .timestamp_tx_Sync_valid_cdc  (timestamp_tx_Sync_valid_cdc  ),
    .timestamp_tx_Presp_valid_cdc (timestamp_tx_Presp_valid_cdc ),
    .timestamp_rx_Pdelay_valid_cdc(timestamp_rx_Pdelay_valid_cdc),
    .timestamp_rx_Sync_valid_cdc  (timestamp_rx_Sync_valid_cdc  ),
    .timestamp_rx_Presp_valid_cdc (timestamp_rx_Presp_valid_cdc )
);



assign sync_rx_data={sync_rx_data4,sync_rx_data3,sync_rx_data2,sync_rx_data1};
assign sync_rx_valid={sync_rx_valid4,sync_rx_valid3,sync_rx_valid2,sync_rx_valid1};


bc_top U_bc_top(
    .clk                       (clk_125M               ),
    .rst_n                     (sys_rst_n              ),

    .gmii_rxd                  (sync_rx_data           ),
    .gmii_rx_dv                (sync_rx_valid          ),
    .gmii_txd                  (sync_tx_data           ),
    .gmii_tx_en                (sync_tx_valid          ),
    
    .Priority1                 (Priority1_vio               ),
    .clockClass                (clockClass_vio              ),
    .clockAccuracy             (clockAccuracy_vio           ),
    .offsetScaledLogVariance   (offsetScaledLogVariance_vio ),
    .Priority2                 (Priority2_vio               ),
    .clockIdentity             (clockIdentity_vio           ),

    .LogInterval_sync          (LogInterval_sync_vio        ),
    .LogInterval_pdelay        (LogInterval_pdelay_vio      ),
    .LogInterval_announce      (LogInterval_announce_vio    ),
    .sys_sync                  (                            ), 
    .sys_time                  (                            ), 

    .timestamp_tx_Pdelay_valid_cdc(timestamp_tx_Pdelay_valid_cdc),
    .timestamp_tx_Sync_valid_cdc  (timestamp_tx_Sync_valid_cdc  ),
    .timestamp_tx_Presp_valid_cdc (timestamp_tx_Presp_valid_cdc ),
    .timestamp_rx_Pdelay_valid_cdc(timestamp_rx_Pdelay_valid_cdc),
    .timestamp_rx_Sync_valid_cdc  (timestamp_rx_Sync_valid_cdc  ),
    .timestamp_rx_Presp_valid_cdc (timestamp_rx_Presp_valid_cdc ),
    .pulse                        (pulse                        )
);


vio_0 clock_message (
  .clk(clk_125M),                // input wire clk
  .probe_out0(Priority1_vio               ),  // output wire [7 : 0] probe_out0
  .probe_out1(clockClass_vio              ),  // output wire [7 : 0] probe_out1
  .probe_out2(clockAccuracy_vio           ),  // output wire [7 : 0] probe_out2
  .probe_out3(offsetScaledLogVariance_vio ),  // output wire [15 : 0] probe_out3
  .probe_out4(Priority2_vio               ),  // output wire [7 : 0] probe_out4
  .probe_out5(clockIdentity_vio           ),  // output wire [63 : 0] probe_out5
  .probe_out6(Sync_period_vio             ),  // output wire [31 : 0] probe_out6
  .probe_out7(Pdelay_req_period_vio       ),  // output wire [31 : 0] probe_out7
  .probe_out8(Announce_period_vio         )   // output wire [31 : 0] probe_out8
  
);

endmodule
