`timescale 1ns / 1ps

module min_finder_tree #(
    parameter DATA_WIDTH = 64,
    parameter PORT_NUM   = 4    
)(
    input  logic                        clk,
    input  logic                        rst_n,
    
    // 控制接口
    input  logic                        start,      // 启动一次比较
    output logic                        busy,       // 指示正在计算中
    output logic                        valid_out,  // 结果有效脉冲

    // 数据接口
    input  logic [PORT_NUM:0]                 mask_in,
    input  logic [PORT_NUM:0][DATA_WIDTH-1:0] vals_in, 
    
    // 结果接口
    output logic [PORT_NUM:0]                 mask_out
);

    //==============================================================
    // 内部寄存器定义
    //==============================================================
    logic [$clog2(PORT_NUM+1):0]        cnt;          // 计数器，指示当前比到第几个端口
    logic [DATA_WIDTH-1:0]              current_min;  // 当前找到的最小值
    logic [PORT_NUM:0]                  current_mask; // 当前的赢家Mask
    
    // 输入锁存 (Input Latch) - 防止计算过程中输入变化导致错误
    logic [PORT_NUM:0][DATA_WIDTH-1:0]  latched_vals;
    logic [PORT_NUM:0]                  latched_mask_in;

    //==============================================================
    // 主状态机 / 计数器逻辑
    //==============================================================
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            busy         <= 1'b0;
            valid_out    <= 1'b0;
            cnt          <= '0;
            current_min  <= {DATA_WIDTH{1'b1}}; // 初始化为最大值
            current_mask <= '0;
            mask_out     <= '0;
            
            latched_vals    <= '0;
            latched_mask_in <= '0;
        end else begin
            // 默认拉低脉冲
            valid_out <= 1'b0;

            if (!busy) begin
                // --- IDLE 状态 ---
                if (start) begin
                    busy            <= 1'b1;
                    cnt             <= '0;
                    
                    // 初始化最小值
                    current_min     <= {DATA_WIDTH{1'b1}}; 
                    current_mask    <= '0;
                    
                    // 必须锁存输入！因为比较过程需要 N 个周期，
                    // 如果这期间外部 vals_in 变了，结果就乱了。
                    latched_vals    <= vals_in;
                    latched_mask_in <= mask_in;
                end
            end else begin
                // --- 比较状态 (RUNNING) ---
                
                // 核心比较逻辑：一个周期只比一个端口 (latched_vals[cnt])
                if (cnt <= PORT_NUM) begin
                    
                    // 1. 如果当前端口有效
                    if (latched_mask_in[cnt]) begin
                        
                        // 情况 A: 发现更小的值 -> 更新最小值，重置 Mask
                        if (latched_vals[cnt] < current_min) begin
                            current_min     <= latched_vals[cnt];
                            current_mask    <= (1'b1 << cnt); // 只有当前这位是1，其他清零
                        end 
                        
                        // 情况 B: 发现相等的值 (平局) -> 将当前位加入 Mask
                        else if (latched_vals[cnt] == current_min) begin
                            current_mask[cnt] <= 1'b1;
                        end
                        // 情况 C: 比当前最小值大 -> 不做任何事
                    end

                    // 计数器增加
                    cnt <= cnt + 1;
                    
                end else begin
                    // --- 结束状态 (DONE) ---
                    // 当计数器超过 PORT_NUM，说明所有端口都比完了
                    busy      <= 1'b0;
                    valid_out <= 1'b1;      // 输出完成脉冲
                    mask_out  <= current_mask; // 更新最终结果
                end
            end
        end
    end

endmodule