`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/06/10 14:52:44
// Design Name: 
// Module Name: port_manager
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module port_manager#
(
    parameter PORT_NUM = 4
)
(   
    input clk,
    input rst_n,
    input [$clog2(PORT_NUM + 1)-1:0] best_index,
    input                            best_valid,
    input                            receive_sync,
    input   [79:0]                   sys_time  ,
    input   [63:0]                   local_time,
    input   [79:0]                   best_offest,

    //发帧指令
    input   [7:0]    LogInterval_sync       ,
    input   [7:0]    LogInterval_pdelay     ,
    input   [7:0]    LogInterval_announce   ,

    output  reg  [PORT_NUM-1:0]     Pdelay_Req_en  ,
    output  reg  [PORT_NUM-1:0]     Sync_en        ,
    output  reg  [PORT_NUM-1:0]     Announce_en    ,
    output  reg       sys_sync 
        
);

localparam P_PASSIVE = 4'b0001;
localparam P_DISABLE = 4'b0010;
localparam P_MASTER  = 4'b0100;
localparam P_SLAVE   = 4'b1000;
localparam P_LISTEN  = 4'b1111;

parameter  SLAVE     = 2'b01;
parameter  MASTER    = 2'b10;
parameter  DISALE    = 2'b00;
parameter  period_ns = 8'h08;


reg [31:0] interval_ns_sync_val;
reg [31:0] interval_ns_pdelay_val;
reg [31:0] interval_ns_announce_val;

logic [31:0] cnt_sync_ns     [PORT_NUM];
logic [31:0] cnt_pdelay_ns   [PORT_NUM];
logic [31:0] cnt_announce_ns [PORT_NUM];
logic [3:0]  port_state_reg  [PORT_NUM];

always_ff@(posedge clk or negedge rst_n)begin
    if(!rst_n)begin
        for(int i = 0; i < PORT_NUM; i++)
            port_state_reg[i] <= P_LISTEN;
    end
    else if(best_valid)begin
        for(int i = 0; i < PORT_NUM; i++)begin
            if(best_index != 0)
                if(i == best_index - 1)
                    port_state_reg[i] <= P_SLAVE;
                else
                    port_state_reg[i] <= P_MASTER;  //仅与最佳主时钟连接的端口置主
            else
                port_state_reg[i] <= P_MASTER;  //最佳主时钟为自身则所有端口置主
        end
    end
end

//Sync,Pdelay_req,Announce帧产生使能 (基于1ms脉冲和周期参数)
genvar k;
generate
    for (k = 0; k < PORT_NUM; k++) begin : frame_en
    // --- A. Sync Message Generation ---
    // 条件：只有在 MASTER 状态下发送
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            cnt_sync_ns[k] <= 32'd0;
            Sync_en[k]     <= 1'b0;
        end
        else begin
            // 计数器累加
            if (cnt_sync_ns[k] >= interval_ns_sync_val) begin
                cnt_sync_ns[k] <= period_ns; // Reset to current step
                // 只有 Master 才发 Sync
                if (port_state_reg[k] == P_MASTER) 
                    Sync_en[k] <= 1'b1;
                else 
                    Sync_en[k] <= 1'b0;
            end
            else begin
                cnt_sync_ns[k] <= cnt_sync_ns[k] + period_ns;
                Sync_en[k]     <= 1'b0;
            end
        end
    end

    // --- B. Pdelay_Req Message Generation ---
    // 条件：只要端口没有 DISABLE 就可以发送 (Master/Slave/Passive 都需要测距)
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            cnt_pdelay_ns[k] <= 32'd0;
            Pdelay_Req_en[k] <= 1'b0;
        end
        else begin
            if (cnt_pdelay_ns[k] >= interval_ns_pdelay_val) begin
                cnt_pdelay_ns[k] <= period_ns;
                // Disable 状态不发包，其他状态通常都发送
                if (port_state_reg[k] != P_DISABLE) 
                    Pdelay_Req_en[k] <= 1'b1;      //始终产生发帧信号
                else 
                    Pdelay_Req_en[k] <= 1'b0;
            end
            else begin
                cnt_pdelay_ns[k] <= cnt_pdelay_ns[k] + period_ns;
                Pdelay_Req_en[k] <= 1'b0;
            end
        end
    end

    // --- C. Announce Message Generation ---
    // 条件：只有在 MASTER 状态下发送
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            cnt_announce_ns[k] <= 32'd0;
            Announce_en[k]     <= 1'b0;
        end
        else begin
            if (cnt_announce_ns[k] >= interval_ns_announce_val) begin
                cnt_announce_ns[k] <= period_ns;
                // 只有 Master 才发 Announce
                if (port_state_reg[k] == P_MASTER || port_state_reg[k] == P_LISTEN) 
                    Announce_en[k] <= 1'b1;
                else 
                    Announce_en[k] <= 1'b0;
            end
            else begin
                cnt_announce_ns[k] <= cnt_announce_ns[k] + period_ns;
                Announce_en[k]     <= 1'b0;
            end
        end
    end
end
endgenerate

function [31:0] log2ns;
    input [7:0] log_val;
    begin
        case(log_val)
            8'hFC: log2ns = 32'd62_500_000;      // -4: 62.5ms
            8'hFD: log2ns = 32'd125_000_000;     // -3: 125ms (Default Sync)
            8'hFE: log2ns = 32'd250_000_000;     // -2: 250ms
            8'hFF: log2ns = 32'd500_000_000;     // -1: 500ms
            8'h00: log2ns = 32'd1_000_000_000;   //  0: 1s (Default Pdelay/Announce)
            8'h01: log2ns = 32'd2_000_000_000;   // +1: 2s
            default: log2ns = 32'd1_000_000_000; // Default to 1s
        endcase
    end
endfunction

always @(*) begin
    interval_ns_sync_val     = log2ns(LogInterval_sync)    /125;
    interval_ns_pdelay_val   = log2ns(LogInterval_pdelay)  /125;
    interval_ns_announce_val = log2ns(LogInterval_announce)/125;
end



// ============================================================
// System Sync Status Logic (sys_sync)
// ============================================================

localparam LOCK_THRESHOLD_NS   = 32'd1000;  // Slave锁定阈值：1us
localparam UNLOCK_THRESHOLD_NS = 32'd2000;  // Slave失锁阈值：2us
localparam SLAVE_STABILITY_TGT = 4'd5;      // Slave稳定性计数目标
localparam MASTER_SYNC_TGT     = 4'd3;      // Master稳定性计数目标 (发送多少帧Sync认为稳定)

reg [3:0]  lock_stability_cnt;              // Slave用的稳定性计数器
reg [3:0]  master_sync_sent_cnt;            // Master用的发送计数器
wire [31:0] offset_ns = best_offest[31:0];  // 提取 Offset 的纳秒部分

// 辅助信号：判断是否有任意端口发送了 Sync 帧 (用于 Master 计数)
wire any_sync_sent = |Sync_en; 

// 辅助信号：当前是否作为 Slave 跟踪外部时钟
// (best_valid 为高 且 best_index 不为 0)
reg  is_slave_active;
reg  is_slave_active_f;
wire is_slave_active_change;
always@(posedge clk or negedge rst_n)begin
    if(!rst_n)
        is_slave_active <= 1'b0;
    else if(best_valid && (best_index != 0))
        is_slave_active <= 1'b1;
    else if(best_valid && (best_index == 0))
        is_slave_active <= 1'b0;
end


always@(posedge clk or negedge rst_n)begin
    if(!rst_n)
        is_slave_active_f <= 1'b0;
    else 
        is_slave_active_f <= is_slave_active;
end

assign is_slave_active_change = is_slave_active ^ is_slave_active_f;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        lock_stability_cnt   <= 4'd0;
        master_sync_sent_cnt <= 4'd0;
        sys_sync             <= 1'b0;
    end
    else begin
        // ----------------------------------------------------
        // Case A: 当前是 SLAVE 模式 (跟踪外部 Master)
        // ----------------------------------------------------
        if(is_slave_active_change) begin
            sys_sync             <= 1'b0; // 强制拉低 Sync
            lock_stability_cnt   <= 4'd0; // 清零 Slave 计数器
            master_sync_sent_cnt <= 4'd0; // 清零 Master 计数器
        end

        else if (is_slave_active) begin
            // 既然是 Slave，就清零 Master 的计数器
            master_sync_sent_cnt <= 4'd0;
            if (receive_sync) begin // 当收到 compute 模块算出的新纠偏值
                // 1. 尝试锁定 (Locking)
                if (sys_sync == 1'b0) begin
                    // 检查误差是否小于锁定阈值 (且这里假设关注的是绝对值，配合外部逻辑)
                    // OC 代码中 sign==0 代表正偏，sign==1 代表负偏。
                    // 通常锁定判断关注绝对误差，简单起见这里直接判断 offset_ns (magnitude)
                    if (offset_ns < LOCK_THRESHOLD_NS) begin
                        if (lock_stability_cnt < SLAVE_STABILITY_TGT)
                            lock_stability_cnt <= lock_stability_cnt + 1'b1;
                        else
                            sys_sync <= 1'b1; // 连续 N 次误差极小，置为锁定
                    end
                    else begin
                        lock_stability_cnt <= 4'd0; // 只要有一次超标，计数器清零
                    end
                end
                // 2. 锁定保持与失锁检测 (Unlock Detection)
                else begin
                    // 引入迟滞：如果误差突然变大超过失锁阈值，拉低 Sync
                    if (offset_ns > UNLOCK_THRESHOLD_NS) begin
                        sys_sync           <= 1'b0;
                        lock_stability_cnt <= 4'd0;
                    end
                end
            end
        end

        // ----------------------------------------------------
        // Case B: 当前是 MASTER 模式 (GM 或 Free-run)
        // ----------------------------------------------------
        else begin
            // 清零 Slave 计数器
            lock_stability_cnt <= 4'd0;

            // 逻辑：如果是刚切换到 Master (例如 Announce 超时导致 best_index 变 0)，
            // sys_sync 会因为 master_sync_sent_cnt 被复位而立即拉低 (符合需求)。
            // 只有当作为 Master 稳定发送了 N 帧 Sync 后，才重新拉高。

            if (any_sync_sent) begin
                if (master_sync_sent_cnt < MASTER_SYNC_TGT)
                    master_sync_sent_cnt <= master_sync_sent_cnt + 1'b1;
            end

            if (master_sync_sent_cnt >= MASTER_SYNC_TGT)
                sys_sync <= 1'b1; // Master 状态稳定
            else
                sys_sync <= 1'b0; // 刚切换或不稳定
        end
    end
end

endmodule