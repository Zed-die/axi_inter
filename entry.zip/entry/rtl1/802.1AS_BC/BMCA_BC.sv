`timescale 1ns / 1ps
//==============================================================================
// Module: BMCA_BC
// Description: Best Master Clock Algorithm (Serial Optimized for Timing)
//              Uses iterative comparators to eliminate setup violations.
//==============================================================================
module BMCA_BC #(
    parameter PORT_NUM = 4,
    parameter AGING_THRESHOLD = 32'd375000000 
)(
    input  logic                                  clk,
    input  logic                                  rst_n,
    
    // 输入接口
    input  logic [15:0] announce_in_currentUtcOffset        [PORT_NUM+1],
    input  logic [7:0]  announce_in_priority1               [PORT_NUM+1],
    input  logic [7:0]  announce_in_clockClass              [PORT_NUM+1],
    input  logic [7:0]  announce_in_clockAccuracy           [PORT_NUM+1],
    input  logic [15:0] announce_in_offsetScaledLogVariance [PORT_NUM+1],
    input  logic [7:0]  announce_in_priority2               [PORT_NUM+1],
    input  logic [63:0] announce_in_clockIdentity           [PORT_NUM+1],
    input  logic [15:0] announce_in_stepsRemoved            [PORT_NUM+1],

    input  logic [PORT_NUM:0]             announce_valid, 
    
    // 输出接口
    output logic [$clog2(PORT_NUM+1)-1:0] best_port_index,
    output logic                          best_valid,
    
    output logic [15:0] best_announce_currentUtcOffset,
    output logic [7:0]  best_announce_priority1,
    output logic [7:0]  best_announce_clockClass,
    output logic [7:0]  best_announce_clockAccuracy,
    output logic [15:0] best_announce_offsetScaledLogVariance,
    output logic [7:0]  best_announce_priority2,
    output logic [63:0] best_announce_clockIdentity,
    output logic [15:0] best_announce_stepsRemoved
);

    //==============================================================
    // 1. 接收缓冲与老化监控 (Rx Capture & Aging Monitor)
    //    (保持原有逻辑不变)
    //==============================================================
    logic [15:0] rx_regs_currentUtcOffset        [PORT_NUM+1];
    logic [7:0]  rx_regs_priority1               [PORT_NUM+1];
    logic [7:0]  rx_regs_clockClass              [PORT_NUM+1];
    logic [7:0]  rx_regs_clockAccuracy           [PORT_NUM+1];
    logic [15:0] rx_regs_offsetScaledLogVariance [PORT_NUM+1];
    logic [7:0]  rx_regs_priority2               [PORT_NUM+1];
    logic [63:0] rx_regs_clockIdentity           [PORT_NUM+1];
    logic [15:0] rx_regs_stepsRemoved            [PORT_NUM+1];

    logic [PORT_NUM:0] rx_alive;
    logic [31:0]       age_timer [PORT_NUM+1];
    logic              rx_event_pulse;

    // Rx Capture Logic (Copy form original code)
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            for (int i = 0; i < PORT_NUM + 1; i++) begin
                rx_regs_currentUtcOffset[i] <= '0; rx_regs_priority1[i] <= '0;
                rx_regs_clockClass[i] <= '0;       rx_regs_clockAccuracy[i] <= '0;
                rx_regs_offsetScaledLogVariance[i] <= '0; rx_regs_priority2[i] <= '0;
                rx_regs_clockIdentity[i] <= '0;    rx_regs_stepsRemoved[i] <= '0;
                rx_alive[i] <= 1'b0; age_timer[i] <= '0;
            end
            rx_event_pulse <= 1'b0;
        end else begin
            rx_event_pulse <= 1'b0;
            // Local Clock (Index 0)
            rx_regs_currentUtcOffset[0] <= announce_in_currentUtcOffset[0];
            rx_regs_priority1[0]        <= announce_in_priority1[0];
            rx_regs_clockClass[0]       <= announce_in_clockClass[0];
            rx_regs_clockAccuracy[0]    <= announce_in_clockAccuracy[0];
            rx_regs_offsetScaledLogVariance[0] <= announce_in_offsetScaledLogVariance[0];
            rx_regs_priority2[0]        <= announce_in_priority2[0];
            rx_regs_clockIdentity[0]    <= announce_in_clockIdentity[0];
            rx_regs_stepsRemoved[0]     <= announce_in_stepsRemoved[0];
            rx_alive[0] <= 1'b1;
            if (announce_valid[0]) rx_event_pulse <= 1'b1;

            // Network Ports (1~N)
            for (int i = 1; i < PORT_NUM + 1; i++) begin
                if (announce_valid[i]) begin
                    rx_regs_currentUtcOffset[i] <= announce_in_currentUtcOffset[i];
                    rx_regs_priority1[i]        <= announce_in_priority1[i];
                    rx_regs_clockClass[i]       <= announce_in_clockClass[i];
                    rx_regs_clockAccuracy[i]    <= announce_in_clockAccuracy[i];
                    rx_regs_offsetScaledLogVariance[i] <= announce_in_offsetScaledLogVariance[i];
                    rx_regs_priority2[i]        <= announce_in_priority2[i];
                    rx_regs_clockIdentity[i]    <= announce_in_clockIdentity[i];
                    rx_regs_stepsRemoved[i]     <= announce_in_stepsRemoved[i];
                    rx_alive[i]  <= 1'b1;
                    age_timer[i] <= '0;
                    rx_event_pulse <= 1'b1;
                end else if (rx_alive[i]) begin
                    if (age_timer[i] < AGING_THRESHOLD) age_timer[i] <= age_timer[i] + 1;
                    else begin
                        rx_alive[i] <= 1'b0;
                        rx_event_pulse <= 1'b1;
                    end
                end
            end
        end
    end

    //==============================================================
    // 2. 串行流水线控制 (Serial Pipeline Control)
    //==============================================================
    // 定义7级流水线 (合并了 ClockID 拆分)
    // S1: Prio1 -> S2: Class -> S3: Acc -> S4: Var -> S5: Prio2 -> S6: ID(64b) -> S7: Steps
    
    // 控制信号
    logic s1_start, s1_busy, s1_done;
    logic s2_start, s2_busy, s2_done;
    logic s3_start, s3_busy, s3_done;
    logic s4_start, s4_busy, s4_done;
    logic s5_start, s5_busy, s5_done;
    logic s6_start, s6_busy, s6_done;
    logic s7_start, s7_busy, s7_done;
    
    logic pipeline_busy;
    logic pending_trigger;
    logic fire_pipeline;
    
    // Mask 传递链
    logic [PORT_NUM:0] mask_initial;
    logic [PORT_NUM:0] mask_s1, mask_s2, mask_s3, mask_s4, mask_s5, mask_s6, mask_s7;

    // 数据快照 (Snapshot)
    // 只要 pipeline_busy 为高，Snapshot 就保持不变，供串行模块读取
    logic [15:0] snap_currentUtcOffset        [PORT_NUM+1];
    logic [7:0]  snap_priority1               [PORT_NUM+1];
    logic [7:0]  snap_clockClass              [PORT_NUM+1];
    logic [7:0]  snap_clockAccuracy           [PORT_NUM+1];
    logic [15:0] snap_offsetScaledLogVariance [PORT_NUM+1];
    logic [7:0]  snap_priority2               [PORT_NUM+1];
    logic [63:0] snap_clockIdentity           [PORT_NUM+1];
    logic [15:0] snap_stepsRemoved            [PORT_NUM+1];

    // 全局忙指示：任何一级在忙，都视为流水线忙
    assign pipeline_busy = s1_busy | s2_busy | s3_busy | s4_busy | s5_busy | s6_busy | s7_busy;

    // 触发逻辑：空闲时才响应
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) pending_trigger <= 0;
        else begin
            if (fire_pipeline) pending_trigger <= 0;
            else if (rx_event_pulse) pending_trigger <= 1;
        end
    end
    
    assign fire_pipeline = !pipeline_busy && (rx_event_pulse || pending_trigger);

    // 快照逻辑 & 启动 S1
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            s1_start <= 0;
            mask_initial <= '0;
        end else begin
            s1_start <= 0; // Pulse
            
            if (fire_pipeline) begin
                s1_start <= 1;
                mask_initial <= rx_alive;
                
                // 锁定数据快照
                snap_currentUtcOffset        <= rx_regs_currentUtcOffset;
                snap_priority1               <= rx_regs_priority1;
                snap_clockClass              <= rx_regs_clockClass;
                snap_clockAccuracy           <= rx_regs_clockAccuracy;
                snap_offsetScaledLogVariance <= rx_regs_offsetScaledLogVariance;
                snap_priority2               <= rx_regs_priority2;
                snap_clockIdentity           <= rx_regs_clockIdentity;
                snap_stepsRemoved            <= rx_regs_stepsRemoved;
            end
        end
    end

    //==============================================================
    // 3. 实例化串行比较器链
    //==============================================================

    // 打包数据辅助 logic
    logic [PORT_NUM:0][7:0]  packed_prio1;
    logic [PORT_NUM:0][7:0]  packed_class;
    logic [PORT_NUM:0][7:0]  packed_acc;
    logic [PORT_NUM:0][15:0] packed_var;
    logic [PORT_NUM:0][7:0]  packed_prio2;
    logic [PORT_NUM:0][63:0] packed_id;
    logic [PORT_NUM:0][15:0] packed_steps;
    
    always_comb begin
        for(int i=0; i<=PORT_NUM; i++) begin
            packed_prio1[i] = snap_priority1[i];
            packed_class[i] = snap_clockClass[i];
            packed_acc[i]   = snap_clockAccuracy[i];
            packed_var[i]   = snap_offsetScaledLogVariance[i];
            packed_prio2[i] = snap_priority2[i];
            packed_id[i]    = snap_clockIdentity[i];
            packed_steps[i] = snap_stepsRemoved[i];
        end
    end

    // --- Stage 1: Priority 1 ---
    min_finder_tree #(.DATA_WIDTH(8), .PORT_NUM(PORT_NUM)) u_serial_s1 (
        .clk(clk), .rst_n(rst_n),
        .start(s1_start), .busy(s1_busy), .valid_out(s1_done),
        .mask_in(mask_initial), .vals_in(packed_prio1), .mask_out(mask_s1)
    );

    // --- Stage 2: Clock Class ---
    // 级联控制：S1 完成触发 S2 开始
    assign s2_start = s1_done; 
    
    min_finder_tree #(.DATA_WIDTH(8), .PORT_NUM(PORT_NUM)) u_serial_s2 (
        .clk(clk), .rst_n(rst_n),
        .start(s2_start), .busy(s2_busy), .valid_out(s2_done),
        .mask_in(mask_s1), .vals_in(packed_class), .mask_out(mask_s2)
    );

    // --- Stage 3: Clock Accuracy ---
    assign s3_start = s2_done;
    
    min_finder_tree #(.DATA_WIDTH(8), .PORT_NUM(PORT_NUM)) u_serial_s3 (
        .clk(clk), .rst_n(rst_n),
        .start(s3_start), .busy(s3_busy), .valid_out(s3_done),
        .mask_in(mask_s2), .vals_in(packed_acc), .mask_out(mask_s3)
    );

    // --- Stage 4: Variance ---
    assign s4_start = s3_done;
    
    min_finder_tree #(.DATA_WIDTH(16), .PORT_NUM(PORT_NUM)) u_serial_s4 (
        .clk(clk), .rst_n(rst_n),
        .start(s4_start), .busy(s4_busy), .valid_out(s4_done),
        .mask_in(mask_s3), .vals_in(packed_var), .mask_out(mask_s4)
    );

    // --- Stage 5: Priority 2 ---
    assign s5_start = s4_done;
    
    min_finder_tree #(.DATA_WIDTH(8), .PORT_NUM(PORT_NUM)) u_serial_s5 (
        .clk(clk), .rst_n(rst_n),
        .start(s5_start), .busy(s5_busy), .valid_out(s5_done),
        .mask_in(mask_s4), .vals_in(packed_prio2), .mask_out(mask_s5)
    );

    // --- Stage 6: Clock Identity (64-bit) ---
    // 串行比较无视位宽，直接比 64 位，无需拆分！
    assign s6_start = s5_done;
    
    min_finder_tree #(.DATA_WIDTH(64), .PORT_NUM(PORT_NUM)) u_serial_s6 (
        .clk(clk), .rst_n(rst_n),
        .start(s6_start), .busy(s6_busy), .valid_out(s6_done),
        .mask_in(mask_s5), .vals_in(packed_id), .mask_out(mask_s6)
    );

    // --- Stage 7: Steps Removed ---
    assign s7_start = s6_done;
    
    min_finder_tree #(.DATA_WIDTH(16), .PORT_NUM(PORT_NUM)) u_serial_s7 (
        .clk(clk), .rst_n(rst_n),
        .start(s7_start), .busy(s7_busy), .valid_out(s7_done),
        .mask_in(mask_s6), .vals_in(packed_steps), .mask_out(mask_s7)
    );

    //==============================================================
    // 4. 最终输出选择 (Final Selection)
    //==============================================================
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            best_port_index <= '0;
            best_valid      <= 1'b0;
            best_announce_currentUtcOffset        <= '0;
            best_announce_priority1               <= '0;
            best_announce_clockClass              <= '0;
            best_announce_clockAccuracy           <= '0;
            best_announce_offsetScaledLogVariance <= '0;
            best_announce_priority2               <= '0;
            best_announce_clockIdentity           <= '0;
            best_announce_stepsRemoved            <= '0;
        end else begin
            best_valid <= 1'b0;
            
            // 当最后一级 (S7) 完成时
            if (s7_done) begin
                best_valid <= 1'b1;
                best_port_index <= '0; // Default

                // 输出快照中的数据（注意：数据来自 snap_xxx）
                // 此时 mask_s7 包含所有最优端口的 BitMap
                for (int i = 0; i < PORT_NUM + 1; i++) begin
                    if (mask_s7[i]) begin
                        best_port_index <= i[$clog2(PORT_NUM+1)-1:0];
                        
                        best_announce_currentUtcOffset        <= snap_currentUtcOffset[i];
                        best_announce_priority1               <= snap_priority1[i];
                        best_announce_clockClass              <= snap_clockClass[i];
                        best_announce_clockAccuracy           <= snap_clockAccuracy[i];
                        best_announce_offsetScaledLogVariance <= snap_offsetScaledLogVariance[i];
                        best_announce_priority2               <= snap_priority2[i];
                        best_announce_clockIdentity           <= snap_clockIdentity[i];
                        best_announce_stepsRemoved            <= snap_stepsRemoved[i];
                        
                        break; // 找到第一个即退出 (Priority to lower index)
                    end
                end
            end
        end
    end

endmodule