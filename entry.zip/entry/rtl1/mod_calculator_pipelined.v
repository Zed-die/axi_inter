




module mod_calculator_pipelined (
    input  wire        clk,
    input  wire        rst_n,
    input  wire [31:0] dividend,       // 被除数 (sys_time_ns)
    input  wire [31:0] divisor,        // 除数 (变除数)
    output reg  [31:0] remainder       // 余数 (local_clk_l)
);

    // 流水线寄存器定义
    reg [31:0] pipe_rem [0:32];
    reg [31:0] pipe_dvd [0:32];
    reg [31:0] pipe_dvs [0:32];

    genvar i;
    generate
        // --- Stage 0: 输入寄存 ---
        always @(posedge clk or negedge rst_n) begin
            if (!rst_n) begin
                pipe_rem[0] <= 32'd0;
                pipe_dvd[0] <= 32'd0;
                pipe_dvs[0] <= 32'd0;
            end else begin
                pipe_rem[0] <= 32'd0;       // 初始余数为0
                pipe_dvd[0] <= dividend;    // 载入被除数
                pipe_dvs[0] <= divisor;     // 载入除数
            end
        end

        // --- Stage 1 到 32: 迭代计算 ---
        for (i = 0; i < 32; i = i + 1) begin : stage_gen
            
            // 1. 移位后的临时余数: {当前余数[30:0], 被除数最高位}
            wire [31:0] next_rem_shifted;
            assign next_rem_shifted = {pipe_rem[i][30:0], pipe_dvd[i][31]};
            
            // 2. 试减逻辑 (33位以包含借位)
            wire [32:0] tmp_sub;
            assign tmp_sub = {1'b0, next_rem_shifted} - {1'b0, pipe_dvs[i]};
            
            // 3. 计算下一级余数 (组合逻辑)
            wire [31:0] next_rem_val;
            // 如果 tmp_sub[32] 为 0，说明结果 >= 0 (够减)，取减法结果
            // 否则 (不够减)，保持移位后的值
            assign next_rem_val = (!tmp_sub[32]) ? tmp_sub[31:0] : next_rem_shifted;

            // =========================================================
            // 时序逻辑：只负责打拍 (寄存器更新)
            // =========================================================
            always @(posedge clk or negedge rst_n) begin
                if (!rst_n) begin
                    pipe_rem[i+1] <= 32'd0;
                    pipe_dvd[i+1] <= 32'd0;
                    pipe_dvs[i+1] <= 32'd0;
                end else begin
                    // 更新余数
                    pipe_rem[i+1] <= next_rem_val;
                    
                    // 被除数左移
                    pipe_dvd[i+1] <= pipe_dvd[i] << 1;
                    
                    // 除数透传
                    pipe_dvs[i+1] <= pipe_dvs[i];
                end
            end
        end
    endgenerate

    // --- 输出级 ---
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            remainder <= 32'd0;
        end else begin
            remainder <= pipe_rem[32];
        end
    end

endmodule