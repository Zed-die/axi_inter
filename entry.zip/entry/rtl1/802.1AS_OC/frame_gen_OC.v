`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/01/13 11:08:03
// Design Name: 
// Module Name: frame_gen_OC
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module frame_gen_OC(
    input      clk                     ,
    input      rst_n                   ,
    input      sync_gen                ,
    input      pdelay_gen              ,
    input      announce_gen            ,
    input      two_step_flag           ,
    input      [79:0]     timer        ,
    input      [79:0]     sys_time     ,

    //输入参数
    input      [79:0]     clockIdentity           ,
    input      [7:0]      LogInterval_sync        ,
    input      [7:0]      LogInterval_pdelay      ,
    input      [7:0]      LogInterval_announce    ,
    input      [79:0]     pdelay_portIdentity     ,
    input                 pdelay_valid            ,   

    input      [15:0]     currentUtcOffset        ,
    input      [7:0]      grandmasterPriority1    ,
    input      [31:0]     grandmasterClockQuality ,
    input      [7:0]      grandmasterPriority2    ,
    input      [63:0]     grandmasterIdentity     ,

    //时间戳信息
    input                 timestamp_tx_Sync_valid_cdc  ,
    input                 timestamp_rx_Pdelay_valid_cdc,
    input                 timestamp_tx_Presp_valid_cdc ,

    //输出
    output     [7:0]      dout                    ,
    output                dout_valid

    );


//*******************
//DEFINE LOCAL PARAMETER
//*******************
localparam Preamble = 56'h55_55_55_55_55_55_55;
localparam SFD = 8'hd5;
localparam [47:0] DA_MAC = 48'h01_80_C2_00_00_0E;
localparam [47:0] SA_MAC = 48'h11_22_33_44_55_66;


localparam EtherType  = 16'h88f7;
localparam TranSpec   = 4'h1;

localparam MsgType_Sync = 4'h0;
localparam MsgType_Pdelay_Req = 4'h2;
localparam MsgType_Pdelay_Resp = 4'h3;
localparam MsgType_Announce = 4'hb;
localparam MsgType_Sync_follow  = 4'h8;
localparam MsgType_Presp_follow = 4'ha;

localparam VerPTP = 8'h02;  //ptp版本

localparam MsgLength_Sync               = 16'h002c;//'d44
localparam MsgLength_Sync_follow        = 16'h002c;//'d44
localparam MsgLength_Pdelay_Req         = 16'h0036;//'d54
localparam MsgLength_Pdelay_Resp        = 16'h0036;//'d54
localparam MsgLength_Pdelay_Resp_follow = 16'h0036;//'d54
localparam MsgLength_Announce           = 16'h0040;  //'d64

localparam DomainNumber = 8'h0;//8'h04;//用户定     域的值是8'd4——8'd127
localparam LogInterval_presp = 8'b0;

//spec规定
localparam controlField_Sync = 8'h00;
localparam controlField_Sync_follow = 8'h02;
localparam controlField_Pdelay_Req = 8'h05;
localparam controlField_Pdelay_Resp = 8'h05;
localparam controlField_Pdelay_Resp_follow = 8'h05;
localparam controlField_Announce = 8'h05;

localparam [63:0] correctionfield = 64'h0;  //高 48 位：表示纳秒的整数部分。低 16 位：表示纳秒的小数部分。
localparam stepsRemoved = 16'h0;  //转发级数
localparam timeSource   = 8'hA0;  //时钟来自内部晶振

//固定优先级仲裁状态机
localparam S_IDLE          = 4'd0;
localparam S_SEND_SYNC     = 4'd1;
localparam S_SEND_SYNC_F   = 4'd2;
localparam S_SEND_PD_REQ   = 4'd3;
localparam S_SEND_PD_RESP  = 4'd4;
localparam S_SEND_PD_RESP_F= 4'd5;
localparam S_SEND_ANNOUNCE = 4'd6;
localparam S_IFG_WAIT      = 4'd7;

//帧间隔
localparam IFG_CYCLES      = 8'd100; 

reg sync_gen_flag,sync_follow_gen_flag;
reg presp_gen_flag,presp_follow_gen_flag;
reg pdelay_gen_flag,announce_gen_flag;
reg [4:0] sync_cnt,sync_follow_cnt,pdelay_cnt,presp_cnt,presp_follow_cnt,announce_cnt;

reg           s_sync_axis_tvalid;
wire          s_sync_axis_tready;
reg   [63:0]  s_sync_axis_tdata ;
reg   [7:0]   s_sync_axis_tkeep ;
reg           s_sync_axis_tlast ;

reg           s_sync_follow_axis_tvalid;
wire          s_sync_follow_axis_tready;
reg [63:0]    s_sync_follow_axis_tdata ;
reg [7:0]     s_sync_follow_axis_tkeep ;
reg           s_sync_follow_axis_tlast ;

reg           s_pdelay_axis_tvalid;
wire          s_pdelay_axis_tready;
reg [63:0]    s_pdelay_axis_tdata ;
reg [7:0]     s_pdelay_axis_tkeep ;
reg           s_pdelay_axis_tlast ;

reg           s_presp_axis_tvalid;
wire          s_presp_axis_tready;
reg [63:0]    s_presp_axis_tdata ;
reg [7:0]     s_presp_axis_tkeep ;
reg           s_presp_axis_tlast ;

reg           s_presp_follow_axis_tvalid;
wire          s_presp_follow_axis_tready;
reg [63:0]    s_presp_follow_axis_tdata ;
reg [7:0]     s_presp_follow_axis_tkeep ;
reg           s_presp_follow_axis_tlast ;

reg           s_announce_axis_tvalid;
wire          s_announce_axis_tready;
reg [63:0]    s_announce_axis_tdata ;
reg [7:0]     s_announce_axis_tkeep ;
reg           s_announce_axis_tlast ;

reg           din_convert_axis_tvalid;
wire          din_convert_axis_tready;
reg [63:0]    din_convert_axis_tdata ;
reg [7:0]     din_convert_axis_tkeep ;
reg           din_convert_axis_tlast ;

wire          m_sync_axis_tvalid ;
reg           m_sync_axis_tready ;
wire [63:0]   m_sync_axis_tdata  ;
wire [7:0]    m_sync_axis_tkeep  ;
wire          m_sync_axis_tlast  ;

wire          m_sync_follow_axis_tvalid ;
reg           m_sync_follow_axis_tready ;
wire [63:0]   m_sync_follow_axis_tdata  ;
wire [7:0]    m_sync_follow_axis_tkeep  ;
wire          m_sync_follow_axis_tlast  ;

wire          m_pdelay_axis_tvalid ;
reg           m_pdelay_axis_tready ;
wire [63:0]   m_pdelay_axis_tdata  ;
wire [7:0]    m_pdelay_axis_tkeep  ;
wire          m_pdelay_axis_tlast  ;

wire          m_presp_axis_tvalid ;
reg           m_presp_axis_tready ;
wire [63:0]   m_presp_axis_tdata  ;
wire [7:0]    m_presp_axis_tkeep  ;
wire          m_presp_axis_tlast  ;

wire          m_presp_follow_axis_tvalid ;
reg           m_presp_follow_axis_tready ;
wire [63:0]   m_presp_follow_axis_tdata  ;
wire [7:0]    m_presp_follow_axis_tkeep  ;
wire          m_presp_follow_axis_tlast  ;

wire          m_announce_axis_tvalid ;
reg           m_announce_axis_tready ;
wire [63:0]   m_announce_axis_tdata  ;
wire [7:0]    m_announce_axis_tkeep  ;
wire          m_announce_axis_tlast  ;

reg [15:0]    sync_sequenceID;
reg [15:0]    pdelay_sequenceID;
reg [15:0]    presp_sequenceID;
reg [15:0]    announce_sequenceID;

wire [63:0] s_sync_axis_order_tdata;
wire [63:0] s_sync_follow_axis_order_tdata;
wire [63:0] s_pdelay_axis_order_tdata;
wire [63:0] s_presp_axis_order_tdata;
wire [63:0] s_presp_follow_axis_order_tdata;
wire [63:0] s_announce_axis_order_tdata;


reg [3:0] arb_state;
reg [7:0] ifg_cnt;

//时间戳信息
reg [79:0] sync_tx_time;
reg [79:0] pdelay_rx_time;
reg [79:0] presp_tx_time;
reg [79:0] pdelay_portIdentity_reg;

wire       dout_valid_convert ;                  
wire [7:0] dout_convert       ;                           
wire       dout_convert_last  ; 

reg  dout_valid_convert_ff;
wire dout_valid_convert_pos;
reg  [7:0] CRC_cnt;
reg  CRC_en;
reg  [3:0] CRC_rd_shift;
wire CRC_rd;
wire [7:0] CRC_out;

wire sync_follow_gen, presp_gen, presp_follow_gen;

assign presp_gen = pdelay_valid;
assign sync_follow_gen = timestamp_tx_Sync_valid_cdc && two_step_flag;
assign presp_follow_gen = timestamp_tx_Presp_valid_cdc && two_step_flag;

//spec规定两步法时第一个字节的bit1应该置1
wire [15:0] FlagField;
assign FlagField = two_step_flag ? 16'h0002 :16'h0000;


always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        sync_sequenceID <= 16'b0;
    end
    else if (sync_gen) begin
        sync_sequenceID <= sync_sequenceID + 1;
    end
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        pdelay_sequenceID <= 16'b0;
    end
    else if (pdelay_gen) begin
        pdelay_sequenceID <= pdelay_sequenceID + 1;
    end
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        presp_sequenceID <= 16'b0;
    end
    else if (presp_gen) begin
        presp_sequenceID <= presp_sequenceID + 1;
    end
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        announce_sequenceID <= 16'b0;
    end
    else if (announce_gen) begin
        announce_sequenceID <= announce_sequenceID + 1;
    end
end

//时间戳获取
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        sync_tx_time <= 80'b0;
    end
    else if(timestamp_tx_Sync_valid_cdc) begin
        sync_tx_time <= sys_time;
    end
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        pdelay_rx_time <= 80'b0;
    end
    else if(timestamp_rx_Pdelay_valid_cdc)begin
        pdelay_rx_time <= timer;
    end
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        presp_tx_time <= 80'b0;
    end
    else if(timestamp_tx_Presp_valid_cdc)begin
        presp_tx_time <= timer;
    end
end

//portidentity产生逻辑
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        pdelay_portIdentity_reg <= 80'b0;
    end
    else if(pdelay_valid)begin
        pdelay_portIdentity_reg <= pdelay_portIdentity;
    end
end

//Sync帧产生逻辑
always@(posedge clk or negedge rst_n)begin
    if(!rst_n)
        sync_gen_flag <= 1'b0;
    else if(sync_gen)
        sync_gen_flag <= 1'b1;
    else if(s_sync_axis_tlast)
        sync_gen_flag <= 1'b0;
end

always@(posedge clk or negedge rst_n)begin
    if(!rst_n)
        sync_cnt <= 4'b0;
    else if(s_sync_axis_tlast)
        sync_cnt <= 4'b0;
    else if(sync_gen_flag)
        sync_cnt <= sync_cnt + 1'b1;
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        s_sync_axis_tvalid <= 1'b0;
        s_sync_axis_tdata  <= 64'b0;
        s_sync_axis_tkeep  <= 8'b0;
        s_sync_axis_tlast  <= 1'b0;
    end
    else if (sync_gen_flag) begin
        case (sync_cnt)
            4'h0: begin s_sync_axis_tdata <= {Preamble, SFD};s_sync_axis_tvalid <= 1'b1;s_sync_axis_tkeep <= 8'hff;s_sync_axis_tlast <= 1'b0; end
            4'h1: s_sync_axis_tdata <= {DA_MAC, SA_MAC[47:32]};
            4'h2: s_sync_axis_tdata <= {SA_MAC[31:0], EtherType, TranSpec, MsgType_Sync, VerPTP};
            4'h3: s_sync_axis_tdata <= {MsgLength_Sync, DomainNumber, 8'h0, FlagField, correctionfield[63:48]};
            4'h4: s_sync_axis_tdata <= {correctionfield[47:0], 16'h0};
            4'h5: s_sync_axis_tdata <= {16'h0, clockIdentity[79:32]};
            4'h6: s_sync_axis_tdata <= {clockIdentity[31:0], sync_sequenceID, controlField_Sync, LogInterval_sync};
            4'h7: s_sync_axis_tdata <= 64'h0; 
            4'h8: begin s_sync_axis_tdata <= 64'h0; s_sync_axis_tkeep <= 8'b0000_1111; s_sync_axis_tlast <= 1'b1;end
            4'h9: begin s_sync_axis_tdata <= 64'h0; s_sync_axis_tkeep <= 8'h0; s_sync_axis_tvalid<= 1'b0;s_sync_axis_tlast <= 1'b0;end
        endcase
    end
end

//Sync_follow帧产生逻辑
always@(posedge clk or negedge rst_n) begin
    if(!rst_n) 
        sync_follow_gen_flag <= 1'b0;
    else if(sync_follow_gen) 
        sync_follow_gen_flag <= 1'b1; 
    else if(s_sync_follow_axis_tlast)
        sync_follow_gen_flag <= 1'b0;
end

always@(posedge clk or negedge rst_n) begin
    if(!rst_n) 
        sync_follow_cnt <= 5'b0;
    else if(s_sync_follow_axis_tlast) 
        sync_follow_cnt <= 5'b0;
    else if(sync_follow_gen_flag) 
        sync_follow_cnt <= sync_follow_cnt + 1'b1;
end

// // --- 数据发送逻辑 ---
// always @(posedge clk or negedge rst_n) begin
//     if (!rst_n) begin
//         s_sync_follow_axis_tvalid <= 1'b0;
//         s_sync_follow_axis_tdata  <= 64'b0;
//         s_sync_follow_axis_tkeep  <= 8'b0;
//         s_sync_follow_axis_tlast  <= 1'b0;
//     end
//     else if (sync_follow_gen_flag) begin
//         case (sync_follow_cnt)
//             5'h0: begin s_sync_follow_axis_tdata <= {Preamble, SFD}; s_sync_follow_axis_tvalid <= 1'b1; s_sync_follow_axis_tkeep <= 8'hff; s_sync_follow_axis_tlast <= 1'b0; end
//             5'h1: s_sync_follow_axis_tdata <= {DA_MAC, SA_MAC[47:32]};
//             5'h2: s_sync_follow_axis_tdata <= {SA_MAC[31:0], EtherType, TranSpec, MsgType_Sync_follow, VerPTP};
//             5'h3: s_sync_follow_axis_tdata <= {MsgLength_Sync_follow, DomainNumber, 8'h0, FlagField, correctionfield[63:48]};
//             5'h4: s_sync_follow_axis_tdata <= {correctionfield[47:0], 16'h0};
//             5'h5: s_sync_follow_axis_tdata <= {16'h0, clockIdentity[79:32]};
//             5'h6: s_sync_follow_axis_tdata <= {clockIdentity[31:0], sync_sequenceID, controlField_Sync_follow, LogInterval_sync};
//             5'h7: s_sync_follow_axis_tdata <= sync_tx_time[79:16]; // 放 timestamp[79:16]
//             5'h8: begin s_sync_follow_axis_tdata <= {sync_tx_time[15:0], 48'h0}; s_sync_follow_axis_tkeep <= 8'b0000_0011; s_sync_follow_axis_tlast <= 1'b1;end
//             5'h9: begin s_sync_follow_axis_tdata <= 64'h0; s_sync_follow_axis_tkeep <= 8'h0; s_sync_follow_axis_tvalid <= 1'b0; s_sync_follow_axis_tlast <= 1'b0; end
//         endcase
//     end
// end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        s_sync_follow_axis_tvalid <= 1'b0;
        s_sync_follow_axis_tdata  <= 64'b0;
        s_sync_follow_axis_tkeep  <= 8'b0;
        s_sync_follow_axis_tlast  <= 1'b0;
    end
    else if (sync_follow_gen_flag) begin
        case (sync_follow_cnt)
            5'h0: begin s_sync_follow_axis_tdata <= {Preamble, SFD}; s_sync_follow_axis_tvalid <= 1'b1; s_sync_follow_axis_tkeep <= 8'hff; s_sync_follow_axis_tlast <= 1'b0; end
            5'h1: s_sync_follow_axis_tdata <= {DA_MAC, SA_MAC[47:32]};
            5'h2: s_sync_follow_axis_tdata <= {SA_MAC[31:0], EtherType, TranSpec, MsgType_Sync_follow, 8'h12};
            5'h3: s_sync_follow_axis_tdata <= {MsgLength_Sync_follow, DomainNumber, 8'h0, 16'b0, correctionfield[63:48]};
            5'h4: s_sync_follow_axis_tdata <= {correctionfield[47:0], 16'h0};
            5'h5: s_sync_follow_axis_tdata <= {16'h0, clockIdentity[79:32]};
            5'h6: s_sync_follow_axis_tdata <= {clockIdentity[31:0], sync_sequenceID, controlField_Sync_follow, LogInterval_sync};
            5'h7: s_sync_follow_axis_tdata <= sync_tx_time[79:16]; // �? timestamp[79:16]
            5'h8: begin s_sync_follow_axis_tdata <= {sync_tx_time[15:0], 48'h0003001c0080}; end
            5'h9: begin s_sync_follow_axis_tdata <= {32'hc2000001,32'h0}; end
            5'hA: begin s_sync_follow_axis_tdata <= 0; end
            5'hB: begin s_sync_follow_axis_tdata <= 0; end
            5'hC: begin s_sync_follow_axis_tdata <= 0; s_sync_follow_axis_tkeep <= 8'b0000_0011; s_sync_follow_axis_tlast <= 1'b1;end
            5'hD: begin s_sync_follow_axis_tdata <= 64'h0; s_sync_follow_axis_tkeep <= 8'h0; s_sync_follow_axis_tvalid <= 1'b0; s_sync_follow_axis_tlast <= 1'b0; end
        endcase
    end
end

//Pdelay帧产生逻辑
always@(posedge clk or negedge rst_n)begin
    if(!rst_n)
        pdelay_gen_flag <= 1'b0;
    else if(pdelay_gen)
        pdelay_gen_flag <= 1'b1;
    else if(s_pdelay_axis_tlast)
        pdelay_gen_flag <= 1'b0;
end

always@(posedge clk or negedge rst_n)begin
    if(!rst_n)
        pdelay_cnt <= 4'b0;
    else if(s_pdelay_axis_tlast)
        pdelay_cnt <= 4'b0;
    else if(pdelay_gen_flag)
        pdelay_cnt <= pdelay_cnt + 1'b1;
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        s_pdelay_axis_tvalid <= 1'b0;
        s_pdelay_axis_tdata  <= 64'b0;
        s_pdelay_axis_tkeep  <= 8'b0;
        s_pdelay_axis_tlast  <= 1'b0;
    end
    else if (pdelay_gen_flag) begin
        case (pdelay_cnt)
            4'h0: begin s_pdelay_axis_tdata <= {Preamble, SFD};s_pdelay_axis_tvalid <= 1'b1;s_pdelay_axis_tkeep <= 8'hff;s_pdelay_axis_tlast <= 1'b0; end
            4'h1: s_pdelay_axis_tdata <= {DA_MAC, SA_MAC[47:32]};
            4'h2: s_pdelay_axis_tdata <= {SA_MAC[31:0], EtherType, TranSpec, MsgType_Pdelay_Req, VerPTP};
            4'h3: s_pdelay_axis_tdata <= {MsgLength_Pdelay_Req, DomainNumber, 8'h0, FlagField, correctionfield[63:48]};
            4'h4: s_pdelay_axis_tdata <= {correctionfield[47:0], 16'h0};
            4'h5: s_pdelay_axis_tdata <= {16'h0, clockIdentity[79:32]};
            4'h6: s_pdelay_axis_tdata <= {clockIdentity[31:0], pdelay_sequenceID, controlField_Pdelay_Req, LogInterval_pdelay};
            4'h7: s_pdelay_axis_tdata <= 64'h0; 
            4'h8: s_pdelay_axis_tdata <= 64'h0; 
            4'h9: begin s_pdelay_axis_tdata <= 64'h0; s_pdelay_axis_tkeep <= 8'b0000_1111; s_pdelay_axis_tlast <= 1'b1;end   //补充了2个10字节的0，为了与presp报文长度一致可以使物理传输尽量对称
            4'ha: begin s_pdelay_axis_tdata <= 64'h0; s_pdelay_axis_tkeep <= 8'h0; s_pdelay_axis_tvalid<= 1'b0;s_pdelay_axis_tlast <= 1'b0;end
        endcase
    end
end

//Pdelay_resp帧产生逻辑
always@(posedge clk or negedge rst_n) begin
    if(!rst_n) 
        presp_gen_flag <= 1'b0;
    else if(presp_gen) 
        presp_gen_flag <= 1'b1;
    else if(s_presp_axis_tlast) 
        presp_gen_flag <= 1'b0;
end

always@(posedge clk or negedge rst_n) begin
    if(!rst_n) 
        presp_cnt <= 5'b0;
    else if(s_presp_axis_tlast) 
        presp_cnt <= 5'b0;
    else if(presp_gen_flag) 
        presp_cnt <= presp_cnt + 1'b1;
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        s_presp_axis_tvalid <= 1'b0;
        s_presp_axis_tdata  <= 64'b0;
        s_presp_axis_tkeep  <= 8'b0;
        s_presp_axis_tlast  <= 1'b0;
    end
    else if (presp_gen_flag) begin
        case (presp_cnt)
            // --- Header ---
            5'h0: begin s_presp_axis_tdata <= {Preamble, SFD}; s_presp_axis_tvalid <= 1'b1; s_presp_axis_tkeep <= 8'hff; s_presp_axis_tlast <= 1'b0; end
            5'h1: s_presp_axis_tdata <= {DA_MAC, SA_MAC[47:32]};
            5'h2: s_presp_axis_tdata <= {SA_MAC[31:0], EtherType, TranSpec, MsgType_Pdelay_Resp, VerPTP};
            5'h3: s_presp_axis_tdata <= {MsgLength_Pdelay_Resp, DomainNumber, 8'h0, FlagField, correctionfield[63:48]};
            5'h4: s_presp_axis_tdata <= {correctionfield[47:0], 16'h0};
            5'h5: s_presp_axis_tdata <= {16'h0, clockIdentity[79:32]};
            5'h6: s_presp_axis_tdata <= {clockIdentity[31:0], presp_sequenceID, controlField_Pdelay_Resp, LogInterval_presp};
            5'h7: s_presp_axis_tdata <= pdelay_rx_time[79:16]; 
            5'h8: s_presp_axis_tdata <= {pdelay_rx_time[15:0],pdelay_portIdentity_reg[79:32]}; 
            5'h9: begin s_presp_axis_tdata <= {pdelay_portIdentity_reg[31:0], 32'h0}; s_presp_axis_tkeep <= 8'b0000_1111; s_presp_axis_tlast <= 1'b1;end
            5'ha: begin s_presp_axis_tdata <= 64'h0; s_presp_axis_tkeep <= 8'h0; s_presp_axis_tvalid <= 1'b0; s_presp_axis_tlast <= 1'b0; end
        endcase
    end
end

//Pdelay_resp_follow帧产生逻辑
always@(posedge clk or negedge rst_n) begin
    if(!rst_n) 
        presp_follow_gen_flag <= 1'b0;
    else if(presp_follow_gen) 
        presp_follow_gen_flag <= 1'b1; 
    else if(s_presp_follow_axis_tlast) 
        presp_follow_gen_flag <= 1'b0;
end

always@(posedge clk or negedge rst_n) begin
    if(!rst_n) 
        presp_follow_cnt <= 5'b0;
    else if(s_presp_follow_axis_tlast) 
        presp_follow_cnt <= 5'b0;
    else if(presp_follow_gen_flag) 
        presp_follow_cnt <= presp_follow_cnt + 1'b1;
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        s_presp_follow_axis_tvalid <= 1'b0;
        s_presp_follow_axis_tdata  <= 64'b0;
        s_presp_follow_axis_tkeep  <= 8'b0;
        s_presp_follow_axis_tlast  <= 1'b0;
    end
    else if (presp_follow_gen_flag) begin
        case (presp_follow_cnt)
            5'h0: begin s_presp_follow_axis_tdata <= {Preamble, SFD}; s_presp_follow_axis_tvalid <= 1'b1; s_presp_follow_axis_tkeep <= 8'hff; s_presp_follow_axis_tlast <= 1'b0; end
            5'h1: s_presp_follow_axis_tdata <= {DA_MAC, SA_MAC[47:32]};
            5'h2: s_presp_follow_axis_tdata <= {SA_MAC[31:0], EtherType, TranSpec, MsgType_Presp_follow, VerPTP};
            5'h3: s_presp_follow_axis_tdata <= {MsgLength_Pdelay_Resp_follow, DomainNumber, 8'h0, FlagField, correctionfield[63:48]};
            5'h4: s_presp_follow_axis_tdata <= {correctionfield[47:0], 16'h0};
            5'h5: s_presp_follow_axis_tdata <= {16'h0, clockIdentity[79:32]};
            5'h6: s_presp_follow_axis_tdata <= {clockIdentity[31:0], presp_sequenceID, controlField_Pdelay_Resp_follow, LogInterval_presp}; //序列号通常与 Presp 一致
            5'h7: s_presp_follow_axis_tdata <= presp_tx_time[79:16]; 
            5'h8: s_presp_follow_axis_tdata <= {presp_tx_time[15:0],pdelay_portIdentity_reg[79:32]}; 
            5'h9: begin s_presp_follow_axis_tdata <= {pdelay_portIdentity_reg[31:0], 32'h0}; s_presp_follow_axis_tkeep <= 8'b0000_1111; s_presp_follow_axis_tlast <= 1'b1;end
            5'ha: begin s_presp_follow_axis_tdata <= 64'h0; s_presp_follow_axis_tkeep <= 8'h0; s_presp_follow_axis_tvalid <= 1'b0; s_presp_follow_axis_tlast <= 1'b0; end
        endcase
    end
end

always@(posedge clk or negedge rst_n) begin
    if(!rst_n) 
        announce_gen_flag <= 1'b0;
    else if(announce_gen) 
        announce_gen_flag <= 1'b1;
    else if(s_announce_axis_tlast) 
        announce_gen_flag <= 1'b0;
end

always@(posedge clk or negedge rst_n) begin
    if(!rst_n) 
        announce_cnt <= 5'b0;
    else if(s_announce_axis_tlast) 
        announce_cnt <= 5'b0;
    else if(announce_gen_flag)
        announce_cnt <= announce_cnt + 1'b1;
end

// --- 数据发送逻辑 ---
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        s_announce_axis_tvalid <= 1'b0;
        s_announce_axis_tdata  <= 64'b0;
        s_announce_axis_tkeep  <= 8'b0;
        s_announce_axis_tlast  <= 1'b0;
    end
    else if (announce_gen_flag) begin
        case (announce_cnt)
            // --- Header ---
            5'h0: begin s_announce_axis_tdata <= {Preamble, SFD}; s_announce_axis_tvalid <= 1'b1; s_announce_axis_tkeep <= 8'hff; s_announce_axis_tlast <= 1'b0; end
            5'h1: s_announce_axis_tdata <= {DA_MAC, SA_MAC[47:32]};
            5'h2: s_announce_axis_tdata <= {SA_MAC[31:0], EtherType, TranSpec, MsgType_Announce, VerPTP};
            5'h3: s_announce_axis_tdata <= {MsgLength_Announce, DomainNumber, 8'h0, FlagField, correctionfield[63:48]};
            5'h4: s_announce_axis_tdata <= {correctionfield[47:0], 16'h0};
            5'h5: s_announce_axis_tdata <= {16'h0, clockIdentity[79:32]};
            5'h6: s_announce_axis_tdata <= {clockIdentity[31:0], announce_sequenceID, controlField_Announce, LogInterval_announce}; 
            5'h7: s_announce_axis_tdata <= 64'h0; 
            5'h8: s_announce_axis_tdata <= {16'h0, currentUtcOffset, 8'h0, grandmasterPriority1, grandmasterClockQuality[31:16]};
            5'h9: s_announce_axis_tdata <= {grandmasterClockQuality[15:0], grandmasterPriority2, grandmasterIdentity[63:24]};
            5'ha: begin s_announce_axis_tdata <= {grandmasterIdentity[23:0], stepsRemoved, timeSource, 16'h0};s_announce_axis_tkeep <= 8'b0011_1111; s_announce_axis_tlast <= 1'b1;end
            5'hb: begin s_announce_axis_tdata <= 64'h0; s_announce_axis_tkeep <= 8'h0; s_announce_axis_tvalid <= 1'b0; s_announce_axis_tlast <= 1'b0; end
        endcase
    end
end

// 状态机逻辑
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        arb_state <= S_IDLE;
        ifg_cnt   <= 8'd0;
    end
    else begin
        case (arb_state)
            S_IDLE: begin
                if (m_sync_axis_tvalid) 
                    arb_state <= S_SEND_SYNC;
                else if (m_sync_follow_axis_tvalid) 
                    arb_state <= S_SEND_SYNC_F;
                else if (m_pdelay_axis_tvalid) 
                    arb_state <= S_SEND_PD_REQ;
                else if (m_presp_axis_tvalid) 
                    arb_state <= S_SEND_PD_RESP;
                else if (m_presp_follow_axis_tvalid) 
                    arb_state <= S_SEND_PD_RESP_F;
                else if (m_announce_axis_tvalid) 
                    arb_state <= S_SEND_ANNOUNCE;
                else 
                    arb_state <= S_IDLE;
            end
            // --- 发送状态：等待握手成功且遇到 tlast ---
            S_SEND_SYNC: begin
                if (din_convert_axis_tready && m_sync_axis_tvalid && m_sync_axis_tlast)
                    arb_state <= S_IFG_WAIT;
            end

            S_SEND_SYNC_F: begin
                if (din_convert_axis_tready && m_sync_follow_axis_tvalid && m_sync_follow_axis_tlast)
                    arb_state <= S_IFG_WAIT;
            end

            S_SEND_PD_REQ: begin
                if (din_convert_axis_tready && m_pdelay_axis_tvalid && m_pdelay_axis_tlast)
                    arb_state <= S_IFG_WAIT;
            end

            S_SEND_PD_RESP: begin
                if (din_convert_axis_tready && m_presp_axis_tvalid && m_presp_axis_tlast)
                    arb_state <= S_IFG_WAIT;
            end

            S_SEND_PD_RESP_F: begin
                if (din_convert_axis_tready && m_presp_follow_axis_tvalid && m_presp_follow_axis_tlast)
                    arb_state <= S_IFG_WAIT;
            end

            S_SEND_ANNOUNCE: begin
                if (din_convert_axis_tready && m_announce_axis_tvalid && m_announce_axis_tlast)
                    arb_state <= S_IFG_WAIT;
            end

            // --- 帧间隙等待状态 ---
            S_IFG_WAIT: begin
                if (ifg_cnt >= IFG_CYCLES - 1'b1) begin
                    arb_state <= S_IDLE;
                    ifg_cnt   <= 8'd0;
                end
                else begin
                    ifg_cnt   <= ifg_cnt + 1'b1;
                    arb_state <= S_IFG_WAIT;
                end
            end
            default: arb_state <= S_IDLE;
        endcase
    end
end

// 组合逻辑输出 MUX (根据当前状态选择数据源)
always @(*) begin
    // 默认值
    din_convert_axis_tvalid = 1'b0;
    din_convert_axis_tdata  = 64'b0;
    din_convert_axis_tkeep  = 8'b0;
    din_convert_axis_tlast  = 1'b0;
    
    m_sync_axis_tready          = 1'b0;
    m_sync_follow_axis_tready   = 1'b0;
    m_pdelay_axis_tready        = 1'b0;
    m_presp_axis_tready         = 1'b0;
    m_presp_follow_axis_tready  = 1'b0;
    m_announce_axis_tready      = 1'b0;

    case (arb_state)
        S_SEND_SYNC: begin
            din_convert_axis_tvalid = m_sync_axis_tvalid;
            din_convert_axis_tdata  = m_sync_axis_tdata;
            din_convert_axis_tkeep  = m_sync_axis_tkeep;
            din_convert_axis_tlast  = m_sync_axis_tlast;
            m_sync_axis_tready      = din_convert_axis_tready; // 直连 Ready 信号
        end

        S_SEND_SYNC_F: begin
            din_convert_axis_tvalid   = m_sync_follow_axis_tvalid;
            din_convert_axis_tdata    = m_sync_follow_axis_tdata;
            din_convert_axis_tkeep    = m_sync_follow_axis_tkeep;
            din_convert_axis_tlast    = m_sync_follow_axis_tlast;
            m_sync_follow_axis_tready = din_convert_axis_tready;
        end

        S_SEND_PD_REQ: begin
            din_convert_axis_tvalid = m_pdelay_axis_tvalid;
            din_convert_axis_tdata  = m_pdelay_axis_tdata;
            din_convert_axis_tkeep  = m_pdelay_axis_tkeep;
            din_convert_axis_tlast  = m_pdelay_axis_tlast;
            m_pdelay_axis_tready    = din_convert_axis_tready;
        end

        S_SEND_PD_RESP: begin
            din_convert_axis_tvalid = m_presp_axis_tvalid;
            din_convert_axis_tdata  = m_presp_axis_tdata;
            din_convert_axis_tkeep  = m_presp_axis_tkeep;
            din_convert_axis_tlast  = m_presp_axis_tlast;
            m_presp_axis_tready     = din_convert_axis_tready;
        end

        S_SEND_PD_RESP_F: begin
            din_convert_axis_tvalid = m_presp_follow_axis_tvalid;
            din_convert_axis_tdata  = m_presp_follow_axis_tdata;
            din_convert_axis_tkeep  = m_presp_follow_axis_tkeep;
            din_convert_axis_tlast  = m_presp_follow_axis_tlast;
            m_presp_follow_axis_tready = din_convert_axis_tready;
        end

        S_SEND_ANNOUNCE: begin
            din_convert_axis_tvalid = m_announce_axis_tvalid;
            din_convert_axis_tdata  = m_announce_axis_tdata;
            din_convert_axis_tkeep  = m_announce_axis_tkeep;
            din_convert_axis_tlast  = m_announce_axis_tlast;
            m_announce_axis_tready  = din_convert_axis_tready;
        end
    endcase
end

//CRC校验
//取输出信号上升沿
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) 
        dout_valid_convert_ff <= 1'b0;
    else
        dout_valid_convert_ff <= dout_valid_convert;
end

assign dout_valid_convert_pos = !dout_valid_convert_ff && dout_valid_convert;

always @(posedge clk or negedge rst_n) begin
    if(!rst_n)
        CRC_cnt <= 8'b0;
    else if(dout_valid_convert_pos)
        CRC_cnt <= 8'b0;
    else if(dout_valid_convert)
        CRC_cnt <= CRC_cnt + 1'b1;
end

always @(posedge clk or negedge rst_n) begin
    if(!rst_n)
        CRC_en <= 1'b0;
    else if(CRC_cnt == 8'd6)
        CRC_en <= 1'b1;
    else if(dout_convert_last)
        CRC_en <= 1'b0;
end

always @(posedge clk or negedge rst_n) begin
    if(!rst_n)
        CRC_rd_shift <= 4'b0;
    else if(dout_convert_last)
        CRC_rd_shift <= 4'b1111;
    else 
        CRC_rd_shift <= CRC_rd_shift << 1;
end

assign CRC_rd = |CRC_rd_shift;
assign dout = CRC_rd ? CRC_out : dout_convert;
assign dout_valid = dout_valid_convert | CRC_rd;

//大小端转换
assign s_sync_axis_order_tdata = {s_sync_axis_tdata[7:0], s_sync_axis_tdata[15:8], s_sync_axis_tdata[23:16], s_sync_axis_tdata[31:24], s_sync_axis_tdata[39:32], 
                                    s_sync_axis_tdata[47:40], s_sync_axis_tdata[55:48], s_sync_axis_tdata[63:56]};
                                    
assign s_sync_follow_axis_order_tdata = {s_sync_follow_axis_tdata[7:0], s_sync_follow_axis_tdata[15:8], s_sync_follow_axis_tdata[23:16], s_sync_follow_axis_tdata[31:24],
                                         s_sync_follow_axis_tdata[39:32], s_sync_follow_axis_tdata[47:40], s_sync_follow_axis_tdata[55:48], s_sync_follow_axis_tdata[63:56]};

assign s_pdelay_axis_order_tdata = {s_pdelay_axis_tdata[7:0], s_pdelay_axis_tdata[15:8], s_pdelay_axis_tdata[23:16], s_pdelay_axis_tdata[31:24],
                                    s_pdelay_axis_tdata[39:32],s_pdelay_axis_tdata[47:40], s_pdelay_axis_tdata[55:48], s_pdelay_axis_tdata[63:56]};

assign s_presp_axis_order_tdata = {s_presp_axis_tdata[7:0], s_presp_axis_tdata[15:8], s_presp_axis_tdata[23:16], s_presp_axis_tdata[31:24],
                                   s_presp_axis_tdata[39:32],s_presp_axis_tdata[47:40], s_presp_axis_tdata[55:48], s_presp_axis_tdata[63:56]};

assign s_presp_follow_axis_order_tdata = {s_presp_follow_axis_tdata[7:0], s_presp_follow_axis_tdata[15:8], s_presp_follow_axis_tdata[23:16], s_presp_follow_axis_tdata[31:24],
                                         s_presp_follow_axis_tdata[39:32],s_presp_follow_axis_tdata[47:40], s_presp_follow_axis_tdata[55:48], s_presp_follow_axis_tdata[63:56]};

assign s_announce_axis_order_tdata = {s_announce_axis_tdata[7:0], s_announce_axis_tdata[15:8], s_announce_axis_tdata[23:16], s_announce_axis_tdata[31:24],
                                     s_announce_axis_tdata[39:32],s_announce_axis_tdata[47:40], s_announce_axis_tdata[55:48], s_announce_axis_tdata[63:56]};

//帧存储
axis_data_fifo sync_buffer(
  .s_axis_aresetn   (rst_n                          ),  // input wire s_axis_aresetn
  .s_axis_aclk      (clk                            ),  // input wire s_axis_aclk
  .s_axis_tvalid    (s_sync_axis_tvalid             ),  // input wire s_axis_tvalid
  .s_axis_tready    (s_sync_axis_tready             ),  // output wire s_axis_tready
  .s_axis_tdata     (s_sync_axis_order_tdata        ),  // input wire [63 : 0] s_axis_tdata
  .s_axis_tkeep     (s_sync_axis_tkeep              ),  // input wire [7 : 0] s_axis_tkeep
  .s_axis_tlast     (s_sync_axis_tlast              ),  // input wire s_axis_tlast
  .m_axis_tvalid    (m_sync_axis_tvalid             ),  // output wire m_axis_tvalid
  .m_axis_tready    (m_sync_axis_tready             ),  // input wire m_axis_tready
  .m_axis_tdata     (m_sync_axis_tdata              ),  // output wire [63 : 0] m_axis_tdata
  .m_axis_tkeep     (m_sync_axis_tkeep              ),  // output wire [7 : 0] m_axis_tkeep
  .m_axis_tlast     (m_sync_axis_tlast              )   // output wire m_axis_tlast
);

axis_data_fifo sync_follow_buffer(
  .s_axis_aresetn   (rst_n                          ),  // input wire s_axis_aresetn
  .s_axis_aclk      (clk                            ),  // input wire s_axis_aclk
  .s_axis_tvalid    (s_sync_follow_axis_tvalid      ),  // input wire s_axis_tvalid
  .s_axis_tready    (s_sync_follow_axis_tready      ),  // output wire s_axis_tready
  .s_axis_tdata     (s_sync_follow_axis_order_tdata ),  // input wire [63 : 0] s_axis_tdata
  .s_axis_tkeep     (s_sync_follow_axis_tkeep       ),  // input wire [7 : 0] s_axis_tkeep
  .s_axis_tlast     (s_sync_follow_axis_tlast       ),  // input wire s_axis_tlast
  .m_axis_tvalid    (m_sync_follow_axis_tvalid      ),  // output wire m_axis_tvalid
  .m_axis_tready    (m_sync_follow_axis_tready      ),  // input wire m_axis_tready
  .m_axis_tdata     (m_sync_follow_axis_tdata       ),  // output wire [63 : 0] m_axis_tdata
  .m_axis_tkeep     (m_sync_follow_axis_tkeep       ),  // output wire [7 : 0] m_axis_tkeep
  .m_axis_tlast     (m_sync_follow_axis_tlast       )   // output wire m_axis_tlast
);

axis_data_fifo pdelay_buffer(
  .s_axis_aresetn   (rst_n                          ),  // input wire s_axis_aresetn
  .s_axis_aclk      (clk                            ),  // input wire s_axis_aclk
  .s_axis_tvalid    (s_pdelay_axis_tvalid           ),  // input wire s_axis_tvalid
  .s_axis_tready    (s_pdelay_axis_tready           ),  // output wire s_axis_tready
  .s_axis_tdata     (s_pdelay_axis_order_tdata      ),  // input wire [63 : 0] s_axis_tdata
  .s_axis_tkeep     (s_pdelay_axis_tkeep            ),  // input wire [7 : 0] s_axis_tkeep
  .s_axis_tlast     (s_pdelay_axis_tlast            ),  // input wire s_axis_tlast
  .m_axis_tvalid    (m_pdelay_axis_tvalid           ),  // output wire m_axis_tvalid
  .m_axis_tready    (m_pdelay_axis_tready           ),  // input wire m_axis_tready
  .m_axis_tdata     (m_pdelay_axis_tdata            ),  // output wire [63 : 0] m_axis_tdata
  .m_axis_tkeep     (m_pdelay_axis_tkeep            ),  // output wire [7 : 0] m_axis_tkeep
  .m_axis_tlast     (m_pdelay_axis_tlast            )   // output wire m_axis_tlast
);

axis_data_fifo presp_buffer(
  .s_axis_aresetn   (rst_n                          ),  // input wire s_axis_aresetn
  .s_axis_aclk      (clk                            ),  // input wire s_axis_aclk
  .s_axis_tvalid    (s_presp_axis_tvalid            ),  // input wire s_axis_tvalid
  .s_axis_tready    (s_presp_axis_tready            ),  // output wire s_axis_tready
  .s_axis_tdata     (s_presp_axis_order_tdata       ),  // input wire [63 : 0] s_axis_tdata
  .s_axis_tkeep     (s_presp_axis_tkeep             ),  // input wire [7 : 0] s_axis_tkeep
  .s_axis_tlast     (s_presp_axis_tlast             ),  // input wire s_axis_tlast
  .m_axis_tvalid    (m_presp_axis_tvalid            ),  // output wire m_axis_tvalid
  .m_axis_tready    (m_presp_axis_tready            ),  // input wire m_axis_tready
  .m_axis_tdata     (m_presp_axis_tdata             ),  // output wire [63 : 0] m_axis_tdata
  .m_axis_tkeep     (m_presp_axis_tkeep             ),  // output wire [7 : 0] m_axis_tkeep
  .m_axis_tlast     (m_presp_axis_tlast             )   // output wire m_axis_tlast
);

axis_data_fifo presp_follow_buffer(
  .s_axis_aresetn   (rst_n                          ),  // input wire s_axis_aresetn
  .s_axis_aclk      (clk                            ),  // input wire s_axis_aclk
  .s_axis_tvalid    (s_presp_follow_axis_tvalid     ),  // input wire s_axis_tvalid
  .s_axis_tready    (s_presp_follow_axis_tready     ),  // output wire s_axis_tready
  .s_axis_tdata     (s_presp_follow_axis_order_tdata),  // input wire [63 : 0] s_axis_tdata
  .s_axis_tkeep     (s_presp_follow_axis_tkeep      ),  // input wire [7 : 0] s_axis_tkeep
  .s_axis_tlast     (s_presp_follow_axis_tlast      ),  // input wire s_axis_tlast
  .m_axis_tvalid    (m_presp_follow_axis_tvalid     ),  // output wire m_axis_tvalid
  .m_axis_tready    (m_presp_follow_axis_tready     ),  // input wire m_axis_tready
  .m_axis_tdata     (m_presp_follow_axis_tdata      ),  // output wire [63 : 0] m_axis_tdata
  .m_axis_tkeep     (m_presp_follow_axis_tkeep      ),  // output wire [7 : 0] m_axis_tkeep
  .m_axis_tlast     (m_presp_follow_axis_tlast      )   // output wire m_axis_tlast
);

axis_data_fifo announce_buffer(
  .s_axis_aresetn   (rst_n                          ),  // input wire s_axis_aresetn
  .s_axis_aclk      (clk                            ),  // input wire s_axis_aclk
  .s_axis_tvalid    (s_announce_axis_tvalid         ),  // input wire s_axis_tvalid
  .s_axis_tready    (s_announce_axis_tready         ),  // output wire s_axis_tready
  .s_axis_tdata     (s_announce_axis_order_tdata    ),  // input wire [63 : 0] s_axis_tdata
  .s_axis_tkeep     (s_announce_axis_tkeep          ),  // input wire [7 : 0] s_axis_tkeep
  .s_axis_tlast     (s_announce_axis_tlast          ),  // input wire s_axis_tlast
  .m_axis_tvalid    (m_announce_axis_tvalid         ),  // output wire m_axis_tvalid
  .m_axis_tready    (m_announce_axis_tready         ),  // input wire m_axis_tready
  .m_axis_tdata     (m_announce_axis_tdata          ),  // output wire [63 : 0] m_axis_tdata
  .m_axis_tkeep     (m_announce_axis_tkeep          ),  // output wire [7 : 0] m_axis_tkeep
  .m_axis_tlast     (m_announce_axis_tlast          )   // output wire m_axis_tlast
);

//axis位宽转换，对于千兆64 -> 8 ,对于万兆不用转换
dout_width_convert U_dout_width_convert (
  .aclk             (clk                       ),  // input wire aclk
  .aresetn          (rst_n                     ),  // input wire aresetn
  .s_axis_tvalid    (din_convert_axis_tvalid   ),  // input wire s_axis_tvalid
  .s_axis_tready    (din_convert_axis_tready   ),  // output wire s_axis_tready
  .s_axis_tdata     (din_convert_axis_tdata    ),  // input wire [63 : 0] s_axis_tdata
  .s_axis_tkeep     (din_convert_axis_tkeep    ),  // input wire [7 : 0] s_axis_tkeep
  .s_axis_tlast     (din_convert_axis_tlast    ),  // input wire s_axis_tlast
  .m_axis_tvalid    (dout_valid_convert        ),  // output wire m_axis_tvalid
  .m_axis_tready    (1'b1                      ),  // input wire m_axis_tready
  .m_axis_tdata     (dout_convert              ),  // output wire [7 : 0] m_axis_tdata
  .m_axis_tkeep     (                          ),  // output wire [0 : 0] m_axis_tkeep
  .m_axis_tlast     (dout_convert_last         )   // output wire m_axis_tlast
);

CRC_gen U_CRC_gen(
        .Reset      (!rst_n        ),
        .Clk        (clk           ),
        .Init       (1'b0          ),
        .Frame_data (dout_convert  ),
        .Data_en    (CRC_en        ),
        .CRC_rd     (CRC_rd        ),
        .CRC_end    (CRC_end       ),
        .CRC_out    (CRC_out       )
);

endmodule
