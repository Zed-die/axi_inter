`timescale 1ns/1ns 

module div_rill_fsm
(
input clk,
input rst,

input enable,
input [31:0] dividend, 
input [31:0] divisor,

//output reg [31:0] yshang,
output reg [31:0] yyushu,

output reg done
);

reg[31:0] tempa;
reg[31:0] tempb;
reg[63:0] temp_a;
reg[63:0] temp_b;

parameter s_idle =  6'b000000;
parameter s_init =  6'b000001;
parameter s_calc1 = 6'b000010;
parameter s_calc2 = 6'b000100;
parameter s_done =  6'b001000;


reg [5:0] c_state ;//current_state
reg [5:0] n_state ;//next_state

reg [31:0] i;

//*********************
//MAIN CORE
//********************* 
// 三段式状态机实现取模操作

always @(posedge clk or posedge rst) begin
    if (rst ==  1'b1) begin
        c_state <= s_idle ;
    end
    else begin
        c_state <= n_state ;
    end    
end

always@(*) begin

    case ( c_state )
        s_idle :
            begin
                if (enable == 1'b1) 
                   n_state = s_init ;
                else 
                   n_state = s_idle ;
            end
        s_init : 
            begin
                   n_state = s_calc1 ;
            end
        s_calc1 : 
            begin
                    n_state = s_calc2;
            end
        s_calc2 : 
           begin
                if(i < 'd31)   
                    n_state = s_calc1;
                else
                    n_state = s_done;
            end
        s_done : 
           begin
                    n_state = s_idle ;
            end
        default  :  n_state = s_idle ;
    endcase
end


always @(posedge clk or posedge rst) begin
    if (rst == 1'b1) begin
            i <= 32'h0;
            tempa <= 32'h0;
            tempb <= 32'h0;
            temp_a <= 64'd0 ;
            temp_b <= 64'd0 ;
 //         yshang <= 32'h0;
            yyushu <= 32'h0;
            done <= 1'b0;
    end
    else  begin
        case ( c_state )
            s_idle : 
                begin
                    tempa <= dividend;
                    tempb <= divisor;
                    done <= 1'b0;
                    i <= 32'h0;
                end
            s_init : 
                begin
                    temp_a <= {32'd0,tempa};
                    temp_b <= {tempb,32'd0};
                end
            s_calc1 : 
                begin
                    temp_a <= {temp_a[62:0],1'b0}; 
                end
            s_calc2 :
                begin
                    if(temp_a[63:32] >= tempb)
                        begin
                            temp_a <= temp_a - temp_b + 1'b1;
                        end
                    else
                        begin
                            temp_a <= temp_a;
                        end
                    i <= i + 1'b1;  
                end
            s_done : 
                begin
                    //yshang <= temp_a[31:0];
                    yyushu <= temp_a[63:32];
                    done <= 1'b1;
                end
            default  : 
                begin
                    i <= 32'h0;
                    tempa <= 32'h0;
                    tempb <= 32'h0;
                    temp_a <= 64'd0 ;
                    temp_b <= 64'd0 ;
 //                 yshang <= 32'h0;
                    yyushu <= 32'h0;
                    done <= 1'b0;  
                end
        endcase
    end
end


//wire [31:0] zyushu ;

//assign zyushu = dividend % divisor;

endmodule


/*************** EOF ******************/