`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module Name: fault_injection_ctrl
// Description: 协议一致性测试故障注入模块 (基于测试时间点与错误掩码)
//              支持：单次丢帧、持续丢帧(超时测试)、10%随机丢帧、FollowUp序列号篡改
//////////////////////////////////////////////////////////////////////////////////

module fault_injection_ctrl(
    input  wire        clk,
    input  wire        rst_n,

    // 1. 注入配置接口
    input  wire [63:0] test_time,
    input  wire [31:0] oc_error_time,
    input  wire [31:0] oc_error_type,

    // 2. 原始触发脉冲 (来自定时器或外部输入)
    input  wire        raw_sync_gen,
    input  wire        raw_sync_follow_gen,
    input  wire        raw_pdelay_gen,
    input  wire        raw_presp_gen,
    input  wire        raw_presp_follow_gen,
    input  wire        raw_announce_gen,

    // 3. 实际输出脉冲 (送往发包状态机)
    output wire        actual_sync_gen,
    output wire        actual_sync_follow_gen,
    output wire        actual_pdelay_gen,
    output wire        actual_presp_gen,
    output wire        actual_presp_follow_gen,
    output wire        actual_announce_gen,

    // 4. 载荷篡改标志 (送往拼帧逻辑)
    output wire        inject_fu_seq_err
);

// ==============================================================================
// 错误掩码位定义 (根据测试例大纲映射)
// ==============================================================================
// [5:0] 单次丢弃 (Armed-Drop)
localparam BIT_S_DROP_SYNC       = 0;
localparam BIT_S_DROP_SYNC_F     = 1;
localparam BIT_S_DROP_PD_REQ     = 2;
localparam BIT_S_DROP_PD_RESP    = 3;
localparam BIT_S_DROP_PD_RESP_F  = 4;
localparam BIT_S_DROP_ANNOUNCE   = 5;

// [9:6] 持续丢弃 (用于超时测试)
localparam BIT_C_DROP_SYNC       = 6;  // Sync超时测试
localparam BIT_C_DROP_SYNC_F     = 7;  // FollowUp超时测试
localparam BIT_C_DROP_PD_RESP    = 8;  // Pdelay超时测试
localparam BIT_C_DROP_ANNOUNCE   = 9;  // Announce超时测试

// [10] 特殊载荷篡改
localparam BIT_ERR_FU_SEQ_ID     = 10; // FollowUp SequenceID 篡改测试

// [11] 随机丢弃
localparam BIT_R_DROP_10_PERCENT = 11; // 10% 随机丢包鲁棒性测试

// [12] 彻底阻断
localparam BIT_C_DROP_ALL        = 12; // 主时钟失效切换测试 (阻断所有发送)


// ==============================================================================
// 1. 触发逻辑
// ==============================================================================
// 只有当测试时间到达设定的错误时间点，且错误时间不为0时，触发
wire trigger_arm = (test_time == oc_error_time) && (oc_error_time != 64'd0);

// ==============================================================================
// 2. 状态寄存器定义
// ==============================================================================
// 单次丢弃 (成功拦截一次后自动清零)
reg s_mask_sync, s_mask_sync_f, s_mask_pd_req, s_mask_pd_resp, s_mask_pd_resp_f, s_mask_announce;

// 持续丢弃 (触发后一直维持，直到外部复位或新的表项覆盖)
reg c_mask_sync, c_mask_sync_f, c_mask_pd_resp, c_mask_announce, c_mask_all;

// 载荷篡改 (单次有效)
reg fu_seq_err_reg;

// 随机模式开启标志
reg random_drop_en;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        s_mask_sync      <= 1'b0; s_mask_sync_f <= 1'b0; s_mask_pd_req   <= 1'b0;
        s_mask_pd_resp   <= 1'b0; s_mask_pd_resp_f<= 1'b0; s_mask_announce <= 1'b0;
        
        c_mask_sync      <= 1'b0; c_mask_sync_f <= 1'b0; c_mask_pd_resp  <= 1'b0;
        c_mask_announce  <= 1'b0; c_mask_all    <= 1'b0;
        
        fu_seq_err_reg   <= 1'b0;
        random_drop_en   <= 1'b0;
    end else begin
        // 到达时间点，根据 oc_error_type 锁存配置
        if (trigger_arm) begin
            s_mask_sync      <= oc_error_type[BIT_S_DROP_SYNC];
            s_mask_sync_f    <= oc_error_type[BIT_S_DROP_SYNC_F];
            s_mask_pd_req    <= oc_error_type[BIT_S_DROP_PD_REQ];
            s_mask_pd_resp   <= oc_error_type[BIT_S_DROP_PD_RESP];
            s_mask_pd_resp_f <= oc_error_type[BIT_S_DROP_PD_RESP_F];
            s_mask_announce  <= oc_error_type[BIT_S_DROP_ANNOUNCE];

            c_mask_sync      <= oc_error_type[BIT_C_DROP_SYNC];
            c_mask_sync_f    <= oc_error_type[BIT_C_DROP_SYNC_F];
            c_mask_pd_resp   <= oc_error_type[BIT_C_DROP_PD_RESP];
            c_mask_announce  <= oc_error_type[BIT_C_DROP_ANNOUNCE];
            c_mask_all       <= oc_error_type[BIT_C_DROP_ALL];

            fu_seq_err_reg   <= oc_error_type[BIT_ERR_FU_SEQ_ID];
            random_drop_en   <= oc_error_type[BIT_R_DROP_10_PERCENT];
        end

        // 成功拦截一次后，解除单次武装 (防止死锁)
        if (raw_sync_gen         && s_mask_sync)      s_mask_sync      <= 1'b0;
        if (raw_sync_follow_gen  && s_mask_sync_f)    s_mask_sync_f    <= 1'b0;
        if (raw_pdelay_gen       && s_mask_pd_req)    s_mask_pd_req    <= 1'b0;
        if (raw_presp_gen        && s_mask_pd_resp)   s_mask_pd_resp   <= 1'b0;
        if (raw_presp_follow_gen && s_mask_pd_resp_f) s_mask_pd_resp_f <= 1'b0;
        if (raw_announce_gen     && s_mask_announce)  s_mask_announce  <= 1'b0;
    end
end

assign inject_fu_seq_err = fu_seq_err_reg;

// ==============================================================================
// 3. 伪随机数发生器 (LFSR) - 用于 10% 随机丢包测试
// ==============================================================================
reg [15:0] lfsr;
wire       random_drop_hit;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        lfsr <= 16'hACE1; // 赋非零初值
    end else begin
        // 16位 Galois LFSR (抽头: 16, 14, 13, 11)
        lfsr <= {lfsr[14:0], lfsr[15] ^ lfsr[13] ^ lfsr[12] ^ lfsr[10]};
    end
end

// 10% 概率阈值: 65536 * 10% ≈ 6553
assign random_drop_hit = random_drop_en & (lfsr < 16'd6553); 

// ==============================================================================
// 4. 掩码综合与最终脉冲输出
// ==============================================================================
// Sync 和 Follow_Up 受随机丢包影响，其余帧只受指定规则影响
wire mask_sync         = s_mask_sync      | c_mask_sync      | c_mask_all | random_drop_hit;
wire mask_sync_follow  = s_mask_sync_f    | c_mask_sync_f    | c_mask_all | random_drop_hit;
wire mask_pdelay       = s_mask_pd_req    |                    c_mask_all;
wire mask_presp        = s_mask_pd_resp   | c_mask_pd_resp   | c_mask_all;
wire mask_presp_follow = s_mask_pd_resp_f |                    c_mask_all;
wire mask_announce     = s_mask_announce  | c_mask_announce  | c_mask_all;

// 最终输出: 仅当原始脉冲为高且【没有被掩盖】时，才向后级输出
assign actual_sync_gen         = raw_sync_gen         & ~mask_sync;
assign actual_sync_follow_gen  = raw_sync_follow_gen  & ~mask_sync_follow;
assign actual_pdelay_gen       = raw_pdelay_gen       & ~mask_pdelay;
assign actual_presp_gen        = raw_presp_gen        & ~mask_presp;
assign actual_presp_follow_gen = raw_presp_follow_gen & ~mask_presp_follow;
assign actual_announce_gen     = raw_announce_gen     & ~mask_announce;

endmodule