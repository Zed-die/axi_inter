`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: wanghaoyu
// 
// Create Date: 2025/04/21 15:21:11
// Design Name: 
// Module Name: gPTP_oc_top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module gPTP_oc_top(
            input            pxie_clk100m_p     ,
            input            pxie_clk100m_n     ,
            input            sys_rst_n          ,

            input            gtrefclk_p         ,
            input            gtrefclk_n         ,

            output           SFP1_TX_DISABLE    ,
            output           SFP2_TX_DISABLE    ,
            output           SFP3_TX_DISABLE    ,
            output           SFP4_TX_DISABLE    ,

            output           txp_1              ,       
            output           txn_1              ,       
            input            rxp_1              ,       	
            input            rxn_1              ,

            output           txp_2              ,       
            output           txn_2              ,       
            input            rxp_2              ,       
            input            rxn_2              ,

            output           txp_3              ,       
            output           txn_3              ,       
            input            rxp_3              ,           
            input            rxn_3              ,

            output           txp_4              ,       
            output           txn_4              ,       
            input            rxp_4              ,       
            input            rxn_4              ,


            output           Link_1             ,
            output           Link_2             ,
            output           Link_3             ,
            output           Link_4             ,
            output           pulse              
); 


wire  [7:0]   sync_tx_data;
wire          sync_tx_valid;
wire  [7:0]   sync_rx_data;
wire          sync_rx_valid;

//用户侧时钟
wire    clk_125M;


wire [3:0] timestamp_tx_Pdelay_valid_cdc;
wire [3:0] timestamp_tx_Sync_valid_cdc  ;
wire [3:0] timestamp_tx_Presp_valid_cdc ;
wire [3:0] timestamp_rx_Pdelay_valid_cdc;
wire [3:0] timestamp_rx_Sync_valid_cdc  ;
wire [3:0] timestamp_rx_Presp_valid_cdc ;

assign SFP1_TX_DISABLE  = 1'b0	;
assign SFP2_TX_DISABLE  = 1'b0	;
assign SFP3_TX_DISABLE  = 1'b0	;
assign SFP4_TX_DISABLE  = 1'b0	;


//vio
wire    [7:0]     Priority1_vio               ;
wire    [7:0]     clockClass_vio              ;
wire    [7:0]     clockAccuracy_vio           ;
wire    [15:0]    offsetScaledLogVariance_vio ;
wire    [7:0]     Priority2_vio               ;
wire    [63:0]    clockIdentity_vio           ;


wire    [7:0]    LogInterval_sync_vio         ;
wire    [7:0]    LogInterval_pdelay_vio       ;
wire    [7:0]    LogInterval_announce_vio     ;

wire    userclk2_out;
wire    two_step_flag_vio;
reg     two_step_flag_vio_ff;
reg     two_step_flag_phy;

wire [79:0]  sys_time;
wire [79:0]  timer   ;

wire [79:0]  sys_time_phy;
wire [79:0]  timer_phy   ;
wire         timestamp_cdc_empty;
wire         timestamp_cdc_full;

//标识位跨时钟域,打两拍
always@(posedge userclk2_out or negedge sys_rst_n) begin
    if(!sys_rst_n)begin
        two_step_flag_vio_ff <= 1'b0;
        two_step_flag_phy    <= 1'b0;
    end
    else begin
        two_step_flag_vio_ff <= two_step_flag_vio;
        two_step_flag_phy    <= two_step_flag_vio_ff;
    end
end

GMII_top inst_GMII_top(
    .sys_clk_p    (pxie_clk100m_p   ),  // 100M
    .sys_clk_n    (pxie_clk100m_n   ),

    .gtrefclk_p   (gtrefclk_p       ), // 125M
    .gtrefclk_n   (gtrefclk_n       ),

    .rst_n        (sys_rst_n        ),

    .rxn_1        (rxn_1            ),
    .rxp_1        (rxp_1            ),        
    .rxn_2        (rxn_2            ),
    .rxp_2        (rxp_2            ),
    .rxn_3        (rxn_3            ),
    .rxp_3        (rxp_3            ),        
    .rxn_4        (rxn_4            ),
    .rxp_4        (rxp_4            ),
            
    .txn_1        (txn_1            ),
    .txp_1        (txp_1            ),       
    .txn_2        (txn_2            ),
    .txp_2        (txp_2            ),
    .txn_3        (txn_3            ),
    .txp_3        (txp_3            ),       
    .txn_4        (txn_4            ),
    .txp_4        (txp_4            ),
    .Link_1       (Link_1           ),
    .Link_2       (Link_2           ),
    .Link_3       (Link_3           ),
    .Link_4       (Link_4           ),

    .clk_125M     (clk_125M         ),   // 用户时钟
    .gmii_txd_A   (sync_tx_data     ),
    .gmii_tx_en_A (sync_tx_valid    ),
    .gmii_txd_B   (0),
    .gmii_tx_en_B (0),
    .gmii_txd_C   (0),
    .gmii_tx_en_C (0),
    .gmii_txd_D   (0),
    .gmii_tx_en_D (0),

    .gmii_rxd_A   (sync_rx_data     ),
    .gmii_rx_en_A (sync_rx_valid    ),
    .gmii_rxd_B   (),
    .gmii_rx_en_B (),
    .gmii_rxd_C   (),
    .gmii_rx_en_C (),
    .gmii_rxd_D   (),
    .gmii_rx_en_D (),
    .userclk2_out                 (userclk2_out                 ),
    .sys_time                     (sys_time_phy                 ),       
    .timer                        (timer_phy                    ),
    .two_step_flag                (two_step_flag_phy            ),
    .timestamp_tx_Pdelay_valid_cdc(timestamp_tx_Pdelay_valid_cdc),
    .timestamp_tx_Sync_valid_cdc  (timestamp_tx_Sync_valid_cdc  ),
    .timestamp_tx_Presp_valid_cdc (timestamp_tx_Presp_valid_cdc ),
    .timestamp_rx_Pdelay_valid_cdc(timestamp_rx_Pdelay_valid_cdc),
    .timestamp_rx_Sync_valid_cdc  (timestamp_rx_Sync_valid_cdc  ),
    .timestamp_rx_Presp_valid_cdc (timestamp_rx_Presp_valid_cdc )
);




oc_top U_oc_top(
    .clk                          (clk_125M                   ),
    .rst_n                        (sys_rst_n                  ),
   
    .gmii_rxd                     (sync_rx_data               ),
    .gmii_rx_dv                   (sync_rx_valid              ),
    .gmii_txd                     (sync_tx_data               ),
    .gmii_tx_en                   (sync_tx_valid              ),
       
    .Priority1                    (Priority1_vio              ),
    .clockClass                   (clockClass_vio             ),
    .clockAccuracy                (clockAccuracy_vio          ),
    .offsetScaledLogVariance      (offsetScaledLogVariance_vio),
    .Priority2                    (Priority2_vio              ),
    .clockIdentity                (clockIdentity_vio          ),

    .two_step_flag                (two_step_flag_vio          ),
   
    .LogInterval_sync             (LogInterval_sync_vio       ),
    .LogInterval_pdelay           (LogInterval_pdelay_vio     ),
    .LogInterval_announce         (LogInterval_announce_vio   ),
   
    .sys_sync                     (sys_sync                   ), 
    .sys_time                     (sys_time                   ), 
    .timer                        (timer                      ),

    .timestamp_tx_Pdelay_valid_cdc(timestamp_tx_Pdelay_valid_cdc[0]),
    .timestamp_tx_Sync_valid_cdc  (timestamp_tx_Sync_valid_cdc[0]  ),
    .timestamp_tx_Presp_valid_cdc (timestamp_tx_Presp_valid_cdc[0] ),
    .timestamp_rx_Pdelay_valid_cdc(timestamp_rx_Pdelay_valid_cdc[0]),
    .timestamp_rx_Sync_valid_cdc  (timestamp_rx_Sync_valid_cdc[0]  ),
    .timestamp_rx_Presp_valid_cdc (timestamp_rx_Presp_valid_cdc[0] ),
    .sync_pulse                   (pulse                           )
);

timestamp_cdc U_timestamp_cdc (
  .rst      (!sys_rst_n                 ),  // input wire rst
  .wr_clk   (clk_125M                   ),  // input wire wr_clk
  .rd_clk   (userclk2_out               ),  // input wire rd_clk
  .din      ({sys_time,timer}           ),  // input wire [159 : 0] din
  .wr_en    (!timestamp_cdc_full        ),  // input wire wr_en
  .rd_en    (!timestamp_cdc_empty       ),  // input wire rd_en
  .dout     ({sys_time_phy,timer_phy}   ),  // output wire [159 : 0] dout
  .full     (timestamp_cdc_full         ),  // output wire full
  .empty    (timestamp_cdc_empty        )   // output wire empty
);

vio_0 clock_message (
    .clk       (clk_125M                    ),  // input wire clk
    .probe_out0(Priority1_vio               ),  // output wire [7 : 0]  probe_out0
    .probe_out1(clockClass_vio              ),  // output wire [7 : 0]  probe_out1
    .probe_out2(clockAccuracy_vio           ),  // output wire [7 : 0]  probe_out2
    .probe_out3(offsetScaledLogVariance_vio ),  // output wire [15 : 0] probe_out3
    .probe_out4(Priority2_vio               ),  // output wire [7 : 0]  probe_out4
    .probe_out5(clockIdentity_vio           ),  // output wire [63 : 0] probe_out5
    .probe_out6(LogInterval_sync_vio        ),  // output wire [31 : 0] probe_out6
    .probe_out7(LogInterval_pdelay_vio      ),  // output wire [31 : 0] probe_out7
    .probe_out8(LogInterval_announce_vio    ),  // output wire [31 : 0] probe_out8
    .probe_out9(two_step_flag_vio           )   // output wire [0 : 0]  probe_out9
);



endmodule
