`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/10/08 20:02:04
// Design Name: 
// Module Name: RR_aribter
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////
module RR_aribter#(
  parameter WIDTH = 4
)(
  input  clk,
  input  rst_n,
  input  RR_en,             
  input  [WIDTH-1:0] request,
  output reg [WIDTH-1:0] grant_o,
  output reg grant_valid
);

reg  [WIDTH-1:0] mask;
wire [WIDTH-1:0] grant_0;
wire [WIDTH-1:0] grant_1;
wire [WIDTH-1:0] mask_req;
wire [WIDTH-1:0] next_grant;

// ------------------------
// 计算下一个仲裁结果
// ------------------------

assign mask_req = mask & request;
assign grant_0 = request & (~request + 1'b1);
assign grant_1 = mask_req & (~mask_req + 1'b1);
assign next_grant = (mask_req == {WIDTH{1'b0}}) ? grant_0 : grant_1;

// ------------------------
// 轮询 mask 更新逻辑
// ------------------------
always @(posedge clk or negedge rst_n) begin
  if (!rst_n)
    mask <= {WIDTH{1'b1}};
  else if (RR_en)
    mask <= ~((next_grant << 1) - 1'b1);
  else
    mask <= mask;
end

// ------------------------
// grant 输出控制逻辑
// ------------------------
always @(posedge clk or negedge rst_n) begin
  if (!rst_n)begin
    grant_o <= {WIDTH{1'b0}};
    grant_valid <= 1'b0;
  end
  else if (RR_en)begin
    grant_o <= next_grant;
    grant_valid <= 1'b1;
  end
  else begin
    grant_o <= grant_o;
    grant_valid <= 1'b0;
  end
end

endmodule

 
 
 

