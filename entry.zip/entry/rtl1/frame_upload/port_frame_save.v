`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/09/18 11:34:54
// Design Name: 
// Module Name: port_frame_save
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module port_frame_save(
    input           rst_n    ,
    input           clk      ,
    input           ui_clk   ,
    input   [7:0]   txd      ,
    input           tx_dval  ,
    input   [7:0]   rxd      ,
    input           rx_dval  ,
    input   [3:0]   port_num ,
    input           lock_port,
    input           frame_save_flag,
    input           init_calib_complete,
    input           port_frame_rd,
    output  [63:0]  port_frame_data,
    output          request
    );


parameter HEADER = 16'hbeef;

//帧长信息
reg [15:0] tx_num;
reg [15:0] rx_num;

//帧时间
reg [63:0] tx_time;
reg [63:0] rx_time;
reg [63:0] local_time;

//帧存储
reg [7:0 ] txd_f;
reg [7:0 ] rxd_f; 
reg        tx_valid;
reg        rx_valid;
reg [63:0] tx_data;
reg        tx_data_valid;
reg [63:0] rx_data;
reg        rx_data_valid;
reg [2:0]  tx_cnt;
reg [2:0]  rx_cnt;

//边沿检测
reg  tx_dval_f;
reg  rx_dval_f;
wire tx_pos,tx_neg,rx_pos,rx_neg;

//fifo计数
wire [4:0] tx_link_count;
wire [8:0] tx_data_count;
wire [4:0] rx_link_count;
wire [8:0] rx_data_count;
reg tx_save_en;
reg rx_save_en;

//取帧
reg  rd_link_tx;
wire rd_data_tx;
reg  rd_link_rx;
wire rd_data_rx;
wire [79:0] dout_link_tx;
wire [63:0] dout_data_tx;
wire [79:0] dout_link_rx;
wire [63:0] dout_data_rx;

//单端口顺序存帧状态机
// 状态定义
parameter [5:0] IDLE           = 6'b00_0001;
parameter [5:0] COMPARE        = 6'b00_0010;
parameter [5:0] READ_TX        = 6'b00_0100;
parameter [5:0] READ_RX        = 6'b00_1000;
parameter [5:0] JUDGE          = 6'b01_0000;
parameter [5:0] TEANSFER_DONE  = 6'b10_0000;

reg [5:0] current_state,next_state;
// 内部寄存器
reg rd_tx_data_valid,rd_rx_data_valid;
//传输结束标识
reg trasnsfer_done;
// 时间戳比较
wire [63:0] tx_timestamp = dout_link_tx[79:16];
wire [63:0] rx_timestamp = dout_link_rx[79:16];
wire tx_smaller = (tx_timestamp <= rx_timestamp && tx_timestamp != 0);
wire tx_link_empty,rx_link_empty;

//存帧
reg frame_buffer_wr;
reg [63:0] frame_buffer_din;
wire [9:0] rd_frame_count;
wire [9:0] wr_frame_count;

wire frame_save_en;
assign frame_save_en = frame_save_flag && (wr_frame_count <= 10'd834) && !lock_port && init_calib_complete;

always @(posedge clk or negedge rst_n) begin
    if(!rst_n)
        tx_dval_f <= 1'b0;
    else 
        tx_dval_f <= tx_dval;
end

always @(posedge clk or negedge rst_n) begin
    if(!rst_n)
        rx_dval_f <= 1'b0;
    else 
        rx_dval_f <= rx_dval;
end

assign tx_pos = tx_dval & ~tx_dval_f;
assign tx_neg = tx_dval_f & ~tx_dval;
assign rx_pos = rx_dval & ~rx_dval_f;
assign rx_neg = rx_dval_f & ~rx_dval;

//接收帧时间
always@(posedge clk or negedge rst_n)begin
    if(!rst_n)begin
        local_time <= 64'b0;
    end
    else begin
        local_time <= local_time + 1'b1;
    end
end

always@(posedge clk or negedge rst_n)begin
    if(!rst_n)begin
        tx_time <= 64'b0;
    end
    else if(tx_pos)begin
        tx_time <= local_time;
    end
    else if(tx_neg)begin
        tx_time <= 64'b0;
    end
    else begin
        tx_time <= tx_time;
    end
end

always@(posedge clk or negedge rst_n)begin
    if(!rst_n)begin
        rx_time <= 64'b0;
    end
    else if(rx_pos)begin
        rx_time <= local_time;
    end
    else if(rx_neg)begin
        rx_time <= 64'b0;
    end
    else begin
        rx_time <= rx_time;
    end
end

//存储数据帧
always @(posedge clk or negedge rst_n) begin
    if(!rst_n)
        txd_f <= 8'b0;
    else 
        txd_f <= txd;
end

always @(posedge clk or negedge rst_n) begin
    if(!rst_n)
        rxd_f <= 8'b0;
    else 
        rxd_f <= rxd;
end

always @(posedge clk or negedge rst_n) begin
    if(!rst_n)
        tx_valid <= 1'b0;
    else if(txd == 8'hd5 && txd_f == 8'h55)
        tx_valid <= 1'b1;
    else if(~tx_dval)
        tx_valid <= 1'b0;
    else
        tx_valid <= tx_valid;       
end

always @(posedge clk or negedge rst_n) begin
    if(!rst_n)
        rx_valid <= 1'b0;
    else if(rxd == 8'hd5 && rxd_f == 8'h55)
        rx_valid <= 1'b1;
    else if(~rx_dval)
        rx_valid <= 1'b0;
    else
        rx_valid <= rx_valid;       
end

//帧长计数
always@(posedge clk or negedge rst_n)begin
    if(!rst_n)begin
        tx_num <= 16'b0;
    end
    else begin
        if(tx_valid && tx_dval)begin
            tx_num <= tx_num + 1;
        end
        else begin
            tx_num <= 16'b0;
        end
    end
end

always@(posedge clk or negedge rst_n)begin
    if(!rst_n)begin
        rx_num <= 16'b0;
    end
    else begin
        if(rx_valid && rx_dval)begin
            rx_num <= rx_num + 1;
        end
        else begin
            rx_num <= 16'b0;
        end
    end
end

//8转64拼帧
always @(posedge clk or negedge rst_n) begin
    if(!rst_n)begin
        tx_data <= 64'b0;
        tx_cnt  <= 3'b0;
        tx_data_valid <= 1'b0;
    end
    else if(tx_valid && tx_dval)begin
        case(tx_cnt)
            3'd0:begin
                tx_data [63:56] <= txd;
                tx_cnt  <= tx_cnt + 1;
                tx_data_valid <= 1'b0;
            end
            3'd1:begin
                tx_data [55:48] <= txd;
                tx_cnt  <= tx_cnt + 1;
                tx_data_valid <= 1'b0;
            end
            3'd2:begin
                tx_data [47:40] <= txd;
                tx_cnt  <= tx_cnt + 1;
                tx_data_valid <= 1'b0;
            end
            3'd3:begin
                tx_data [39:32] <= txd;
                tx_cnt  <= tx_cnt + 1;
                tx_data_valid <= 1'b0;
            end
            3'd4:begin
                tx_data [31:24] <= txd;
                tx_cnt  <= tx_cnt + 1;
                tx_data_valid <= 1'b0;
            end
            3'd5:begin
                tx_data [23:16] <= txd;
                tx_cnt  <= tx_cnt + 1;
                tx_data_valid <= 1'b0;
            end
            3'd6:begin
                tx_data [15: 8] <= txd;
                tx_cnt  <= tx_cnt + 1;
                tx_data_valid <= 1'b0;
            end
            3'd7:begin
                tx_data [7: 0 ] <= txd;
                tx_cnt  <= tx_cnt + 1;
                tx_data_valid <= 1'b1;
            end
            default:begin
                tx_data <= 64'b0;
                tx_cnt  <= 3'b0;
                tx_data_valid <= 1'b0;
            end
        endcase
    end
    else if(tx_valid && ~tx_dval && tx_cnt != 3'd0)begin
        case(tx_cnt)
            3'd1:tx_data [55:0] <= 56'b0;
            3'd2:tx_data [47:0] <= 48'b0;
            3'd3:tx_data [39:0] <= 40'b0;
            3'd4:tx_data [31:0] <= 32'b0;
            3'd5:tx_data [23:0] <= 24'b0;
            3'd6:tx_data [15:0] <= 16'b0;
            3'd7:tx_data [7:0]  <= 8'b0;
            default:tx_data <= 64'b0;
        endcase
        tx_cnt  <= 3'b0;
        tx_data_valid <= 1'b1;
    end
    else begin
        tx_data <= 64'b0;
        tx_cnt  <= 3'b0;
        tx_data_valid <= 1'b0;
    end
end

always @(posedge clk or negedge rst_n) begin
    if(!rst_n)begin
        rx_data <= 64'b0;
        rx_cnt  <= 3'b0;
        rx_data_valid <= 1'b0;
    end
    else if(rx_valid && rx_dval)begin
        case(rx_cnt)
            3'd0:begin
                rx_data [63:56] <= rxd;
                rx_cnt  <= rx_cnt + 1;
                rx_data_valid <= 1'b0;
            end
            3'd1:begin
                rx_data [55:48] <= rxd;
                rx_cnt  <= rx_cnt + 1;
                rx_data_valid <= 1'b0;
            end
            3'd2:begin
                rx_data [47:40] <= rxd;
                rx_cnt  <= rx_cnt + 1;
                rx_data_valid <= 1'b0;
            end
            3'd3:begin
                rx_data [39:32] <= rxd;
                rx_cnt  <= rx_cnt + 1;
                rx_data_valid <= 1'b0;
            end
            3'd4:begin
                rx_data [31:24] <= rxd;
                rx_cnt  <= rx_cnt + 1;
                rx_data_valid <= 1'b0;
            end
            3'd5:begin
                rx_data [23:16] <= rxd;
                rx_cnt  <= rx_cnt + 1;
                rx_data_valid <= 1'b0;
            end
            3'd6:begin
                rx_data [15: 8] <= rxd;
                rx_cnt  <= rx_cnt + 1;
                rx_data_valid <= 1'b0;
            end
            3'd7:begin
                rx_data [7: 0 ] <= rxd;
                rx_cnt  <= rx_cnt + 1;
                rx_data_valid <= 1'b1;
            end
            default:begin
                rx_data <= 64'b0;
                rx_cnt  <= 3'b0;
                rx_data_valid <= 1'b0;
            end
        endcase
    end
    else if(rx_valid && ~rx_dval && rx_cnt != 3'd0)begin
        case(rx_cnt)
            3'd1:rx_data [55:0] <= 56'b0;
            3'd2:rx_data [47:0] <= 48'b0;
            3'd3:rx_data [39:0] <= 40'b0;
            3'd4:rx_data [31:0] <= 32'b0;
            3'd5:rx_data [23:0] <= 24'b0;
            3'd6:rx_data [15:0] <= 16'b0;
            3'd7:rx_data [7:0]  <= 8'b0;
            default:rx_data <= 64'b0;
        endcase
        rx_cnt  <= 3'b0;
        rx_data_valid <= 1'b1;
    end
    else begin
        rx_data <= 64'b0;
        rx_cnt  <= 3'b0;
        rx_data_valid <= 1'b0;
    end
end

//fifo反压
always @(posedge clk or negedge rst_n) begin
    if(!rst_n)begin
        tx_save_en <= 1'b1;
    end
    else if(tx_pos && tx_data_count >= 482)
        tx_save_en <= 1'b0;
    else if(tx_pos && tx_data_count < 482 )
        tx_save_en <= 1'b1;
    else
        tx_save_en <= tx_save_en;
end

always @(posedge clk or negedge rst_n) begin
    if(!rst_n)begin
        rx_save_en <= 1'b1;
    end
    else if(rx_pos && rx_data_count >= 482)
        rx_save_en <= 1'b0;
    else if(rx_pos && rx_data_count < 482 )
        rx_save_en <= 1'b1;
    else
        rx_save_en <= rx_save_en;
end

// ===============================
// 第一段：同步时序逻辑，状态寄存器
// ===============================
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) 
        current_state <= IDLE;
    else
        current_state <= next_state;
end

// ===============================
// 第二段：组合逻辑，下一状态逻辑
// ===============================
always @(*) begin
    case (current_state)
        IDLE: begin
            if ((!tx_link_empty || !rx_link_empty) && frame_save_en) begin
                next_state = COMPARE;
            end else begin
                next_state = IDLE;
            end
        end
        COMPARE: begin
            if (rd_tx_data_valid && rd_rx_data_valid) begin
                if (tx_smaller) begin
                    next_state = READ_TX;
                end else begin
                    next_state = READ_RX;
                end
            end
            else if(rd_tx_data_valid && !rd_rx_data_valid) 
                next_state = READ_TX;
            else if(!rd_tx_data_valid && rd_rx_data_valid) 
                next_state = READ_RX;
            else begin
                next_state = COMPARE;
            end
        end
        READ_TX: begin
            if (trasnsfer_done) begin
                next_state = JUDGE;
            end else begin
                next_state = READ_TX;
            end
        end
        READ_RX: begin
            if (trasnsfer_done) begin
                next_state = JUDGE;
            end else begin
                next_state = READ_RX;
            end
        end
        JUDGE: begin
            if(frame_save_en)
                next_state = TEANSFER_DONE;
            else
                next_state = JUDGE;
        end
        TEANSFER_DONE: begin
                if(rd_rx_data_valid && rd_tx_data_valid)
                        next_state = COMPARE;
                else if(rd_rx_data_valid)
                        next_state = READ_RX;
                else if(rd_tx_data_valid)
                        next_state = READ_TX;
                else
                    next_state = IDLE;
            end
        default: begin
            next_state = IDLE;
        end
    endcase
end

always@(*)begin
    rd_link_tx = 1'b0;
    rd_link_rx = 1'b0;
    if(current_state == IDLE)begin
        if (!tx_link_empty && !rx_link_empty && frame_save_en) begin
            // 两个FIFO都有数据，同时读取
            rd_link_tx = 1'b1;
            rd_link_rx = 1'b1;
        end else if (!tx_link_empty && frame_save_en) begin
            // 只有发送FIFO有数据
            rd_link_tx = 1'b1;
        end else if (!rx_link_empty && frame_save_en) begin
            // 只有接收FIFO有数据
            rd_link_rx = 1'b1;
        end
        else begin
            rd_link_tx = 1'b0;
            rd_link_rx = 1'b0;
        end
    end
    else if(next_state == TEANSFER_DONE)begin
        if(rd_tx_data_valid && !rx_link_empty)
            rd_link_rx = 1'b1;
        else if(rd_rx_data_valid && !tx_link_empty)
            rd_link_tx = 1'b1;
        else begin
            rd_link_tx = 1'b0;
            rd_link_rx = 1'b0;
        end
    end
    else begin
            rd_link_tx = 1'b0;
            rd_link_rx = 1'b0;
    end
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) 
        rd_tx_data_valid <= 1'b0;
    else if (rd_link_tx) 
        rd_tx_data_valid <= 1'b1;
    else if (trasnsfer_done && current_state == READ_TX) 
        rd_tx_data_valid <= 1'b0;
    else 
        rd_tx_data_valid <= rd_tx_data_valid;
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) 
        rd_rx_data_valid <= 1'b0;
    else if (rd_link_rx) 
        rd_rx_data_valid <= 1'b1;
    else if (trasnsfer_done && current_state == READ_RX) 
        rd_rx_data_valid <= 1'b0;
    else 
        rd_rx_data_valid <= rd_rx_data_valid;
end

reg  [15:0] tx_index;
reg  [15:0] rx_index;
wire [15:0] tx_length = (current_state == READ_TX) ? (dout_link_tx[15:0] % 8 == 0 ? dout_link_tx[15:0] >> 3:(dout_link_tx[15:0] >> 3) + 1):8'b0;
wire [15:0] rx_length = (current_state == READ_RX) ? (dout_link_rx[15:0] % 8 == 0 ? dout_link_rx[15:0] >> 3:(dout_link_rx[15:0] >> 3) + 1):8'b0;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        tx_index       <= 16'b0;
        rx_index       <= 16'b0;
        trasnsfer_done <= 1'b0;
    end
    else if(current_state == READ_TX)begin
        tx_index   <= tx_index + 1;
        trasnsfer_done <= 1'b0;
        if(tx_index == tx_length)
            trasnsfer_done <= 1'b1;
    end
    else if(current_state == READ_RX)begin
        rx_index   <= rx_index + 1;
        trasnsfer_done <= 1'b0;
        if(rx_index == rx_length)
            trasnsfer_done <= 1'b1;
    end
    else begin
        tx_index       <= 16'b0;
        rx_index       <= 16'b0;
        trasnsfer_done <= 1'b0 ;
    end
end

always @(posedge clk or negedge rst_n) begin
    if(!rst_n)begin
        frame_buffer_wr  <= 1'b0;
        frame_buffer_din <= 64'b0;
    end
    else if(current_state == READ_TX && tx_index <= tx_length)begin
        frame_buffer_wr  <= 1'b1;
        if(tx_index == 16'b0)
            frame_buffer_din <= {HEADER,dout_link_tx[15:0],port_num,28'b0};
        else
            frame_buffer_din <= dout_data_tx;
    end
    else if(current_state == READ_RX && rx_index <= rx_length)begin
        frame_buffer_wr  <= 1'b1;
        if(rx_index == 16'b0)
            frame_buffer_din <= {HEADER,dout_link_rx[15:0],port_num,28'b0};
        else
            frame_buffer_din <= dout_data_rx;
    end
    else begin
        frame_buffer_wr  <= 1'b0;
        frame_buffer_din <= 64'b0;
    end
end


assign rd_data_tx = (current_state == READ_TX) && (tx_index < tx_length);
assign rd_data_rx = (current_state == READ_RX) && (rx_index < rx_length);

wire frame_empty;
assign request = ~frame_empty;
    
//读数据帧进整合fifo
frame_link tx_frame_link (
  .clk(clk),                // input wire clk
  .rst(~rst_n),             // input wire rst
  .din({tx_time,tx_num}),   // input wire [79 : 0] din
  .wr_en(tx_neg & tx_save_en),  // input wire wr_en
  .rd_en(rd_link_tx),           // input wire rd_en
  .dout(dout_link_tx),          // output wire [79 : 0] dout
  .data_count(tx_link_count),   // output wire [4 : 0] data_count
  .empty(tx_link_empty)
);

frame_data tx_frame_data (
  .clk(clk),                // input wire clk
  .rst(~rst_n),             // input wire rst
  .din(tx_data),            // input wire [63 : 0] din
  .wr_en(tx_data_valid & tx_save_en), // input wire wr_en
  .rd_en(rd_data_tx),                 // input wire rd_en
  .dout(dout_data_tx),                // output wire [63 : 0] dout
  .data_count(tx_data_count),         // output wire [8 : 0] data_count
  .empty(tx_data_empty)
);

frame_link rx_frame_link (
  .clk(clk),                // input wire clk
  .rst(~rst_n),             // input wire rst
  .din({rx_time,rx_num}),   // input wire [79 : 0] din
  .wr_en(rx_neg & rx_save_en),   // input wire wr_en
  .rd_en(rd_link_rx),            // input wire rd_en
  .dout(dout_link_rx),           // output wire [79 : 0] dout
  .data_count(rx_link_count),    // output wire [4 : 0] data_count
  .empty(rx_link_empty)
);

frame_data rx_frame_data (
  .clk(clk),                // input wire clk
  .rst(~rst_n),             // input wire rst
  .din(rx_data),            // input wire [63 : 0] din
  .wr_en(rx_data_valid & rx_save_en), // input wire wr_en
  .rd_en(rd_data_rx),                 // input wire rd_en
  .dout(dout_data_rx),                // output wire [63 : 0] dout
  .data_count(rx_data_count),         // output wire [8 : 0] data_count
  .empty(rx_data_empty)
);


frame_buffer U_frame_buffer (
  .wr_clk(clk),                   // input wire wr_clk
  .wr_rst(~rst_n),                // input wire wr_rst
  .rd_clk(ui_clk),                // input wire rd_clk
  .rd_rst(~rst_n),                // input wire rd_rst
  .din(frame_buffer_din),         // input wire [63 : 0] din
  .wr_en(frame_buffer_wr),        // input wire wr_en
  .rd_en(port_frame_rd),          // input wire rd_en
  .dout(port_frame_data),         // output wire [63 : 0] dout
  .full(full),                    // output wire full
  .empty(frame_empty),            // output wire empty
  .rd_data_count(rd_frame_count), // output wire [9 : 0] rd_data_count
  .wr_data_count(wr_frame_count)  // output wire [9 : 0] wr_data_count
);


endmodule
