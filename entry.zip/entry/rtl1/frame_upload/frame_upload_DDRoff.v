`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/03/18 17:16:03
// Design Name: 
// Module Name: frame_upload_DDRoff
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////
// Module Name: frame_upload_DDRoff
// Description: 4端口公平轮询(Round-Robin)帧汇总与 AXI-Stream 上报模块
//              支持解析 16'hbeef 帧头、TLV不定长传输与精确的反压握手
//////////////////////////////////////////////////////////////////////////////////
`timescale 1ns / 1ps
module frame_upload_DDRoff(
    input  wire               clk,
    input  wire               rst_n,
    
    // 端口 Request 信号 (对应各端口的 ~frame_empty)
    input  wire               request1,
    input  wire               request2,
    input  wire               request3,
    input  wire               request4,

    // 端口数据输入 (FIFO 读出数据)
    input  wire [63:0]        port_frame_data1,
    input  wire [63:0]        port_frame_data2,
    input  wire [63:0]        port_frame_data3,
    input  wire [63:0]        port_frame_data4,

    // 端口读使能输出 (发给 FIFO)
    output reg                port_frame_rd1,
    output reg                port_frame_rd2, 
    output reg                port_frame_rd3, 
    output reg                port_frame_rd4,

    // AXI-Stream 上报接口
    output      [63:0]        m_axis_tdata_bigend ,
    output      [7:0]         m_axis_tkeep_bigend ,
    output reg                m_axis_up_load_valid,
    output reg                m_axis_up_load_last ,
    input  wire               m_axis_up_load_ready,

    // 上位机控制接口
    input  wire               card_upload_ren_1   ,
    output reg                card_upload_flag_1  
);

//=========================================================
// 状态机参数定义
//=========================================================
localparam [2:0] IDLE       = 3'd0;
localparam [2:0] ARB        = 3'd1;  // 仲裁
localparam [2:0] REQ_HDR    = 3'd2;  // 发起读 Header 请求
localparam [2:0] PARSE_HDR  = 3'd3;  // 解析 Header 并输出
localparam [2:0] WAIT_READY = 3'd4;  // AXI 握手等待
localparam [2:0] REQ_DATA   = 3'd5;  // 请求下一拍 Payload
localparam [2:0] SEND_DATA  = 3'd6;  // 发送 Payload
localparam [2:0] WAIT_HOST  = 3'd7;  // 发送 Payload

reg [2:0] state;

//=========================================================
// 轮询仲裁 (Round-Robin) 逻辑
//=========================================================
reg  [1:0] rr_ptr;      // 轮询优先级指针: 0~3
reg  [1:0] grant_id;    // 当前获得授权的端口号
reg  [1:0] next_grant;  // 组合逻辑计算出的下一个授权端口
reg  [63:0] m_axis_up_load_data;
reg  [7:0] m_axis_up_load_keep;
wire [3:0] req_vec = {request4, request3, request2, request1};
assign m_axis_tdata_bigend = {m_axis_up_load_data[7:0], m_axis_up_load_data[15:8], m_axis_up_load_data[23:16], m_axis_up_load_data[31:24], m_axis_up_load_data[39:32], m_axis_up_load_data[47:40], m_axis_up_load_data[55:48], m_axis_up_load_data[63:56]};  //大小端转换
assign m_axis_tkeep_bigend = {m_axis_up_load_keep[0], m_axis_up_load_keep[1], m_axis_up_load_keep[2], m_axis_up_load_keep[3], m_axis_up_load_keep[4], m_axis_up_load_keep[5], m_axis_up_load_keep[6], m_axis_up_load_keep[7]};

// 寻找下一个有请求的端口 (严格公平的 Round-Robin)
always @(*) begin
    next_grant = rr_ptr; // 默认保持
    case (rr_ptr)
        2'd0: begin
                 if (request1) next_grant = 2'd0;
            else if (request2) next_grant = 2'd1;
            else if (request3) next_grant = 2'd2;
            else if (request4) next_grant = 2'd3;
        end
        2'd1: begin
                 if (request2) next_grant = 2'd1;
            else if (request3) next_grant = 2'd2;
            else if (request4) next_grant = 2'd3;
            else if (request1) next_grant = 2'd0;
        end
        2'd2: begin
                 if (request3) next_grant = 2'd2;
            else if (request4) next_grant = 2'd3;
            else if (request1) next_grant = 2'd0;
            else if (request2) next_grant = 2'd1;
        end
        2'd3: begin
                 if (request4) next_grant = 2'd3;
            else if (request1) next_grant = 2'd0;
            else if (request2) next_grant = 2'd1;
            else if (request3) next_grant = 2'd2;
        end
    endcase
end

//=========================================================
// 数据复用与包长计算逻辑 (组合逻辑提取)
//=========================================================
// 1. 数据多路复用器
wire [63:0] mux_data = (grant_id == 2'd0) ? port_frame_data1 :
                       (grant_id == 2'd1) ? port_frame_data2 :
                       (grant_id == 2'd2) ? port_frame_data3 :
                                            port_frame_data4;

// 2. 实时从当前 mux_data 的 Header 中提取信息
wire [15:0] current_payload_bytes = mux_data[47:32];
// 将字节数转换为 64-bit(8 Byte) 的 Word 数量，向上取整
wire [15:0] current_word_count    = (current_payload_bytes == 16'd0) ? 16'd0 : 
                                    ((current_payload_bytes - 16'd1) >> 3) + 16'd1;

// 3. 内部计数与状态寄存器
reg [15:0] latched_payload_bytes; // 锁存下来的字节数，用于算 Keep
reg [15:0] words_left;            // 剩余需要发送的 Word 数量

// 4. 根据锁存的字节数计算 AXI-Stream 的 TKeep 信号 (最后拍的有效掩码)
reg [7:0] last_keep;
always @(*) begin
    case (latched_payload_bytes[2:0]) // 对 8 取余
        3'd1: last_keep = 8'b1000_0000;
        3'd2: last_keep = 8'b1100_0000;
        3'd3: last_keep = 8'b1110_0000;
        3'd4: last_keep = 8'b1111_0000;
        3'd5: last_keep = 8'b1111_1000;
        3'd6: last_keep = 8'b1111_1100;
        3'd7: last_keep = 8'b1111_1110;
        3'd0: last_keep = 8'b1111_1111; // 恰好整除，全部有效
    endcase
end

//=========================================================
// 主控制状态机与数据搬运
//=========================================================
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        state                 <= IDLE;
        rr_ptr                <= 2'd0;
        grant_id              <= 2'd0;
        port_frame_rd1        <= 1'b0; 
        port_frame_rd2        <= 1'b0;
        port_frame_rd3        <= 1'b0; 
        port_frame_rd4        <= 1'b0;
        m_axis_up_load_valid  <= 1'b0;
        m_axis_up_load_last   <= 1'b0;
        m_axis_up_load_data   <= 64'b0;
        m_axis_up_load_keep   <= 8'h00;
        words_left            <= 16'd0;
        latched_payload_bytes <= 16'd0;
    end else begin
        // 默认将 FIFO 读使能拉低，保证只产生单拍脉冲
        port_frame_rd1 <= 1'b0; 
        port_frame_rd2 <= 1'b0;
        port_frame_rd3 <= 1'b0; 
        port_frame_rd4 <= 1'b0;

        case (state)
            IDLE: begin
                // 当全局上传使能开启，且有任何端口请求时，启动仲裁
                if ( req_vec != 4'b0000) begin
                    state <= ARB;
                end
            end

            ARB: begin
                // 获取授权，更新轮询优先级指针，防止饿死
                grant_id <= next_grant;
                rr_ptr   <= next_grant + 2'd1;

                // 发出读 Header 脉冲
                case (next_grant)
                    2'd0: port_frame_rd1 <= 1'b1;
                    2'd1: port_frame_rd2 <= 1'b1;
                    2'd2: port_frame_rd3 <= 1'b1;
                    2'd3: port_frame_rd4 <= 1'b1;
                endcase
                state <= REQ_HDR;
            end

            REQ_HDR: begin
                // 等待 1 拍，让数据从 FIFO 读出到 port_frame_dataX
                state <= PARSE_HDR;
            end

            PARSE_HDR: begin
                // 检查是否是合法的帧头
                if (mux_data[63:48] == 16'hbeef) begin
                    // 1. 将 Header 作为第一拍推上 AXI 总线
                    m_axis_up_load_data  <= mux_data;
                    m_axis_up_load_valid <= 1'b1;
                    m_axis_up_load_keep  <= 8'hFF;
                    
                    // 2. 锁存 Payload 长度与切分片数
                    latched_payload_bytes <= current_payload_bytes;
                    words_left            <= current_word_count;
                    
                    // 3. 如果 Payload 长度是 0，说明这个包只有 Header，直接置 Last
                    if (current_word_count == 16'd0)
                        m_axis_up_load_last <= 1'b1;
                    else
                        m_axis_up_load_last <= 1'b0;
                        
                    state <= WAIT_READY;
                end else begin
                    // 异常：没对齐 beef (非预期的错位数据)，丢弃并复位
                    state <= IDLE;
                end
            end

            WAIT_READY: begin
                // AXI-Stream 反压握手：等待下游拉高 ready
                if (m_axis_up_load_valid && m_axis_up_load_ready) begin
                    m_axis_up_load_valid <= 1'b0; // 一拍传完，立刻拉低 Valid
                    m_axis_up_load_last  <= 1'b0;

                    if (words_left == 16'd0) begin
                        // 这包数据传完了，回到 IDLE 寻找下一帧
                        state <= WAIT_HOST;
                    end else begin
                        // 还没传完，继续请求下一拍 Payload
                        case (grant_id)
                            2'd0: port_frame_rd1 <= 1'b1;
                            2'd1: port_frame_rd2 <= 1'b1;
                            2'd2: port_frame_rd3 <= 1'b1;
                            2'd3: port_frame_rd4 <= 1'b1;
                        endcase
                        state <= REQ_DATA;
                    end
                end
            end

            REQ_DATA: begin
                // 同样等待 1 拍 FIFO 的读出延迟
                state <= SEND_DATA;
            end

            SEND_DATA: begin
                // 将 Payload 推上 AXI 总线
                m_axis_up_load_data  <= mux_data;
                m_axis_up_load_valid <= 1'b1;
                
                // 判断是否是这个包的最后一拍 (Words Left == 1)
                if (words_left == 16'd1) begin
                    m_axis_up_load_last <= 1'b1;
                    m_axis_up_load_keep <= last_keep; // 赋予精确的尾部掩码
                end else begin
                    m_axis_up_load_last <= 1'b0;
                    m_axis_up_load_keep <= 8'hFF;     // 中间数据全部有效
                end

                words_left <= words_left - 16'd1;
                state <= WAIT_READY;
            end

            WAIT_HOST:begin
                if(!card_upload_flag_1)
                    state <= IDLE;
                else
                    state <= WAIT_HOST;
            end


            default: state <= IDLE;
        endcase
    end
end


always@(posedge clk or negedge rst_n ) begin
    if(!rst_n)begin
        card_upload_flag_1 <= 1'b0;
    end
    else if(card_upload_ren_1)begin
        card_upload_flag_1 <= 1'b0;
    end
    else if(m_axis_up_load_last)begin
        card_upload_flag_1 <= 1'b1;
    end
    else begin
        card_upload_flag_1 <= card_upload_flag_1;
    end
end

`ifdef DEBUG
ila_frame_upload U_ila_frame_upload (
	.clk        (clk                    ), // input wire clk
	.probe0     (request1               ), // input wire [0:0]  probe0  
	.probe1     (request2               ), // input wire [0:0]  probe1 
	.probe2     (request3               ), // input wire [0:0]  probe2 
	.probe3     (request4               ), // input wire [0:0]  probe3 
	.probe4     (port_frame_data1       ), // input wire [63:0]  probe4 
	.probe5     (port_frame_data2       ), // input wire [63:0]  probe5 
	.probe6     (port_frame_data3       ), // input wire [63:0]  probe6 
	.probe7     (port_frame_data4       ), // input wire [63:0]  probe7 
	.probe8     (port_frame_rd1         ), // input wire [0:0]  probe8 
	.probe9     (port_frame_rd2         ), // input wire [0:0]  probe9 
	.probe10    (port_frame_rd3         ), // input wire [0:0]  probe10 
	.probe11    (port_frame_rd4         ), // input wire [0:0]  probe11 
	.probe12    (m_axis_tdata_bigend    ), // input wire [63:0]  probe12 
	.probe13    (m_axis_tkeep_bigend    ), // input wire [7:0]  probe13 
	.probe14    (m_axis_up_load_valid   ), // input wire [0:0]  probe14 
	.probe15    (m_axis_up_load_last    ), // input wire [0:0]  probe15 
	.probe16    (m_axis_up_load_ready   ), // input wire [0:0]  probe16 
	.probe17    (card_upload_ren_1      ), // input wire [0:0]  probe17 
	.probe18    (card_upload_flag_1     )  // input wire [0:0]  probe18
);
`endif
endmodule












