`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/10/13 20:02:40
// Design Name: 
// Module Name: axi_full2axis
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module axi_full2axis(
    input             clk,
    input             rst_n,
    input   [63:0]    frame_upload ,
    input             frame_upload_valid,

    output  [63:0]    m_axis_up_load_data ,
    output  [7:0]     m_axis_up_load_keep ,
    output            m_axis_up_load_valid,
    output            m_axis_up_load_last ,
    input             m_axis_up_load_ready,

    input             card_upload_ren_1   ,
    output   reg      card_upload_flag_1  ,
    output            axi_full2axis_ready

    );


parameter IDLE     = 4'b0001,
          INFOR    = 4'b0010,
          TRANSFER = 4'b0100,
          FINISH   = 4'b1000;

reg [3:0]  cstate,nstate;
reg [15:0] transfer_length;
reg [15:0] transfer_index;


reg        axis_valid;

//数据读取
wire rd_en;
wire empty;
wire almost_full;
wire [63:0] dout;
wire [7 :0] data_count;

wire tx_en = m_axis_up_load_ready & axis_valid;
    
assign m_axis_up_load_keep  = 8'hff;
assign m_axis_up_load_data  = {dout[7:0],dout[15:8],dout[23:16],dout[31:24],dout[39:32],dout[47:40],dout[55:48],dout[63:56]};

assign m_axis_up_load_valid = axis_valid;
assign m_axis_up_load_last  = (transfer_index == transfer_length) && transfer_length != 0;



assign axi_full2axis_ready = !almost_full;

always@(posedge clk or negedge rst_n) begin
    if(!rst_n)
        cstate <= IDLE;
    else
        cstate <= nstate;
end

always @(*) begin
    case (cstate)
        IDLE: begin
            if(!empty)
                nstate = INFOR;
            else
                nstate = IDLE;
        end
        INFOR:begin
            if(dout[63:48] == 16'hbeef)
                nstate = TRANSFER;
            else
                nstate = IDLE;
        end
        TRANSFER: begin
            if (m_axis_up_load_last)
                nstate = FINISH;
            else
                nstate = TRANSFER;
        end
        FINISH:begin
            if(!card_upload_flag_1)
                nstate = IDLE;
            else
                nstate = FINISH;
        end
        default: nstate = IDLE;
    endcase
end

assign rd_en = (nstate == INFOR) || (tx_en && transfer_index < transfer_length) ;

always@(posedge clk or negedge rst_n)begin
    if(!rst_n)
        transfer_length <= 16'b0;
    else if(cstate == INFOR)
        transfer_length <= dout[47:32] % 8 == 0 ? dout[47:32] >> 3:(dout[47:32] >> 3) + 1;
    else
        transfer_length <= transfer_length;
end

always@(posedge clk or negedge rst_n) begin
    if(!rst_n)begin
        axis_valid <= 1'b0;
        transfer_index <= 16'b0;
    end
    else if(cstate == TRANSFER)begin
        axis_valid <= 1'b1;
        if(tx_en)begin
            transfer_index <= transfer_index + 1'b1;
            if(transfer_index == transfer_length)begin
                transfer_index <= 16'b0;
                axis_valid <= 1'b0;
            end
        end
        else 
            transfer_index <= transfer_index;
    end
    else begin
        axis_valid <= 1'b0;
        transfer_index <= 16'b0;
    end
end


always@(posedge clk or negedge rst_n) begin
    if(!rst_n)
        card_upload_flag_1 <= 1'b1;
    else if(card_upload_ren_1)
        card_upload_flag_1 <= 1'b0;
    else if(m_axis_up_load_last)
        card_upload_flag_1 <= 1'b1;
    else 
        card_upload_flag_1 <= card_upload_flag_1;
end


axi_full2axis_fifo U_axi_full2axis_fifo (
  .clk(clk),                // input wire clk
  .rst(~rst_n),                // input wire rst
  .din(frame_upload),                // input wire [63 : 0] din
  .wr_en(frame_upload_valid && axi_full2axis_ready),            // input wire wr_en
  .rd_en(rd_en),            // input wire rd_en
  .dout(dout),              // output wire [63 : 0] dout
  .full(full),              // output wire full
  .empty(empty),            // output wire empty
  .almost_full(almost_full),
  .data_count(data_count)  // output wire [7 : 0] data_count
);



endmodule
