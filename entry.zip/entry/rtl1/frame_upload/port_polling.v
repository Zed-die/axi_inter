`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: why
// 
// Create Date: 2025/10/09 20:20:29
// Design Name: 
// Module Name: port_polling
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module port_polling#(
    // Base address of targeted slave
    parameter  C_M_TARGET_SLAVE_BASE_ADDR1   = 31'h0000_0000,
    parameter  C_M_TARGET_SLAVE_BASE_ADDR2   = 31'h2000_0000,
    parameter  C_M_TARGET_SLAVE_BASE_ADDR3   = 31'h4000_0000,
    parameter  C_M_TARGET_SLAVE_BASE_ADDR4   = 31'h6000_0000,
    // Burst Length. Supports 1, 2, 4, 8, 16, 32, 64, 128, 256 burst lengths
    parameter integer C_M_AXI_BURST_LEN = 31,
    // Thread ID Width
    parameter integer C_M_AXI_ID_WIDTH  = 3,
    // Width of Address Bus
    parameter integer C_M_AXI_ADDR_WIDTH    = 31,
    // Width of Data Bus
    parameter integer C_M_AXI_DATA_WIDTH    = 64,
    // Width of User Write Address Bus
    parameter integer C_M_AXI_AWUSER_WIDTH  = 1,
    // Width of User Read Address Bus
    parameter integer C_M_AXI_ARUSER_WIDTH  = 1,
    // Width of User Write Data Bus
    parameter integer C_M_AXI_WUSER_WIDTH   = 1,
    // Width of User Read Data Bus
    parameter integer C_M_AXI_RUSER_WIDTH   = 1,
    // Width of User Response Bus
    parameter integer C_M_AXI_BUSER_WIDTH   = 1)
(
    input wire  M_AXI_ACLK,
    input wire  M_AXI_ARESETN,
    //请求信号
    input    request1,
    input    request2,
    input    request3,
    input    request4,

    input   [63:0]     port_frame_data1,
    input   [63:0]     port_frame_data2,
    input   [63:0]     port_frame_data3,
    input   [63:0]     port_frame_data4,

    output    reg      port_frame_rd1,
    output    reg      port_frame_rd2, 
    output    reg      port_frame_rd3, 
    output    reg      port_frame_rd4,

    output    reg      lock_port,

    input     init_calib_complete,
    input     read_ddr_port1,
    input     read_ddr_port2,
    input     read_ddr_port3,
    input     read_ddr_port4,
    input     axi_full2axis_ready,

    output [C_M_AXI_ID_WIDTH-1 : 0]     M_AXI_AWID   ,
    output [C_M_AXI_ADDR_WIDTH-1 : 0]   M_AXI_AWADDR ,
    output [7 : 0]                      M_AXI_AWLEN  ,
    output [2 : 0]                      M_AXI_AWSIZE ,
    output [1 : 0]                      M_AXI_AWBURST,
    output                              M_AXI_AWLOCK ,
    output [3 : 0]                      M_AXI_AWCACHE,
    output [2 : 0]                      M_AXI_AWPROT ,
    output [3 : 0]                      M_AXI_AWQOS  ,
    output [C_M_AXI_AWUSER_WIDTH-1 : 0] M_AXI_AWUSER ,
    output                              M_AXI_AWVALID,
    input                               M_AXI_AWREADY,
    output [C_M_AXI_DATA_WIDTH-1 : 0]   M_AXI_WDATA  ,
    output [C_M_AXI_DATA_WIDTH/8-1 : 0] M_AXI_WSTRB  ,
    output                              M_AXI_WLAST  ,
    output [C_M_AXI_WUSER_WIDTH-1 : 0]  M_AXI_WUSER  ,
    output                              M_AXI_WVALID ,
    input                               M_AXI_WREADY ,
    input  [C_M_AXI_ID_WIDTH-1 : 0]     M_AXI_BID    ,
    input  [1 : 0]                      M_AXI_BRESP  ,
    input  [C_M_AXI_BUSER_WIDTH-1 : 0]  M_AXI_BUSER  ,
    input                               M_AXI_BVALID ,
    output                              M_AXI_BREADY ,
    output [C_M_AXI_ID_WIDTH-1 : 0]     M_AXI_ARID   ,
    output [C_M_AXI_ADDR_WIDTH-1 : 0]   M_AXI_ARADDR ,
    output [7 : 0]                      M_AXI_ARLEN  ,
    output [2 : 0]                      M_AXI_ARSIZE ,
    output [1 : 0]                      M_AXI_ARBURST,
    output                              M_AXI_ARLOCK , 
    output [3 : 0]                      M_AXI_ARCACHE,
    output [2 : 0]                      M_AXI_ARPROT ,
    output [3 : 0]                      M_AXI_ARQOS  ,
    output [C_M_AXI_ARUSER_WIDTH-1 : 0] M_AXI_ARUSER ,
    output                              M_AXI_ARVALID,
    input                               M_AXI_ARREADY,
    input  [C_M_AXI_ID_WIDTH-1 : 0]     M_AXI_RID    ,
    input  [C_M_AXI_DATA_WIDTH-1 : 0]   M_AXI_RDATA  ,
    input  [1 : 0]                      M_AXI_RRESP  ,
    input                               M_AXI_RLAST  ,
    input  [C_M_AXI_RUSER_WIDTH-1 : 0]  M_AXI_RUSER  ,
    input                               M_AXI_RVALID ,
    output                              M_AXI_RREADY 

);


//log2函数
function integer clogb2 (input integer bit_depth);              
begin                                                           
    for(clogb2=0; bit_depth>0; clogb2=clogb2+1)                   
        bit_depth = bit_depth >> 1;                                 
    end                                                           
endfunction        

//DDR写,四端口轮询
parameter   IDLE          = 10'b00_0000_0001,
            PORT_SELECT   = 10'b00_0000_0010,
            WR_ADDR       = 10'b00_0000_0100, 
            WRITE         = 10'b00_0000_1000, 
            WAIT_RESPONSE = 10'b00_0001_0000, 
            READ_ADDR     = 10'b00_0010_0000,
            READ          = 10'b00_0100_0000,
            WRITE_FINISH  = 10'b00_1000_0000,
            FINISH_RADDR  = 10'b01_0000_0000,
            READ_FINISH   = 10'b10_0000_0000;

reg [9:0] cstate,nstate;

//调度信号
reg RR_en;
reg  [3:0] request_i;
wire [3:0] request;  
wire [3:0] grant_o;    
wire   grant_valid;
assign request = {request4, request3, request2, request1};

//AXI4 internal temp signals
reg [C_M_AXI_ADDR_WIDTH-1 : 0]  axi_awaddr;
reg [C_M_AXI_ADDR_WIDTH-1 : 0]  axi_awaddr1;
reg [C_M_AXI_ADDR_WIDTH-1 : 0]  axi_awaddr2;
reg [C_M_AXI_ADDR_WIDTH-1 : 0]  axi_awaddr3;
reg [C_M_AXI_ADDR_WIDTH-1 : 0]  axi_awaddr4;

reg [C_M_AXI_ADDR_WIDTH-1 : 0]  axi_araddr1;
reg [C_M_AXI_ADDR_WIDTH-1 : 0]  axi_araddr2;
reg [C_M_AXI_ADDR_WIDTH-1 : 0]  axi_araddr3;
reg [C_M_AXI_ADDR_WIDTH-1 : 0]  axi_araddr4;

wire [7:0] axi_awlen = C_M_AXI_BURST_LEN;
wire [7:0] axi_arlen = C_M_AXI_BURST_LEN;
reg     axi_awvalid;
reg [C_M_AXI_DATA_WIDTH-1 : 0]  axi_wdata;
reg     axi_wlast;
reg     axi_wvalid;
reg     axi_bready;
reg [C_M_AXI_ADDR_WIDTH-1 : 0]  axi_araddr;
reg     axi_arvalid;
reg     axi_rready;

//AXI4 User signals
reg [15 : 0] write_index;
reg [15 : 0] read_index;

//写数据握手成功
wire wnext;
assign wnext = M_AXI_WREADY & axi_wvalid;

reg rd_port1_en;
reg rd_port2_en;
reg rd_port3_en;
reg rd_port4_en;
wire [3:0] rd_port_en;
assign rd_port_en = {rd_port4_en, rd_port3_en, rd_port2_en, rd_port1_en};
wire [3:0] upload_port;
assign upload_port = rd_port_en & (~rd_port_en + 1);

//I/O Connections. Write Address (AW)
assign M_AXI_AWID   = 'b0;
//The AXI address is a concatenation of the target base address + active offset range
assign M_AXI_AWADDR = axi_awaddr;
//Burst LENgth is number of transaction beats, minus 1
assign M_AXI_AWLEN  = axi_awlen;
//Size should be C_M_AXI_DATA_WIDTH, in 2^SIZE bytes, otherwise narrow bursts are used
assign M_AXI_AWSIZE = clogb2((C_M_AXI_DATA_WIDTH/8)-1);
//INCR burst type is usually used, except for keyhole bursts
assign M_AXI_AWBURST = 2'b01;
assign M_AXI_AWLOCK  = 1'b0;
//Update value to 4'b0011 if coherent accesses to be used via the Zynq ACP port. Not Allocated, Modifiable, not Bufferable. Not Buffer
assign M_AXI_AWCACHE = 4'b0010;
assign M_AXI_AWPROT  = 3'h0;
assign M_AXI_AWQOS   = 4'h0;
assign M_AXI_AWUSER  = 'b1;
assign M_AXI_AWVALID = axi_awvalid;
//Write Data(W)
assign M_AXI_WDATA  = axi_wdata;
//All bursts are complete and aligned in this example
assign M_AXI_WSTRB  = {(C_M_AXI_DATA_WIDTH/8){1'b1}};
assign M_AXI_WLAST  = axi_wlast;
assign M_AXI_WUSER  = 'b0;
assign M_AXI_WVALID = axi_wvalid;
//Write Response (B)
assign M_AXI_BREADY = axi_bready;
//Read Address (AR)
assign M_AXI_ARID   = 'b0;
assign M_AXI_ARADDR = axi_araddr;
//Burst LENgth is number of transaction beats, minus 1
assign M_AXI_ARLEN  = axi_arlen;
//Size should be C_M_AXI_DATA_WIDTH, in 2^n bytes, otherwise narrow bursts are used
assign M_AXI_ARSIZE = clogb2((C_M_AXI_DATA_WIDTH/8)-1);
//INCR burst type is usually used, except for keyhole bursts
assign M_AXI_ARBURST = 2'b01;
assign M_AXI_ARLOCK  = 1'b0;
//Update value to 4'b0011 if coherent accesses to be used via the Zynq ACP port. Not Allocated, Modifiable, not Bufferable. Not Buffer
assign M_AXI_ARCACHE = 4'b0010;
assign M_AXI_ARPROT  = 3'h0;
assign M_AXI_ARQOS   = 4'h0;
assign M_AXI_ARUSER  = 'b1;
assign M_AXI_ARVALID = axi_arvalid;
//Read and Read Response (R)
assign M_AXI_RREADY = axi_full2axis_ready;
//Burst size in bytes
assign burst_size_bytes = (axi_arlen+1) * C_M_AXI_DATA_WIDTH/8;

//读端口标识
reg read_ddr_port1_f;
reg read_ddr_port2_f;
reg read_ddr_port3_f;
reg read_ddr_port4_f;
wire read_ddr_port1_flag;
wire read_ddr_port2_flag;
wire read_ddr_port3_flag;
wire read_ddr_port4_flag;

always@(posedge M_AXI_ACLK or negedge M_AXI_ARESETN) begin
    if (~M_AXI_ARESETN) begin
        read_ddr_port1_f <= 1'b0;
        read_ddr_port2_f <= 1'b0;
        read_ddr_port3_f <= 1'b0;
        read_ddr_port4_f <= 1'b0;
    end
    else begin
        read_ddr_port1_f <= read_ddr_port1;
        read_ddr_port2_f <= read_ddr_port2;
        read_ddr_port3_f <= read_ddr_port3;
        read_ddr_port4_f <= read_ddr_port4;
    end
end

assign read_ddr_port1_flag = ~read_ddr_port1_f & read_ddr_port1;
assign read_ddr_port2_flag = ~read_ddr_port2_f & read_ddr_port2;
assign read_ddr_port3_flag = ~read_ddr_port3_f & read_ddr_port3;
assign read_ddr_port4_flag = ~read_ddr_port4_f & read_ddr_port4;

//调度信号使能
always@(posedge M_AXI_ACLK or negedge M_AXI_ARESETN) begin
    if (~M_AXI_ARESETN) begin
        RR_en     <= 1'b0;
        request_i <= 4'b0;
    end
    else if(cstate == IDLE && |request && init_calib_complete)begin
        RR_en     <= 1'b1;
        request_i <= request;
    end
    else begin
        RR_en     <= 1'b0;
        request_i <= 4'b0;
    end
end

//进入读状态锁死端口存帧
always@(posedge M_AXI_ACLK or negedge M_AXI_ARESETN) begin
    if(~M_AXI_ARESETN)
        lock_port <= 1'b0;
    else if(read_ddr_port1 || read_ddr_port2 || read_ddr_port3 || read_ddr_port4) 
        lock_port <= 1'b1;
    else
        lock_port <=lock_port;
end


//AXI 状态机
always@(posedge M_AXI_ACLK or negedge M_AXI_ARESETN) begin
    if(~M_AXI_ARESETN)
        cstate <= IDLE;
    else
        cstate <= nstate;
end

always@(*) begin
    case(cstate)
        IDLE: begin
            if(|upload_port && ~(|request))  //所有已存入前级fifo的帧全进入DDR后再读
                nstate = READ_ADDR;
            else if(|request && init_calib_complete) 
                nstate = PORT_SELECT;
            else 
                nstate = IDLE;
        end
        PORT_SELECT: begin
            if(grant_valid) 
                nstate = WR_ADDR;
            else 
                nstate = PORT_SELECT;
        end
        WR_ADDR:begin
            if(M_AXI_AWREADY && axi_awvalid)
                nstate = WRITE;
            else
                nstate = WR_ADDR;
        end
        WRITE:begin
            if(write_index == axi_awlen)
                nstate = WAIT_RESPONSE;
            else
                nstate = WRITE;
        end
        WAIT_RESPONSE:begin
            if(M_AXI_BVALID)
                nstate = WRITE_FINISH;
            else
                nstate = WAIT_RESPONSE;
            end 
        READ_ADDR:begin
            if(M_AXI_ARREADY && axi_arvalid)
                nstate = READ;
            else
                nstate = READ_ADDR;
        end
        READ:begin
            if(M_AXI_RLAST && M_AXI_RVALID)
                nstate = FINISH_RADDR;
            else
                nstate = READ;
        end
        WRITE_FINISH: nstate = IDLE;
        FINISH_RADDR: nstate = READ_FINISH;
        READ_FINISH : nstate = IDLE;
        
        default: nstate = IDLE;
    endcase
end


//AXI写事务握手
always @(posedge M_AXI_ACLK or negedge M_AXI_ARESETN)begin                                                                
    if(!M_AXI_ARESETN)
        axi_awvalid <= 1'b0;
    else if (M_AXI_AWREADY && axi_awvalid)
        axi_awvalid <= 1'b0;
    else if(cstate == WR_ADDR)
        axi_awvalid <= 1'b1;
    else
        axi_awvalid <= axi_awvalid;
end 

//地址赋予
always @(posedge M_AXI_ACLK or negedge M_AXI_ARESETN)begin                                                                
    if(!M_AXI_ARESETN)
        axi_awaddr <= 31'b0;
    else if (M_AXI_AWREADY && axi_awvalid)
        axi_awaddr <= 31'b0;
    else if(cstate == WR_ADDR)begin
        case(grant_o)
            4'b0001:axi_awaddr <= axi_awaddr1;
            4'b0010:axi_awaddr <= axi_awaddr2;
            4'b0100:axi_awaddr <= axi_awaddr3;
            4'b1000:axi_awaddr <= axi_awaddr4;
            default:axi_awaddr <= 31'b0;
        endcase
    end
    else
        axi_awaddr <= 31'b0;
end 

//地址管理
always @(posedge M_AXI_ACLK or negedge M_AXI_ARESETN)begin                                                                
    if(!M_AXI_ARESETN)begin
        axi_awaddr1 <= C_M_TARGET_SLAVE_BASE_ADDR1;//初始地址
        axi_awaddr2 <= C_M_TARGET_SLAVE_BASE_ADDR2;
        axi_awaddr3 <= C_M_TARGET_SLAVE_BASE_ADDR3;
        axi_awaddr4 <= C_M_TARGET_SLAVE_BASE_ADDR4;
    end
    else if (cstate == WRITE_FINISH)begin
        case(grant_o)
            4'b0001:axi_awaddr1 <= axi_awaddr1 + (axi_awlen + 1'b1)*(C_M_AXI_DATA_WIDTH/8);
            4'b0010:axi_awaddr2 <= axi_awaddr2 + (axi_awlen + 1'b1)*(C_M_AXI_DATA_WIDTH/8);
            4'b0100:axi_awaddr3 <= axi_awaddr3 + (axi_awlen + 1'b1)*(C_M_AXI_DATA_WIDTH/8);
            4'b1000:axi_awaddr4 <= axi_awaddr4 + (axi_awlen + 1'b1)*(C_M_AXI_DATA_WIDTH/8);
            default:begin
                axi_awaddr1 <= axi_awaddr1;
                axi_awaddr2 <= axi_awaddr2;
                axi_awaddr3 <= axi_awaddr3;
                axi_awaddr4 <= axi_awaddr4;
            end
        endcase
    end
    else begin
        axi_awaddr1 <= axi_awaddr1;
        axi_awaddr2 <= axi_awaddr2;
        axi_awaddr3 <= axi_awaddr3;
        axi_awaddr4 <= axi_awaddr4;
    end
end 

//AXI写数据握手
always @(posedge M_AXI_ACLK or negedge M_AXI_ARESETN)begin                                                                             
        if (M_AXI_ARESETN == 0)                                                                                                                               
            axi_wvalid <= 1'b0;                                                                                                                                                                
        else if (cstate == WR_ADDR && nstate == WRITE)                                                                                                        
            axi_wvalid <= 1'b1;                                                                                                                                                                    
        else if (write_index == axi_awlen && wnext)                                                    
            axi_wvalid <= 1'b0;                                                           
        else                                                                            
            axi_wvalid <= axi_wvalid;                                                     
end 

always @(posedge M_AXI_ACLK or negedge M_AXI_ARESETN)begin                                                                
    if(!M_AXI_ARESETN)
        write_index <= 5'b0;
    else if(cstate == WR_ADDR)
        write_index <= 5'b0;
    else if(cstate == WRITE && wnext) 
        write_index <= write_index + 1'b1;
    else
        write_index <= write_index;
end  

always @(*)begin
    if(!M_AXI_ARESETN)
        axi_wdata = 64'b0;
    else begin
        case(grant_o)
            4'b0001:axi_wdata = port_frame_data1;
            4'b0010:axi_wdata = port_frame_data2;
            4'b0100:axi_wdata = port_frame_data3;
            4'b1000:axi_wdata = port_frame_data4;
            default:axi_wdata = 64'b0;
        endcase
    end
end

//读fifo使能
always @(*)begin
    if(!M_AXI_ARESETN)begin
        port_frame_rd1 = 1'b0;
        port_frame_rd2 = 1'b0;
        port_frame_rd3 = 1'b0;
        port_frame_rd4 = 1'b0;
    end
    else begin
        port_frame_rd1 = 1'b0;
        port_frame_rd2 = 1'b0;
        port_frame_rd3 = 1'b0;
        port_frame_rd4 = 1'b0;
        case(grant_o)
            4'b0001:port_frame_rd1 = ((M_AXI_AWREADY && axi_awvalid)||((cstate == WRITE) && (write_index <= axi_awlen - 1) && wnext)) && request1;
            4'b0010:port_frame_rd2 = ((M_AXI_AWREADY && axi_awvalid)||((cstate == WRITE) && (write_index <= axi_awlen - 1) && wnext)) && request2;
            4'b0100:port_frame_rd3 = ((M_AXI_AWREADY && axi_awvalid)||((cstate == WRITE) && (write_index <= axi_awlen - 1) && wnext)) && request3;
            4'b1000:port_frame_rd4 = ((M_AXI_AWREADY && axi_awvalid)||((cstate == WRITE) && (write_index <= axi_awlen - 1) && wnext)) && request4;
            default:begin
                port_frame_rd1 = 1'b0;
                port_frame_rd2 = 1'b0;
                port_frame_rd3 = 1'b0;
                port_frame_rd4 = 1'b0;
            end
        endcase
    end
end

//写last
always @(*)begin                                                                             
    if (M_AXI_ARESETN == 0)                                                                                                                                 
        axi_wlast = 1'b0;                                                                                                                                  
    else if (((write_index == axi_awlen) && wnext))                                                                         
        axi_wlast = 1'b1;                                                                                                                                                                     
    else                                                                
        axi_wlast = 1'b0;                                                                                                                                                                             
end      

//准备接收resp
always @(posedge M_AXI_ACLK or negedge M_AXI_ARESETN)begin                                                                 
    if (M_AXI_ARESETN == 0)                                                                                                         
        axi_bready <= 1'b0;                                                                                                                                    
    else if (axi_wvalid)                                                                                            
        axi_bready <= 1'b1;                                                                                                                               
    else if (M_AXI_BVALID)                                                                                                
        axi_bready <= 1'b0;                                                                                                                                     
    else                                                                
        axi_bready <= axi_bready;                                         
end

//判断下发端口处有没有数据存储，写地址有无变化
always @(posedge M_AXI_ACLK or negedge M_AXI_ARESETN)begin                                                                
    if(!M_AXI_ARESETN)
        rd_port1_en <= 1'b0;
    else if(read_ddr_port1_flag && axi_awaddr1 != C_M_TARGET_SLAVE_BASE_ADDR1)
        rd_port1_en <= 1'b1;
    else if(axi_araddr1 == axi_awaddr1)
        rd_port1_en <= 1'b0;
    else
        rd_port1_en <= rd_port1_en;
end

always @(posedge M_AXI_ACLK or negedge M_AXI_ARESETN)begin                                                                
    if(!M_AXI_ARESETN)
        rd_port2_en <= 1'b0;
    else if(read_ddr_port2_flag && axi_awaddr2 != C_M_TARGET_SLAVE_BASE_ADDR2)
        rd_port2_en <= 1'b1;
    else if(axi_araddr2 == axi_awaddr2)
        rd_port2_en <= 1'b0;
    else
        rd_port2_en <= rd_port2_en;
end

always @(posedge M_AXI_ACLK or negedge M_AXI_ARESETN)begin                                                                
    if(!M_AXI_ARESETN)
        rd_port3_en <= 1'b0;
    else if(read_ddr_port3_flag && axi_awaddr3 != C_M_TARGET_SLAVE_BASE_ADDR3)
        rd_port3_en <= 1'b1;
    else if(axi_araddr3 == axi_awaddr3)
        rd_port3_en <= 1'b0;
    else
        rd_port3_en <= rd_port3_en;
end

always @(posedge M_AXI_ACLK or negedge M_AXI_ARESETN)begin                                                                
    if(!M_AXI_ARESETN)
        rd_port4_en <= 1'b0;
    else if(read_ddr_port4_flag && axi_awaddr4 != C_M_TARGET_SLAVE_BASE_ADDR4)
        rd_port4_en <= 1'b1;
    else if(axi_araddr4 == axi_awaddr4)
        rd_port4_en <= 1'b0;
    else
        rd_port4_en <= rd_port4_en;
end

always @(posedge M_AXI_ACLK or negedge M_AXI_ARESETN)begin   
    if(!M_AXI_ARESETN)
        axi_arvalid <= 1'b0;
    else if(axi_arvalid && M_AXI_ARREADY) 
        axi_arvalid <= 1'b0;
    else if(cstate == READ_ADDR)
        axi_arvalid <= 1'b1;
    else
        axi_arvalid <= axi_arvalid;  
end

  
//AXI读地址管理
always @(posedge M_AXI_ACLK or negedge M_AXI_ARESETN)begin                                                                
    if(!M_AXI_ARESETN)begin
        axi_araddr1 <= C_M_TARGET_SLAVE_BASE_ADDR1;//初始地址
        axi_araddr2 <= C_M_TARGET_SLAVE_BASE_ADDR2;
        axi_araddr3 <= C_M_TARGET_SLAVE_BASE_ADDR3;
        axi_araddr4 <= C_M_TARGET_SLAVE_BASE_ADDR4;
    end
    else if (cstate == FINISH_RADDR)begin
        case(upload_port)
            4'b0001:axi_araddr1 <= axi_araddr1 + (axi_arlen + 1'b1)*(C_M_AXI_DATA_WIDTH/8);
            4'b0010:axi_araddr2 <= axi_araddr2 + (axi_arlen + 1'b1)*(C_M_AXI_DATA_WIDTH/8);
            4'b0100:axi_araddr3 <= axi_araddr3 + (axi_arlen + 1'b1)*(C_M_AXI_DATA_WIDTH/8);
            4'b1000:axi_araddr4 <= axi_araddr4 + (axi_arlen + 1'b1)*(C_M_AXI_DATA_WIDTH/8);
            default:begin
                axi_araddr1 <= axi_araddr1;
                axi_araddr2 <= axi_araddr2;
                axi_araddr3 <= axi_araddr3;
                axi_araddr4 <= axi_araddr4;
            end
        endcase
    end
    else begin
        axi_araddr1 <= axi_araddr1;
        axi_araddr2 <= axi_araddr2;
        axi_araddr3 <= axi_araddr3;
        axi_araddr4 <= axi_araddr4;
    end
end 

always @(posedge M_AXI_ACLK or negedge M_AXI_ARESETN)begin                                                                
    if(!M_AXI_ARESETN)
        axi_araddr <= 31'b0;
    else if (M_AXI_ARREADY && axi_arvalid)
        axi_araddr <= 31'b0;
    else if(cstate == READ_ADDR)begin
        case(upload_port)
            4'b0001:axi_araddr <= axi_araddr1;
            4'b0010:axi_araddr <= axi_araddr2;
            4'b0100:axi_araddr <= axi_araddr3;
            4'b1000:axi_araddr <= axi_araddr4;
            default:axi_araddr <= 31'b0;
        endcase
    end
    else
        axi_araddr <= 31'b0;
end 

always @(posedge M_AXI_ACLK or negedge M_AXI_ARESETN)begin
    if(M_AXI_ARESETN == 1'b0)
        axi_rready <= 0 ;     
    else if(M_AXI_RLAST)
        axi_rready <= 0;
    else if(cstate == READ)
        axi_rready <= 1;
    else
        axi_rready <= axi_rready;
end


RR_aribter #(4) U_RR_aribter(
    .clk        (M_AXI_ACLK    ),
    .rst_n      (M_AXI_ARESETN ),
    .RR_en      (RR_en         ),
    .request    (request_i     ),
    .grant_o    (grant_o       ),
    .grant_valid(grant_valid   )
);




endmodule
