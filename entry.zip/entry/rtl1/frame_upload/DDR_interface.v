`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/10/11 17:27:54
// Design Name: 
// Module Name: DDR_interface
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module DDR_interface(
    input    sys_clk_p,
    input    sys_clk_n,
    input    sys_rst  ,
    output   ui_clk   ,
    
    //请求信号
    input    request1,
    input    request2,
    input    request3,
    input    request4,

    input   [63:0]     port_frame_data1,
    input   [63:0]     port_frame_data2,
    input   [63:0]     port_frame_data3,
    input   [63:0]     port_frame_data4,

    output             port_frame_rd1,
    output             port_frame_rd2, 
    output             port_frame_rd3, 
    output             port_frame_rd4,

    output             lock_port    ,

    //DDR3 interface
    output             init_calib_complete,
    // Inouts
    inout [63:0]       ddr3_dq,
    inout [7:0]        ddr3_dqs_n,
    inout [7:0]        ddr3_dqs_p,
   
    // Outputs
    output [14:0]      ddr3_addr,
    output [2:0]       ddr3_ba,
    output             ddr3_ras_n,
    output             ddr3_cas_n,
    output             ddr3_we_n,
    output             ddr3_reset_n,
    output [0:0]       ddr3_ck_p,
    output [0:0]       ddr3_ck_n,
    output [0:0]       ddr3_cke,
    output [0:0]       ddr3_cs_n,
    output [7:0]       ddr3_dm,
    output [0:0]       ddr3_odt,

    //axis interface
    output     [63:0]      s_axis_c2h_tdata_sys0 ,
    output                 s_axis_c2h_tlast_sys0 ,
    output                 s_axis_c2h_tvalid_sys0,
    input                  s_axis_c2h_tready_sys0,
    output     [7:0]       s_axis_c2h_tkeep_sys0 
);


parameter integer C_M_AXI_ID_WIDTH    = 3 ;
parameter integer C_M_AXI_ADDR_WIDTH  = 31;
parameter integer C_M_AXI_DATA_WIDTH  = 64;


wire  [C_M_AXI_ID_WIDTH-1 : 0]     M_AXI_AWID   ;      
wire  [C_M_AXI_ADDR_WIDTH-1 : 0]   M_AXI_AWADDR ;      
wire  [7 : 0]                      M_AXI_AWLEN  ;      
wire  [2 : 0]                      M_AXI_AWSIZE ;      
wire  [1 : 0]                      M_AXI_AWBURST;      
wire                               M_AXI_AWLOCK ;      
wire  [3 : 0]                      M_AXI_AWCACHE;      
wire  [2 : 0]                      M_AXI_AWPROT ;      
wire  [3 : 0]                      M_AXI_AWQOS  ;        
wire                               M_AXI_AWVALID;      
wire                               M_AXI_AWREADY;      
wire  [C_M_AXI_DATA_WIDTH-1 : 0]   M_AXI_WDATA  ;      
wire  [C_M_AXI_DATA_WIDTH/8-1 : 0] M_AXI_WSTRB  ;      
wire                               M_AXI_WLAST  ;        
wire                               M_AXI_WVALID ;      
wire                               M_AXI_WREADY ;      
wire  [C_M_AXI_ID_WIDTH-1 : 0]     M_AXI_BID    ;      
wire  [1 : 0]                      M_AXI_BRESP  ;        
wire                               M_AXI_BVALID ;      
wire                               M_AXI_BREADY ;      
wire  [C_M_AXI_ID_WIDTH-1 : 0]     M_AXI_ARID   ;      
wire  [C_M_AXI_ADDR_WIDTH-1 : 0]   M_AXI_ARADDR ;      
wire  [7 : 0]                      M_AXI_ARLEN  ;      
wire  [2 : 0]                      M_AXI_ARSIZE ;      
wire  [1 : 0]                      M_AXI_ARBURST;      
wire                               M_AXI_ARLOCK ;      
wire  [3 : 0]                      M_AXI_ARCACHE;      
wire  [2 : 0]                      M_AXI_ARPROT ;      
wire  [3 : 0]                      M_AXI_ARQOS  ;         
wire                               M_AXI_ARVALID;      
wire                               M_AXI_ARREADY;      
wire  [C_M_AXI_ID_WIDTH-1 : 0]     M_AXI_RID    ;      
wire  [C_M_AXI_DATA_WIDTH-1 : 0]   M_AXI_RDATA  ;      
wire  [1 : 0]                      M_AXI_RRESP  ;      
wire                               M_AXI_RLAST  ;      
wire                               M_AXI_RVALID ;      
wire                               M_AXI_RREADY ;   
wire                               axi_full2axis_ready;   

wire  read_ddr_port1;    
wire  read_ddr_port2;    
wire  read_ddr_port3;    
wire  read_ddr_port4;   
 
port_polling U_port_polling(
    .M_AXI_ARESETN          (~sys_rst              ),
    .M_AXI_ACLK             (ui_clk                ),
    .request1               (request1              ),
    .request2               (request2              ),
    .request3               (request3              ),
    .request4               (request4              ),
    .port_frame_data1       (port_frame_data1      ),
    .port_frame_data2       (port_frame_data2      ),
    .port_frame_data3       (port_frame_data3      ),
    .port_frame_data4       (port_frame_data4      ),
    .port_frame_rd1         (port_frame_rd1        ),
    .port_frame_rd2         (port_frame_rd2        ), 
    .port_frame_rd3         (port_frame_rd3        ), 
    .port_frame_rd4         (port_frame_rd4        ),
    .lock_port              (lock_port             ),
    .init_calib_complete    (init_calib_complete   ),

    .read_ddr_port1         (read_ddr_port1        ),
    .read_ddr_port2         (read_ddr_port2        ),
    .read_ddr_port3         (read_ddr_port3        ),
    .read_ddr_port4         (read_ddr_port4        ),
    .axi_full2axis_ready    (axi_full2axis_ready   ),
    
    .M_AXI_AWID             (M_AXI_AWID            ),
    .M_AXI_AWADDR           (M_AXI_AWADDR          ),
    .M_AXI_AWLEN            (M_AXI_AWLEN           ),
    .M_AXI_AWSIZE           (M_AXI_AWSIZE          ),
    .M_AXI_AWBURST          (M_AXI_AWBURST         ),
    .M_AXI_AWLOCK           (M_AXI_AWLOCK          ),
    .M_AXI_AWCACHE          (M_AXI_AWCACHE         ),
    .M_AXI_AWPROT           (M_AXI_AWPROT          ),
    .M_AXI_AWQOS            (M_AXI_AWQOS           ),
    .M_AXI_AWVALID          (M_AXI_AWVALID         ),
    .M_AXI_AWREADY          (M_AXI_AWREADY         ),
    .M_AXI_WDATA            (M_AXI_WDATA           ),
    .M_AXI_WSTRB            (M_AXI_WSTRB           ),
    .M_AXI_WLAST            (M_AXI_WLAST           ),
    .M_AXI_WVALID           (M_AXI_WVALID          ),
    .M_AXI_WREADY           (M_AXI_WREADY          ),
    .M_AXI_BID              (M_AXI_BID             ),
    .M_AXI_BRESP            (M_AXI_BRESP           ),
    .M_AXI_BVALID           (M_AXI_BVALID          ),
    .M_AXI_BREADY           (M_AXI_BREADY          ),
    .M_AXI_ARID             (M_AXI_ARID            ),
    .M_AXI_ARADDR           (M_AXI_ARADDR          ),
    .M_AXI_ARLEN            (M_AXI_ARLEN           ),
    .M_AXI_ARSIZE           (M_AXI_ARSIZE          ),
    .M_AXI_ARBURST          (M_AXI_ARBURST         ),
    .M_AXI_ARLOCK           (M_AXI_ARLOCK          ),
    .M_AXI_ARCACHE          (M_AXI_ARCACHE         ),
    .M_AXI_ARPROT           (M_AXI_ARPROT          ),
    .M_AXI_ARQOS            (M_AXI_ARQOS           ),
    .M_AXI_ARVALID          (M_AXI_ARVALID         ),
    .M_AXI_ARREADY          (M_AXI_ARREADY         ),
    .M_AXI_RID              (M_AXI_RID             ),
    .M_AXI_RDATA            (M_AXI_RDATA           ),
    .M_AXI_RRESP            (M_AXI_RRESP           ),
    .M_AXI_RLAST            (M_AXI_RLAST           ),
    .M_AXI_RVALID           (M_AXI_RVALID          ),
    .M_AXI_RREADY           (M_AXI_RREADY          )

);

vio_read_port U_vio_read_port (
    .clk(ui_clk),                // input wire clk
    .probe_out0(read_ddr_port1),  // output wire [0 : 0] probe_out0
    .probe_out1(read_ddr_port2),  // output wire [0 : 0] probe_out1
    .probe_out2(read_ddr_port3),  // output wire [0 : 0] probe_out2
    .probe_out3(read_ddr_port4)  // output wire [0 : 0] probe_out3
);


axi_full2axis U_axi_full2axis(
    .clk                   (ui_clk                ),
    .rst_n                 (~sys_rst              ),
    .frame_upload          (M_AXI_RDATA           ),
    .frame_upload_valid    (M_AXI_RVALID          ),

    .m_axis_up_load_data   (s_axis_c2h_tdata_sys0 ),
    .m_axis_up_load_keep   (s_axis_c2h_tkeep_sys0 ),
    .m_axis_up_load_valid  (s_axis_c2h_tvalid_sys0),
    .m_axis_up_load_last   (s_axis_c2h_tlast_sys0 ),
    .m_axis_up_load_ready  (s_axis_c2h_tready_sys0),
    .axi_full2axis_ready   (axi_full2axis_ready   ),
    .card_upload_ren_1     (1'b1)
);
       

mig_7series_0 u_mig_7series_0 (
    // Memory interface ports
    .ddr3_addr                      (ddr3_addr          ),  // output [14:0]	ddr3_addr
    .ddr3_ba                        (ddr3_ba            ),  // output [2:0]		ddr3_ba
    .ddr3_cas_n                     (ddr3_cas_n         ),  // output			ddr3_cas_n
    .ddr3_ck_n                      (ddr3_ck_n          ),  // output [0:0]		ddr3_ck_n
    .ddr3_ck_p                      (ddr3_ck_p          ),  // output [0:0]		ddr3_ck_p
    .ddr3_cke                       (ddr3_cke           ),  // output [0:0]		ddr3_cke
    .ddr3_ras_n                     (ddr3_ras_n         ),  // output			ddr3_ras_n
    .ddr3_reset_n                   (ddr3_reset_n       ),  // output			ddr3_reset_n
    .ddr3_we_n                      (ddr3_we_n          ),  // output			ddr3_we_n
    .ddr3_dq                        (ddr3_dq            ),  // inout [63:0]		ddr3_dq
    .ddr3_dqs_n                     (ddr3_dqs_n         ),  // inout [7:0]		ddr3_dqs_n          数据选取脉冲
    .ddr3_dqs_p                     (ddr3_dqs_p         ),  // inout [7:0]		ddr3_dqs_p          数据选取脉冲
    .init_calib_complete            (init_calib_complete),  // output			init_calib_complete 初始化完成
	.ddr3_cs_n                      (ddr3_cs_n          ),  // output [0:0]		ddr3_cs_n
    .ddr3_dm                        (ddr3_dm            ),  // output [7:0]		ddr3_dm
    .ddr3_odt                       (ddr3_odt           ),  // output [0:0]		ddr3_odt
    // Application interface ports
    .ui_clk                         (ui_clk             ),  // output			ui_clk           用户时钟接口
    .ui_clk_sync_rst                (ui_clk_sync_rst    ),  // output			ui_clk_sync_rst  初始化复位，init_calib_complete完成后自动拉低
    .mmcm_locked                    (mmcm_locked        ),  // output			mmcm_locked      表示DDR3时钟锁定
    .aresetn                        (~ui_clk_sync_rst   ),  // input			aresetn          用户给mig的复位信号
    .app_sr_req                     (1'b0               ),  // input			app_sr_req       请求进入自刷新模式（低功耗模式）。DDR 会关闭大部分电路，仅保留数据内容。
    .app_ref_req                    (1'b0               ),  // input			app_ref_req      请求执行一次手动刷新,一般由控制逻辑发起，正常模式下 MIG 会自动定期刷新。
    .app_zq_req                     (1'b0               ),  // input			app_zq_req       请求执行一次 ZQ 校准。ZQ 校准用于校正 DDR3 I/O 驱动强度和终端阻抗。
    .app_sr_active                  (app_sr_active      ),  // output			app_sr_active    表示 DDR 目前处于自刷新模式中。为 1 时，不能执行读写操作。
    .app_ref_ack                    (app_ref_ack        ),  // output			app_ref_ack      表示 MIG 已响应 app_ref_req 并执行刷新。
    .app_zq_ack                     (app_zq_ack         ),  // output			app_zq_ack       表示 MIG 已执行完一次 ZQ 校准。
    // Slave Interface Write Address Ports
    .s_axi_awid                     (M_AXI_AWID         ),  // input [2:0]		s_axi_awid
    .s_axi_awaddr                   (M_AXI_AWADDR       ),  // input [30:0]		s_axi_awaddr
    .s_axi_awlen                    (M_AXI_AWLEN        ),  // input [7:0]		s_axi_awlen
    .s_axi_awsize                   (M_AXI_AWSIZE       ),  // input [2:0]		s_axi_awsize
    .s_axi_awburst                  (M_AXI_AWBURST      ),  // input [1:0]		s_axi_awburst
    .s_axi_awlock                   (M_AXI_AWLOCK       ),  // input [0:0]		s_axi_awlock
    .s_axi_awcache                  (M_AXI_AWCACHE      ),  // input [3:0]		s_axi_awcache
    .s_axi_awprot                   (M_AXI_AWPROT       ),  // input [2:0]		s_axi_awprot
    .s_axi_awqos                    (M_AXI_AWQOS        ),  // input [3:0]		s_axi_awqos
    .s_axi_awvalid                  (M_AXI_AWVALID      ),  // input			s_axi_awvalid
    .s_axi_awready                  (M_AXI_AWREADY      ),  // output			s_axi_awready
    // Slave Interface Write Data Ports
    .s_axi_wdata                    (M_AXI_WDATA        ),  // input [31:0]		s_axi_wdata
    .s_axi_wstrb                    (M_AXI_WSTRB        ),  // input [3:0]		s_axi_wstrb
    .s_axi_wlast                    (M_AXI_WLAST        ),  // input			s_axi_wlast
    .s_axi_wvalid                   (M_AXI_WVALID       ),  // input			s_axi_wvalid
    .s_axi_wready                   (M_AXI_WREADY       ),  // output			s_axi_wready
    // Slave Interface Write Response Ports
    .s_axi_bid                      (M_AXI_BID          ),  // output [2:0]		s_axi_bid
    .s_axi_bresp                    (M_AXI_BRESP        ),  // output [1:0]		s_axi_bresp
    .s_axi_bvalid                   (M_AXI_BVALID       ),  // output			s_axi_bvalid
    .s_axi_bready                   (M_AXI_BREADY       ),  // input			s_axi_bready
    // Slave Interface Read Address Ports   
    .s_axi_arid                     (M_AXI_ARID         ),  // input [2:0]	    s_axi_arid
    .s_axi_araddr                   (M_AXI_ARADDR       ),  // input [30:0]	    s_axi_araddr
    .s_axi_arlen                    (M_AXI_ARLEN        ),  // input [7:0]	    s_axi_arlen
    .s_axi_arsize                   (M_AXI_ARSIZE       ),  // input [2:0]	    s_axi_arsize
    .s_axi_arburst                  (M_AXI_ARBURST      ),  // input [1:0]	    s_axi_arburst
    .s_axi_arlock                   (M_AXI_ARLOCK       ),  // input [0:0]	    s_axi_arlock
    .s_axi_arcache                  (M_AXI_ARCACHE      ),  // input [3:0]	    s_axi_arcache
    .s_axi_arprot                   (M_AXI_ARPROT       ),  // input [2:0]	    s_axi_arprot
    .s_axi_arqos                    (M_AXI_ARQOS        ),  // input [3:0]	    s_axi_arqos
    .s_axi_arvalid                  (M_AXI_ARVALID      ),  // input			s_axi_arvalid
    .s_axi_arready                  (M_AXI_ARREADY      ),  // output			s_axi_arready
    // Slave Interface Read Data Ports  
    .s_axi_rid                      (M_AXI_RID          ),  // output [2:0]		s_axi_rid
    .s_axi_rdata                    (M_AXI_RDATA        ),  // output [31:0]	s_axi_rdata
    .s_axi_rresp                    (M_AXI_RRESP        ),  // output [1:0]		s_axi_rresp
    .s_axi_rlast                    (M_AXI_RLAST        ),  // output			s_axi_rlast
    .s_axi_rvalid                   (M_AXI_RVALID       ),  // output			s_axi_rvalid
    .s_axi_rready                   (M_AXI_RREADY       ),  // input			s_axi_rready
    // System Clock Ports   
    .sys_clk_p                      (sys_clk_p          ),  // input			sys_clk_p
    .sys_clk_n                      (sys_clk_n          ),  // input			sys_clk_n
    .sys_rst                        (~sys_rst           )   // input            sys_rst
    );

endmodule
