// **************************************************************
// COPYRIGHT(c)2015, Xidian University
// All rights reserved.
//
// IP LIB INDEX :  
// IP Name      :      
// File name    : ccd.v
// Module name  : CCD
// Full name    :  
//
// Author       :  Chenhaoming 
// Email        : 
// Data         : 
// Version      : V 1.0 
// 
// Abstract     : 使用异步FIFO实现接收时钟域到系统内部时钟域之间的转换
// Called by    :  
// 
// Modification history
// -----------------------------------------------------------------
// 
// 
//
// *****************************************************************

// *******************
// TIMESCALE
// ******************* 
`timescale 1ns/1ps 

// *******************
// INFORMATION
// *******************


//*******************
//DEFINE(s)
//*******************
//`define UDLY 1    //Unit delay, for non-blocking assignments in sequential logic



//*******************
//DEFINE MODULE PORT
//*******************
module inport_ccd_1000M_tx_SFP ( 
                input             rx_clk   ,  //接收时钟                            
                input             clk      ,  //系统时钟                     
                input             rst      ,  //异步高复位                 
                
                //interface to inport
                input     [7:0]   rxd_i   ,  //数据             
                input             rx_dv_i ,  //数据有效                                                             
                input             rx_er_i ,  //数据出错  

                //时间戳
                input     [79:0]  sys_time     ,
                input     [79:0]  timer        , 
                input             two_step_flag,                                            
                
                //interface to identify_and_dispatch
                output    [7:0]   data_out      ,  //数据                      
                output            data_out_valid,  //数据有效                      
                output            data_out_err  ,   //数据出错

                input             onestep_rx_pdelay_valid,
                output            timestamp_tx_Pdelay_valid_cdc,
                output            timestamp_tx_Sync_valid_cdc,
                output            timestamp_tx_Presp_valid_cdc                      

         ) ;


//for debug 
reg rx_dv_o_ff;

reg [31:0] rxd_cnt;
reg [31:0] rxd_bits_cnt;

reg [7:0] data_o_reg_ff;
reg [7:0] timestamp_cnt;
reg timestamp_tx_Pdelay_valid;
reg timestamp_tx_Sync_valid  ;
reg timestamp_tx_Presp_valid ;

reg [7:0]  rxd_o   ;
reg        rx_dv_o ;
reg        rx_er_o ;

reg [7:0] dout      ;
reg       dout_valid;
reg       dout_err  ;

reg CRC_en;
reg [7:0] dout_ff;      
reg dout_valid_ff;
wire [7:0] CRC_out;
reg CRC_rd;


assign data_out       = CRC_rd ? CRC_out :dout;
assign data_out_valid = dout_valid;
assign data_out_err   = dout_err  ;

always @( posedge clk or posedge rst )
begin
  if(rst == 1'b1)
  begin
    rx_dv_o_ff <= 1'b0;
  end
  else
  begin
    rx_dv_o_ff <= rx_dv_o;
  end
end
 
always @( posedge clk or posedge rst )
begin
  if(rst == 1'b1)
  begin
    rxd_cnt <= 32'd0;
  end
  else if(rxd_cnt == 32'b1111_1111_1111_1111_1111_1111_1111_1111)
  begin
    rxd_cnt <= 32'd0;
  end
  else if(rx_dv_o_ff == 1'b1 && rx_dv_o == 1'b0)
  begin
    rxd_cnt <= rxd_cnt + 32'b1;
  end
  else
  begin
    rxd_cnt <= rxd_cnt;
  end
end



always @( posedge clk or posedge rst )
begin
  if(rst == 1'b1)
  begin
    rxd_bits_cnt <= 32'd0;
  end
  else if(rxd_bits_cnt == 32'b1111_1111_1111_1111_1111_1111_1111_1111)
  begin
    rxd_bits_cnt <= 32'd0;
  end
  else if(rx_dv_o == 1'b1)
  begin
    rxd_bits_cnt <= rxd_bits_cnt + 32'b1;
  end
  else
  begin
    rxd_bits_cnt <= rxd_bits_cnt;
  end
end


//*******************
//DEFINE LOCAL PARAMETER
//*******************
//parameter(s)
parameter   IDLE    = 10'b00_0000_0001 ;                                    
parameter   WAIT_1  = 10'b00_0000_0010 ;                                
parameter   WAIT_2  = 10'b00_0000_0100 ;                                
parameter   WAIT_3  = 10'b00_0000_1000 ;                                
parameter   WAIT_4  = 10'b00_0001_0000 ;                                
parameter   WAIT_5  = 10'b00_0010_0000 ;  
parameter   WAIT_6  = 10'b00_0100_0000 ;                                                               
parameter   READ    = 10'b10_0000_0000 ;                                  
 

//*********************
//INNER SIGNAL DECLARATION
//*********************
//REGS   
// 跨时钟域转换相关
reg [9:0]  wr_data ; // fifo写数据
reg        wr_en ;  // fifo写使能，对rx_dv打拍得来，时钟域 rx_clk

reg     rx_dv_ff1 ; // 打拍，时钟域 clk 
reg     rx_dv_ff2 ;
reg     rx_dv_ff3 ;
wire    rx_dv_pos ;       // 帧起始
wire    rx_dv_neg ;       // 帧结束


reg rd_en_reg ; // rd_en打拍，当读完数据后，截取有效数据，时钟域Clk_125M

(*mark_debug = "TRUE"*)reg [9:0] c_s ; // 读使能产生状态机
reg [9:0] n_s ;

//WIRES
wire  [9:0] rd_data ; // fifo读数据
(*mark_debug = "TRUE"*)wire empty;  // fifo空标志
(*mark_debug = "TRUE"*)wire full;
wire      rd_en ;  // fifo读使能
wire  [11:0] rd_data_count ;//FIFO占用空间计数（读时钟域）

//debug
reg rx_dv_i_ff1 ;
reg rx_dv_i_ff2 ;

reg[31:0] gPTP_cnt;
reg rx_dv_o_ff1;
reg gPTP_flag;

always @ (posedge clk or posedge rst)
begin
    if (rst)
    begin
        rx_dv_o_ff1 <= 1'b0;
    end 
    else
    begin
        rx_dv_o_ff1 <= rx_dv_o;
    end
end
always @ (posedge clk or posedge rst)
 begin
     if (rst)
     begin
         gPTP_cnt <= 32'b0;
     end
     else if(rx_dv_o && ~rx_dv_o_ff1)
     begin
         gPTP_cnt <= gPTP_cnt + 32'b1;
     end
     else
     begin
         gPTP_cnt <= gPTP_cnt;
     end
 end  
//*********************
//INSTANTCE MODULE
//*********************

// 异步fifo实现跨时钟域
ccd_fifo_10_128 U_ccd_fifo (
  .rst(rst),   
  .wr_clk(rx_clk), // input wr_clk
  .rd_clk(clk), // input rd_clk
  .din(wr_data), // input [9 : 0] din
  .wr_en(wr_en), // input wr_en
  .rd_en(rd_en), // input rd_en
  .dout(rd_data), // output [9 : 0] dout
  .full(full), // output full
  .empty(empty), // output empty
  .rd_data_count(rd_data_count)  // output wire [4 : 0] rd_data_count
);

//*********************
//MAIN CORE
//********************* 

always@(posedge rx_clk or posedge rst)
begin
    if (rst)
    begin
        rx_dv_i_ff1 <= 1'b0 ;
        rx_dv_i_ff2 <= 1'b0 ;
    end

    else
    begin
        rx_dv_i_ff1 <= rx_dv_i ;
        rx_dv_i_ff2 <= rx_dv_i_ff1 ;        
    end
end 

always@(posedge rx_clk or posedge rst) // 产生写使能
begin
    if(rst == 1'b1)
        wr_en <= 1'b0 ;
    else 
        wr_en <= rx_dv_i/*|rx_dv_i_ff1|rx_dv_i_ff2*/ ;
end

always@(posedge rx_clk or posedge rst)  // 写数据
begin
    if(rst == 1'b1)
        wr_data <=  'b0                 ;  
    else
        wr_data <=  {rx_dv_i, rx_er_i, rxd_i} ;
end



always @ (posedge clk or posedge rst)
begin
    if(rst == 1'b1) begin
        rx_dv_ff1 <= 1'b0 ;
        rx_dv_ff2 <= 1'b0 ;
        rx_dv_ff3 <= 1'b0 ;
    end
    else begin
        rx_dv_ff1 <= rx_dv_i ;
        rx_dv_ff2 <= rx_dv_ff1 ; 
        rx_dv_ff3 <= rx_dv_ff2 ;                
    end       
end

assign rx_dv_pos = rx_dv_ff2 & (~rx_dv_ff3);
assign rx_dv_neg = rx_dv_ff3 & (~rx_dv_ff2);



// 状态机实现fifo读
always @ (posedge clk or posedge rst)
begin
    if(rst == 1'b1)
        c_s <= IDLE ;
    else 
        c_s <= n_s ;    
end

always @ (*) begin
    case(c_s)
        IDLE   : begin
            if ( rx_dv_pos == 1'b1 )
                n_s = WAIT_1 ;
            else 
                n_s = IDLE   ;    
        end
        WAIT_1 : n_s = WAIT_2 ;
        WAIT_2 : n_s = WAIT_3 ;
        WAIT_3 : n_s = WAIT_4 ;
        WAIT_4 : n_s = WAIT_5 ;
        WAIT_5 : n_s = WAIT_6 ;
        WAIT_6 : n_s = READ ;
        READ   : begin
            if ( empty == 1'b1 )
                n_s = IDLE ;
            else 
                n_s = READ ;    
        end
        default: n_s = IDLE ;
    endcase
end

assign rd_en = ( c_s == READ ) ?(!empty): 1'b0   ; // 读使能产生


always @ (posedge clk or posedge rst)
begin
    if(rst == 1'b1)
        rd_en_reg <= 1'b0 ;
    else 
        rd_en_reg <= rd_en ;    
end


// 截取有效数据
always @ (posedge clk or posedge rst)
begin
    if(rst == 1'b1) begin
        rxd_o   <= 'b0 ;
        rx_er_o <= 'b0 ;
        rx_dv_o <= 'b0 ;
    end
    else if ( rd_en_reg == 1'b1 ) begin
        rxd_o   <= rd_data[7:0] ;
        rx_er_o <= rd_data[8] ;
        rx_dv_o <= rd_data[9] ;
    end    
    else begin
        rxd_o   <=  'b0 ;
        rx_er_o <=  'b0 ;
        rx_dv_o <=  'b0 ;
    end
end


//发送时间戳标记
always@(posedge clk or posedge rst)
begin 
  if(rst)
      data_o_reg_ff <= 8'b0;
  else 
      data_o_reg_ff <= rxd_o;
end 

always@(posedge clk or posedge rst)
begin
    if (rst)
        timestamp_cnt <= 8'b0;
    else if(rxd_o==8'hd5 && data_o_reg_ff==8'h55)
        timestamp_cnt <= 8'b0;
    else if(rx_dv_o)
        timestamp_cnt <= timestamp_cnt + 1;
    else
        timestamp_cnt <= 8'b0;
end 

always@(posedge rx_clk or posedge rst)
begin
    if (rst)
        gPTP_flag <= 1'b0;
    else if(rx_dv_o && timestamp_cnt == 8'd13 && rxd_o==8'hf7 && data_o_reg_ff==8'h88)
        gPTP_flag <= 1'b1;
    else if(rx_dv_o)
        gPTP_flag <= 1'b1;
    else
        gPTP_flag <= 1'b0;
end 


always@(posedge clk or posedge rst)
begin
    if (rst)begin
        timestamp_tx_Pdelay_valid   <= 1'b0;
        timestamp_tx_Sync_valid     <= 1'b0;
        timestamp_tx_Presp_valid    <= 1'b0;
    end
    else if(gPTP_flag && timestamp_cnt==8'd15)begin  //两步法才会拉高时戳valid
        if(data_o_reg_ff[3:0]==4'h0)begin
            timestamp_tx_Sync_valid<=1'b1;
        end
        else if(data_o_reg_ff[3:0]==4'h2)begin
            timestamp_tx_Pdelay_valid<=1'b1;
        end
        else if(data_o_reg_ff[3:0]==4'h3)begin
            timestamp_tx_Presp_valid<=1'b1;
        end
        else begin
            timestamp_tx_Pdelay_valid   <= 1'b0;
            timestamp_tx_Sync_valid     <= 1'b0;
            timestamp_tx_Presp_valid    <= 1'b0;
        end
    end
    else begin
            timestamp_tx_Pdelay_valid   <= 1'b0;
            timestamp_tx_Sync_valid     <= 1'b0;
            timestamp_tx_Presp_valid    <= 1'b0;
    end
end 

//一步法时戳设计
reg sync_frame;
reg presp_frame;
reg [79:0] sync_timestamp;
reg [79:0] presp_timestamp;
reg [79:0] pdelay_timestamp;
reg [63:0] presp_correction;
reg presp_correction_flag;

always@(posedge clk or posedge rst)begin
    if(rst)begin
        sync_timestamp  <= 80'b0;
        presp_timestamp <= 80'b0;
        presp_correction_flag <= 1'b0;
    end
    else begin
        presp_correction_flag <= 1'b0;
        if(gPTP_flag && timestamp_cnt == 8'd15 && !two_step_flag)begin
            if(data_o_reg_ff[3:0]==4'h0)begin
                sync_timestamp <= sys_time;
            end
            else if(data_o_reg_ff[3:0]==4'h3)begin
                presp_timestamp <= timer;
                presp_correction_flag <= 1'b1;
            end
        end
    end
end

always@(posedge clk or posedge rst)begin
    if(rst)begin
        pdelay_timestamp  <= 80'b0;
    end
    else if(onestep_rx_pdelay_valid && !two_step_flag)begin
        pdelay_timestamp  <= timer;
    end
end

always @(posedge clk or posedge rst) begin
    if (rst) begin
        presp_correction <= 64'b0 ;
    end
    else if (presp_correction_flag) begin
        if (presp_timestamp[31:0] < pdelay_timestamp[31:0]) begin
            presp_correction[31:0]  <= presp_timestamp[31:0] + 32'd1000000000 - pdelay_timestamp[31:0] ;
            presp_correction[63:32] <= presp_timestamp[63:32] - 48'd1 - pdelay_timestamp[63:32] ;
        end
        else begin
            presp_correction[31:0] <= presp_timestamp[31:0] - pdelay_timestamp[31:0] ;
            presp_correction[63:32] <= presp_timestamp[63:32] - pdelay_timestamp[63:32] ;            
        end
    end
    else begin
        presp_correction <= presp_correction ;
    end
end

always@(posedge clk or posedge rst)begin
    if(rst)begin
        sync_frame  <= 1'b0;
    end
    else if(gPTP_flag && timestamp_cnt == 8'd15 && !two_step_flag)begin
        if(data_o_reg_ff[3:0]==4'h0)begin
            sync_frame <=1'b1;
        end
    end
    else if(!rx_dv_o)
        sync_frame  <= 1'b0;
end

always@(posedge clk or posedge rst)begin
    if(rst)begin
        presp_frame  <= 1'b0;
    end
    else if(gPTP_flag && timestamp_cnt == 8'd15 && !two_step_flag)begin
        if(data_o_reg_ff[3:0]==4'h3)begin
            presp_frame <=1'b1;
        end
    end
    else if(!rx_dv_o)
        presp_frame  <= 1'b0;
end

always@(posedge clk or posedge rst)begin
    if(rst)begin
        dout       <= 8'b0;
        dout_valid <= 1'b0;
        dout_err   <= 1'b0; 
    end
    else begin
        dout_valid <= rx_dv_o;
        dout_err   <= rx_er_o;
        dout       <= rxd_o  ;
        if(sync_frame)begin
            case(timestamp_cnt)
                8'd48: dout <= sync_timestamp[79:72];
                8'd49: dout <= sync_timestamp[71:64];
                8'd50: dout <= sync_timestamp[63:56];
                8'd51: dout <= sync_timestamp[55:48];
                8'd52: dout <= sync_timestamp[47:40];
                8'd53: dout <= sync_timestamp[39:32];
                8'd54: dout <= sync_timestamp[31:24];
                8'd55: dout <= sync_timestamp[23:16];
                8'd56: dout <= sync_timestamp[15:8 ];
                8'd57: dout <= sync_timestamp[7:0  ];
                default: dout <= rxd_o;
            endcase
        end
        else if(presp_frame)begin
            case(timestamp_cnt)
                8'd22: dout <= presp_correction[63:56];
                8'd23: dout <= presp_correction[55:48];
                8'd24: dout <= presp_correction[47:40];
                8'd25: dout <= presp_correction[39:32];
                8'd26: dout <= presp_correction[31:24];
                8'd27: dout <= presp_correction[23:16];
                8'd28: dout <= presp_correction[15:8 ];
                8'd29: dout <= presp_correction[7:0  ];
                default: dout <= rxd_o;
            endcase
        end
    end
end

//*****************************************************
//             CRC Re-generation Logic
//*****************************************************


always@(posedge clk or posedge rst)begin
    if(rst)begin
        dout_ff <= 8'b0;
        dout_valid_ff <= 1'b0;
    end
    else begin  
        dout_ff <= dout;
        dout_valid_ff <= dout_valid;
    end
end


always@(posedge clk or posedge rst)begin
    if(rst)
        CRC_en <= 1'b0;
    else if(dout_ff == 8'h55 && dout == 8'hd5 && dout_valid)
        CRC_en <= 1'b1;
    else if(sync_frame && timestamp_cnt == 8'd58)
        CRC_en <= 1'b0;
    else if(presp_frame && timestamp_cnt == 8'd68)
        CRC_en <= 1'b0;
    else if(!dout_valid)
        CRC_en <= 1'b0;
end

always@(posedge clk or posedge rst)begin
    if(rst)
        CRC_rd <= 1'b0;
    else if(sync_frame && timestamp_cnt == 8'd58)
        CRC_rd <= 1'b1;
    else if(sync_frame && timestamp_cnt == 8'd62)
        CRC_rd <= 1'b0;
    else if(presp_frame && timestamp_cnt == 8'd68)
        CRC_rd <= 1'b1;
    else if(presp_frame && timestamp_cnt == 8'd72)
        CRC_rd <= 1'b0;
end


CRC_gen U_CRC_gen(
        .Reset      (rst           ),
        .Clk        (clk           ),
        .Init       (1'b0          ),
        .Frame_data (dout          ),
        .Data_en    (CRC_en        ),
        .CRC_rd     (CRC_rd        ),
        .CRC_end    (CRC_end       ),
        .CRC_out    (CRC_out       )
);



//时间戳跨时钟域
xpm_cdc_pulse #(
   .DEST_SYNC_FF(2),   // DECIMAL; range: 2-10
   .INIT_SYNC_FF(1),   // DECIMAL; 0=disable simulation init values, 1=enable simulation init values
   .REG_OUTPUT(0),     // DECIMAL; 0=disable registered output, 1=enable registered output
   .RST_USED(1),       // DECIMAL; 0=no reset, 1=implement reset
   .SIM_ASSERT_CHK(0)  // DECIMAL; 0=disable simulation messages, 1=enable simulation messages
)
xpm_cdc_pulse_inst0 (
   .dest_pulse(timestamp_tx_Pdelay_valid_cdc), // 1-bit output: Outputs a pulse the size of one dest_clk period when a pulse
                            // transfer is correctly initiated on src_pulse input. This output is
                            // combinatorial unless REG_OUTPUT is set to 1.
   .dest_clk(rx_clk),     // 1-bit input: Destination clock.
   .dest_rst(1'b0),     // 1-bit input: optional; required when RST_USED = 1
   .src_clk(clk),       // 1-bit input: Source clock.
   .src_pulse(timestamp_tx_Pdelay_valid),   // 1-bit input: Rising edge of this signal initiates a pulse transfer to the
                            // destination clock domain. The minimum gap between each pulse transfer must be
                            // at the minimum 2*(larger(src_clk period, dest_clk period)). This is measured
                            // between the falling edge of a src_pulse to the rising edge of the next
                            // src_pulse. This minimum gap will guarantee that each rising edge of src_pulse
                            // will generate a pulse the size of one dest_clk period in the destination
                            // clock domain. When RST_USED = 1, pulse transfers will not be guaranteed while
                            // src_rst and/or dest_rst are asserted.
   .src_rst(1'b0)        // 1-bit input: optional; required when RST_USED = 1
);


xpm_cdc_pulse #(
   .DEST_SYNC_FF(2),   // DECIMAL; range: 2-10
   .INIT_SYNC_FF(1),   // DECIMAL; 0=disable simulation init values, 1=enable simulation init values
   .REG_OUTPUT(0),     // DECIMAL; 0=disable registered output, 1=enable registered output
   .RST_USED(1),       // DECIMAL; 0=no reset, 1=implement reset
   .SIM_ASSERT_CHK(0)  // DECIMAL; 0=disable simulation messages, 1=enable simulation messages
)
xpm_cdc_pulse_inst (
   .dest_pulse(timestamp_tx_Sync_valid_cdc), // 1-bit output: Outputs a pulse the size of one dest_clk period when a pulse
                            // transfer is correctly initiated on src_pulse input. This output is
                            // combinatorial unless REG_OUTPUT is set to 1.
   .dest_clk(rx_clk),     // 1-bit input: Destination clock.
   .dest_rst(1'b0),     // 1-bit input: optional; required when RST_USED = 1
   .src_clk(clk),       // 1-bit input: Source clock.
   .src_pulse(timestamp_tx_Sync_valid),   // 1-bit input: Rising edge of this signal initiates a pulse transfer to the
                            // destination clock domain. The minimum gap between each pulse transfer must be
                            // at the minimum 2*(larger(src_clk period, dest_clk period)). This is measured
                            // between the falling edge of a src_pulse to the rising edge of the next
                            // src_pulse. This minimum gap will guarantee that each rising edge of src_pulse
                            // will generate a pulse the size of one dest_clk period in the destination
                            // clock domain. When RST_USED = 1, pulse transfers will not be guaranteed while
                            // src_rst and/or dest_rst are asserted.
   .src_rst(1'b0)        // 1-bit input: optional; required when RST_USED = 1
);

xpm_cdc_pulse #(
   .DEST_SYNC_FF(2),   // DECIMAL; range: 2-10
   .INIT_SYNC_FF(1),   // DECIMAL; 0=disable simulation init values, 1=enable simulation init values
   .REG_OUTPUT(0),     // DECIMAL; 0=disable registered output, 1=enable registered output
   .RST_USED(1),       // DECIMAL; 0=no reset, 1=implement reset
   .SIM_ASSERT_CHK(0)  // DECIMAL; 0=disable simulation messages, 1=enable simulation messages
)
xpm_cdc_pulse_inst2 (
   .dest_pulse(timestamp_tx_Presp_valid_cdc), // 1-bit output: Outputs a pulse the size of one dest_clk period when a pulse
                            // transfer is correctly initiated on src_pulse input. This output is
                            // combinatorial unless REG_OUTPUT is set to 1.
   .dest_clk(rx_clk),     // 1-bit input: Destination clock.
   .dest_rst(1'b0),     // 1-bit input: optional; required when RST_USED = 1
   .src_clk(clk),       // 1-bit input: Source clock.
   .src_pulse(timestamp_tx_Presp_valid),   // 1-bit input: Rising edge of this signal initiates a pulse transfer to the
                            // destination clock domain. The minimum gap between each pulse transfer must be
                            // at the minimum 2*(larger(src_clk period, dest_clk period)). This is measured
                            // between the falling edge of a src_pulse to the rising edge of the next
                            // src_pulse. This minimum gap will guarantee that each rising edge of src_pulse
                            // will generate a pulse the size of one dest_clk period in the destination
                            // clock domain. When RST_USED = 1, pulse transfers will not be guaranteed while
                            // src_rst and/or dest_rst are asserted.
   .src_rst(1'b0)        // 1-bit input: optional; required when RST_USED = 1
);

//*********************
endmodule   