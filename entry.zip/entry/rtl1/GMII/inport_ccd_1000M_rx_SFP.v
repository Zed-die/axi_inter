// **************************************************************
// COPYRIGHT(c)2015, Xidian University
// All rights reserved.
//
// IP LIB INDEX :  
// IP Name      :      
// File name    : ccd.v
// Module name  : CCD
// Full name    :  
//
// Author       :  Chenhaoming 
// Email        : 
// Data         : 
// Version      : V 1.0 
// 
// Abstract     : 使用异步FIFO实现接收时钟域到系统内部时钟域之间的转换
// Called by    :  
// 
// Modification history
// -----------------------------------------------------------------
// 
// 
//
// *****************************************************************

// *******************
// TIMESCALE
// ******************* 
`timescale 1ns/1ps 

// *******************
// INFORMATION
// *******************


//*******************
//DEFINE(s)
//*******************
//`define UDLY 1    //Unit delay, for non-blocking assignments in sequential logic



//*******************
//DEFINE MODULE PORT
//*******************
module inport_ccd_1000M_rx_SFP ( 
                input            rx_clk   ,  //接收时钟                            
                input            clk      ,  //系统时钟                     
(*mark_debug = "true"*)input            rst      ,  //异步高复位                 
                
                //interface to inport
(*mark_debug = "true"*)input      [7:0]  rxd_i   ,  //数据             
(*mark_debug = "true"*)input             rx_dv_i ,  //数据有效                                                             
(*mark_debug = "true"*)input             rx_er_i ,  //数据出错                                            
                
                //interface to identify_and_dispatch
(*mark_debug = "true"*)output reg [7:0]  rxd_o   ,  //数据                      
(*mark_debug = "true"*)output reg        rx_dv_o ,  //数据有效                      
(*mark_debug = "true"*)output reg        rx_er_o ,   //数据出错 
                output          onestep_rx_pdelay_valid,
                output          timestamp_rx_Pdelay_valid_cdc,
                output          timestamp_rx_Sync_valid_cdc,
                output          timestamp_rx_Presp_valid_cdc                        

         ) ;


//for debug 
reg rx_dv_o_ff;

reg [31:0] rxd_cnt;
reg [31:0] rxd_bits_cnt;
reg [7:0] data_i_reg_ff;
reg [7:0] timesamp_cnt;


reg timestamp_rx_Pdelay_valid;  
reg timestamp_rx_Sync_valid  ;  
reg timestamp_rx_Presp_valid ;

assign onestep_rx_pdelay_valid = timestamp_rx_Pdelay_valid;

always @(posedge clk or posedge rst )
begin
  if(rst == 1'b1)
  begin
    rx_dv_o_ff <= 1'b0;
  end
  else
  begin
    rx_dv_o_ff <= rx_dv_o;
  end
end
 
always @( posedge clk or posedge rst )
begin
  if(rst == 1'b1)
  begin
    rxd_cnt <= 32'd0;
  end
  else if(rxd_cnt == 32'b1111_1111_1111_1111_1111_1111_1111_1111)
  begin
    rxd_cnt <= 32'd0;
  end
  else if(rx_dv_o_ff == 1'b1 && rx_dv_o == 1'b0)
  begin
    rxd_cnt <= rxd_cnt + 32'b1;
  end
  else
  begin
    rxd_cnt <= rxd_cnt;
  end
end



always @( posedge clk or posedge rst )
begin
  if(rst == 1'b1)
  begin
    rxd_bits_cnt <= 32'd0;
  end
  else if(rxd_bits_cnt == 32'b1111_1111_1111_1111_1111_1111_1111_1111)
  begin
    rxd_bits_cnt <= 32'd0;
  end
  else if(rx_dv_o == 1'b1)
  begin
    rxd_bits_cnt <= rxd_bits_cnt + 32'b1;
  end
  else
  begin
    rxd_bits_cnt <= rxd_bits_cnt;
  end
end


//*******************
//DEFINE LOCAL PARAMETER
//*******************
//parameter(s)
parameter   IDLE    = 10'b00_0000_0001 ;                                    
parameter   WAIT_1  = 10'b00_0000_0010 ;                                
parameter   WAIT_2  = 10'b00_0000_0100 ;                                
parameter   WAIT_3  = 10'b00_0000_1000 ;                                
parameter   WAIT_4  = 10'b00_0001_0000 ;                                
parameter   WAIT_5  = 10'b00_0010_0000 ;  
parameter   WAIT_6  = 10'b00_0100_0000 ;                                                               
parameter   READ    = 10'b10_0000_0000 ;                                  
 

//*********************
//INNER SIGNAL DECLARATION
//*********************
//REGS   
// 跨时钟域转换相关
reg [9:0]  wr_data ; // fifo写数据
reg        wr_en ;  // fifo写使能，对rx_dv打拍得来，时钟域 rx_clk

reg rx_dv_ff1 ; // 打拍，时钟域 clk 
reg rx_dv_ff2 ;
reg rx_dv_ff3 ;
wire rx_dv_pos ;       // 帧起始
wire rx_dv_neg ;       // 帧结束


reg rd_en_reg ; // rd_en打拍，当读完数据后，截取有效数据，时钟域Clk_125M

(*mark_debug = "TRUE"*)reg [9:0] c_s ; // 读使能产生状态机
reg [9:0] n_s ;

//WIRES
wire  [9:0] rd_data ; // fifo读数据
(*mark_debug = "TRUE"*)wire        empty ;  // fifo空标志
(*mark_debug = "TRUE"*)wire full;
wire      rd_en ;  // fifo读使能
wire  [11:0] rd_data_count ;//FIFO占用空间计数（读时钟域）

//debug
reg rx_dv_i_ff1 ;
reg rx_dv_i_ff2 ;

reg[31:0] gPTP_cnt;
reg rx_dv_o_ff1;
reg gPTP_flag;

always @ (posedge clk or posedge rst)
begin
    if (rst)
    begin
        rx_dv_o_ff1 <= 1'b0;
    end 
    else
    begin
        rx_dv_o_ff1 <= rx_dv_o;
    end
end
always @ (posedge clk or posedge rst)
 begin
     if (rst)
     begin
         gPTP_cnt <= 32'b0;
     end
     else if(rx_dv_o && ~rx_dv_o_ff1)
     begin
         gPTP_cnt <= gPTP_cnt + 32'b1;
     end
     else
     begin
         gPTP_cnt <= gPTP_cnt;
     end
 end  
//*********************
//INSTANTCE MODULE
//*********************

// 异步fifo实现跨时钟域
ccd_fifo_10_128 U_ccd_fifo (
  .rst(rst),
  .wr_clk(rx_clk), // input wr_clk
  .rd_clk(clk), // input rd_clk
  .din(wr_data), // input [9 : 0] din
  .wr_en(wr_en), // input wr_en
  .rd_en(rd_en), // input rd_en
  .dout(rd_data), // output [9 : 0] dout
  .full(full), // output full
  .empty(empty), // output empty
  .rd_data_count(rd_data_count)  // output wire [4 : 0] rd_data_count
);


//*********************
//MAIN CORE
//********************* 

always @ (posedge rx_clk or posedge rst)
begin
    if (rst)
    begin
        rx_dv_i_ff1 <= 1'b0 ;
        rx_dv_i_ff2 <= 1'b0 ;
    end

    else
    begin
        rx_dv_i_ff1 <= rx_dv_i ;
        rx_dv_i_ff2 <= rx_dv_i_ff1 ;        
    end
end 

always @ (posedge rx_clk or posedge rst) // 产生写使能
begin
    if(rst == 1'b1)
        wr_en <= 1'b0 ;
    else 
        wr_en <= rx_dv_i/*|rx_dv_i_ff1|rx_dv_i_ff2*/ ;
end

always @ (posedge rx_clk or posedge rst)  // 写数据
begin
    if(rst == 1'b1)
        wr_data <=  'b0                 ;  
    else
        wr_data <=  {rx_dv_i, rx_er_i, rxd_i} ;
end



always @ (posedge clk or posedge rst)
begin
    if(rst == 1'b1) begin
        rx_dv_ff1 <= 1'b0 ;
        rx_dv_ff2 <= 1'b0 ;
        rx_dv_ff3 <= 1'b0 ;
    end
    else begin
        rx_dv_ff1 <= rx_dv_i ;
        rx_dv_ff2 <= rx_dv_ff1 ; 
        rx_dv_ff3 <= rx_dv_ff2 ;                
    end       
end

assign rx_dv_pos = rx_dv_ff2 & (~rx_dv_ff3);
assign rx_dv_neg = rx_dv_ff3 & (~rx_dv_ff2);



// 状态机实现fifo读
always @ (posedge clk or posedge rst)
begin
    if(rst == 1'b1)
        c_s <= IDLE ;
    else 
        c_s <= n_s ;    
end

always @ (*) begin
    case(c_s)
        IDLE   : begin
            if ( rx_dv_pos == 1'b1 )
                n_s = WAIT_1 ;
            else 
                n_s = IDLE   ;    
        end
        WAIT_1 : n_s = WAIT_2 ;
        WAIT_2 : n_s = WAIT_3 ;
        WAIT_3 : n_s = WAIT_4 ;
        WAIT_4 : n_s = WAIT_5 ;
        WAIT_5 : n_s = WAIT_6 ;
        WAIT_6 : n_s = READ ;
        READ   : begin
            if ( empty == 1'b1 )
                n_s = IDLE ;
            else 
                n_s = READ ;    
        end
        default: n_s = IDLE ;
    endcase
end

assign rd_en = ( c_s == READ ) ?(!empty): 1'b0   ; // 读使能产生





always @ (posedge clk or posedge rst)
begin
    if(rst == 1'b1)
        rd_en_reg <= 1'b0 ;
    else 
        rd_en_reg <= rd_en ;    
end


// 截取有效数据
always @ (posedge clk or posedge rst)
begin
    if(rst == 1'b1) begin
        rxd_o   <= 'b0 ;
        rx_er_o <= 'b0 ;
        rx_dv_o <= 'b0 ;
    end
    else if ( rd_en_reg == 1'b1 ) begin
        rxd_o   <= rd_data[7:0] ;
        rx_er_o <= rd_data[8] ;
        rx_dv_o <= rd_data[9] ;
    end    
    else begin
        rxd_o   <=  'b0 ;
        rx_er_o <=  'b0 ;
        rx_dv_o <=  'b0 ;
    end
end

//接收时间戳标记
always@(posedge rx_clk or posedge rst)
begin 
  if(rst)
      data_i_reg_ff <= 8'b0;
  else 
      data_i_reg_ff <= rxd_i;
end 

always@(posedge rx_clk or posedge rst)
begin
    if (rst)
        timesamp_cnt <= 8'b0;
    else if(rxd_i==8'hd5 && data_i_reg_ff==8'h55)
        timesamp_cnt <= 8'b0;
    else if(rx_dv_i)
        timesamp_cnt <= timesamp_cnt+1;
    else
        timesamp_cnt <= 8'b0;
end 

always@(posedge rx_clk or posedge rst)
begin
    if (rst)
        gPTP_flag <= 1'b0;
    else if(rx_dv_i && timesamp_cnt == 8'd13 && rxd_i==8'hf7 && data_i_reg_ff==8'h88)
        gPTP_flag <= 1'b1;
    else if(rx_dv_i)
        gPTP_flag <= 1'b1;
    else
        gPTP_flag <= 1'b0;
end 


always@(posedge rx_clk or posedge rst)
begin
    if (rst)begin
        timestamp_rx_Pdelay_valid   <= 1'b0;
        timestamp_rx_Sync_valid     <= 1'b0;
        timestamp_rx_Presp_valid    <= 1'b0;
    end
    else if(gPTP_flag && timesamp_cnt==8'd15)begin
        if(data_i_reg_ff[3:0]==4'h0)begin
            timestamp_rx_Sync_valid<=1'b1;
        end
        else if(data_i_reg_ff[3:0]==4'h2)begin
            timestamp_rx_Pdelay_valid<=1'b1;
        end
        else if(data_i_reg_ff[3:0]==4'h3)begin
            timestamp_rx_Presp_valid<=1'b1;
        end
        else begin
            timestamp_rx_Pdelay_valid   <= 1'b0;
            timestamp_rx_Sync_valid     <= 1'b0;
            timestamp_rx_Presp_valid    <= 1'b0;
        end
    end
    else begin
            timestamp_rx_Pdelay_valid   <= 1'b0;
            timestamp_rx_Sync_valid     <= 1'b0;
            timestamp_rx_Presp_valid    <= 1'b0;
    end
end 

//时间戳跨时钟域
xpm_cdc_pulse #(
   .DEST_SYNC_FF(2),   // DECIMAL; range: 2-10
   .INIT_SYNC_FF(1),   // DECIMAL; 0=disable simulation init values, 1=enable simulation init values
   .REG_OUTPUT(0),     // DECIMAL; 0=disable registered output, 1=enable registered output
   .RST_USED(1),       // DECIMAL; 0=no reset, 1=implement reset
   .SIM_ASSERT_CHK(0)  // DECIMAL; 0=disable simulation messages, 1=enable simulation messages
)
xpm_cdc_pulse_inst0 (
   .dest_pulse(timestamp_rx_Pdelay_valid_cdc), // 1-bit output: Outputs a pulse the size of one dest_clk period when a pulse
                            // transfer is correctly initiated on src_pulse input. This output is
                            // combinatorial unless REG_OUTPUT is set to 1.
   .dest_clk(clk),     // 1-bit input: Destination clock.
   .dest_rst(1'b0),     // 1-bit input: optional; required when RST_USED = 1
   .src_clk(rx_clk),       // 1-bit input: Source clock.
   .src_pulse(timestamp_rx_Pdelay_valid),   // 1-bit input: Rising edge of this signal initiates a pulse transfer to the
                            // destination clock domain. The minimum gap between each pulse transfer must be
                            // at the minimum 2*(larger(src_clk period, dest_clk period)). This is measured
                            // between the falling edge of a src_pulse to the rising edge of the next
                            // src_pulse. This minimum gap will guarantee that each rising edge of src_pulse
                            // will generate a pulse the size of one dest_clk period in the destination
                            // clock domain. When RST_USED = 1, pulse transfers will not be guaranteed while
                            // src_rst and/or dest_rst are asserted.
   .src_rst(1'b0)        // 1-bit input: optional; required when RST_USED = 1
);


xpm_cdc_pulse #(
   .DEST_SYNC_FF(2),   // DECIMAL; range: 2-10
   .INIT_SYNC_FF(1),   // DECIMAL; 0=disable simulation init values, 1=enable simulation init values
   .REG_OUTPUT(0),     // DECIMAL; 0=disable registered output, 1=enable registered output
   .RST_USED(1),       // DECIMAL; 0=no reset, 1=implement reset
   .SIM_ASSERT_CHK(0)  // DECIMAL; 0=disable simulation messages, 1=enable simulation messages
)
xpm_cdc_pulse_inst (
   .dest_pulse(timestamp_rx_Sync_valid_cdc), // 1-bit output: Outputs a pulse the size of one dest_clk period when a pulse
                            // transfer is correctly initiated on src_pulse input. This output is
                            // combinatorial unless REG_OUTPUT is set to 1.
   .dest_clk(clk),     // 1-bit input: Destination clock.
   .dest_rst(1'b0),     // 1-bit input: optional; required when RST_USED = 1
   .src_clk(rx_clk),       // 1-bit input: Source clock.
   .src_pulse(timestamp_rx_Sync_valid),   // 1-bit input: Rising edge of this signal initiates a pulse transfer to the
                            // destination clock domain. The minimum gap between each pulse transfer must be
                            // at the minimum 2*(larger(src_clk period, dest_clk period)). This is measured
                            // between the falling edge of a src_pulse to the rising edge of the next
                            // src_pulse. This minimum gap will guarantee that each rising edge of src_pulse
                            // will generate a pulse the size of one dest_clk period in the destination
                            // clock domain. When RST_USED = 1, pulse transfers will not be guaranteed while
                            // src_rst and/or dest_rst are asserted.
   .src_rst(1'b0)        // 1-bit input: optional; required when RST_USED = 1
);

xpm_cdc_pulse #(
   .DEST_SYNC_FF(2),   // DECIMAL; range: 2-10
   .INIT_SYNC_FF(1),   // DECIMAL; 0=disable simulation init values, 1=enable simulation init values
   .REG_OUTPUT(0),     // DECIMAL; 0=disable registered output, 1=enable registered output
   .RST_USED(1),       // DECIMAL; 0=no reset, 1=implement reset
   .SIM_ASSERT_CHK(0)  // DECIMAL; 0=disable simulation messages, 1=enable simulation messages
)
xpm_cdc_pulse_inst2 (
   .dest_pulse(timestamp_rx_Presp_valid_cdc), // 1-bit output: Outputs a pulse the size of one dest_clk period when a pulse
                            // transfer is correctly initiated on src_pulse input. This output is
                            // combinatorial unless REG_OUTPUT is set to 1.
   .dest_clk(clk),     // 1-bit input: Destination clock.
   .dest_rst(1'b0),     // 1-bit input: optional; required when RST_USED = 1
   .src_clk(rx_clk),       // 1-bit input: Source clock.
   .src_pulse(timestamp_rx_Presp_valid),   // 1-bit input: Rising edge of this signal initiates a pulse transfer to the
                            // destination clock domain. The minimum gap between each pulse transfer must be
                            // at the minimum 2*(larger(src_clk period, dest_clk period)). This is measured
                            // between the falling edge of a src_pulse to the rising edge of the next
                            // src_pulse. This minimum gap will guarantee that each rising edge of src_pulse
                            // will generate a pulse the size of one dest_clk period in the destination
                            // clock domain. When RST_USED = 1, pulse transfers will not be guaranteed while
                            // src_rst and/or dest_rst are asserted.
   .src_rst(1'b0)        // 1-bit input: optional; required when RST_USED = 1
);
//*********************
endmodule   