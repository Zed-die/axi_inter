`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2022/07/12 09:12:46
// Design Name: 
// Module Name: 325t_top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module GMII_top(
    input           sys_clk_p     , // 200M
    input           sys_clk_n     ,
    input           gtrefclk_p    , // 125M
    input           gtrefclk_n    ,
    input           rst_n         ,
        
    input           rxn_1         ,
    input           rxp_1         ,
    input           rxn_2         ,
    input           rxp_2         ,
    input           rxn_3         ,
    input           rxp_3         ,
    input           rxn_4         ,
    input           rxp_4         ,
        
    output          txn_1         ,
    output          txp_1         ,
    output          txn_2         ,
    output          txp_2         ,
    output          txn_3         ,
    output          txp_3         ,
    output          txn_4         ,
    output          txp_4         ,
    output          Link_1        ,
    output          Link_2        ,
    output          Link_3        ,
    output          Link_4        ,

    /* 
     * GMII Tx Rx
     */
    (*DOUT_TOUCH = "TRUE"*)output          clk_125M      ,
    (*DOUT_TOUCH = "TRUE"*)input   [7:0]   gmii_txd_A    ,
    (*DOUT_TOUCH = "TRUE"*)input           gmii_tx_en_A  ,
    (*DOUT_TOUCH = "TRUE"*)input   [7:0]   gmii_txd_B    ,
    (*DOUT_TOUCH = "TRUE"*)input           gmii_tx_en_B  ,
    (*DOUT_TOUCH = "TRUE"*)input   [7:0]   gmii_txd_C    ,
    (*DOUT_TOUCH = "TRUE"*)input           gmii_tx_en_C  ,
    (*DOUT_TOUCH = "TRUE"*)input   [7:0]   gmii_txd_D    ,
    (*DOUT_TOUCH = "TRUE"*)input           gmii_tx_en_D  ,
    (*DOUT_TOUCH = "TRUE"*)output  [7:0]   gmii_rxd_A    ,
    (*DOUT_TOUCH = "TRUE"*)output          gmii_rx_en_A  ,
    (*DOUT_TOUCH = "TRUE"*)output  [7:0]   gmii_rxd_B    ,
    (*DOUT_TOUCH = "TRUE"*)output          gmii_rx_en_B  ,
    (*DOUT_TOUCH = "TRUE"*)output  [7:0]   gmii_rxd_C    ,
    (*DOUT_TOUCH = "TRUE"*)output          gmii_rx_en_C  ,
    (*DOUT_TOUCH = "TRUE"*)output  [7:0]   gmii_rxd_D    ,
    (*DOUT_TOUCH = "TRUE"*)output          gmii_rx_en_D  ,
    input       [79:0]      sys_time                     ,
    input       [79:0]      timer                        , 
    input                   two_step_flag                ,   
    output                  userclk2_out                 ,
    output      [3:0]       timestamp_tx_Pdelay_valid_cdc,
    output      [3:0]       timestamp_tx_Sync_valid_cdc  ,
    output      [3:0]       timestamp_tx_Presp_valid_cdc ,
    output      [3:0]       timestamp_rx_Pdelay_valid_cdc,
    output      [3:0]       timestamp_rx_Sync_valid_cdc  ,
    output      [3:0]       timestamp_rx_Presp_valid_cdc 
);


wire clk;
wire clk_200m;
wire locked;

reg    sync_125m_rst;
(*mark_debug = "true"*)reg    sync_125m_rst_f;
reg    sync_200m_rst;
(*mark_debug = "true"*)reg    sync_200m_rst_f;


assign clk_125M = clk;

//rst for 125m
always @(posedge clk or negedge rst_n)
begin
    if (~rst_n)
      sync_125m_rst <= 1'b1 ;
    else if (locked)
      sync_125m_rst <= 1'b0 ;
    else 
      sync_125m_rst <= sync_125m_rst ;
end

always @(posedge clk or negedge rst_n)
begin
    if (~rst_n)
      sync_125m_rst_f <= 1'b1 ;
    else 
      sync_125m_rst_f <= sync_125m_rst ;
end


//rst for pcs_pma 200m
always @(posedge clk_200m or negedge rst_n)
begin
    if (~rst_n)
      sync_200m_rst <= 1'b1 ;
    else if (locked)
      sync_200m_rst <= 1'b0 ;
    else 
      sync_200m_rst <= sync_200m_rst ;
end

always @(posedge clk_200m or negedge rst_n)
begin
    if (~rst_n)
      sync_200m_rst_f <= 1'b1 ;
    else 
      sync_200m_rst_f <= sync_200m_rst ;
end



  clk_wiz_1 U_clk_gen
   (
    // Clock out ports
    .clk_out1(clk),     // 125m user clock
    .clk_out2(clk_200m),     // 200m ip clk
    // Status and control signals
    .reset(~rst_n), // input reset
    .locked(locked),       // output locked
   // Clock in ports
    .clk_in1_p(sys_clk_p),   
    .clk_in1_n(sys_clk_n)
    );  


pcs_pma U_pcs_pma(
    .clk                        (clk)                     ,
    .clk_200M                   (clk_200m)                ,
    .rst                        (sync_125m_rst_f)         ,
    .rst_200m                   (sync_200m_rst_f)         ,
    .gtrefclk_p                 (gtrefclk_p)              ,
    .gtrefclk_n                 (gtrefclk_n)              ,
    .rxn_1                      (rxn_1)                   ,
    .rxp_1                      (rxp_1)                   ,
    .rxn_2                      (rxn_2)                   ,
    .rxp_2                      (rxp_2)                   ,
    .rxn_3                      (rxn_3)                   ,
    .rxp_3                      (rxp_3)                   ,
    .rxn_4                      (rxn_4)                   ,
    .rxp_4                      (rxp_4)                   ,
    .gmii_txd_1                 (gmii_txd_A)              ,
    .gmii_tx_en_1               (gmii_tx_en_A)            ,
    .gmii_txd_2                 (gmii_txd_B)              ,
    .gmii_tx_en_2               (gmii_tx_en_B)            ,
    .gmii_txd_3                 (gmii_txd_C)              ,
    .gmii_tx_en_3               (gmii_tx_en_C)            ,
    .gmii_txd_4                 (gmii_txd_D)              ,
    .gmii_tx_en_4               (gmii_tx_en_D)            ,
    .txn_1                      (txn_1)                   ,
    .txp_1                      (txp_1)                   ,
    .txn_2                      (txn_2)                   ,
    .txp_2                      (txp_2)                   ,
    .txn_3                      (txn_3)                   ,
    .txp_3                      (txp_3)                   ,
    .txn_4                      (txn_4)                   ,
    .txp_4                      (txp_4)                   ,
    .gmii_rxd_1                 (gmii_rxd_A)              ,
    .gmii_rx_dv_1               (gmii_rx_en_A)            ,
    .gmii_rxd_2                 (gmii_rxd_B)              ,
    .gmii_rx_dv_2               (gmii_rx_en_B)            ,
    .gmii_rxd_3                 (gmii_rxd_C)              ,
    .gmii_rx_dv_3               (gmii_rx_en_C)            ,
    .gmii_rxd_4                 (gmii_rxd_D)              ,
    .gmii_rx_dv_4               (gmii_rx_en_D)            ,
    .Link_1                     (Link_1)                  ,              
    .Link_2                     (Link_2)                  ,
    .Link_3                     (Link_3)                  ,
    .Link_4                     (Link_4)                  ,
    .userclk2_out               (userclk2_out)            ,
    .sys_time                   (sys_time)                ,   
    .timer                      (timer   )                ,
    .two_step_flag              (two_step_flag)           ,
    .timestamp_tx_Pdelay_valid_cdc(timestamp_tx_Pdelay_valid_cdc),
    .timestamp_tx_Sync_valid_cdc  (timestamp_tx_Sync_valid_cdc  ),
    .timestamp_tx_Presp_valid_cdc (timestamp_tx_Presp_valid_cdc ),
    .timestamp_rx_Pdelay_valid_cdc(timestamp_rx_Pdelay_valid_cdc),
    .timestamp_rx_Sync_valid_cdc  (timestamp_rx_Sync_valid_cdc  ),
    .timestamp_rx_Presp_valid_cdc (timestamp_rx_Presp_valid_cdc )      
);





endmodule
