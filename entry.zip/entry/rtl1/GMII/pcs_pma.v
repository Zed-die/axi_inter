`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2022/07/11 21:03:45
// Design Name: 
// Module Name: pcs_pma
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////



//4port new connect
module pcs_pma(
    input   wire                  clk                 ,    //user clock
    input   wire                  clk_200M            ,    //to pcs_pma ip
    input   wire                  rst                 ,
    input   wire                  rst_200m            ,

    input   wire                  gtrefclk_p          ,    //to master
    input   wire                  gtrefclk_n          ,    //to master
    input   wire                  rxn_1               ,    //to master
    input   wire                  rxp_1               ,    //to master
    input   wire                  rxn_2               ,    //to slave   
    input   wire                  rxp_2               ,    //to slave
    input   wire                  rxn_3               ,    //to slave
    input   wire                  rxp_3               ,    //to slave
    input   wire                  rxn_4               ,    //to slave   
    input   wire                  rxp_4               ,    //to slave
    input   wire    [7:0]         gmii_txd_1          ,    //to master   
    input   wire                  gmii_tx_en_1        ,    //to master
    input   wire    [7:0]         gmii_txd_2          ,    //to slave
    input   wire                  gmii_tx_en_2        ,    //to slave
    input   wire    [7:0]         gmii_txd_3          ,    //to slave   
    input   wire                  gmii_tx_en_3        ,    //to slave
    input   wire    [7:0]         gmii_txd_4          ,    //to slave
    input   wire                  gmii_tx_en_4        ,    //to slave

    output                        Link_1              ,
    output                        Link_2              ,
    output                        Link_3              ,
    output                        Link_4              ,
    output  wire                  userclk2_out        ,    //phy侧输出用户时钟
    output  wire                  txn_1               ,    //from master
    output  wire                  txp_1               ,    //from master
    output  wire                  txn_2               ,    //from slave
    output  wire                  txp_2               ,    //from slave
    output  wire                  txn_3               ,    //from slave
    output  wire                  txp_3               ,    //from slave
    output  wire                  txn_4               ,    //from slave
    output  wire                  txp_4               ,    //from slave
    output  wire    [7:0]         gmii_rxd_1          ,    //from master
    output  wire                  gmii_rx_dv_1        ,    //from master
    output  wire                  gmii_rx_er_1        ,    //from master
    output  wire    [7:0]         gmii_rxd_2          ,    //from slave
    output  wire                  gmii_rx_dv_2        ,    //from slave
    output  wire                  gmii_rx_er_2        ,    //from slave
    output  wire    [7:0]         gmii_rxd_3          ,    //from slave
    output  wire                  gmii_rx_dv_3        ,    //from slave
    output  wire                  gmii_rx_er_3        ,    //from master
    output  wire    [7:0]         gmii_rxd_4          ,    //from slave
    output  wire                  gmii_rx_dv_4        ,    //from slave
    output  wire                  gmii_rx_er_4,            //from slave

    input           [79:0]        sys_time                     ,
    input           [79:0]        timer                        , 
    input                         two_step_flag                ,   
    output          [3:0]         timestamp_tx_Pdelay_valid_cdc,
    output          [3:0]         timestamp_tx_Sync_valid_cdc  ,
    output          [3:0]         timestamp_tx_Presp_valid_cdc ,
    output          [3:0]         timestamp_rx_Pdelay_valid_cdc,
    output          [3:0]         timestamp_rx_Sync_valid_cdc  ,
    output          [3:0]         timestamp_rx_Presp_valid_cdc 
    );

wire gtrefclk_out               ;    //from master to slave
wire gtrefclk_bufg_out          ;    //from master to slave
wire userclk_out                ;    //from master to slave
wire pma_reset_out              ;    //from master to slave
wire mmcm_locked_out            ;    //from master to slave
wire recclk_mmcm_locked_out     ;
wire gt0_qplloutclk_out         ;    //from master to slave
wire gt0_qplloutrefclk_out      ;    //from master to slave
wire rxoutclk1                  ;    //from slave   
wire rxuserclk_buf1             ;    //bufg from rxoutclk

wire rxoutclk2                  ;    //from slave   
wire rxuserclk_buf2             ;    //bufg from rxoutclk

wire rxoutclk3                  ;    //from slave   
wire rxuserclk_buf3             ;    //bufg from rxoutclk



(*mark_debug = "true"*)wire [15:0] status_vector_master     ;
(*mark_debug = "true"*)wire [15:0] status_vector_slave1      ;
(*mark_debug = "true"*)wire [15:0] status_vector_slave2      ;
(*mark_debug = "true"*)wire [15:0] status_vector_slave3      ;
(*mark_debug = "true"*)wire resetdone_master           ;
(*mark_debug = "true"*)wire resetdone_slave1            ;
(*mark_debug = "true"*)wire resetdone_slave2            ;
(*mark_debug = "true"*)wire resetdone_slave3            ;



(*mark_debug =  "true"*)wire [7:0]    gmii_txd_in_1     ;    //from fifo to master
(*mark_debug =  "true"*)wire          gmii_tx_en_in_1   ;    //from fifo to master
(*mark_debug =  "true"*)wire [7:0]    gmii_txd_in_2     ;    //from fifo to slave
(*mark_debug =  "true"*)wire          gmii_tx_en_in_2   ;    //from fifo to slave
(*mark_debug =  "true"*)wire [7:0]    gmii_rxd_out_1     ;   
(*mark_debug =  "true"*)wire          gmii_rx_en_out_1   ;   
(*mark_debug =  "true"*)wire [7:0]    gmii_rxd_out_2     ;  
(*mark_debug =  "true"*)wire          gmii_rx_en_out_2   ;  
(*mark_debug =  "true"*)wire [7:0]    gmii_txd_in_3     ;    //from fifo to master
(*mark_debug =  "true"*)wire          gmii_tx_en_in_3   ;    //from fifo to master
(*mark_debug =  "true"*)wire [7:0]    gmii_txd_in_4     ;    //from fifo to slave
(*mark_debug =  "true"*)wire          gmii_tx_en_in_4   ;    //from fifo to slave
(*mark_debug =  "true"*)wire [7:0]    gmii_rxd_out_3     ;   
(*mark_debug =  "true"*)wire          gmii_rx_en_out_3   ;   
(*mark_debug =  "true"*)wire [7:0]    gmii_rxd_out_4     ;  
(*mark_debug =  "true"*)wire          gmii_rx_en_out_4   ;  

assign Link_1 = ~(status_vector_master[0]&&resetdone_master);
assign Link_2 = ~(status_vector_slave1[0]&&status_vector_slave1);
assign Link_3 = ~(status_vector_slave2[0]&&status_vector_slave2);
assign Link_4 = ~(status_vector_slave3[0]&&status_vector_slave3);
wire [3:0] onestep_rx_pdelay_valid;

inport_ccd_1000M_tx_SFP u_sfp_tx_1(
    .rx_clk               (clk                    ), //输入用户时钟
    .clk                  (userclk2_out           ), //输出sfp发送时钟
    .rst                  (rst                    ),
    .rxd_i                (gmii_txd_1             ),
    .rx_dv_i              (gmii_tx_en_1           ),
    .rx_er_i              (1'b0                   ),
    .data_out             (gmii_txd_in_1          ),
    .data_out_valid       (gmii_tx_en_in_1        ),
    .data_out_err         (                       ),
    .sys_time             (sys_time               ),
    .timer                (timer                  ),
    .two_step_flag        (two_step_flag          ),
    .onestep_rx_pdelay_valid      (onestep_rx_pdelay_valid[0]      ),
    .timestamp_tx_Pdelay_valid_cdc(timestamp_tx_Pdelay_valid_cdc[0]),
    .timestamp_tx_Sync_valid_cdc  (timestamp_tx_Sync_valid_cdc[0]  ),
    .timestamp_tx_Presp_valid_cdc (timestamp_tx_Presp_valid_cdc[0] )  
);

inport_ccd_1000M_tx_SFP u_sfp_tx_2(
    .rx_clk               (clk                    ), //输入用户时钟
    .clk                  (userclk2_out           ), //输出sfp发送时钟
    .rst                  (rst                    ),
    .rxd_i                (gmii_txd_2             ),
    .rx_dv_i              (gmii_tx_en_2           ),
    .rx_er_i              (1'b0                   ),
    .data_out             (gmii_txd_in_2          ),
    .data_out_valid       (gmii_tx_en_in_2        ),
    .data_out_err         (                       ),
    .sys_time             (sys_time               ),
    .timer                (timer                  ),
    .two_step_flag        (two_step_flag          ),
    .timestamp_tx_Pdelay_valid_cdc(timestamp_tx_Pdelay_valid_cdc[1]),
    .timestamp_tx_Sync_valid_cdc  (timestamp_tx_Sync_valid_cdc[1]  ),
    .timestamp_tx_Presp_valid_cdc (timestamp_tx_Presp_valid_cdc[1] )  
);

inport_ccd_1000M_tx_SFP u_sfp_tx_3(
    .rx_clk               (clk                    ), //输入用户时钟
    .clk                  (userclk2_out           ), //输出sfp发送时钟
    .rst                  (rst                    ),
    .rxd_i                (gmii_txd_3             ),
    .rx_dv_i              (gmii_tx_en_3           ),
    .rx_er_i              (1'b0                   ),
    .data_out             (gmii_txd_in_3          ),
    .data_out_valid       (gmii_tx_en_in_3        ),
    .data_out_err         (                       ),
    .sys_time             (sys_time               ),
    .timer                (timer                  ),
    .two_step_flag        (two_step_flag          ),
    .timestamp_tx_Pdelay_valid_cdc(timestamp_tx_Pdelay_valid_cdc[2]),
    .timestamp_tx_Sync_valid_cdc  (timestamp_tx_Sync_valid_cdc[2]  ),
    .timestamp_tx_Presp_valid_cdc (timestamp_tx_Presp_valid_cdc[2] )  
);

inport_ccd_1000M_tx_SFP u_sfp_tx_4(
    .rx_clk               (clk                    ), //输入用户时钟
    .clk                  (userclk2_out           ), //输出sfp发送时钟
    .rst                  (rst                    ),
    .rxd_i                (gmii_txd_4             ),
    .rx_dv_i              (gmii_tx_en_4           ),
    .rx_er_i              (1'b0                   ),
    .data_out             (gmii_txd_in_4          ),
    .data_out_valid       (gmii_tx_en_in_4        ),
    .data_out_err         (                       ),
    .sys_time             (sys_time               ),
    .timer                (timer                  ),
    .two_step_flag        (two_step_flag          ),
    .timestamp_tx_Pdelay_valid_cdc(timestamp_tx_Pdelay_valid_cdc[3]),
    .timestamp_tx_Sync_valid_cdc  (timestamp_tx_Sync_valid_cdc[3]  ),
    .timestamp_tx_Presp_valid_cdc (timestamp_tx_Presp_valid_cdc[3] )  
);

inport_ccd_1000M_rx_SFP u_sfp_rx_1(
    .rx_clk               (userclk2_out             ), //输入用户时钟
    .clk                  (clk                      ), //输出sfp发送时钟
    .rst                  (rst                      ),
    .rxd_i                (gmii_rxd_out_1           ),
    .rx_dv_i              (gmii_rx_en_out_1         ),
    .rx_er_i              (1'b0                     ),
    .rxd_o                (gmii_rxd_1               ),
    .rx_dv_o              (gmii_rx_dv_1             ),
    .rx_er_o              (gmii_rx_er_1             ),
    .onestep_rx_pdelay_valid      (onestep_rx_pdelay_valid[0]      ),
    .timestamp_rx_Pdelay_valid_cdc(timestamp_rx_Pdelay_valid_cdc[0]),
    .timestamp_rx_Sync_valid_cdc  (timestamp_rx_Sync_valid_cdc[0]  ),
    .timestamp_rx_Presp_valid_cdc (timestamp_rx_Presp_valid_cdc[0] )  
);

inport_ccd_1000M_rx_SFP u_sfp_rx_2(
    .rx_clk               (userclk2_out             ),
    .clk                  (clk                      ),
    .rst                  (rst                      ),
    .rxd_i                (gmii_rxd_out_2           ),
    .rx_dv_i              (gmii_rx_en_out_2         ),
    .rx_er_i              (1'b0                     ),
    .rxd_o                (gmii_rxd_2               ),
    .rx_dv_o              (gmii_rx_dv_2             ),
    .rx_er_o              (gmii_rx_er_2             ),
    .timestamp_rx_Pdelay_valid_cdc(timestamp_rx_Pdelay_valid_cdc[1]),
    .timestamp_rx_Sync_valid_cdc  (timestamp_rx_Sync_valid_cdc[1]  ),
    .timestamp_rx_Presp_valid_cdc (timestamp_rx_Presp_valid_cdc[1] )  
);

inport_ccd_1000M_rx_SFP u_sfp_rx_3(
    .rx_clk               (userclk2_out            ),
    .clk                  (clk                     ),
    .rst                  (rst                     ),
    .rxd_i                (gmii_rxd_out_3          ),
    .rx_dv_i              (gmii_rx_en_out_3        ),
    .rx_er_i              (1'b0                    ),
    .rxd_o                (gmii_rxd_3              ),
    .rx_dv_o              (gmii_rx_dv_3            ),
    .rx_er_o              (gmii_rx_er_3            ),
    .timestamp_rx_Pdelay_valid_cdc(timestamp_rx_Pdelay_valid_cdc[2]),
    .timestamp_rx_Sync_valid_cdc  (timestamp_rx_Sync_valid_cdc[2]  ),
    .timestamp_rx_Presp_valid_cdc (timestamp_rx_Presp_valid_cdc[2] )  
);

inport_ccd_1000M_rx_SFP u_sfp_rx_4(
    .rx_clk               (userclk2_out            ),
    .clk                  (clk                     ),
    .rst                  (rst                     ),
    .rxd_i                (gmii_rxd_out_4          ),
    .rx_dv_i              (gmii_rx_en_out_4        ),
    .rx_er_i              (1'b0                    ),
    .rxd_o                (gmii_rxd_4              ),
    .rx_dv_o              (gmii_rx_dv_4            ),
    .rx_er_o              (gmii_rx_er_4            ),
    .timestamp_rx_Pdelay_valid_cdc(timestamp_rx_Pdelay_valid_cdc[3]),
    .timestamp_rx_Sync_valid_cdc  (timestamp_rx_Sync_valid_cdc[3]  ),
    .timestamp_rx_Presp_valid_cdc (timestamp_rx_Presp_valid_cdc[3] ) 
);


gig_ethernet_pcs_pma_0 master (
  .gtrefclk_p(gtrefclk_p),                          // input wire gtrefclk_p    connect with pin
  .gtrefclk_n(gtrefclk_n),                          // input wire gtrefclk_n    connect with pin
  .gtrefclk_out(gtrefclk_out),                      // output wire gtrefclk_out  connect with slave  125M reference clock
  .gtrefclk_bufg_out(gtrefclk_bufg_out),            // output wire gtrefclk_bufg_out connect with slave   reference clock
  .txn(txn_1),                                        // output wire txn
  .txp(txp_1),                                        // output wire txp
  .rxn(rxn_1),                                        // input wire rxn
  .rxp(rxp_1),                                        // input wire rxp
  .independent_clock_bufg(clk_200M),  // input wire independent_clock_bufg         stable clock 200M
  .userclk_out(userclk_out),                        // output wire userclk_out     connect to slave 62.5M/156.25M
  .userclk2_out(userclk2_out),                      // output wire userclk2_out    connect to slave 125M/312.5M    gmii_txd_clk
  .rxuserclk_out(rxuserclk_out),                    // output wire rxuserclk_out   connect nothing   
  .rxuserclk2_out(rxuserclk2_out),                  // output wire rxuserclk2_out  connect nothing   gmii_rxd_clk
  .resetdone(resetdone_master),                            // output wire resetdone
  .pma_reset_out(pma_reset_out),                    // output wire pma_reset_out   connect nothing
  .mmcm_locked_out(mmcm_locked_out),                // output wire mmcm_locked_out    connect slave
  //.recclk_mmcm_locked_out(recclk_mmcm_locked_out),  // output wire recclk_mmcm_locked_out  enabled when rx clk source is rxoutclk
  .gmii_txd(gmii_txd_in_1),                              // input wire [7 : 0] gmii_txd  
  .gmii_tx_en(gmii_tx_en_in_1),                          // input wire gmii_tx_en
  .gmii_tx_er(1'b0),                          // input wire gmii_tx_er
  .gmii_rxd(gmii_rxd_out_1),                              // output wire [7 : 0] gmii_rxd
  .gmii_rx_dv(gmii_rx_en_out_1),                          // output wire gmii_rx_dv
  .gmii_rx_er(),                          // output wire gmii_rx_er
  // .gmii_isolate(gmii_isolate),                      // output wire gmii_isolate
  .configuration_vector(5'b10000),      // input wire [4 : 0] configuration_vector
  .an_interrupt(),                      // output wire an_interrupt    enabled when an
  .an_adv_config_vector(16'b0000000000100000),      // input wire [15 : 0] an_adv_config_vector    enabled when an
  .an_restart_config(1'b0),            // input wire an_restart_config    enabled when an
  .status_vector(status_vector_master),                    // output wire [15 : 0] status_vector   connect nothing 
  .reset(rst_200m),                                    // input wire reset
  .signal_detect(1'b1),                    // input wire signal_detect
  .gt0_qplloutclk_out(gt0_qplloutclk_out),          // output wire gt0_qplloutclk_out   connect nothing
  .gt0_qplloutrefclk_out(gt0_qplloutrefclk_out)    // output wire gt0_qplloutrefclk_out    connect nothing 
);



BUFG BUFG_SFP1 (
   .O(rxuserclk_buf1), // 1-bit output: Clock output
   .I(rxoutclk1)  // 1-bit input: Clock input
);


gig_ethernet_pcs_pma_1 slave1 (
  .gtrefclk_bufg(gtrefclk_bufg_out),                    // input wire gtrefclk_bufg
  .gtrefclk(gtrefclk_out),                              // input wire gtrefclk
  .txn(txn_2),                                        // output wire txn
  .txp(txp_2),                                        // output wire txp
  .rxn(rxn_2),                                        // input wire rxn
  .rxp(rxp_2),                                        // input wire rxp
  .independent_clock_bufg(clk_200M),  // input wire independent_clock_bufg
  // .txoutclk(txoutclk),                              // output wire txoutclk
  .rxoutclk(rxoutclk1),                              // output wire rxoutclk
  .resetdone(resetdone_slave1),                            // output wire resetdone
  // .cplllock(cplllock),                              // output wire cplllock
  // .mmcm_reset(mmcm_reset),                          // output wire mmcm_reset
  .userclk(userclk_out),                                // input wire userclk
  .userclk2(userclk2_out),                              // input wire userclk2
  .pma_reset(pma_reset_out),                            // input wire pma_reset
  .mmcm_locked(mmcm_locked_out),                        // input wire mmcm_locked 
  // .recclk_mmcm_locked(mmcm_locked_out),          // input wire recclk_mmcm_locked  enabled when rx clk source is rxoutclk    
  .rxuserclk(rxuserclk_buf1),                            // input wire rxuserclk
  .rxuserclk2(rxuserclk_buf1),                          // input wire rxuserclk2
  .gmii_txd(gmii_txd_in_2),                              // input wire [7 : 0] gmii_txd
  .gmii_tx_en(gmii_tx_en_in_2),                          // input wire gmii_tx_en
  .gmii_tx_er(1'b0),                          // input wire gmii_tx_er
  .gmii_rxd(gmii_rxd_out_2),                              // output wire [7 : 0] gmii_rxd
  .gmii_rx_dv(gmii_rx_en_out_2),                          // output wire gmii_rx_dv
  .gmii_rx_er(),                          // output wire gmii_rx_er
  // .gmii_isolate(gmii_isolate),                      // output wire gmii_isolate
  .configuration_vector(5'b10000),      // input wire [4 : 0] configuration_vector
  .an_interrupt(),                      // output wire an_interrupt     enabled when an
  .an_adv_config_vector(16'b0000000000100000),      // input wire [15 : 0] an_adv_config_vector     enabled when an
  .an_restart_config(1'b0),            // input wire an_restart_config     enabled when an
  .status_vector(status_vector_slave1),                    // output wire [15 : 0] status_vector
  .reset(rst_200m),                                    // input wire reset
  .signal_detect(1'b1),                    // input wire signal_detect
  .gt0_qplloutclk_in(gt0_qplloutclk_out),            // input wire gt0_qplloutclk_in
  .gt0_qplloutrefclk_in(gt0_qplloutrefclk_out)      // input wire gt0_qplloutrefclk_in
);




   BUFG BUFG_SFP2 (
      .O(rxuserclk_buf2), // 1-bit output: Clock output
      .I(rxoutclk2)  // 1-bit input: Clock input
   );


gig_ethernet_pcs_pma_1 slave2 (
  .gtrefclk_bufg(gtrefclk_bufg_out),                    // input wire gtrefclk_bufg
  .gtrefclk(gtrefclk_out),                              // input wire gtrefclk
  .txn(txn_3),                                        // output wire txn
  .txp(txp_3),                                        // output wire txp
  .rxn(rxn_3),                                        // input wire rxn
  .rxp(rxp_3),                                        // input wire rxp
  .independent_clock_bufg(clk_200M),  // input wire independent_clock_bufg
  // .txoutclk(txoutclk),                              // output wire txoutclk
  .rxoutclk(rxoutclk2),                              // output wire rxoutclk
  .resetdone(resetdone_slave2),                            // output wire resetdone
  // .cplllock(cplllock),                              // output wire cplllock
  // .mmcm_reset(mmcm_reset),                          // output wire mmcm_reset
  .userclk(userclk_out),                                // input wire userclk
  .userclk2(userclk2_out),                              // input wire userclk2
  .pma_reset(pma_reset_out),                            // input wire pma_reset
  .mmcm_locked(mmcm_locked_out),                        // input wire mmcm_locked 
  // .recclk_mmcm_locked(mmcm_locked_out),          // input wire recclk_mmcm_locked  enabled when rx clk source is rxoutclk    
  .rxuserclk(rxuserclk_buf2),                            // input wire rxuserclk
  .rxuserclk2(rxuserclk_buf2),                          // input wire rxuserclk2
  .gmii_txd(gmii_txd_in_3),                              // input wire [7 : 0] gmii_txd
  .gmii_tx_en(gmii_tx_en_in_3),                          // input wire gmii_tx_en
  .gmii_tx_er(1'b0),                          // input wire gmii_tx_er
  .gmii_rxd(gmii_rxd_out_3),                              // output wire [7 : 0] gmii_rxd
  .gmii_rx_dv(gmii_rx_en_out_3),                          // output wire gmii_rx_dv
  .gmii_rx_er(),                          // output wire gmii_rx_er
  // .gmii_isolate(gmii_isolate),                      // output wire gmii_isolate
  .configuration_vector(5'b10000),      // input wire [4 : 0] configuration_vector
  .an_interrupt(),                      // output wire an_interrupt     enabled when an
  .an_adv_config_vector(16'b0000000000100000),      // input wire [15 : 0] an_adv_config_vector     enabled when an
  .an_restart_config(1'b0),            // input wire an_restart_config     enabled when an
  .status_vector(status_vector_slave2),                    // output wire [15 : 0] status_vector
  .reset(rst_200m),                                    // input wire reset
  .signal_detect(1'b1),                    // input wire signal_detect
  .gt0_qplloutclk_in(gt0_qplloutclk_out),            // input wire gt0_qplloutclk_in
  .gt0_qplloutrefclk_in(gt0_qplloutrefclk_out)      // input wire gt0_qplloutrefclk_in
);

   BUFG BUFG_SFP3 (
      .O(rxuserclk_buf3), // 1-bit output: Clock output
      .I(rxoutclk3)  // 1-bit input: Clock input
   );


gig_ethernet_pcs_pma_1 slave3 (
  .gtrefclk_bufg(gtrefclk_bufg_out),                    // input wire gtrefclk_bufg
  .gtrefclk(gtrefclk_out),                              // input wire gtrefclk
  .txn(txn_4),                                        // output wire txn
  .txp(txp_4),                                        // output wire txp
  .rxn(rxn_4),                                        // input wire rxn
  .rxp(rxp_4),                                        // input wire rxp
  .independent_clock_bufg(clk_200M),  // input wire independent_clock_bufg
  // .txoutclk(txoutclk),                              // output wire txoutclk
  .rxoutclk(rxoutclk3),                              // output wire rxoutclk
  .resetdone(resetdone_slave3),                            // output wire resetdone
  // .cplllock(cplllock),                              // output wire cplllock
  // .mmcm_reset(mmcm_reset),                          // output wire mmcm_reset
  .userclk(userclk_out),                                // input wire userclk
  .userclk2(userclk2_out),                              // input wire userclk2
  .pma_reset(pma_reset_out),                            // input wire pma_reset
  .mmcm_locked(mmcm_locked_out),                        // input wire mmcm_locked 
  // .recclk_mmcm_locked(mmcm_locked_out),          // input wire recclk_mmcm_locked  enabled when rx clk source is rxoutclk    
  .rxuserclk(rxuserclk_buf3),                            // input wire rxuserclk
  .rxuserclk2(rxuserclk_buf3),                          // input wire rxuserclk2
  .gmii_txd(gmii_txd_in_4),                              // input wire [7 : 0] gmii_txd
  .gmii_tx_en(gmii_tx_en_in_4),                          // input wire gmii_tx_en
  .gmii_tx_er(1'b0),                          // input wire gmii_tx_er
  .gmii_rxd(gmii_rxd_out_4),                              // output wire [7 : 0] gmii_rxd
  .gmii_rx_dv(gmii_rx_en_out_4),                          // output wire gmii_rx_dv
  .gmii_rx_er(),                          // output wire gmii_rx_er
  // .gmii_isolate(gmii_isolate),                      // output wire gmii_isolate
  .configuration_vector(5'b10000),      // input wire [4 : 0] configuration_vector
  .an_interrupt(),                      // output wire an_interrupt     enabled when an
  .an_adv_config_vector(16'b0000000000100000),      // input wire [15 : 0] an_adv_config_vector     enabled when an
  .an_restart_config(1'b0),            // input wire an_restart_config     enabled when an
  .status_vector(status_vector_slave3),                    // output wire [15 : 0] status_vector
  .reset(rst_200m),                                    // input wire reset
  .signal_detect(1'b1),                    // input wire signal_detect
  .gt0_qplloutclk_in(gt0_qplloutclk_out),            // input wire gt0_qplloutclk_in
  .gt0_qplloutrefclk_in(gt0_qplloutrefclk_out)      // input wire gt0_qplloutrefclk_in
);


endmodule

