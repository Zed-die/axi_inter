`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company:XIDIAN
// Engineer:wanghaoyu 
// 
// Create Date: 2025/07/13 10:31:54
// Design Name: 
// Module Name: sync_ctrl
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// use to board sync
//
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module sync_ctrl (
	//时钟与复位
	input     clk            ,    
	input     rst_n          ,
	input     test_rst       ,
	input     restart_sync   ,//测试仪重新启动的控制信号

	input             pulse         ,//秒脉冲
	input             sync_register1,//agent告诉主控fpga等待下一个秒脉冲到达给出反馈信号
	output    reg     sync_register2,//主控fpga等到秒脉冲到达，给agent发出反馈信号
	input             sync_register3,//agent告诉fpga等待下一个秒脉冲进入同步状态
	output    reg     sync_register4,//告诉agent,测试仪fpga已经进入同步状态了   

    input             Test_sync_register1,
    output    reg     Test_sync_register2,
    input             Test_sync_register3,
    output    reg     Test_sync_register4,

	output               	local_sync        ,//本地同步信号
	output         [63:0] 	local_time		  ,

	output    reg         	test_sync         ,//测试同步信号
	output    	   [63:0] 	test_time 		   
	    
);

//状态定义
parameter IDLE                      =  9'b0_0000_0001;
parameter LOCAL_SYNC_WFIR_PLUSE     =  9'b0_0000_0010;
parameter LOCAL_SYNC_WSEC_PLUSE     =  9'b0_0000_0100;
parameter LOCAL_SYNC_SET_READYREG   =  9'b0_0000_1000; 
parameter LOCAL_SYNC                =  9'b0_0001_0000;
parameter TEST_SYNC_WFIR_PLUSE      =  9'b0_0010_0000;              
parameter TEST_SYNC_WSEC_PLUSE      =  9'b0_0100_0000;
parameter TEST_SYNC_SET_READYREG    =  9'b0_1000_0000;
parameter TEST_SYNC                 =  9'b1_0000_0000;   

localparam PERIOD_S = 32'd1_000_000_000;       

//------------------------------------------------信号沿检测----------------------------------//
reg pulse_ff1 ;
reg pulse_ff2 ;
reg pulse_ff3 ;
reg pos_pulse ;

//本地同步相关寄存器
reg sync_register1_ff   ;
reg sync_register1_pose ;
reg sync_register3_pose ;
reg sync_register3_ff   ;

//测试同步相关寄存器
reg Test_sync_register1_ff   ;
reg Test_sync_register1_pose ;
reg Test_sync_register3_pose ;
reg Test_sync_register3_ff   ;

//测试复位相关寄存器
reg test_rst_ff ;
reg test_rst_pose ;

//状态机
reg [8:0] c_state ;
reg [8:0] n_state ;

//时间变量
reg [31:0] local_time_ns;
reg [31:0] local_time_s ;
assign local_time = {local_time_s, local_time_ns};

reg [31:0] test_time_ns;
reg [31:0] test_time_s ;
assign test_time = {test_time_s, test_time_ns};
//板卡同步标识
wire board_sync;
assign board_sync = c_state == LOCAL_SYNC || c_state ==TEST_SYNC_WFIR_PLUSE  || c_state ==TEST_SYNC_WSEC_PLUSE  || c_state ==TEST_SYNC_SET_READYREG|| c_state ==TEST_SYNC;
assign local_sync = board_sync;

//检测秒脉冲
//打三拍的意义在于从地板传过来的脉冲信号宽度未知，确保稳定，一定能能够采到
always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		pulse_ff1 <= 1'b0 ;
	else if ( pulse == 1'b1 ) 
		pulse_ff1 <= 1'b1 ;
	else
		pulse_ff1 <= 1'b0 ;
end

always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		pulse_ff2 <= 1'b0 ;
	else if ( pulse_ff1 == 1'b1 ) 
		pulse_ff2 <= 1'b1 ;
	else
		pulse_ff2 <= 1'b0 ;
end

always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		pulse_ff3 <= 1'b0 ;
	else if ( pulse_ff2 == 1'b1 ) 
		pulse_ff3 <= 1'b1 ;
	else
		pulse_ff3 <= 1'b0 ;
end

always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		pos_pulse <= 1'b0 ;
	else if ( pulse_ff2 == 1'b0 && pulse_ff3 == 1'b1 ) 
		pos_pulse <= 1'b1 ;
	else
		pos_pulse <= 1'b0 ;
end


//对本地同步寄存器sync_register1进行上升沿检测
always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		sync_register1_ff <= 1'b0 ;
	else
		sync_register1_ff <= sync_register1 ;
end

always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		sync_register1_pose <= 1'b0 ;
	else if ( sync_register1 == 1'b1 && sync_register1_ff == 1'b0 )
		sync_register1_pose <= 1'b1 ;
	else 
		sync_register1_pose <= 1'b0 ;
end


//对本地同步寄存器sync_register3进行上升沿检测
always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		sync_register3_ff <= 1'b0 ;
	else
		sync_register3_ff <= sync_register3 ;
end

always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		sync_register3_pose <= 1'b0 ;
	else if ( sync_register3 == 1'b1 && sync_register3_ff == 1'b0 )
		sync_register3_pose <= 1'b1 ;
	else 
		sync_register3_pose <= 1'b0 ;
end


//对测试同步寄存器Test_sync_register1进行上升沿检测
always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		Test_sync_register1_ff <= 1'b0 ;
	else
		Test_sync_register1_ff <= Test_sync_register1 ;
end

always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		Test_sync_register1_pose <= 1'b0 ;
	else if ( Test_sync_register1 == 1'b1 && Test_sync_register1_ff == 1'b0 )
		Test_sync_register1_pose <= 1'b1 ;
	else 
		Test_sync_register1_pose <= 1'b0 ;
end


//对测试同步寄存器Test_sync_register3进行上升沿检测
always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		Test_sync_register3_ff <= 1'b0 ;
	else
		Test_sync_register3_ff <= Test_sync_register3 ;
end

always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		Test_sync_register3_pose <= 1'b0 ;
	else if ( Test_sync_register3 == 1'b1 && Test_sync_register3_ff == 1'b0 )
		Test_sync_register3_pose <= 1'b1 ;
	else 
		Test_sync_register3_pose <= 1'b0 ;
end


//对测试复位寄存器test_rst进行上升沿检测
always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		test_rst_ff <= 1'b0 ;
	else
		test_rst_ff <= test_rst ;
end

always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		test_rst_pose <= 1'b0 ;
	else if ( test_rst == 1'b1 && test_rst_ff == 1'b0 )
		test_rst_pose <= 1'b1 ;
	else 
		test_rst_pose <= 1'b0 ;
end


//-------------------------状态机第一段-------------------------------
always @(posedge clk or negedge rst_n) begin
	if (!rst_n)
		c_state <= IDLE ;
	else
		c_state <= n_state ;
end


//-------------------------状态机第二段-------------------------------
always @(*) begin
	case( c_state )
		IDLE:
			if(sync_register1_pose)
				n_state = LOCAL_SYNC_WFIR_PLUSE ;
			else if (sync_register3_pose)
				n_state = LOCAL_SYNC_WSEC_PLUSE ;   
			else
				n_state = IDLE ;

		LOCAL_SYNC_WFIR_PLUSE:
			if (restart_sync)
				n_state = IDLE ;
			else if (pos_pulse == 1'b1)
				n_state = LOCAL_SYNC_SET_READYREG ;
			else 
				n_state = LOCAL_SYNC_WFIR_PLUSE ;

		LOCAL_SYNC_WSEC_PLUSE:
			if (restart_sync)
				n_state = IDLE ;
			else if (pos_pulse == 1'b1)
				n_state = LOCAL_SYNC ;
			else
				n_state = LOCAL_SYNC_WSEC_PLUSE ;

		LOCAL_SYNC_SET_READYREG:
				n_state = IDLE ;

		LOCAL_SYNC:
			if (restart_sync)
				n_state = IDLE ;
			else if(Test_sync_register1_pose)
				n_state = TEST_SYNC_WFIR_PLUSE ;
			else if (Test_sync_register3_pose)
				n_state = TEST_SYNC_WSEC_PLUSE ;
			else 
				n_state = LOCAL_SYNC ;

		TEST_SYNC_WFIR_PLUSE:
			if (restart_sync)
				n_state = IDLE ;
			else if (pos_pulse == 1'b1)
				n_state = TEST_SYNC_SET_READYREG ;
			else 
				n_state = TEST_SYNC_WFIR_PLUSE ;

		TEST_SYNC_WSEC_PLUSE:
			if (restart_sync)
				n_state = IDLE ;
			else if (pos_pulse == 1'b1)
				n_state = TEST_SYNC ;
			else
				n_state = TEST_SYNC_WSEC_PLUSE ;

		TEST_SYNC_SET_READYREG:
				n_state = LOCAL_SYNC ;

		TEST_SYNC:
			if (restart_sync)
				n_state = IDLE ;
			else if (test_rst_pose)
				n_state = LOCAL_SYNC ;
			else 
				n_state = TEST_SYNC  ;
		default:
		        n_state = IDLE ;

	endcase
end


//-------------------------状态机第三段-------------------------------

//主控fpga等到秒脉冲到达，给agent发出反馈信号
always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		sync_register2 <= 1'b0 ;
	else if ( n_state == LOCAL_SYNC_SET_READYREG )
		sync_register2 <= 1'b1 ;
	else 
		sync_register2 <= sync_register2 ;
end

//告诉agent,测试仪fpga已经进入同步状态了
always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		sync_register4 <= 1'b0 ;
	else if ( n_state == LOCAL_SYNC )
		sync_register4 <= 1'b1 ;
	else 
		sync_register4 <= 1'b0 ;
end

//板卡同步的local_time
always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		local_time_ns <= 32'd0;
	else if (local_time_ns == PERIOD_S - 1) 
		local_time_ns <= 32'd0;
	else if (board_sync)begin 
		if(pos_pulse)
			local_time_ns <= 32'd0;
		else 
			local_time_ns <= local_time_ns + 32'd8;
		end
	else 
		local_time_ns <= 32'd0;	
end

always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		local_time_s <= 32'd0;
	else if (board_sync)begin 
		if(pos_pulse)
			local_time_s <= local_time_s + 32'd1;
		else
			local_time_s <= local_time_s;
		end
	else 
		local_time_s <= 32'd0;	
end

//测试仪开始测试同步的标志
always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		test_sync <= 1'b0 ;
	else if ( n_state == TEST_SYNC )
		test_sync <= 1'b1 ;
	else 
		test_sync <= 1'b0 ;
end

always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		Test_sync_register2 <= 1'b0 ;
	else if ( n_state == TEST_SYNC_SET_READYREG )
		Test_sync_register2 <= 1'b1 ;
	else if ( n_state == TEST_SYNC )
		Test_sync_register2 <= 1'b0 ;
	else 
		Test_sync_register2 <= Test_sync_register2 ;
end

//告诉agent,测试仪fpga已经进入同步状态了
always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		Test_sync_register4 <= 1'b0 ;
	else if ( n_state == TEST_SYNC )
		Test_sync_register4 <= 1'b1 ;
	else 
		Test_sync_register4 <= 1'b0 ;
end

//测试仪同步之后维护的测试同步时间
always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		test_time_ns <= 32'd0;
	else if (test_time_ns == PERIOD_S-1) 
		test_time_ns <= 32'd0;
	else if ( c_state == TEST_SYNC )	begin 
		if(pos_pulse)
			test_time_ns <= 32'd0;
		else 
			test_time_ns <= test_time_ns+32'd8;
		end
	else 
		test_time_ns <= 32'd0;	
end

always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		test_time_s <= 32'd0;
	else if ( test_rst )
		test_time_s <= 32'd0;
	else if ( c_state == TEST_SYNC )	begin 
		if(pos_pulse)
			test_time_s <= test_time_s + 32'd1;
		else 
			test_time_s <= test_time_s;
		end
	else 
		test_time_s <= 32'd0;	
end


endmodule