`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company:XIDIAN
// Engineer: wanghaoyu
// 
// Create Date: 2025/07/02 15:41:08
// Design Name: 
// Module Name: output_select
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: GMII TX Multiplexer with hitless (frame-boundary) switching.
//              支持在帧间隙安全切换模式，并对随机的 testing 信号做防断帧门控。
// 
// Dependencies: 
// 
// Revision:
// Revision 0.03 - Added testing signal gating with frame-boundary protection
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module output_select(
    input                 clk            ,
    input                 rst_n          ,
    input        [1:0]    port_mode      ,  // 模式控制信号 (外部随时可能切换)
    input                 testing        ,  // 测试使能信号 (外部完全随机输入)

    input        [7:0]    txd_from_test  ,  // 来自 test 模块的数据
    input                 tx_en_from_test,  // 来自 test 模块的使能
    input        [7:0]    txd_from_oc    ,  // 来自 oc 模块的数据
    input                 tx_en_from_oc  ,  // 来自 oc 模块的使能
    
    output  reg  [7:0]    gmii_txd       ,  // 输出到 PHY 的 GMII 数据
    output  reg           gmii_tx_en        // 输出到 PHY 的数据有效标志
);

parameter MODE1 = 2'b01,  // 测试模式
          MODE2 = 2'b10;  // OC 模式

// 内部实际生效的寄存器（经过帧间隙保护）
reg [1:0] active_mode;
reg       active_testing;

//-------------------------------------------------------------------------
// 状态更新逻辑：只在安全窗口（帧间隙）进行状态更新
// 无论是切模式还是切 testing 使能，都必须等当前帧发完
//-------------------------------------------------------------------------
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        active_mode    <= 2'b00; // 默认空闲状态
        active_testing <= 1'b0;  // 默认不使能
    end else begin
        // 根据当前正在生效的模式，去侦听对应的 tx_en 信号
        case (active_mode)
            MODE1: begin
                // 如果当前是测试模式，必须等 test 的 tx_en 拉低（发完当前帧），才能更新状态
                if (!tx_en_from_test) begin
                    active_mode    <= port_mode;
                    active_testing <= testing;
                end
            end
            MODE2: begin
                // 如果当前是 OC 模式，必须等 oc 的 tx_en 拉低，才能更新状态
                if (!tx_en_from_oc) begin
                    active_mode    <= port_mode;
                    active_testing <= testing;
                end
            end
            default: begin
                // 如果当前是空闲或其他状态，总线必定空闲，直接立刻采样外部信号
                active_mode    <= port_mode;
                active_testing <= testing;
            end
        endcase
    end
end

//-------------------------------------------------------------------------
// 数据输出逻辑：根据“实际生效”的模式和使能进行数据选择与隔离
//-------------------------------------------------------------------------
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        gmii_txd   <=  8'b0;
        gmii_tx_en <=  1'b0;
    end else if (active_testing) begin
        // 只有当受保护的 testing 信号为高时，才允许数据输出到 GMII
        case (active_mode)
            MODE1: begin
                // 数据来自 test
                gmii_txd   <= txd_from_test  ;
                gmii_tx_en <= tx_en_from_test;
            end
            MODE2: begin
                // 数据来自 oc
                gmii_txd   <= txd_from_oc    ;
                gmii_tx_en <= tx_en_from_oc  ;
            end
            default: begin
                // 未知模式，强制关断
                gmii_txd   <= 8'b0;
                gmii_tx_en <= 1'b0;
            end
        endcase
    end else begin
        // active_testing 为低电平时，无论各模块在发什么，强制在 GMII 侧关断输出
        gmii_txd   <= 8'b0;
        gmii_tx_en <= 1'b0;
    end
end

endmodule