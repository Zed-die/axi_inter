`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: XIDIAN
// Engineer: wanghaoyu
// 
// Create Date: 2025/06/16 16:26:12
// Design Name: 
// Module Name: TSN_802_TestCenter_Top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module TSN_802_TestCenter_Top(
    input              clk,
    input              rst_n,
    input              pulse,
    
    input      [7:0]   gmii_rxd0  ,
    input              gmii_rx_en0,
    output     [7:0]   gmii_txd0  ,
    output             gmii_tx_en0,
      
    input      [7:0]   gmii_rxd1  ,
    input              gmii_rx_en1,
    output     [7:0]   gmii_txd1  ,
    output             gmii_tx_en1,
      
    input      [7:0]   gmii_rxd2  ,
    input              gmii_rx_en2,
    output     [7:0]   gmii_txd2  ,
    output             gmii_tx_en2,
      
    input      [7:0]   gmii_rxd3  ,
    input              gmii_rx_en3,
    output     [7:0]   gmii_txd3  ,
    output             gmii_tx_en3,
    
    // xdma配置下发
    input              wen_sys     ,
    input      [31:0]  waddr_sys   ,
    input      [31:0]  wdata_sys   ,
    input              ren_sys     ,
    input      [31:0]  raddr_sys   ,
    output     [31:0]  rdata_sys   ,
    output             rvalid_sys  ,
    input      [31:0]  ga_data_in  ,

    // AXI-Stream 输出
    output     [63:0]  s_axis_c2h_tdata_1  , 
    output             s_axis_c2h_tlast_1  ,
    output             s_axis_c2h_tvalid_1 ,
    input              s_axis_c2h_tready_1 ,
    output     [7:0]   s_axis_c2h_tkeep_1  ,

    output             card_upload_ren_1   ,
    input              card_upload_flag_1  ,

    // 同步脉冲
    output             sync_pulse,

    // 时间戳
    input      [3:0]   timestamp_tx_Pdelay_valid_cdc      ,
    input      [3:0]   timestamp_tx_Sync_valid_cdc        ,
    input      [3:0]   timestamp_tx_Presp_valid_cdc       ,
    input      [3:0]   timestamp_rx_Pdelay_valid_cdc      ,
    input      [3:0]   timestamp_rx_Sync_valid_cdc        ,
    input      [3:0]   timestamp_rx_Presp_valid_cdc       ,
    input      [3:0]   timestamp_rx_Sync_follow_valid_cdc ,
    input      [3:0]   timestamp_rx_Presp_follow_valid_cdc,
    input      [3:0]   timestamp_rx_Announce_valid_cdc     
);


wire frame_info_empty0;
wire frame_info_empty1;
wire frame_info_empty2;
wire frame_info_empty3;
wire frame_info_rd_en0;
wire frame_info_rd_en1;
wire frame_info_rd_en2;
wire frame_info_rd_en3;

wire [383:0] upload_frame_info0;
wire [383:0] upload_frame_info1;
wire [383:0] upload_frame_info2;
wire [383:0] upload_frame_info3;

// 上报交互
wire  card_upload_ren_0 ; 
wire  card_upload_flag_0;

// 上报OC端信息
wire [31:0]  port0_upload_port_state ;
wire [31:0]  port0_upload_sys_time_ns;
wire [31:0]  port0_upload_offset     ;
wire [31:0]  port0_upload_delay      ;

wire [31:0]  port1_upload_port_state ;
wire [31:0]  port1_upload_sys_time_ns;
wire [31:0]  port1_upload_offset     ;
wire [31:0]  port1_upload_delay      ;

wire [31:0]  port2_upload_port_state ;
wire [31:0]  port2_upload_sys_time_ns;
wire [31:0]  port2_upload_offset     ;
wire [31:0]  port2_upload_delay      ;

wire [31:0]  port3_upload_port_state ;
wire [31:0]  port3_upload_sys_time_ns;
wire [31:0]  port3_upload_offset     ;
wire [31:0]  port3_upload_delay      ;

// 帧间隔统计
wire [31:0]  port0_sync_interval       ;
wire [31:0]  port0_announce_interval   ;
wire [31:0]  port0_pdelay_interval     ;
wire [31:0]  port0_pdelay_resp_interval;

wire [31:0]  port1_sync_interval       ;
wire [31:0]  port1_announce_interval   ;
wire [31:0]  port1_pdelay_interval     ;
wire [31:0]  port1_pdelay_resp_interval;

wire [31:0]  port2_sync_interval       ;
wire [31:0]  port2_announce_interval   ;
wire [31:0]  port2_pdelay_interval     ;
wire [31:0]  port2_pdelay_resp_interval;

wire [31:0]  port3_sync_interval       ;
wire [31:0]  port3_announce_interval   ;
wire [31:0]  port3_pdelay_interval     ;
wire [31:0]  port3_pdelay_resp_interval;

// 多板卡同步
wire  sync_register1;          
wire  sync_register2;          
wire  sync_register3;          
wire  sync_register4;          
wire  Test_sync_register1;     
wire  Test_sync_register2;     
wire  Test_sync_register3;     
wire  Test_sync_register4; 

wire [1:0] port0_mode;
wire [1:0] port1_mode;
wire [1:0] port2_mode;
wire [1:0] port3_mode;

wire         local_sync;  
wire         test_sync ;                  
wire  [63:0] local_time;             
wire  [63:0] test_time ;    
wire         testing;           

// OC端配置
wire  [7:0 ]  oc0_Priority1                ;
wire  [7:0 ]  oc0_clockClass               ;
wire  [7:0 ]  oc0_clockAccuracy            ;
wire  [15:0]  oc0_offsetScaledLogVariance  ;
wire  [7:0 ]  oc0_Priority2                ;
wire  [63:0]  oc0_clockIdentity            ;
wire  [7:0]   oc0_LogInterval_sync         ;
wire  [7:0]   oc0_LogInterval_pdelay       ;
wire  [7:0]   oc0_LogInterval_announce     ;
wire  [31:0]  oc0_error_time               ;
wire  [31:0]  oc0_error_type               ;

wire  [7:0 ]  oc1_Priority1                ;
wire  [7:0 ]  oc1_clockClass               ;
wire  [7:0 ]  oc1_clockAccuracy            ;
wire  [15:0]  oc1_offsetScaledLogVariance  ;
wire  [7:0 ]  oc1_Priority2                ;
wire  [63:0]  oc1_clockIdentity            ;
wire  [7:0]   oc1_LogInterval_sync         ;
wire  [7:0]   oc1_LogInterval_pdelay       ;
wire  [7:0]   oc1_LogInterval_announce     ;
wire  [31:0]  oc1_error_time               ;
wire  [31:0]  oc1_error_type               ;

wire  [7:0 ]  oc2_Priority1                ;
wire  [7:0 ]  oc2_clockClass               ;
wire  [7:0 ]  oc2_clockAccuracy            ;
wire  [15:0]  oc2_offsetScaledLogVariance  ;
wire  [7:0 ]  oc2_Priority2                ;
wire  [63:0]  oc2_clockIdentity            ;
wire  [7:0]   oc2_LogInterval_sync         ;
wire  [7:0]   oc2_LogInterval_pdelay       ;
wire  [7:0]   oc2_LogInterval_announce     ;
wire  [31:0]  oc2_error_time               ;
wire  [31:0]  oc2_error_type               ;

wire  [7:0 ]  oc3_Priority1                ;
wire  [7:0 ]  oc3_clockClass               ;
wire  [7:0 ]  oc3_clockAccuracy            ;
wire  [15:0]  oc3_offsetScaledLogVariance  ;
wire  [7:0 ]  oc3_Priority2                ;
wire  [63:0]  oc3_clockIdentity            ;
wire  [7:0]   oc3_LogInterval_sync         ;
wire  [7:0]   oc3_LogInterval_pdelay       ;
wire  [7:0]   oc3_LogInterval_announce     ;
wire  [31:0]  oc3_error_time               ;
wire  [31:0]  oc3_error_type               ;

// 错帧配置
wire          port0_wen  ;
wire  [31:0]  port0_wdata;
wire          port1_wen  ;
wire  [31:0]  port1_wdata;
wire          port2_wen  ;
wire  [31:0]  port2_wdata;
wire          port3_wen  ;
wire  [31:0]  port3_wdata;

//测试时长及测试开始标识
wire          test_start ;
wire  [31:0]  config_time;
wire          test_rst   ;

wire  [31:0]  monitior_error;
wire  [7:0]   monitior_error0;
wire  [7:0]   monitior_error1;
wire  [7:0]   monitior_error2;
wire  [7:0]   monitior_error3;

wire sync_pulse0, sync_pulse1, sync_pulse2, sync_pulse3;
// 同步脉冲
assign sync_pulse = sync_pulse0 | sync_pulse1 | sync_pulse2 | sync_pulse3;

assign monitior_error = {monitior_error0, monitior_error1, monitior_error2, monitior_error3};

// ==============================================================================
// 模块例化开始
// ==============================================================================

CPU_CFG_INTERFACE U_CPU_CFG_INTERFACE(
    .LREST                                (rst_n                                   ),
    .clk                                  (clk                                     ),

    .wen_sys                              (wen_sys                                 ),
    .waddr_sys                            (waddr_sys                               ),
    .wdata_sys                            (wdata_sys                               ),
 
    .ren_sys                              (ren_sys                                 ),
    .raddr_sys                            (raddr_sys                               ),
    .rdata_sys                            (rdata_sys                               ),
    .rvalid_sys                           (rvalid_sys                              ),

    // sync_register
    .sync_register1                       (sync_register1                          ),
    .sync_register2                       (sync_register2                          ),
    .sync_register3                       (sync_register3                          ),
    .sync_register4                       (sync_register4                          ),
    .Test_sync_register1                  (Test_sync_register1                     ),
    .Test_sync_register2                  (Test_sync_register2                     ),
    .Test_sync_register3                  (Test_sync_register3                     ),
    .Test_sync_register4                  (Test_sync_register4                     ),

    // 端口模式
    .port0_mode                           (port0_mode                              ),
    .port1_mode                           (port1_mode                              ),
    .port2_mode                           (port2_mode                              ),
    .port3_mode                           (port3_mode                              ),
    .ga_data_in                           (ga_data_in                              ),

    // OC端配置 - Port 0
    .oc0_Priority1                        (oc0_Priority1                           ), 
    .oc0_clockClass                       (oc0_clockClass                          ), 
    .oc0_clockAccuracy                    (oc0_clockAccuracy                       ), 
    .oc0_offsetScaledLogVariance          (oc0_offsetScaledLogVariance             ), 
    .oc0_Priority2                        (oc0_Priority2                           ), 
    .oc0_clockIdentity                    (oc0_clockIdentity                       ), 
    .oc0_LogInterval_sync                 (oc0_LogInterval_sync                    ), 
    .oc0_LogInterval_pdelay               (oc0_LogInterval_pdelay                  ), 
    .oc0_LogInterval_announce             (oc0_LogInterval_announce                ), 
    .oc0_error_time                       (oc0_error_time                          ),
    .oc0_error_type                       (oc0_error_type                          ),

    // OC端配置 - Port 1
    .oc1_Priority1                        (oc1_Priority1                           ), 
    .oc1_clockClass                       (oc1_clockClass                          ), 
    .oc1_clockAccuracy                    (oc1_clockAccuracy                       ), 
    .oc1_offsetScaledLogVariance          (oc1_offsetScaledLogVariance             ), 
    .oc1_Priority2                        (oc1_Priority2                           ), 
    .oc1_clockIdentity                    (oc1_clockIdentity                       ), 
    .oc1_LogInterval_sync                 (oc1_LogInterval_sync                    ), 
    .oc1_LogInterval_pdelay               (oc1_LogInterval_pdelay                  ), 
    .oc1_LogInterval_announce             (oc1_LogInterval_announce                ), 
    .oc1_error_time                       (oc1_error_time                          ),
    .oc1_error_type                       (oc1_error_type                          ),

    // OC端配置 - Port 2
    .oc2_Priority1                        (oc2_Priority1                           ), 
    .oc2_clockClass                       (oc2_clockClass                          ), 
    .oc2_clockAccuracy                    (oc2_clockAccuracy                       ), 
    .oc2_offsetScaledLogVariance          (oc2_offsetScaledLogVariance             ), 
    .oc2_Priority2                        (oc2_Priority2                           ), 
    .oc2_clockIdentity                    (oc2_clockIdentity                       ), 
    .oc2_LogInterval_sync                 (oc2_LogInterval_sync                    ), 
    .oc2_LogInterval_pdelay               (oc2_LogInterval_pdelay                  ), 
    .oc2_LogInterval_announce             (oc2_LogInterval_announce                ),
    .oc2_error_time                       (oc2_error_time                          ),
    .oc2_error_type                       (oc2_error_type                          ), 

    // OC端配置 - Port 3
    .oc3_Priority1                        (oc3_Priority1                           ), 
    .oc3_clockClass                       (oc3_clockClass                          ), 
    .oc3_clockAccuracy                    (oc3_clockAccuracy                       ), 
    .oc3_offsetScaledLogVariance          (oc3_offsetScaledLogVariance             ), 
    .oc3_Priority2                        (oc3_Priority2                           ), 
    .oc3_clockIdentity                    (oc3_clockIdentity                       ), 
    .oc3_LogInterval_sync                 (oc3_LogInterval_sync                    ), 
    .oc3_LogInterval_pdelay               (oc3_LogInterval_pdelay                  ), 
    .oc3_LogInterval_announce             (oc3_LogInterval_announce                ),
    .oc3_error_time                       (oc3_error_time                          ),
    .oc3_error_type                       (oc3_error_type                          ), 

    //端口寄存器上报
    .port0_upload_port_state              (port0_upload_port_state                 ),
    .port0_upload_sys_time_ns             (port0_upload_sys_time_ns                ),
    .port0_upload_offset                  (port0_upload_offset                     ),
    .port0_upload_delay                   (port0_upload_delay                      ),

    .port1_upload_port_state              (port1_upload_port_state                 ),
    .port1_upload_sys_time_ns             (port1_upload_sys_time_ns                ),
    .port1_upload_offset                  (port1_upload_offset                     ),
    .port1_upload_delay                   (port1_upload_delay                      ),

    .port2_upload_port_state              (port2_upload_port_state                 ),
    .port2_upload_sys_time_ns             (port2_upload_sys_time_ns                ),
    .port2_upload_offset                  (port2_upload_offset                     ),
    .port2_upload_delay                   (port2_upload_delay                      ),

    .port3_upload_port_state              (port3_upload_port_state                 ),
    .port3_upload_sys_time_ns             (port3_upload_sys_time_ns                ),
    .port3_upload_offset                  (port3_upload_offset                     ),
    .port3_upload_delay                   (port3_upload_delay                      ),

    // 帧间隔统计
    .port0_sync_interval                  (port0_sync_interval                     ),
    .port0_announce_interval              (port0_announce_interval                 ),
    .port0_pdelay_interval                (port0_pdelay_interval                   ),
    .port0_pdelay_resp_interval           (port0_pdelay_resp_interval              ),
                 
    .port1_sync_interval                  (port1_sync_interval                     ),
    .port1_announce_interval              (port1_announce_interval                 ),
    .port1_pdelay_interval                (port1_pdelay_interval                   ),
    .port1_pdelay_resp_interval           (port1_pdelay_resp_interval              ),

    .port2_sync_interval                  (port2_sync_interval                     ),
    .port2_announce_interval              (port2_announce_interval                 ),
    .port2_pdelay_interval                (port2_pdelay_interval                   ),
    .port2_pdelay_resp_interval           (port2_pdelay_resp_interval              ),

    .port3_sync_interval                  (port3_sync_interval                     ),
    .port3_announce_interval              (port3_announce_interval                 ),
    .port3_pdelay_interval                (port3_pdelay_interval                   ),
    .port3_pdelay_resp_interval           (port3_pdelay_resp_interval              ),
    
    // 错误注入配表
    .port0_wen                            (port0_wen                               ),
    .port0_wdata                          (port0_wdata                             ),  
    .port1_wen                            (port1_wen                               ),
    .port1_wdata                          (port1_wdata                             ),    
    .port2_wen                            (port2_wen                               ),
    .port2_wdata                          (port2_wdata                             ),        
    .port3_wen                            (port3_wen                               ),
    .port3_wdata                          (port3_wdata                             ),

    // 上报主机交互
    .card_upload_ren_0                    (card_upload_ren_0                       ), 
    .card_upload_flag_0                   (card_upload_flag_0                      ),
    .card_upload_ren_1                    (card_upload_ren_1                       ), 
    .card_upload_flag_1                   (card_upload_flag_1                      ),

    //测试时长及启动标识
    .test_start                           (test_start                              ),
    .config_time                          (config_time                             ),
    .test_rst                             (test_rst                                ),

    //监听错误上报
    .monitior_error                       (monitior_error                          )
);

// // 多板卡同步,暂未启用
// sync_ctrl U_sync_ctrl (
//     .clk                                  (clk                                  ),    
//     .rst_n                                (rst_n                                ),
//     .test_rst                             (test_rst                             ), 
//     .restart_sync                         (restart_sync                         ), 
//     .pulse                                (pulse                                ),
//     .sync_register1                       (sync_register1                       ),
//     .sync_register2                       (sync_register2                       ),
//     .sync_register3                       (sync_register3                       ),
//     .sync_register4                       (sync_register4                       ),
//     .Test_sync_register1                  (Test_sync_register1                  ),
//     .Test_sync_register2                  (Test_sync_register2                  ),
//     .Test_sync_register3                  (Test_sync_register3                  ),
//     .Test_sync_register4                  (Test_sync_register4                  ),
//     .local_sync                           (local_sync                           ),
//     .local_time                           (local_time                           ),
//     .test_sync                            (test_sync                            )
// );

// 轮询上报
upload_info_arbiter u_upload_info_arbiter (
    .clk                                  (clk                                     ),
    .rst_n                                (rst_n                                   ),
    // 四个FIFO数据与状态输入
    .fifo_data0                           (upload_frame_info0                      ),
    .fifo_data1                           (upload_frame_info1                      ),
    .fifo_data2                           (upload_frame_info2                      ),
    .fifo_data3                           (upload_frame_info3                      ),
    .fifo_empty0                          (frame_info_empty0                       ),
    .fifo_empty1                          (frame_info_empty1                       ),
    .fifo_empty2                          (frame_info_empty2                       ),
    .fifo_empty3                          (frame_info_empty3                       ),
    // 四个FIFO的读使能输出                
    .fifo_rd_en0                          (frame_info_rd_en0                       ),
    .fifo_rd_en1                          (frame_info_rd_en1                       ),
    .fifo_rd_en2                          (frame_info_rd_en2                       ),
    .fifo_rd_en3                          (frame_info_rd_en3                       ),
    // AXI-Stream输出接口（连接到 XDMA C2H）
    .m_axis_tready                        (s_axis_c2h_tready_1                     ),
    .m_axis_tdata_bigend                  (s_axis_c2h_tdata_1                      ),
    .m_axis_tvalid                        (s_axis_c2h_tvalid_1                     ),
    .m_axis_tkeep                         (s_axis_c2h_tkeep_1                      ),
    .m_axis_tlast                         (s_axis_c2h_tlast_1                      ),
    .card_upload_ren                      (card_upload_ren_0                       ),
    .card_upload_flag                     (card_upload_flag_0                      )
);          

// ==============================================================================
// Port 0 同步测试模块
// ==============================================================================
port_sync_test port0_sync_test(
    .clk                                  (clk                                     ),
    .rst_n                                (rst_n                                   ),
    .port_num                             (2'b00                                   ),        
    .gmii_rxd                             (gmii_rxd0                               ),
    .gmii_rx_en                           (gmii_rx_en0                             ),
    .gmii_txd                             (gmii_txd0                               ),
    .gmii_tx_en                           (gmii_tx_en0                             ),
    .port_en                              (port0_en                                ),
    .port_mode                            (port0_mode                              ),
    .port_reset                           (port0_reset                             ),
    .port_test_done                       (port0_test_done                         ),
    .test_time                            (test_time                               ),
    .testing                              (testing                                 ),
    .test_rst                             (test_rst                                ),   
    // 表项管理
    .port_wen                             (port0_wen                               ),
    .port_wdata                           (port0_wdata                             ),
    // OC端配置
    .oc_Priority1                         (oc0_Priority1                           ),
    .oc_clockClass                        (oc0_clockClass                          ),
    .oc_clockAccuracy                     (oc0_clockAccuracy                       ),
    .oc_offsetScaledLogVariance           (oc0_offsetScaledLogVariance             ),
    .oc_Priority2                         (oc0_Priority2                           ),
    .oc_clockIdentity                     (oc0_clockIdentity                       ),
    .oc_LogInterval_sync                  (oc0_LogInterval_sync                    ),
    .oc_LogInterval_pdelay                (oc0_LogInterval_pdelay                  ),
    .oc_LogInterval_announce              (oc0_LogInterval_announce                ),
    .oc_error_time                        (oc0_error_time                          ),
    .oc_error_type                        (oc0_error_type                          ),
    // 同步脉冲
    .sync_pulse                           (sync_pulse0                             ),
    // 接收帧信息上报
    .frame_info_rd_en                     (frame_info_rd_en0                       ),
    .frame_info_empty                     (frame_info_empty0                       ),
    .upload_frame_info                    (upload_frame_info0                      ),
    // OC寄存器上报
    .upload_port_state                    (port0_upload_port_state                 ), 
    .upload_sys_time_ns                   (port0_upload_sys_time_ns                ), 
    .upload_offset                        (port0_upload_offset                     ),      
    .upload_delay                         (port0_upload_delay                      ),
    //监听错误上报
    .monitior_error                       (monitior_error0                         ),
    // 帧时间间隔上报
    .sync_interval                        (port0_sync_interval                     ),
    .announce_interval                    (port0_announce_interval                 ),
    .pdelay_interval                      (port0_pdelay_interval                   ),
    .pdelay_resp_interval                 (port0_pdelay_resp_interval              ),
    // 时间戳
    .timestamp_tx_Pdelay_valid_cdc        (timestamp_tx_Pdelay_valid_cdc[0]        ),
    .timestamp_tx_Sync_valid_cdc          (timestamp_tx_Sync_valid_cdc[0]          ),
    .timestamp_tx_Presp_valid_cdc         (timestamp_tx_Presp_valid_cdc[0]         ),
    .timestamp_rx_Pdelay_valid_cdc        (timestamp_rx_Pdelay_valid_cdc[0]        ),
    .timestamp_rx_Sync_valid_cdc          (timestamp_rx_Sync_valid_cdc[0]          ),
    .timestamp_rx_Presp_valid_cdc         (timestamp_rx_Presp_valid_cdc[0]         ),
    .timestamp_rx_Sync_follow_valid_cdc   (timestamp_rx_Sync_follow_valid_cdc[0]   ),
    .timestamp_rx_Presp_follow_valid_cdc  (timestamp_rx_Presp_follow_valid_cdc[0]  ),
    .timestamp_rx_Announce_valid_cdc      (timestamp_rx_Announce_valid_cdc[0]      )
);

// ==============================================================================
// Port 1 同步测试模块
// ==============================================================================
port_sync_test port1_sync_test(
    .clk                                  (clk                                     ),
    .rst_n                                (rst_n                                   ),
    .port_num                             (2'b01                                   ),        
    .gmii_rxd                             (gmii_rxd1                               ),
    .gmii_rx_en                           (gmii_rx_en1                             ),
    .gmii_txd                             (gmii_txd1                               ),
    .gmii_tx_en                           (gmii_tx_en1                             ),
    .port_en                              (port1_en                                ),
    .port_mode                            (port1_mode                              ),
    .port_reset                           (port1_reset                             ),
    .port_test_done                       (port1_test_done                         ),
    .test_time                            (test_time                               ),
    .testing                              (testing                                 ),
    .test_rst                             (test_rst                                ),  
    // 表项管理
    .port_wen                             (port1_wen                               ),
    .port_wdata                           (port1_wdata                             ),
    // OC端配置
    .oc_Priority1                         (oc1_Priority1                           ),
    .oc_clockClass                        (oc1_clockClass                          ),
    .oc_clockAccuracy                     (oc1_clockAccuracy                       ),
    .oc_offsetScaledLogVariance           (oc1_offsetScaledLogVariance             ),
    .oc_Priority2                         (oc1_Priority2                           ),
    .oc_clockIdentity                     (oc1_clockIdentity                       ),
    .oc_LogInterval_sync                  (oc1_LogInterval_sync                    ),
    .oc_LogInterval_pdelay                (oc1_LogInterval_pdelay                  ),
    .oc_LogInterval_announce              (oc1_LogInterval_announce                ),
    .oc_error_time                        (oc1_error_time                          ),
    .oc_error_type                        (oc1_error_type                          ),
    // 同步脉冲
    .sync_pulse                           (sync_pulse1                             ),
    // 接收帧信息上报
    .frame_info_rd_en                     (frame_info_rd_en1                       ),
    .frame_info_empty                     (frame_info_empty1                       ),
    .upload_frame_info                    (upload_frame_info1                      ),
    // OC寄存器上报
    .upload_port_state                    (port1_upload_port_state                 ), 
    .upload_sys_time_ns                   (port1_upload_sys_time_ns                ), 
    .upload_offset                        (port1_upload_offset                     ),      
    .upload_delay                         (port1_upload_delay                      ),
    // 帧时间间隔上报
    .sync_interval                        (port1_sync_interval                     ),
    .announce_interval                    (port1_announce_interval                 ),
    .pdelay_interval                      (port1_pdelay_interval                   ),
    .pdelay_resp_interval                 (port1_pdelay_resp_interval              ),
    //监听错误上报
    .monitior_error                       (monitior_error1                         ),
    // 时间戳
    .timestamp_tx_Pdelay_valid_cdc        (timestamp_tx_Pdelay_valid_cdc[1]        ),
    .timestamp_tx_Sync_valid_cdc          (timestamp_tx_Sync_valid_cdc[1]          ),
    .timestamp_tx_Presp_valid_cdc         (timestamp_tx_Presp_valid_cdc[1]         ),
    .timestamp_rx_Pdelay_valid_cdc        (timestamp_rx_Pdelay_valid_cdc[1]        ),
    .timestamp_rx_Sync_valid_cdc          (timestamp_rx_Sync_valid_cdc[1]          ),
    .timestamp_rx_Presp_valid_cdc         (timestamp_rx_Presp_valid_cdc[1]         ),
    .timestamp_rx_Sync_follow_valid_cdc   (timestamp_rx_Sync_follow_valid_cdc[1]   ),
    .timestamp_rx_Presp_follow_valid_cdc  (timestamp_rx_Presp_follow_valid_cdc[1]  ),
    .timestamp_rx_Announce_valid_cdc      (timestamp_rx_Announce_valid_cdc[1]      )
);

// ==============================================================================
// Port 2 同步测试模块
// ==============================================================================
port_sync_test port2_sync_test(
    .clk                                  (clk                                     ),
    .rst_n                                (rst_n                                   ),
    .port_num                             (2'b10                                   ),        
    .gmii_rxd                             (gmii_rxd2                               ),
    .gmii_rx_en                           (gmii_rx_en2                             ),
    .gmii_txd                             (gmii_txd2                               ),
    .gmii_tx_en                           (gmii_tx_en2                             ),
    .port_en                              (port2_en                                ),
    .port_mode                            (port2_mode                              ),
    .port_reset                           (port2_reset                             ),
    .port_test_done                       (port2_test_done                         ),
    .test_time                            (test_time                               ),
    .testing                              (testing                                 ),
    .test_rst                             (test_rst                                ),  
    // 表项管理
    .port_wen                             (port2_wen                               ),
    .port_wdata                           (port2_wdata                             ),
    // OC端配置
    .oc_Priority1                         (oc2_Priority1                           ),
    .oc_clockClass                        (oc2_clockClass                          ),
    .oc_clockAccuracy                     (oc2_clockAccuracy                       ),
    .oc_offsetScaledLogVariance           (oc2_offsetScaledLogVariance             ),
    .oc_Priority2                         (oc2_Priority2                           ),
    .oc_clockIdentity                     (oc2_clockIdentity                       ),
    .oc_LogInterval_sync                  (oc2_LogInterval_sync                    ),
    .oc_LogInterval_pdelay                (oc2_LogInterval_pdelay                  ),
    .oc_LogInterval_announce              (oc2_LogInterval_announce                ),
    .oc_error_time                        (oc2_error_time                          ),
    .oc_error_type                        (oc2_error_type                          ),
    // 同步脉冲
    .sync_pulse                           (sync_pulse2                             ),
    // 接收帧信息上报
    .frame_info_rd_en                     (frame_info_rd_en2                       ),
    .frame_info_empty                     (frame_info_empty2                       ),
    .upload_frame_info                    (upload_frame_info2                      ),
    // OC寄存器上报
    .upload_port_state                    (port2_upload_port_state                 ), 
    .upload_sys_time_ns                   (port2_upload_sys_time_ns                ), 
    .upload_offset                        (port2_upload_offset                     ),      
    .upload_delay                         (port2_upload_delay                      ),
    // 帧时间间隔上报
    .sync_interval                        (port2_sync_interval                     ),
    .announce_interval                    (port2_announce_interval                 ),
    .pdelay_interval                      (port2_pdelay_interval                   ),
    .pdelay_resp_interval                 (port2_pdelay_resp_interval              ),
    //监听错误上报
    .monitior_error                       (monitior_error2                         ),
    // 时间戳
    .timestamp_tx_Pdelay_valid_cdc        (timestamp_tx_Pdelay_valid_cdc[2]        ),
    .timestamp_tx_Sync_valid_cdc          (timestamp_tx_Sync_valid_cdc[2]          ),
    .timestamp_tx_Presp_valid_cdc         (timestamp_tx_Presp_valid_cdc[2]         ),
    .timestamp_rx_Pdelay_valid_cdc        (timestamp_rx_Pdelay_valid_cdc[2]        ),
    .timestamp_rx_Sync_valid_cdc          (timestamp_rx_Sync_valid_cdc[2]          ),
    .timestamp_rx_Presp_valid_cdc         (timestamp_rx_Presp_valid_cdc[2]         ),
    .timestamp_rx_Sync_follow_valid_cdc   (timestamp_rx_Sync_follow_valid_cdc[2]   ),
    .timestamp_rx_Presp_follow_valid_cdc  (timestamp_rx_Presp_follow_valid_cdc[2]  ),
    .timestamp_rx_Announce_valid_cdc      (timestamp_rx_Announce_valid_cdc[2]      )
);

// ==============================================================================
// Port 3 同步测试模块
// ==============================================================================
port_sync_test port3_sync_test(
    .clk                                  (clk                                     ),
    .rst_n                                (rst_n                                   ),
    .port_num                             (2'b11                                   ),        
    .gmii_rxd                             (gmii_rxd3                               ),
    .gmii_rx_en                           (gmii_rx_en3                             ),
    .gmii_txd                             (gmii_txd3                               ),
    .gmii_tx_en                           (gmii_tx_en3                             ),
    .port_en                              (port3_en                                ),
    .port_mode                            (port3_mode                              ),
    .port_reset                           (port3_reset                             ),
    .port_test_done                       (port3_test_done                         ),
    .test_time                            (test_time                               ),
    .testing                              (testing                                 ),
    .test_rst                             (test_rst                                ),  
    // 表项管理
    .port_wen                             (port3_wen                               ),
    .port_wdata                           (port3_wdata                             ),
    // OC端配置
    .oc_Priority1                         (oc3_Priority1                           ),
    .oc_clockClass                        (oc3_clockClass                          ),
    .oc_clockAccuracy                     (oc3_clockAccuracy                       ),
    .oc_offsetScaledLogVariance           (oc3_offsetScaledLogVariance             ),
    .oc_Priority2                         (oc3_Priority2                           ),
    .oc_clockIdentity                     (oc3_clockIdentity                       ),
    .oc_LogInterval_sync                  (oc3_LogInterval_sync                    ),
    .oc_LogInterval_pdelay                (oc3_LogInterval_pdelay                  ),
    .oc_LogInterval_announce              (oc3_LogInterval_announce                ),
    .oc_error_time                        (oc3_error_time                          ),
    .oc_error_type                        (oc3_error_type                          ),
    // 同步脉冲
    .sync_pulse                           (sync_pulse3                             ),
    // 接收帧信息上报
    .frame_info_rd_en                     (frame_info_rd_en3                       ),
    .frame_info_empty                     (frame_info_empty3                       ),
    .upload_frame_info                    (upload_frame_info3                      ),
    // OC寄存器上报
    .upload_port_state                    (port3_upload_port_state                 ), 
    .upload_sys_time_ns                   (port3_upload_sys_time_ns                ), 
    .upload_offset                        (port3_upload_offset                     ),      
    .upload_delay                         (port3_upload_delay                      ),
    // 帧时间间隔上报
    .sync_interval                        (port3_sync_interval                     ),
    .announce_interval                    (port3_announce_interval                 ),
    .pdelay_interval                      (port3_pdelay_interval                   ),
    .pdelay_resp_interval                 (port3_pdelay_resp_interval              ),
    //监听错误上报
    .monitior_error                       (monitior_error3                         ),
    // 时间戳
    .timestamp_tx_Pdelay_valid_cdc        (timestamp_tx_Pdelay_valid_cdc[3]        ),
    .timestamp_tx_Sync_valid_cdc          (timestamp_tx_Sync_valid_cdc[3]          ),
    .timestamp_tx_Presp_valid_cdc         (timestamp_tx_Presp_valid_cdc[3]         ),
    .timestamp_rx_Pdelay_valid_cdc        (timestamp_rx_Pdelay_valid_cdc[3]        ),
    .timestamp_rx_Sync_valid_cdc          (timestamp_rx_Sync_valid_cdc[3]          ),
    .timestamp_rx_Presp_valid_cdc         (timestamp_rx_Presp_valid_cdc[3]         ),
    .timestamp_rx_Sync_follow_valid_cdc   (timestamp_rx_Sync_follow_valid_cdc[3]   ),
    .timestamp_rx_Presp_follow_valid_cdc  (timestamp_rx_Presp_follow_valid_cdc[3]  ),
    .timestamp_rx_Announce_valid_cdc      (timestamp_rx_Announce_valid_cdc[3]      )
);

// 测试时间生成模块
test_time_gen U_test_time_gen(
    .clk                                  (clk                                     ),       
    .rst_n                                (rst_n & !test_rst                       ),    
    .test_start                           (test_start                              ), // 需确认顶层是否有声明
    .config_time                          (config_time                             ), // 需确认顶层是否有声明
    .test_time                            (test_time                               ), 
    .testing                              (testing                                 )    
);

// ILA Debug 模块
`ifdef DEBUG
ila_ren_flag u_ila_ren_flag (
    .clk                                  (clk                                     ), // input wire clk
    .probe0                               (card_upload_ren_0                       ), // input wire [0:0]  probe0  
    .probe1                               (card_upload_flag_0                      ), // input wire [0:0]  probe1 
    .probe2                               (card_upload_ren_1                       ), // input wire [0:0]  probe2 
    .probe3                               (card_upload_flag_1                      )  // input wire [0:0]  probe3
);
`endif

endmodule