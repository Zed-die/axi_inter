`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: wanghaoyu
// 
// Create Date: 2025/04/24 17:03:28
// Design Name: 
// Module Name: Pdelay_analysis
// Project Name: gPTP/802.1AS Tester
// Description: Pdelay_Req帧深度解析与一致性校验模块
//              集成了 Sequence ID 校验、报文格式规范校验及 32-bit error_code 上报
//////////////////////////////////////////////////////////////////////////////////

module Pdelay_analysis(
    input                   clk                 ,
    input                   rst_n               ,
    input       [7:0]       data_i              ,
    input                   valid_i             ,
    input       [1:0]       port_num            ,

    output reg  [15:0]      MsgLength           ,
    output reg  [7:0]       DomainNumber        ,
    output reg  [15:0]      FlagField           ,
    output reg  [63:0]      CorrectionField     ,
    output reg  [79:0]      sourcePortIdentity  ,
    output reg  [15:0]      SequenceID          ,
    output reg  [7:0]       ControlField        ,
    output reg  [7:0]       logMessage          ,
    output                  message_valid       ,
    output reg  [383:0]     upload_message      ,
    output reg              upload_message_valid,
    
    //时间戳
    input      [1:0 ]       port_mode           ,
    input      [63:0]       test_time           , 
    input      [63:0]       sys_time            ,  
    input                   timestamp_rx_Pdelay_valid_cdc        
);

// ==============================================================================
// 全局 error_code 位映射定义 (Pdelay_Req相关部分)
// ==============================================================================
localparam BIT_ERR_MSG_LENGTH       = 5'd2;
localparam BIT_ERR_DOMAIN_NUM       = 5'd4;
localparam BIT_ERR_CONTROL_FIELD    = 5'd6;
localparam BIT_ERR_PDELAY_SEQ_JUMP  = 5'd12; // Pdelay_Req 序列号跳变
localparam BIT_ERR_PDELAY_SEQ_RPT   = 5'd13; // Pdelay_Req 序列号重复
localparam BIT_ERR_CORRECTION       = 5'd25; // 修正域错误

// ==============================================================================
// 内部信号定义
// ==============================================================================
reg [7:0]  cnt;   
reg [63:0] timestamp_rx_Pdelay;
assign message_valid = (cnt == 32) ? 1'b1 : 1'b0;

reg [15:0] last_sequence_id;
reg        first_packet    ;
reg        verify_done     ;    
reg [31:0] error_code      ; // 新增：统合错误码寄存器

// 字节流计数
always @(posedge clk or negedge rst_n) begin
    if(!rst_n)
        cnt <= 8'b0;
    else if(!valid_i)
        cnt <= 8'b0;
    else
        cnt <= cnt + 1'b1;
end

// 报文提取 (保持原有提取逻辑)
always @(posedge clk or negedge rst_n) begin
    if(!rst_n)begin
        MsgLength          <= 16'b0;
        DomainNumber       <= 8'b0;
        FlagField          <= 16'b0;
        CorrectionField    <= 64'b0;
        sourcePortIdentity <= 80'b0;
        SequenceID         <= 16'b0;
        ControlField       <= 8'b0;
        logMessage         <= 8'b0; 
    end
    else begin
        case(cnt)
            8'd0:  MsgLength[15:8]            <= data_i;
            8'd1:  MsgLength[7:0]             <= data_i;
            8'd2:  DomainNumber               <= data_i;
            8'd4:  FlagField[15:8]            <= data_i;
            8'd5:  FlagField[7:0]             <= data_i;
            8'd6:  CorrectionField[63:56]     <= data_i;
            8'd7:  CorrectionField[55:48]     <= data_i;
            8'd8:  CorrectionField[47:40]     <= data_i;
            8'd9:  CorrectionField[39:32]     <= data_i;
            8'd10: CorrectionField[31:24]     <= data_i;
            8'd11: CorrectionField[23:16]     <= data_i;
            8'd12: CorrectionField[15:8]      <= data_i;
            8'd13: CorrectionField[7:0]       <= data_i;
            8'd18: sourcePortIdentity[79:72]  <= data_i;
            8'd19: sourcePortIdentity[71:64]  <= data_i;
            8'd20: sourcePortIdentity[63:56]  <= data_i;
            8'd21: sourcePortIdentity[55:48]  <= data_i;
            8'd22: sourcePortIdentity[47:40]  <= data_i;
            8'd23: sourcePortIdentity[39:32]  <= data_i;
            8'd24: sourcePortIdentity[31:24]  <= data_i;
            8'd25: sourcePortIdentity[23:16]  <= data_i;
            8'd26: sourcePortIdentity[15:8 ]  <= data_i;
            8'd27: sourcePortIdentity[7:0  ]  <= data_i;
            8'd28: SequenceID[15:8]           <= data_i;
            8'd29: SequenceID[7:0]            <= data_i;
            8'd30: ControlField               <= data_i;
            8'd31: logMessage                 <= data_i;
            default:begin
                MsgLength          <=  MsgLength          ;
                DomainNumber       <=  DomainNumber       ;
                FlagField          <=  FlagField          ;
                CorrectionField    <=  CorrectionField    ;
                sourcePortIdentity <=  sourcePortIdentity ;
                SequenceID         <=  SequenceID         ;
                ControlField       <=  ControlField       ;
                logMessage         <=  logMessage         ;
            end
        endcase
    end
end

// 接收帧时戳
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        timestamp_rx_Pdelay <= 64'b0;
    end 
    else if (timestamp_rx_Pdelay_valid_cdc) begin
        if(port_mode == 2'b10)
            timestamp_rx_Pdelay <= sys_time;
        else
            timestamp_rx_Pdelay <= test_time;
    end
    else
        timestamp_rx_Pdelay <= timestamp_rx_Pdelay;
end

// ==============================================================================
// 深度解析：统合生成 32-bit error_code (针对 Pdelay_Req 规则)
// ==============================================================================
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        last_sequence_id <= 16'd0;
        first_packet     <= 1'b1;
        error_code       <= 32'd0;
    end else if (message_valid) begin
        
        error_code <= 32'd0; 
        
        // 1. Sequence ID 校验 (连续性)
        if (first_packet) begin
            last_sequence_id <= SequenceID;
            first_packet     <= 1'b0;
        end else begin
            if (SequenceID == last_sequence_id) begin
                error_code[BIT_ERR_PDELAY_SEQ_RPT]  <= 1'b1;
            end else if (SequenceID != last_sequence_id + 1'b1) begin
                error_code[BIT_ERR_PDELAY_SEQ_JUMP] <= 1'b1;
            end
            last_sequence_id <= SequenceID;
        end
        
        // 2. 格式与协议一致性校验 (Pdelay_Req 专属)
        error_code[BIT_ERR_MSG_LENGTH]    <= (MsgLength != 16'd54);       // Pdelay_Req 总长度为 54
        error_code[BIT_ERR_DOMAIN_NUM]    <= (DomainNumber != 8'd0);      // 默认 802.1AS 域为 0
        error_code[BIT_ERR_CONTROL_FIELD] <= (ControlField != 8'd5);      // Pdelay_Req 控制域必须为 0x05
        error_code[BIT_ERR_CORRECTION]    <= (CorrectionField != 64'd0);  // 规范下发出的 Pdelay_Req 修正域应为 0
        
    end
end

// 校验完成信号生成
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) 
        verify_done   <= 1'b0;
    else 
        verify_done   <= message_valid;
end

// ==============================================================================
// 组装上报报文
// ==============================================================================
// verify: 只要 error_code 非 0，即标记为异常 (2'b10)
wire [1:0] verify;
assign verify = (error_code != 32'd0) ? 2'b10 : 2'b01;

always @(posedge clk or negedge rst_n)begin
    if (!rst_n) begin
        upload_message       <= 384'b0;
        upload_message_valid <= 1'b0;
    end else if (verify_done) begin
        // MsgType (Pdelay_Req 为 4'h2), 将 error_code 拼入
        upload_message       <= {port_num, verify, 4'h2, DomainNumber, FlagField, 
                                 CorrectionField, sourcePortIdentity, SequenceID, 
                                 ControlField, logMessage, 80'b0, error_code, timestamp_rx_Pdelay};
        upload_message_valid <= 1'b1;
    end
    else begin
        upload_message       <= 384'b0;
        upload_message_valid <= 1'b0;
    end
end
endmodule