`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/07/08 14:27:26
// Design Name: 
// Module Name: upload_frame
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module upload_frame(
    input          clk,
    input          rst_n,
    input [1:0]    port_num,

    input [7:0]    rxd_to_test  ,
    input          rx_en_to_test,
    
    input          frame_info_rd_en ,
    output         frame_info_empty ,
    output [383:0] upload_frame_info,

    //时间戳
    input  [1:0 ]  port_mode        ,
    input  [63:0]  test_time        , 
    input  [63:0]  sys_time         ,  
    input          timestamp_rx_Pdelay_valid_cdc      ,
    input          timestamp_rx_Sync_valid_cdc        ,
    input          timestamp_rx_Presp_valid_cdc       ,
    input          timestamp_rx_Sync_follow_valid_cdc ,
    input          timestamp_rx_Presp_follow_valid_cdc,
    input          timestamp_rx_Announce_valid_cdc    
    
    );


wire [383:0] upload_message      ;     
wire         upload_message_valid;

wire frame_info_full;

frame_analysis U_frame_analysis(
    .clk                                (clk                                ),
    .rst_n                              (rst_n                              ),
    .port_num                           (port_num                           ), 
    .data_i                             (rxd_to_test                        ),
    .valid_i                            (rx_en_to_test                      ),
    
    .upload_message                     (upload_message                     ),
    .upload_message_valid               (upload_message_valid               ),
    .port_mode                          (port_mode                          ),
    .test_time                          (test_time                          ),
    .sys_time                           (sys_time                           ),
    .timestamp_rx_Pdelay_valid_cdc      (timestamp_rx_Pdelay_valid_cdc      ),
    .timestamp_rx_Sync_valid_cdc        (1'b1                               ),
    .timestamp_rx_Presp_valid_cdc       (timestamp_rx_Presp_valid_cdc       ),
    .timestamp_rx_Sync_follow_valid_cdc (timestamp_rx_Sync_follow_valid_cdc ),
    .timestamp_rx_Presp_follow_valid_cdc(timestamp_rx_Presp_follow_valid_cdc),
    .timestamp_rx_Announce_valid_cdc    (timestamp_rx_Announce_valid_cdc    )
);

frame_info U_frame_info(
    .clk(clk),      // input wire clk
    .rst(~rst_n),      // input wire rst
    .din(upload_message),      // input wire [383 : 0] din
    .wr_en(upload_message_valid && !frame_info_full),  // input wire wr_en
    .rd_en(frame_info_rd_en),  // input wire rd_en
    .dout(upload_frame_info),    // output wire [383 : 0] dout
    .full(frame_info_full),    // output wire full
    .empty(frame_info_empty)  // output wire empty
);

endmodule
