`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: wanghaoyu
// 
// Create Date: 2025/04/24 17:03:28
// Design Name: 
// Module Name: Announce_analysis
// Project Name: gPTP/802.1AS Tester
// Description: Announce帧深度解析与一致性校验模块
//              提取 BMCA 关键属性字段，并统合 32-bit error_code 状态上报
//////////////////////////////////////////////////////////////////////////////////

module Announce_analysis(
    input                   clk                 ,
    input                   rst_n               ,
    input       [7:0]       data_i              ,
    input                   valid_i             ,
    input       [1:0]       port_num            ,

    output reg  [15:0]      MsgLength           ,
    output reg  [7:0]       DomainNumber        ,
    output reg  [15:0]      FlagField           ,
    output reg  [63:0]      CorrectionField     ,
    output reg  [79:0]      sourcePortIdentity  ,
    output reg  [15:0]      SequenceID          ,
    output reg  [7:0]       ControlField        ,
    output reg  [7:0]       logMessage          ,

    // BMCA 专属状态机字段
    output reg  [15:0]      Message_currentUtcOffset        ,
    output reg  [7:0]       Message_Priority1               ,        
    output reg  [7:0]       Message_clockClass              ,       
    output reg  [7:0]       Message_clockAccuracy           ,    
    output reg  [15:0]      Message_offsetScaledLogVariance ,   
    output reg  [7:0]       Message_Priority2               ,        
    output reg  [63:0]      Message_clockIdentity           ,  
    output reg  [15:0]      Message_stepsRemoved            ,
    output reg  [7:0]       Message_timeSource              ,

    output                  message_valid       ,
    output reg  [383:0]     upload_message      ,
    output reg              upload_message_valid,
    
    //时间戳
    input      [1:0 ]       port_mode           ,
    input      [63:0]       test_time           , 
    input      [63:0]       sys_time            ,  
    input                   timestamp_rx_Announce_valid_cdc  
);

// ==============================================================================
// 全局 error_code 位映射定义 (Announce相关部分)
// ==============================================================================
localparam BIT_ERR_MSG_LENGTH       = 5'd2;
localparam BIT_ERR_DOMAIN_NUM       = 5'd4;
localparam BIT_ERR_CONTROL_FIELD    = 5'd6;
localparam BIT_ERR_ANNC_SEQ_JUMP    = 5'd21; // Announce 序列号跳变 (独立位防冲突)
localparam BIT_ERR_ANNC_SEQ_RPT     = 5'd22; // Announce 序列号重复 (独立位防冲突)
localparam BIT_ERR_CORRECTION       = 5'd25; // 修正域错误

// ==============================================================================
// 内部信号定义
// ==============================================================================
reg [7:0]  cnt;
reg [63:0] timestamp_rx_Announce;
assign message_valid = (cnt == 62) ? 1'b1 : 1'b0;

reg [15:0] last_sequence_id;
reg        first_packet    ;
reg        verify_done     ;
reg [31:0] error_code      ; // 新增：统合错误码寄存器

// 字节流计数
always @(posedge clk or negedge rst_n) begin
    if(!rst_n)
        cnt <= 8'b0;
    else if(!valid_i)
        cnt <= 8'b0;
    else
        cnt <= cnt + 1'b1;
end

// 报文提取 (保持原有全部逻辑)
always @(posedge clk or negedge rst_n) begin
    if(!rst_n)begin
        MsgLength                       <= 16'b0;
        DomainNumber                    <= 8'b0 ;
        FlagField                       <= 16'b0;
        CorrectionField                 <= 64'b0;
        sourcePortIdentity              <= 80'b0;
        SequenceID                      <= 16'b0;
        ControlField                    <= 8'b0 ;
        logMessage                      <= 8'b0 ; 
        Message_currentUtcOffset        <= 16'b0;
        Message_Priority1               <= 8'b0 ;
        Message_clockClass              <= 8'b0 ;
        Message_clockAccuracy           <= 8'b0 ;
        Message_offsetScaledLogVariance <= 16'b0;
        Message_Priority2               <= 8'b0 ;
        Message_clockIdentity           <= 64'b0;
        Message_stepsRemoved            <= 16'b0;
        Message_timeSource              <= 8'b0 ;
    end
    else begin
        case(cnt)
            8'd0:  MsgLength[15:8]                               <= data_i;
            8'd1:  MsgLength[7:0]                                <= data_i;
            8'd2:  DomainNumber                                  <= data_i;
            8'd4:  FlagField[15:8]                               <= data_i;
            8'd5:  FlagField[7:0]                                <= data_i;
            8'd6:  CorrectionField[63:56]                        <= data_i;
            8'd7:  CorrectionField[55:48]                        <= data_i;
            8'd8:  CorrectionField[47:40]                        <= data_i;
            8'd9:  CorrectionField[39:32]                        <= data_i;
            8'd10: CorrectionField[31:24]                        <= data_i;
            8'd11: CorrectionField[23:16]                        <= data_i;
            8'd12: CorrectionField[15:8]                         <= data_i;
            8'd13: CorrectionField[7:0]                          <= data_i;
            8'd18: sourcePortIdentity[79:72]                     <= data_i;
            8'd19: sourcePortIdentity[71:64]                     <= data_i;
            8'd20: sourcePortIdentity[63:56]                     <= data_i;
            8'd21: sourcePortIdentity[55:48]                     <= data_i;
            8'd22: sourcePortIdentity[47:40]                     <= data_i;
            8'd23: sourcePortIdentity[39:32]                     <= data_i;
            8'd24: sourcePortIdentity[31:24]                     <= data_i;
            8'd25: sourcePortIdentity[23:16]                     <= data_i;
            8'd26: sourcePortIdentity[15:8 ]                     <= data_i;
            8'd27: sourcePortIdentity[7:0  ]                     <= data_i;
            8'd28: SequenceID[15:8]                              <= data_i;
            8'd29: SequenceID[7:0]                               <= data_i;
            8'd30: ControlField                                  <= data_i;
            8'd31: logMessage                                    <= data_i;
            8'd42: Message_currentUtcOffset[15:8]                <= data_i;
            8'd43: Message_currentUtcOffset[7:0]                 <= data_i;
            8'd45: Message_Priority1                             <= data_i;
            8'd46: Message_clockClass                            <= data_i;
            8'd47: Message_clockAccuracy                         <= data_i;
            8'd48: Message_offsetScaledLogVariance[15:8]         <= data_i;
            8'd49: Message_offsetScaledLogVariance[7:0]          <= data_i;
            8'd50: Message_Priority2                             <= data_i;
            8'd51: Message_clockIdentity[63:56]                  <= data_i;
            8'd52: Message_clockIdentity[55:48]                  <= data_i;
            8'd53: Message_clockIdentity[47:40]                  <= data_i;
            8'd54: Message_clockIdentity[39:32]                  <= data_i;
            8'd55: Message_clockIdentity[31:24]                  <= data_i;
            8'd56: Message_clockIdentity[23:16]                  <= data_i;
            8'd57: Message_clockIdentity[15:8]                   <= data_i;
            8'd58: Message_clockIdentity[7:0]                    <= data_i;
            8'd59: Message_stepsRemoved[15:8]                    <= data_i;
            8'd60: Message_stepsRemoved[7:0]                     <= data_i;
            8'd61: Message_timeSource                            <= data_i;
            default:begin
                MsgLength                       <= MsgLength                      ;
                DomainNumber                    <= DomainNumber                   ;
                FlagField                       <= FlagField                      ;
                CorrectionField                 <= CorrectionField                ;
                sourcePortIdentity              <= sourcePortIdentity             ;
                SequenceID                      <= SequenceID                     ;
                ControlField                    <= ControlField                   ;
                logMessage                      <= logMessage                     ;
                Message_currentUtcOffset        <= Message_currentUtcOffset       ;
                Message_Priority1               <= Message_Priority1              ;
                Message_clockClass              <= Message_clockClass             ;
                Message_clockAccuracy           <= Message_clockAccuracy          ;
                Message_offsetScaledLogVariance <= Message_offsetScaledLogVariance;
                Message_Priority2               <= Message_Priority2              ;
                Message_clockIdentity           <= Message_clockIdentity          ;
                Message_stepsRemoved            <= Message_stepsRemoved           ;
                Message_timeSource              <= Message_timeSource             ;
            end
        endcase
    end
end

// 接收帧时戳
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        timestamp_rx_Announce <= 64'b0;
    end 
    else if (timestamp_rx_Announce_valid_cdc) begin
        if(port_mode == 2'b10)
            timestamp_rx_Announce <= sys_time;
        else
            timestamp_rx_Announce <= test_time;
    end
end

// ==============================================================================
// 深度解析：统合生成 32-bit error_code (针对 Announce 规则)
// ==============================================================================
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        last_sequence_id <= 16'd0;
        first_packet     <= 1'b1;
        error_code       <= 32'd0;
    end else if (message_valid) begin
        
        error_code <= 32'd0; 
        
        // 1. Sequence ID 校验 (连续性)
        if (first_packet) begin
            last_sequence_id <= SequenceID;
            first_packet     <= 1'b0;
        end else begin
            if (SequenceID == last_sequence_id) begin
                error_code[BIT_ERR_ANNC_SEQ_RPT]  <= 1'b1;
            end else if (SequenceID != last_sequence_id + 1'b1) begin
                error_code[BIT_ERR_ANNC_SEQ_JUMP] <= 1'b1;
            end
            last_sequence_id <= SequenceID;
        end
        
        // 2. 格式与协议一致性校验 (Announce 专属)
        error_code[BIT_ERR_MSG_LENGTH]    <= (MsgLength != 16'd64);       // Announce 报文总长度标准为 64
        error_code[BIT_ERR_DOMAIN_NUM]    <= (DomainNumber != 8'd0);      // 默认 802.1AS 域为 0
        error_code[BIT_ERR_CONTROL_FIELD] <= (ControlField != 8'd5);      // Announce 控制域必须为 0x05
        error_code[BIT_ERR_CORRECTION]    <= (CorrectionField != 64'd0);  // Announce 的修正域一般应为 0
        
    end
end

// 校验完成信号生成
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) 
        verify_done <= 1'b0;
    else 
        verify_done <= message_valid;
end

// ==============================================================================
// 组装上报报文
// ==============================================================================
// verify: 只要 error_code 非 0，即标记为异常 (2'b10)
wire [1:0] verify;
assign verify = (error_code != 32'd0) ? 2'b10 : 2'b01;

always @(posedge clk or negedge rst_n)begin
    if (!rst_n) begin
        upload_message       <= 384'b0;
        upload_message_valid <= 1'b0;
    end else if (verify_done) begin
        // MsgType (Announce 为 4'hb), 将 error_code 填入原本的 112 占位中 (使用 80'b0 + 32-bit error_code)
        upload_message       <= {port_num, verify, 4'hb, DomainNumber, FlagField, 
                                 CorrectionField, sourcePortIdentity, SequenceID, 
                                 ControlField, logMessage, 80'b0, error_code, timestamp_rx_Announce};
        upload_message_valid <= 1'b1;
    end
    else begin
        upload_message       <= 384'b0;
        upload_message_valid <= 1'b0;
    end
end

endmodule