`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/03/18 15:31:50
// Design Name: 
// Module Name: test_time_gen
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module test_time_gen(
    input             clk,          // 125MHz时钟，周期8ns
    input             rst_n,        // 异步复位，低电平有效
    input             test_start,   // 开始测试的单脉冲信号
    input      [31:0] config_time,  // 配置的测试时间（单位：秒）
    output     [63:0] test_time,    // 当前经过的测试时间组合 {s, ns}
    output reg        testing       // 测试进行中标志
);

    reg [31:0] test_time_ns;
    reg [31:0] test_time_s;

    // 拼接输出
    assign test_time = {test_time_s, test_time_ns};

    localparam ONE_SEC_IN_NS = 32'd1_000_000_000;
    localparam CLK_PERIOD_NS = 32'd8;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            testing      <= 1'b0;
            test_time_ns <= 32'd0;
            test_time_s  <= 32'd0;
        end 
        else begin
            // 1. 收到启动脉冲
            if (test_start) begin
                // 防呆设计：如果配置时间本身为0，则不拉高 testing
                if (config_time > 32'd0) begin
                    testing      <= 1'b1;
                    test_time_ns <= 32'd0;
                    test_time_s  <= 32'd0;
                end else begin
                    testing      <= 1'b0;
                end
            end 
            // 2. 测试运行中
            else if (testing) begin
                // 当 ns 计数器达到 999,999,992 时，代表下一个周期就满 1s 了
                if (test_time_ns >= (ONE_SEC_IN_NS - CLK_PERIOD_NS)) begin
                    test_time_ns <= 32'd0; // 纳秒清零进位
                    // 判断进位后是否达到配置的秒数
                    if ((test_time_s + 1'b1) >= config_time) begin
                        test_time_s <= test_time_s + 1'b1;
                        testing     <= 1'b0; // 达到指定时间，停止计数
                    end else begin
                        test_time_s <= test_time_s + 1'b1;
                    end
                end 
                // 尚未达到 1s，继续累加 ns
                else begin
                    test_time_ns <= test_time_ns + CLK_PERIOD_NS;
                end
            end
        end
    end

`ifdef DEBUG
ila_test_time U_ila_test_time (
	.clk        (clk        ),          // input wire clk
	.probe0     (test_start ),          // input wire [0:0]  probe0  
	.probe1     (testing    ),          // input wire [0:0]  probe1
    .probe2     (config_time)           // input wire [31:0] probe2
);
`endif


endmodule
