`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: XIDAIN
// Engineer:wanghaoyu
// 
// Create Date: 2025/07/03 10:54:57
// Design Name: 
// Module Name: test_frame_gen
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module test_frame_gen(
    input            clk                ,
    input            rst_n              ,
    input            test_rst           ,   
    input   [63:0]   test_time          ,
    //配表完成标识
    input            table_finish       ,
    //gPTP自定义报文
    input   [47:0]   port_des_mac       ,
    input   [47:0]   port_src_mac       ,

    //gPTP报文头部
    input   [3:0 ]   port_MsgType       ,
    input   [7:0 ]   port_DominNumber   ,
    input   [15:0]   port_FlagField     ,
    input   [63:0]   port_Correction    ,
    input   [79:0]   port_PortIdentity  ,
    input   [7:0 ]   port_LogMsgInterval,
    
    //特定payload
    input   [15:0]   port_CurrentUtcOffset   ,
    input   [7:0 ]   port_Priority1          ,
    input   [31:0]   port_clockQuailty       ,
    input   [7:0 ]   port_Priority2          ,
    input   [63:0]   port_clockIdentity      ,
    input   [15:0]   port_StepsRemoved       ,
    input   [7:0]    port_TimeSource         ,
    input   [79:0]   port_Pdelay_PortIdentity,

    //帧生成配置
    input   [63:0]   test_start_time     ,
    input   [31:0]   package_correct_num ,
    input   [31:0]   package_error_num   ,
    input   [31:0]   package_IFG         ,
    input   [31:0]   error_code          ,

    //时戳产生
    input   timestamp_tx_Sync_valid_cdc  ,
    input   timestamp_rx_Pdelay_valid_cdc,
    input   timestamp_tx_Presp_valid_cdc ,
    //帧产生
    output  [7:0 ]   dout                ,
    output           dval                ,
    output           sop                 ,
    output           eop                 ,
    output  reg      test_done           
);

reg  [31:0]  frame_IFG_cnt  ;
reg  [31:0]  package_num_cnt;
reg          gPTP_gen       ;
wire [31:0]  package_IFG_fix;

//给入帧生成模块
reg [47:0] des_mac       ;
reg [47:0] src_mac       ;
reg [15:0] ether_type    ;
reg [3:0 ] TranSpec      ;
reg [3:0 ] MsgType       ;
reg [3:0 ] VerPTP        ;
reg [15:0] MsgLength     ;
reg [7:0 ] DominNumber   ;
reg [15:0] FlagField     ;
reg [63:0] Correction    ;
reg [79:0] PortIdentity  ;
reg [15:0] SequenceID    ;
reg [7:0 ] ControlField  ;
reg [7:0 ] LogMsgInterval;
reg [79:0] Sync_tx_timestamp  ;
reg [79:0] Pdelay_rx_timestamp;
reg [79:0] Presp_tx_timestamp ;

wire des_mac_error       ;
wire src_mac_error       ;
wire ether_type_error    ;
wire TranSpec_error      ;
wire MsgType_error       ;
wire VerPTP_error        ;
wire MsgLength_error     ;
wire DominNumber_error   ;
wire FlagField_error     ;
wire Correction_error    ;
wire PortIdentity_error  ;
wire SequenceID_error    ;
wire ControlField_error  ;
wire LogMsgInterval_error;
wire crc_error           ;

assign des_mac_error        =   error_code[0]  && table_finish;
assign src_mac_error        =   error_code[1]  && table_finish;
assign ether_type_error     =   error_code[2]  && table_finish;
assign TranSpec_error       =   error_code[3]  && table_finish;
assign MsgType_error        =   error_code[4]  && table_finish;
assign VerPTP_error         =   error_code[5]  && table_finish;
assign MsgLength_error      =   error_code[6]  && table_finish;
assign DominNumber_error    =   error_code[7]  && table_finish;
assign FlagField_error      =   error_code[8]  && table_finish;
assign Correction_error     =   error_code[9]  && table_finish;
assign PortIdentity_error   =   error_code[10] && table_finish;
assign SequenceID_error     =   error_code[11] && table_finish;
assign ControlField_error   =   error_code[12] && table_finish;
assign LogMsgInterval_error =   error_code[13] && table_finish;
assign crc_error            =   error_code[14] && table_finish;
assign Sync_tx_error        =   error_code[15] && table_finish;
assign Pdelay_rx_error      =   error_code[16] && table_finish;
assign Presp_tx_error       =   error_code[17] && table_finish;

//gPTP 报文生成
wire Sync_en         ;
wire Pdelay_Req_en   ;
wire Presp_en        ;
wire Announce_en     ;
wire Sync_follow_en  ;
wire Presp_follow_en ;
reg  test_start      ;
reg  test_start_ff   ;
wire frame_gen_init  ;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) 
        test_start <= 1'b0;
    else if(test_time == test_start_time && test_start_time != 0)
        test_start <= 1'b1;
    else
        test_start <= 1'b0;
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) 
        test_start_ff <=1'b0;
    else
        test_start_ff <= test_start;
end

assign frame_gen_init  = (~test_start_ff) && test_start;   //取上升沿
assign Sync_en         = (port_MsgType == 4'h0)?(table_finish && (gPTP_gen||frame_gen_init)):1'b0;
assign Pdelay_Req_en   = (port_MsgType == 4'h2)?(table_finish && (gPTP_gen||frame_gen_init)):1'b0;
assign Presp_en        = (port_MsgType == 4'h3)?(table_finish && (gPTP_gen||frame_gen_init)):1'b0;
assign Sync_follow_en  = (port_MsgType == 4'h8)?(table_finish && (gPTP_gen||frame_gen_init)):1'b0;
assign Presp_follow_en = (port_MsgType == 4'ha)?(table_finish && (gPTP_gen||frame_gen_init)):1'b0;
assign Announce_en     = (port_MsgType == 4'hb)?(table_finish && (gPTP_gen||frame_gen_init)):1'b0;

//时序对齐
assign package_IFG_fix = package_IFG-32'd4;

//帧间隔计数
reg count_en;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        frame_IFG_cnt <= 32'd0;
        count_en      <= 1'b0;       
    end
    else begin
        if (eop) begin
            frame_IFG_cnt <= 32'd0;  
            count_en      <= 1'b1;   
        end
        else if (count_en && frame_IFG_cnt < package_IFG_fix) begin
            frame_IFG_cnt <= frame_IFG_cnt + 1'b1;
        end
        else if (count_en && frame_IFG_cnt >= package_IFG_fix) begin
            frame_IFG_cnt <= 32'd0;
            count_en      <= 1'b0;   
        end
    end
end

//发帧脉冲
always @(posedge clk or negedge rst_n) begin
    if(!rst_n) 
        gPTP_gen <= 1'b0 ;
    else if (frame_IFG_cnt == package_IFG_fix && package_num_cnt < (package_correct_num + package_error_num)) 
        gPTP_gen <= 1'b1 ;
    else 
        gPTP_gen <= 1'b0 ;
end

//发包统计
always @(posedge clk or negedge rst_n) begin
    if (!rst_n)  
        package_num_cnt <= 32'd0 ;
    else if (test_done)    
        package_num_cnt <= 32'd0 ;
    else if (gPTP_gen||frame_gen_init)
        package_num_cnt <= package_num_cnt + 1'b1 ;
    else 
        package_num_cnt <= package_num_cnt ;
end

//目的mac错误
always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		des_mac <= 48'b0 ;
	else if (des_mac_error == 1'b0) 
		des_mac <= port_des_mac ;
    else if (des_mac_error && package_num_cnt < package_correct_num)
        des_mac <= port_des_mac ;
    else    
        des_mac <= port_des_mac + 1'b1 ;
end

//源mac错误
always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		src_mac <= 48'b0 ;
	else if (src_mac_error == 1'b0) 
		src_mac <= port_src_mac ;
    else if (src_mac_error && package_num_cnt < package_correct_num)
        src_mac <= port_src_mac ;
    else    
        src_mac <= port_src_mac + 1'b1 ;
end

//帧标识错误
always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		ether_type <= 16'b0 ;
	else if (ether_type_error == 1'b0) 
		ether_type <= 16'h88f7;
    else if (ether_type_error && package_num_cnt < package_correct_num)
        ether_type <= 16'h88f7;
    else    
        ether_type <= 16'hbeef;
end

//TranSpec错误
always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		TranSpec <= 4'b0 ;
	else if (TranSpec_error == 1'b0) 
		TranSpec <= 4'b1 ;
    else if (TranSpec_error && package_num_cnt < package_correct_num)
        TranSpec <= 4'b1 ;
    else    
        TranSpec <= 4'b0 ;
end

//MsgType错误
always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		MsgType <= 4'b0 ;
	else if (MsgType_error == 1'b0) 
		MsgType <= port_MsgType ;
    else if (MsgType_error && package_num_cnt < package_correct_num)
        MsgType <= port_MsgType ;
    else    
        MsgType <= port_MsgType + 1'b1 ;
end

//VerPTP错误
always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		VerPTP <= 4'b0 ;
	else if (VerPTP_error == 1'b0) 
		VerPTP <= 4'h2 ;
    else if (VerPTP_error && package_num_cnt < package_correct_num)
        VerPTP <= 4'h2 ;
    else    
        VerPTP <= 4'h1 ;
end

//MsgLength错误
always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		MsgLength <= 16'b0 ;
	else if (MsgLength_error == 1'b0)begin
        case(MsgType)
            4'h0: MsgLength <= 16'h002c;
            4'h2: MsgLength <= 16'h0036;
            4'h3: MsgLength <= 16'h0036;
            4'h8: MsgLength <= 16'h002c;
            4'ha: MsgLength <= 16'h0036;
            4'hb: MsgLength <= 16'h0040;
            default: MsgLength <= 16'h0;
        endcase
    end
    else if (MsgLength_error && package_num_cnt < package_correct_num)begin
        case(MsgType)
            4'h0: MsgLength <= 16'h002c;
            4'h2: MsgLength <= 16'h0036;
            4'h3: MsgLength <= 16'h0036;
            4'h8: MsgLength <= 16'h002c;
            4'ha: MsgLength <= 16'h0036;
            4'hb: MsgLength <= 16'h0040;
            default: MsgLength <= 16'h0;
        endcase
    end
    else    
        MsgLength <= 16'hbeef;
end

//DominNumber错误
always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		DominNumber <= 8'b0 ;
	else if (DominNumber_error == 1'b0) 
		DominNumber <= port_DominNumber ;
    else if (DominNumber_error && package_num_cnt < package_correct_num)
        DominNumber <= port_DominNumber ;
    else    
        DominNumber <= port_DominNumber +1 ;
end

//FlagField错误
always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		FlagField <= 16'b0 ;
	else if (FlagField_error == 1'b0) 
		FlagField <= port_FlagField ;
    else if (FlagField_error && package_num_cnt < package_correct_num)
        FlagField <= port_FlagField ;
    else    
        FlagField <= port_FlagField +1 ;
end

//Correction错误
always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		Correction <= 64'b0 ;
	else if (Correction_error == 1'b0) 
		Correction <= port_Correction ;
    else if (Correction_error && package_num_cnt < package_correct_num)
        Correction <= port_Correction ;
    else    
        Correction <= 64'hffff_ffff_ffff_ffff;
end

//SequenceID错误
always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		SequenceID <= 16'b0 ;
	else if (SequenceID_error == 1'b0) 
		SequenceID <= package_num_cnt ;
    else if (SequenceID_error && package_num_cnt < package_correct_num)
        SequenceID <= package_num_cnt ;
    else    
        SequenceID <= 16'hffff;
end

//PortIdentity错误
always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		PortIdentity <= 80'b0 ;
	else if (PortIdentity_error == 1'b0) 
		PortIdentity <= port_PortIdentity ;
    else if (PortIdentity_error && package_num_cnt < package_correct_num)
        PortIdentity <= port_PortIdentity ;
    else    
        PortIdentity <= 80'hbeef_beef_beef_beef_beef;
end

//ControlField错误
always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		ControlField <= 8'b0 ;
	else if (ControlField_error == 1'b0) 
		ControlField <= 8'h1 ;
    else if (ControlField_error && package_num_cnt < package_correct_num)
        ControlField <= 8'h1 ;
    else    
        ControlField <= 8'haa;
end

//LogMsgInterval错误
always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		LogMsgInterval <= 8'b0 ;
	else if (LogMsgInterval_error == 1'b0) 
		LogMsgInterval <= port_LogMsgInterval ;
    else if (LogMsgInterval_error && package_num_cnt < package_correct_num)
        LogMsgInterval <= port_LogMsgInterval ;
    else    
        LogMsgInterval <= 8'h0;
end

//发送sync帧时间戳
always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		Sync_tx_timestamp <= 80'b0 ;
    else if (Sync_tx_error)
        Sync_tx_timestamp <= 80'hffff_ffff_ffff_ffff_ffff;
	else if (timestamp_tx_Sync_valid_cdc) 
		Sync_tx_timestamp <= test_time ;
    else    
        Sync_tx_timestamp <= Sync_tx_timestamp;
end

//接收Pdelay帧时间戳
always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		Pdelay_rx_timestamp <= 80'b0 ;
    else if(Pdelay_rx_error)
        Pdelay_rx_timestamp <= 80'hffff_ffff_ffff_ffff_ffff;
	else if (timestamp_rx_Pdelay_valid_cdc) 
		Pdelay_rx_timestamp <= test_time ;
    else    
        Pdelay_rx_timestamp <= Pdelay_rx_timestamp;
end

//发送Presp帧时间戳
always @(posedge clk or negedge rst_n) begin
	if (!rst_n) 
		Presp_tx_timestamp <= 80'b0 ;
    else if(Presp_tx_error)
        Presp_tx_timestamp <= 80'hffff_ffff_ffff_ffff_ffff;
	else if (timestamp_tx_Presp_valid_cdc) 
		Presp_tx_timestamp <= test_time ;
    else    
        Presp_tx_timestamp <= Presp_tx_timestamp;
end

//测试完成标识
always @(posedge clk or negedge rst_n) begin
    if (!rst_n)
        test_done <= 1'b0 ;
    else if (test_rst)
        test_done <= 1'b0 ;
    else if (package_num_cnt == (package_correct_num + package_error_num) && eop) 
        test_done <= 1'b1 ;
    else 
        test_done <= 1'b0 ;
end


frame_gen U_frame_gen(
    .clk                    (clk                     ),
    .rst_n                  (rst_n                   ),

    .Sync_en                (Sync_en                 ),
    .Pdelay_Req_en          (Pdelay_Req_en           ),
    .Presp_gen              (Presp_en                ), 
    .Announce_en            (Announce_en             ),
    .Sync_follow_en         (Sync_follow_en          ),
    .Presp_follow_gen       (Presp_follow_en         ),
    .crc_error              (crc_error               ),

    //帧头
    .des_mac                (des_mac                 ),
    .src_mac                (src_mac                 ),
    .ether_type             (ether_type              ),
    .TranSpec               (TranSpec                ),
    .MsgType                (MsgType                 ),
    .VerPTP                 (VerPTP                  ),
    .MsgLength              (MsgLength               ),
    .DominNumber            (DominNumber             ),
    .FlagField              (FlagField               ),
    .Correction             (Correction              ),
    .PortIdentity           (PortIdentity            ),
    .SequenceID             (SequenceID              ),
    .ControlField           (ControlField            ),
    .LogMsgInterval         (LogMsgInterval          ),

    //payload
    .CurrentUtcOffset       (port_CurrentUtcOffset   ), 
    .Priority1              (port_Priority1          ), 
    .clockQuailty           (port_clockQuailty       ), 
    .Priority2              (port_Priority2          ), 
    .clockIdentity          (port_clockIdentity      ), 
    .StepsRemoved           (port_StepsRemoved       ), 
    .TimeSource             (port_TimeSource         ), 

    .Sync_tx_timestamp      (Sync_tx_timestamp       ), 
    .Pdelay_rx_timestamp    (Pdelay_rx_timestamp     ), 
    .Presp_tx_timestamp     (Presp_tx_timestamp      ), 
    .Pdelay_PortIdentity    (port_Pdelay_PortIdentity),

    //发帧
    .data_out               (dout                    ),   
    .data_valid             (dval                    ),   
    .sop                    (sop                     ),   
    .eop                    (eop                     )
);

`ifdef DEBUG
ila_test_frame_gen U_ila_test_frame_gen (
	.clk                    (clk                     ), // input wire clk
	.probe0                 (dout                    ), // input wire [7:0]  probe0  
	.probe1                 (dval                    )  // input wire [0:0]  probe1
);
`endif

endmodule
