// `timescale 1ns / 1ps
// //////////////////////////////////////////////////////////////////////////////////
// // Module Name: test_mode_monitor
// // Description: 支持多表项连续侦听、双模期望裁决、统一错误上报的协议监视器。
// //////////////////////////////////////////////////////////////////////////////////

// module test_mode_monitor(
//     input  wire        clk,
//     input  wire        rst_n,
//     input  wire [3:0]  port_Op_Index,         // 控制字: [3]bit位代表使能监视, [2]bit位含义:1为期望沉默/0为期望发包
//     input  wire [63:0] test_time,             // 当前经过的测试时间
//     input  wire [63:0] port_Test_start_time,  // 当前表项规定的触发时间点
//     input  wire        table_finish ,         // 表项有效标识
//     input  wire        testing      ,         // 全局测试窗口期 (高电平有效)
//     input  wire [7:0]  rxd_to_test  ,         // DUT 发送的 MAC 数据
//     input  wire        rx_en_to_test,         // 数据有效使能
//     output wire [7:0]  monitior_error         // 统一错误输出 (0为正常)
// );

//     // 超时阈值：例如 3倍 Announce 间隔 (1s * 3 = 3s)。
//     parameter TIMEOUT_THRESHOLD = 375_000_000;    // 超时阈值
//     parameter MONITIOR_MSG_TYPE = 4'hB;   //期望监听的报文类型

//     // =========================================================================
//     // 1. 指令解析与瞬时触发逻辑
//     // =========================================================================
//     reg monitor_armed;       // 待命状态指示
//     reg monitor_running;     // 运行状态指示
//     reg cur_expect_silence;  // 锁存的期望模式 (1:期望沉默, 0:期望持续发包)
//     reg [63:0] watchdog_cnt;
//     reg [7:0]  error_reg;
//     reg [3:0]  err_announce_cnt; //沉默模式下的异常报文计数器
//     reg table_finish_ff1;
//     reg table_finish_ff2;
//     wire table_finish_neg;


//     // 触发脉冲：必须处于武装状态，且时间精确匹配
//     wire trigger_start = monitor_armed && (test_time == port_Test_start_time);   //时间点到达脉冲

//     assign table_finish_neg = table_finish_ff1 & !table_finish_ff2;

//     always @(posedge clk or negedge rst_n) begin
//         if (!rst_n) begin
//             table_finish_ff1 <= 1'b0;
//             table_finish_ff2 <= 1'b0;
//         end else begin
//             table_finish_ff1 <= table_finish & testing;
//             table_finish_ff2 <= table_finish_ff1;
//         end
//     end


//     always @(posedge clk or negedge rst_n) begin
//         if (!rst_n) begin
//             monitor_armed      <= 1'b0;
//             monitor_running    <= 1'b0;
//             cur_expect_silence <= 1'b0;
//         end else if (!testing) begin
//             // 全局测试结束，强制关闭并清空所有状态
//             monitor_armed      <= 1'b0;
//             monitor_running    <= 1'b0;
//         end else begin
            
//             // 动作 A：抓取 table_finish 脉冲，进行“武装”
//             if (table_finish_neg) begin
//                 if (port_Op_Index[3]) begin
//                     monitor_armed      <= 1'b1;             // 开启监视，进入待命状态
//                     cur_expect_silence <= port_Op_Index[2]; // 提前锁存期望模式
//                 end else begin
//                     monitor_armed      <= 1'b0;             // 本表项不需要监视，解除武装
//                 end
//             end
            
//             // 动作 B：时间点匹配，正式触发！
//             if (trigger_start) begin
//                 // 触发瞬间，解除待命状态（由于monitor_armed变0，trigger_start只会维持1拍）
//                 monitor_armed   <= 1'b0; 
//                 monitor_running <= 1'b1; // 正式进入监视掐表状态
//             end
            
//             // 动作 C：正常退出机制（针对期望沉默的情况）
//             if (monitor_running) begin
//                 // 如果是“期望沉默”模式，且安然度过了超时窗口还没收到包，说明测试通过，自动关闭监视
//                 // 这允许系统平静地等待下一个 table_finish 的到来
//                 if (cur_expect_silence && (watchdog_cnt == TIMEOUT_THRESHOLD)) begin
//                     monitor_running <= 1'b0;
//                 end
//             end
            
//         end
//     end

//     // =========================================================================
//     // 2. 前导码 SFD 严格识别 (55 -> D5) 与有效负载字节计数
//     // =========================================================================
//     reg [7:0]  rxd_to_test_d1; // 增加一拍缓存
//     reg        payload_en;
//     reg [15:0] payload_cnt;
    
//     always @(posedge clk or negedge rst_n) begin
//         if (!rst_n) begin
//             rxd_to_test_d1 <= 8'h00;
//             payload_en     <= 1'b0;
//             payload_cnt    <= 16'd0;
//         end else if (!rx_en_to_test) begin
//             rxd_to_test_d1 <= 8'h00;     // 帧间隙期间复位状态
//             payload_en     <= 1'b0;      
//             payload_cnt    <= 16'd0;
//         end else begin
//             // 每拍缓存当前数据，供下一拍做时序判断
//             rxd_to_test_d1 <= rxd_to_test;

//             if (!payload_en) begin
//                 // 严格判定：前一拍是 0x55，当前拍是 0xD5
//                 if ((rxd_to_test_d1 == 8'h55) && (rxd_to_test == 8'hD5)) begin
//                     payload_en <= 1'b1; // 下一拍开始正式作为 MAC Payload 计数
//                 end
//             end else begin
//                 payload_cnt <= payload_cnt + 1'b1;
//             end
//         end
//     end

//     // =========================================================================
//     // 3. 提取 EtherType
//     // =========================================================================
//     reg [15:0] eth_type;
//     always @(posedge clk or negedge rst_n) begin
//         if (!rst_n) begin
//             eth_type <= 16'd0;
//         end else if (rx_en_to_test && payload_en) begin
//             // DA(6) + SA(6) = 12, 故偏移量为 12 和 13 是 EtherType
//             if (payload_cnt == 16'd12) eth_type[15:8] <= rxd_to_test;
//             if (payload_cnt == 16'd13) eth_type[7:0]  <= rxd_to_test;
//         end
//     end

//     // =========================================================================
//     // 4. 实时识别要监听的报文
//     // =========================================================================
//     // IEEE 802.1AS: EtherType = 0x88F7, MsgType 位于 Payload 偏移为 14 的字节的低 4 位
//     wire is_monitior_msg = rx_en_to_test && payload_en && 
//                            (payload_cnt == 16'd14) && 
//                            (eth_type == 16'h88F7) && 
//                            (rxd_to_test[3:0] == MONITIOR_MSG_TYPE);
                           

//     // =========================================================================
//     // 5. 核心逻辑：双模看门狗、容忍计数器与粘性错误寄存器
//     // =========================================================================
//     always @(posedge clk or negedge rst_n) begin
//         if (!rst_n) begin
//             watchdog_cnt     <= 64'd0;
//             error_reg        <= 8'd0;
//             err_announce_cnt <= 4'd0;
//         end else if (!testing) begin
//             // 全局测试拉低时，彻底清零
//             watchdog_cnt     <= 64'd0;
//             error_reg        <= 8'd0;
//             err_announce_cnt <= 4'd0;
//         end else if (trigger_start) begin
//             // 到达新时间点触发时，复位看门狗和报文计数器（保留 error_reg）
//             watchdog_cnt     <= 64'd0;
//             err_announce_cnt <= 4'd0;
//         end else if (monitor_running) begin
            
//             if (is_monitior_msg) begin
//                 // 收到了 DUT 发出的监视报文
//                 watchdog_cnt <= 64'd0; // 喂狗清零
                
//                 // 裁决 A：期望沉默模式
//                 if (cur_expect_silence) begin
//                     // 报文计数器累加 (防止溢出锁死在全1)
//                     if (err_announce_cnt < 4'hF) begin
//                         err_announce_cnt <= err_announce_cnt + 1'b1;
//                     end
                    
//                     //容忍第一帧，从第二帧开始抓
//                     if (err_announce_cnt >= 4'd1) begin
//                         error_reg <= error_reg | 8'h01; // 错误码 1: 期望沉默却持续发包
//                     end
//                 end

//             end else if (watchdog_cnt < TIMEOUT_THRESHOLD) begin
//                 // 未收到包且未超时，累加看门狗时间
//                 watchdog_cnt <= watchdog_cnt + 1'b1;

//             end else if (watchdog_cnt == TIMEOUT_THRESHOLD) begin
                
//                 // 裁决 B：期望发包模式
//                 if (!cur_expect_silence) begin
//                     error_reg <= error_reg | 8'h02; // 错误码 2: 期望发包却超时沉默
//                 end
                
//                 watchdog_cnt <= watchdog_cnt + 1'b1; // 加 1 防止反复触发
//             end
//         end
//     end

//     // 输出最终的错误状态
//     assign monitior_error = error_reg;

//     ila_monitior U_ila_monitior (
//     	.clk            (clk                  ), // input wire clk
//     	.probe0         (testing              ), // input wire [0:0]  probe0  
//     	.probe1         (port_Op_Index        ), // input wire [3:0]  probe1 
//     	.probe2         (table_finish         ), // input wire [0:0]  probe2 
//     	.probe3         (is_monitior_msg      ), // input wire [0:0]  probe3 
//     	.probe4         (monitior_error       ), // input wire [7:0]  probe4
//         .probe5         (watchdog_cnt         ), // input wire [63:0]  probe4
//         .probe6         (cur_expect_silence   ), // input wire [0:0]  probe4
//         .probe7         (err_announce_cnt     )  // input wire [3:0]  probe4
//     );

// endmodule

`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module Name: test_mode_monitor
// Description: 支持多表项连续侦听、双模期望裁决、统一错误上报的协议监视器。
// Update: 修复流水线冲突，引入 pending_expect_silence 影子寄存器，确保表项时间到达时才切换期望模式。
//////////////////////////////////////////////////////////////////////////////////

module test_mode_monitor(
    input  wire        clk,
    input  wire        rst_n,
    input  wire [3:0]  port_Op_Index,        // 控制字: [3]bit位代表使能监视, [2]bit位含义:1为期望沉默/0为期望发包
    input  wire [63:0] test_time,            // 当前经过的测试时间
    input  wire [63:0] port_Test_start_time, // 当前表项规定的触发时间点
    input  wire        table_finish ,        // 表项有效标识
    input  wire        testing      ,        // 全局测试窗口期 (高电平有效)
    input  wire [7:0]  rxd_to_test  ,        // DUT 发送的 MAC 数据
    input  wire        rx_en_to_test,        // 数据有效使能
    output wire [7:0]  monitior_error        // 统一错误输出 (0为正常)
);

    // 超时阈值：例如 3倍 Announce 间隔 (1s * 3 = 3s)。
    parameter TIMEOUT_THRESHOLD = 375_000_000;    // 超时阈值
    parameter MONITIOR_MSG_TYPE = 4'hB;   //期望监听的报文类型

    // =========================================================================
    // 1. 指令解析与瞬时触发逻辑
    // =========================================================================
    reg monitor_armed;          // 待命状态指示
    reg monitor_running;        // 运行状态指示
    reg pending_expect_silence; // 【新增】挂起的期望模式 (表项加载完但触发时间未到时暂存)
    reg cur_expect_silence;     // 正在执行的当前期望模式
    reg [63:0] watchdog_cnt;
    reg [7:0]  error_reg;
    reg [3:0]  err_announce_cnt; //沉默模式下的异常报文计数器
    reg table_finish_ff1;
    reg table_finish_ff2;
    wire table_finish_neg;


    // 触发脉冲：必须处于武装状态，且时间精确匹配
    wire trigger_start = monitor_armed && (test_time == port_Test_start_time);   //时间点到达脉冲

    assign table_finish_neg = table_finish_ff1 & !table_finish_ff2;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            table_finish_ff1 <= 1'b0;
            table_finish_ff2 <= 1'b0;
        end else begin
            table_finish_ff1 <= table_finish & testing;
            table_finish_ff2 <= table_finish_ff1;
        end
    end


    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            monitor_armed          <= 1'b0;
            monitor_running        <= 1'b0;
            cur_expect_silence     <= 1'b0;
            pending_expect_silence <= 1'b0; // 【新增】复位影子寄存器
        end else if (!testing) begin
            // 全局测试结束，强制关闭并清空所有状态
            monitor_armed          <= 1'b0;
            monitor_running        <= 1'b0;
        end else begin
            
            // 动作 A：抓取 table_finish 脉冲，进行“武装”
            if (table_finish_neg) begin
                if (port_Op_Index[3]) begin
                    monitor_armed          <= 1'b1;            // 开启监视，进入待命状态
                    pending_expect_silence <= port_Op_Index[2]; // 【核心修复】提前锁存到 pending 寄存器，不破坏当前正在执行的 cur 状态
                end else begin
                    monitor_armed          <= 1'b0;            // 本表项不需要监视，解除武装
                end
            end
            
            // 动作 B：时间点匹配，正式触发！
            if (trigger_start) begin
                // 触发瞬间，解除待命状态（由于monitor_armed变0，trigger_start只会维持1拍）
                monitor_armed      <= 1'b0; 
                monitor_running    <= 1'b1;                   // 正式进入监视掐表状态
                cur_expect_silence <= pending_expect_silence; // 【核心修复】时间点到达时，正式将期望模式接管到工作寄存器
            end
            
            // 动作 C：正常退出机制（针对期望沉默的情况）
            if (monitor_running) begin
                // 如果是“期望沉默”模式，且安然度过了超时窗口还没收到包，说明测试通过，自动关闭监视
                // 这允许系统平静地等待下一个 table_finish 的到来
                if (cur_expect_silence && (watchdog_cnt == TIMEOUT_THRESHOLD)) begin
                    monitor_running <= 1'b0;
                end
            end
            
        end
    end

    // =========================================================================
    // 2. MAC 层报文解析与字节计数
    // =========================================================================
    reg [15:0] byte_cnt;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            byte_cnt <= 16'd0;
        end else if (rx_en_to_test) begin
            byte_cnt <= byte_cnt + 1'b1;
        end else begin
            byte_cnt <= 16'd0; // 帧间隙 (IPG) 期间复位计数器
        end
    end

    // =========================================================================
    // 3. 提取 EtherType
    // =========================================================================
    reg [15:0] eth_type;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            eth_type <= 16'd0;
        end else if (rx_en_to_test) begin
            if (byte_cnt == 16'd20) eth_type[15:8] <= rxd_to_test;
            if (byte_cnt == 16'd21) eth_type[7:0]  <= rxd_to_test;
        end
    end

    // =========================================================================
    // 4. 实时识别要监听的报文
    // =========================================================================
    // IEEE 802.1AS: EtherType = 0x88F7, MsgType (低4位) = 0xB
    wire is_monitior_msg = rx_en_to_test && 
                           (byte_cnt == 16'd22) && 
                           (eth_type == 16'h88F7) && 
                           (rxd_to_test[3:0] == MONITIOR_MSG_TYPE);

    // =========================================================================
    // 5. 核心逻辑：双模看门狗、容忍计数器与粘性错误寄存器
    // =========================================================================
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            watchdog_cnt     <= 64'd0;
            error_reg        <= 8'd0;
            err_announce_cnt <= 4'd0;
        end else if (!testing) begin
            // 全局测试拉低时，彻底清零
            watchdog_cnt     <= 64'd0;
            error_reg        <= 8'd0;
            err_announce_cnt <= 4'd0;
        end else if (trigger_start) begin
            // 到达新时间点触发时，复位看门狗和报文计数器（保留 error_reg）
            watchdog_cnt     <= 64'd0;
            err_announce_cnt <= 4'd0;
        end else if (monitor_running) begin
            
            if (is_monitior_msg) begin
                // 收到了 DUT 发出的监视报文
                watchdog_cnt <= 64'd0; // 喂狗清零
                
                // 裁决 A：期望沉默模式
                if (cur_expect_silence) begin
                    // 报文计数器累加 (防止溢出锁死在全1)
                    if (err_announce_cnt < 4'hF) begin
                        err_announce_cnt <= err_announce_cnt + 1'b1;
                    end
                    
                    //容忍第一帧，从第二帧开始抓
                    if (err_announce_cnt >= 4'd1) begin
                        error_reg <= error_reg | 8'h01; // 错误码 1: 期望沉默却持续发包
                    end
                end

            end else if (watchdog_cnt < TIMEOUT_THRESHOLD) begin
                // 未收到包且未超时，累加看门狗时间
                watchdog_cnt <= watchdog_cnt + 1'b1;

            end else if (watchdog_cnt == TIMEOUT_THRESHOLD) begin
                
                // 裁决 B：期望发包模式
                if (!cur_expect_silence) begin
                    error_reg <= error_reg | 8'h02; // 错误码 2: 期望发包却超时沉默
                end
                
                watchdog_cnt <= watchdog_cnt + 1'b1; // 加 1 防止反复触发
            end
        end
    end

    // 输出最终的错误状态
    assign monitior_error = error_reg;

    `ifdef DEBUG
    ila_monitior U_ila_monitior (
    	.clk            (clk                  ), // input wire clk
    	.probe0         (testing              ), // input wire [0:0]  probe0  
    	.probe1         (port_Op_Index        ), // input wire [3:0]  probe1 
    	.probe2         (table_finish         ), // input wire [0:0]  probe2 
    	.probe3         (is_monitior_msg      ), // input wire [0:0]  probe3 
    	.probe4         (monitior_error       ), // input wire [7:0]  probe4
        .probe5         (watchdog_cnt         ), // input wire [63:0]  probe4
        .probe6         (cur_expect_silence   ), // input wire [0:0]  probe4
        .probe7         (err_announce_cnt     )  // input wire [3:0]  probe4
    );
    `endif

endmodule