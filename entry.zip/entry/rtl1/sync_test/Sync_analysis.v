`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: wanghaoyu
// 
// Create Date: 2025/04/24 17:03:28
// Design Name: 
// Module Name: Sync_analysis
// Project Name: gPTP/802.1AS Tester
// Description: Sync帧深度解析与一致性校验模块 (集成了 32-bit error_code 统合上报)
//////////////////////////////////////////////////////////////////////////////////

module Sync_analysis(
    input                   clk                 ,
    input                   rst_n               ,
    input       [7:0]       data_i              ,
    input                   valid_i             ,
    input       [1:0]       port_num            ,

    output reg  [15:0]      MsgLength           ,
    output reg  [7:0]       DomainNumber        ,
    output reg  [15:0]      FlagField           ,
    output reg  [63:0]      CorrectionField     ,
    output reg  [79:0]      sourcePortIdentity  ,
    output reg  [15:0]      SequenceID          ,
    output reg  [7:0]       ControlField        ,
    output reg  [7:0]       logMessage          ,
    output reg  [79:0]      timestamp_tx_Sync   ,
    output                  message_valid       ,
    output reg  [383:0]     upload_message      ,
    output reg              upload_message_valid,
    
    //时间戳
    input      [1:0 ]       port_mode           ,
    input      [63:0]       test_time           , 
    input      [63:0]       sys_time            ,  
    input                   timestamp_rx_Sync_valid_cdc       
);

// ==============================================================================
// 全局 error_code 位映射定义 (Sync相关部分)
// ==============================================================================
localparam BIT_ERR_MSG_LENGTH     = 5'd2;
localparam BIT_ERR_DOMAIN_NUM     = 5'd4;
localparam BIT_ERR_FLAGS_TWOSTEP  = 5'd5;
localparam BIT_ERR_CONTROL_FIELD  = 5'd6;
localparam BIT_ERR_SYNC_SEQ_JUMP  = 5'd8;
localparam BIT_ERR_SYNC_SEQ_RPT   = 5'd9;
localparam BIT_ERR_CORRECTION     = 5'd25;

// ==============================================================================
// 内部信号定义
// ==============================================================================
reg [7:0]  cnt;       
reg [63:0] timestamp_rx_Sync;
assign message_valid = (cnt == 42) ? 1'b1 : 1'b0;

reg [15:0] last_sequence_id;
reg        first_packet    ;
reg        verify_done     ;
reg [31:0] error_code      ; // 新增：统合错误码寄存器

// 字节流计数
always @(posedge clk or negedge rst_n) begin
    if(!rst_n)
        cnt <= 8'b0;
    else if(!valid_i)
        cnt <= 8'b0;
    else
        cnt <= cnt + 1'b1;
end

// 报文提取 (保持原有逻辑完全不变)
always @(posedge clk or negedge rst_n) begin
    if(!rst_n)begin
        MsgLength          <= 16'b0;
        DomainNumber       <= 8'b0 ;
        FlagField          <= 16'b0;
        CorrectionField    <= 64'b0;
        sourcePortIdentity <= 80'b0;
        SequenceID         <= 16'b0;
        ControlField       <= 8'b0 ;
        logMessage         <= 8'b0 ; 
    end
    else begin
        case(cnt)
            8'd0:  MsgLength[15:8]            <= data_i;
            8'd1:  MsgLength[7:0]             <= data_i;
            8'd2:  DomainNumber               <= data_i;
            8'd4:  FlagField[15:8]            <= data_i;
            8'd5:  FlagField[7:0]             <= data_i;
            8'd6:  CorrectionField[63:56]     <= data_i;
            8'd7:  CorrectionField[55:48]     <= data_i;
            8'd8:  CorrectionField[47:40]     <= data_i;
            8'd9:  CorrectionField[39:32]     <= data_i;
            8'd10: CorrectionField[31:24]     <= data_i;
            8'd11: CorrectionField[23:16]     <= data_i;
            8'd12: CorrectionField[15:8]      <= data_i;
            8'd13: CorrectionField[7:0]       <= data_i;
            8'd18: sourcePortIdentity[79:72]  <= data_i;
            8'd19: sourcePortIdentity[71:64]  <= data_i;
            8'd20: sourcePortIdentity[63:56]  <= data_i;
            8'd21: sourcePortIdentity[55:48]  <= data_i;
            8'd22: sourcePortIdentity[47:40]  <= data_i;
            8'd23: sourcePortIdentity[39:32]  <= data_i;
            8'd24: sourcePortIdentity[31:24]  <= data_i;
            8'd25: sourcePortIdentity[23:16]  <= data_i;
            8'd26: sourcePortIdentity[15:8 ]  <= data_i;
            8'd27: sourcePortIdentity[7:0  ]  <= data_i;
            8'd28: SequenceID[15:8]           <= data_i;
            8'd29: SequenceID[7:0]            <= data_i;
            8'd30: ControlField               <= data_i;
            8'd31: logMessage                 <= data_i;
            8'd32: timestamp_tx_Sync[79:72]   <= data_i;
            8'd33: timestamp_tx_Sync[71:64]   <= data_i; 
            8'd34: timestamp_tx_Sync[63:56]   <= data_i;
            8'd35: timestamp_tx_Sync[55:48]   <= data_i;
            8'd36: timestamp_tx_Sync[47:40]   <= data_i;
            8'd37: timestamp_tx_Sync[39:32]   <= data_i;
            8'd38: timestamp_tx_Sync[31:24]   <= data_i; 
            8'd39: timestamp_tx_Sync[23:16]   <= data_i;
            8'd40: timestamp_tx_Sync[15:8 ]   <= data_i;
            8'd41: timestamp_tx_Sync[7:0  ]   <= data_i;        
            default:begin
                MsgLength          <=  MsgLength          ;
                DomainNumber       <=  DomainNumber       ;
                FlagField          <=  FlagField          ;
                CorrectionField    <=  CorrectionField    ;
                sourcePortIdentity <=  sourcePortIdentity ;
                SequenceID         <=  SequenceID         ;
                ControlField       <=  ControlField       ;
                logMessage         <=  logMessage         ;
                timestamp_tx_Sync  <=  timestamp_tx_Sync  ;
            end
        endcase
    end
end

// 接收帧时戳捕获
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        timestamp_rx_Sync <= 64'b0;
    end 
    else if (timestamp_rx_Sync_valid_cdc) begin
        if(port_mode == 2'b10)
            timestamp_rx_Sync <= sys_time;
        else
            timestamp_rx_Sync <= test_time;
    end
end

// ==============================================================================
// 深度解析：统合生成 32-bit error_code
// ==============================================================================
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        last_sequence_id <= 16'd0;
        first_packet     <= 1'b1;
        error_code       <= 32'd0;
    end else if (message_valid) begin
        
        // 每次判定前先将 error_code 清零，然后各个击破
        error_code <= 32'd0; 
        
        // 1. Sequence ID 校验 (Bits 8, 9)
        if (first_packet) begin
            last_sequence_id <= SequenceID;
            first_packet     <= 1'b0;
        end else begin
            if (SequenceID == last_sequence_id) begin
                error_code[BIT_ERR_SYNC_SEQ_RPT]  <= 1'b1; // 重复
            end else if (SequenceID != last_sequence_id + 1'b1) begin
                error_code[BIT_ERR_SYNC_SEQ_JUMP] <= 1'b1; // 跳变
            end
            last_sequence_id <= SequenceID;
        end
        
        // 2. 格式与协议一致性校验 (Bits 2, 4, 5, 6, 25)
        error_code[BIT_ERR_MSG_LENGTH]    <= (MsgLength != 16'd44);       // Sync长度应为44字节
        error_code[BIT_ERR_DOMAIN_NUM]    <= (DomainNumber != 8'd0);      // 802.1AS默认域为0
        error_code[BIT_ERR_FLAGS_TWOSTEP] <= (~FlagField[9]);             // TwoStepFlag必须为1
        error_code[BIT_ERR_CONTROL_FIELD] <= (ControlField != 8'd0);      // Sync控制域应为0
        error_code[BIT_ERR_CORRECTION]    <= (CorrectionField != 64'd0);  // 普通节点发出的Sync Correction应为0
        
    end
end

// 校验完成信号生成
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) 
        verify_done <= 1'b0;
    else 
        verify_done <= message_valid;
end

// ==============================================================================
// 组装上报报文
// ==============================================================================
// verify: 只要 error_code 非 0，就标记为异常(2'b10)
wire [1:0] verify;
assign verify = (error_code != 32'd0) ? 2'b10 : 2'b01;

always @(posedge clk or negedge rst_n)begin
    if (!rst_n) begin
        upload_message       <= 384'b0;
        upload_message_valid <= 1'b0;
    end else if (verify_done) begin
        upload_message       <= {port_num, verify, 4'h0, DomainNumber, FlagField, 
                                 CorrectionField, sourcePortIdentity, SequenceID, 
                                 ControlField, logMessage, 80'b0, error_code, timestamp_rx_Sync};
        upload_message_valid <= 1'b1;
    end
    else begin
        upload_message       <= 384'b0;
        upload_message_valid <= 1'b0;
    end
end

endmodule