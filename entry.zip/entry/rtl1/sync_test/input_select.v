`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: XIDIAN
// Engineer: wanghaoyu
// 
// Create Date: 2025/07/02 15:31:08
// Design Name: 
// Module Name: input_select
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 数据输入选择模块，支持在安全窗口（帧间隙）切换模式和测试使能，
//              提供完整的防断帧保护。
// 
// Dependencies: 
// 
// Revision:
// Revision 0.02 - Added frame integrity protection for random testing signal
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module input_select(
    input             clk            ,
    input             rst_n          ,
    input      [1:0]  port_mode      ,  // 模式控制信号 (外部随时可能切换)
    input             testing        ,  // 测试使能信号 (外部完全随机输入)
    input      [7:0]  gmii_rxd       ,  // 接收到的 GMII 数据
    input             gmii_rx_en     ,  // 数据有效标志
    output reg [7:0]  rxd_to_test    ,  // 输出到 test 模块的数据
    output reg        rx_en_to_test  ,  // 输出到 test 模块的使能
    output reg [7:0]  rxd_to_oc      ,  // 输出到 oc 模块的数据
    output reg        rx_en_to_oc       // 输出到 oc 模块的使能
);

parameter MODE1 = 2'b01, // 测试模式
          MODE2 = 2'b10; // OC 模式

// 内部实际生效的寄存器（经过帧间隙保护）
reg [1:0] active_mode;
reg       active_testing;

//-------------------------------------------------------------------------
// 状态更新逻辑：只在安全窗口（帧间隙 gmii_rx_en == 0）进行状态更新
// 包含模式切换保护和 testing 信号保护，彻底防止断帧
//-------------------------------------------------------------------------
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        active_mode    <= 2'b00; // 默认空闲状态
        active_testing <= 1'b0;  // 默认不使能
    end else begin
        // 无论外部的 port_mode 还是 testing 怎么随机跳变，
        // 我们只在总线空闲 (!gmii_rx_en) 的时刻，将它们采样到内部寄存器中,防止产生断帧
        if (!gmii_rx_en) begin
            active_mode    <= port_mode;
            active_testing <= testing;
        end
    end
end

//-------------------------------------------------------------------------
// 数据分发逻辑：根据安全的 active_mode 进行路由，并受 active_testing 管控
//-------------------------------------------------------------------------
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        rxd_to_test   <= 8'd0;
        rx_en_to_test <= 1'b0;
        rxd_to_oc     <= 8'd0;
        rx_en_to_oc   <= 1'b0;
    end else if (active_testing) begin
        // 使用受保护的 active_testing 作为分流使能
        case (active_mode)
            MODE1: begin
                // 路由到 test 模块
                rxd_to_test   <= gmii_rxd;
                rx_en_to_test <= gmii_rx_en;
                // oc 模块保持安静
                rxd_to_oc     <= 8'd0;
                rx_en_to_oc   <= 1'b0;
            end
            MODE2: begin
                // 路由到 oc 模块
                rxd_to_oc     <= gmii_rxd;
                rx_en_to_oc   <= gmii_rx_en;
                // test 模块保持安静
                rxd_to_test   <= 8'd0;
                rx_en_to_test <= 1'b0;
            end
            default: begin
                rxd_to_test   <= 8'd0;
                rx_en_to_test <= 1'b0;
                rxd_to_oc     <= 8'd0;
                rx_en_to_oc   <= 1'b0;
            end
        endcase
    end else begin
        // active_testing 为低电平时，切断所有输出流
        rxd_to_test   <= 8'd0;
        rx_en_to_test <= 1'b0;
        rxd_to_oc     <= 8'd0;
        rx_en_to_oc   <= 1'b0;
    end
end

endmodule