`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/01/13 10:20:23
// Design Name: 
// Module Name: frame_interval
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module frame_interval(
    input  clk,
    input  rst_n,
    input  timestamp_rx_Sync_valid_cdc    ,
    input  timestamp_rx_Pdelay_valid_cdc  ,
    input  timestamp_rx_Announce_valid_cdc,
    input  timestamp_tx_Pdelay_valid_cdc  ,
    input  timestamp_rx_Presp_valid_cdc   ,
    output reg [31:0] sync_interval       ,
    output reg [31:0] announce_interval   ,
    output reg [31:0] pdelay_interval     ,
    output reg [31:0] pdelay_resp_interval
    );

reg [63:0] timer;
reg [63:0] sync_rx_pre;
reg [63:0] sync_rx_new;
reg [63:0] announce_rx_pre;
reg [63:0] announce_rx_new;
reg [63:0] pdelay_rx_pre;
reg [63:0] pdelay_rx_new;
reg [63:0] pdelay_tx_snapshot;

always@(posedge clk or negedge rst_n) begin
   if (!rst_n) begin
       timer <= 64'b0;
   end else begin
       timer <= timer + 1;
   end
end

//Sync发送时间间隔统计
always @(posedge clk or negedge rst_n) begin
   if (!rst_n) begin
       sync_rx_pre   <= 64'b0;
       sync_rx_new   <= 64'b0;
       sync_interval <= 32'b0;
   end else begin
       sync_interval <=  sync_rx_new - sync_rx_pre;
       if (timestamp_rx_Sync_valid_cdc) begin
           sync_rx_new <= timer;
           sync_rx_pre <= sync_rx_new;
       end
    end
end

//Announce发送时间间隔统计
always @(posedge clk or negedge rst_n) begin
   if (!rst_n) begin
       announce_rx_pre   <= 64'b0;
       announce_rx_new   <= 64'b0;
       announce_interval <= 32'b0;
   end else begin
       announce_interval <=  announce_rx_new - announce_rx_pre;
       if (timestamp_rx_Announce_valid_cdc) begin
           announce_rx_new <= timer;
           announce_rx_pre <= announce_rx_new;
       end
    end
end

//Pdelay发送时间间隔统计
always @(posedge clk or negedge rst_n) begin
   if (!rst_n) begin
       pdelay_rx_pre   <= 64'b0;
       pdelay_rx_new   <= 64'b0;
       pdelay_interval <= 32'b0;
   end else begin
       pdelay_interval <=  pdelay_rx_new - pdelay_rx_pre;
       if (timestamp_rx_Pdelay_valid_cdc) begin
           pdelay_rx_new <= timer;
           pdelay_rx_pre <= pdelay_rx_new;
       end
    end
end

//Pdelay回转时间间隔统计
always @(posedge clk or negedge rst_n) begin
   if (!rst_n) begin
       pdelay_tx_snapshot   <= 64'b0;
       pdelay_resp_interval <= 32'b0;
   end else begin
       if (timestamp_tx_Pdelay_valid_cdc) begin
           pdelay_tx_snapshot <= timer;
       end
       if (timestamp_rx_Presp_valid_cdc) begin
           pdelay_resp_interval <= (timer - pdelay_tx_snapshot);
       end
   end
end


endmodule
