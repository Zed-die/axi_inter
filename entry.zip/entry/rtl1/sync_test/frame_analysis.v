`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: wanghaoyu
// 
// Create Date: 2025/04/23 22:36:35
// Design Name: 
// Module Name: frame_analysis
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


 module frame_analysis(
            input           clk    ,
            input           rst_n  ,
            input   [1:0]   port_num,
            (*mark_debug = "true"*)input   [7:0]   data_i ,
            (*mark_debug = "true"*)input           valid_i,
            output          pdelay_valid                  ,
            output  [79:0]  pdelay_portIdentity           ,
            //BMCA
            output  [79:0]  Message_sourcePortIdentity     ,
            output  [15:0]  Message_currentUtcOffset       ,
            output  [7:0]   Message_Priority1              ,         
            output  [7:0]   Message_clockClass             ,        
            output  [7:0]   Message_clockAccuracy          ,     
            output  [15:0]  Message_offsetScaledLogVariance,   
            output  [7:0]   Message_Priority2              ,        
            output  [63:0]  Message_clockIdentity          ,  
            output  [15:0]  Message_stepsRemoved           ,
            output  [7:0]   Message_timeSource             , 
            output          Message_Announce_valid         ,

            //接收时间戳标记,时间戳提取
            (*mark_debug = "true"*)output  [79:0]  Pdelay_Resp_tx_ts          ,  //对端发送Presp的时间点，由Presp_follow帧中提取
            (*mark_debug = "true"*)output          Pdelay_Resp_tx_ts_valid    , 

            (*mark_debug = "true"*)output  [79:0]  Pdelay_opposite_rx_ts      ,  //对端接收Pdelay帧的时间点，由Presp帧中提取
            (*mark_debug = "true"*)output          Pdelay_opposite_rx_ts_valid,

            (*mark_debug = "true"*)output  [79:0]  Sync_tx_ts                 ,  //对端发送Sync帧的时间点，由Sync_follow帧中提取
            (*mark_debug = "true"*)output  [63:0]  Sync_correction_field      ,  //对端发送Sync_follow中的修正域，由Sync_follow帧中提取
            (*mark_debug = "true"*)output          Sync_ts_valid              ,

            //上报
            output  reg  [383:0]    upload_message          ,
            output  reg             upload_message_valid    ,

            //时间戳
            input  [1:0 ]  port_mode        ,
            input  [63:0]  test_time        , 
            input  [63:0]  sys_time         ,  
            input          timestamp_rx_Sync_valid_cdc        ,
            input          timestamp_rx_Pdelay_valid_cdc      ,
            input          timestamp_rx_Presp_valid_cdc       ,
            input          timestamp_rx_Sync_follow_valid_cdc ,
            input          timestamp_rx_Presp_follow_valid_cdc,
            input          timestamp_rx_Announce_valid_cdc    

          
);

parameter IDLE         = 10'b00_0000_0001;
parameter FRAME_START  = 10'b00_0000_0010;
parameter MESSAGE_TYPE = 10'b00_0000_0100;
parameter FRAME_SELECT = 10'b00_0000_1000;
parameter SYNC         = 10'b00_0001_0000;
parameter PDELAY       = 10'b00_0010_0000;
parameter PRESP        = 10'b00_0100_0000;
parameter PRESP_FOLLOW = 10'b00_1000_0000;
parameter SYNC_FOLLOW  = 10'b01_0000_0000;
parameter ANNOUNCE     = 10'b10_0000_0000;

         
reg [9:0] cstate, nstate;

reg [7:0] cnt;
reg [7:0] data_ff0;
reg [3:0] frame_type;


reg  [7:0] Sync_data_reg ;
reg        Sync_valid_reg;

reg  [7:0] Pdelay_data_reg ;
reg        Pdelay_valid_reg;

reg  [7:0] Presp_data_reg ;
reg        Presp_valid_reg;

reg  [7:0] Sync_follow_data_reg ;
reg        Sync_follow_valid_reg;

reg  [7:0] Presp_follow_data_reg ;
reg        Presp_follow_valid_reg;

reg  [7:0] Announce_data_reg ;
reg        Announce_valid_reg;

reg valid_i_ff;

wire [383:0] Sync_upload_message        ;
wire         Sync_upload_message_valid  ;
wire [383:0] Pdelay_upload_message      ;
wire         Pdelay_upload_message_valid;
wire [383:0] Presp_upload_message       ;
wire         Presp_upload_message_valid ;
wire [383:0] Sync_follow_upload_message       ;
wire         Sync_follow_upload_message_valid ;
wire [383:0] Presp_follow_upload_message      ;
wire         Presp_follow_upload_message_valid;
wire [383:0] Announce_upload_message          ;
wire         Announce_upload_message_valid    ;

always @(posedge clk or negedge rst_n) 
begin
    if(!rst_n) begin
        data_ff0 <= 8'b0;
        valid_i_ff <= 1'b0;
    end
    else begin
        data_ff0 <= data_i;
        valid_i_ff<=valid_i;
    end
end

//帧解析
always @(posedge clk or negedge rst_n) 
begin
    if(!rst_n) 
        cstate <= IDLE;
    else 
        cstate <= nstate;
end

always@(*)
begin
    case(cstate)
    IDLE:
    begin
        if(data_i == 8'hd5 && data_ff0 == 8'h55 && valid_i)
            nstate = FRAME_START;
        else
            nstate = IDLE;
    end

    FRAME_START:
    begin
        if(cnt == 8'd14 && valid_i)
            nstate = MESSAGE_TYPE;
        else
            nstate = FRAME_START;
    end

    MESSAGE_TYPE:nstate = FRAME_SELECT;

    FRAME_SELECT:
    begin
        if(frame_type == 4'h0 && valid_i)
            nstate = SYNC;
        else if(frame_type == 4'h2 && valid_i)
            nstate = PDELAY;
        else if(frame_type == 4'h3 && valid_i)
            nstate = PRESP;
        else if(frame_type == 4'ha && valid_i)
            nstate = PRESP_FOLLOW;
        else if(frame_type == 4'h8 && valid_i)
            nstate = SYNC_FOLLOW;
        else if(frame_type == 4'hb && valid_i)
            nstate = ANNOUNCE;
        else
            nstate = IDLE;
    end

    SYNC:
    begin
        if(!valid_i_ff)
            nstate = IDLE;
        else
            nstate = SYNC;
    end

    PDELAY:
    begin
        if(!valid_i_ff)
            nstate = IDLE;
        else
            nstate = PDELAY;
    end

    PRESP:
    begin
        if(!valid_i_ff)
            nstate = IDLE;
        else
            nstate = PRESP;
    end

    PRESP_FOLLOW:
    begin
        if(!valid_i_ff)
            nstate = IDLE;
        else
            nstate = PRESP_FOLLOW;
    end

    SYNC_FOLLOW:
    begin
        if(!valid_i_ff)
            nstate = IDLE;
        else
            nstate = SYNC_FOLLOW;
    end

    ANNOUNCE:
    begin
        if(!valid_i_ff)
            nstate = IDLE;
        else
            nstate = ANNOUNCE;
    end
    default : nstate = IDLE;
    endcase 
end 


always @(posedge clk or negedge rst_n) 
begin
    if(!rst_n) 
        frame_type <= 4'b0;
    else if(cstate==MESSAGE_TYPE)begin
        frame_type <= data_i[3:0];
    end
    else
        frame_type <= 4'b0;
end

always @(posedge clk or negedge rst_n) 
begin
    if(!rst_n) begin
        Sync_data_reg           <=     8'b0;
        Sync_valid_reg          <=     1'b0;
        Pdelay_data_reg         <=     8'b0;
        Pdelay_valid_reg        <=     1'b0;
        Presp_data_reg          <=     8'b0;
        Presp_valid_reg         <=     1'b0;
        Sync_follow_data_reg    <=     8'b0;
        Sync_follow_valid_reg   <=     1'b0;
        Presp_follow_data_reg   <=     8'b0;
        Presp_follow_valid_reg  <=     1'b0;
        Announce_data_reg       <=     8'b0;
        Announce_valid_reg      <=     1'b0;
    end
    else if(cstate==SYNC)begin
        Sync_data_reg <= data_i;
        Sync_valid_reg<= valid_i;
    end
    else if(cstate==PDELAY)begin
        Pdelay_data_reg <= data_i;
        Pdelay_valid_reg<= valid_i;
    end
    else if(cstate==PRESP)begin
        Presp_data_reg <= data_i;
        Presp_valid_reg<= valid_i;
    end
    else if(cstate==SYNC_FOLLOW)begin
        Sync_follow_data_reg <= data_i;
        Sync_follow_valid_reg<= valid_i;
    end
    else if(cstate==PRESP_FOLLOW)begin
        Presp_follow_data_reg <= data_i;
        Presp_follow_valid_reg<= valid_i;
    end
    else if(cstate==ANNOUNCE)begin
        Announce_data_reg <= data_i;
        Announce_valid_reg<= valid_i;
    end
    else begin
        Sync_data_reg          <= 8'b0;
        Sync_valid_reg         <= 1'b0;
        Pdelay_data_reg        <= 8'b0;
        Pdelay_valid_reg       <= 1'b0;
        Presp_data_reg         <= 8'b0;
        Presp_valid_reg        <= 1'b0;
        Sync_follow_data_reg   <= 8'b0;
        Sync_follow_valid_reg  <= 1'b0;
        Presp_follow_data_reg  <= 8'b0;
        Presp_follow_valid_reg <= 1'b0;
        Announce_data_reg      <= 8'b0;
        Announce_valid_reg     <= 1'b0;
    end
end


always @(posedge clk or negedge rst_n) 
begin
    if(!rst_n) 
        cnt <= 1'b0;
    else if(nstate != IDLE && valid_i)
        cnt <= cnt + 1'b1;
    else 
        cnt <= 1'b0;
end

//上报信息轮询
always @(posedge clk or negedge rst_n) 
begin
    if(!rst_n) begin
        upload_message      <= 384'b0;
        upload_message_valid<= 1'b0;
    end
    else if(Sync_upload_message_valid)begin
        upload_message <= Sync_upload_message;
        upload_message_valid<= 1'b1;
    end
    else if(Pdelay_upload_message_valid)begin
        upload_message <= Pdelay_upload_message;
        upload_message_valid<= 1'b1;
    end
    else if(Presp_upload_message_valid)begin
        upload_message <= Presp_upload_message;
        upload_message_valid<= 1'b1;
    end
    else if(Sync_follow_upload_message_valid)begin
        upload_message <= Sync_follow_upload_message;
        upload_message_valid<= 1'b1;
    end
    else if(Presp_follow_upload_message_valid)begin
        upload_message <= Presp_follow_upload_message;
        upload_message_valid<= 1'b1;
    end
    else if(Announce_upload_message_valid)begin
        upload_message <= Announce_upload_message;
        upload_message_valid<= 1'b1;
    end
    else begin
        upload_message       <= 384'b0;
        upload_message_valid <= 1'b0;
    end
end


Sync_analysis U_Sync_analysis(
        .clk                                 (clk                                ),          
        .rst_n                               (rst_n                              ),   
        .data_i                              (Sync_data_reg                      ),
        .valid_i                             (Sync_valid_reg                     ),
        .port_num                            (port_num                           ),
        .port_mode                           (port_mode                          ),
        .test_time                           (test_time                          ),
        .sys_time                            (sys_time                           ),
        .timestamp_rx_Sync_valid_cdc         (timestamp_rx_Sync_valid_cdc        ),
        .MsgLength                           (                                   ),
        .DomainNumber                        (                                   ),
        .FlagField                           (                                   ),
        .CorrectionField                     (                                   ),
        .sourcePortIdentity                  (                                   ),
        .SequenceID                          (                                   ),
        .ControlField                        (                                   ),
        .logMessage                          (                                   ),
        .message_valid                       (                                   ),
        .upload_message                      (Sync_upload_message                ),
        .upload_message_valid                (Sync_upload_message_valid          )
);

Pdelay_analysis U_Pdelay_analysis( 
        .clk                                 (clk                                ),          
        .rst_n                               (rst_n                              ),   
        .data_i                              (Pdelay_data_reg                    ),
        .valid_i                             (Pdelay_valid_reg                   ),
        .port_num                            (port_num                           ),
        .port_mode                           (port_mode                          ),
        .test_time                           (test_time                          ),
        .sys_time                            (sys_time                           ),
        .timestamp_rx_Pdelay_valid_cdc       (timestamp_rx_Pdelay_valid_cdc      ),
        .MsgLength                           (                                   ),
        .DomainNumber                        (                                   ),
        .FlagField                           (                                   ),
        .CorrectionField                     (                                   ),
        .sourcePortIdentity                  (pdelay_portIdentity                ),
        .SequenceID                          (                                   ),
        .ControlField                        (                                   ),
        .logMessage                          (                                   ),
        .message_valid                       (pdelay_valid                       ),
        .upload_message                      (Pdelay_upload_message              ),
        .upload_message_valid                (Pdelay_upload_message_valid        )
);

Presp_analysis U_Presp_analysis(
        .clk                                 (clk                                ),          
        .rst_n                               (rst_n                              ),   
        .data_i                              (Presp_data_reg                     ),
        .valid_i                             (Presp_valid_reg                    ),
        .port_num                            (port_num                           ),
        .port_mode                           (port_mode                          ),
        .test_time                           (test_time                          ),
        .sys_time                            (sys_time                           ),
        .timestamp_rx_Presp_valid_cdc        (timestamp_rx_Presp_valid_cdc       ),
        .MsgLength                           (                                   ),
        .DomainNumber                        (                                   ),
        .FlagField                           (                                   ),
        .CorrectionField                     (                                   ),
        .sourcePortIdentity                  (                                   ),
        .SequenceID                          (                                   ),
        .ControlField                        (                                   ),
        .logMessage                          (                                   ),
        .Pdelay_RX_timestamp                 (Pdelay_opposite_rx_ts              ),
        .Pdelay_PortIdentity                 (                                   ),
        .message_valid                       (Pdelay_opposite_rx_ts_valid        ),
        .upload_message                      (Presp_upload_message               ),
        .upload_message_valid                (Presp_upload_message_valid         )
);

Sync_follow_analysis U_Sync_follow_analysis(
        .clk                                 (clk                                ),          
        .rst_n                               (rst_n                              ),   
        .data_i                              (Sync_follow_data_reg               ),
        .valid_i                             (Sync_follow_valid_reg              ),
        .port_num                            (port_num                           ),
        .port_mode                           (port_mode                          ),
        .test_time                           (test_time                          ),
        .sys_time                            (sys_time                           ),
        .timestamp_rx_Sync_follow_valid_cdc  (timestamp_rx_Sync_follow_valid_cdc ),
        .MsgLength                           (                                   ),
        .DomainNumber                        (                                   ),
        .FlagField                           (                                   ),
        .CorrectionField                     (Sync_correction_field              ),
        .sourcePortIdentity                  (                                   ),
        .SequenceID                          (                                   ),
        .ControlField                        (                                   ),
        .logMessage                          (                                   ),
        .Sync_TX_timesamp                    (Sync_tx_ts                         ),
        .message_valid                       (Sync_ts_valid                      ),
        .upload_message                      (Sync_follow_upload_message         ),
        .upload_message_valid                (Sync_follow_upload_message_valid   )
);                              

Presp_follow_analysis U_Presp_follow_analysis(
        .clk                                 (clk                                ),          
        .rst_n                               (rst_n                              ),   
        .data_i                              (Presp_follow_data_reg              ),
        .valid_i                             (Presp_follow_valid_reg             ),
        .port_num                            (port_num                           ),
        .port_mode                           (port_mode                          ),
        .test_time                           (test_time                          ),
        .sys_time                            (sys_time                           ),
        .timestamp_rx_Presp_follow_valid_cdc (timestamp_rx_Presp_follow_valid_cdc),
        .MsgLength                           (                                   ),
        .DomainNumber                        (                                   ),
        .FlagField                           (                                   ),
        .CorrectionField                     (                                   ),
        .sourcePortIdentity                  (                                   ),
        .SequenceID                          (                                   ),
        .ControlField                        (                                   ),
        .logMessage                          (                                   ),
        .Pdelay_PortIdentity                 (                                   ),
        .Presp_TX_timestamp                  (Pdelay_Resp_tx_ts                  ),
        .message_valid                       (Pdelay_Resp_tx_ts_valid            ),
        .upload_message                      (Presp_follow_upload_message        ),
        .upload_message_valid                (Presp_follow_upload_message_valid  )
);

Announce_analysis U_Announce_analysis(
        .clk                                 (clk                                ),          
        .rst_n                               (rst_n                              ),   
        .data_i                              (Announce_data_reg                  ),
        .valid_i                             (Announce_valid_reg                 ),
        .port_num                            (port_num                           ),
        .port_mode                           (port_mode                          ),
        .test_time                           (test_time                          ),
        .sys_time                            (sys_time                           ),
        .timestamp_rx_Announce_valid_cdc     (timestamp_rx_Announce_valid_cdc    ),
        .MsgLength                           (                                   ),
        .DomainNumber                        (                                   ),
        .FlagField                           (                                   ),
        .CorrectionField                     (                                   ),
        .sourcePortIdentity                  (Message_sourcePortIdentity         ),
        .SequenceID                          (                                   ),
        .ControlField                        (                                   ),
        .logMessage                          (                                   ),
        .Message_currentUtcOffset            (Message_currentUtcOffset           ),
        .Message_Priority1                   (Message_Priority1                  ),
        .Message_clockClass                  (Message_clockClass                 ),
        .Message_clockAccuracy               (Message_clockAccuracy              ),
        .Message_offsetScaledLogVariance     (Message_offsetScaledLogVariance    ),
        .Message_Priority2                   (Message_Priority2                  ),
        .Message_clockIdentity               (Message_clockIdentity              ),
        .Message_stepsRemoved                (Message_stepsRemoved               ),
        .Message_timeSource                  (Message_timeSource                 ),
        .message_valid                       (Message_Announce_valid             ),
        .upload_message                      (Announce_upload_message            ),
        .upload_message_valid                (Announce_upload_message_valid      )
        
);

endmodule
