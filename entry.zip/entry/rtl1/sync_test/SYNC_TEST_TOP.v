`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: wanghaoyu
// 
// Create Date: 2025/06/16 16:14:47
// Design Name: 
// Module Name: SYNC_TEST_TOP
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module SYNC_TEST_TOP #(
    parameter PL_LINK_CAP_MAX_LINK_WIDTH = 1, // PCIe的lane数
    parameter C_DATA_WIDTH               = 64
)(

    input            pxie_clk100m_p    ,
    input            pxie_clk100m_n    ,
    input            clk_200m_n        ,
    input            clk_200m_p        ,
    input            sys_rst_n         ,


    input            gtrefclk_p        ,   // 125M gt参考时钟
    input            gtrefclk_n        ,

    input            rxn_1              ,
    input            rxp_1              ,
    input            rxn_2              ,
    input            rxp_2              ,
    input            rxn_3              ,
    input            rxp_3              ,
    input            rxn_4              ,
    input            rxp_4              ,

    output           txn_1              ,
    output           txp_1              ,
    output           txn_2              ,
    output           txp_2              ,
    output           txn_3              ,
    output           txp_3              ,
    output           txn_4              ,
    output           txp_4              ,


    output           Link_1             ,
    output           Link_2             ,
    output           Link_3             ,
    output           Link_4             ,
    output           SFP1_TX_DISABLE    ,
    output           SFP2_TX_DISABLE    ,
    output           SFP3_TX_DISABLE    ,
    output           SFP4_TX_DISABLE    ,
    output           board_time_pulse   ,
    inout            trig               ,

    //CPU interface
    output [(PL_LINK_CAP_MAX_LINK_WIDTH - 1) : 0]    pci_exp_txp ,
    output [(PL_LINK_CAP_MAX_LINK_WIDTH - 1) : 0]    pci_exp_txn ,
    input  [(PL_LINK_CAP_MAX_LINK_WIDTH - 1) : 0]    pci_exp_rxp ,
    input  [(PL_LINK_CAP_MAX_LINK_WIDTH - 1) : 0]    pci_exp_rxn ,

    input            pci_clk_p           ,   // PCIe链路同步时钟 100MHz差分
    input            pci_clk_n           ,   // PCIe链路同步时钟 100MHz差分
    input            pci_rst_n           ,   // PCIe链路低电平复位

    input            GA_0               ,
    input            GA_1               ,
    input            GA_2               ,
    input            GA_3               ,
    input            GA_4               ,
    //DDR3 interface
    // Inouts
    inout [63:0]       ddr3_dq,
    inout [7:0]        ddr3_dqs_n,
    inout [7:0]        ddr3_dqs_p,
   
    // Outputs
    output [14:0]      ddr3_addr,
    output [2:0]       ddr3_ba,
    output             ddr3_ras_n,
    output             ddr3_cas_n,
    output             ddr3_we_n,
    output             ddr3_reset_n,
    output [0:0]       ddr3_ck_p,
    output [0:0]       ddr3_ck_n,
    output [0:0]       ddr3_cke,
    output [0:0]       ddr3_cs_n,
    output [7:0]       ddr3_dm,
    output [0:0]       ddr3_odt

    // //同步脉冲
    // output sync_pulse    
        
);

wire          wen_sys   ;
wire  [31:0]  waddr_sys ;
wire  [31:0]  wdata_sys ;
wire          ren_sys   ;
wire  [31:0]  raddr_sys ;
wire  [31:0]  rdata_sys ;
wire          rvalid_sys;

wire          wen_phy   ;
wire  [31:0]  waddr_phy ;
wire  [31:0]  wdata_phy ;

wire pulse;

wire  [3:0]  timestamp_tx_Pdelay_valid_cdc;
wire  [3:0]  timestamp_tx_Sync_valid_cdc  ;
wire  [3:0]  timestamp_tx_Presp_valid_cdc ;
wire  [3:0]  timestamp_rx_Pdelay_valid_cdc;
wire  [3:0]  timestamp_rx_Sync_valid_cdc  ;
wire  [3:0]  timestamp_rx_Presp_valid_cdc ;
wire  [3:0]  timestamp_rx_Sync_follow_valid_cdc ;
wire  [3:0]  timestamp_rx_Presp_follow_valid_cdc;
wire  [3:0]  timestamp_rx_Announce_valid_cdc    ;

wire  [7:0]   gmii_rxd_1_mac  ;
wire          gmii_rx_dv_1_mac;
wire  [7:0]   gmii_txd_1_mac  ;
wire          gmii_tx_en_1_mac;
wire  [7:0]   gmii_rxd_2_mac  ;
wire          gmii_rx_dv_2_mac;
wire  [7:0]   gmii_txd_2_mac  ;
wire          gmii_tx_en_2_mac;
wire  [7:0]   gmii_rxd_3_mac  ;
wire          gmii_rx_dv_3_mac;
wire  [7:0]   gmii_txd_3_mac  ;
wire          gmii_tx_en_3_mac;
wire  [7:0]   gmii_rxd_4_mac  ;
wire          gmii_rx_dv_4_mac;
wire  [7:0]   gmii_txd_4_mac  ;
wire          gmii_tx_en_4_mac;

wire ui_clk;
wire clk_125M;
wire userclk2_out;
wire [31:0] ga_data_in;   //板卡位置信息输入
assign ga_data_in = {26'b0, GA_4, GA_3, GA_2, GA_1, GA_0};

//axis上报
wire [C_DATA_WIDTH-1:0]      s_axis_c2h_tdata_0 ;
wire                         s_axis_c2h_tlast_0 ;
wire                         s_axis_c2h_tvalid_0;
wire                         s_axis_c2h_tready_0;
wire [C_DATA_WIDTH/8-1:0]    s_axis_c2h_tkeep_0 ;

wire [C_DATA_WIDTH-1:0]      s_axis_c2h_tdata_1 ;
wire                         s_axis_c2h_tlast_1 ;
wire                         s_axis_c2h_tvalid_1;
wire                         s_axis_c2h_tready_1;
wire [C_DATA_WIDTH/8-1:0]    s_axis_c2h_tkeep_1 ;

wire   card_upload_ren_1 ;
wire   card_upload_flag_1;

CPU_INTERFACE_TOP #(
    .PL_LINK_CAP_MAX_LINK_WIDTH(1)  // PCIe的lane数
) U_CPU_INTERFACE_TOP (
    .pci_exp_txp    (pci_exp_txp),
    .pci_exp_txn    (pci_exp_txn),
    .pci_exp_rxp    (pci_exp_rxp),
    .pci_exp_rxn    (pci_exp_rxn),
    
    .sys_clk_p      (pci_clk_p  ),
    .sys_clk_n      (pci_clk_n  ),
    .ui_clk         (ui_clk     ),
    .sys_rst_n      (pci_rst_n  ),
    
    .pcie_core_clk  (pcie_core_clk   ),//o
    .pcie_core_rstn (pcie_core_rstn  ),//o
    .pcie_link_up   (pcie_core_linkup),//o
        
    .clk            (clk_125M    ),//i
    .userclk2_out   (userclk2_out),

    .wen_sys        (wen_sys     ),//o
    .waddr_sys      (waddr_sys   ),//o
    .wdata_sys      (wdata_sys   ),//o
    .ren_sys        (ren_sys     ),//o
    .raddr_sys      (raddr_sys   ),//o
    .rdata_sys      (rdata_sys   ),//i
    .rvalid_sys     (rvalid_sys  ),//i

    //PHY时钟域下的配置
    .wen_phy        (wen_phy     ),
    .waddr_phy      (waddr_phy   ),
    .wdata_phy      (wdata_phy   ),

    .s_axis_c2h_tdata_0     (s_axis_c2h_tdata_0 ),
    .s_axis_c2h_tlast_0     (s_axis_c2h_tlast_0 ),
    .s_axis_c2h_tvalid_0    (s_axis_c2h_tvalid_0),
    .s_axis_c2h_tready_0    (s_axis_c2h_tready_0),
    .s_axis_c2h_tkeep_0     (s_axis_c2h_tkeep_0 ),

    .s_axis_c2h_tdata_1     (s_axis_c2h_tdata_1 ),
    .s_axis_c2h_tlast_1     (s_axis_c2h_tlast_1 ),
    .s_axis_c2h_tvalid_1    (s_axis_c2h_tvalid_1),
    .s_axis_c2h_tready_1    (s_axis_c2h_tready_1),
    .s_axis_c2h_tkeep_1     (s_axis_c2h_tkeep_1 )
);

GMII_top inst_GMII_top(
    .sys_clk_p    (pxie_clk100m_p   ), // 100M
    .sys_clk_n    (pxie_clk100m_n   ),
   
    .gtrefclk_p   (gtrefclk_p       ), // 125M
    .gtrefclk_n   (gtrefclk_n       ),
   
    .clk_200m_n   (clk_200m_n       ), // 200M
    .clk_200m_p   (clk_200m_p       ),
    .ui_clk       (ui_clk           ),
   
    .rst_n        (sys_rst_n        ),

    .rxn_1        (rxn_1            ),
    .rxp_1        (rxp_1            ),        
    .rxn_2        (rxn_2            ),
    .rxp_2        (rxp_2            ),
    .rxn_3        (rxn_3            ),
    .rxp_3        (rxp_3            ),        
    .rxn_4        (rxn_4            ),
    .rxp_4        (rxp_4            ),
            
    .txn_1        (txn_1            ),
    .txp_1        (txp_1            ),       
    .txn_2        (txn_2            ),
    .txp_2        (txp_2            ),
    .txn_3        (txn_3            ),
    .txp_3        (txp_3            ),       
    .txn_4        (txn_4            ),
    .txp_4        (txp_4            ),
    .Link_1       (Link_1           ),
    .Link_2       (Link_2           ),
    .Link_3       (Link_3           ),
    .Link_4       (Link_4           ),
    .clk_125M     (clk_125M         ),   //用户时钟
    .userclk2_out (userclk2_out     ),   //物理层时钟
    .gmii_txd_A   (gmii_txd_1_mac   ),
    .gmii_tx_en_A (gmii_tx_en_1_mac ),
    .gmii_txd_B   (gmii_txd_2_mac   ),
    .gmii_tx_en_B (gmii_tx_en_2_mac ),
    .gmii_txd_C   (gmii_txd_3_mac   ),
    .gmii_tx_en_C (gmii_tx_en_3_mac ),
    .gmii_txd_D   (gmii_txd_4_mac   ),
    .gmii_tx_en_D (gmii_tx_en_4_mac ),

    .gmii_rxd_A   (gmii_rxd_1_mac   ),
    .gmii_rx_en_A (gmii_rx_dv_1_mac ),
    .gmii_rxd_B   (gmii_rxd_2_mac   ),
    .gmii_rx_en_B (gmii_rx_dv_2_mac ),
    .gmii_rxd_C   (gmii_rxd_3_mac   ),
    .gmii_rx_en_C (gmii_rx_dv_3_mac ),
    .gmii_rxd_D   (gmii_rxd_4_mac   ),
    .gmii_rx_en_D (gmii_rx_dv_4_mac ),

    //配置逻辑
    .wen_phy      (wen_phy          ),
    .waddr_phy    (waddr_phy        ),
    .wdata_phy    (wdata_phy        ),

    //时戳统计
    .timestamp_tx_Pdelay_valid_cdc      (timestamp_tx_Pdelay_valid_cdc      ),
    .timestamp_tx_Sync_valid_cdc        (timestamp_tx_Sync_valid_cdc        ),
    .timestamp_tx_Presp_valid_cdc       (timestamp_tx_Presp_valid_cdc       ),
    .timestamp_rx_Pdelay_valid_cdc      (timestamp_rx_Pdelay_valid_cdc      ),
    .timestamp_rx_Sync_valid_cdc        (timestamp_rx_Sync_valid_cdc        ),
    .timestamp_rx_Presp_valid_cdc       (timestamp_rx_Presp_valid_cdc       ),
    .timestamp_rx_Sync_follow_valid_cdc (timestamp_rx_Sync_follow_valid_cdc ),
    .timestamp_rx_Presp_follow_valid_cdc(timestamp_rx_Presp_follow_valid_cdc),
    .timestamp_rx_Announce_valid_cdc    (timestamp_rx_Announce_valid_cdc    ),

    //数据上报
    .m_axis_up_load_data1               (s_axis_c2h_tdata_1                 ),
    .m_axis_up_load_last1               (s_axis_c2h_tlast_1                 ),
    .m_axis_up_load_valid1              (s_axis_c2h_tvalid_1                ),
    .m_axis_up_load_ready1              (s_axis_c2h_tready_1                ),
    .m_axis_up_load_keep1               (s_axis_c2h_tkeep_1                 ),
    .card_upload_ren_1                  (card_upload_ren_1                  ),
    .card_upload_flag_1                 (card_upload_flag_1                 ),

    //DDR3 interface
    .ddr3_dq                            (ddr3_dq                            ),
    .ddr3_dqs_n                         (ddr3_dqs_n                         ),
    .ddr3_dqs_p                         (ddr3_dqs_p                         ),
    .ddr3_addr                          (ddr3_addr                          ),
    .ddr3_ba                            (ddr3_ba                            ),
    .ddr3_ras_n                         (ddr3_ras_n                         ),
    .ddr3_cas_n                         (ddr3_cas_n                         ),
    .ddr3_we_n                          (ddr3_we_n                          ),
    .ddr3_reset_n                       (ddr3_reset_n                       ),
    .ddr3_ck_p                          (ddr3_ck_p                          ),
    .ddr3_ck_n                          (ddr3_ck_n                          ),
    .ddr3_cke                           (ddr3_cke                           ),
    .ddr3_cs_n                          (ddr3_cs_n                          ),
    .ddr3_dm                            (ddr3_dm                            ),
    .ddr3_odt                           (ddr3_odt                           )
);


TSN_802_TestCenter_Top U_TSN_802_TestCenter_Top(
    .clk                                        (clk_125M                           ),
    .rst_n                                      (sys_rst_n                          ),
    .pulse                                      (pulse                              ),
    .gmii_rxd0                                  (gmii_rxd_1_mac                     ),
    .gmii_rx_en0                                (gmii_rx_dv_1_mac                   ),
    .gmii_txd0                                  (gmii_txd_1_mac                     ),
    .gmii_tx_en0                                (gmii_tx_en_1_mac                   ),
    .gmii_rxd1                                  (gmii_rxd_2_mac                     ),
    .gmii_rx_en1                                (gmii_rx_dv_2_mac                   ),
    .gmii_txd1                                  (gmii_txd_2_mac                     ),
    .gmii_tx_en1                                (gmii_tx_en_2_mac                   ),
    .gmii_rxd2                                  (gmii_rxd_3_mac                     ),
    .gmii_rx_en2                                (gmii_rx_dv_3_mac                   ),
    .gmii_txd2                                  (gmii_txd_3_mac                     ),
    .gmii_tx_en2                                (gmii_tx_en_3_mac                   ),
    .gmii_rxd3                                  (gmii_rxd_4_mac                     ),
    .gmii_rx_en3                                (gmii_rx_dv_4_mac                   ),
    .gmii_txd3                                  (gmii_txd_4_mac                     ),
    .gmii_tx_en3                                (gmii_tx_en_4_mac                   ),
    .wen_sys                                    (wen_sys                            ),
    .waddr_sys                                  (waddr_sys                          ),
    .wdata_sys                                  (wdata_sys                          ),
    .ren_sys                                    (ren_sys                            ),
    .raddr_sys                                  (raddr_sys                          ),
    .rdata_sys                                  (rdata_sys                          ),
    .rvalid_sys                                 (rvalid_sys                         ),
    .ga_data_in                                 (ga_data_in                         ),

    //AXIS测试数据上报              
    .s_axis_c2h_tdata_1                         (s_axis_c2h_tdata_0                 ),
    .s_axis_c2h_tlast_1                         (s_axis_c2h_tlast_0                 ),
    .s_axis_c2h_tvalid_1                        (s_axis_c2h_tvalid_0                ),
    .s_axis_c2h_tready_1                        (s_axis_c2h_tready_0                ),
    .s_axis_c2h_tkeep_1                         (s_axis_c2h_tkeep_0                 ),
    .card_upload_ren_1                          (card_upload_ren_1                  ),
    .card_upload_flag_1                         (card_upload_flag_1                 ),

    //同步脉冲              
    .sync_pulse                                 (sync_pulse                         ), 

    //时间戳
    .timestamp_tx_Pdelay_valid_cdc              (timestamp_tx_Pdelay_valid_cdc      ),
    .timestamp_tx_Sync_valid_cdc                (timestamp_tx_Sync_valid_cdc        ),
    .timestamp_tx_Presp_valid_cdc               (timestamp_tx_Presp_valid_cdc       ),
    .timestamp_rx_Pdelay_valid_cdc              (timestamp_rx_Pdelay_valid_cdc      ),
    .timestamp_rx_Sync_valid_cdc                (timestamp_rx_Sync_valid_cdc        ),
    .timestamp_rx_Presp_valid_cdc               (timestamp_rx_Presp_valid_cdc       ),
    .timestamp_rx_Sync_follow_valid_cdc         (timestamp_rx_Sync_follow_valid_cdc ),
    .timestamp_rx_Presp_follow_valid_cdc        (timestamp_rx_Presp_follow_valid_cdc),
    .timestamp_rx_Announce_valid_cdc            (timestamp_rx_Announce_valid_cdc    ) 

);


board_local_time U_board_local_time(
    .clk                                        (clk_125M ),
    .rst_n                                      (sys_rst_n),
    .wen                                        (wen_sys  ),
    .waddr                                      (waddr_sys),
    .wdata                                      (wdata_sys),
    .trig                                       (trig     ),
    .board_time_pulse                           (pulse    )
);


endmodule
