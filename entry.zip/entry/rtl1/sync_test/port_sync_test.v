`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/06/16 16:40:24
// Design Name: 
// Module Name: port_sync_test
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module port_sync_test(
    input                                 clk                                ,
    input                                 rst_n                              ,
    input                                 port_en                            ,
    input                                 port_reset                         ,
    output                                port_test_done                     ,
    input  [1:0]                          port_num                           , 
    input  [1:0]                          port_mode                          ,
    input  [63:0]                         test_time                          ,
    input                                 testing                            ,
    input                                 test_rst                           ,

    // 数据帧接收/发送
    input  [7:0]                          gmii_rxd                           ,
    input                                 gmii_rx_en                         ,
    output [7:0]                          gmii_txd                           ,
    output                                gmii_tx_en                         ,
    
    // 表项管理 
    input                                 port_wen                           ,
    input  [31:0]                         port_wdata                         ,
    
    // OC端配置
    input  [7:0]                          oc_Priority1                       ,
    input  [7:0]                          oc_clockClass                      ,
    input  [7:0]                          oc_clockAccuracy                   ,
    input  [15:0]                         oc_offsetScaledLogVariance         ,
    input  [7:0]                          oc_Priority2                       ,
    input  [63:0]                         oc_clockIdentity                   ,
    input  [7:0]                          oc_LogInterval_sync                ,
    input  [7:0]                          oc_LogInterval_pdelay              ,
    input  [7:0]                          oc_LogInterval_announce            ,
    input  [31:0]                         oc_error_time                      ,
    input  [31:0]                         oc_error_type                      ,
    
    // 同步脉冲
    output                                sync_pulse                         ,

    // 上报信息
    input                                 frame_info_rd_en                   ,
    output                                frame_info_empty                   ,
    output [383:0]                        upload_frame_info                  ,

    // 上报OC寄存器
    output [31:0]                         upload_port_state                  , 
    output [31:0]                         upload_sys_time_ns                 , 
    output [31:0]                         upload_offset                      ,       
    output [31:0]                         upload_delay                       ,
    
    // 帧时间间隔上报
    output [31:0]                         sync_interval                      ,
    output [31:0]                         announce_interval                  ,
    output [31:0]                         pdelay_interval                    ,
    output [31:0]                         pdelay_resp_interval               ,
    
    //监听错误上报
    output [7:0]                          monitior_error                     ,

    // 时间戳脉冲
    input                                 timestamp_tx_Pdelay_valid_cdc      ,
    input                                 timestamp_tx_Sync_valid_cdc        ,
    input                                 timestamp_tx_Presp_valid_cdc       ,
    input                                 timestamp_rx_Pdelay_valid_cdc      ,
    input                                 timestamp_rx_Sync_valid_cdc        ,
    input                                 timestamp_rx_Presp_valid_cdc       ,
    input                                 timestamp_rx_Sync_follow_valid_cdc ,
    input                                 timestamp_rx_Presp_follow_valid_cdc,
    input                                 timestamp_rx_Announce_valid_cdc    
);

//---------------------------------------------------------
// 内部连线声明
//---------------------------------------------------------
// 输入分流
wire [7:0]   rxd_to_test;
wire         rx_en_to_test;
wire [7:0]   rxd_to_oc;
wire         rx_en_to_oc;

// 输出仲裁
wire [7:0]   txd_from_test;
wire         tx_en_from_test;
wire [7:0]   txd_from_oc;
wire         tx_en_from_oc;

// 接收上报
reg  [7:0]   rxd_to_upload;
reg          rx_en_to_upload;

// 表项配置
wire [47:0]  port_Des_Mac;
wire [47:0]  port_Src_Mac;
wire [3:0]   port_MsgType;
wire [7:0]   port_DominNumber;
wire [15:0]  port_FlagField;
wire [63:0]  port_CorrectionField;
wire [79:0]  port_PortIdentity;
wire [7:0]   port_LogMsgInterval;
wire [15:0]  port_CurrentUtcOffset;
wire [7:0]   port_Priority1;
wire [31:0]  port_ClockQuality;
wire [7:0]   port_Priority2;
wire [63:0]  port_ClockIdentity;
wire [15:0]  port_StepsRemoved;
wire [7:0]   port_TimeSource;
wire [79:0]  port_Pdelay_PortIdentity;

// 错帧生成
wire [63:0]  test_start_time;
wire [31:0]  package_correct_num;
wire [31:0]  package_error_num;
wire [31:0]  package_IFG;
wire [31:0]  error_code;

// 其他控制线
wire         table_rd;
wire         table_finish;
wire [79:0]  sys_time;
wire [3:0]   port_Op_Index; // 判断是否要开启 monitor

// 组合逻辑赋值,确保测试时间结束之后不会再进行上报
always@(*)begin
    if(rx_en_to_test)begin
        rxd_to_upload   = rxd_to_test;
        rx_en_to_upload = rx_en_to_test;
    end
    else if(rx_en_to_oc)begin
        rxd_to_upload   = rxd_to_oc;
        rx_en_to_upload = rx_en_to_oc;
    end
    else begin
        rxd_to_upload   = 8'b0;
        rx_en_to_upload = 1'b0;
    end
end

//---------------------------------------------------------
// 子模块例化
//---------------------------------------------------------

// 1. 输入分流模块
input_select U_input_select(
    .clk                                  (clk                                  ),
    .rst_n                                (rst_n                                ),
    .port_mode                            (port_mode                            ),
    .testing                              (testing                              ),
    .gmii_rxd                             (gmii_rxd                             ),
    .gmii_rx_en                           (gmii_rx_en                           ),
    .rxd_to_test                          (rxd_to_test                          ),
    .rx_en_to_test                        (rx_en_to_test                        ),
    .rxd_to_oc                            (rxd_to_oc                            ),
    .rx_en_to_oc                          (rx_en_to_oc                          )
);      

// 2. 802.1AS OC 协议栈顶层
oc_top U_oc_top(
    .clk                                  (clk                                  ),
    .rst_n                                (rst_n  & !test_rst                   ),
    .port_num                             (port_num                             ),
    .test_time                            (test_time                            ),
    .gmii_rxd                             (rxd_to_oc                            ),
    .gmii_rx_dv                           (rx_en_to_oc                          ),
    .gmii_txd                             (txd_from_oc                          ),
    .gmii_tx_en                           (tx_en_from_oc                        ),

    .Priority1                            (oc_Priority1                         ),
    .clockClass                           (oc_clockClass                        ),
    .clockAccuracy                        (oc_clockAccuracy                     ),
    .offsetScaledLogVariance              (oc_offsetScaledLogVariance           ),
    .Priority2                            (oc_Priority2                         ),
    .clockIdentity                        (oc_clockIdentity                     ),
    .LogInterval_sync                     (oc_LogInterval_sync                  ),
    .LogInterval_pdelay                   (oc_LogInterval_pdelay                ),
    .LogInterval_announce                 (oc_LogInterval_announce              ),
    .oc_error_time                        (oc_error_time                        ),
    .oc_error_type                        (oc_error_type                        ),

    .sys_sync                             (sys_sync                             ), 
    .sys_time                             (sys_time                             ),
    .upload_port_state                    (upload_port_state                    ),
    .upload_sys_time_ns                   (upload_sys_time_ns                   ),
    .upload_offset                        (upload_offset                        ),     
    .upload_delay                         (upload_delay                         ),      
    .sync_pulse                           (sync_pulse                           ),

    .timestamp_tx_Pdelay_valid_cdc        (timestamp_tx_Pdelay_valid_cdc        ),
    .timestamp_tx_Sync_valid_cdc          (timestamp_tx_Sync_valid_cdc          ),
    .timestamp_tx_Presp_valid_cdc         (timestamp_tx_Presp_valid_cdc         ),
    .timestamp_rx_Pdelay_valid_cdc        (timestamp_rx_Pdelay_valid_cdc        ),
    .timestamp_rx_Sync_valid_cdc          (timestamp_rx_Sync_valid_cdc          ),
    .timestamp_rx_Presp_valid_cdc         (timestamp_rx_Presp_valid_cdc         )
);

// 3. 测试模式监视器 
test_mode_monitor u_test_mode_monitor (
    .clk                                  (clk                                  ),
    .rst_n                                (rst_n & !test_rst                    ),
    .port_Op_Index                        (port_Op_Index                        ), // 来自 table_control 的解析输出
    .test_time                            (test_time                            ), // 顶层输入的全局测试时间
    .port_Test_start_time                 (test_start_time                      ), // 来自 table_control 解析的错帧/优帧发送时间
    .table_finish                         (table_finish                         ), // 来自 table_control 的单拍有效脉冲
    .testing                              (testing                              ), // 顶层输入的全局测试窗口使能
    .rxd_to_test                          (rxd_to_test                          ), // 来自 input_select 的 MAC 数据
    .rx_en_to_test                        (rx_en_to_test                        ), // 来自 input_select 的 MAC 使能
    .monitior_error                       (monitior_error                       )  // 输出的错误码
);

// 4. 测试帧生成器
test_frame_gen U_test_frame_gen(
    .clk                                  (clk                                  ),
    .rst_n                                (rst_n & !test_rst                    ),
    .test_rst                             (port_reset                           ),  
    .test_time                            (test_time                            ), 
    .table_finish                         (table_finish                         ),

    .port_des_mac                         (port_Des_Mac                         ),
    .port_src_mac                         (port_Src_Mac                         ),
    .port_MsgType                         (port_MsgType                         ),
    .port_DominNumber                     (port_DominNumber                     ),
    .port_FlagField                       (port_FlagField                       ),
    .port_Correction                      (port_CorrectionField                 ),
    .port_PortIdentity                    (port_PortIdentity                    ),
    .port_LogMsgInterval                  (port_LogMsgInterval                  ),
    .port_CurrentUtcOffset                (port_CurrentUtcOffset                ),
    .port_Priority1                       (port_Priority1                       ),
    .port_clockQuailty                    (port_ClockQuality                    ),
    .port_Priority2                       (port_Priority2                       ),
    .port_clockIdentity                   (port_ClockIdentity                   ),
    .port_StepsRemoved                    (port_StepsRemoved                    ),
    .port_TimeSource                      (port_TimeSource                      ),
    .port_Pdelay_PortIdentity             (port_Pdelay_PortIdentity             ),

    .test_start_time                      (test_start_time                      ),
    .package_correct_num                  (package_correct_num                  ),
    .package_error_num                    (package_error_num                    ),
    .package_IFG                          (package_IFG                          ),
    .error_code                           (error_code                           ),
    
    .dout                                 (txd_from_test                        ),
    .dval                                 (tx_en_from_test                      ),
    .test_done                            (port_test_done                       ) // 读取下一条表项
);

// 5. 帧信息上报
upload_frame U_upload_frame(
    .clk                                  (clk                                  ),
    .rst_n                                (rst_n & !test_rst                    ),
    .port_num                             (port_num                             ),
    .rxd_to_test                          (rxd_to_upload                        ),
    .rx_en_to_test                        (rx_en_to_upload                      ),
    .frame_info_rd_en                     (frame_info_rd_en                     ),
    .frame_info_empty                     (frame_info_empty                     ),
    .upload_frame_info                    (upload_frame_info                    ),
    .port_mode                            (port_mode                            ),
    .test_time                            (test_time                            ),
    .sys_time                             (sys_time[63:0]                       ),
    .timestamp_rx_Pdelay_valid_cdc        (timestamp_rx_Pdelay_valid_cdc        ),
    .timestamp_rx_Sync_valid_cdc          (timestamp_rx_Sync_valid_cdc          ),
    .timestamp_rx_Presp_valid_cdc         (timestamp_rx_Presp_valid_cdc         ),
    .timestamp_rx_Sync_follow_valid_cdc   (timestamp_rx_Sync_follow_valid_cdc   ),
    .timestamp_rx_Presp_follow_valid_cdc  (timestamp_rx_Presp_follow_valid_cdc  ),
    .timestamp_rx_Announce_valid_cdc      (timestamp_rx_Announce_valid_cdc      )
);

// 6. 表项管理控制
table_control U_table_control(
    .clk                                  (clk                                  ),
    .rst_n                                (rst_n & !test_rst                    ),
            
    .port_wen                             (port_wen                             ),
    .port_wdata                           (port_wdata                           ),
    .table_rd                             (port_test_done                       ),
    .table_finish                         (table_finish                         ),
    
    // 表项生成
    .port_Op_Index                        (port_Op_Index                        ),
    .port_Des_Mac                         (port_Des_Mac                         ),          
    .port_Src_Mac                         (port_Src_Mac                         ),          
    .port_MsgType                         (port_MsgType                         ),          
    .port_DominNumber                     (port_DominNumber                     ),      
    .port_FlagField                       (port_FlagField                       ),        
    .port_CorrectionField                 (port_CorrectionField                 ),  
    .port_PortIdentity                    (port_PortIdentity                    ),     
    .port_LogMsgInterval                  (port_LogMsgInterval                  ),   
    .port_CurrentUtcOffset                (port_CurrentUtcOffset                ), 
    .port_Priority1                       (port_Priority1                       ),        
    .port_ClockQuality                    (port_ClockQuality                    ),     
    .port_Priority2                       (port_Priority2                       ),        
    .port_ClockIdentity                   (port_ClockIdentity                   ),    
    .port_StepsRemoved                    (port_StepsRemoved                    ),     
    .port_TimeSource                      (port_TimeSource                      ),       
    .port_Pdelay_PortIdentity             (port_Pdelay_PortIdentity             ),     
    
    // 错帧生成参数
    .port_Test_start_time                 (test_start_time                      ),
    .package_correct_num                  (package_correct_num                  ),
    .package_error_num                    (package_error_num                    ),
    .package_IFG                          (package_IFG                          ),
    .error_code                           (error_code                           )
);

// 7. 帧时间间隔统计
frame_interval U_frame_interval(
    .clk                                  (clk                                  ),
    .rst_n                                (rst_n & !test_rst                    ),
    .timestamp_rx_Sync_valid_cdc          (timestamp_rx_Sync_valid_cdc          ),
    .timestamp_rx_Pdelay_valid_cdc        (timestamp_rx_Pdelay_valid_cdc        ),
    .timestamp_rx_Announce_valid_cdc      (timestamp_rx_Announce_valid_cdc      ),
    .timestamp_tx_Pdelay_valid_cdc        (timestamp_tx_Pdelay_valid_cdc        ),
    .timestamp_rx_Presp_valid_cdc         (timestamp_rx_Presp_valid_cdc         ),
    .sync_interval                        (sync_interval                        ),
    .announce_interval                    (announce_interval                    ),
    .pdelay_interval                      (pdelay_interval                      ),
    .pdelay_resp_interval                 (pdelay_resp_interval                 )
);

// 8. 输出仲裁模块
output_select U_output_select(
    .clk                                  (clk                                  ), 
    .rst_n                                (rst_n                                ), 
    .port_mode                            (port_mode                            ), 
    .testing                              (testing                              ),
    .txd_from_test                        (txd_from_test                        ), 
    .tx_en_from_test                      (tx_en_from_test                      ), 
    .txd_from_oc                          (txd_from_oc                          ), 
    .tx_en_from_oc                        (tx_en_from_oc                        ), 
    .gmii_txd                             (gmii_txd                             ), 
    .gmii_tx_en                           (gmii_tx_en                           ) 
);

`ifdef DEBUG
ila_port_sync_test U_ila_port_sync_test (
	.clk                                  (clk                                  ), // input wire clk
	.probe0                               (testing                              ), // input wire [0:0]  probe0  
	.probe1                               (test_rst                             ) // input wire [0:0]  probe1
);
`endif

endmodule