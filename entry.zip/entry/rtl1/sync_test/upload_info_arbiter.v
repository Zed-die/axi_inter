`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module Name: upload_info_arbiter
// Description: 4-Port Round-Robin Arbiter with AXI-Stream Output (64-Byte Aligned)
//////////////////////////////////////////////////////////////////////////////////

module upload_info_arbiter(
    input                 clk,
    input                 rst_n,

    // 四个 FIFO 输入
    input      [383:0]    fifo_data0,
    input      [383:0]    fifo_data1,
    input      [383:0]    fifo_data2,
    input      [383:0]    fifo_data3,
    input                 fifo_empty0,
    input                 fifo_empty1,
    input                 fifo_empty2,
    input                 fifo_empty3,
    output reg            fifo_rd_en0,
    output reg            fifo_rd_en1,
    output reg            fifo_rd_en2,
    output reg            fifo_rd_en3,

    // AXI-Stream 输出
    input                 m_axis_tready,
    output     [63:0]     m_axis_tdata_bigend, 
    output reg            m_axis_tvalid,
    output     [7:0]      m_axis_tkeep,
    output reg            m_axis_tlast,

    input                 card_upload_ren ,
    output reg            card_upload_flag
);

    reg [1:0]   current_port;
    reg [383:0] send_data;
    reg [3:0]   word_index; // 计数 0~7
    reg [63:0]  m_axis_tdata;
    // 始终保持所有字节有效
    assign m_axis_tkeep = 8'hFF;
    assign m_axis_tdata_bigend = {m_axis_tdata[7:0], m_axis_tdata[15:8], m_axis_tdata[23:16], m_axis_tdata[31:24], m_axis_tdata[39:32], m_axis_tdata[47:40], m_axis_tdata[55:48], m_axis_tdata[63:56]};  //大小端转换

    // 状态机定义
    localparam IDLE         = 10'b00_0000_0001,
               UPLOAD_PORT1 = 10'b00_0000_0010,
               UPLOAD_PORT2 = 10'b00_0000_0100,
               UPLOAD_PORT3 = 10'b00_0000_1000,
               UPLOAD_PORT4 = 10'b00_0001_0000,
               READ_FIFO    = 10'b00_0010_0000,
               SEND_INIT    = 10'b00_0100_0000,
               SEND_STREAM  = 10'b00_1000_0000,
               WAIT         = 10'b01_0000_0000,
               NEXT_PORT    = 10'b10_0000_0000;

    reg [9:0] cstate, nstate;

    // --------------------------------------------------------
    // 1. 状态机跳转逻辑
    // --------------------------------------------------------
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            cstate <= IDLE;
        else
            cstate <= nstate; 
    end

    always @(*) begin
        case (cstate)
            IDLE: 
                nstate = UPLOAD_PORT1;

            // 轮询仲裁逻辑
            UPLOAD_PORT1 : nstate = (!fifo_empty0) ? READ_FIFO : UPLOAD_PORT2;
            UPLOAD_PORT2 : nstate = (!fifo_empty1) ? READ_FIFO : UPLOAD_PORT3;
            UPLOAD_PORT3 : nstate = (!fifo_empty2) ? READ_FIFO : UPLOAD_PORT4;
            UPLOAD_PORT4 : nstate = (!fifo_empty3) ? READ_FIFO : UPLOAD_PORT1;

            READ_FIFO : nstate = SEND_INIT;
            SEND_INIT : nstate = SEND_STREAM;
            
            SEND_STREAM: begin
                // 修改点：word_index == 7 (发送第8个字后结束，凑齐64字节)
                // 只有当握手成功(Valid & Ready)且是最后一个字时，才跳转
                if (m_axis_tvalid && m_axis_tready && word_index == 4'd7)
                    nstate = WAIT;
                else
                    nstate = SEND_STREAM;
            end

            WAIT:nstate = NEXT_PORT;  //等待card_upload_flag_1更新
  
            NEXT_PORT: begin
                if(card_upload_flag == 0)begin
                    case (current_port)
                        2'd0: nstate = UPLOAD_PORT2;
                        2'd1: nstate = UPLOAD_PORT3;
                        2'd2: nstate = UPLOAD_PORT4;
                        2'd3: nstate = UPLOAD_PORT1;
                        default: nstate = IDLE;
                    endcase 
                end
                else
                    nstate = NEXT_PORT;
            end

            default: nstate = IDLE;
        endcase
    end

    // --------------------------------------------------------
    // 2. FIFO 读使能控制
    // --------------------------------------------------------
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            fifo_rd_en0 <= 0; fifo_rd_en1 <= 0; 
            fifo_rd_en2 <= 0; fifo_rd_en3 <= 0;
        end 
        else if (nstate == READ_FIFO) begin
            fifo_rd_en0 <= (current_port == 2'b00);
            fifo_rd_en1 <= (current_port == 2'b01);
            fifo_rd_en2 <= (current_port == 2'b10);
            fifo_rd_en3 <= (current_port == 2'b11);
        end
        else begin
            fifo_rd_en0 <= 0; fifo_rd_en1 <= 0; 
            fifo_rd_en2 <= 0; fifo_rd_en3 <= 0;
        end
    end

    // --------------------------------------------------------
    // 3. 数据锁存与当前端口记录
    // --------------------------------------------------------
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            current_port <= 2'b0;
        else if (nstate == UPLOAD_PORT1) current_port <= 2'b00;
        else if (nstate == UPLOAD_PORT2) current_port <= 2'b01;
        else if (nstate == UPLOAD_PORT3) current_port <= 2'b10;
        else if (nstate == UPLOAD_PORT4) current_port <= 2'b11;
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            send_data <= 384'b0;
        end
        else if(cstate == SEND_INIT) begin
            case(current_port)
                2'b00: send_data <= fifo_data0;
                2'b01: send_data <= fifo_data1;
                2'b10: send_data <= fifo_data2;
                2'b11: send_data <= fifo_data3;
                default: send_data <= 384'b0;
            endcase
        end
    end

    // --------------------------------------------------------
    // 4. AXI-Stream 发送逻辑 (关键修复部分)
    // --------------------------------------------------------
    
    // 组合逻辑预计算下一个要发送的数据，解决时序和逻辑复杂度
    reg [63:0] next_tdata;
    always @(*) begin
        if (word_index == 4'd0) begin
            // Header: 加入 current_port 信息方便软件识别
            // {MagicNum(16),length(16) ,RESVD(30), PortID(2)}
            next_tdata = {16'hbeef, 16'h40 ,30'b0, current_port};
        end
        else if (word_index <= 4'd6) begin
            // 发送 Payload (原始数据)
            // 逻辑: 383 - (word_index-1)*64
            next_tdata = send_data[383 - (word_index-1)*64 -: 64];
        end
        else begin
            // word_index == 7: Padding (补齐到64字节)
            next_tdata = 64'b0;
        end
    end

    // 时序逻辑处理握手
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            word_index    <= 0;
            m_axis_tvalid <= 0;
            m_axis_tdata  <= 64'b0;
            m_axis_tlast  <= 0;
        end else begin
            if (cstate == SEND_STREAM) begin
                // 只有当 (1) 刚开始发送 或者 (2) 上一拍握手成功(Ready=1) 时，才更新数据
                if (!m_axis_tvalid || m_axis_tready) begin
                    m_axis_tvalid <= 1;
                    m_axis_tdata  <= next_tdata; // 加载上面组合逻辑算好的数据

                    // 处理 TLAST (当是第8个字时拉高)
                    if (word_index == 4'd7)
                        m_axis_tlast <= 1;
                    else
                        m_axis_tlast <= 0;

                    // 计数器递增 (防止溢出，虽然状态机会跳转)
                    if (word_index <= 4'd7)
                        word_index <= word_index + 1;
                end
                // 这符合 AXI 协议：Valid 拉高后数据必须保持稳定，直到 Ready 拉高。
            end
            else begin
                // 非发送状态，复位接口信号
                m_axis_tvalid <= 0;
                m_axis_tlast  <= 0;
                word_index    <= 0;
                m_axis_tdata  <= 0;
            end
        end
    end

    always@(posedge clk or negedge rst_n ) begin
        if(!rst_n)begin
            card_upload_flag <= 1'b0;
        end
        else if(card_upload_ren)begin
            card_upload_flag <= 1'b0;
        end
        else if(m_axis_tlast)begin
            card_upload_flag <= 1'b1;
        end
        else begin
            card_upload_flag <= card_upload_flag;
        end
    end


endmodule