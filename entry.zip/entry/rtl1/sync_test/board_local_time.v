`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company:XIDIAN
// Engineer:wanghaoyu 
// 
// Create Date: 2025/07/13 10:31:54
// Design Name: 
// Module Name: board_local_time
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// use to board sync
//
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

`include "../../include/cpu_define.v"
module board_local_time(
    input              clk        ,
    input              rst_n      ,
    input              wen        ,
    input     [31:0]   waddr      ,
    input     [31:0]   wdata      ,
    inout              trig       ,
    output             board_time_pulse
);

localparam PERIOD_S = 32'd125_000_000;

wire trig_self ; 
wire trig_input; 

reg [31:0] trig_cnt; 
reg  master_board_flag;  
reg  trig_f  ;
reg  trig_ff ;
wire trig_pos;
reg [31:0]  board_time_ns;
reg [47:0]  board_time_s ;
//主从板卡脉冲定义
assign trig = master_board_flag ? trig_self : 1'bz;
assign trig_input = trig;


always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        master_board_flag <= 1'b0;
    end
    else if ( wen == 1'b1 && waddr == `TESTYSNC_BOARD_MASTER && wdata == 1'b1) begin
        master_board_flag <= 1'b1;
    end
    else if ( wen == 1'b1 && waddr == `TESTYSNC_BOARD_MASTER && wdata == 1'b0) begin
        master_board_flag <= 1'b0;
    end
    else begin
        master_board_flag <= master_board_flag;
    end
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) 
        trig_cnt <= 32'd0;
    else if (trig_cnt == PERIOD_S - 32'd1)
        trig_cnt <= 32'd0;
    else
        trig_cnt <= trig_cnt + 1'd1;
end

assign trig_self = (|trig_cnt[31:2])? 1'b0 :1'b1;

always @ (posedge clk or negedge rst_n) begin
    if(!rst_n)
        trig_f <= 1'b0;
    else if(master_board_flag)
        trig_f  <= trig_self;
    else 
        trig_f  <= trig_input;
end

always @ (posedge clk or negedge rst_n) begin
    if(!rst_n)
        trig_ff <= 1'b0;
    else
        trig_ff <= trig_f;       
end

assign trig_pos = trig_f && (!trig_ff);

always @ (posedge clk or negedge rst_n) begin
    if(!rst_n)
        board_time_ns <= 32'd0;
    else if(trig_pos)
        board_time_ns <= 32'd0;
    else if(board_time_ns == PERIOD_S - 32'd1)
        board_time_ns <= 32'd0;
    else 
        board_time_ns <= board_time_ns + 1'd1;
end

assign board_time_pulse = (|board_time_ns[31:2])? 1'b0 : 1'b1;

endmodule