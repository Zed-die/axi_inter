`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module Name: table_control
// Description: 配置表项解析与分发模块 (Ver 3.0 - 88 Bytes format)
//              Total Size: 88 Bytes -> 704 Bits -> 22 Words (32-bit)
//////////////////////////////////////////////////////////////////////////////////

module table_control #(
    parameter TABLE_DEPTH = 22  // 88 Bytes = 22 Words
)(
    input          clk,
    input          rst_n,
    
    // 主机接口 (Write Side)
    input          port_wen,
    input  [31:0]  port_wdata,
    
    // 控制接口
    input          table_rd,       // 触发读取下一条表项
    output reg     table_finish,   // 当前表项解析完成标志
    
    //-------------------------------------------------------------------------
    // 解析输出接口 
    //-------------------------------------------------------------------------
    // [Header Part]
    output wire [3:0]   port_Op_Index,            // [0.5 Byte] 操作序号
    output wire [63:0]  port_Test_start_time,     // [8 Bytes]  发帧时间点 
    output wire [47:0]  port_Des_Mac,             // [6 Bytes]  目的MAC
    output wire [47:0]  port_Src_Mac,             // [6 Bytes]  源MAC
    output wire [3:0]   port_MsgType,             // [0.5 Byte] 报文类型
    output wire [7:0]   port_DominNumber,         // [1 Byte]   域号 (NEW)
    output wire [15:0]  port_FlagField,           // [2 Bytes]  标志位
    output wire [63:0]  port_CorrectionField,     // [8 Bytes]  修正域
    output wire [79:0]  port_PortIdentity,        // [10 Bytes] 端口ID
    output wire [7:0]   port_LogMsgInterval,      // [1 Byte]   发送间隔
    output wire [15:0]  port_CurrentUtcOffset,    // [2 Bytes]  UTC偏移
    output wire [7:0]   port_Priority1,           // [1 Byte]   优先级1
    output wire [31:0]  port_ClockQuality,        // [4 Bytes]  时钟质量
    output wire [7:0]   port_Priority2,           // [1 Byte]   优先级2
    output wire [63:0]  port_ClockIdentity,       // [8 Bytes]  时钟ID
    output wire [15:0]  port_StepsRemoved,        // [2 Bytes]  路径跳数
    output wire [7:0]   port_TimeSource,          // [1 Byte]   时间源
    output wire [79:0]  port_Pdelay_PortIdentity, // [10 Bytes] Pdelay端口ID 
    
    // [Control Part]
    output wire [31:0]  package_correct_num,      // [4 Bytes]  正确包数量
    output wire [31:0]  package_error_num,        // [4 Bytes]  错误包数量
    output wire [31:0]  package_IFG,              // [4 Bytes]  帧间隙
    output wire [31:0]  error_code                // [4 Bytes]  错误码
);

    //=============================================================================
    // 内部信号定义
    //=============================================================================
    localparam TOTAL_BITS = TABLE_DEPTH * 32; // 22 * 32 = 704 Bits
    
    reg [TOTAL_BITS-1:0] table_cache; 
    
    wire        fifo_empty;
    wire        fifo_full;
    wire [31:0] fifo_rdata;
    wire [9:0]  data_count;
    
    reg         rd_en;
    reg [15:0]  rd_cnt;
    reg         rd_finish;
    reg         data_valid;
    
    reg         table_init_done; 
    reg         loading_active;  
    
    //=============================================================================
    // FIFO 实例化
    //=============================================================================
    frame_table_control U_frame_table_control (
        .clk        (clk),
        .rst        (~rst_n),
        .din        (port_wdata),
        .wr_en      (port_wen),
        .rd_en      (rd_en),
        .dout       (fifo_rdata),
        .full       (fifo_full),
        .empty      (fifo_empty),
        .data_count (data_count)
    );

    //=============================================================================
    // 读取控制状态机
    //=============================================================================
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            loading_active <= 1'b0;
            table_init_done <= 1'b0;
        end else begin
            if (!table_init_done && (data_count >= TABLE_DEPTH)) begin
                loading_active <= 1'b1;
                table_init_done <= 1'b1;
            end
            else if (table_rd && (data_count >= TABLE_DEPTH)) begin
                loading_active <= 1'b1;
            end
            else if (rd_cnt == TABLE_DEPTH - 1) begin
                loading_active <= 1'b0;
            end
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            rd_en <= 1'b0;
            rd_cnt <= 16'b0;
        end else if (loading_active) begin
            rd_en <= 1'b1;
            rd_cnt <= rd_cnt + 1;
        end else begin
            rd_en <= 1'b0;
            rd_cnt <= 16'b0;
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) 
            data_valid <= 1'b0;
        else
            data_valid <= rd_en;
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            table_cache <= {TOTAL_BITS{1'b0}};
        end else if (data_valid) begin
            table_cache <= {fifo_rdata, table_cache[TOTAL_BITS - 1 : 32]};
        end
    end
    
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) 
            rd_finish <= 1'b0;
        else if (rd_cnt == TABLE_DEPTH && !loading_active) 
            rd_finish <= 1'b1;
        else 
            rd_finish <= 1'b0;
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) 
            table_finish <= 1'b0;
        else if(rd_finish)
            table_finish <= 1'b1;
        else if(table_rd)
            table_finish <= 1'b0;
    end

    //=============================================================================
    // Mapping: Little Endian Bit Stream
    //=============================================================================
    
    // [0] Op_Index (4 bits) -> [3:0]
    assign port_Op_Index        = table_cache[3:0];
    
    // [0.5] Test_start_time (64 bits) -> [67:4]
    assign port_Test_start_time = table_cache[67:4];
    
    // [8.5] Des_Mac (48 bits) -> [115:68]
    assign port_Des_Mac         = table_cache[115:68];
    
    // [14.5] Src_Mac (48 bits) -> [163:116]
    assign port_Src_Mac         = table_cache[163:116];
    
    // [20.5] Msg_Type (4 bits) -> [167:164]
    assign port_MsgType         = table_cache[167:164];
    
    // [21.0] DominNumber (8 bits) -> [175:168] **NEW**
    assign port_DominNumber     = table_cache[175:168];

    // [22.0] FlagField (16 bits) -> [191:176]
    assign port_FlagField       = table_cache[191:176];
    
    // [24.0] CorrectionField (64 bits) -> [255:192]
    assign port_CorrectionField = table_cache[255:192];
    
    // [32.0] PortIdentity (80 bits) -> [335:256]
    assign port_PortIdentity    = table_cache[335:256];
    
    // [42.0] LogMsgInterval (8 bits) -> [343:336]
    assign port_LogMsgInterval  = table_cache[343:336];
    
    // [43.0] CurrentUtcOffset (16 bits) -> [359:344]
    assign port_CurrentUtcOffset= table_cache[359:344];
    
    // [45.0] Priority1 (8 bits) -> [367:360]
    assign port_Priority1       = table_cache[367:360];
    
    // [46.0] ClockQuality (32 bits) -> [399:368]
    assign port_ClockQuality    = table_cache[399:368];
    
    // [50.0] Priority2 (8 bits) -> [407:400]
    assign port_Priority2       = table_cache[407:400];
    
    // [51.0] ClockIdentity (64 bits) -> [471:408]
    assign port_ClockIdentity   = table_cache[471:408];
    
    // [59.0] StepsRemoved (16 bits) -> [487:472]
    assign port_StepsRemoved    = table_cache[487:472];
    
    // [61.0] TimeSource (8 bits) -> [495:488]
    assign port_TimeSource      = table_cache[495:488];

    // [62.0] Pdelay_PortIdentity (80 bits) -> [575:496]
    assign port_Pdelay_PortIdentity = table_cache[575:496];
    
    // --- Header Part End (72 Bytes) ---
    // Start Bit for Control Part = 72 * 8 = 576
    
    // [72.0] package_correct_num (32 bits) -> [607:576]
    assign package_correct_num  = table_cache[607:576];
    
    // [76.0] package_error_num (32 bits) -> [639:608]
    assign package_error_num    = table_cache[639:608];
    
    // [80.0] package_IFG (32 bits) -> [671:640]
    assign package_IFG          = table_cache[671:640];
    
    // [84.0] error_code (32 bits) -> [703:672]
    assign error_code           = table_cache[703:672];

    // Total Bits Used: 704 Bits (88 Bytes)
    // TABLE_DEPTH = 22 Words = 704 Bits. (Exactly filled)

endmodule


