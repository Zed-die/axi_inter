`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/06/16 17:00:18
// Design Name: 
// Module Name: frame_gen
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

//Announce消息结构体

module frame_gen (

   input   clk  ,
   input   rst_n,
   input   Sync_en          ,
   input   Pdelay_Req_en    ,
   input   Presp_gen        ,
   input   Announce_en      ,
   input   Sync_follow_en   ,
   input   Presp_follow_gen ,
   input   crc_error        ,
   //gPTP帧头
   input   [47:0]    des_mac       ,  
   input   [47:0]    src_mac       ,
   input   [15:0]    ether_type    ,
   input   [3:0 ]    TranSpec      ,
   input   [3:0 ]    MsgType       ,
   input   [3:0 ]    VerPTP        ,
   input   [15:0]    MsgLength     ,
   input   [7:0 ]    DominNumber   ,
   input   [15:0]    FlagField     ,
   input   [63:0]    Correction    ,
   input   [79:0]    PortIdentity  ,
   input   [15:0]    SequenceID    ,
   input   [7:0 ]    ControlField  ,
   input   [7:0 ]    LogMsgInterval,
   //gPTP payload
   //Announce
   input   [15:0]    CurrentUtcOffset    ,
   input   [7:0 ]    Priority1           ,
   input   [31:0]    clockQuailty        ,
   input   [7:0 ]    Priority2           ,
   input   [63:0]    clockIdentity       ,
   input   [15:0]    StepsRemoved        ,
   input   [7:0 ]    TimeSource          ,
   //Sync_follow
   input   [79:0]    Sync_tx_timestamp   ,
   //presp & presp_follow
   input   [79:0]    Pdelay_rx_timestamp ,
   input   [79:0]    Presp_tx_timestamp  ,//三种时戳
   input   [79:0]    Pdelay_PortIdentity ,

   output  [7:0]     data_out     ,
   output            data_valid   , 
   output            sop          ,
   output            eop       

);

// 状态定义
localparam  IDLE      = 3'b001;
localparam  LOAD      = 3'b010;
localparam  SEND      = 3'b100;
localparam  Reserved1 = 4'h0;
localparam  Reserved2 = 8'h0;
localparam  Reserved3 = 32'h0;
localparam  Reserved  = 8'b0;

parameter   Preamble  = 56'h55_55_55_55_55_55_55;
parameter   SFD       = 8'hd5;


reg [2:0]   cstate;
reg [2:0]   nstate;
reg [447:0] gPTP_head;
reg [239:0] gPTP_payload;
reg [7:0]   gPTP_length;
reg [7:0]   gPTP_cnt;
reg [7:0]   dout;
reg         dval;

always @(posedge clk or negedge rst_n) begin
   if (!rst_n)
      cstate <= IDLE;
   else
      cstate <= nstate;
end
// 下一状态逻辑
always @(*) begin
   case (cstate)
      IDLE:
         if (Sync_en || Pdelay_Req_en || Presp_gen || Announce_en || Sync_follow_en || Presp_follow_gen)
               nstate = LOAD;
         else
               nstate = IDLE;
      LOAD:
               nstate = SEND;
      SEND:
         if(gPTP_cnt == gPTP_length)
               nstate = IDLE;
         else
               nstate = SEND;
      default: nstate = IDLE;
   endcase
end

// gPTP帧头加载（LOAD状态）
always @(posedge clk or negedge rst_n)begin
   if(!rst_n)begin
      gPTP_head <= 448'b0;
   end
   else if(cstate == LOAD)begin
      gPTP_head <= {Preamble,SFD,des_mac,src_mac,ether_type,TranSpec,MsgType,Reserved1,VerPTP,MsgLength,DominNumber,Reserved2,FlagField,Correction,Reserved3,PortIdentity,SequenceID,ControlField,LogMsgInterval};
   end
   else begin
      gPTP_head <= gPTP_head;
   end
end

// 帧内容,长度加载
always @(posedge clk or negedge rst_n)begin
   if(!rst_n)begin
      gPTP_payload <= 240'b0;
      gPTP_length  <= 8'b0  ;
   end
   else if(Sync_en)begin
      gPTP_payload <= 240'b0;
      gPTP_length  <= 8'd70 ;
   end
   else if(Sync_follow_en)begin
      gPTP_payload <= {Sync_tx_timestamp,160'b0};
      gPTP_length  <= 8'd70 ;
   end
   else if(Pdelay_Req_en)begin
      gPTP_payload <= 240'b0;
      gPTP_length  <= 8'd80 ;
   end
   else if(Presp_gen)begin
      gPTP_payload <= {Pdelay_rx_timestamp, Pdelay_PortIdentity, 80'b0};
      gPTP_length  <= 8'd80 ;
   end
   else if(Presp_follow_gen)begin
      gPTP_payload <= {Presp_tx_timestamp, Pdelay_PortIdentity, 80'b0};
      gPTP_length  <= 8'd80 ;
   end
   else if(Announce_en)begin
      gPTP_payload <= {80'b0,CurrentUtcOffset,Reserved,Priority1,clockQuailty,Priority2,clockIdentity,StepsRemoved,TimeSource};
      gPTP_length  <= 8'd90 ;
   end
   else begin
      gPTP_payload <= gPTP_payload;
      gPTP_length  <= gPTP_length;
   end
end

always @(posedge clk or negedge rst_n)begin
   if(!rst_n)begin
      dout <= 8'b0;
      dval <= 1'b0;
      gPTP_cnt <= 8'b0;
   end
   else if(cstate == SEND)begin
      gPTP_cnt <= gPTP_cnt + 1;
      if(gPTP_cnt < 8'd56) begin
         dout <= gPTP_head[447-8*gPTP_cnt-:8];   //发送gptp头部
         dval <= 1'b1;
      end
      else if(gPTP_cnt >= 8'd56 && gPTP_cnt < gPTP_length-8'd4)begin
         dout <= gPTP_payload[239-8*(gPTP_cnt-56)-:8];
         dval <= 1'b1;
      end
      else begin
         dout <= 8'b0;
         dval <= 1'b0;
      end
   end
   else begin
      dout <= 8'b0;
      dval <= 1'b0;
      gPTP_cnt <= 8'b0;
   end
end

wire CRC_en;
wire CRC_rd;
wire [7:0] CRC_out;
wire CRC_end;
assign sop = (gPTP_cnt == 8'd1) ?1'b1:1'b0;
assign CRC_en = dval?((gPTP_cnt >= 8'd9) ?1'b1:1'b0):1'b0;
assign CRC_rd = (gPTP_cnt >= gPTP_length-3 && gPTP_cnt <= gPTP_length) ?1'b1:1'b0;
//CRC_gen

//*********************
//INSTANTCE MODULE
//*********************
CRC_gen U_CRC_gen(
        .Reset       (~rst_n  ),
        .Clk         (clk     ),
        .Init        (1'b0    ),
        .Frame_data  (dout    ),
        .Data_en     (CRC_en  ),
        .CRC_rd      (CRC_rd  ),
        .CRC_end     (CRC_end ),
        .CRC_out     (CRC_out )
);

assign eop = CRC_end;
assign data_out=CRC_rd?(crc_error?8'b0:CRC_out):dout;
assign data_valid=dval|CRC_rd;
//*********************
//MAIN CORE
//********************* 
//*********************

endmodule