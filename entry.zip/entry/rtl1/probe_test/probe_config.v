`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module Name: probe_config
// Description: gPTP 探针故障注入配置模块 (4 Port Support)
// Base Address: 21'h08_0000
// Port Offset:  0x100 per port (P0: 0x000, P1: 0x100, P2: 0x200, P3: 0x300)
//////////////////////////////////////////////////////////////////////////////////
`include "../../include/cpu_define.v"

module probe_config(
    // --- System Interface ---
    input                   clk,
    input                   rst,

    // --- CPU / Bus Interface ---
    input                           wen_phy,
    input               [31:0]      waddr_phy,
    input               [31:0]      wdata_phy,
    input                           ren_phy,
    input               [31:0]      raddr_phy,
    output      reg     [31:0]      rdata_phy,
    output      reg                 rvalid_phy,

    // 寄存器列表
    output      reg     [1:0]       port0_mode                   ,
    output      reg     [1:0]       port1_mode                   ,
    output      reg     [1:0]       port2_mode                   ,
    output      reg     [1:0]       port3_mode                   ,  


    output      reg                 port0_probe_glb_ctrl         ,
    output      reg     [31:0]      port0_probe_fault_sel        ,
    output      reg     [47:0]      port0_probe_dmac             ,
    output      reg     [15:0]      port0_probe_ethtype          ,
    output      reg     [3:0]       port0_probe_msgtype          ,
    output      reg     [3:0]       port0_probe_transpec         ,
    output      reg     [3:0]       port0_probe_verptp           ,
    output      reg     [15:0]      port0_probe_msglength        ,
    output      reg     [7:0]       port0_probe_domainnumber     ,
    output      reg     [15:0]      port0_probe_flagfield        ,
    output      reg     [79:0]      port0_probe_sourceportid     ,
    output      reg     [15:0]      port0_probe_sequenceid       ,
    output      reg     [7:0]       port0_probe_controlfield     ,
    output      reg     [7:0]       port0_probe_logmsginterval   ,
    output      reg     [63:0]      port0_probe_correction       ,


    output      reg                 port1_probe_glb_ctrl         ,
    output      reg     [31:0]      port1_probe_fault_sel        ,
    output      reg     [47:0]      port1_probe_dmac             ,
    output      reg     [15:0]      port1_probe_ethtype          ,
    output      reg     [3:0]       port1_probe_msgtype          ,
    output      reg     [3:0]       port1_probe_transpec         ,
    output      reg     [3:0]       port1_probe_verptp           ,
    output      reg     [15:0]      port1_probe_msglength        ,
    output      reg     [7:0]       port1_probe_domainnumber     ,
    output      reg     [15:0]      port1_probe_flagfield        ,
    output      reg     [79:0]      port1_probe_sourceportid     ,
    output      reg     [15:0]      port1_probe_sequenceid       ,
    output      reg     [7:0]       port1_probe_controlfield     ,
    output      reg     [7:0]       port1_probe_logmsginterval   ,
    output      reg     [63:0]      port1_probe_correction       ,

    output      reg                 port2_probe_glb_ctrl         ,
    output      reg     [31:0]      port2_probe_fault_sel        ,
    output      reg     [47:0]      port2_probe_dmac             ,
    output      reg     [15:0]      port2_probe_ethtype          ,
    output      reg     [3:0]       port2_probe_msgtype          ,
    output      reg     [3:0]       port2_probe_transpec         ,
    output      reg     [3:0]       port2_probe_verptp           ,
    output      reg     [15:0]      port2_probe_msglength        ,
    output      reg     [7:0]       port2_probe_domainnumber     ,
    output      reg     [15:0]      port2_probe_flagfield        ,
    output      reg     [79:0]      port2_probe_sourceportid     ,
    output      reg     [15:0]      port2_probe_sequenceid       ,
    output      reg     [7:0]       port2_probe_controlfield     ,
    output      reg     [7:0]       port2_probe_logmsginterval   ,
    output      reg     [63:0]      port2_probe_correction       ,

    output      reg                 port3_probe_glb_ctrl         ,
    output      reg     [31:0]      port3_probe_fault_sel        ,
    output      reg     [47:0]      port3_probe_dmac             ,
    output      reg     [15:0]      port3_probe_ethtype          ,
    output      reg     [3:0]       port3_probe_msgtype          ,
    output      reg     [3:0]       port3_probe_transpec         ,
    output      reg     [3:0]       port3_probe_verptp           ,
    output      reg     [15:0]      port3_probe_msglength        ,
    output      reg     [7:0]       port3_probe_domainnumber     ,
    output      reg     [15:0]      port3_probe_flagfield        ,
    output      reg     [79:0]      port3_probe_sourceportid     ,
    output      reg     [15:0]      port3_probe_sequenceid       ,
    output      reg     [7:0]       port3_probe_controlfield     ,
    output      reg     [7:0]       port3_probe_logmsginterval   ,
    output      reg     [63:0]      port3_probe_correction       
);

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            // =============================================================
            // PORT 0 Probe Reset
            // =============================================================
            port0_probe_glb_ctrl        <= 1'b0;
            port0_probe_fault_sel       <= 32'h0;
            port0_probe_dmac            <= 48'h0;
            port0_probe_ethtype         <= 16'h0;
            port0_probe_msgtype         <= 4'h0;
            port0_probe_transpec        <= 4'h0;
            port0_probe_verptp          <= 4'h0;
            port0_probe_msglength       <= 16'h0;
            port0_probe_domainnumber    <= 8'h0;
            port0_probe_flagfield       <= 16'h0;
            port0_probe_sourceportid    <= 80'h0;
            port0_probe_sequenceid      <= 16'h0;
            port0_probe_controlfield    <= 8'h0;
            port0_probe_logmsginterval  <= 8'h0;
            port0_probe_correction      <= 64'h0;
            // =============================================================
            // PORT 1 Probe Reset
            // =============================================================
            port1_probe_glb_ctrl        <= 1'b0;
            port1_probe_fault_sel       <= 32'h0;
            port1_probe_dmac            <= 48'h0;
            port1_probe_ethtype         <= 16'h0;
            port1_probe_msgtype         <= 4'h0;
            port1_probe_transpec        <= 4'h0;
            port1_probe_verptp          <= 4'h0;
            port1_probe_msglength       <= 16'h0;
            port1_probe_domainnumber    <= 8'h0;
            port1_probe_flagfield       <= 16'h0;
            port1_probe_sourceportid    <= 80'h0;
            port1_probe_sequenceid      <= 16'h0;
            port1_probe_controlfield    <= 8'h0;
            port1_probe_logmsginterval  <= 8'h0;
            port1_probe_correction      <= 64'h0;

            // =============================================================
            // PORT 2 Probe Reset
            // =============================================================
            port2_probe_glb_ctrl        <= 1'b0;
            port2_probe_fault_sel       <= 32'h0;
            port2_probe_dmac            <= 48'h0;
            port2_probe_ethtype         <= 16'h0;
            port2_probe_msgtype         <= 4'h0;
            port2_probe_transpec        <= 4'h0;
            port2_probe_verptp          <= 4'h0;
            port2_probe_msglength       <= 16'h0;
            port2_probe_domainnumber    <= 8'h0;
            port2_probe_flagfield       <= 16'h0;
            port2_probe_sourceportid    <= 80'h0;
            port2_probe_sequenceid      <= 16'h0;
            port2_probe_controlfield    <= 8'h0;
            port2_probe_logmsginterval  <= 8'h0;
            port2_probe_correction      <= 64'h0;

            // =============================================================
            // PORT 3 Probe Reset
            // =============================================================
            port3_probe_glb_ctrl        <= 1'b0;
            port3_probe_fault_sel       <= 32'h0;
            port3_probe_dmac            <= 48'h0;
            port3_probe_ethtype         <= 16'h0;
            port3_probe_msgtype         <= 4'h0;
            port3_probe_transpec        <= 4'h0;
            port3_probe_verptp          <= 4'h0;
            port3_probe_msglength       <= 16'h0;
            port3_probe_domainnumber    <= 8'h0;
            port3_probe_flagfield       <= 16'h0;
            port3_probe_sourceportid    <= 80'h0;
            port3_probe_sequenceid      <= 16'h0;
            port3_probe_controlfield    <= 8'h0;
            port3_probe_logmsginterval  <= 8'h0;
            port3_probe_correction      <= 64'h0;
        end
        else if (wen_phy == 1'b1) begin
            case (waddr_phy)
                // =============================================================
                // PORT 0 Probe Fault Injection Registers
                // =============================================================
                `PORT0_PROBE_GLB_CTRL           :port0_probe_glb_ctrl             <= wdata_phy[0];
                `PORT0_PROBE_FAULT_SEL          :port0_probe_fault_sel            <= wdata_phy[31:0];
                `PORT0_PROBE_DMAC_HI            :port0_probe_dmac[47:16]          <= wdata_phy[31:0];
                `PORT0_PROBE_DMAC_LO            :port0_probe_dmac[15:0]           <= wdata_phy[15:0];
                `PORT0_PROBE_ETHTYPE            :port0_probe_ethtype              <= wdata_phy[15:0];
                `PORT0_PROBE_MSGTYPE            :port0_probe_msgtype              <= wdata_phy[3:0 ];
                `PORT0_PROBE_TRANSPEC           :port0_probe_transpec             <= wdata_phy[3:0 ];
                `PORT0_PROBE_VERPTP             :port0_probe_verptp               <= wdata_phy[3:0 ];
                `PORT0_PROBE_MSGLENGTH          :port0_probe_msglength            <= wdata_phy[15:0];
                `PORT0_PROBE_DOMAINNUMBER       :port0_probe_domainnumber         <= wdata_phy[7:0 ];
                `PORT0_PROBE_FLAGFIELD          :port0_probe_flagfield            <= wdata_phy[15:0];
                `PORT0_PROBE_SOURCEPORTID_HI    :port0_probe_sourceportid[79:48]  <= wdata_phy[31:0];
                `PORT0_PROBE_SOURCEPORTID_MI    :port0_probe_sourceportid[47:16]  <= wdata_phy[31:0];
                `PORT0_PROBE_SOURCEPORTID_LO    :port0_probe_sourceportid[15:0 ]  <= wdata_phy[15:0];
                `PORT0_PROBE_SEQUENCEID         :port0_probe_sequenceid           <= wdata_phy[15:0];
                `PORT0_PROBE_CONTROLFIELD       :port0_probe_controlfield         <= wdata_phy[7:0 ];
                `PORT0_PROBE_LOGMSGINTERVAL     :port0_probe_logmsginterval       <= wdata_phy[7:0 ];
                `PORT0_PROBE_CORRECTION_HI      :port0_probe_correction[63:32]    <= wdata_phy[31:0];
                `PORT0_PROBE_CORRECTION_LO      :port0_probe_correction[31:0 ]    <= wdata_phy[31:0];

                // =============================================================
                // PORT 1 Probe Fault Injection Registers
                // =============================================================
                `PORT1_PROBE_GLB_CTRL           :port1_probe_glb_ctrl             <= wdata_phy[0];
                `PORT1_PROBE_FAULT_SEL          :port1_probe_fault_sel            <= wdata_phy[31:0];
                `PORT1_PROBE_DMAC_HI            :port1_probe_dmac[47:16]          <= wdata_phy[31:0];
                `PORT1_PROBE_DMAC_LO            :port1_probe_dmac[15:0]           <= wdata_phy[15:0];
                `PORT1_PROBE_ETHTYPE            :port1_probe_ethtype              <= wdata_phy[15:0];
                `PORT1_PROBE_MSGTYPE            :port1_probe_msgtype              <= wdata_phy[3:0 ];
                `PORT1_PROBE_TRANSPEC           :port1_probe_transpec             <= wdata_phy[3:0 ];
                `PORT1_PROBE_VERPTP             :port1_probe_verptp               <= wdata_phy[3:0 ];
                `PORT1_PROBE_MSGLENGTH          :port1_probe_msglength            <= wdata_phy[15:0];
                `PORT1_PROBE_DOMAINNUMBER       :port1_probe_domainnumber         <= wdata_phy[7:0 ];
                `PORT1_PROBE_FLAGFIELD          :port1_probe_flagfield            <= wdata_phy[15:0];
                `PORT1_PROBE_SOURCEPORTID_HI    :port1_probe_sourceportid[79:48]  <= wdata_phy[31:0];
                `PORT1_PROBE_SOURCEPORTID_MI    :port1_probe_sourceportid[47:16]  <= wdata_phy[31:0];
                `PORT1_PROBE_SOURCEPORTID_LO    :port1_probe_sourceportid[15:0 ]  <= wdata_phy[15:0];
                `PORT1_PROBE_SEQUENCEID         :port1_probe_sequenceid           <= wdata_phy[15:0];
                `PORT1_PROBE_CONTROLFIELD       :port1_probe_controlfield         <= wdata_phy[7:0 ];
                `PORT1_PROBE_LOGMSGINTERVAL     :port1_probe_logmsginterval       <= wdata_phy[7:0 ];
                `PORT1_PROBE_CORRECTION_HI      :port1_probe_correction[63:32]    <= wdata_phy[31:0];
                `PORT1_PROBE_CORRECTION_LO      :port1_probe_correction[31:0 ]    <= wdata_phy[31:0];

                // =============================================================
                // PORT 2 Probe Fault Injection Registers
                // =============================================================
                `PORT2_PROBE_GLB_CTRL           :port2_probe_glb_ctrl             <= wdata_phy[0];
                `PORT2_PROBE_FAULT_SEL          :port2_probe_fault_sel            <= wdata_phy[31:0];
                `PORT2_PROBE_DMAC_HI            :port2_probe_dmac[47:16]          <= wdata_phy[31:0];
                `PORT2_PROBE_DMAC_LO            :port2_probe_dmac[15:0]           <= wdata_phy[15:0];
                `PORT2_PROBE_ETHTYPE            :port2_probe_ethtype              <= wdata_phy[15:0];
                `PORT2_PROBE_MSGTYPE            :port2_probe_msgtype              <= wdata_phy[3:0 ];
                `PORT2_PROBE_TRANSPEC           :port2_probe_transpec             <= wdata_phy[3:0 ];
                `PORT2_PROBE_VERPTP             :port2_probe_verptp               <= wdata_phy[3:0 ];
                `PORT2_PROBE_MSGLENGTH          :port2_probe_msglength            <= wdata_phy[15:0];
                `PORT2_PROBE_DOMAINNUMBER       :port2_probe_domainnumber         <= wdata_phy[7:0 ];
                `PORT2_PROBE_FLAGFIELD          :port2_probe_flagfield            <= wdata_phy[15:0];
                `PORT2_PROBE_SOURCEPORTID_HI    :port2_probe_sourceportid[79:48]  <= wdata_phy[31:0];
                `PORT2_PROBE_SOURCEPORTID_MI    :port2_probe_sourceportid[47:16]  <= wdata_phy[31:0];
                `PORT2_PROBE_SOURCEPORTID_LO    :port2_probe_sourceportid[15:0 ]  <= wdata_phy[15:0];
                `PORT2_PROBE_SEQUENCEID         :port2_probe_sequenceid           <= wdata_phy[15:0];
                `PORT2_PROBE_CONTROLFIELD       :port2_probe_controlfield         <= wdata_phy[7:0 ];
                `PORT2_PROBE_LOGMSGINTERVAL     :port2_probe_logmsginterval       <= wdata_phy[7:0 ];
                `PORT2_PROBE_CORRECTION_HI      :port2_probe_correction[63:32]    <= wdata_phy[31:0];
                `PORT2_PROBE_CORRECTION_LO      :port2_probe_correction[31:0 ]    <= wdata_phy[31:0];

                // =============================================================
                // PORT 3 Probe Fault Injection Registers
                // =============================================================
                `PORT3_PROBE_GLB_CTRL           :port3_probe_glb_ctrl             <= wdata_phy[0];
                `PORT3_PROBE_FAULT_SEL          :port3_probe_fault_sel            <= wdata_phy[31:0];
                `PORT3_PROBE_DMAC_HI            :port3_probe_dmac[47:16]          <= wdata_phy[31:0];
                `PORT3_PROBE_DMAC_LO            :port3_probe_dmac[15:0]           <= wdata_phy[15:0];
                `PORT3_PROBE_ETHTYPE            :port3_probe_ethtype              <= wdata_phy[15:0];
                `PORT3_PROBE_MSGTYPE            :port3_probe_msgtype              <= wdata_phy[3:0 ];
                `PORT3_PROBE_TRANSPEC           :port3_probe_transpec             <= wdata_phy[3:0 ];
                `PORT3_PROBE_VERPTP             :port3_probe_verptp               <= wdata_phy[3:0 ];
                `PORT3_PROBE_MSGLENGTH          :port3_probe_msglength            <= wdata_phy[15:0];
                `PORT3_PROBE_DOMAINNUMBER       :port3_probe_domainnumber         <= wdata_phy[7:0 ];
                `PORT3_PROBE_FLAGFIELD          :port3_probe_flagfield            <= wdata_phy[15:0];
                `PORT3_PROBE_SOURCEPORTID_HI    :port3_probe_sourceportid[79:48]  <= wdata_phy[31:0];
                `PORT3_PROBE_SOURCEPORTID_MI    :port3_probe_sourceportid[47:16]  <= wdata_phy[31:0];
                `PORT3_PROBE_SOURCEPORTID_LO    :port3_probe_sourceportid[15:0 ]  <= wdata_phy[15:0];
                `PORT3_PROBE_SEQUENCEID         :port3_probe_sequenceid           <= wdata_phy[15:0];
                `PORT3_PROBE_CONTROLFIELD       :port3_probe_controlfield         <= wdata_phy[7:0 ];
                `PORT3_PROBE_LOGMSGINTERVAL     :port3_probe_logmsginterval       <= wdata_phy[7:0 ];
                `PORT3_PROBE_CORRECTION_HI      :port3_probe_correction[63:32]    <= wdata_phy[31:0];
                `PORT3_PROBE_CORRECTION_LO      :port3_probe_correction[31:0 ]    <= wdata_phy[31:0];
            endcase
        end
    end

endmodule