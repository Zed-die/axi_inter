`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module Name: packet_modifier_core
// Description: 流水线式 gPTP 报文篡改核心
// Feature: 
//   1. 自动识别 gPTP (EtherType = 0x88F7)
//   2. 仅对 gPTP 帧应用故障注入，其他帧透明传输
//   3. 引入固定延迟 (Latency = 20 clk) 以支持头部字段修改
//////////////////////////////////////////////////////////////////////////////////

module packet_modifier_core (
    input wire          clk,
    input wire          rst, // 同步高复位
    
    // Data Stream Input
    input wire [7:0]    rx_data,
    input wire          rx_en,
    
    // Data Stream Output (Latency = PIPELINE_DEPTH)
    output reg [7:0]    tx_data,
    output reg          tx_en,
    
    // Config Registers
    input wire          glb_enable,      // 探针使能标识
    input wire [31:0]   fault_sel,       // 错误码
    input wire [47:0]   cfg_dmac,
    input wire [15:0]   cfg_ethtype,
    input wire [3:0]    cfg_msgtype,
    input wire [3:0]    cfg_transpec,
    input wire [3:0]    cfg_verptp,
    input wire [15:0]   cfg_msglength,
    input wire [7:0]    cfg_domain,
    input wire [15:0]   cfg_flagfield,
    input wire [79:0]   cfg_sourceid,
    input wire [15:0]   cfg_seqid,
    input wire [7:0]    cfg_ctrlfield,
    input wire [7:0]    cfg_loginterval,
    input wire [63:0]   cfg_correction
);

    // =========================================================================
    // 参数定义
    // =========================================================================
    // 延迟深度必须 > 14，以便在输出 Byte 0 之前捕获 Byte 13 (EtherType)
    localparam PIPELINE_DEPTH = 14; 
    localparam GPTP_ETHTYPE   = 16'h88F7;

    // =========================================================================
    // 1. 数据流水线 (Data Pipeline / Shift Register)
    // =========================================================================
    // 使用寄存器数组推断 SRL16/SRL32，实现数据延迟
    reg [7:0] pipe_data [0:PIPELINE_DEPTH];
    reg       pipe_en   [0:PIPELINE_DEPTH];
    integer i;

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            for (i=0; i<= PIPELINE_DEPTH; i=i+1) begin
                pipe_data[i] <= 8'd0;
                pipe_en[i]   <= 1'b0;
            end
        end else begin
            // 移位逻辑 (Shift)
            pipe_data[0] <= rx_data;
            pipe_en[0]   <= rx_en;
            for (i=1; i <= PIPELINE_DEPTH; i=i+1) begin
                pipe_data[i] <= pipe_data[i-1];
                pipe_en[i]   <= pipe_en[i-1];
            end
        end
    end

    // =========================================================================
    // 2. 输入侧逻辑：EtherType 嗅探 (Snooping)
    // =========================================================================
    reg frame_flag;
    reg [11:0] in_byte_cnt;
    reg [15:0] snooped_ethtype;
    reg        frame_is_gptp_detected; // 输入侧检测标志

    always @(posedge clk or posedge rst) begin
        if (rst) 
            frame_flag <= 1'b0;
        else if (rx_en && rx_data == 8'hd5 && pipe_data[0] == 8'h55)   
            frame_flag <= 1'b1;
        else if(!rx_en)
            frame_flag <= 1'b0;
    end

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            in_byte_cnt            <= 12'd0;
            snooped_ethtype        <= 16'h0;
            frame_is_gptp_detected <= 1'b0;
        end else if (frame_flag) begin
            // 字节计数
            in_byte_cnt <= in_byte_cnt + 1'b1;
            frame_is_gptp_detected <= 1'b0;
            // 捕获 EtherType (Offset 12, 13)
            if (in_byte_cnt == 12'd12) 
                snooped_ethtype[15:8] <= rx_data;
            if (in_byte_cnt == 12'd13) begin
                if ({snooped_ethtype[15:8], rx_data} == GPTP_ETHTYPE)
                    frame_is_gptp_detected <= 1'b1;
                else
                    frame_is_gptp_detected <= 1'b0;
            end
        end else begin
            in_byte_cnt            <= 12'd0;
            snooped_ethtype        <= 16'h0;
            frame_is_gptp_detected <= 1'b0 ;
        end
    end

    // =========================================================================
    // 3. 输出侧逻辑：修改决策与执行
    // =========================================================================
    reg [11:0] out_byte_cnt;
    reg        out_byte_cnt_enable;
    reg        active_frame_modify; // 当前输出帧是否需要修改
    
    // 获取延迟后的数据
    wire [7:0] delayed_data     = pipe_data[PIPELINE_DEPTH-1];
    wire       delayed_en       = pipe_en  [PIPELINE_DEPTH-1];
    wire [7:0] delayed_data_ff  = pipe_data[PIPELINE_DEPTH]  ;
    wire       delayed_en_ff    = pipe_en  [PIPELINE_DEPTH]  ;

    always @(posedge clk or posedge rst) begin
        if(rst)
            active_frame_modify <= 1'b0;
        else if(delayed_en && frame_is_gptp_detected && glb_enable)
            active_frame_modify <= 1'b1;
        else if(!delayed_en)
            active_frame_modify <= 1'b0;
    end

    //输出计数
    always @(posedge clk or posedge rst) begin
        if(rst)
            out_byte_cnt <= 12'b0;
        else if (!active_frame_modify)
            out_byte_cnt <= 12'b0;
        else 
            out_byte_cnt <= out_byte_cnt + 1'b1;
    end

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            tx_data  <= 8'd0;
            tx_en    <= 1'b0;
        end else begin
            // 输出使能跟随延迟线
            tx_en <= delayed_en_ff;
           // --- 字段修改逻辑 ---
            if (active_frame_modify) begin
                case (out_byte_cnt)
                    // DMAC (0-5)
                    12'd0: tx_data  <= (fault_sel[0]) ? cfg_dmac[47:40] : delayed_data_ff;
                    12'd1: tx_data  <= (fault_sel[0]) ? cfg_dmac[39:32] : delayed_data_ff;
                    12'd2: tx_data  <= (fault_sel[0]) ? cfg_dmac[31:24] : delayed_data_ff;
                    12'd3: tx_data  <= (fault_sel[0]) ? cfg_dmac[23:16] : delayed_data_ff;
                    12'd4: tx_data  <= (fault_sel[0]) ? cfg_dmac[15:8]  : delayed_data_ff;
                    12'd5: tx_data  <= (fault_sel[0]) ? cfg_dmac[7:0]   : delayed_data_ff;
                    
                    // EthType (12-13)
                    12'd12: tx_data <= (fault_sel[1]) ? cfg_ethtype[15:8] : delayed_data_ff;
                    12'd13: tx_data <= (fault_sel[1]) ? cfg_ethtype[7:0]  : delayed_data_ff;
                    
                    // gPTP Header Fields (Starts at 14)
                    12'd14: tx_data <= (fault_sel[2]) ? {cfg_transpec, cfg_msgtype} : delayed_data_ff;
                    12'd15: tx_data <= (fault_sel[3]) ? {4'b0000, cfg_verptp} : delayed_data_ff;
                    
                    12'd16: tx_data <= (fault_sel[4]) ? cfg_msglength[15:8] : delayed_data_ff;
                    12'd17: tx_data <= (fault_sel[4]) ? cfg_msglength[7:0]  : delayed_data_ff;
                    
                    12'd18: tx_data <= (fault_sel[5]) ? cfg_domain : delayed_data_ff;
                    
                    12'd20: tx_data <= (fault_sel[6]) ? cfg_flagfield[15:8] : delayed_data_ff;
                    12'd21: tx_data <= (fault_sel[6]) ? cfg_flagfield[7:0]  : delayed_data_ff;
                    
                    // Correction Field (22-29)
                    12'd22: tx_data <= (fault_sel[7]) ? cfg_correction[63:56] : delayed_data_ff;
                    12'd23: tx_data <= (fault_sel[7]) ? cfg_correction[55:48] : delayed_data_ff;
                    12'd24: tx_data <= (fault_sel[7]) ? cfg_correction[47:40] : delayed_data_ff;
                    12'd25: tx_data <= (fault_sel[7]) ? cfg_correction[39:32] : delayed_data_ff;
                    12'd26: tx_data <= (fault_sel[7]) ? cfg_correction[31:24] : delayed_data_ff;
                    12'd27: tx_data <= (fault_sel[7]) ? cfg_correction[23:16] : delayed_data_ff;
                    12'd28: tx_data <= (fault_sel[7]) ? cfg_correction[15:8]  : delayed_data_ff;
                    12'd29: tx_data <= (fault_sel[7]) ? cfg_correction[7:0]   : delayed_data_ff;
                    
                    // SourcePortID (34-43)
                    12'd34: tx_data <= (fault_sel[8]) ? cfg_sourceid[79:72] : delayed_data_ff;
                    12'd35: tx_data <= (fault_sel[8]) ? cfg_sourceid[71:64] : delayed_data_ff;
                    12'd36: tx_data <= (fault_sel[8]) ? cfg_sourceid[63:56] : delayed_data_ff;
                    12'd37: tx_data <= (fault_sel[8]) ? cfg_sourceid[55:48] : delayed_data_ff;
                    12'd38: tx_data <= (fault_sel[8]) ? cfg_sourceid[47:40] : delayed_data_ff;
                    12'd39: tx_data <= (fault_sel[8]) ? cfg_sourceid[39:32] : delayed_data_ff;
                    12'd40: tx_data <= (fault_sel[8]) ? cfg_sourceid[31:24] : delayed_data_ff;
                    12'd41: tx_data <= (fault_sel[8]) ? cfg_sourceid[23:16] : delayed_data_ff;
                    12'd42: tx_data <= (fault_sel[8]) ? cfg_sourceid[15:8]  : delayed_data_ff;
                    12'd43: tx_data <= (fault_sel[8]) ? cfg_sourceid[7:0]   : delayed_data_ff;
                    
                    // SequenceID (44-45)
                    12'd44: tx_data <= (fault_sel[9]) ? cfg_seqid[15:8] : delayed_data_ff;
                    12'd45: tx_data <= (fault_sel[9]) ? cfg_seqid[7:0]  : delayed_data_ff;
                    
                    // ControlField (46)
                    12'd46: tx_data <= (fault_sel[10]) ? cfg_ctrlfield : delayed_data_ff;
                    
                    // LogMessageInterval (47)
                    12'd47: tx_data <= (fault_sel[11]) ? cfg_loginterval : delayed_data_ff;
                    default: tx_data <= delayed_data_ff;
                endcase
            end 
            else begin
                // 不修改：直接输出流水线延迟后的数据
                tx_data <= delayed_data_ff;
            end
        end 
    end

endmodule