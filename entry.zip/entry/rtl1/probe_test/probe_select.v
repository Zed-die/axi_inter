`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module Name: probe_select
// Description: 安全无缝切换的探针数据选择模块
// Key Feature: Glitch-free switching based on IDLE state detection
//////////////////////////////////////////////////////////////////////////////////

module probe_select(
    input                   clk,           
    input                   rst,           
    // 模式配置
    input    [1:0]          port0_mode,     
    input    [1:0]          port1_mode,     
    input    [1:0]          port2_mode,     
    input    [1:0]          port3_mode,     
    
    // 探针篡改数据
    input    [7:0]          probe_tx_data1 ,    
    input                   probe_tx_en1   ,    
    input    [7:0]          probe_tx_data2 ,    
    input                   probe_tx_en2   ,    
    input    [7:0]          probe_tx_data3 ,    
    input                   probe_tx_en3   ,    
    input    [7:0]          probe_tx_data4 ,    
    input                   probe_tx_en4   ,         
    
    // 端口原本待发送数据 
    input    [7:0]          gmii_txd_in_1  ,
    input                   gmii_tx_en_in_1,
    input    [7:0]          gmii_txd_in_2  ,
    input                   gmii_tx_en_in_2,
    input    [7:0]          gmii_txd_in_3  ,
    input                   gmii_tx_en_in_3,
    input    [7:0]          gmii_txd_in_4  ,
    input                   gmii_tx_en_in_4,
    
    // 输出仲裁给 PCS/PMA IP
    output   reg [7:0]      pcs_pma_txd1   ,
    output   reg            pcs_pma_tx_en1 ,
    output   reg [7:0]      pcs_pma_txd2   ,
    output   reg            pcs_pma_tx_en2 ,
    output   reg [7:0]      pcs_pma_txd3   ,
    output   reg            pcs_pma_tx_en3 ,
    output   reg [7:0]      pcs_pma_txd4   ,
    output   reg            pcs_pma_tx_en4 
);

    // =========================================================================
    // 内部状态锁存器 (用于记录当前实际生效的模式)
    // 0 = Normal Mode (MAC源), 1 = Probe Mode (PHY源)
    // =========================================================================
    reg active_mode_p1;
    reg active_mode_p2;
    reg active_mode_p3;
    reg active_mode_p4;

/*
    探针模式下连接拓扑：
            +--------+                                         +--------+
            | DUT A  | <-->    端口[1]   <-->  端口[2]    <-->|  DUT B  |
            +--------+                                         +--------+

            +--------+                                         +--------+
            | DUT C  | <-->    端口[3]   <-->  端口[4]    <-->|  DUT D  |
            +--------+                                         +--------+

    1,2端口为1对，3,4端口为1对
*/

    wire probe_req_group_01 = ({port0_mode, port1_mode} == 4'b1111);
    wire probe_req_group_23 = ({port2_mode, port3_mode} == 4'b1111);

    // =========================================================================
    // 端口 1 处理逻辑 (Port 1 Output Mux)
    // =========================================================================
    always @(posedge clk or posedge rst) begin
        if(rst) begin
            pcs_pma_txd1   <= 8'd0;
            pcs_pma_tx_en1 <= 1'b0;
            active_mode_p1 <= 1'b0; // 默认MAC模式
        end else begin
            // 1. 安全切换检查：只有在当前发送为空闲(IDLE)时，才允许更新模式
            if(pcs_pma_tx_en1 == 1'b0) begin
                active_mode_p1 <= probe_req_group_01; 
            end
            // else: 如果正在发包(tx_en=1)，active_mode_p1 保持不变，强行把包发完

            // 2. 数据通路选择 (基于锁存后的安全模式)
            if(active_mode_p1 == 1'b1) begin
                // --- 探针模式: 转发 Port 2 的探针篡改后的数据 ---
                pcs_pma_txd1   <= probe_tx_data2;
                pcs_pma_tx_en1 <= probe_tx_en2  ;
            end else begin
                // --- 正常模式: 发送 MAC 的 TX 数据 ---
                pcs_pma_txd1   <= gmii_txd_in_1;
                pcs_pma_tx_en1 <= gmii_tx_en_in_1;
            end
        end
    end

    // =========================================================================
    // 端口 2 处理逻辑 (Port 2 Output Mux)
    // =========================================================================
    always @(posedge clk or posedge rst) begin
        if(rst) begin
            pcs_pma_txd2   <= 8'd0;
            pcs_pma_tx_en2 <= 1'b0;
            active_mode_p2 <= 1'b0;
        end else begin
            // IDLE Check
            if(pcs_pma_tx_en2 == 1'b0) begin
                active_mode_p2 <= probe_req_group_01;
            end
            // Mux
            if(active_mode_p2 == 1'b1) begin
                // --- 探针模式: 转发 Port 1 的 RX 数据 ---
                pcs_pma_txd2   <= probe_tx_data1;
                pcs_pma_tx_en2 <= probe_tx_en1  ;
            end else begin
                // --- 正常模式 ---
                pcs_pma_txd2   <= gmii_txd_in_2;
                pcs_pma_tx_en2 <= gmii_tx_en_in_2;
            end
        end
    end

    // =========================================================================
    // 端口 3 处理逻辑 (Port 3 Output Mux)
    // =========================================================================
    always @(posedge clk or posedge rst) begin
        if(rst) begin
            pcs_pma_txd3   <= 8'd0;
            pcs_pma_tx_en3 <= 1'b0;
            active_mode_p3 <= 1'b0;
        end else begin
            // IDLE Check
            if(pcs_pma_tx_en3 == 1'b0) begin
                active_mode_p3 <= probe_req_group_23;
            end

            // Mux
            if(active_mode_p3 == 1'b1) begin
                // --- 探针模式: 转发 Port 4 的 RX 数据 ---
                pcs_pma_txd3   <= probe_tx_data4;
                pcs_pma_tx_en3 <= probe_tx_en4  ;
            end else begin
                // --- 正常模式 ---
                pcs_pma_txd3   <= gmii_txd_in_3;
                pcs_pma_tx_en3 <= gmii_tx_en_in_3;
            end
        end
    end

    // =========================================================================
    // 端口 4 处理逻辑 (Port 4 Output Mux)
    // =========================================================================
    always @(posedge clk or posedge rst) begin
        if(rst) begin
            pcs_pma_txd4   <= 8'd0;
            pcs_pma_tx_en4 <= 1'b0;
            active_mode_p4 <= 1'b0;
        end else begin
            // IDLE Check
            if(pcs_pma_tx_en4 == 1'b0) begin
                active_mode_p4 <= probe_req_group_23;
            end

            // Mux
            if(active_mode_p4 == 1'b1) begin
                // --- 探针模式: 转发 Port 3 的 RX 数据 ---
                pcs_pma_txd4   <= probe_tx_data3;
                pcs_pma_tx_en4 <= probe_tx_en3  ;
            end else begin
                // --- 正常模式 ---
                pcs_pma_txd4   <= gmii_txd_in_4;
                pcs_pma_tx_en4 <= gmii_tx_en_in_4;
            end
        end
    end

endmodule