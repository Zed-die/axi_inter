`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module Name: probe_modify
// Description: gPTP 探针报文篡改模块
// Function: 根据配置寄存器，实时修改流经的以太网帧字段
//////////////////////////////////////////////////////////////////////////////////

module probe_modify(
    input clk,
    input rst,
    
    // --- PHY侧接收数据 ---
    input        [7:0]       phy_rx_data1 ,    
    input                    phy_rx_en1   ,    
    input        [7:0]       phy_rx_data2 ,    
    input                    phy_rx_en2   ,    
    input        [7:0]       phy_rx_data3 ,    
    input                    phy_rx_en3   ,    
    input        [7:0]       phy_rx_data4 ,    
    input                    phy_rx_en4   ,
    
    // --- 探针篡改后输出数据 ---
    output       [7:0]       probe_tx_data1, 
    output                   probe_tx_en1  , 
    output       [7:0]       probe_tx_data2, 
    output                   probe_tx_en2  , 
    output       [7:0]       probe_tx_data3, 
    output                   probe_tx_en3  , 
    output       [7:0]       probe_tx_data4, 
    output                   probe_tx_en4  , 

    // --- PORT 0 配置寄存器 ---
    input                    port0_probe_glb_ctrl       ,
    input        [31:0]      port0_probe_fault_sel      ,
    input        [47:0]      port0_probe_dmac           ,
    input        [15:0]      port0_probe_ethtype        ,
    input        [3:0]       port0_probe_msgtype        ,
    input        [3:0]       port0_probe_transpec       ,
    input        [3:0]       port0_probe_verptp         ,
    input        [15:0]      port0_probe_msglength      ,
    input        [7:0]       port0_probe_domainnumber   ,
    input        [15:0]      port0_probe_flagfield      ,
    input        [79:0]      port0_probe_sourceportid   ,
    input        [15:0]      port0_probe_sequenceid     ,
    input        [7:0]       port0_probe_controlfield   ,
    input        [7:0]       port0_probe_logmsginterval ,
    input        [63:0]      port0_probe_correction     ,

    // --- PORT 1 配置寄存器 ---
    input                    port1_probe_glb_ctrl       ,
    input        [31:0]      port1_probe_fault_sel      ,
    input        [47:0]      port1_probe_dmac           ,
    input        [15:0]      port1_probe_ethtype        ,
    input        [3:0]       port1_probe_msgtype        ,
    input        [3:0]       port1_probe_transpec       ,
    input        [3:0]       port1_probe_verptp         ,
    input        [15:0]      port1_probe_msglength      ,
    input        [7:0]       port1_probe_domainnumber   ,
    input        [15:0]      port1_probe_flagfield      ,
    input        [79:0]      port1_probe_sourceportid   ,
    input        [15:0]      port1_probe_sequenceid     ,
    input        [7:0]       port1_probe_controlfield   ,
    input        [7:0]       port1_probe_logmsginterval ,
    input        [63:0]      port1_probe_correction     ,

    // --- PORT 2 配置寄存器 ---
    input                    port2_probe_glb_ctrl       ,
    input        [31:0]      port2_probe_fault_sel      ,
    input        [47:0]      port2_probe_dmac           ,
    input        [15:0]      port2_probe_ethtype        ,
    input        [3:0]       port2_probe_msgtype        ,
    input        [3:0]       port2_probe_transpec       ,
    input        [3:0]       port2_probe_verptp         ,
    input        [15:0]      port2_probe_msglength      ,
    input        [7:0]       port2_probe_domainnumber   ,
    input        [15:0]      port2_probe_flagfield      ,
    input        [79:0]      port2_probe_sourceportid   ,
    input        [15:0]      port2_probe_sequenceid     ,
    input        [7:0]       port2_probe_controlfield   ,
    input        [7:0]       port2_probe_logmsginterval ,
    input        [63:0]      port2_probe_correction     ,

    // --- PORT 3 配置寄存器 ---
    input                    port3_probe_glb_ctrl       ,
    input        [31:0]      port3_probe_fault_sel      ,
    input        [47:0]      port3_probe_dmac           ,
    input        [15:0]      port3_probe_ethtype        ,
    input        [3:0]       port3_probe_msgtype        ,
    input        [3:0]       port3_probe_transpec       ,
    input        [3:0]       port3_probe_verptp         ,
    input        [15:0]      port3_probe_msglength      ,
    input        [7:0]       port3_probe_domainnumber   ,
    input        [15:0]      port3_probe_flagfield      ,
    input        [79:0]      port3_probe_sourceportid   ,
    input        [15:0]      port3_probe_sequenceid     ,
    input        [7:0]       port3_probe_controlfield   ,
    input        [7:0]       port3_probe_logmsginterval ,
    input        [63:0]      port3_probe_correction     
);

    // =========================================================================
    // 实例化 4 个报文修改核心 (Packet Modifier Core Instances)
    // =========================================================================

    // --- Port 0 Config -> Process Data 1 ---
    packet_modifier_core u_mod_p1 (
        .clk              (clk                       ),
        .rst              (rst                       ),
        .rx_data          (phy_rx_data1              ),
        .rx_en            (phy_rx_en1                ),
        .tx_data          (probe_tx_data1            ),
        .tx_en            (probe_tx_en1              ),
        // Configuration
        .glb_enable       (port0_probe_glb_ctrl      ), 
        .fault_sel        (port0_probe_fault_sel     ),
        .cfg_dmac         (port0_probe_dmac          ),
        .cfg_ethtype      (port0_probe_ethtype       ),
        .cfg_msgtype      (port0_probe_msgtype       ),
        .cfg_transpec     (port0_probe_transpec      ),
        .cfg_verptp       (port0_probe_verptp        ),
        .cfg_msglength    (port0_probe_msglength     ),
        .cfg_domain       (port0_probe_domainnumber  ),
        .cfg_flagfield    (port0_probe_flagfield     ),
        .cfg_sourceid     (port0_probe_sourceportid  ),
        .cfg_seqid        (port0_probe_sequenceid    ),
        .cfg_ctrlfield    (port0_probe_controlfield  ),
        .cfg_loginterval  (port0_probe_logmsginterval),
        .cfg_correction   (port0_probe_correction    )
    );

    // --- Port 1 Config -> Process Data 2 ---
    packet_modifier_core u_mod_p2 (
        .clk              (clk                       ),
        .rst              (rst                       ),
        .rx_data          (phy_rx_data2              ),
        .rx_en            (phy_rx_en2                ),
        .tx_data          (probe_tx_data2            ),
        .tx_en            (probe_tx_en2              ),
        .glb_enable       (port1_probe_glb_ctrl      ),
        .fault_sel        (port1_probe_fault_sel     ),
        .cfg_dmac         (port1_probe_dmac          ),
        .cfg_ethtype      (port1_probe_ethtype       ),
        .cfg_msgtype      (port1_probe_msgtype       ),
        .cfg_transpec     (port1_probe_transpec      ),
        .cfg_verptp       (port1_probe_verptp        ),
        .cfg_msglength    (port1_probe_msglength     ),
        .cfg_domain       (port1_probe_domainnumber  ),
        .cfg_flagfield    (port1_probe_flagfield     ),
        .cfg_sourceid     (port1_probe_sourceportid  ),
        .cfg_seqid        (port1_probe_sequenceid    ),
        .cfg_ctrlfield    (port1_probe_controlfield  ),
        .cfg_loginterval  (port1_probe_logmsginterval),
        .cfg_correction   (port1_probe_correction    )
    );

    // --- Port 2 Config -> Process Data 3 ---
    packet_modifier_core u_mod_p3 (
        .clk              (clk                       ),
        .rst              (rst                       ),
        .rx_data          (phy_rx_data3              ),
        .rx_en            (phy_rx_en3                ),
        .tx_data          (probe_tx_data3            ),
        .tx_en            (probe_tx_en3              ),
        .glb_enable       (port2_probe_glb_ctrl      ),
        .fault_sel        (port2_probe_fault_sel     ),
        .cfg_dmac         (port2_probe_dmac          ),
        .cfg_ethtype      (port2_probe_ethtype       ),
        .cfg_msgtype      (port2_probe_msgtype       ),
        .cfg_transpec     (port2_probe_transpec      ),
        .cfg_verptp       (port2_probe_verptp        ),
        .cfg_msglength    (port2_probe_msglength     ),
        .cfg_domain       (port2_probe_domainnumber  ),
        .cfg_flagfield    (port2_probe_flagfield     ),
        .cfg_sourceid     (port2_probe_sourceportid  ),
        .cfg_seqid        (port2_probe_sequenceid    ),
        .cfg_ctrlfield    (port2_probe_controlfield  ),
        .cfg_loginterval  (port2_probe_logmsginterval),
        .cfg_correction   (port2_probe_correction    )
    );

    // --- Port 3 Config -> Process Data 4 ---
    packet_modifier_core u_mod_p4 (
        .clk              (clk                       ),
        .rst              (rst                       ),
        .rx_data          (phy_rx_data4              ),
        .rx_en            (phy_rx_en4                ),
        .tx_data          (probe_tx_data4            ),
        .tx_en            (probe_tx_en4              ),
        .glb_enable       (port3_probe_glb_ctrl      ),
        .fault_sel        (port3_probe_fault_sel     ),
        .cfg_dmac         (port3_probe_dmac          ),
        .cfg_ethtype      (port3_probe_ethtype       ),
        .cfg_msgtype      (port3_probe_msgtype       ),
        .cfg_transpec     (port3_probe_transpec      ),
        .cfg_verptp       (port3_probe_verptp        ),
        .cfg_msglength    (port3_probe_msglength     ),
        .cfg_domain       (port3_probe_domainnumber  ),
        .cfg_flagfield    (port3_probe_flagfield     ),
        .cfg_sourceid     (port3_probe_sourceportid  ),
        .cfg_seqid        (port3_probe_sequenceid    ),
        .cfg_ctrlfield    (port3_probe_controlfield  ),
        .cfg_loginterval  (port3_probe_logmsginterval),
        .cfg_correction   (port3_probe_correction    )
    );

endmodule


