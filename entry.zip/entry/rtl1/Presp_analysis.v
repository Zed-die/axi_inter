`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: wanghaoyu
// 
// Create Date: 2025/04/24 17:03:28
// Design Name: 
// Module Name: Presp_analysis
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module Presp_analysis(
    input           clk,
    input           rst_n,
    input   [7:0]   data_i          ,
    input           valid_i         ,

    output reg [15:0]  MsgLength           ,
    output reg [7:0]   DomainNumber        ,
    output reg [15:0]  FlagField           ,
    output reg [63:0]  CorrectionField     ,
    output reg [79:0]  sourcePortIdentity  ,
    output reg [15:0]  SequenceID          ,
    output reg [7:0]   ControlField        ,
    output reg [7:0]   logMessage          ,
    output reg [79:0]  Pdelay_RX_timestamp ,
    output reg [79:0]  Pdelay_PortIdentity ,
    output             message_valid       
      
);

reg [7:0] cnt;       
assign message_valid=(cnt==52)?1:0;

always @(posedge clk or negedge rst_n) begin
    if(!rst_n)
        cnt<=8'b0;
    else if(!valid_i)
        cnt<=8'b0;
    else
        cnt<=cnt+1;
end

always @(posedge clk or negedge rst_n) begin
    if(!rst_n)begin
        MsgLength           <=16'b0;
        DomainNumber        <=8'b0;
        FlagField           <=16'b0;
        CorrectionField     <=64'b0;
        sourcePortIdentity  <=80'b0;
        SequenceID          <=16'b0;
        ControlField        <=8'b0;
        logMessage          <=8'b0; 
        Pdelay_RX_timestamp <=80'b0;
        Pdelay_PortIdentity <=80'b0;
    end
    else begin
        case(cnt)
            8'd0: MsgLength[15:8]            <= data_i;
            8'd1: MsgLength[7:0]             <= data_i;
            8'd2: DomainNumber               <= data_i;
            8'd4: FlagField[15:8]            <= data_i;
            8'd5: FlagField[7:0]             <= data_i;
            8'd6: CorrectionField[63:56]     <= data_i;
            8'd7: CorrectionField[55:48]     <= data_i;
            8'd8: CorrectionField[47:40]     <= data_i;
            8'd9: CorrectionField[39:32]     <= data_i;
            8'd10:CorrectionField[31:24]     <= data_i;
            8'd11:CorrectionField[23:16]     <= data_i;
            8'd12:CorrectionField[15:8]      <= data_i;
            8'd13:CorrectionField[7:0]       <= data_i;
            8'd18:sourcePortIdentity[79:72]  <= data_i;
            8'd19:sourcePortIdentity[71:64]  <= data_i;
            8'd20:sourcePortIdentity[63:56]  <= data_i;
            8'd21:sourcePortIdentity[55:48]  <= data_i;
            8'd22:sourcePortIdentity[47:40]  <= data_i;
            8'd23:sourcePortIdentity[39:32]  <= data_i;
            8'd24:sourcePortIdentity[31:24]  <= data_i;
            8'd25:sourcePortIdentity[23:16]  <= data_i;
            8'd26:sourcePortIdentity[15:8 ]  <= data_i;
            8'd27:sourcePortIdentity[7:0  ]  <= data_i;
            8'd28:SequenceID[15:8]           <= data_i;
            8'd29:SequenceID[7:0]            <= data_i;
            8'd30:ControlField               <= data_i;
            8'd31:logMessage                 <= data_i;
            8'd32:Pdelay_RX_timestamp[79:72] <= data_i;
            8'd33:Pdelay_RX_timestamp[71:64] <= data_i;
            8'd34:Pdelay_RX_timestamp[63:56] <= data_i;
            8'd35:Pdelay_RX_timestamp[55:48] <= data_i;
            8'd36:Pdelay_RX_timestamp[47:40] <= data_i;
            8'd37:Pdelay_RX_timestamp[39:32] <= data_i;
            8'd38:Pdelay_RX_timestamp[31:24] <= data_i;
            8'd39:Pdelay_RX_timestamp[23:16] <= data_i;
            8'd40:Pdelay_RX_timestamp[15:8]  <= data_i;
            8'd41:Pdelay_RX_timestamp[7:0]   <= data_i;
            8'd42:Pdelay_PortIdentity[79:72] <= data_i;
            8'd43:Pdelay_PortIdentity[71:64] <= data_i;
            8'd44:Pdelay_PortIdentity[63:56] <= data_i;
            8'd45:Pdelay_PortIdentity[55:48] <= data_i;
            8'd46:Pdelay_PortIdentity[47:40] <= data_i;
            8'd47:Pdelay_PortIdentity[39:32] <= data_i;
            8'd48:Pdelay_PortIdentity[31:24] <= data_i;
            8'd49:Pdelay_PortIdentity[23:16] <= data_i;
            8'd50:Pdelay_PortIdentity[15:8]  <= data_i;
            8'd51:Pdelay_PortIdentity[7:0]   <= data_i;
            default:begin
                MsgLength           <=  MsgLength          ;
                DomainNumber        <=  DomainNumber       ;
                FlagField           <=  FlagField          ;
                CorrectionField     <=  CorrectionField    ;
                sourcePortIdentity  <=  sourcePortIdentity ;
                SequenceID          <=  SequenceID         ;
                ControlField        <=  ControlField       ;
                logMessage          <=  logMessage         ;
                Pdelay_RX_timestamp <=  Pdelay_RX_timestamp;
                Pdelay_PortIdentity <=  Pdelay_PortIdentity;
            end
        endcase
    end
end



endmodule
