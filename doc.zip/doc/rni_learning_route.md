# RNI 模块学习路线

这份文档给出一个适合阅读 `rtl/rni` 的学习顺序。目标不是逐行解释 RTL，而是先建立正确的模块边界和数据流，再进入读路径、写路径和 CHI link/credit 细节。

推荐原则：

- 先看顶层连接，再看单条 transaction 怎么走。
- 先读读路径，再读写路径。读路径少了 WDATA、DBID、TXDAT、CompAck 和 B response，认知负担小很多。
- 先理解 `segment`、`entry`、`bank/mask`，再去啃 `arctrl/awctrl` 的状态和依赖逻辑。
- `rni_link_ctl` 很关键，但建议在理解 AR/AW 控制器产生什么 flit 之后再细看。

## 0. 先建立全局地图

先只看 [`rtl/rni/rni.v`](../rtl/rni/rni.v)，不要陷入每根 wire。目标是画出下面这张图：

```text
AXI AW/AR
  -> rni_axi_bus
  -> rni_awlink / rni_arlink
  -> rni_segburst
  -> rni_awctrl / rni_arctrl
  -> CHI TXREQ
  -> rni_link_ctl

AXI W
  -> rni_axi_bus
  -> rni_wr_buffer
  -> CHI TXDAT
  -> rni_link_ctl

CHI RXDAT
  -> rni_link_ctl
  -> rni_rd_buffer
  -> AXI R

CHI RXRSP
  -> rni_link_ctl
  -> rni_awctrl / rni_arctrl / rni_misc
```

顶层里重点确认这些实例：

| 顶层实例 | 作用 |
| --- | --- |
| `rni_axi_bus_inst` | AXI 字段和内部 packed bus 的转换 |
| `rni_arctrl_inst` | 读请求 entry、TXREQ、读数据返回调度 |
| `rni_rd_buffer_inst` | RXDAT 数据暂存，生成 AXI R |
| `rni_awctrl_inst` | 写请求 entry、TXREQ、RXRSP、TXDAT/B response 调度 |
| `rni_wr_buffer_inst` | AXI W 缓存，生成 TXDAT 和 AXI B |
| `rni_misc_inst` | PCRDGrant 缓存和 AR/AW 之间的 grant 仲裁 |
| `rni_link_ctl_inst` | CHI link active、credit、TX/RX flit pipeline |

## 1. 第一阶段：参数、字段和公共工具

先读：

```text
rtl/include/rni_param.v
rtl/include/rni_defines.v
rtl/include/axi4_defines.v
rtl/include/chie_defines.v
rtl/misc/sync_fifo.v
rtl/misc/poll_function.v
rtl/misc/poll_with_start_entry.v
```

这一阶段只需要搞清楚三件事：

1. AXI 五个通道如何被打包成 `AW_CH_S0/W_CH_S0/B_CH_S0/AR_CH_S0/R_CH_S0`。
2. CHI `REQ/RSP/DAT` flit 字段范围和常见 opcode，例如 `ReadOnce`、`WriteUniquePtl`、`DBIDResp`、`CompData`。
3. RNI 内部按 64B cacheline、4 个 16B bank 组织数据，`CT/PD/LS/RV mask` 都是围绕这 4 个 bank 展开的。

重点记住：

```text
64B cacheline = bank0 + bank1 + bank2 + bank3
每个 bank = 16B
RNI_DMASK_WIDTH = 16 = CT[3:0] + PD[3:0] + LS[3:0] + RV[3:0]
```

## 2. 第二阶段：AXI 入口和 burst 切分

再读：

```text
rtl/rni/rni_axi_bus.v
rtl/rni/rni_segburst.v
rtl/rni/rni_arlink.v
rtl/rni/rni_awlink.v
```

推荐顺序是先看 `rni_axi_bus`，再看 `rni_segburst`，最后看 `arlink/awlink`。

`rni_axi_bus` 很薄，只做字段拼接和拆分。读到能回答下面问题就够了：

```text
AWID/AWADDR/AWLEN/... -> AW_CH_S0
WDATA/WSTRB/WLAST     -> W_CH_S0
ARID/ARADDR/ARLEN/... -> AR_CH_S0
B_CH_S0               -> BID/BRESP
R_CH_S0               -> RID/RDATA/RRESP/RLAST
```

`rni_segburst` 是这一级的重点。它把 AXI burst 切成不跨 64B cacheline 的 segment，并输出：

| 信号 | 你需要理解的含义 |
| --- | --- |
| `segburst_valid_s1_o` | 当前是否有一个 segment 可用 |
| `segburst_addr_s1_o` | 当前 segment 的地址 |
| `segburst_done_s1_o` | 当前 segment 是否是原 AXI burst 的最后一段 |
| `segburst_bc_vec_s2_o` | 每个 bank 需要多少 AXI beat |
| `segburst_dmask_s2_o` | CT/PD/LS/RV mask |
| `segburst_size_s2_o` | CHI request size |

注意它有一个 S1/S2 对齐关系：地址和 valid 在 S1，mask/size/bc_vec 在 S2。后面的 `arctrl/awctrl` 会把 entry pointer 延迟一拍来对齐这些信息。

## 3. 第三阶段：先读完整读路径

读路径建议顺序：

```text
rni_arlink
  -> rni_segburst
  -> rni_arctrl
  -> rni_link_ctl 的 TXREQ/RXDAT 相关部分
  -> rni_rd_buffer
  -> rni_datbuf_bank
```

先看 [`rtl/rni/rni_arctrl.v`](../rtl/rni/rni_arctrl.v)，目标不是一次读懂所有 always block，而是追一笔 AR：

```text
AXI AR handshake
  -> arlink FIFO
  -> segburst 输出 segment
  -> arctrl 分配 AR entry
  -> arctrl 生成 ReadOnce TXREQ
  -> link_ctl 接收并打一拍送出 TXREQFLIT/TXREQFLITV
  -> CHI 返回 RXDAT CompData
  -> rd_buffer 按 TxnID/DataID 写入 data bank
  -> arctrl 根据 RXDAT 更新 RV/PD mask
  -> arctrl 调度 rd_buffer 返回 AXI R
  -> entry 释放
```

读 `rni_arctrl` 时，建议分 5 块看：

| 阅读块 | 重点 |
| --- | --- |
| AR entry 分配 | `arctrl_entry_v_q`、`arctrl_alloc_ptr_*`、`arlink_valid_s1_w` |
| 请求依赖 | 同 ID、同 cacheline 的 request ordering |
| TXREQ 生成 | `ReadOnce` flit 的 `Opcode/SrcID/TgtID/TxnID/Addr/QoS` |
| RXDAT 跟踪 | `TxnID/DataID` 如何更新 `RV/PD/CT mask` |
| AXI R 调度 | 何时让 `rd_buffer` 读 bank，何时产生 `RLAST` |

然后看 [`rtl/rni/rni_rd_buffer.v`](../rtl/rni/rni_rd_buffer.v) 和 [`rtl/rni/rni_datbuf_bank.v`](../rtl/rni/rni_datbuf_bank.v)。这里的核心问题是：

- `RXDATFLIT` 里的 `TxnID` 如何定位 AR entry。
- `DataID` 如何定位 16B bank。
- `CHIE_DATA_WIDTH_PARAM == 256` 时，一个 RXDAT flit 如何覆盖两个 16B bank。
- `arctrl_rb_*` 这组调度信号如何变成 AXI `R_CH_S0/RVALID0`。

## 4. 第四阶段：再读完整写路径

写路径建议顺序：

```text
rni_awlink
  -> rni_segburst
  -> rni_awctrl
  -> rni_wr_buffer
  -> rni_bcount_ctl
  -> rni_link_ctl 的 TXREQ/TXDAT/TXRSP 相关部分
```

写路径比读路径复杂，因为它至少有三条并行线：

```text
AW -> TXREQ WriteUniquePtl
W  -> TXDAT NonCopyBackWrData
RXRSP -> DBIDResp / Comp / CompDBIDResp / RetryAck
```

读 [`rtl/rni/rni_awctrl.v`](../rtl/rni/rni_awctrl.v) 时，建议分 6 块看：

| 阅读块 | 重点 |
| --- | --- |
| AW entry 分配 | `awctrl_entry_v_q`、`awctrl_alloc_ptr_*`、`awlink_valid_s1_w` |
| TXREQ 生成 | `WriteUniquePtl` flit，写 entry 的 TxnID 最高位为 1 |
| RXRSP 处理 | `DBIDResp`、`Comp`、`CompDBIDResp`、`RetryAck` |
| TXDAT 调度 | 何时通知 `wr_buffer` 可以发写数据 |
| CompAck/TXRSP | 哪些写事务需要发 `CompAck` |
| B response 调度 | 何时可以返回 AXI B，为什么要等最后一个 segment |

再看 [`rtl/rni/rni_wr_buffer.v`](../rtl/rni/rni_wr_buffer.v)。它不管理写事务协议本身，主要管数据：

```text
AXI WVALID/WREADY
  -> W FIFO
  -> 根据 awctrl 的 entry/mask 写入 4 个 data bank
  -> bcount_ctl 判断每个 bank 和整个 request 是否收齐
  -> awctrl 允许后组装 TXDAT
  -> link_ctl 接收并发送 TXDAT
  -> B response FIFO 输出 AXI B
```

读 `wr_buffer` 时特别注意 `W_CH_S0`：它是 `rni_axi_bus` 打包后的写数据通道，包含 `WDATA/WSTRB/WLAST`，后续会根据 AW segment 的 bank mask 被写入对应 entry 的数据 bank。

## 5. 第五阶段：最后看 CHI link、credit 和 retry

最后读：

```text
rtl/rni/rni_link_handshake.v
rtl/rni/rni_lcrd_hdlr.v
rtl/rni/rni_link_ctl.v
rtl/rni/rni_misc.v
```

`rni_lcrd_hdlr` 很小，先读它。你需要理解：

```text
lcrd_inc : 收到对端归还的 credit
lcrd_dec : 本端发送一个 flit 消耗 credit
lcrd_avail : 当前是否有 credit 可发送
```

再读 `rni_link_handshake`，理解 TX/RX link 的 `STOP/ACTIVATE/RUN/DEACTIVATE` 状态。

最后读 [`rtl/rni/rni_link_ctl.v`](../rtl/rni/rni_link_ctl.v)。建议按通道读，不要从头到尾硬扫：

| 通道 | 重点 |
| --- | --- |
| RXRSP | 接收打一拍，过滤 `RSPLCRDRETURN`，转发给 `arctrl/awctrl/misc` |
| RXDAT | 接收打一拍，过滤 `DATLCRDRETURN`，转发给 `rd_buffer/arctrl` |
| TXREQ | 在 AR/AW 两个 TXREQ 源之间仲裁，检查 TXREQ credit 和 link RUN |
| TXDAT | 接收 `wr_buffer` 的 TXDAT，检查 TXDAT credit |
| TXRSP | 接收 `awctrl` 的 CompAck，检查 TXRSP credit |

这里有一个常见时序点：

```text
arctrl/awctrl 在 S4 给出 txreqflit_s4_i
link_ctl 在 S4 仲裁并产生 *_sent_s4_o
下一个周期 S5，对外 TXREQFLITV 和 TXREQFLIT 同拍有效
```

所以内部 S4 到外部 `TXREQFLIT` 是一拍延迟，但外部 `TXREQFLITV` 与 `TXREQFLIT` 是同拍对齐。

`rni_misc` 放最后看。它主要把 `PCRDGrant` 从 RXRSP 中抽出来，缓存在 FIFO 里，再在 AR/AW 之间做 high/low QoS grant 仲裁。理解 Retry 时再回来读它最顺。

## 6. 推荐的实际阅读任务

按下面 5 个小任务读，比“打开所有文件从上到下看”更有效：

1. 跟一笔 64B read：从 `ARVALID0` 到 `TXREQFLIT`，再从 `RXDATFLIT` 到 `RVALID0`。
2. 跟一笔 64B write：从 `AWVALID0/WVALID0` 到 `TXREQFLIT/TXDATFLIT`，再到 `BVALID0`。
3. 跟一个跨 64B 边界的 AXI burst：重点看 `rni_segburst` 如何切成多个 segment。
4. 跟一个 Retry：看 `RetryAck` 如何记录在 `arctrl/awctrl`，再通过 `rni_misc` 等 `PCRDGrant` 后重发。
5. 跟一次 credit：看 `TXREQLCRDV` 如何让 `rni_lcrd_hdlr` 增加 credit，`TXREQFLITV` 如何消耗 credit。

## 7. 最容易混淆的边界

| 容易混淆的点 | 正确理解 |
| --- | --- |
| AXI ID vs CHI TxnID | AXI ID 用于 AXI ordering；CHI TxnID 在本设计中主要编码 AR/AW entry index |
| `rni_segburst` vs `arctrl/awctrl` | `segburst` 只负责切 segment；entry 生命周期由 `arctrl/awctrl` 管 |
| `rd_buffer` vs `arctrl` | `rd_buffer` 存数据并输出 AXI R；`arctrl` 决定什么时候返回哪个 entry/bank |
| `wr_buffer` vs `awctrl` | `wr_buffer` 管 WDATA/TXDAT/B FIFO；`awctrl` 管写事务状态和调度 |
| `*_valid` vs `*_sent` | valid 表示上层有 flit；sent 表示 link 层在 credit/link/仲裁条件满足时真正接收 |
| `TXREQFLITV` vs `TXREQFLIT` | 对外端口同拍有效；相对内部 S4 源 flit 延后一拍 |

## 8. 建议配套阅读文档

当前 `doc` 目录下已有更深入的分模块文档，可以按学习阶段配合阅读：

| 阶段 | 文档 |
| --- | --- |
| 总览 | [`rni_design.md`](rni_design.md), [`rni_reading_guide.md`](rni_reading_guide.md) |
| burst 切分 | [`rni_segburst_design.md`](rni_segburst_design.md) |
| 读路径 | [`rni_arlink_design.md`](rni_arlink_design.md), [`rni_arctrl_design.md`](rni_arctrl_design.md) |
| 写路径 | [`rni_awctrl_design.md`](rni_awctrl_design.md) |

建议先按本文档把路线跑一遍，再用这些设计文档补细节。读 RNI 最重要的不是记住每个寄存器名字，而是能把一笔 read/write transaction 从 AXI 侧一路追到 CHI flit，再从 CHI response 追回 AXI response。
