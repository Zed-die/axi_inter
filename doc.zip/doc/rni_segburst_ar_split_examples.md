# rni_segburst AR 拆分说明与实例

## 1. 模块作用

`rni_segburst` 是 AXI AR/AW burst 到 RNI segment 的切分模块。放在读路径上看，它的位置是：

```text
AXI AR
  -> rni_arlink
      -> rni_segburst
          -> arlink_valid_s1_o
          -> arlink_addr_s1_o
          -> arlink_bc_vec_s2_o
          -> arlink_dmask_s2_o
          -> arlink_size_s2_o
  -> rni_arctrl
```

`rni_segburst` 做的事情可以概括为一句话：

```text
把一笔 AXI AR burst，按照 64B cacheline 边界切成一个或多个 segment，
并为每个 segment 生成 16B bank 粒度的 mask、beat count 和 CHI size 信息。
```

它不管理 `arctrl_entry`，不判断 request chain，也不真正发送 TXREQ。它只负责把原始 AR 请求拆成后级更容易处理的 segment。

## 2. 基本粒度

代码中定义：

```verilog
`define SEGB_CACHE_OFFSET 6
```

所以 `rni_segburst` 以 64B cacheline 为大边界。一个 64B cacheline 被拆成 4 个 16B bank：

```text
bank0: offset 0x00 ~ 0x0f, mask bit0, 4'b0001
bank1: offset 0x10 ~ 0x1f, mask bit1, 4'b0010
bank2: offset 0x20 ~ 0x2f, mask bit2, 4'b0100
bank3: offset 0x30 ~ 0x3f, mask bit3, 4'b1000
```

后面文档里的 mask 都按 `bank3 bank2 bank1 bank0` 的二进制形式写，例如：

```text
4'b0110 = 覆盖 bank1 和 bank2
4'b1100 = 覆盖 bank2 和 bank3
4'b1111 = 覆盖整个 64B cacheline
```

## 3. 输入字段如何理解

读路径中，`rni_arlink` 把 FIFO 头部 AR 请求送入 `rni_segburst`：

```verilog
axi_valid_s1_i    <- arvalid_s1
axi_addr_in_s1_i  <- ARADDR
axi_len_in_s1_i   <- ARLEN
axi_size_in_s1_i  <- ARSIZE
axi_burst_s1_i    <- ARBURST
axi_lock_in_s1_i  <- ARLOCK
stall_flag_s1_i   <- segburst_busy_s1_w
```

本文例子中：

```text
ARLEN  = AXI 编码长度，真实 beat 数 = ARLEN + 1
ARSIZE = AXI 单 beat 字节数编码，真实单 beat 字节数 = 2^ARSIZE
ARBURST:
    FIXED = 2'b00
    INCR  = 2'b01
    WRAP  = 2'b10
```

`rni_segburst` 会先把地址按 `ARSIZE` 对齐：

```verilog
axi_addr_align_w = (axi_addr_in_s1_i >> axi_size_in_s1_i) << axi_size_in_s1_i;
```

所以如果输入 `ARADDR` 不是 beat 对齐地址，后续范围判断以 `axi_addr_align_w` 为准。

## 4. 输出字段如何理解

读路径中，`rni_segburst` 输出到 `rni_arlink` 的主要信号是：

```text
arlink_valid_s1_o  : 当前 segment 有效
arlink_addr_s1_o   : 当前 segment 起始地址
arlink_dmask_s2_o  : 当前 segment 的 CT/PD/LS/RV mask
arlink_bc_vec_s2_o : 当前 segment 每个 bank 的 beat count
arlink_size_s2_o   : 当前 segment 的 CHI size 编码
```

注意时序上分两级：

```text
S1: arlink_valid_s1_o, arlink_addr_s1_o, segburst_done_s1_w
S2: arlink_dmask_s2_o, arlink_bc_vec_s2_o, arlink_size_s2_o
```

文档的表格为了方便理解，把 S1/S2 信息放在同一行描述同一个 segment；实际 RTL 里 `dmask/bc_vec/size` 比 `valid/addr/done` 晚一拍。

`arlink_dmask_s2_o` 的 16 bit 格式来自 `rni_defines.v`：

```text
[3:0]    CT mask
[7:4]    PD mask
[11:8]   LS mask
[15:12]  RV mask
```

字段含义：

```text
CT : Current mask，当前 segment 从哪个 16B bank 开始处理
PD : Pending/Data mask，当前 segment 覆盖哪些 16B bank
LS : Last mask，原始 AXI burst 的最后数据落在哪个 bank
RV : Return valid mask，rni_segburst 固定初始化为 4'b0000，后续由读返回路径更新
```

`arlink_bc_vec_s2_o` 也是 16 bit，每 4 bit 对应一个 bank：

```text
[3:0]    bank0 beat count
[7:4]    bank1 beat count
[11:8]   bank2 beat count
[15:12]  bank3 beat count
```

每个  的值是：

```text
该 bank 中需要处理的 AXI beat 数量 - 1
```

例如 `ARSIZE=4` 时每 beat 16B，一个 bank 通常只有 1 个 beat，所以对应 nibble 是 `4'h0`。如果 `ARSIZE=3`，每 beat 8B，一个完整 16B bank 有 2 个 beat，对应 nibble 是 `4'h1`。

## 5. 状态机如何拆分

`rni_segburst` 的状态有：

```verilog
`SEGB_PASS
`SEGB_INCR
`SEGB_MULTILINE_WRAP
`SEGB_SINGLELINE_WRAP
`SEGB_SINGLELINE_WRAP_FIRST_PART
`SEGB_SINGLELINE_WRAP_SECOND_PART
```

基本规则如下：

```text
不跨 64B 的 FIXED/INCR:
    SEGB_PASS 一拍输出完成

跨 64B 的 INCR:
    SEGB_PASS 输出第一段
    SEGB_INCR 输出后续段

WRAP 且 wrap region 跨多条 64B:
    SEGB_PASS 输出第一段
    SEGB_MULTILINE_WRAP 输出后续段

WRAP 且 wrap region 在单条 64B 内:
    如果从 wrap boundary 开始，输出 1 个 segment
    如果不是从 wrap boundary 开始，输出高地址部分 + 回绕后的低地址部分
```

`segburst_done_s1_o` 只在原始 AR burst 的最后一个 segment 拉高。`rni_arlink` 也正是等 `segburst_done_s1_w` 拉高后才 pop 当前 AR FIFO entry。

## 6. CHI size 的一个容易误解点

`segburst_size_s2_o` 不是简单等于当前 segment 的真实字节数。它由 segment 起始 bank 和末尾 bank 决定，倾向于选择能覆盖该访问范围的 16B/32B/64B 对齐窗口：

```text
3'b100 -> 16B
3'b101 -> 32B
3'b110 -> 64B
```

例如从 bank1 到 bank2，真实覆盖 32B，但跨过了 32B 半线边界，因此代码会生成 `3'b110`，也就是 64B。

读路径里还要注意一个实现细节：`rni_segburst` 会生成 `arlink_size_s2_o`，但当前 `rni_arctrl.v` 的 TXREQ 组包中如果把读请求 `Size` 固定成 `3'b110`，那属于下游 `rni_arctrl` 的发送策略，不改变 `rni_segburst` 本身的拆分结果。

## 7. INCR 示例 1：单 beat，单 bank

输入：

```text
ARADDR  = 0x1000
ARSIZE  = 4       // 16B per beat
ARLEN   = 0       // 1 beat
ARBURST = INCR
```

访问范围：

```text
0x1000 ~ 0x100f
```

拆分结果：

| segment | state_q | arlink_addr_s1_o | 覆盖范围 | CT | PD | LS | bc_vec | size | done |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | `SEGB_PASS` | `0x1000` | bank0 | `0001` | `0001` | `0001` | `16'h0000` | 16B | 1 |

说明：

```text
只覆盖 bank0，不跨 64B，所以一拍完成。
```

## 8. INCR 示例 2：两个 16B beat，自然落在 32B 半线内

输入：

```text
ARADDR  = 0x1000
ARSIZE  = 4       // 16B per beat
ARLEN   = 1       // 2 beat
ARBURST = INCR
```

访问范围：

```text
0x1000 ~ 0x101f
```

拆分结果：

| segment | state_q | arlink_addr_s1_o | 覆盖范围 | CT | PD | LS | bc_vec | size | done |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | `SEGB_PASS` | `0x1000` | bank0, bank1 | `0001` | `0011` | `0010` | `16'h0000` | 32B | 1 |

说明：

```text
bank0 + bank1 正好是低 32B 半线，所以 segburst_size_s2_o = 3'b101。
```

## 9. INCR 示例 3：两个 16B beat，但跨 32B 半线

输入：

```text
ARADDR  = 0x1010
ARSIZE  = 4       // 16B per beat
ARLEN   = 1       // 2 beat
ARBURST = INCR
```

访问范围：

```text
0x1010 ~ 0x102f
```

拆分结果：

| segment | state_q | arlink_addr_s1_o | 覆盖范围 | CT | PD | LS | bc_vec | size | done |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | `SEGB_PASS` | `0x1010` | bank1, bank2 | `0010` | `0110` | `0100` | `16'h0000` | 64B | 1 |

说明：

```text
真实数据只有 32B，但 bank1 -> bank2 跨过 offset[5]，代码会把 CHI size 生成为 64B。
```

## 10. INCR 示例 4：8B beat，单 segment 但每个 bank 的 bc_vec 不同

输入：

```text
ARADDR  = 0x1008
ARSIZE  = 3       // 8B per beat
ARLEN   = 3       // 4 beat
ARBURST = INCR
```

AXI beat 地址序列：

```text
0x1008, 0x1010, 0x1018, 0x1020
```

访问范围：

```text
0x1008 ~ 0x1027
```

拆分结果：

| segment | state_q | arlink_addr_s1_o | 覆盖范围 | CT | PD | LS | bc_vec | size | done |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | `SEGB_PASS` | `0x1008` | bank0 后半、bank1 全部、bank2 前半 | `0001` | `0111` | `0100` | `16'h0010` | 64B | 1 |

`bc_vec = 16'h0010` 的含义：

```text
bank0 nibble = 0, bank0 有 1 个 8B beat
bank1 nibble = 1, bank1 有 2 个 8B beat
bank2 nibble = 0, bank2 有 1 个 8B beat
bank3 nibble = 0, bank3 不参与
```

## 11. INCR 示例 5：从 bank3 跨到后面两条 cacheline

输入：

```text
ARADDR  = 0x1030
ARSIZE  = 4       // 16B per beat
ARLEN   = 5       // 6 beat
ARBURST = INCR
```

AXI beat 地址序列：

```text
0x1030, 0x1040, 0x1050, 0x1060, 0x1070, 0x1080
```

访问范围：

```text
0x1030 ~ 0x108f
```

拆分结果：

| segment | state_q | arlink_addr_s1_o | 覆盖范围 | CT | PD | LS | bc_vec | size | done |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | `SEGB_PASS` | `0x1030` | bank3 | `1000` | `1000` | `0000` | `16'h0000` | 16B | 0 |
| 1 | `SEGB_INCR` | `0x1040` | bank0 ~ bank3 | `0001` | `1111` | `0000` | `16'h0000` | 64B | 0 |
| 2 | `SEGB_INCR` | `0x1080` | bank0 | `0001` | `0001` | `0001` | `16'h0000` | 16B | 1 |

说明：

```text
第一段只补完 0x1000 这条 cacheline 的 bank3。
第二段是完整 64B cacheline。
第三段是最后一条 cacheline 的 bank0，同时 LS=0001，done=1。
```

## 12. INCR 示例 6：从 bank2 跨一条 cacheline

输入：

```text
ARADDR  = 0x1020
ARSIZE  = 4       // 16B per beat
ARLEN   = 4       // 5 beat
ARBURST = INCR
```

AXI beat 地址序列：

```text
0x1020, 0x1030, 0x1040, 0x1050, 0x1060
```

拆分结果：

| segment | state_q | arlink_addr_s1_o | 覆盖范围 | CT | PD | LS | bc_vec | size | done |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | `SEGB_PASS` | `0x1020` | bank2, bank3 | `0100` | `1100` | `0000` | `16'h0000` | 32B | 0 |
| 1 | `SEGB_INCR` | `0x1040` | bank0, bank1, bank2 | `0001` | `0111` | `0100` | `16'h0000` | 64B | 1 |

说明：

```text
第 0 段从 bank2 开始到当前 cacheline 末尾。
第 1 段从下一条 64B cacheline 的 bank0 开始，到 bank2 结束。
```

## 13. INCR 示例 7：两个完整 cacheline

输入：

```text
ARADDR  = 0x1000
ARSIZE  = 4       // 16B per beat
ARLEN   = 7       // 8 beat
ARBURST = INCR
```

访问范围：

```text
0x1000 ~ 0x107f
```

拆分结果：

| segment | state_q | arlink_addr_s1_o | 覆盖范围 | CT | PD | LS | bc_vec | size | done |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | `SEGB_PASS` | `0x1000` | bank0 ~ bank3 | `0001` | `1111` | `0000` | `16'h0000` | 64B | 0 |
| 1 | `SEGB_INCR` | `0x1040` | bank0 ~ bank3 | `0001` | `1111` | `1000` | `16'h0000` | 64B | 1 |

说明：

```text
虽然两个 segment 都是完整 64B，但只有最后一个 segment 的 LS=1000 且 done=1。
```

## 14. INCR 示例 8：4B beat 从 bank0 中间跨到 bank1

输入：

```text
ARADDR  = 0x1004
ARSIZE  = 2       // 4B per beat
ARLEN   = 3       // 4 beat
ARBURST = INCR
```

AXI beat 地址序列：

```text
0x1004, 0x1008, 0x100c, 0x1010
```

访问范围：

```text
0x1004 ~ 0x1013
```

拆分结果：

| segment | state_q | arlink_addr_s1_o | 覆盖范围 | CT | PD | LS | bc_vec | size | done |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | `SEGB_PASS` | `0x1004` | bank0 后 12B、bank1 前 4B | `0001` | `0011` | `0010` | `16'h0002` | 32B | 1 |

`bc_vec = 16'h0002` 的含义：

```text
bank0 nibble = 2, bank0 有 3 个 4B beat
bank1 nibble = 0, bank1 有 1 个 4B beat
```

## 15. FIXED 示例：多个 beat 固定在同一 bank

输入：

```text
ARADDR  = 0x1020
ARSIZE  = 4       // 16B per beat
ARLEN   = 3       // 4 beat
ARBURST = FIXED
```

FIXED burst 的地址不递增，所以 4 个 beat 都认为落在同一个 bank2。

拆分结果：

| segment | state_q | arlink_addr_s1_o | 覆盖范围 | CT | PD | LS | bc_vec | size | done |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | `SEGB_PASS` | `0x1020` | bank2 | `0100` | `0100` | `0100` | `16'h0300` | 16B | 1 |

`bc_vec = 16'h0300` 的含义：

```text
bank2 nibble = 3, bank2 有 4 个 beat
```

## 16. WRAP 示例 1：single-line WRAP，从 wrap boundary 开始

输入：

```text
ARADDR  = 0x1000
ARSIZE  = 4       // 16B per beat
ARLEN   = 3       // 4 beat
ARBURST = WRAP
```

AXI beat 地址序列：

```text
0x1000, 0x1010, 0x1020, 0x1030
```

这笔 WRAP 的 wrap region 是 `0x1000 ~ 0x103f`，且从 region 起点开始，所以最终只需要一个 segment。

注意：代码会先在 `SEGB_PASS` 进入 `SEGB_SINGLELINE_WRAP`，`SEGB_PASS` 当拍不输出有效 segment；下一拍 `SEGB_SINGLELINE_WRAP` 输出下面这一段。

| segment | state_q | arlink_addr_s1_o | 覆盖范围 | CT | PD | LS | bc_vec | size | done |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | `SEGB_SINGLELINE_WRAP` | `0x1000` | bank0 ~ bank3 | `0001` | `1111` | `1000` | `16'h0000` | 64B | 1 |

## 17. WRAP 示例 2：single-line WRAP，从 bank3 开始

输入：

```text
ARADDR  = 0x1030
ARSIZE  = 4       // 16B per beat
ARLEN   = 3       // 4 beat
ARBURST = WRAP
```

AXI beat 地址序列：

```text
0x1030, 0x1000, 0x1010, 0x1020
```

wrap region 仍然是 `0x1000 ~ 0x103f`，但起点不是 `addr_boundary_wrap_s1_w`，所以模块拆成两段：

```text
first part : 0x1030，高地址部分
second part: 0x1000 ~ 0x102f，回绕后的低地址部分
```

拆分结果：

| segment | state_q | arlink_addr_s1_o | 覆盖范围 | CT | PD | LS | bc_vec | size | done |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | `SEGB_SINGLELINE_WRAP_FIRST_PART` | `0x1030` | bank3 | `1000` | `1000` | `0000` | `16'h0000` | 16B | 0 |
| 1 | `SEGB_SINGLELINE_WRAP_SECOND_PART` | `0x1000` | bank0, bank1, bank2 | `0001` | `0111` | `0100` | `16'h0000` | 64B | 1 |

说明：

```text
LS=0100 出现在 second part，因为 AXI 逻辑顺序的最后一个 beat 是 0x1020。
```

## 18. WRAP 示例 3：single-line WRAP，从 bank2 开始

输入：

```text
ARADDR  = 0x1020
ARSIZE  = 4       // 16B per beat
ARLEN   = 3       // 4 beat
ARBURST = WRAP
```

AXI beat 地址序列：

```text
0x1020, 0x1030, 0x1000, 0x1010
```

拆分结果：

| segment | state_q | arlink_addr_s1_o | 覆盖范围 | CT | PD | LS | bc_vec | size | done |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | `SEGB_SINGLELINE_WRAP_FIRST_PART` | `0x1020` | bank2, bank3 | `0100` | `1100` | `0000` | `16'h0000` | 32B | 0 |
| 1 | `SEGB_SINGLELINE_WRAP_SECOND_PART` | `0x1000` | bank0, bank1 | `0001` | `0011` | `0010` | `16'h0000` | 32B | 1 |

说明：

```text
这个例子刚好被拆成两个 32B 半线。
```

## 19. WRAP 示例 4：multiline WRAP，从 wrap boundary 开始

输入：

```text
ARADDR  = 0x1000
ARSIZE  = 4       // 16B per beat
ARLEN   = 7       // 8 beat，wrap region 128B
ARBURST = WRAP
```

AXI beat 地址序列：

```text
0x1000, 0x1010, 0x1020, 0x1030,
0x1040, 0x1050, 0x1060, 0x1070
```

wrap region 是 `0x1000 ~ 0x107f`，跨两条 64B cacheline。

拆分结果：

| segment | state_q | arlink_addr_s1_o | 覆盖范围 | CT | PD | LS | bc_vec | size | done |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | `SEGB_PASS` | `0x1000` | bank0 ~ bank3 | `0001` | `1111` | `0000` | `16'h0000` | 64B | 0 |
| 1 | `SEGB_MULTILINE_WRAP` | `0x1040` | bank0 ~ bank3 | `0001` | `1111` | `1000` | `16'h0000` | 64B | 1 |

说明：

```text
这是 multiline WRAP，但因为从 wrap boundary 开始，segment 地址仍然单调递增。
```

## 20. WRAP 示例 5：multiline WRAP，从高地址 line 的 bank1 开始

输入：

```text
ARADDR  = 0x1050
ARSIZE  = 4       // 16B per beat
ARLEN   = 7       // 8 beat，wrap region 128B
ARBURST = WRAP
```

AXI beat 地址序列：

```text
0x1050, 0x1060, 0x1070,
0x1000, 0x1010, 0x1020, 0x1030, 0x1040
```

wrap region 是：

```text
0x1000 ~ 0x107f
```

`addr_boundary_wrap_s1_w = 0x1000`，`addr_multiline_wrap_final_s1_w = 0x1040`。因为起点已经在 final line 内部，所以 segment 地址顺序会是：

```text
0x1050 -> 0x1000 -> 0x1040
```

拆分结果：

| segment | state_q | arlink_addr_s1_o | 覆盖范围 | CT | PD | LS | bc_vec | size | done |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | `SEGB_PASS` | `0x1050` | bank1, bank2, bank3 | `0010` | `1110` | `0000` | `16'h0000` | 64B | 0 |
| 1 | `SEGB_MULTILINE_WRAP` | `0x1000` | bank0 ~ bank3 | `0001` | `1111` | `0000` | `16'h0000` | 64B | 0 |
| 2 | `SEGB_MULTILINE_WRAP` | `0x1040` | bank0 | `0001` | `0001` | `0001` | `16'h0000` | 16B | 1 |

说明：

```text
WRAP 的 segment 顺序跟 AXI 逻辑访问顺序一致，不一定按地址单调递增。
最后一个 beat 是 0x1040，所以最后一段 LS=0001。
```

## 21. WRAP 示例 6：multiline WRAP，从第二条 line 起点开始

输入：

```text
ARADDR  = 0x1040
ARSIZE  = 4       // 16B per beat
ARLEN   = 7       // 8 beat，wrap region 128B
ARBURST = WRAP
```

AXI beat 地址序列：

```text
0x1040, 0x1050, 0x1060, 0x1070,
0x1000, 0x1010, 0x1020, 0x1030
```

拆分结果：

| segment | state_q | arlink_addr_s1_o | 覆盖范围 | CT | PD | LS | bc_vec | size | done |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | `SEGB_PASS` | `0x1040` | bank0 ~ bank3 | `0001` | `1111` | `0000` | `16'h0000` | 64B | 0 |
| 1 | `SEGB_MULTILINE_WRAP` | `0x1000` | bank0 ~ bank3 | `0001` | `1111` | `1000` | `16'h0000` | 64B | 1 |

说明：

```text
第一段在 wrap region 的高 64B，第二段回绕到低 64B。
```

## 22. stall_flag_s1_i 对拆分的影响

读路径中：

```verilog
assign segburst_busy_s1_w = alloc_busy_s1_i;
```

也就是说当 `rni_arctrl` 没有空 entry 时，`rni_arlink` 会通过 `stall_flag_s1_i` 暂停 `rni_segburst`。

`stall_flag_s1_i = 1` 时：

```text
segburst_valid_s1_o 不输出有效 segment
state_q 不推进
txn_cnt_q 不更新
axi_addr_q 不更新
当前 AXI AR FIFO entry 不会因为 done 被 pop
```

这保证了跨多个 segment 的 AR burst 不会在后级没有 entry 时丢段。

## 23. 和 rni_arctrl entry 的关系

每当 `arlink_valid_s1_o` 输出一个 segment，`rni_arctrl` 就会为它分配一个 AR entry。也就是说：

```text
一笔 AXI AR burst
    -> rni_segburst 拆成 N 个 segment
        -> rni_arctrl 分配 N 个 entry
```

例如第 11 节的 AR：

```text
ARADDR=0x1030, ARSIZE=4, ARLEN=5, ARBURST=INCR
```

会拆成 3 个 segment，因此会占用 3 个 `arctrl_entry`：

```text
entry A: addr 0x1030, PD=1000
entry B: addr 0x1040, PD=1111
entry C: addr 0x1080, PD=0001, LS=0001
```

如果这些 segment 属于同一条原始 AR 请求，后续 `rni_arctrl` 还会通过 req chain / rdata chain 保证 TXREQ 发送顺序和 AXI RDATA 返回顺序。`rni_segburst` 只负责把这些 segment 产生出来。

## 24. 快速判断方法

看一笔 AR 会被拆成几个 segment，可以按下面步骤：

```text
1. 先用 ARSIZE 对齐 ARADDR，得到 axi_addr_align_w。
2. 根据 ARLEN 和 ARSIZE 算出总覆盖范围。
3. 看覆盖范围跨了几个 64B cacheline。
4. INCR:
      不跨 64B -> 1 个 segment
      跨 64B   -> 第一条 line 尾部 + 中间完整 line + 最后一条 line 头部
5. WRAP:
      wrap region 在单条 64B 内:
          从 boundary 开始 -> 1 个 segment
          不从 boundary 开始 -> 高地址部分 + 低地址部分
      wrap region 跨多条 64B:
          按 AXI WRAP 逻辑顺序输出 cacheline segment，可能会从高地址跳回 boundary
6. 每个 segment 内再根据 bank 范围生成 CT/PD/LS/bc_vec。
```

这就是 `rni_segburst` 的核心设计：先按 64B cacheline 拆大段，再按 16B bank 描述每段内部的数据覆盖情况。
