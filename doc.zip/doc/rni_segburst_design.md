# rni_segburst 设计说明

## 1. 模块定位

`rni_segburst` 是 RNI 前端的 AXI burst 切段模块。它接收一笔 AXI AR/AW burst 的地址、长度、大小和 burst 类型信息，将其转换成一个或多个以 64B cacheline 为边界的 RNI segment。

它被读写地址入口共同复用：

```text
AXI AR -> rni_arlink -> rni_segburst -> rni_arctrl -> CHI ReadOnce
AXI AW -> rni_awlink -> rni_segburst -> rni_awctrl -> CHI WriteUniquePtl
```

`rni_segburst` 不负责 outstanding entry 管理，也不负责 CHI flit 的最终组包。它只负责把 AXI burst 规整成后级能分配 entry 的 segment，并为每个 segment 生成地址、size、bank mask 和 beat count。

## 2. 为什么需要切段

AXI burst 可以跨越多个 64B cacheline，例如：

```text
起始地址: 0x30
覆盖范围: 0x30 ~ 0x8f
```

这笔 burst 跨过了 0x40 和 0x80 两个 64B 边界。RNI/CHI 后级更适合按 cacheline 或 cacheline 内 16B bank 粒度处理，所以需要切成：

```text
segment0: 0x30 ~ 0x3f
segment1: 0x40 ~ 0x7f
segment2: 0x80 ~ 0x8f
```

切段后的每个 segment 都可以独立分配 RNI entry，并生成对应的 CHI request。

## 3. 基本粒度

模块中定义：

```verilog
`define SEGB_CACHE_OFFSET 6
```

因此 cacheline 粒度是：

```text
2^6 = 64B
```

同时，一个 64B cacheline 被看成 4 个 16B bank：

```text
bank0: offset 0x00 ~ 0x0f
bank1: offset 0x10 ~ 0x1f
bank2: offset 0x20 ~ 0x2f
bank3: offset 0x30 ~ 0x3f
```

后续的 `ctmask`、`pdmask`、`lsmask`、`bc_vec` 都围绕这 4 个 bank 生成。

## 4. 输入接口

主要输入如下：

```verilog
input wire                           axi_valid_s1_i;
input wire [`AXI4_AWADDR_WIDTH-1:0]  axi_addr_in_s1_i;
input wire [`AXI4_AWLEN_WIDTH-1:0]   axi_len_in_s1_i;
input wire [`AXI4_AWSIZE_WIDTH-1:0]  axi_size_in_s1_i;
input wire [`AXI4_AWBURST_WIDTH-1:0] axi_burst_s1_i;
input wire                           axi_lock_in_s1_i;
input wire                           stall_flag_s1_i;
```

含义如下：

| 信号 | 含义 |
| --- | --- |
| `axi_valid_s1_i` | 当前输入 burst 有效。对 AR/AW link 来说，通常表示入口 FIFO 非空 |
| `axi_addr_in_s1_i` | AXI burst 起始地址 |
| `axi_len_in_s1_i` | AXI `AxLEN`，真实 beat 数为 `AxLEN + 1` |
| `axi_size_in_s1_i` | AXI `AxSIZE`，单 beat 字节数为 `2^AxSIZE` |
| `axi_burst_s1_i` | AXI burst 类型，支持 FIXED / INCR / WRAP |
| `axi_lock_in_s1_i` | AXI lock 属性，打一拍后输出 |
| `stall_flag_s1_i` | 后级反压。为 1 时暂停切段输出 |

虽然端口命名使用 AW 字段宽度，例如 `AXI4_AWADDR_WIDTH`，但该模块同时用于 AR 和 AW。通常 AXI AR/AW 地址、长度、size、burst 字段宽度一致，因此可以复用。

## 5. 输出接口

主要输出如下：

```verilog
output reg  [`AXI4_AWADDR_WIDTH-1:0]         segburst_addr_s1_o;
output reg                                   segburst_valid_s1_o;
output reg                                   segburst_done_s1_o;
output reg  [`RNI_BCVEC_WIDTH-1:0]           segburst_bc_vec_s2_o;
output wire [`RNI_DMASK_WIDTH-1:0]           segburst_dmask_s2_o;
output wire [`CHIE_REQ_FLIT_SIZE_WIDTH-1:0]  segburst_size_s2_o;
output wire                                  segburst_lock_s2_o;
```

含义如下：

| 信号 | 含义 |
| --- | --- |
| `segburst_valid_s1_o` | 当前输出 segment 有效 |
| `segburst_addr_s1_o` | 当前 segment 的起始地址 |
| `segburst_done_s1_o` | 当前 segment 是原始 AXI burst 的最后一段 |
| `segburst_bc_vec_s2_o` | 4 个 16B bank 的 beat count vector |
| `segburst_dmask_s2_o` | 当前 segment 的 data mask |
| `segburst_size_s2_o` | 当前 segment 的 CHI request size |
| `segburst_lock_s2_o` | 输入 lock 属性的寄存输出 |

`valid/addr/done` 是 S1 阶段信号；`bc_vec/dmask/size/lock` 是 S2 阶段信号。

## 6. 输出时序

模块内部对部分输出打一拍：

```verilog
if (segburst_valid_s1_o) begin
    segburst_dmask_q      <= segburst_dmask_s1_r;
    segburst_bc_vec_s2_o  <= chi_bc_vec_s1_r;
    chi_size_q            <= chi_size_s1_r;
end
```

因此后级使用时要注意：

```text
S1: segburst_valid_s1_o, segburst_addr_s1_o, segburst_done_s1_o
S2: segburst_dmask_s2_o, segburst_bc_vec_s2_o, segburst_size_s2_o
```

`rni_arctrl` 和 `rni_awctrl` 中一般会把 S1 的 entry 分配指针打一拍，与 S2 的 mask/size/bc 信息对齐。

## 7. 地址规整与范围计算

模块首先将输入 AXI 地址按 `AxSIZE` 对齐：

```verilog
axi_addr_align_w = (axi_addr_in_s1_i >> axi_size_in_s1_i) << axi_size_in_s1_i;
```

然后计算 AXI burst 的真实 beat 数：

```verilog
axi_len_plusone_s1_w = axi_len_in_s1_i + 1'b1;
```

总字节覆盖范围减 1：

```verilog
axi_bytes_subone_w = ((axi_len_in_s1_i + 1) << axi_size_in_s1_i) - 1;
```

最后一个 byte 的地址低 12 位：

```verilog
addr_plus_bytes_w = axi_addr_align_w[11:0] + axi_bytes_subone_w;
```

最后一个 beat 的起始地址低 12 位：

```verilog
axi_last_trans_addr_w = axi_addr_align_w[11:0] +
                        (axi_len_in_s1_i << axi_size_in_s1_i);
```

这些计算用于判断 burst 是否跨 64B cacheline，以及最后一个 segment 覆盖到哪个 bank。

## 8. Burst 类型判断

模块根据 `axi_burst_s1_i` 解码 AXI burst 类型：

```verilog
axi_burst_fix_w  = ~|axi_burst_s1_i;
axi_burst_incr_w = axi_burst_s1_i[0];
axi_burst_wrap_w = axi_burst_s1_i[1];
```

对应 AXI 编码：

```text
FIXED: 2'b00
INCR : 2'b01
WRAP : 2'b10
```

## 9. 跨 cacheline 判断

对于 INCR burst：

```verilog
cacheline_cnt_incr_w =
    addr_plus_bytes_w[11:6] - axi_addr_align_w[11:6];
```

如果 `cacheline_cnt_incr_w != 0`，说明该 INCR burst 跨越了至少一个 64B 边界，需要进入 `SEGB_INCR` 状态继续切段。

对于 WRAP burst：

```verilog
cacheline_cnt_wrap_w = axi_bytes_subone_w[11:6];
```

如果 `cacheline_cnt_wrap_w != 0`，说明 WRAP burst 覆盖范围超过一个 64B cacheline，需要走 multiline wrap。

如果 WRAP burst 没跨 64B，则走 single-line wrap。

## 10. WRAP 边界计算

AXI WRAP burst 的地址会在 wrap 区间内回绕。模块通过下面逻辑计算 wrap 起始边界：

```verilog
addr_div_size_w = axi_addr_align_w >> axi_size_in_s1_i;

addr_boundary_and_len_wrap_w =
    {addr_div_size_w[ADDR_WIDTH-1:4],
     addr_div_size_w[3:0] & (~axi_len_in_s1_i[3:0])};

addr_boundary_wrap_s1_w =
    addr_boundary_and_len_wrap_w << axi_size_in_s1_i;
```

直观理解：

```text
先把 byte address 转成 beat address
再根据 burst length 找到 wrap 对齐边界
最后转回 byte address
```

对 multiline wrap，还需要找到高地址方向走到哪里后回绕：

```verilog
addr_multiline_wrap_final_s1_w
```

该信号用于在 `SEGB_MULTILINE_WRAP` 状态中判断什么时候从高地址部分跳回 wrap boundary。

## 11. 状态机

状态定义如下：

```verilog
`define SEGB_PASS
`define SEGB_INCR
`define SEGB_MULTILINE_WRAP
`define SEGB_SINGLELINE_WRAP
`define SEGB_SINGLELINE_WRAP_FIRST_PART
`define SEGB_SINGLELINE_WRAP_SECOND_PART
```

各状态含义如下：

| 状态 | 含义 |
| --- | --- |
| `SEGB_PASS` | 默认状态。直接通过不跨线 burst，或输出跨线 burst 的第一段 |
| `SEGB_INCR` | 处理跨 64B 的 INCR burst 后续 segment |
| `SEGB_MULTILINE_WRAP` | 处理跨多条 64B cacheline 的 WRAP burst |
| `SEGB_SINGLELINE_WRAP` | 处理范围在同一条 64B cacheline 内的 WRAP burst |
| `SEGB_SINGLELINE_WRAP_FIRST_PART` | single-line WRAP 的高地址部分 |
| `SEGB_SINGLELINE_WRAP_SECOND_PART` | single-line WRAP 回绕后的低地址部分 |

状态推进条件：

```verilog
state_enable_w = ~stall_flag_s1_i & axi_valid_s1_i;
```

所以当输入无效或后级 stall 时，状态机不会前进。

## 12. 状态跳转

在 `SEGB_PASS` 中，根据 burst 类型和跨线情况选择下一个状态：

```text
WRAP 且不跨 64B -> SEGB_SINGLELINE_WRAP
WRAP 且跨 64B   -> SEGB_MULTILINE_WRAP
INCR 且跨 64B   -> SEGB_INCR
其他情况        -> SEGB_PASS
```

`SEGB_INCR` 和 `SEGB_MULTILINE_WRAP` 通过 `txn_cnt_q` 计数，直到最后一个 segment 输出后回到 `SEGB_PASS`。

single-line WRAP 可能需要拆成两段：

```text
SEGB_SINGLELINE_WRAP
    -> SEGB_SINGLELINE_WRAP_FIRST_PART
        -> SEGB_SINGLELINE_WRAP_SECOND_PART
            -> SEGB_PASS
```

## 13. Segment 地址生成

在 `SEGB_PASS` 中，第一段地址就是输入地址：

```verilog
segburst_addr_s1_o = axi_addr_in_s1_i;
```

在 `SEGB_INCR` 中，后续段地址按 64B 对齐递增：

```verilog
segburst_addr_s1_o =
    (axi_addr_q[ADDR_WIDTH-1:6] + 1'b1) << 6;
```

在 `SEGB_MULTILINE_WRAP` 中，如果还没到 wrap final，就继续递增 64B；如果到了 wrap final，则跳回 wrap boundary：

```text
如果当前 cacheline == wrap final cacheline:
    下一段地址 = addr_boundary_wrap_q
否则:
    下一段地址 = 下一条 64B cacheline
```

在 single-line WRAP 中，模块会输出高地址部分和回绕后的低地址部分。

## 14. txn_cnt_q 的作用

`txn_cnt_q` 用来记录当前 AXI burst 还需要输出多少个后续 segment。

在 `SEGB_PASS` 中遇到跨线 burst 时，模块会根据覆盖的 cacheline 数量初始化 `txn_cnt_s1_r`：

```text
INCR 跨线      -> cacheline_cnt_incr_w
WRAP 跨多线    -> txn_cnt_multi_wrap_w
WRAP 单线特殊  -> txn_cnt_single_wrap_w + 1
FIXED          -> axi_len
```

在后续状态中，每输出一个 segment，`txn_cnt_q` 减 1。减到 0 后回到 `SEGB_PASS`。

## 15. segburst_done_s1_o

`segburst_done_s1_o` 表示原始 AXI burst 的所有 segment 已经输出完成。

它的典型用途是在 `rni_arlink` / `rni_awlink` 中 pop 原始 AXI address FIFO：

```text
done=0: 当前 AXI burst 还没切完，FIFO 头部不能弹出
done=1: 当前 AXI burst 已经切完，可以 pop，处理下一笔 AXI burst
```

所以 `done` 是连接切段器和入口 FIFO 的关键控制信号。

## 16. dmask 格式

`segburst_dmask_s2_o` 是 16 bit，字段定义来自 `rni_defines.v`：

```text
[3:0]    CT mask
[7:4]    PD mask
[11:8]   LS mask
[15:12]  RV mask
```

含义如下：

| 字段 | 含义 |
| --- | --- |
| `CT` | Current mask，当前 segment 首个待处理 bank |
| `PD` | Pending/Data mask，当前 segment 覆盖哪些 16B bank |
| `LS` | Last mask，哪个 bank 是当前 AXI burst 的最后部分 |
| `RV` | Return valid mask，初始化为 0，读返回路径后续更新 |

组装逻辑：

```verilog
segburst_dmask_s1_r[`RNI_DMASK_CT_RANGE] = chi_ct_vec_s1_r;
segburst_dmask_s1_r[`RNI_DMASK_PD_RANGE] = chi_pd_vec_s1_r;
segburst_dmask_s1_r[`RNI_DMASK_LS_RANGE] = chi_ls_vec_s1_r;
segburst_dmask_s1_r[`RNI_DMASK_RV_RANGE] = 4'b0000;
```

## 17. CT mask

`CT` 默认由当前 segment 地址所在的 16B bank 决定：

```verilog
chi_ct_vec_s1_r = 4'b0001 << segburst_addr_s1_o[5:4];
```

例如：

```text
addr[5:4] = 2'b00 -> CT = 4'b0001
addr[5:4] = 2'b01 -> CT = 4'b0010
addr[5:4] = 2'b10 -> CT = 4'b0100
addr[5:4] = 2'b11 -> CT = 4'b1000
```

后级可以用 CT 知道当前 segment 从哪个 16B bank 开始处理。

## 18. PD mask

`PD` 表示当前 segment 覆盖哪些 16B bank。

例如：

```text
segment 覆盖 bank0             -> PD = 4'b0001
segment 覆盖 bank1 和 bank2    -> PD = 4'b0110
segment 覆盖 bank0~bank3       -> PD = 4'b1111
segment 覆盖 bank2~bank3       -> PD = 4'b1100
```

对于跨线 INCR burst 的中间完整 cacheline，通常：

```verilog
PD = 4'b1111
```

对于第一段或最后一段，PD 会根据起始 offset 和结束 offset 生成部分 bank mask。

## 19. LS mask

`LS` 表示当前 AXI burst 的最后数据落在哪个 bank。

如果当前 segment 不是最后一个 segment，`LS` 通常为 0。

如果当前 segment 是最后一段，则根据最后覆盖到的 bank 设置：

```text
最后落在 bank0 -> LS = 4'b0001
最后落在 bank1 -> LS = 4'b0010
最后落在 bank2 -> LS = 4'b0100
最后落在 bank3 -> LS = 4'b1000
```

后级可用 LS 判断 AXI RLAST 或 B response 何时可以产生。

## 20. RV mask

`RV` 在本模块中固定初始化为 0：

```verilog
segburst_dmask_s1_r[`RNI_DMASK_RV_RANGE] = 4'b0000;
```

读路径中，`rni_arctrl` 和 `rni_rd_buffer` 会根据 RXDAT 返回情况逐步更新 RV mask，用它记录哪些 data bank 已经返回。

## 21. bc_vec 格式

`segburst_bc_vec_s2_o` 是 16 bit，每 4 bit 对应一个 16B bank：

```text
[3:0]    bank0 beat count
[7:4]    bank1 beat count
[11:8]   bank2 beat count
[15:12]  bank3 beat count
```

模块内部先计算三类基础 beat count：

```verilog
chi_bc_first_w
chi_bc_middle_w
chi_bc_last_w
```

含义：

- `first`：起始 bank 中剩余需要处理的 beat 数。
- `middle`：完整覆盖一个 16B bank 时的 beat 数。
- `last`：最后一个 bank 中需要处理的 beat 数。

然后根据当前 segment 覆盖的 bank 范围，把这些值放入 `bc_vec` 的对应 4-bit 字段。

## 22. CHI size 生成

`segburst_size_s2_o` 表示当前 segment 对应的 CHI request size，不是 AXI `AxSIZE` 的简单透传。

AXI `AxSIZE` 是单个 AXI beat 的大小；而 `segburst_size_s2_o` 描述当前 segment 覆盖的整体范围。

常见编码：

```text
3'b100 -> 16B
3'b101 -> 32B
3'b110 -> 64B
```

模块根据起始 bank 和最后 bank 的相对位置生成 16B、32B 或 64B 的 CHI size。

## 23. FIXED burst 处理

对于 FIXED burst，地址不递增，因此模块不会按 cacheline 递增地址切段。它在 `SEGB_PASS` 中直接输出当前地址所在 bank 的 mask。

相关逻辑：

```verilog
if (axi_burst_fix_w) begin
    chi_pd_vec_s1_r = 4'b0001 << axi_addr_align_w[5:4];
    chi_ls_vec_s1_r = 4'b0001 << axi_addr_align_w[5:4];
    chi_bc_vec_s1_r = {12'b0, axi_len_in_s1_i[3:0]}
                      << {axi_addr_align_w[5:4], 2'b00};
end
```

也就是说，FIXED burst 被看成集中落在同一个 16B bank。

## 24. INCR burst 处理

INCR burst 是最常见情况。

如果不跨 64B，则在 `SEGB_PASS` 中一次输出完成：

```text
state = SEGB_PASS
valid = 1
done  = 1
```

如果跨 64B：

```text
SEGB_PASS 输出第一段
SEGB_INCR 输出后续段
最后一段 done=1
```

第一段从原始地址开始，可能只覆盖当前 cacheline 的后半部分。中间段通常覆盖完整 64B。最后一段根据结束地址只覆盖部分 bank。

## 25. WRAP burst 处理

WRAP burst 有两种情况。

第一种是 multiline wrap，即 wrap 范围跨多个 64B cacheline：

```text
SEGB_PASS
    -> SEGB_MULTILINE_WRAP
```

地址先向高地址方向按 64B 前进，走到 wrap final 后跳回 wrap boundary。

第二种是 single-line wrap，即 wrap 范围仍在同一条 64B cacheline 内：

```text
SEGB_PASS
    -> SEGB_SINGLELINE_WRAP
        -> SEGB_SINGLELINE_WRAP_FIRST_PART
            -> SEGB_SINGLELINE_WRAP_SECOND_PART
```

这类情况虽然不跨 64B，但由于 WRAP 地址顺序不是简单递增，可能需要拆成高地址部分和低地址部分。

## 26. stall_flag_s1_i 机制

`stall_flag_s1_i` 是后级反压信号。

当它为 1 时：

- `segburst_valid_s1_o` 不再输出有效 segment。
- 状态机不前进。
- `txn_cnt_q` 不更新。
- `axi_addr_q` 不更新。
- `axi_lock_q` 不更新。

这保证了后级暂时不能接收 segment 时，切段器不会丢失当前 burst 的进度。

读路径中，stall 来源通常是：

```text
rni_arctrl 的 AR entry 全满
```

写路径中，stall 来源通常是：

```text
rni_awctrl 的 AW entry 全满
或 wr_buffer 的 AW request FIFO 接近满
```

## 27. 与 rni_arlink 的配合

`rni_arlink` 将 AXI AR 请求缓存进一个 2-entry FIFO。FIFO 头部的 AR 信息送入 `rni_segburst`。

`rni_segburst` 每输出一个 segment，`rni_arctrl` 就为该 segment 分配一个 AR entry。

当 `segburst_done_s1_o=1` 时，说明当前 AXI AR burst 全部切完，`rni_arlink` 才 pop FIFO。

```text
rni_arlink FIFO 中的一笔 AR
    -> rni_segburst 可能输出多个 read segment
    -> 最后一个 segment done=1
    -> FIFO pop
```

## 28. 与 rni_awlink 的配合

`rni_awlink` 与 `rni_arlink` 类似，也是将 AXI AW 请求缓存后送入 `rni_segburst`。

区别是写路径还需要与写数据 buffer 配合。每个 AW segment 不仅要分配 AW entry，还要在 `rni_wr_buffer` 中记录该 segment 对应的数据 mask 和 beat count，用于后续收集 WDATA。

因此写路径的 stall 条件比读路径更多。

## 29. 设计例子：不跨线 INCR

假设：

```text
addr  = 0x10
size  = 4, 每 beat 16B
len   = 1, 共 2 beat
burst = INCR
```

覆盖范围：

```text
0x10 ~ 0x2f
```

这只覆盖 bank1 和 bank2，不跨 64B。

输出：

```text
segment 数量 = 1
addr         = 0x10
done         = 1
PD           = 4'b0110
LS           = 4'b0100
size         = 32B
```

## 30. 设计例子：跨线 INCR

假设：

```text
addr  = 0x30
size  = 4, 每 beat 16B
len   = 5, 共 6 beat
burst = INCR
```

覆盖范围：

```text
0x30 ~ 0x8f
```

切段：

```text
segment0: 0x30 ~ 0x3f
segment1: 0x40 ~ 0x7f
segment2: 0x80 ~ 0x8f
```

输出序列：

```text
cycle A:
    state = SEGB_PASS
    addr  = 0x30
    done  = 0
    PD    = 4'b1000

cycle B:
    state = SEGB_INCR
    addr  = 0x40
    done  = 0
    PD    = 4'b1111

cycle C:
    state = SEGB_INCR
    addr  = 0x80
    done  = 1
    PD    = 4'b0001
    LS    = 4'b0001
```

## 31. 设计例子：single-line WRAP

假设一笔 WRAP burst 的范围仍在同一条 64B cacheline 内，但起始地址不是 wrap boundary。

例如逻辑访问顺序类似：

```text
0x30 -> 0x00 -> 0x10 -> 0x20
```

虽然所有地址都在同一条 64B line 内，但访问顺序发生回绕。模块会将其拆成：

```text
first part : 0x30 附近的高地址部分
second part: wrap boundary 开始的低地址部分
```

这样后级可以按连续 segment 处理，而不需要自己理解 AXI WRAP 地址顺序。

## 32. 设计特点总结

`rni_segburst` 的设计特点如下：

- 按 64B cacheline 边界切分 AXI burst。
- 在 64B 内进一步生成 4 个 16B bank 的 mask。
- 支持 FIXED、INCR、WRAP 三类 AXI burst。
- 对跨线 INCR 和跨线 WRAP 使用状态机多拍输出。
- 对 single-line WRAP 做特殊拆分。
- 使用 `stall_flag_s1_i` 支持后级反压，不丢切段进度。
- 输出 S1/S2 两级信息，便于后级 entry 分配和 mask 信息对齐。

## 33. 一句话理解

可以把 `rni_segburst` 理解成：

```text
AXI burst 描述
    -> 64B cacheline segment 序列
        -> 每个 segment 附带 16B bank mask、beat count 和 CHI size
```

它是 AXI 地址语义和 RNI/CHI cacheline 粒度之间的转换层。

