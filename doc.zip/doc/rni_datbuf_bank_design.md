# rni_datbuf_bank 设计说明

## 1. 模块定位

`rni_datbuf_bank` 是 `rni_rd_buffer` 内部使用的数据存储模块，用来暂存 CHI RXDAT 返回的数据。

它本身不理解 CHI/AXI 协议，也不负责 entry 分配、RDATA chain、RRESP 生成、AXI R 通道握手。它只做一件事：

```text
按照 entry index，把 64B cacheline 内的 4 个 16B bank 存起来，并支持按 entry index 读出。
```

在读路径中的位置可以理解为：

```text
CHI RXDAT flit
    -> rni_rd_buffer 解析 TxnID/DataID/Data
    -> rni_datbuf_bank 写入对应 entry/bank

rni_arctrl 调度 AXI RDATA 返回
    -> rni_rd_buffer 根据 entry index + ctmask
    -> rni_datbuf_bank 读出对应 entry/bank
    -> rni_rd_buffer 组包 AXI R channel
```

所以 `rni_datbuf_bank` 是读返回数据的真实存储体。

## 2. 结构概览

模块内部有 4 个并行 data bank：

```verilog
datbank0_q[RNI_AR_ENTRIES_NUM_PARAM-1:0]
datbank1_q[RNI_AR_ENTRIES_NUM_PARAM-1:0]
datbank2_q[RNI_AR_ENTRIES_NUM_PARAM-1:0]
datbank3_q[RNI_AR_ENTRIES_NUM_PARAM-1:0]
```

每个 bank 的数据宽度是：

```verilog
`RNI_RD_BANK_DATA_WIDTH = 128
```

也就是：

```text
128 bit = 16B
```

4 个 bank 合起来对应一个 64B cacheline：

```text
bank0: cacheline offset 0x00 ~ 0x0f
bank1: cacheline offset 0x10 ~ 0x1f
bank2: cacheline offset 0x20 ~ 0x2f
bank3: cacheline offset 0x30 ~ 0x3f
```

每个 bank 的深度是：

```verilog
RNI_AR_ENTRIES_NUM_PARAM
```

当前默认配置下：

```verilog
RNI_AR_ENTRIES_NUM_PARAM = 32
```

所以可以把模块抽象成：

```text
bank0[0..31] : 每项 16B
bank1[0..31] : 每项 16B
bank2[0..31] : 每项 16B
bank3[0..31] : 每项 16B
```

二维视角是：

```text
datbank0_q[entry] -> entry 对应 cacheline 的 bank0
datbank1_q[entry] -> entry 对应 cacheline 的 bank1
datbank2_q[entry] -> entry 对应 cacheline 的 bank2
datbank3_q[entry] -> entry 对应 cacheline 的 bank3
```

## 3. 参数和宏

这个模块主要依赖下面几个宏：

| 宏 | 含义 |
|---|---|
| `RNI_AR_ENTRIES_NUM_PARAM` | AR entry 数量，也就是每个 bank 的深度 |
| `RNI_AR_ENTRIES_WIDTH` | AR entry index 位宽 |
| `RNI_RD_BANK_ADDR_WIDTH` | bank 读写地址位宽，等于 `RNI_AR_ENTRIES_WIDTH` |
| `RNI_RD_BANK_DATA_WIDTH` | 每个 bank 的数据宽度，固定为 128 bit |
| `RNI_RD_BANK_NUM` | bank 数量，固定为 4 |

在 `rni_defines.v` 中：

```verilog
`define RNI_RD_BANK_NUM                 4
`define RNI_RD_BANK_ADDR_WIDTH          `RNI_AR_ENTRIES_WIDTH
`define RNI_RD_BANK_DATA_WIDTH          128
```

因此 `rni_datbuf_bank` 的 bank 组织和 AR entry 数量直接绑定。

## 4. 端口说明

### 4.1 全局端口

```verilog
input wire clk_i
input wire rst_i
```

`clk_i` 用于同步写入。

`rst_i` 在当前模块内部没有实际使用。也就是说，`datbankX_q` 不会被 reset 清零。设计依赖 entry 生命周期保证：只有对应 RXDAT 写入后，后续才会读该 entry/bank。

### 4.2 bank 写端口

每个 bank 都有独立写端口。以 bank0 为例：

```verilog
bank0_wr_en_i
bank0_wr_addr_i
bank0_wr_data_i
```

含义如下：

| 信号 | 含义 |
|---|---|
| `bank0_wr_en_i` | bank0 写使能 |
| `bank0_wr_addr_i` | bank0 写地址，也就是 AR entry index |
| `bank0_wr_data_i` | 写入 bank0 的 128-bit 数据 |

bank1、bank2、bank3 同理。

### 4.3 bank 读端口

每个 bank 都有独立读端口。以 bank2 为例：

```verilog
bank2_rd_en_i
bank2_rd_addr_i
bank2_rd_data_o
```

含义如下：

| 信号 | 含义 |
|---|---|
| `bank2_rd_en_i` | bank2 读使能 |
| `bank2_rd_addr_i` | bank2 读地址，也就是 AR entry index |
| `bank2_rd_data_o` | 从 bank2 读出的 128-bit 数据 |

## 5. 写入设计

写入逻辑是同步写，也就是在 `posedge clk_i` 时更新存储。

以 bank0 为例：

```verilog
generate
    for (bk_entry=0; bk_entry<RNI_AR_ENTRIES_NUM_PARAM; bk_entry=bk_entry+1) begin
        always @(posedge clk_i) begin
            if(bank0_wr_en_i && (bank0_wr_addr_i == bk_entry))
                datbank0_q[bk_entry] <= bank0_wr_data_i;
        end
    end
endgenerate
```

这段代码等价于：

```text
if bank0_wr_en_i:
    datbank0_q[bank0_wr_addr_i] <= bank0_wr_data_i
```

作者没有直接写数组索引赋值，而是用 generate 展开每个 entry 的写条件：

```text
entry0: if wr_addr == 0 -> 写 datbank0_q[0]
entry1: if wr_addr == 1 -> 写 datbank0_q[1]
...
entry31: if wr_addr == 31 -> 写 datbank0_q[31]
```

bank1、bank2、bank3 的写入逻辑完全相同。

### 5.1 写入没有反压

`rni_datbuf_bank` 的写接口没有 ready/full/acpt 信号。

```text
只要 bankX_wr_en_i 为 1，到时钟沿就写入。
```

这是因为它不是 FIFO，而是按 entry index 编址的固定存储阵列。容量由 `RNI_AR_ENTRIES_NUM_PARAM` 决定，每个 entry 固定拥有 4 个 bank 位置。

写入安全性依赖上游保证：

```text
1. RXDAT.TxnID 对应一个有效 AR entry。
2. entry 在 RXDAT 可能回来之前不会提前释放。
3. 同一个 entry/bank 不会被错误地写入两份不同数据。
4. rni_arctrl 的 RVMASK/PD/CT/dealloc 逻辑正确维护 entry 生命周期。
```

## 6. 读取设计

读取逻辑是组合读。以 bank1 为例：

```verilog
always @* begin
    bank1_rd_data = {`RNI_RD_BANK_DATA_WIDTH{1'b0}};
    for(i=0; i<RNI_AR_ENTRIES_NUM_PARAM; i=i+1) begin
        if(bank1_rd_en_i && (bank1_rd_addr_i == i))
            bank1_rd_data = datbank1_q[i];
    end
end
```

这段代码等价于：

```text
if bank1_rd_en_i:
    bank1_rd_data = datbank1_q[bank1_rd_addr_i]
else:
    bank1_rd_data = 0
```

最后输出：

```verilog
assign bank1_rd_data_o = bank1_rd_data;
```

bank0、bank2、bank3 的读取逻辑完全相同。

### 6.1 组合读的效果

由于读是组合逻辑，所以当：

```text
bankX_rd_en_i 变化
bankX_rd_addr_i 变化
datbankX_q 内容变化
```

对应的：

```text
bankX_rd_data_o
```

会组合更新。

这个设计适合 `rni_rd_buffer` 在 D4 阶段根据 `arctrl_rb_idx_d4_i` 和 `arctrl_rb_ctmask_d4_i` 直接取出 bank 数据，然后 push 到 `rp_fifo`。

## 7. 与 rni_rd_buffer 的连接方式

`rni_rd_buffer` 中实例化了 `rni_datbuf_bank`：

```verilog
rni_datbuf_bank rni_datbuf_bank_inst (
    .bank0_wr_en_i   (bank0_wr_en_d2_w),
    .bank0_wr_addr_i (bank0_wr_addr_d2_w),
    .bank0_wr_data_i (bank0_wr_data_d2_w),
    .bank0_rd_en_i   (bank0_rd_en_d4_w),
    .bank0_rd_addr_i (bank0_rd_addr_d4_w),
    .bank0_rd_data_o (bank0_rd_data_d4_w),
    ...
);
```

写入侧来自 RXDAT：

```text
rxdatflit_d1_i
    -> rni_rd_buffer decode
    -> dataid_d2_q / txnid_d2_q / data_d2_q
    -> bankX_wr_en_d2_w / bankX_wr_addr_d2_w / bankX_wr_data_d2_w
    -> rni_datbuf_bank
```

读出侧来自 `rni_arctrl` 的 RDATA 调度：

```text
arctrl_rb_valid_d4_i
arctrl_rb_idx_d4_i
arctrl_rb_ctmask_d4_i
    -> data_bank_vec_d4_w
    -> bankX_rd_en_d4_w / bankX_rd_addr_d4_w
    -> rni_datbuf_bank
    -> bankX_rd_data_d4_w
    -> AXI RDATA pack
```

## 8. 写入例子

当前主要配置是：

```text
CHIE_DATA_WIDTH_PARAM = 256
RNI_RD_BANK_DATA_WIDTH = 128
```

因此一个 RXDAT flit 是 32B，会写两个 16B bank。

### 8.1 DataID = 0

假设 RXDAT：

```text
TxnID  = 5
DataID = 2'b00
Data   = {high_16B, low_16B}
```

`rni_rd_buffer` 会产生：

```text
bank0_wr_en_d2_w   = 1
bank0_wr_addr_d2_w = 5
bank0_wr_data_d2_w = data_d2_q[127:0]

bank1_wr_en_d2_w   = 1
bank1_wr_addr_d2_w = 5
bank1_wr_data_d2_w = data_d2_q[255:128]
```

写入结果：

```text
datbank0_q[5] <= low_16B
datbank1_q[5] <= high_16B
```

### 8.2 DataID = 2

假设 RXDAT：

```text
TxnID  = 5
DataID = 2'b10
Data   = {high_16B, low_16B}
```

写入结果：

```text
datbank2_q[5] <= low_16B
datbank3_q[5] <= high_16B
```

## 9. 读取例子

假设 `rni_arctrl` 当前调度：

```text
arctrl_rb_idx_d4_i    = 5
arctrl_rb_ctmask_d4_i = 4'b0100
```

这表示：

```text
读取 entry5 的 bank2
```

`rni_rd_buffer` 会产生：

```text
bank2_rd_en_d4_w   = 1
bank2_rd_addr_d4_w = 5
```

于是 `rni_datbuf_bank` 输出：

```text
bank2_rd_data_o = datbank2_q[5]
```

这个数据随后会被 `rni_rd_buffer` 组装成 AXI `RDATA`。

## 10. 同周期读写注意点

该模块没有显式定义同一个 bank、同一个 entry 的读写冲突行为。

写入是时序逻辑：

```verilog
always @(posedge clk_i)
    datbankX_q[...] <= bankX_wr_data_i;
```

读取是组合逻辑：

```verilog
always @*
    bankX_rd_data = datbankX_q[...];
```

因此如果同一周期内对同一个 `datbankX_q[entry]` 同时写和读，仿真中读数据会随着时钟沿后 `datbankX_q` 的更新而组合变化；综合后具体 read-during-write 行为取决于综合工具如何实现这个结构。

正常设计应避免依赖这种冲突行为。读返回调度应只发生在 `rni_arctrl` 已经确认对应 bank 数据有效之后，也就是对应 `arctrl_entry_rvmask_q` 已经置位之后。

## 11. 复位行为

虽然模块有：

```verilog
rst_i
```

但是当前 RTL 没有用 `rst_i` 清空 `datbankX_q`。

这意味着：

```text
reset 后 bank 内容不保证为 0。
```

设计依赖有效位和 entry 生命周期控制，避免读取未写入的数据。

这类数据 RAM/寄存器阵列不复位是常见设计选择，因为真实数据存储体通常没有必要在 reset 时全部清空，清空也会带来面积和时序成本。

## 12. 综合实现特征

从功能上看，`rni_datbuf_bank` 是 4 组独立 RAM/register-file：

```text
4 banks x RNI_AR_ENTRIES_NUM_PARAM entries x 128 bit
```

不过 RTL 写法不是直接：

```verilog
datbank0_q[bank0_wr_addr_i] <= bank0_wr_data_i;
```

而是 generate 展开所有 entry 的比较写入：

```verilog
if(bank0_wr_en_i && (bank0_wr_addr_i == bk_entry))
    datbank0_q[bk_entry] <= bank0_wr_data_i;
```

读也是 for-loop mux：

```verilog
if(bank0_rd_en_i && (bank0_rd_addr_i == i))
    bank0_rd_data = datbank0_q[i];
```

因此综合工具可能把它实现成寄存器阵列加 mux，也可能识别成小型 RAM/register file，取决于工具和约束。

当前默认 32 entry、4 bank、每 bank 128 bit 时，总数据容量是：

```text
32 entries x 4 banks x 128 bit = 16384 bit = 2KB
```

## 13. 设计总结

`rni_datbuf_bank` 的设计思想是把一个 AR entry 对应的 64B cacheline 拆成 4 个 16B bank 存储：

```text
entry index 选择哪一笔读事务
bank index 选择 cacheline 内哪一个 16B chunk
```

写入时：

```text
RXDAT.TxnID  -> entry index
RXDAT.DataID -> bank 选择
RXDAT.Data   -> bank data
```

读出时：

```text
arctrl_rb_idx_d4_i    -> entry index
arctrl_rb_ctmask_d4_i -> bank 选择
```

一句话概括：

```text
rni_datbuf_bank 是 RNI 读路径的 4-bank 数据暂存阵列，每个 AR entry 拥有 4 个 16B bank，用于承接乱序到达的 CHI RXDAT，并按 arctrl 调度顺序读出给 AXI R 通道。
```
