# rni_wr_buffer 设计说明

本文基于 [`rtl/rni/rni_wr_buffer.v`](../rtl/rni/rni_wr_buffer.v)、[`rtl/rni/rni_bcount_ctl.v`](../rtl/rni/rni_bcount_ctl.v)、[`rtl/include/rni_defines.v`](../rtl/include/rni_defines.v) 和 [`rtl/include/rni_param.v`](../rtl/include/rni_param.v) 整理。

`rni_wr_buffer` 是 RNI 写路径中的数据缓冲和数据 flit 组包模块。它不负责 AW entry 的协议状态机、同 ID ordering、Retry、DBID/Comp/CompAck 判断，这些由 `rni_awctrl` 完成。它的主要职责是：

1. 接收 AXI W channel 数据并放入 W FIFO。
2. 接收 `rni_awctrl` 分配的 AW entry、`ctmask/pdmask/bc_vec` 信息。
3. 将 AXI WDATA/WSTRB 按 entry 和 16B bank 写入本地写数据 bank。
4. 在某个 entry 的写数据收齐后，通知 `rni_awctrl`。
5. 接收 `rni_awctrl` 的 TXDAT 调度授权，组装 CHI `DAT` flit。
6. 接收 `rni_awctrl` 的 BResp 调度项，最终向 AXI B channel 返回写响应。

整体路径可以概括为：

```text
AXI W
  -> wd_fifo
  -> rni_bcount_ctl 根据 AW mask/BC 控制写入 bank
  -> per-entry write data bank / strobe bank
  -> AWCTRL 授权 TXDAT
  -> 组 CHI TXDAT flit
  -> rni_link_ctl

AWCTRL BResp 调度
  -> brsp_fifo
  -> AXI B channel
```

## 1. 模块定位

在 RNI 写路径中，`rni_awctrl` 和 `rni_wr_buffer` 是控制和数据的分工关系：

```text
rni_awctrl:
  管 AW entry 生命周期
  管 TXREQ / RXRSP / Retry / CompAck / BResp ready
  决定什么时候授权 TXDAT

rni_wr_buffer:
  管 AXI WDATA/WSTRB 缓存
  管写数据是否收齐
  管 TXDAT 数据 flit 的 DATA/BE/DataID 组装
  管 AXI B channel 输出
```

两者之间的关键接口包括：

```text
AW allocation:
  aw_alloc_valid_s2_i
  aw_alloc_entry_s2_i
  aw_ctmask_s2_i
  aw_pdmask_s2_i
  aw_bc_vec_s2_i

WDATA done:
  wb_req_done_d3_o
  wb_req_entry_d3_o

TXDAT grant:
  txdat_rdy_v_d2_q_i
  txdat_rdy_entry_d2_q_i
  txdat_qos_d2_i
  txdat_dbid_d2_i
  txdat_tgtid_d2_i
  txdat_ctmask_d2_q_i

BResp:
  brsp_rdy_v_d2_i
  brsp_last_v_d2_q_i
  brsp_axid_d2_i
  wb_brsp_fifo_pop_d3_o
```

## 2. 关键参数和数据粒度

当前默认参数为：

```verilog
AXI4_AXDATA_WIDTH_PARAM = 128
CHIE_DATA_WIDTH_PARAM   = 256
CHIE_BE_WIDTH_PARAM     = 32
```

因此：

```text
AXI WDATA 宽度      = 128 bit = 16B
CHI DAT DATA 宽度   = 256 bit = 32B
一个 cacheline      = 64B
内部 bank 数量      = 4
每个 bank 宽度      = 128 bit = 16B
```

内部写数据 bank 对 cacheline 的划分是：

```text
bank0: cacheline offset 0x00 ~ 0x0f
bank1: cacheline offset 0x10 ~ 0x1f
bank2: cacheline offset 0x20 ~ 0x2f
bank3: cacheline offset 0x30 ~ 0x3f
```

`rni_wr_buffer` 内部每个 AW entry 都有 4 个 16B bank：

```text
w_data_d2_q[entry][bank]
w_strb_d2_q[entry][bank]
```

其中 `w_data_d2_q` 保存真实 AXI WDATA，`w_strb_d2_q` 保存 byte-level WSTRB，后续用于生成 CHI DAT flit 的 `BE` 字段。

## 3. Mask 含义

`rni_wr_buffer` 主要使用 `ctmask` 和 `pdmask`。

### 3.1 ctmask

`ctmask` 是当前处理的 cacheline chunk/bank mask：

```text
ctmask[0] -> bank0
ctmask[1] -> bank1
ctmask[2] -> bank2
ctmask[3] -> bank3
```

在写数据收集阶段，`ctmask` 作为初始 bank 指示，送入 `rni_bcount_ctl`。

在 TXDAT 组包阶段，`txdat_ctmask_d2_q_i` 用于选择输出低 32B 还是高 32B：

```verilog
txdat_ctmask_d3_w = {
    |txdat_ctmask_d3_q[3:2],
    |txdat_ctmask_d3_q[1:0]
};
```

也就是：

```text
txdat_ctmask_d3_w[0] = 低 32B 是否有效，对应 bank0/bank1
txdat_ctmask_d3_w[1] = 高 32B 是否有效，对应 bank2/bank3
```

### 3.2 pdmask

`pdmask` 表示该 AW segment 还有哪些 bank 的写数据需要收集。它进入 `rni_bcount_ctl`，由 `fdmask` 逐个 bank 推进，直到所有 pending bank 收齐。

当 `rni_bcount_ctl` 判断 `pdmask_nxt` 清空时，输出：

```verilog
rq_done = 1
```

在 `rni_wr_buffer` 中对应：

```verilog
wb_req_done_d3_o
```

这表示该 entry 的写数据已经按 `pdmask/bc_vec` 收齐。

## 4. 接口分组

### 4.1 来自 rni_awctrl 的 AW 分配信息

```verilog
aw_alloc_valid_s2_i
aw_alloc_entry_s2_i
aw_ctmask_s2_i
aw_pdmask_s2_i
aw_bc_vec_s2_i
```

当 `rni_awctrl` 为一个 AW segment 分配 entry 后，会把该 segment 的数据收集信息送到 `rni_wr_buffer`。

这些信息被写入 `aw_req_fifo`：

```verilog
aw_req_fifo_in_s2_w =
    {aw_bc_vec_s2_i, aw_pdmask_s2_i, aw_ctmask_s2_i, aw_alloc_entry_s2_i};
```

### 4.2 AXI W channel

```verilog
W_CH_S0
WVALID0
WREADY0
```

`W_CH_S0` 是打包后的 AXI W channel，包含：

```text
WDATA
WSTRB
WLAST
```

本模块先把 AXI W channel 放入 `wd_fifo`，再和 `aw_req_fifo` 中的 AW segment 信息配对。

### 4.3 TXDAT 调度输入

```verilog
txdat_rdy_v_d2_q_i
txdat_rdy_entry_d2_q_i
txdat_qos_d2_i
txdat_compack_d2_i
txdat_dbid_d2_i
txdat_tgtid_d2_i
txdat_ccid_d2_i
txdat_ctmask_d2_q_i
```

这些信号来自 `rni_awctrl`，表示：

```text
某个 entry 已经收到 DBID
WDATA 已经收齐
AWCTRL 允许 wr_buffer 为该 entry 发送 TXDAT
```

`rni_wr_buffer` 根据 `txdat_rdy_entry_d2_q_i` 选出该 entry 的 data/strb，再根据 `txdat_ctmask_d2_q_i` 选择低 32B 或高 32B 组成 CHI DAT flit。

### 4.4 Link TXDAT 输出

```verilog
wb_txdatflit_d3_o
wb_txdatflitv_d3_o
wb_txdatflit_sent_d3_i
```

`wb_txdatflit_d3_o` 是最终送到 `rni_link_ctl` 的 CHI DAT flit。`wb_txdatflit_sent_d3_i` 是 link 层返回的发送成功/已接受指示。

### 4.5 B channel 输出

```verilog
B_CH_S0
BVALID0
BREADY0
```

本模块内部的 `brsp_fifo` 接收 `rni_awctrl` 的 BResp 调度项。只有 `last_v=1` 的调度项才会真正对 AXI 输出 `BVALID0`。非 last 调度项会被内部自动 pop，用于释放中间 segment 对应的 AW entry。

## 5. WDATA FIFO

AXI W channel 先进入 `wd_fifo`：

```verilog
wd_fifo_push_d0_w = WVALID0 & WREADY0;
wd_fifo_in_d0_w   = W_CH_S0;
```

pop 条件为：

```verilog
wd_fifo_pop_d0_w = rq_wd_rdy_w & ~wd_fifo_empty_d1_w;
```

其中：

```verilog
rq_wd_rdy_w = aw_req_avail_w & w_valid_d1_w;
```

也就是只有当：

```text
AW request info FIFO 非空
WDATA FIFO 非空
```

才会配对消费一个 W beat。

`WREADY0` 的生成：

```verilog
WREADY0 = ~wd_fifo_full_d1_w | wd_fifo_pop_d0_w;
```

这是一种常见 FIFO ready 逻辑：FIFO 未满时可以接收；如果本拍同时 pop，即使原先 full 也可以接收新数据。

## 6. AW Req Info FIFO

AW segment 信息进入 `aw_req_fifo`：

```verilog
push = aw_alloc_valid_s2_i
data = {aw_bc_vec_s2_i, aw_pdmask_s2_i, aw_ctmask_s2_i, aw_alloc_entry_s2_i}
```

解包为：

```verilog
{aw_bc_vec_s3_w,
 aw_pdmask_s3_w,
 aw_ctmask_s3_w,
 aw_new_alloc_entry_s3_w} = aw_req_fifo_out_s3_w;
```

`aw_req_fifo` 的 pop 由写数据收齐事件驱动：

```verilog
aw_req_fifo_pop_w = wb_req_done_d3_o;
```

因此一个 AW segment 的 request info 会一直留在 FIFO 头部，直到它对应的 WDATA 全部收齐。

`wb_req_fifo_pfull_d1_o` 用于反压 AWCTRL/AWLINK：

```verilog
wb_req_fifo_pfull_d1_o = (aw_req_fifo_count_w >= (`AW_REQ_FIFO_ENTRIES_DEPTH-1));
```

当该 FIFO 接近满时，AWCTRL 会 stall 新的 AW segment 分配。

## 7. rni_bcount_ctl

`rni_bcount_ctl` 是 AW segment 和 AXI W beat 之间的 bank 级对齐控制器。

输入：

```verilog
rq_valid   = rq_wd_rdy_w
wd_valid   = w_valid_d1_w
bcount_vec = aw_bc_vec_s3_w
ctmask     = aw_ctmask_s3_w
pdmask     = aw_pdmask_s3_w
```

输出：

```verilog
fdmask        // 当前 W beat 要填哪个 bank
bk_done       // 当前 bank 收集完成
rq_done       // 整个 AW segment 的 WDATA 收集完成
```

`fdmask` 表示当前正在填充的 bank。初始来自 `ctmask`，每当当前 bank 完成后循环左移：

```verilog
fdmask_nxt = rq_done ? 4'b0000 : {fdmask[2:0], fdmask[3]};
```

`bcount_vec` 是每个 bank 对应的 beat count。`rni_bcount_ctl` 根据当前 `fdmask` 选出对应 bank 的 `BC`，然后随着 W beat 消费递减。

完成条件可以理解为：

```text
bk_done:
  当前 bank 的 beat count 已经归零

rq_done:
  当前 bank 完成，并且所有 pdmask bank 都已经处理完
```

`rq_done` 在 `rni_wr_buffer` 中直接作为：

```verilog
wb_req_done_d3_o
```

并通过：

```verilog
wb_req_entry_d3_o = aw_new_alloc_entry_s3_w;
```

通知 AWCTRL：该 entry 的 WDATA 已经收齐。

## 8. WDB 写入设计

本模块为每个 AW entry 保存 4 个 bank 的数据和 strobe。

### 8.1 写 entry 选择

```verilog
wr_entry_d1_w[entry] =
    aw_new_alloc_entry_s3_w[entry] &
    aw_req_avail_w &
    w_valid_d1_w;
```

只有 FIFO 头部 AW request info 有效，并且当前有 W beat 时，才会选择该 entry。

### 8.2 写 bank 选择

```verilog
wr_bank_d1_w[bank] =
    aw_fdmask_s3_w[bank] &
    aw_req_avail_w &
    w_valid_d1_w;
```

`aw_fdmask_s3_w` 来自 `rni_bcount_ctl`，表示当前 W beat 属于哪个 16B bank。

### 8.3 WSTRB 累积

每个 entry、每个 bank、每个 byte 的 strobe 更新为：

```verilog
w_strb_nxt =
    (wr_wstrb | old_w_strb) & ~awctrl_dealloc_entry_i[entry];
```

含义是：

```text
写入时累积 WSTRB
entry dealloc 时清零
```

这很重要，因为后续 CHI DAT flit 的 `BE` 字段来自 `w_strb_d2_q`，不是来自 `pdmask`。`pdmask` 只决定 coarse-grain bank 是否需要发送；真正 byte 级有效性由 `BE/WSTRB` 表示。

### 8.4 WDATA 写入

真实数据写入受 byte strobe 控制：

```verilog
if(wr_wstrb_d1_w[entry][bank*WSTRB_WIDTH + byt])
    w_data_d2_q[entry][bank_byte] <= w_data_d1_w[byte];
```

因此无效 byte 不会覆盖旧值。最终输出 TXDAT 时，无效 byte 还会被 BE 再次清零。

## 9. TXDAT 调度输入和 D2 数据选择

当 AWCTRL 判断某个 entry 可以发送 TXDAT 时，会拉高：

```verilog
txdat_rdy_v_d2_q_i
txdat_rdy_entry_d2_q_i
```

`rni_wr_buffer` 根据 one-hot entry 从所有 entry bank 中选出 64B 数据和 64 bit strobe：

```verilog
txdat_data_d2_r = selected w_data_d2_q[entry];
txdat_be_d2_r   = selected w_strb_d2_q[entry];
```

同时将 one-hot entry 转换为 entry index：

```verilog
txdat_rdy_idx_d2_r = selected entry index;
```

该 index 后续会被编码进 CHI DAT flit 的 `DBID` 字段低位，用于让 RNI 本地识别写 entry。

## 10. TXDAT backpressure 和保持机制

TXDAT 输出侧的 busy 条件：

```verilog
txdat_busy_d2_w = txdat_rdy_v_d3_q & ~wb_txdatflit_sent_d3_i;
wb_txdat_not_busy_d2_o = ~txdat_busy_d2_w;
```

含义是：

```text
D3 阶段已有一个 valid TXDAT flit
但 link 层还没有 sent
=> TXDAT 输出通路 busy
```

`wb_txdat_not_busy_d2_o` 反馈给 AWCTRL，让 AWCTRL 在 wr_buffer busy 时保持 TXDAT 调度信息。

wr_buffer 自己的 D3 valid 也只在 not busy 时更新：

```verilog
if(wb_txdat_not_busy_d2_o)
    txdat_rdy_v_d3_q <= txdat_rdy_v_d2_q_i;
```

TXDAT 信息锁存 enable：

```verilog
txdat_info_flop_en_d2_w =
    wb_txdat_not_busy_d2_o & txdat_rdy_v_d2_q_i;
```

只有输出通路可以接收新 flit，且 AWCTRL 当前给了有效调度，才会锁存：

```verilog
txdat_data_d3_q
txdat_be_d3_q
txdat_qos_d3_q
txdat_dbid_d3_q
txdat_tgtid_d3_q
txdat_ccid_d3_q
txdat_ctmask_d3_q
```

## 11. TXDAT 数据半区选择

当前 cacheline 总共 64B，而一个 CHI DAT flit 是 32B。因此本模块每次 TXDAT 只输出低 32B 或高 32B。

先把 4 bit `ctmask` 压成 2 bit：

```verilog
txdat_ctmask_d3_w = {
    |txdat_ctmask_d3_q[3:2],
    |txdat_ctmask_d3_q[1:0]
};
```

然后选择数据：

```verilog
txdat_data_d3_w =
    {DATA_WIDTH{txdat_ctmask_d3_w[0]}} & low_32B |
    {DATA_WIDTH{txdat_ctmask_d3_w[1]}} & high_32B;
```

BE 选择方式相同：

```verilog
txdat_be_d3_w =
    {BE_WIDTH{txdat_ctmask_d3_w[0]}} & low_32B_BE |
    {BE_WIDTH{txdat_ctmask_d3_w[1]}} & high_32B_BE;
```

因此：

```text
ctmask[1:0] 有效 -> 发送低 32B，DataID=2'b00
ctmask[3:2] 有效 -> 发送高 32B，DataID=2'b10
```

如果一个 AW entry 同时覆盖低 32B 和高 32B，AWCTRL 会分两次授权 TXDAT。第一次和第二次通过不同的 `txdat_ctmask_d2_q_i` 让 wr_buffer 选择不同半区。

## 12. BE 和 DATA 处理

CHI DAT flit 的 `BE` 字段来自 AXI `WSTRB`：

```verilog
txdatflit_be_d3_w = txdat_be_d3_w;
```

最终 DATA 会按 BE 做 byte 级清零：

```verilog
txdatflit_data_d3_w[8*byt +: 8] =
    {8{txdatflit_be_d3_w[byt]}} & txdat_data_d3_w[8*byt +: 8];
```

这表示：

```text
BE[byt] = 1 -> DATA byte 有效
BE[byt] = 0 -> DATA byte 输出为 0
```

注意，HN 判断哪些 byte 有效靠的是 `BE` 字段，而不是 DATA 是否为 0。DATA 清零只是本实现对无效 byte 的处理。

## 13. TXDAT flit 字段装载

TXDAT flit 的主要字段如下：

| 字段 | 来源 |
|---|---|
| `QOS` | `txdat_qos_d3_q`，来自 AWCTRL |
| `TGTID` | `txdat_tgtid_d3_q`，通常为 DBIDResp 的 SrcID |
| `SRCID` | `RNI_NID_PARAM` |
| `TXNID` | `txdat_dbid_d3_q`，HN 分配的 DBID |
| `OPCODE` | `txdat_compack_d3_q ? CHIE_NCBWRDATACOMPACK : CHIE_NONCOPYBACKWRDATA` |
| `DBID` | `{1'b1, entry_index}` |
| `CCID` | `txdat_ccid_d3_q` |
| `DATAID` | 低 32B 为 `2'b00`，高 32B 为 `2'b10` |
| `BE` | 从 AXI WSTRB 累积得到 |
| `DATA` | 根据 `ctmask` 选择的 32B 数据，并按 BE 清零 |

代码中：

```verilog
wb_txdatflit_d3_o[`CHIE_DAT_FLIT_TXNID_RANGE] = txdat_dbid_d3_q;
wb_txdatflit_d3_o[`CHIE_DAT_FLIT_DBID_RANGE]  = txdatflit_txnid_d3_w;
```

这两个字段容易混淆：

```text
DAT.TXNID = HN 返回给 RNI 的 DBID
DAT.DBID  = RNI 本地生成的 {1'b1, aw_entry}
```

这和 AWCTRL 中的写事务映射一致。

当前 AWCTRL 里 `txdat_compack_d2_i` 固定为 0，因此当前路径实际使用：

```text
Opcode = CHIE_NONCOPYBACKWRDATA
```

但 `rni_wr_buffer` 本身保留了 `CHIE_NCBWRDATACOMPACK` 的组包能力。

## 14. TXDAT valid 和 link sent

DAT flit valid：

```verilog
wb_txdatflitv_d3_o = txdat_rdy_v_d3_q;
```

如果 `wb_txdatflitv_d3_o=1` 但 `wb_txdatflit_sent_d3_i=0`，则：

```text
txdat_busy_d2_w = 1
wb_txdat_not_busy_d2_o = 0
```

wr_buffer 会 hold 当前 D3 flit，不接收新的 AWCTRL TXDAT 调度。

当 link 层返回 `wb_txdatflit_sent_d3_i=1` 后，当前 flit 被认为已经发送，wr_buffer 可以接收下一笔 TXDAT 信息。

## 15. B Response Dispatch

B response 由 AWCTRL 决定何时可以返回。wr_buffer 只负责排队和输出 AXI B channel。

AWCTRL 送入：

```verilog
brsp_rdy_v_d2_i
brsp_last_v_d2_q_i
brsp_axid_d2_i
brsp_resperr_d2_i
```

wr_buffer 写入 `brsp_fifo`：

```verilog
brsp_fifo_push_d2_w = brsp_rdy_v_d2_i;
brsp_fifo_in_d2_w   = {brsp_axid_d2_i, brsp_resperr_d2_i, brsp_last_v_d2_q_i};
```

FIFO 内容为：

```text
{AXI BID, BRESP/RespErr, last_v}
```

`last_v` 的作用非常关键。一个 AXI AW burst 可能被拆成多个 CHI AW segment，每个 segment 完成时 AWCTRL 都会给 wr_buffer 一个 BResp 调度项，但 AXI 侧只能对原始 AW burst 返回一个 B response。

因此：

```text
last_v = 0 -> 内部调度项，自动 pop，不对 AXI 输出 BVALID
last_v = 1 -> 原始 AXI AW 的最后一个 segment，真正输出 AXI BVALID
```

pop 逻辑：

```verilog
wb_brsp_fifo_pop_d3_o =
    (~brsp_fifo_empty_w & ~brsp_fifo_out_d3_w[`BRSP_FIFO_LAST_RANGE]) |
    (BVALID0 & BREADY0);
```

含义是：

```text
非 last 调度项:
  FIFO 非空即自动 pop

last 调度项:
  等 AXI B channel 握手 BVALID & BREADY 后 pop
```

AXI B 输出：

```verilog
BVALID0 = ~brsp_fifo_empty_w & brsp_fifo_out_d3_w[`BRSP_FIFO_LAST_RANGE];

BID   = last_v ? brsp_fifo_out.BID   : 0
BRESP = last_v ? brsp_fifo_out.RESP  : 0
```

wr_buffer 的 `wb_brsp_fifo_pop_d3_o` 会反馈给 AWCTRL。AWCTRL 用这个 pop 事件释放对应 AW entry。

## 16. 与 AWCTRL 的 BResp 释放关系

AWCTRL 内部有自己的 `bresp_credit` FIFO，保存已经满足 BResp ready 的 entry one-hot。wr_buffer 的 `wb_brsp_fifo_pop_d3_o` 同时具有两个含义：

```text
1. wr_buffer 已经消费了一个 BResp 调度项
2. AWCTRL 可以释放这个调度项对应的 AW entry
```

AWCTRL 中的释放逻辑为：

```verilog
awctrl_entry_dealloc_vec_w =
    {N{awctrl_brsp_fifo_pop_d3_i}} & bresp_send_ptr_w;
```

所以 BResp 通路的完整链路是：

```text
AWCTRL 判断 entry 可以 BResp
  -> push entry one-hot 到 AWCTRL bresp_credit FIFO
  -> 同时输出 brsp_rdy_v_d2_i 给 wr_buffer
  -> wr_buffer push brsp_fifo
  -> wr_buffer pop brsp_fifo
  -> wb_brsp_fifo_pop_d3_o 反馈 AWCTRL
  -> AWCTRL 释放对应 entry
```

## 17. 典型写事务流程

以一个普通 one-packet 写事务为例：

```text
1. AXI AW 进入 rni_awctrl，分配 AW entry
2. rni_awctrl 将 entry/ctmask/pdmask/bc_vec 送入 rni_wr_buffer
3. rni_wr_buffer push aw_req_fifo
4. AXI W beat 进入 wd_fifo
5. aw_req_fifo 头部和 wd_fifo 头部配对
6. rni_bcount_ctl 给出 fdmask，指示当前 W beat 写哪个 bank
7. w_data_d2_q / w_strb_d2_q 按 entry+bank 更新
8. 所有 pdmask bank 收齐后，wb_req_done_d3_o 拉高
9. rni_awctrl 收到 DBID 且 WDATA done 后，授权 TXDAT
10. rni_wr_buffer 根据 entry 取出 data/strb
11. 根据 txdat_ctmask 选择低 32B 或高 32B
12. 组 CHI NonCopyBackWrData flit
13. link 层 sent 后，AWCTRL 后续等待 Comp/CompAck/BResp
14. AWCTRL 送 BResp 调度到 wr_buffer
15. wr_buffer 输出 AXI B，或对非 last segment 自动 pop
```

## 18. Two-packet TXDAT 场景

如果一个 AW entry 的写范围同时覆盖低 32B 和高 32B，则 AWCTRL 会授权 wr_buffer 发送两次 TXDAT。

例如：

```text
PDMASK = 4'b0110
```

表示：

```text
bank1 有效，属于低 32B
bank2 有效，属于高 32B
```

因此需要两个 CHI DAT flit：

```text
第一个 flit:
  DataID = 2'b00
  DATA 选择低 32B
  BE 只打开低 32B 中实际 WSTRB 有效的 byte

第二个 flit:
  DataID = 2'b10
  DATA 选择高 32B
  BE 只打开高 32B 中实际 WSTRB 有效的 byte
```

wr_buffer 不关心该 entry 是第几包。它只根据 AWCTRL 当前传入的 `txdat_ctmask_d2_q_i` 选择半区。两包调度的阶段控制由 AWCTRL 的 `awctrl_entry_two_packets_flag_q/current_q` 完成。

## 19. 反压和状态保持

本模块有三类反压：

### 19.1 AXI W channel 反压

```verilog
WREADY0 = ~wd_fifo_full_d1_w | wd_fifo_pop_d0_w;
```

`wd_fifo` 满且本拍不 pop 时，AXI W 被 backpressure。

### 19.2 AW request info FIFO 反压

```verilog
wb_req_fifo_pfull_d1_o =
    aw_req_fifo_count_w >= (`AW_REQ_FIFO_ENTRIES_DEPTH-1);
```

该信号反馈给 AWCTRL，防止 AW segment 分配速度超过 wr_buffer 的 WDATA 收集能力。

### 19.3 TXDAT 输出反压

```verilog
wb_txdat_not_busy_d2_o =
    ~(txdat_rdy_v_d3_q & ~wb_txdatflit_sent_d3_i);
```

当 D3 flit valid 且未 sent 时，wr_buffer busy，AWCTRL 需要 hold 当前 TXDAT 调度信息。

## 20. Assertion

`ASSERT_CHECKER_ON` 打开时，本模块检查：

```verilog
aw_alloc_valid_s2_i & ~(|aw_alloc_entry_s2_i)
```

即 AWCTRL 不应在 allocation valid 时给出全 0 entry pointer。

还检查：

```verilog
txdat_rdy_v_d2_q_i & ~(|txdat_rdy_entry_d2_q_i)
```

即 AWCTRL 不应在 TXDAT ready valid 时给出全 0 entry pointer。

## 21. 阅读建议

建议按以下顺序阅读 `rni_wr_buffer.v`：

1. 先看端口，分清 AWCTRL、AXI W/B、link_ctl 三组接口。
2. 看 `wd_fifo`，理解 AXI W channel 如何进入模块。
3. 看 `aw_req_fifo`，理解 AW segment 的 entry/mask/BC 如何进入模块。
4. 看 `rni_bcount_ctl`，理解 W beat 如何映射到 16B bank。
5. 看 WDB update，理解 data 和 strobe 如何按 entry+bank 保存。
6. 看 TXDAT entry select，理解 AWCTRL 授权后如何选出 64B 数据。
7. 看 TXDAT flit pack，重点看 `DataID/BE/DATA/TXNID/DBID` 字段。
8. 看 `brsp_fifo`，理解为什么非 last segment 自动 pop，last segment 才输出 AXI BVALID。

一句话总结：

```text
rni_wr_buffer = AXI WDATA bank 缓存 + CHI TXDAT 组包 + AXI B response 输出
```
