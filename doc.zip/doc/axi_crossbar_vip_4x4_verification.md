# AXI Crossbar 4x4 VIP 验证说明

本文档说明 `tb_axi_crossbar_vip_4x4` 验证环境的测试设计、运行方式、覆盖场景和当前通过情况。

## 1. 验证对象

验证对象是 `rtl/axi_crossbar/axi_crossbar.v` 的 4x4 配置实例，由 `sim/tb_axi_crossbar_vip_4x4.sv` 例化。

主要参数如下：

| 项目 | 配置 |
| --- | --- |
| 上游 AXI master 端口数 | 4 |
| 下游 AXI slave 端口数 | 4 |
| 数据宽度 | 32 bit |
| 地址宽度 | 32 bit |
| 上游 ID 宽度 | 8 bit |
| 下游 ID 宽度 | 10 bit，包含 source tag |
| 每个 slave 地址窗口 | 64 KB |

地址映射来自 `sim/axi_crossbar_vip_4x4_pkg.sv`：

| Target | Base 地址 | 地址范围 |
| --- | --- | --- |
| M0 | `0x0000_0000` | `0x0000_0000` - `0x0000_FFFF` |
| M1 | `0x0001_0000` | `0x0001_0000` - `0x0001_FFFF` |
| M2 | `0x0002_0000` | `0x0002_0000` - `0x0002_FFFF` |
| M3 | `0x0003_0000` | `0x0003_0000` - `0x0003_FFFF` |
| Unmapped | `0x1000_0000` | 用于 DECERR 测试 |

## 2. 验证环境结构

testbench 使用 Xilinx AXI VIP：

| 位置 | 作用 |
| --- | --- |
| `axi_vip_xbar_mst_0` - `axi_vip_xbar_mst_3` | 作为 4 个 AXI master，驱动 crossbar 的 `s_axi_*` 端口 |
| `axi_vip_xbar_slv_0` - `axi_vip_xbar_slv_3` | 作为 4 个 AXI slave memory model，响应 crossbar 的 `m_axi_*` 端口 |
| `protocol_monitor` | 监听下游握手、检查地址路由、source tag、stall 情况 |
| `transaction_cg` / `route_cg` / `stall_cg` | 统计功能覆盖率 |

基本检查任务：

| 任务 | 检查内容 |
| --- | --- |
| `vip_write` | 发送写事务，检查 `BRESP` 和返回 ID |
| `vip_read_check` | 发送读事务，检查 `RRESP`、返回 ID 和读数据 |
| `check_route_matrix` | 检查 4x4 所有 source-target 写路由和读路由都被命中 |
| `protocol_monitor` | 检查下游地址 decode 是否等于实际 target，检查扩展 ID 中的 source tag 合法 |

## 3. 运行模式

当前默认模式为 `all`。也就是说，如果 GUI 不传 plusarg，或者脚本使用 `-Mode all`，会在一次仿真中顺序执行：

```text
directed -> random -> stress
```

可选模式如下：

| 模式 | 说明 | 是否发 AXI 事务 |
| --- | --- | --- |
| `smoke` | 只启动 VIP agent，检查环境是否能起来 | 否 |
| `directed` | 定向功能测试 | 是 |
| `random` | 随机事务测试，使用随机 ready backpressure | 是 |
| `stress` | 与 random 同一生成器，但打开进度打印，面向压力回归 | 是 |
| `all` | 一次仿真内顺序跑 directed、random、stress | 是 |

推荐运行命令：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\sim\scripts\run_axi_crossbar_vip_4x4.ps1 -Mode all -Seed 1 -Transactions 200
```

Vivado GUI 已配置 custom Tcl：

```text
sim/scripts/tb_axi_crossbar_vip_4x4_run_all.tcl
```

该 Tcl 会执行 `run all`，避免 GUI 默认只跑 `1000ns` 就停止。

## 4. 测试例设计

### 4.1 smoke

设计目的：

验证 AXI VIP package、VIP wrapper、DUT、clock/reset 和 agent 启动流程是否正常。

执行内容：

1. 等待 `agents_started`。
2. 等待 `aresetn` 释放。
3. 等 10 个时钟。
4. 打印 coverage summary。

预期结果：

`TB_PASS smoke`，并且不产生 AXI AW/AR 下游事务。

当前状态：

已通过。最近一次运行输出 `TB_PASS smoke`。

### 4.2 directed: routing_matrix

设计目的：

验证 4 个 source 到 4 个 target 的完整读写路由矩阵。

执行内容：

对每个 `(source, target)` 组合执行：

1. 写入 `target_base_addr(target) + offset`。
2. 从同一地址读回。
3. 检查写响应为 `OKAY`。
4. 检查读响应为 `OKAY`。
5. 检查读数据与写数据一致。
6. 由 `protocol_monitor` 检查下游 AW/AR 实际 target 是否与地址 decode 一致。
7. 由 `check_route_matrix` 检查所有 source-target 写路由和读路由都至少命中一次。

覆盖场景：

| 覆盖点 | 场景 |
| --- | --- |
| source | 0、1、2、3 |
| target | 0、1、2、3 |
| direction | write、read |
| response | `OKAY` |
| route matrix | 4 x 4 x 2 全路由矩阵 |

当前状态：

已通过。`all` 回归中 route coverage 为 `100.00%`。

### 4.3 directed: decode_error

设计目的：

验证未映射地址不会被错误转发到下游 slave，并且上游能收到 `DECERR`。

执行内容：

对每个 source 执行：

1. 向 `UNMAPPED_ADDR + offset` 写事务。
2. 从 `UNMAPPED_ADDR + offset` 读事务。
3. 期望写响应 `DECERR`。
4. 期望读响应 `DECERR`。
5. 记录进入该测试前的 `downstream_aw_count/downstream_ar_count`。
6. 测试后检查这两个计数没有变化，确认 decode error 没有打到下游。

覆盖场景：

| 覆盖点 | 场景 |
| --- | --- |
| mapped | unmapped |
| direction | write、read |
| response | `DECERR` |
| source | 0、1、2、3 |
| burst length | source 0 使用 4-beat，其余 source 使用 1-beat |

当前状态：

已通过。`all` 回归中 `failures=0`。

### 4.4 directed: burst_and_strobe

设计目的：

验证 burst 类型、连续多拍数据、FIXED burst 数据语义和 byte strobe。

执行内容：

| 子项 | 操作 | 检查 |
| --- | --- | --- |
| INCR burst | 对 M2 执行 4-beat INCR 写读 | 读回数据逐拍递增 |
| WRAP burst | 对 M2 执行 4-beat WRAP 写读 | 读回数据逐拍递增 |
| FIXED burst | 对 M2 执行 4-beat FIXED 写读 | 固定地址最终读回最后一拍数据 |
| Partial strobe | 对 M1 执行 `strb=4'b0101` 写 | 读回值应保留未写 byte 的默认 memory fill |

partial strobe 预期值：

```text
写入数据: 0x1122_3344
写 strobe: 4'b0101
默认 memory fill: 0xA5A5_A5A5
期望读回: 0xA522_A544
```

覆盖场景：

| 覆盖点 | 场景 |
| --- | --- |
| burst type | FIXED、INCR、WRAP |
| beats | 4-beat burst |
| strobe | full strobe、partial strobe |
| data check | 单拍、多拍、固定地址覆盖 |

当前状态：

已通过。`all` 回归中 transaction coverage 为 `93.89%`。

### 4.5 directed: arbitration_and_id_expansion

设计目的：

验证多个 source 同时访问同一个 target 时的仲裁，以及 crossbar 对 ID 的扩展/还原。

执行内容：

1. 4 个 source 并发向 M0 写不同地址。
2. 4 个事务使用相同上游 ID `8'h5a`。
3. crossbar 下游 ID 应加入 source tag，用于区分返回路径。
4. 随后每个 source 读回对应地址。
5. 检查读回数据分别为各 source 写入值。

覆盖场景：

| 覆盖点 | 场景 |
| --- | --- |
| arbitration | 4 个 source 同时竞争 M0 |
| ID handling | 相同上游 ID，经下游 source tag 区分 |
| response routing | B/R 返回到正确 source |
| read data | 每个 source 读回自身写入数据 |

当前状态：

已通过。monitor 没有报告 `write_source_tag` 或 `read_source_tag` 错误。

### 4.6 directed: outstanding

设计目的：

验证同一 source 对同一 target 发送多个未完成事务时，响应 ID 和数据不会串扰。

执行内容：

1. 对 slave 3 memory model 设置固定响应延迟：
   - `bresp_delay = 8`
   - `inter_beat_gap = 8`
2. source 2 连续发送两个写事务：
   - ID `8'ha1`，地址 `M3 + 0x5000`，数据 `0x6600_0001`
   - ID `8'ha2`，地址 `M3 + 0x5004`，数据 `0x6600_0002`
3. 等待两个写响应，检查两个 ID 都返回。
4. 连续发送两个读事务：
   - ID `8'hb1`，读 `M3 + 0x5000`
   - ID `8'hb2`，读 `M3 + 0x5004`
5. 检查两个读响应 ID 和数据。

覆盖场景：

| 覆盖点 | 场景 |
| --- | --- |
| outstanding write | 同一 source 连续 2 个写事务 |
| outstanding read | 同一 source 连续 2 个读事务 |
| delayed response | 下游响应延迟 |
| ID/data integrity | 返回 ID 与数据匹配 |

当前状态：

已通过。`all` 回归中没有 `outstanding_*` failure。

### 4.7 directed: backpressure

设计目的：

验证 crossbar 在 ready 间歇拉低时不会丢事务、乱序返回错误数据或卡死。

执行内容：

1. 调用 `configure_backpressure(0)`。
2. ready generator 使用 OSC 策略：
   - low time = 2
   - high time = 1
3. 每个 source 执行 4-beat INCR 写读。
4. 检查读回数据。
5. 检查 `stall_count` 不为 0，确认确实观察到 backpressure。

覆盖场景：

| 覆盖点 | 场景 |
| --- | --- |
| upstream stall | AW、W、B、AR、R |
| downstream stall | AW、W、B、AR、R |
| burst under backpressure | 4-beat INCR |
| data integrity | backpressure 下读回正确 |

当前状态：

已通过。`all` 回归中 stall coverage 为 `100.00%`，`stalls=8059`。

### 4.8 random

设计目的：

用约束随机事务扩大覆盖空间，覆盖不同 source、target、地址、burst、读写方向、mapped/unmapped 和响应类型组合。

随机约束来自 `xbar_random_request`：

| 字段 | 约束 |
| --- | --- |
| source | 0 到 3 |
| target | 0 到 3 |
| mapped | mapped:unmapped = 9:1 |
| burst | INCR:FIXED:WRAP = 8:1:1 |
| beats | 1、2、4、8，权重为 4:2:2:1 |
| offset | 4-byte 对齐，位于 `0x0100` 到 `0xE000` |
| WRAP beats | 只允许 2、4、8 |
| strobe | package 支持 full/partial，但当前 `run_random_traffic` 强制 full strobe |

执行内容：

1. 使用 `request.srandom(seed)` 固定随机种子。
2. 调用 `configure_backpressure(1)`，使用随机 ready policy。
3. 每笔随机事务：
   - mapped write: 写入后读回检查。
   - mapped read: 通过写读组合检查数据路径。
   - unmapped write: 期望 `DECERR`。
   - unmapped read: 期望 `DECERR`。
4. FIXED burst 读回时使用最后一拍作为期望值。
5. INCR/WRAP burst 读回时按 beat 递增检查。

覆盖场景：

| 覆盖点 | 场景 |
| --- | --- |
| source/target | 随机覆盖 4x4 |
| mapped/unmapped | OKAY 与 DECERR 路径 |
| burst type | INCR 为主，少量 FIXED/WRAP |
| beats | 1、2、4、8 |
| backpressure | 随机 ready 拉低 |

当前状态：

已通过。当前默认回归中 random 作为 `all` 的第二阶段执行完成。

### 4.9 stress

设计目的：

在 random 基础上继续施加随机 backpressure，并用于更长事务数的压力回归。

执行内容：

`stress` 与 `random` 使用同一个 `run_random_traffic` 生成器，差异是 verbose 打开。每完成 250 笔会打印一次：

```text
TB_INFO stress_progress completed=<n> total=<count>
```

覆盖场景：

| 覆盖点 | 场景 |
| --- | --- |
| 随机读写 | mapped/unmapped、读/写混合 |
| 随机 backpressure | 上游和下游 ready 随机变化 |
| 长时间运行 | 通过较大 `TRANSACTIONS` 增加压力 |

当前状态：

已通过。当前默认回归中 stress 作为 `all` 的第三阶段执行完成。

## 5. 功能覆盖模型

### 5.1 route coverage

`route_cg` 统计：

| Coverpoint | 内容 |
| --- | --- |
| source | 0 到 3 |
| target | 0 到 3 |
| direction | read、write |
| cross | source x target x direction |

目标是覆盖完整 4x4 读写路由矩阵。

当前结果：

```text
route = 100.00%
```

### 5.2 transaction coverage

`transaction_cg` 统计：

| Coverpoint | 内容 |
| --- | --- |
| source | 0 到 3 |
| target | mapped target 0 到 3，以及 unmapped |
| mapped | yes/no |
| direction | read/write |
| beats | single、short burst、long burst |
| burst | FIXED、INCR、WRAP |
| strobe | full、partial |
| response | OKAY、DECERR |
| cross | mapped x direction x response |
| cross | direction x burst x beats |

当前结果：

```text
transaction = 93.89%
```

没有达到 100% 的主要原因是当前随机流量强制 full strobe，partial strobe 主要由 directed 测试覆盖；部分 direction/burst/beats 组合也依赖随机命中。

### 5.3 stall coverage

`stall_cg` 统计：

| Bin | 通道 |
| --- | --- |
| upstream_aw | 上游 AW stall |
| upstream_w | 上游 W stall |
| upstream_b | 上游 B stall |
| upstream_ar | 上游 AR stall |
| upstream_r | 上游 R stall |
| downstream_aw | 下游 AW stall |
| downstream_w | 下游 W stall |
| downstream_b | 下游 B stall |
| downstream_ar | 下游 AR stall |
| downstream_r | 下游 R stall |

当前结果：

```text
stall = 100.00%
```

## 6. 当前验证结果

最近一次完整回归命令：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\sim\scripts\run_axi_crossbar_vip_4x4.ps1 -Mode all -Seed 1 -Transactions 200
```

结果：

```text
TB_INFO agents_started mode=all seed=1 transactions=200
TB_INFO all directed
TB_INFO all random
TB_INFO all stress
TB_COVERAGE route=100.00 transaction=93.89 stall=100.00 checks=4031 failures=0 stalls=8059 aw=383 ar=383
TB_PASS all
TB_PASS runner mode=all seed=1 transactions=200
```

结论：

| 项目 | 状态 |
| --- | --- |
| 编译 | 通过 |
| elaboration | 通过 |
| smoke | 通过 |
| directed | 通过 |
| random | 通过 |
| stress | 通过 |
| all 单次完整回归 | 通过 |
| failure count | 0 |

覆盖率报告路径：

```text
sim/build/axi_crossbar_vip_4x4/all/coverage_report/xcrg_report.txt
```

## 7. 已知限制与后续建议

1. 当前 random/stress 中 `run_random_traffic` 使用 `randomize() with { strb == full; }`，因此 partial strobe 主要依赖 directed 测试覆盖。后续可以放开随机 strobe，以提高 transaction coverage。
2. 当前 stress 与 random 使用同一事务生成器，区别主要是进度打印和回归用途。若需要更强压力，可增加 outstanding 随机化、跨 source 并发随机流量。
3. 当前 watchdog 已按 `all` 模式扩展 timeout 预算，避免 `TRANSACTIONS=200` 时被固定 100us 提前杀掉。
4. 当前 coverage 是 testbench 自定义 covergroup 的功能覆盖率，不等价于 RTL line/toggle/code coverage。

