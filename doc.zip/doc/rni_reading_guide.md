# RNI 模块阅读顺序与设计总览

本文档面向学习当前工程中的 RNI RTL，目标不是替代源码，而是给出一条比较顺的阅读路径：先看系统骨架，再看 AXI 入口如何被切成 CHI transaction，再分别深入读路径、写路径、link/credit 管理，最后回头看公共小模块。

涉及的主要源码目录：

```text
rtl/rni
rtl/include/rni_param.v
rtl/include/rni_defines.v
rtl/include/axi4_defines.v
rtl/include/chie_defines.v
rtl/misc/sync_fifo.v
rtl/misc/poll_function.v
rtl/misc/poll_with_start_entry.v
```

## 1. 推荐阅读顺序

建议按下面顺序阅读：

| 顺序 | 模块/文件 | 为什么先读它 |
| --- | --- | --- |
| 1 | `rni_param.v`, `rni_defines.v`, `axi4_defines.v`, `chie_defines.v` | 先建立参数、位宽、flit 字段、mask 字段的基础概念 |
| 2 | `rni.v` | 看顶层如何把 AXI、CHI、读写控制、buffer、link 串起来 |
| 3 | `rni_axi_bus.v` | 理解 AXI 独立字段如何被打包成内部 bus |
| 4 | `sync_fifo.v`, `poll_function.v`, `poll_with_start_entry.v` | 这些公共模块贯穿 AW/AR entry 分配、调度和入口缓存 |
| 5 | `rni_segburst.v` | 这是 AXI burst 转 CHI/cacheline segment 的核心 |
| 6 | `rni_awlink.v`, `rni_arlink.v` | 看 AXI AW/AR 入口 FIFO、backpressure、segment 输出 |
| 7 | `rni_arctrl.v` | 先看读控制，读路径相对写路径少了 W/TXDAT/CompAck 流程 |
| 8 | `rni_rd_buffer.v`, `rni_datbuf_bank.v` | 接着看 RXDAT 如何落 bank，如何返回 AXI R |
| 9 | `rni_awctrl.v` | 再看写控制，包含 TXREQ、DBID、TXDAT、Comp、Retry、B response |
| 10 | `rni_wr_buffer.v`, `rni_bcount_ctl.v` | 看 AXI W 如何缓存、按 bank 收齐、组 TXDAT、生成 B |
| 11 | `rni_link_handshake.v`, `rni_lcrd_hdlr.v`, `rni_link_ctl.v` | 最后看 CHI link active、L-credit、TX/RX flit 仲裁 |
| 12 | `rni_misc.v` | 看 Retry/PCRDGrant 的共享辅助逻辑 |

这样读的好处是：先理解 transaction 被拆成什么，再看 entry 怎么管理，最后看这些 request/data/response 如何真正经过 CHI link 发出去。

## 2. 先建立几个核心概念

### 2.1 RNI 的位置

当前 `rni` 可以看成一个 AXI4 slave 到 CHI-E RN-I 侧接口的转换模块。上游 AXI master 发出 AW/W/AR 请求，RNI 将其转换为 CHI `TXREQ/TXDAT/TXRSP`，并接收 CHI `RXRSP/RXDAT`，最终恢复为 AXI `B/R` 响应。

整体数据流：

```text
AXI AW/AR
  -> rni_axi_bus
  -> rni_awlink / rni_arlink
  -> rni_segburst
  -> rni_awctrl / rni_arctrl
  -> CHI TXREQ
  -> rni_link_ctl
  -> CHI network

AXI W
  -> rni_axi_bus
  -> rni_wr_buffer
  -> CHI TXDAT
  -> rni_link_ctl
  -> CHI network

CHI RXDAT
  -> rni_link_ctl
  -> rni_rd_buffer
  -> rni_datbuf_bank
  -> AXI R

CHI RXRSP
  -> rni_link_ctl
  -> rni_awctrl / rni_arctrl / rni_misc
```

### 2.2 Entry

RNI 内部的 `entry` 是一个 transaction/segment 的跟踪槽位。

读路径里有 AR entry：

```text
RNI_AR_ENTRIES_NUM_PARAM
```

写路径里有 AW entry：

```text
RNI_AW_ENTRIES_NUM_PARAM
```

一个 AXI burst 如果跨多个 64B cacheline，会被 `rni_segburst` 切成多个 segment。每个 segment 通常会分配一个 entry。因此 entry 不是简单等价于一个原始 AXI burst，而更接近“一个已经按 CHI/cacheline 规则规整后的 request 单元”。

### 2.3 Segment

`segment` 是 `rni_segburst` 输出的一个 CHI 请求片段。它包含：

- segment 起始地址
- segment 是否是原始 AXI burst 的最后一段
- CHI request size
- 该 segment 覆盖哪些 16B bank
- 每个 bank 对应的 beat count 信息

### 2.4 16B Bank

当前设计把一个 64B cacheline 拆成 4 个 16B bank：

```text
bank0: offset 0x00 ~ 0x0f
bank1: offset 0x10 ~ 0x1f
bank2: offset 0x20 ~ 0x2f
bank3: offset 0x30 ~ 0x3f
```

很多 mask 都是 4 bit，每一 bit 对应一个 bank。

### 2.5 dmask

`rni_segburst` 输出的 `dmask` 宽度为 16 bit，通常被拆成四组 4 bit：

| 字段 | 作用 |
| --- | --- |
| `CT mask` | 当前需要传输/返回的 bank |
| `PD mask` | pending data mask，当前 segment 需要等待/处理的 bank |
| `LS mask` | last mask，标记哪个 bank 对应 AXI LAST/RLAST/B 返回边界 |
| `RV mask` | received-valid mask，用于读路径跟踪 RXDAT 哪些 bank 已回来 |

理解这四个 mask，是读懂 `rni_arctrl`、`rni_awctrl`、`rni_rd_buffer`、`rni_wr_buffer` 的关键。

## 3. 参数与宏定义

### 3.1 `rni_param.v`

这个文件定义 RNI 参数宏 `RNI_PARAM` 和 `RNI_PARAM_INST`。主要参数包括：

| 参数 | 默认值 | 含义 |
| --- | ---: | --- |
| `AXI4_PA_WIDTH_PARAM` | 44 | AXI 地址宽度 |
| `AXI4_AXDATA_WIDTH_PARAM` | 128 | AXI W/R data 宽度 |
| `CHIE_NID_WIDTH_PARAM` | 11 | CHI Node ID 宽度 |
| `CHIE_REQ_ADDR_WIDTH_PARAM` | 44 | CHI REQ 地址宽度 |
| `CHIE_DATA_WIDTH_PARAM` | 256 | CHI DAT flit data 宽度 |
| `CHIE_BE_WIDTH_PARAM` | 32 | CHI DAT byte enable 宽度 |
| `RNI_AR_ENTRIES_NUM_PARAM` | 32 | 读 entry 数量 |
| `RNI_AW_ENTRIES_NUM_PARAM` | 32 | 写 entry 数量 |
| `HNF_NID_PARAM` | 0 | 目标 HNF 节点 ID |
| `RNI_NID_PARAM` | 6 | 当前 RNI 节点 ID |

这里要注意：`RNI_NID_PARAM` 和 `HNF_NID_PARAM` 是 CHI 网络节点 ID，不是 AXI ID。AXI ID 用于 AXI outstanding 和 ordering；Node ID 用于 CHI flit 的 `SrcID/TgtID`。

### 3.2 `rni_defines.v`

这个文件定义 RNI 内部常用宽度和 FIFO 参数。重点看：

```verilog
RNI_DMASK_CT_WIDTH = 4
RNI_DMASK_PD_WIDTH = 4
RNI_DMASK_LS_WIDTH = 4
RNI_DMASK_RV_WIDTH = 4
RNI_BC_WIDTH       = 4
RNI_BCVEC_WIDTH    = 16
RNI_DMASK_WIDTH    = 16
```

这些定义体现了 RNI 内部的 4-bank 模型。

还要看：

```verilog
RNI_RD_BANK_NUM        = 4
RNI_RD_BANK_DATA_WIDTH = 128
WR_BUFFER_DATA_BANK_NUM = 4
```

这说明读写 buffer 都围绕 4 个 16B bank 组织。

### 3.3 `axi4_defines.v`

定义 AXI AW/W/B/AR/R 内部打包 bus 的字段范围。例如：

```text
AW_CH_S0: AWID/AWADDR/AWLEN/AWSIZE/AWBURST/...
AR_CH_S0: ARID/ARADDR/ARLEN/ARSIZE/ARBURST/...
W_CH_S0 : WDATA/WSTRB/WLAST
B_CH_S0 : BID/BRESP
R_CH_S0 : RID/RDATA/RRESP/RLAST
```

后续模块一般不再直接处理顶层 AXI 分散字段，而是处理这些 packed bus。

### 3.4 `chie_defines.v`

定义 CHI flit 字段范围和 opcode。RNI 当前主要使用：

| 类型 | opcode |
| --- | --- |
| 读请求 | `CHIE_READONCE` |
| 写请求 | `CHIE_WRITEUNIQUEPTL` |
| 写数据 | `CHIE_NONCOPYBACKWRDATA` |
| 写数据携带 CompAck | `CHIE_NCBWRDATACOMPACK` |
| 写 CompAck | `CHIE_COMPACK` |
| 正常写响应 | `CHIE_COMP`, `CHIE_DBIDRESP`, `CHIE_COMPDBIDRESP` |
| Retry 流程 | `CHIE_RETRYACK`, `CHIE_PCRDGRANT` |
| 数据返回 | `CHIE_COMPDATA` |

## 4. 顶层骨架

### 4.1 `rni.v`

`rni.v` 是顶层集成模块。它本身不实现复杂算法，主要负责把各个子模块连接起来。

主要实例关系：

```text
rni
  |- rni_axi_bus
  |- rni_arctrl
  |- rni_rd_buffer
  |- rni_awctrl
  |- rni_wr_buffer
  |- rni_misc
  |- rni_link_ctl
```

推荐读 `rni.v` 时不要陷入每根 wire，而是先抓住这些边界：

- `rni_axi_bus` 负责 AXI 字段打包/解包。
- `rni_arctrl` 负责读 request entry、TXREQ、读返回调度。
- `rni_rd_buffer` 负责 RXDAT 数据缓存和 AXI R 输出。
- `rni_awctrl` 负责写 request entry、TXREQ、DBID/Comp/Retry、B 调度。
- `rni_wr_buffer` 负责 AXI W 缓存、TXDAT 组包、AXI B 输出。
- `rni_misc` 负责 PCRDGrant 的共享缓存与 AR/AW 仲裁。
- `rni_link_ctl` 负责 CHI link active、L-credit、TX/RX flit pipeline。

### 4.2 `rni_axi_bus.v`

`rni_axi_bus` 是一个纯字段重组模块。

它做两件事：

1. 把顶层 AXI 输入字段打包成内部 bus：

```text
AWID/AWADDR/AWLEN/... -> AW_CH_S0
WDATA/WSTRB/WLAST    -> W_CH_S0
ARID/ARADDR/ARLEN/... -> AR_CH_S0
```

2. 把内部返回 bus 解包到顶层 AXI 输出字段：

```text
B_CH_S0 -> BID/BRESP
R_CH_S0 -> RID/RDATA/RRESP/RLAST
```

设计思路很直接：后续控制模块只需要处理 packed bus，可以减少端口数量，也避免每个模块重复拼字段。

## 5. 公共基础模块

### 5.1 `sync_fifo.v`

`sync_fifo` 是同步 FIFO，被 AW/AR link、W buffer、B/R 返回 FIFO、PCRDGrant FIFO 等复用。

设计特点：

- 单时钟同步 FIFO。
- 参数化宽度和深度。
- `FIFO_BYP_ENABLE` 支持空 FIFO 时 push/pop 同拍旁路。
- `data_out` 是当前读指针对应的存储内容，配合 `empty/full/count` 使用。

学习时注意两点：

1. 当 `FIFO_BYP_ENABLE=0` 时，本拍 push 的数据不会直接作为 `data_out` 旁路输出。
2. 很多入口 FIFO 深度很小，例如 AW/AR link 只有 2 深度，它们主要用于吸收前后级一拍时序差，而不是作为大容量缓存。

### 5.2 `poll_function.v`

`poll_function` 是一个带状态的 round-robin/priority selector。

输入：

```text
entry_vec : 候选 entry
upd       : 本次选择被消耗，更新下次起点
```

输出：

```text
sel_entry : one-hot 选择结果
sel_index : 编码后的 index
found     : 是否找到候选项
```

`POLL_MODE=0` 时每次从 LSB 开始找；`POLL_MODE=1` 时会从上一次选择之后的位置继续找，实现比较公平的轮询。

它常用于：

- `rni_link_ctl` 中 AR/AW TXREQ 仲裁。
- `rni_link_ctl` 中 TXRSP 仲裁。
- `rni_awctrl` 中 TXDAT/BRESP/CompAck 等选择。

### 5.3 `poll_with_start_entry.v`

`poll_with_start_entry` 是一个无状态的“指定起点循环选择器”。

输入：

```text
entry_vec   : 候选 one-hot vector
start_entry : 从哪里开始找
```

输出：

```text
entry_ptr_sel : 从 start_entry 开始循环找到的第一个有效 entry
found         : 是否找到
```

它和 `poll_function` 的区别是：`poll_with_start_entry` 不保存内部轮询状态，起点完全由外部 `start_entry` 提供。

它常用于：

- AR/AW entry 分配。
- AR/AW request retry/new 选择。
- 读返回 entry 选择。
- 读返回 bank mask 选择。

## 6. AXI Burst 切分层

### 6.1 `rni_segburst.v`

`rni_segburst` 是理解 RNI 的关键模块之一。它接收一笔 AXI AW/AR burst 的地址、长度、size、burst 类型，然后输出一个或多个 segment。

它解决的问题是：AXI burst 可以跨 64B cacheline，但 CHI/RNI 内部更适合按 cacheline 和 16B bank 处理。

例如：

```text
AXI burst 覆盖 0x1030 ~ 0x106f

segment0: 0x1030 ~ 0x103f
segment1: 0x1040 ~ 0x106f
```

`rni_segburst` 的核心输出：

| 信号 | 含义 |
| --- | --- |
| `segburst_valid_s1_o` | 当前有 segment 输出 |
| `segburst_addr_s1_o` | 当前 segment 起始地址 |
| `segburst_done_s1_o` | 当前 segment 是否是原始 AXI burst 的最后一段 |
| `segburst_bc_vec_s2_o` | 每个 bank 的 beat count |
| `segburst_dmask_s2_o` | 当前 segment 的 CT/PD/LS/RV mask |
| `segburst_size_s2_o` | 当前 segment 对应的 CHI request size 编码 |
| `segburst_lock_s2_o` | AXI lock 属性延后一拍输出 |

时序上要特别注意：

```text
S1: valid / addr / done
S2: bc_vec / dmask / size / lock
```

也就是说，后级控制器通常会把 S1 分配得到的 entry pointer打一拍，使其与 S2 的 mask/size 信息对齐。

设计思路：

- 先对齐 AXI 起始地址。
- 计算 burst 覆盖的最后 byte 和最后 beat 地址。
- 判断 FIXED/INCR/WRAP。
- 判断是否跨 64B cacheline。
- 对 INCR burst，按 64B 边界顺序切分。
- 对 WRAP burst，先计算 wrap 下界，再根据是否跨 cacheline 选择 single-line 或 multiline wrap 处理。
- 对每个 segment 生成 16B bank 级别的 mask。

### 6.2 `rni_awlink.v`

`rni_awlink` 是 AXI AW 入口模块。

它的结构：

```text
AXI AWVALID/AWREADY
  -> 2-entry AW FIFO
  -> rni_segburst
  -> awctrl
```

主要作用：

- 用小 FIFO 缓冲 AW 请求。
- 给 AXI 侧产生 `AWREADY`。
- 从 FIFO 头部取出 AW bus，送入 `rni_segburst`。
- 输出 segment 地址、mask、size、done 等信息给 `rni_awctrl`。

`AWREADY` 的设计不是简单等于 FIFO 非满，还会考虑 `segburst_done_s1_o`。因为一个 AXI burst 可能被切成多个 segment，只有当前 burst 的所有 segment 都输出完成后，FIFO 才 pop 下一笔 AW。

设计思路：AW link 层只处理“入口缓存 + burst 切分”，不负责 entry 生命周期，也不负责 CHI flit 组包。这样 AW 入口和写事务控制解耦。

### 6.3 `rni_arlink.v`

`rni_arlink` 是 AXI AR 入口模块。

结构类似 AW：

```text
AXI ARVALID/ARREADY
  -> 2-entry AR FIFO
  -> rni_segburst
  -> arctrl
```

主要区别是：`rni_arlink` 接收 `alloc_busy_s1_i`，当 AR entry 满时，`rni_segburst` 会被 stall，避免继续输出无法分配的 segment。

`ARREADY` 当前主要由 AR FIFO 是否 full 决定。因为 AR link 和 AR entry 分配之间还有 `alloc_busy_s1_i` 这层 backpressure，用于阻止 segment 继续向 `rni_arctrl` 推进。

## 7. 读路径

读路径建议先看，因为它比写路径少了 AXI W、TXDAT、DBID、CompAck，结构更清楚。

### 7.1 `rni_arctrl.v`

`rni_arctrl` 是读事务控制中心。

它负责：

- 实例化 `rni_arlink` 接收 AXI AR。
- 为每个 segment 分配 AR entry。
- 保存原始 AR 信息、segment 地址、mask、size、QoS。
- 生成 CHI `ReadOnce` TXREQ。
- 处理 `RetryAck` 和匹配到的 `PCRDGrant`。
- 跟踪 RXDAT 哪些 data bank 已返回。
- 按 AXI ID ordering 和 data readiness 调度 `rni_rd_buffer` 返回 AXI R。
- 在读数据全部返回后释放 entry。

典型读路径：

```text
AR handshake
  -> rni_arlink FIFO
  -> rni_segburst segment
  -> 分配 AR entry
  -> 生成 TXREQ ReadOnce
  -> CHI 返回 RXDAT
  -> 更新 RV mask
  -> 选择可返回 bank
  -> 通知 rd_buffer 输出 RDATA
  -> PD mask 清零后 dealloc entry
```

AR entry 中的重要状态：

| 状态 | 含义 |
| --- | --- |
| `arctrl_entry_v_q` | entry 是否有效 |
| `arctrl_entry_info_q` | 原始 AXI AR bus |
| `arctrl_entry_addr_q` | segment 地址 |
| `arctrl_entry_lsmask_q` | 哪个 bank 对应 RLAST |
| `arctrl_entry_bcvec_q` | 返回 AXI R 时的 beat count |
| `arctrl_entry_rvmask_q` | 已收到哪些 RXDAT bank |
| `arctrl_entry_ctmask_q` | 当前/下一次要返回的 bank |
| `arctrl_entry_pdmask_q` | 还未返回给 AXI 的 pending bank |
| `rxrsp_retryack_recv_vec_q` | 该 entry 是否收到 RetryAck |
| `rxrsp_pcrdgrant_recv_vec_q` | 该 entry 是否收到匹配 PCRDGrant |

TXREQ 组包思路：

```text
Opcode = ReadOnce
SrcID  = RNI_NID_PARAM
TgtID  = HNF_NID_PARAM
TxnID  = {1'b0, entry_index}
Addr   = segment address
QoS    = ARQOS
```

当前代码里读请求 size 固定为 `3'b110`，也就是 64B。这一点和 AW 路径不同，AW 会使用 `rni_segburst` 输出的 segment size。

读返回调度思路：

- RXDAT 回来时，`rni_rd_buffer` 解析出 `TxnID/DataID` 并转发给 `rni_arctrl`。
- `rni_arctrl` 根据 `TxnID` 找到 entry。
- 根据 `DataID` 更新 `RV mask`。
- 当某些 bank 已经 ready，且没有 ordering dependency，就选择一个 bank mask 输出给 `rni_rd_buffer`。
- `rni_rd_buffer` 接收后返回 `rp_fifo_acpt_d4_i`。
- `rni_arctrl` 清除对应 pending bit。
- 最后一个 pending bank 被接受后，释放 entry。

读路径中的 dependency：

- request dependency：限制某些同 ID、同 cacheline 的 request 发出顺序。
- rdata dependency：限制 AXI R 返回顺序，避免同 ID 返回乱序破坏 AXI 语义。

### 7.2 `rni_rd_buffer.v`

`rni_rd_buffer` 是读数据 buffer 和 AXI R 发送模块。

它做两件事：

1. 从 CHI `RXDAT` 中解析数据并写入 `rni_datbuf_bank`。
2. 根据 `rni_arctrl` 的调度读出某个 entry、某个 bank，组装 AXI R beat。

RXDAT 写入思路：

```text
RXDATFLIT
  -> decode TxnID / DataID / Data / RespErr
  -> 根据 DataID 写入对应 bank
```

当 `CHIE_DATA_WIDTH_PARAM == 256` 时，一个 RXDAT flit 是 32B，会写两个 16B bank：

```text
DataID = 0 -> bank0 + bank1
DataID = 2 -> bank2 + bank3
```

读出思路：

```text
rni_arctrl 输出:
  arctrl_rb_valid_d4_i
  arctrl_rb_idx_d4_i
  arctrl_rb_ctmask_d4_i
  arctrl_rb_rlast_d4_i
  arctrl_rb_rid_d4_i
  arctrl_rb_bc_d4_i

rni_rd_buffer:
  读 datbuf bank
  合成 RDATA/RRESP/RID/RLAST
  进入 rp_fifo
  根据 beat count 控制 RLAST 时机
  进入 rd_fifo
  输出 AXI RVALID/R_CH_S0
```

为什么有 `rp_fifo` 和 `rd_fifo` 两级：

- `rp_fifo` 保存已经被 arctrl 调度出来的读返回候选。
- `bcount` 逻辑处理一个 bank 对应多个 AXI beat 的情况。
- `rd_fifo` 面向 AXI R 通道，吸收 `RREADY` backpressure。

### 7.3 `rni_datbuf_bank.v`

`rni_datbuf_bank` 是读返回数据的 4-bank 存储体。

结构：

```text
datbank0_q[entry]
datbank1_q[entry]
datbank2_q[entry]
datbank3_q[entry]
```

每个 bank 宽度是 128 bit，即 16B。地址是 AR entry index。

它不做控制，只做：

```text
write enable + write entry index + write data -> 写 bank
read enable  + read entry index              -> 读 bank
```

设计思路：把数据存储和读事务控制分开。`rni_arctrl` 只负责“什么时候可以返回哪个 bank”，`rni_rd_buffer/datbuf_bank` 负责“数据在哪里、如何变成 AXI RDATA”。

## 8. 写路径

写路径比读路径复杂，因为写请求有三条交织的线：

```text
AW -> TXREQ WriteUniquePtl
W  -> TXDAT NonCopyBackWrData
RXRSP -> DBID/Comp/Retry
```

### 8.1 `rni_awctrl.v`

`rni_awctrl` 是写事务控制中心。

它负责：

- 实例化 `rni_awlink` 接收 AXI AW。
- 为每个写 segment 分配 AW entry。
- 生成 CHI `WriteUniquePtl` TXREQ。
- 处理 `DBIDResp`、`Comp`、`CompDBIDResp`、`RetryAck`。
- 等待 `PCRDGrant` 后重发 Retry 请求。
- 判断何时可以通知 `rni_wr_buffer` 发送 TXDAT。
- 判断是否需要发送 `CompAck`。
- 判断何时可以生成 AXI B response。
- 在 B response 被消费后释放 entry。

典型写路径：

```text
AW handshake
  -> rni_awlink FIFO
  -> rni_segburst segment
  -> 分配 AW entry
  -> 生成 TXREQ WriteUniquePtl
  -> 等 RXRSP DBIDResp / CompDBIDResp
  -> 等 wr_buffer 收齐 W 数据
  -> 调度 wr_buffer 发 TXDAT
  -> 等 Completion 条件满足
  -> 生成 B response 调度
  -> wr_buffer 输出 AXI B
  -> dealloc entry
```

AW entry 中的重要状态：

| 状态 | 含义 |
| --- | --- |
| `awctrl_entry_v_q` | entry 是否有效 |
| `awctrl_entry_info_q` | 原始 AXI AW bus |
| `awctrl_entry_addr_q` | segment 地址 |
| `awctrl_entry_size_q` | CHI request size |
| `awctrl_entry_ctmask_q` | 写数据覆盖的 bank |
| `awctrl_entry_pdmask_q` | pending data bank |
| `awctrl_entry_expcompack_q` | 是否需要 CompAck |
| `rxrsp_dbid_recv_vec_q` | 是否收到 DBID |
| `rxrsp_comp_recv_vec_q` | 是否收到 Comp |
| `rxrsp_retryack_recv_vec_q` | 是否收到 RetryAck |
| `wdata_recv_done_q` | W 数据是否已经被 wr_buffer 收齐 |
| `txdat_send_vec_q` | TXDAT 是否已经发出 |
| `bresp_select_vec_q` | 是否已经进入 B response 流程 |

TXREQ 组包思路：

```text
Opcode = WriteUniquePtl
SrcID  = RNI_NID_PARAM
TgtID  = HNF_NID_PARAM
TxnID  = {1'b1, entry_index}
Addr   = segment address
Size   = segment size
QoS    = AWQOS
```

这里 `TxnID` 最高位为 1，用于和读 entry 区分。读请求最高位为 0。

TXDAT 调度思路：

`rni_awctrl` 不直接保存 WDATA。它等两个条件：

```text
1. 收到 DBID / 可发送写数据
2. rni_wr_buffer 已经收齐该 entry 对应的 W 数据
```

然后输出：

```text
awctrl_txdat_rdy_v_d2_o
awctrl_txdat_rdy_entry_d2_o
awctrl_txdat_dbid_d2_o
awctrl_txdat_tgtid_d2_o
awctrl_txdat_ctmask_d2_o
```

`rni_wr_buffer` 根据这些信息组 TXDAT flit。

B response 思路：

AXI B 不能在单个 segment 完成时随便返回，必须等原始 AXI 写 burst 的最后一个 segment 完成，并满足 CHI completion 条件。`awlink_done_s1_o` 会一路影响到 B response 的 last 标记。

### 8.2 `rni_wr_buffer.v`

`rni_wr_buffer` 是写数据缓存、TXDAT 组包、AXI B 输出模块。

它负责：

1. 接收 AXI W 通道。
2. 根据 `awctrl` 分配的 entry/mask，把 WDATA/WSTRB 写入对应 entry 的 4 个 bank。
3. 判断某个 AW entry 的写数据是否收齐。
4. 在 `awctrl` 允许时组装 CHI TXDAT。
5. 缓存 B response 调度信息并输出 AXI B。

AXI W 接收路径：

```text
WVALID/WREADY
  -> W data FIFO
  -> 根据 AW request FIFO 的 entry/mask 匹配到具体 bank
  -> 写入 w_data_d2_q / w_strb_d2_q
```

`rni_wr_buffer` 内部也有一个 AW request info FIFO：

```text
aw_alloc_entry
ctmask
pdmask
bc_vec
```

这个 FIFO 把 AW segment 信息和后续 W beat 对齐。因为 AXI AW 和 W 是独立通道，W 数据可能和 AW 请求不同步到达。

TXDAT 组包：

```text
从指定 entry 取 64B 写数据和 byte enable
根据 txdat_ctmask 选择低 256b 或高 256b
填入 CHI DAT flit 字段
Opcode = NonCopyBackWrData 或 NCBWrDataCompAck
```

其中：

```text
TXDAT TxnID 字段使用 HN 返回的 DBID
TXDAT DBID 字段携带本地 entry index，并将最高位置 1 表示写 entry
DataID 根据发送的是低 32B 还是高 32B 选择 0 或 2
```

B response：

`rni_awctrl` 把可以返回 B 的信息送入 `brsp_fifo`，`rni_wr_buffer` 再根据 `BREADY` 输出：

```text
BID
BRESP
BVALID
```

### 8.3 `rni_bcount_ctl.v`

`rni_bcount_ctl` 是写数据接收过程中的 bank/beat 计数器。

它接收：

```text
rq_valid
wd_valid
bcount_vec
ctmask
pdmask
```

输出：

```text
fdmask  : 当前正在填充哪个 bank
bk_done : 当前 bank 是否填完
rq_done : 整个 request 数据是否收齐
```

设计思路：

- `ctmask` 给出当前起始 bank。
- `bcount_vec` 给出每个 bank 需要多少 AXI W beat。
- `fdmask` 在 bank 完成后轮转到下一个 bank。
- `pdmask` 随完成的 bank 被清除。
- 当 pending mask 全部清空时，`rq_done` 拉高。

它是 AW segment 和 AXI W beat 之间的“对齐器”。没有它，`rni_wr_buffer` 不知道连续进来的 W beat 应该写到哪个 16B bank。

## 9. CHI Link 与 Credit

### 9.1 `rni_link_handshake.v`

`rni_link_handshake` 管理 CHI TX/RX link active 状态。

状态编码来自：

```verilog
LL_STOP
LL_ACTIVATE
LL_RUN
LL_DEACTIVATE
```

它根据：

```text
txflit_avail
RXLINKACTIVEREQ
TXLINKACTIVEACK
rxcrd_cnt_full
```

产生：

```text
TXLINKACTIVEREQ
RXLINKACTIVEACK
txlink_state
rxlink_state
lcrd_return_en
rxcrd_en
```

设计思路：

- TX 侧有待发 flit 或对端请求 RX link active 时，推动 TX link 从 STOP 进入 ACTIVATE/RUN。
- RX 侧根据对端 `RXLINKACTIVEREQ` 和本端 credit 回收状态决定是否保持 active。
- 当 TX link 不 active 时，允许发送 LCRD return flit。
- 只有 RX link 处于 RUN 时，才允许接收侧返回 RX credit。

### 9.2 `rni_lcrd_hdlr.v`

`rni_lcrd_hdlr` 是 link credit 计数器。

输入：

```text
lcrd_inc : credit 增加
lcrd_dec : credit 消耗
```

输出：

```text
lcrd_full  : credit 是否满
lcrd_avail : 是否有可用 credit
```

计数逻辑：

```text
inc=0 dec=0 : 保持
inc=0 dec=1 : -1
inc=1 dec=0 : +1
inc=1 dec=1 : 保持
```

`lcrd_avail` 的关键设计是：

```verilog
lcrd_avail = (lcrd_cnt_not_zero | lcrd_inc) & ~rst
```

这表示：当前计数非 0，或者本拍刚收到 credit 返回，都认为本拍 credit 可用。这个 `lcrd_inc` bypass 可以避免多等一拍。

### 9.3 `rni_link_ctl.v`

`rni_link_ctl` 是 CHI 物理/链路侧控制中心。

它负责：

- 实例化 `rni_link_handshake` 管理 link active。
- 实例化多组 `rni_lcrd_hdlr` 管理 RXRSP/RXDAT/TXREQ/TXDAT/TXRSP credit。
- 接收 CHI RXRSP/RXDAT flit，打一拍后分发给 `awctrl/arctrl/rd_buffer/misc`。
- 过滤 LCRD return flit，不把它当普通协议 flit 交给上层。
- 在 TXREQ 上仲裁 AR 和 AW 两个来源。
- 在 TXDAT/TXRSP/TXREQ 发送时检查 link 是否 RUN、credit 是否 available。
- 在 link inactive 时发送 LCRD return flit。

TXREQ 仲裁：

```text
arctrl_txreq
awctrl_txreq
  -> poll_function
  -> TXREQFLIT
```

由于 AR 和 AW 都可能发 TXREQ，`rni_link_ctl` 用 `poll_function` 选择一个来源，并通过：

```text
ar_txreqflit_sent_s4_o
aw_txreqflit_sent_s4_o
```

反馈给对应控制器。

TXDAT 来源比较单一，主要来自 `rni_wr_buffer`。TXRSP 当前主要来自 `rni_awctrl` 的 CompAck。

## 10. Retry 与 PCRDGrant 辅助

### 10.1 `rni_misc.v`

`rni_misc` 当前主要处理 `PCRDGrant`。

它从 `RXRSP` 中筛选：

```text
Opcode == PCRDGrant
```

然后提取：

```text
PCRDType
SrcID
TgtID
```

写入一个 PCRDGrant FIFO。之后 AR/AW 控制器根据自己被 Retry 的 entry 去匹配这个 grant。如果 AR 和 AW 都有匹配需求，`rni_misc` 做仲裁。

仲裁分 high QoS 和 low QoS：

```text
high priority grant arbitration
low priority grant arbitration
```

当前代码里还保留了一个 `L_DISABLE_H_EN` 机制，用来在 low QoS 长时间输给 high QoS 时临时禁止 high，不过当前参数：

```verilog
localparam L_DISABLE_H_EN = 1'b0;
```

所以该机制默认关闭。

设计思路：PCRDGrant 是 AR/AW 共享资源，不适合放在某一个控制器内部。`rni_misc` 把 grant 缓存和 AR/AW grant 仲裁抽出来，避免两个控制器重复解析 RXRSP。

## 11. 模块总表

| 模块 | 作用 | 重点阅读点 |
| --- | --- | --- |
| `rni.v` | 顶层集成 | 子模块连接关系、读写路径、link 路径 |
| `rni_axi_bus.v` | AXI 字段打包/解包 | AW/W/AR 打包，B/R 解包 |
| `rni_segburst.v` | AXI burst 切成 CHI/cacheline segment | 64B 边界、16B bank、dmask、S1/S2 时序 |
| `rni_awlink.v` | AW 入口缓存与切分 | AW FIFO、AWREADY、segburst pop/done |
| `rni_arlink.v` | AR 入口缓存与切分 | AR FIFO、alloc_busy backpressure |
| `rni_arctrl.v` | 读事务控制 | AR entry、ReadOnce、Retry、RXDAT mask、R 调度 |
| `rni_rd_buffer.v` | 读数据缓存与 AXI R 输出 | RXDAT DataID、datbuf bank、rp_fifo、rd_fifo、RLAST |
| `rni_datbuf_bank.v` | 读数据 bank RAM | entry index 寻址，4 个 16B bank |
| `rni_awctrl.v` | 写事务控制 | AW entry、WriteUniquePtl、DBID、TXDAT 调度、CompAck、B 调度 |
| `rni_wr_buffer.v` | 写数据缓存、TXDAT 组包、AXI B 输出 | W FIFO、AW info FIFO、bcount、TXDAT flit、B FIFO |
| `rni_bcount_ctl.v` | W beat 到 16B bank 的计数控制 | fdmask、bk_done、rq_done |
| `rni_link_handshake.v` | CHI link active 状态机 | TX/RX link state、credit return enable |
| `rni_lcrd_hdlr.v` | link credit 计数器 | inc/dec、avail bypass、full |
| `rni_link_ctl.v` | CHI link/flit/credit 总控制 | RX pipeline、TX credit、TXREQ 仲裁、LCRD return |
| `rni_misc.v` | PCRDGrant 解析和 AR/AW 仲裁 | PCRDGrant FIFO、high/low QoS arbitration |
| `sync_fifo.v` | 公共同步 FIFO | FWFT 风格读出、bypass 参数、count/full/empty |
| `poll_function.v` | 带状态轮询选择器 | round-robin、公平性、upd 更新 |
| `poll_with_start_entry.v` | 指定起点循环选择器 | 无状态 one-hot select |

## 12. 建议的学习路线细化

### 第一步：先画出顶层数据流

只看 `rni.v` 的实例化，画出：

```text
AW -> awctrl -> wr_buffer -> TXDAT
AR -> arctrl -> rd_buffer -> R
RXRSP -> awctrl/arctrl/misc
RXDAT -> rd_buffer/arctrl
TXREQ/TXDAT/TXRSP -> link_ctl
```

这一阶段不要纠结每个 entry 的寄存器。

### 第二步：理解 4-bank 模型

重点看：

```text
rni_defines.v
rni_segburst.v
rni_datbuf_bank.v
rni_rd_buffer.v
rni_wr_buffer.v
```

你需要建立这个图：

```text
64B cacheline
  = bank0 16B
  + bank1 16B
  + bank2 16B
  + bank3 16B
```

后面所有 `ctmask/pdmask/lsmask/rvmask/bc_vec` 都围绕这个模型展开。

### 第三步：先读读路径

推荐顺序：

```text
rni_arlink
  -> rni_segburst
  -> rni_arctrl
  -> rni_rd_buffer
  -> rni_datbuf_bank
```

读路径最关键的问题：

- AR burst 如何变成一个或多个 ReadOnce？
- TxnID 如何对应 AR entry？
- RXDAT DataID 如何映射到 bank？
- 什么时候可以向 AXI R 返回？
- RLAST 如何生成？

### 第四步：再读写路径

推荐顺序：

```text
rni_awlink
  -> rni_segburst
  -> rni_awctrl
  -> rni_wr_buffer
  -> rni_bcount_ctl
```

写路径最关键的问题：

- AW 和 W 是独立通道，如何在 entry 上重新关联？
- AW segment 的 mask 如何指导 WDATA 写入 bank？
- DBIDResp/CompDBIDResp 如何影响 TXDAT？
- TXDAT 的 DataID/DBID/TxnID 字段如何填写？
- AXI B 为什么只能在最后 segment 完成后返回？

### 第五步：最后看 link 和 retry

推荐顺序：

```text
rni_link_handshake
  -> rni_lcrd_hdlr
  -> rni_link_ctl
  -> rni_misc
  -> 回到 arctrl/awctrl 的 Retry 分支
```

这一阶段重点理解：

- CHI 不是 AXI valid/ready，而是 flit valid + credit。
- 发送 flit 必须 link RUN 且 credit available。
- 接收 flit 后要返回对应方向的 credit。
- RetryAck 不代表失败结束，而是等待 PCRDGrant 后重发。

## 13. 读写路径一图流

### 13.1 读路径

```text
AXI AR
  -> rni_axi_bus 打包 AR_CH_S0
  -> rni_arlink FIFO
  -> rni_segburst 切 segment
  -> rni_arctrl 分配 AR entry
  -> rni_arctrl 生成 TXREQ ReadOnce
  -> rni_link_ctl 发 TXREQ
  -> CHI network / HN
  -> RXDAT CompData
  -> rni_link_ctl 接收打一拍
  -> rni_rd_buffer 写 datbuf bank
  -> rni_arctrl 根据 TxnID/DataID 更新 RV mask
  -> rni_arctrl 调度可返回 bank
  -> rni_rd_buffer 读 bank 并输出 AXI R
```

### 13.2 写路径

```text
AXI AW
  -> rni_axi_bus 打包 AW_CH_S0
  -> rni_awlink FIFO
  -> rni_segburst 切 segment
  -> rni_awctrl 分配 AW entry
  -> rni_awctrl 生成 TXREQ WriteUniquePtl
  -> rni_link_ctl 发 TXREQ
  -> CHI network / HN
  -> RXRSP DBIDResp / CompDBIDResp / Comp

AXI W
  -> rni_axi_bus 打包 W_CH_S0
  -> rni_wr_buffer W FIFO
  -> 根据 AW entry/mask 写入 W data bank
  -> awctrl 收到 DBID 且 W 数据收齐
  -> awctrl 调度 wr_buffer 发 TXDAT
  -> rni_link_ctl 发 TXDAT
  -> Completion 条件满足
  -> awctrl 调度 B response
  -> wr_buffer 输出 AXI B
```

## 14. 容易混淆的点

### 14.1 AXI ID 和 CHI TxnID 不是一回事

AXI ID 来自 `AWID/ARID`，用于 AXI ordering。

CHI TxnID 在 RNI 内部通常编码 entry index：

```text
读: TxnID[MSB] = 0, 低位 = AR entry index
写: TxnID[MSB] = 1, 低位 = AW entry index
```

这样 RXRSP/RXDAT 回来时，可以定位到对应 entry。

### 14.2 `rni_segburst` 不管理 outstanding

`rni_segburst` 只负责切 segment。真正的 outstanding/entry 管理在：

```text
rni_arctrl
rni_awctrl
```

### 14.3 `rni_datbuf_bank` 不是通用 cache

它只是读返回临时数据 buffer。地址是 AR entry index，不是物理地址。

### 14.4 `rni_wr_buffer` 和 `rni_awctrl` 分工不同

`rni_awctrl` 管控制：

```text
entry、TXREQ、DBID、Comp、Retry、TXDAT 调度、B 调度
```

`rni_wr_buffer` 管数据：

```text
W FIFO、W data bank、TXDAT payload、B channel FIFO
```

### 14.5 `rni_link_ctl` 的 sent 信号不只是 valid

例如：

```text
ar_txreqflit_sent_s4_o
aw_txreqflit_sent_s4_o
```

表示该 flit 真的被 link 层接受并准备发送。它需要同时满足：

- 对应 valid 为 1
- TX link 在 RUN
- 对应 TX credit available
- 仲裁选中
- 当前不是 LCRD return 占用

## 15. 建议后续深入顺序

如果你已经理解本文档，下一步建议按下面专题继续深入：

1. `rni_segburst` 的 mask/size 生成规则。
2. `rni_arctrl` 的 `RV/PD/CT/LS mask` 更新。
3. `rni_awctrl` 的 DBID、Comp、TXDAT、B response 条件。
4. `rni_link_ctl` 的 L-credit 与 TXREQ 仲裁。
5. 对照仿真波形观察一笔 64B read 和一笔 64B write。

学习这个 RNI 时，最好的方法不是一口气读完所有 always block，而是每次只追一条线：

```text
一笔 AR 怎么变成 ReadOnce？
一笔 RXDAT 怎么变成 AXI R？
一笔 AW 怎么等到 DBID？
一组 WDATA 怎么变成 TXDAT？
一个 RetryAck 怎么等 PCRDGrant 后重发？
```

把这五条线追清楚，整个 RNI 的设计骨架基本就立起来了。 
