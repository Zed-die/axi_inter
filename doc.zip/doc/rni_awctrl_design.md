# rni_awctrl 设计报告

        RNI                                   HN
         |                                    |
         |---- REQ: WriteUniquePtl ---------->|
         |     TxnID = {1'b1, aw_entry}       |
         |     Addr/Size/QoS/AllowRetry       |
         |                                    |
         |<--- RSP: DBIDResp -----------------|
         |     TxnID = {1'b1, aw_entry}       |
         |     DBID                           |
         |                                    |
         |---- DAT: NonCopyBackWrData ------->|
         |     TxnID = DBID from HN           |
         |     DBID  = {1'b1, aw_entry}       |
         |     Data/BE/DataID                 |
         |                                    |
         |<--- RSP: Comp ---------------------|
         |     TxnID = {1'b1, aw_entry}       |
         |                                    |
         |---- RSP: CompAck ----------------->|  optional
         |     only if ExpCompAck = 1         |
         |                                    |

如果 HN 把 DBID 和 Comp 合并返回，则是：

```
        RNI                                   HN
         |                                    |
         |---- REQ: WriteUniquePtl ---------->|
         |                                    |
         |<--- RSP: CompDBIDResp -------------|
         |     DBID + completion              |
         |                                    |
         |---- DAT: NonCopyBackWrData ------->|
         |                                    |
         |---- RSP: CompAck ----------------->|  optional
         |                                    |
```

如果发生 Retry：

```
        RNI                                   HN
         |                                    |
         |---- REQ: WriteUniquePtl ---------->|
         |     AllowRetry = 1                 |
         |                                    |
         |<--- RSP: RetryAck -----------------|
         |     PCRDType                       |
         |                                    |
         |<--- RSP: PCRDGrant ----------------|
         |     matching PCRDType              |
         |                                    |
         |---- REQ: WriteUniquePtl ---------->|
         |     AllowRetry = 0                 |
         |     PCRDType from RetryAck         |
         |                                    |
         |<--- RSP: DBIDResp/CompDBIDResp ----|
         |                                    |
         |---- DAT: NonCopyBackWrData ------->|
         |                                    |
         |<--- RSP: Comp ---------------------|  if not CompDBIDResp
         |                                    |
         |---- RSP: CompAck ----------------->|  optional
         |                                    |
```

本文基于 `rtl/rni/rni_awctrl.v`、`rtl/rni/rni_awlink.v`、`rtl/rni/rni_wr_buffer.v` 和相关宏定义整理。文档重点说明 `rni_awctrl` 在 RNI 写通路中的作用、entry 生命周期、AW segment 如何变成 CHI `WriteUniquePtl` 请求、RXRSP/Retry/PCRDGrant 如何处理、TXDAT 如何授权、CompAck 和 AXI B response 如何产生。

## 1. 模块定位

`rni_awctrl` 是 RNI 写请求控制模块。它位于 AXI AW 通道、CHI REQ/RSP/DAT 通道以及 `rni_wr_buffer` 之间，负责把 AXI 写地址请求转换成 CHI 写事务控制流。

它本身不直接接收 AXI WDATA，也不直接拼 TXDAT 数据。AXI WDATA 的缓存、WSTRB 保存、TXDAT 数据 flit 拼接、AXI B 通道输出主要由 `rni_wr_buffer` 完成。`rni_awctrl` 的核心职责是：

```text
1. 接收 rni_awlink 拆分后的 AW segment
2. 为每个 segment 分配 AW entry
3. 保存 AWID/AWADDR/AWSIZE/AWQOS/ctmask/pdmask 等 entry 信息
4. 建立同 AWID 的 req/compack/bresp 顺序依赖链
5. 仲裁可发送的 TXREQ WriteUniquePtl
6. 处理 RXRSP: DBIDResp / CompDBIDResp / Comp / RetryAck
7. 处理 RetryAck 之后的 PCRDGrant 匹配
8. 在 DBID 和写数据都准备好后，授权 rni_wr_buffer 发送 TXDAT
9. 在需要时发送 TXRSP CompAck
10. 在 CHI 写事务完成后，通知 rni_wr_buffer 返回 AXI B response
11. 在 B response 调度项被消费后释放 AW entry
```

整体数据流如下：

```text
AXI AW
  -> rni_axi_bus 打包成 AW_CH_S0
  -> rni_awlink FIFO + rni_segburst
  -> rni_awctrl 分配 awctrl_entry_* entry
  -> TXREQ WriteUniquePtl
  -> CHI fabric / HN
  -> RXRSP DBIDResp / Comp / CompDBIDResp / RetryAck

AXI W
  -> rni_wr_buffer 缓存写数据
  -> 等 awctrl_txdat_rdy_* 授权
  -> TXDAT NonCopyBackWrData

CHI completion
  -> 可选 TXRSP CompAck
  -> awctrl_brsp_* 调度
  -> rni_wr_buffer 输出 AXI B
  -> awctrl_entry_dealloc_vec_w 释放 entry
```

## 2. 外部接口分组

### 2.1 AXI AW 接口

```verilog
input  wire                      AWVALID0;
input  wire [`AXI4_AW_WIDTH-1:0] AW_CH_S0;
output wire                      AWREADY0;
```

`AW_CH_S0` 是 `rni_axi_bus` 打包后的 AXI AW 总线，包含 `AWID`、`AWADDR`、`AWLEN`、`AWSIZE`、`AWBURST`、`AWLOCK`、`AWCACHE`、`AWPROT`、`AWQOS`、`AWREGION`。

`AWREADY0` 不是在 `rni_awctrl` 主体中直接生成，而是由内部例化的 `rni_awlink` 输出。`rni_awctrl` 通过 `stall_flag_s1_w` 对 `rni_awlink` 施加反压。

### 2.2 CHI TXREQ 接口

```verilog
output wire [`CHIE_REQ_FLIT_WIDTH-1:0] awctrl_txreqflit_s4_o;
output wire                            awctrl_txreqflitv_s4_o;
input  wire                            awctrl_txreqflit_sent_s4_i;
```

`awctrl_txreqflit_s4_o` 输出 CHI REQ flit。当前写请求固定使用：

```text
Opcode = CHIE_WRITEUNIQUEPTL
```

`awctrl_txreqflit_sent_s4_i` 来自 `rni_link_ctl`，表示当前 S4 输出的 TXREQ flit 已经被 link 侧接收或者成功发送。

### 2.3 CHI RXRSP 接口

```verilog
input wire                         awctrl_rxrspflitv_d1_i;
input wire [`CHIE_RSP_FLIT_RANGE]  awctrl_rxrspflit_d1_i;
```

`rni_awctrl` 从 RXRSP 中解析：

```text
TgtID    -> awctrl_entry_rxrsp_tgtid_w
SrcID    -> awctrl_entry_rxrsp_srcid_w
TxnID    -> awctrl_entry_rxrsp_txnid_w
Opcode   -> awctrl_entry_rxrsp_opcode_w
DBID     -> awctrl_entry_rxrsp_dbid_w
PCRDType -> awctrl_entry_rxrsp_pcrdtype_w
```

本模块识别的响应类型包括：

```text
CHIE_DBIDRESP      : 返回 DBID，允许后续发送 TXDAT
CHIE_COMP          : 写事务 completion
CHIE_COMPDBIDRESP  : 同时包含 DBID 和 completion
CHIE_RETRYACK      : 请求被 Retry，需要等待 PCRDGrant 后重发 TXREQ
```

### 2.4 PCRDGrant 接口

```verilog
input  wire                            pcrdgnt_pkt_v_d2_i;
input  wire [`PCRDGRANT_PKT_WIDTH-1:0] pcrdgnt_pkt_d2_i;
output wire                            awctrl_pcrdgnt_h_present_d3_o;
output wire                            awctrl_pcrdgnt_l_present_d3_o;
input  wire                            awctrl_pcrdgnt_h_win_d3_i;
input  wire                            awctrl_pcrdgnt_l_win_d3_i;
```

`pcrdgnt_pkt_*` 由 `rni_misc` 从 CHI link 侧提取。`rni_awctrl` 根据 `RetryAck` 中保存的 `PCRDType` 匹配 PCRDGrant，并按 QoS 拆成 high/low 两路参与全局仲裁。

### 2.5 与 rni_wr_buffer 的分配接口

```verilog
output wire                                awctrl_alloc_valid_s2_o;
output wire [RNI_AW_ENTRIES_NUM_PARAM-1:0] awctrl_alloc_entry_s2_o;
output wire [`RNI_DMASK_CT_WIDTH-1:0]      awctrl_ctmask_s2_o;
output wire [`RNI_DMASK_PD_WIDTH-1:0]      awctrl_pdmask_s2_o;
output wire [`RNI_BCVEC_WIDTH-1:0]         awctrl_bc_vec_s2_o;
output wire [RNI_AW_ENTRIES_NUM_PARAM-1:0] awctrl_dealloc_entry_o;
```

这组信号告诉 `rni_wr_buffer`：新的 AW segment 已经分配 entry，并把该 segment 对应的 `ctmask`、`pdmask`、`bc_vec` 交给写数据缓存侧。

`rni_wr_buffer` 用这些信息把 AXI W beat 写入对应 entry 和 bank，并在写数据收齐时反馈：

```verilog
input wire                                wb_req_done_d3_i;
input wire [RNI_AW_ENTRIES_NUM_PARAM-1:0] wb_req_entry_d3_i;
```

### 2.6 TXDAT 授权接口

```verilog
input  wire                                wb_not_busy_d1_i;
output wire                                awctrl_txdat_rdy_v_d2_o;
output wire [RNI_AW_ENTRIES_NUM_PARAM-1:0] awctrl_txdat_rdy_entry_d2_o;
output reg  [`CHIE_DAT_FLIT_QOS_WIDTH-1:0] awctrl_txdat_qos_d2_o;
output wire                                awctrl_txdat_compack_d2_o;
output reg  [`CHIE_DAT_FLIT_DBID_WIDTH-1:0] awctrl_txdat_dbid_d2_o;
output reg  [`CHIE_DAT_FLIT_TGTID_WIDTH-1:0] awctrl_txdat_tgtid_d2_o;
output wire [`CHIE_DAT_FLIT_CCID_WIDTH-1:0] awctrl_txdat_ccid_d2_o;
output wire [`RNI_DMASK_CT_WIDTH-1:0]       awctrl_txdat_ctmask_d2_o;
input  wire                                awctrl_txdat_not_busy_d2_i;
```

`rni_awctrl` 不拼 TXDAT 数据本体，而是选择哪个 entry 可以发 TXDAT，并给出 DBID、目标节点、QoS 和本次发送的 `ctmask`。

`rni_wr_buffer` 收到这些信号后，从内部写数据 bank 取出数据，拼出 `wb_txdatflit_d3_o`。

### 2.7 B response 调度接口

```verilog
input  wire                            awctrl_brsp_fifo_pop_d3_i;
output wire                            awctrl_brsp_rdy_v_d2_o;
output wire                            awctrl_brsp_last_v_d2_o;
output wire [`AXI4_BID_WIDTH-1:0]      awctrl_brsp_axid_d2_o;
output wire [`CHIE_RSP_FLIT_RESPERR_WIDTH-1:0] awctrl_brsp_resperr_d2_o;
```

`rni_awctrl` 决定某个 AW entry 已经可以产生 AXI B response 调度项。`rni_wr_buffer` 内部有 `brsp_fifo`，最终决定是否对 AXI 输出 `BVALID0`。

注意当前代码中：

```verilog
assign awctrl_brsp_resperr_d2_o = {`CHIE_RSP_FLIT_RESPERR_WIDTH{1'b0}};
```

也就是 B response 错误信息固定为 OKAY，没有从 CHI RXRSP RespErr 传播。

## 3. 关键内部 entry 状态

每个 AW segment 会占用一个 `awctrl_entry_*` entry。entry 数量由：

```verilog
RNI_AW_ENTRIES_NUM_PARAM
```

决定，当前参数通常为 32。

主要 entry 状态如下：

```text
awctrl_entry_v_q[entry]
    entry valid 标志。

awctrl_entry_info_q[entry]
    保存完整 AXI AW bus，包括 AWID/AWADDR/AWCACHE/AWQOS 等。

awctrl_entry_len_q[entry]
    保存原始 AWLEN。当前 awctrl 主流程中主要保存备用。

awctrl_entry_addr_q[entry]
    保存 rni_segburst 输出的当前 segment 地址。

awctrl_entry_size_q[entry]
    保存当前 segment 的 CHI request Size。

awctrl_entry_ctmask_q[entry]
    当前 segment 覆盖的 16B chunk mask。

awctrl_entry_pdmask_q[entry]
    当前 segment 需要等待 AXI W 数据填充的 pending data mask。

awctrl_entry_expcompack_q[entry]
    当前 TXREQ 是否设置 ExpCompAck。

awctrl_entry_segburst_last_q[entry]
    当前 segment 是否为原始 AXI AW burst 的最后一个 segment。

awctrl_entry_qos_hi_q[entry]
    AWQOS 是否等于 4'b1111，用于 high/low QoS 仲裁。
```

`rni_awctrl` 中还维护三套同 AWID 顺序链：

```text
awctrl_entry_req_dep_v_q
    控制 TXREQ new request 的发送顺序。

awctrl_entry_compack_dep_v_q
    控制 CompAck 的发送顺序。

awctrl_entry_bresp_dep_v_q
    控制 AXI B response 的返回顺序。
```

这三套链的结构相似，但清除时机不同。

## 4. AW 接收、拆分与 entry 分配

### 4.1 rni_awlink 的作用

`rni_awctrl` 内部例化 `rni_awlink`：

```verilog
rni_awlink rni_awlink_u0 (...);
```

`rni_awlink` 内部有一个 AW FIFO，接收 `AWVALID0 & AWREADY0` 的 AXI AW 请求，然后调用 `rni_segburst` 把 AXI burst 拆成 cacheline/segment 粒度的请求。

`rni_awlink` 输出：

```text
awlink_valid_s1_w      当前 segment 有效
awlink_addr_s1_w       当前 segment 地址
awlink_done_s1_w       当前 segment 是否为原始 AW burst 的最后 segment
awlink_bc_vec_s2_w     每个 16B bank 的 beat count vector
awlink_dmask_s2_w      dmask，包括 CT/PD/LS/RV 等子字段
awlink_size_s2_w       CHI request Size
```

### 4.2 AW 侧反压

`rni_awctrl` 对 `rni_awlink` 的反压来自：

```verilog
assign stall_flag_s1_w = wb_req_fifo_pfull_d1_i | awctrl_entry_full_r;
```

含义：

```text
wb_req_fifo_pfull_d1_i = 1
    rni_wr_buffer 的 AW request FIFO 快满，不能继续接收新 AW segment。

awctrl_entry_full_r = 1
    awctrl 所有 entry 都 valid，没有空 entry。
```

因此只要写数据侧请求 FIFO 快满，或者 AW entry 池满，新的 AW segment 就会被阻塞。

### 4.3 entry 分配

可分配 entry 向量：

```verilog
assign awctrl_entry_rdy_s1_w =
    ~awctrl_entry_v_q & {RNI_AW_ENTRIES_NUM_PARAM{awlink_valid_s1_w}};
```

`poll_with_start_entry` 从空 entry 中选择一个：

```verilog
awctrl_entry_alloc(
    .entry_vec     (awctrl_entry_rdy_s1_w),
    .start_entry   ({RNI_AW_ENTRIES_NUM_PARAM{1'b0}}),
    .entry_ptr_sel (awctrl_alloc_ptr_s1_w)
);
```

`awctrl_entry_v_ns_w` 在分配时置位，在释放时清零：

```verilog
assign awctrl_entry_v_ns_w =
    (awctrl_entry_v_q | awctrl_alloc_ptr_s1_w)
    & ~awctrl_entry_dealloc_vec_w;
```

### 4.4 S1 保存的信息

当 `awctrl_alloc_ptr_s1_w[entry]` 为 1 时，保存：

```text
awctrl_entry_info_q[entry]          <= awlink_awbus_s1_w
awctrl_entry_len_q[entry]           <= awlink_len_s1_w
awctrl_entry_addr_q[entry]          <= awlink_addr_s1_w
awctrl_entry_segburst_last_q[entry] <= awlink_done_s1_w
awctrl_entry_qos_hi_q[entry]        <= (AWQOS == 4'b1111)
```

### 4.5 S2 输出给 rni_wr_buffer

S1 的分配指针打一拍得到：

```verilog
awctrl_alloc_ptr_s2_q <= awctrl_alloc_ptr_s1_w;
awlink_valid_s2_q    <= awlink_valid_s1_w;
```

S2 对外输出：

```verilog
assign awctrl_alloc_valid_s2_o = awlink_valid_s2_q;
assign awctrl_alloc_entry_s2_o = awctrl_alloc_ptr_s2_q;
assign awctrl_ctmask_s2_o      = awlink_dmask_s2_w[`RNI_DMASK_CT_RANGE];
assign awctrl_pdmask_s2_o      = awlink_dmask_s2_w[`RNI_DMASK_PD_RANGE];
assign awctrl_bc_vec_s2_o      = awlink_bc_vec_s2_w;
```

这些信号进入 `rni_wr_buffer` 的 `aw_req_fifo`，用于后续 WDATA 收集。

### 4.6 S2 保存的信息

当 `awctrl_alloc_ptr_s2_q[entry]` 为 1 时，保存：

```text
awctrl_entry_size_q[entry]    <= awlink_size_s2_w
awctrl_entry_ctmask_q[entry]  <= awctrl_ctmask_s2_o
awctrl_entry_pdmask_q[entry]  <= awctrl_pdmask_s2_o
awctrl_entry_expcompack_q[entry] <= aw_txreq_expcompack_w
```

其中：

```verilog
assign aw_txreq_expcompack_w = awctrl_new_entry_compack_dep_w;
```

也就是说，如果新 entry 和已有同 AWID entry 形成 `compack chain`，新请求会设置 `ExpCompAck`。

## 5. 三套依赖链设计

AWCTRL 中有三条链：

```text
request chain
compack chain
bresp chain
```

它们都按 AXI `AWID` 建链，目的都是保证同一 AXI ID 下的必要顺序。

### 5.1 request chain

request chain 约束 TXREQ 的 new request 发送顺序。

建链条件：

```verilog
awctrl_sameid_req_chain_vec_d2_r[entry] =
    awlink_valid_s2_q
    && (awctrl_awid_s2_r == awctrl_entry_info_q[entry][`AXI4_AWID_RANGE])
    && awctrl_req_dep_chain_young_q[entry];
```

附加前提：

```text
不是本次新分配 entry:
    awctrl_alloc_ptr_s2_q[entry] == 0

目标 entry 有效:
    awctrl_entry_v_q[entry] == 1

目标 entry 还没有收到 DBID:
    rxrsp_dbid_recv_vec_w[entry] == 0
```

request chain 的清除事件是：

```text
rxrsp_dbid_recv_vec_w[entry]
```

也就是说，前驱 entry 收到 DBID 后，后继 entry 的 TXREQ new request 依赖可以解除。

关键信号含义：

```text
awctrl_entry_is_req_dep_v_q
    记录哪些旧 entry 被后继 entry 依赖。

awctrl_entry_req_dep_v_q
    记录哪些 entry 依赖前驱 entry，因此不能作为 new request 发送。

awctrl_entry_is_req_dep_num_q[old]
    old entry 被哪个 newer entry 依赖。当前代码每个 old entry 保存一个 one-hot 后继。

awctrl_req_dep_chain_young_q
    每条同 AWID request chain 当前最新的链尾 entry。
```

### 5.2 compack chain

compack chain 约束 CompAck 的发送顺序。

建链条件：

```verilog
awctrl_sameid_compack_chain_vec_d2_r[entry] =
    awlink_valid_s2_q
    && (awctrl_awid_s2_r == awctrl_entry_info_q[entry][`AXI4_AWID_RANGE])
    && awctrl_compack_dep_chain_young_q[entry];
```

附加前提：

```text
目标 entry 有效
目标 entry 不是本次新分配 entry
目标 entry 的 compack chain 未被 clean
```

compack chain 的清除事件由：

```verilog
awctrl_compack_chain_clean_vec_w
```

产生：

```verilog
assign awctrl_compack_chain_clean_vec_w =
    ({N{awctrl_txrspflitv_d0_o & awctrl_txrspflit_sent_d0_i}} & txrsp_select_ptr_q)
    | (rxrsp_comp_recv_vec_w & ~awctrl_entry_expcompack_q);
```

含义：

```text
如果 entry 需要发送 CompAck:
    CompAck TXRSP 成功发送后，该 entry 的 compack chain clean。

如果 entry 不需要发送 CompAck:
    收到 Comp 后，该 entry 的 compack chain clean。
```

### 5.3 bresp chain

bresp chain 约束 AXI B response 返回顺序。

建链条件：

```verilog
awctrl_sameid_bresp_chain_vec_d2_r[entry] =
    awlink_valid_s2_q
    && (awctrl_awid_s2_r == awctrl_entry_info_q[entry][`AXI4_AWID_RANGE])
    && awctrl_bresp_dep_chain_young_q[entry];
```

附加前提：

```text
目标 entry 有效
目标 entry 不是本次新分配 entry
目标 entry 未被 dealloc
```

bresp chain 的清除事件是：

```text
awctrl_entry_dealloc_vec_w[entry]
```

也就是说，前驱 entry 的 B response 调度项被 `rni_wr_buffer` 消费并释放 entry 后，后继 entry 的 B response 依赖才解除。

### 5.4 三套链的差异总结

```text
request chain:
    保护 TXREQ 发送顺序
    清除点是 rxrsp_dbid_recv_vec_w

compack chain:
    保护 CompAck 顺序
    清除点是 CompAck 已发送，或者无 ExpCompAck entry 收到 Comp

bresp chain:
    保护 AXI B response 顺序
    清除点是 entry dealloc
```

这三个清除点不同，原因是写事务有多个独立阶段：

```text
TXREQ 可以在 DBID 后推进后继
CompAck 必须等 Comp/CompAck 相关动作完成
B response 必须等写数据发送、Comp、可选 CompAck 和 B response 调度都完成
```

## 6. TXREQ 仲裁设计

### 6.1 retry 请求 ready

```verilog
assign awctrl_req_retry_ready_w =
    awctrl_entry_v_q
    & awctrl_entry_req_select_rdy_q
    & rxrsp_pcrdgrant_recv_vec_q
    & ~awctrl_entry_req_select_vec_q;
```

含义：

```text
entry 有效
entry 已经进入可选状态
该 entry 曾收到 RetryAck，并且已经匹配到 PCRDGrant
该 entry 当前没有被选择过或挂起在 TXREQ select 状态
```

再按 QoS 分成：

```text
awctrl_entry_req_hi_retry_rdy_w
awctrl_entry_req_lo_retry_rdy_w
```

### 6.2 new 请求 ready

```verilog
assign awctrl_req_new_rdy_w =
    awctrl_entry_v_q
    & awctrl_entry_req_select_rdy_q
    & ~awctrl_entry_req_dep_v_q
    & ~rxrsp_retryack_recv_vec_q
    & ~awctrl_entry_req_select_vec_q;
```

含义：

```text
entry 有效
entry 已经进入可选状态
没有 request chain 依赖
没有收到 RetryAck
没有已经被 TXREQ select
```

`~awctrl_entry_req_dep_v_q` 是 request chain 真正约束 TXREQ 顺序的位置。后继 entry 即使已经 valid，只要它依赖前驱，就不能作为 new request 进入 TXREQ 仲裁。

### 6.3 四路优先级

`rni_awctrl` 有四个 `poll_with_start_entry`：

```text
req_retry_hi
req_retry_lo
req_new_hi
req_new_lo
```

最终选择优先级：

```verilog
assign awctrl_entry_req_ptr_ns_w =
    awctrl_req_hi_retry_found_w ? awctrl_entry_req_hi_retry_dec_w :
    awctrl_req_hi_new_found_w   ? awctrl_entry_req_hi_new_dec_w   :
    awctrl_req_lo_retry_found_w ? awctrl_entry_req_lo_retry_dec_w :
                                  awctrl_entry_req_lo_new_dec_w;
```

优先级从高到低是：

```text
high QoS retry
high QoS new
low QoS retry
low QoS new
```

### 6.4 select 成功条件

```verilog
assign awctrl_entry_req_select_success_flag_w =
    (awctrl_req_hi_retry_found_w
   | awctrl_req_hi_new_found_w
   | awctrl_req_lo_retry_found_w
   | awctrl_req_lo_new_found_w)
   & (awctrl_txreqflit_sent_s4_i | ~awctrl_txreqflitv_s4_o);
```

后半段：

```text
awctrl_txreqflit_sent_s4_i | ~awctrl_txreqflitv_s4_o
```

表示 TXREQ 输出通路当前可以接收新的 flit：

```text
当前 S4 没有 valid，或者
当前 S4 valid 已经被 link 侧 sent
```

这和 `valid/ready` skid buffer 的思想类似。

### 6.5 防重复选择

```verilog
assign awctrl_entry_req_select_vec_ns_w =
    (awctrl_entry_req_select_vec_q
     | ({N{awctrl_entry_req_select_success_flag_w}} & awctrl_entry_req_ptr_ns_w))
    & ~rxrsp_retryack_recv_vec_w
    & ~awctrl_entry_dealloc_vec_w;
```

`awctrl_entry_req_select_vec_q` 表示该 entry 的 TXREQ 已经被选择发送过。它防止仲裁器重复输出同一个 new request。

如果收到 `RetryAck`，对应 bit 被清掉，后续等待 PCRDGrant 后走 retry 路径。

## 7. TXREQ flit 生成

### 7.1 TXNID 编码

```verilog
aw_txreq_txnid_r[`CHIE_REQ_FLIT_TXNID_WIDTH-1] = 1'b1;
aw_txreq_txnid_r[`RNI_AW_ENTRIES_WIDTH-1:0] = selected entry index;
```

写请求 TXNID 最高位为 1，低位为 AW entry index。

格式可以理解为：

```text
TXNID = {write标志1, entry index}
```

### 7.2 flit 字段

当前代码生成的 `aw_txreqflit_info_r` 字段如下：

```text
QOS        : 来自 awctrl_entry_info_q[i][AXI4_AWQOS_RANGE]
TGTID      : HNF_NID_PARAM
SRCID      : RNI_NID_PARAM
TXNID      : {write标志1, entry index}
Opcode     : CHIE_WRITEUNIQUEPTL
Size       : awctrl_entry_size_q[i]
Addr       : awctrl_entry_addr_q[i]
AllowRetry : new 请求为 1，retry 请求为 0
PCRDType   : retry 请求使用 rxrsp_retryack_pcrdtype_q[i]，new 请求为 0
MemAttr    : EarlyWrAck=1, Device=0, Cacheable=1, Allocate=AWCACHE[MSB]
SnpAttr    : 1
Order      : 2'b10
LPID       : 0
ExpCompAck : awctrl_entry_expcompack_q[i]
```

Order置为10代表强序

`AllowRetry` 来自：

```verilog
aw_txreqflit_info_r[`CHIE_REQ_FLIT_ALLOWRETRY_RANGE] =
    ~awctrl_entry_req_select_retry_flag_q;
```

含义：

```text
new request:
    awctrl_entry_req_select_retry_flag_q = 0
    AllowRetry = 1

retry request:
    awctrl_entry_req_select_retry_flag_q = 1
    AllowRetry = 0
```

### 7.3 S4/S5 保持逻辑

```verilog
assign awctrl_txreqflitv_s4_o =
    awctrl_entry_req_select_success_q
    | (~aw_txreqflit_sent_s5_q & aw_txreqflitv_s5_q);

assign awctrl_txreqflit_s4_o =
    (~aw_txreqflit_sent_s5_q & aw_txreqflitv_s5_q)
    ? aw_txreqflit_s5_q
    : aw_txreqflit_info_r;
```

如果上一拍 S4 有 valid 但没有 sent，则当前拍继续输出 `aw_txreqflit_s5_q`，保证 flit 不丢。

如果上一拍已经 sent，或者上一拍没有 valid，则可以输出新的 `aw_txreqflit_info_r`。

## 8. RXRSP 处理

### 8.1 正确 RXRSP 判断

```verilog
assign aw_rxrsp_correct_w =
    awctrl_rxrspflitv_d1_i
    & awctrl_entry_rxrsp_txnid_w[`CHIE_RSP_FLIT_TXNID_WIDTH-1]
    & (awctrl_entry_rxrsp_tgtid_w == RNI_NID_PARAM);
```

含义：

```text
RXRSP valid
TXNID 最高位为 1，说明这是写请求响应
TgtID 等于本 RNI 节点 ID
```

### 8.2 根据 TXNID 找 entry

```verilog
if(entry == awctrl_entry_rxrsp_txnid_w[`RNI_AW_ENTRIES_WIDTH-1:0])
    awctrl_rxrsp_ptr_r[entry] = 1'b1;
```

RXRSP 的 TXNID 低位就是 AW entry index。

### 8.3 DBID 接收

```verilog
assign rxrsp_dbid_recv_flag_w =
    aw_rxrsp_correct_w
    & ((Opcode == CHIE_COMPDBIDRESP) | (Opcode == CHIE_DBIDRESP));
```

当收到 `DBIDResp` 或 `CompDBIDResp` 时：

```text
rxrsp_dbid_recv_vec_w[entry] = 1
rxrsp_dbid_recv_vec_q[entry] 后续保持为 1
rxrsp_dbidresp_srcid_q[entry] 保存 SrcID
rxrsp_dbidresp_dbid_q[entry] 保存 DBID
```

这些信息后续用于 TXDAT：

```text
awctrl_txdat_tgtid_d2_o = rxrsp_dbidresp_srcid_q[entry]
awctrl_txdat_dbid_d2_o  = rxrsp_dbidresp_dbid_q[entry]
```

### 8.4 Comp 接收

```verilog
assign rxrsp_comp_recv_flag_w =
    aw_rxrsp_correct_w
    & ((Opcode == CHIE_COMPDBIDRESP) | (Opcode == CHIE_COMP));
```

`CompDBIDResp` 既置位 DBID 相关状态，也置位 Comp 相关状态。

`rxrsp_comp_recv_vec_q[entry]` 表示该 entry 已经收到 completion。

### 8.5 RetryAck 接收

```verilog
assign rxrsp_retryack_recv_flag_w =
    aw_rxrsp_correct_w
    & (Opcode == CHIE_RETRYACK);
```

收到 `RetryAck` 时：

```text
rxrsp_retryack_recv_vec_q[entry] 置位
rxrsp_retryack_pcrdtype_q[entry] 保存 PCRDType
awctrl_entry_req_select_vec_q 对应 bit 清掉
```

之后该 entry 不能立即重发 TXREQ，必须等待匹配的 PCRDGrant。

### 8.6 PCRDGrant 匹配

对每个 entry，只有满足以下条件才可能匹配 PCRDGrant：

```text
pcrdgnt_pkt_v_d2_i = 1
rxrsp_retryack_recv_vec_q[entry] = 1
rxrsp_pcrdgrant_recv_vec_q[entry] = 0
当前 ns 也没有已经给它分配 PCRDGrant
```

匹配字段：

```verilog
pcrdgnt_pkt_d2_i[`PCRDGRANT_PKT_PCRDTYPE_RANGE]
    == rxrsp_retryack_pcrdtype_q[entry]

pcrdgnt_pkt_d2_i[`PCRDGRANT_PKT_SRCID_RANGE]
    == aw_tx_send_nid_w

pcrdgnt_pkt_d2_i[`PCRDGRANT_PKT_TGTID_RANGE]
    == RNI_NID_PARAM
```

然后按 QoS 分成：

```text
rxrsp_pcrdgrant_hi_rdy_vec_r
rxrsp_pcrdgrant_lo_rdy_vec_r
```

`pcrdtype_hi_select` 和 `pcrdtype_lo_select` 两个仲裁器分别选择 high/low QoS entry。全局 PCRDGrant 仲裁胜出后：

```text
rxrsp_pcrdgrant_recv_vec_q[entry] = 1
```

该 entry 可以进入 retry TXREQ ready 集合。

## 9. TXDAT 授权设计

### 9.1 TXDAT ready 条件

```verilog
assign txdat_select_rdy_w =
    rxrsp_dbid_recv_vec_q
    & wdata_recv_done_q
    & ~txdat_select_vec_q;
```

一个 entry 可以发送 TXDAT 的条件是：

```text
已经收到 DBID
AXI W 数据已经由 rni_wr_buffer 收齐
该 entry 尚未被 TXDAT select 过
```

其中 `wdata_recv_done_q` 来自：

```verilog
assign wdata_recv_done_ns_w =
    (wdata_recv_done_q
     | ({N{wb_req_done_d3_i}} & wb_req_entry_d3_i))
    & ~awctrl_entry_dealloc_vec_w;
```

`wb_req_done_d3_i` 和 `wb_req_entry_d3_i` 由 `rni_wr_buffer` 的 `rni_bcount_ctl` 产生，表示某个 AW entry 的写数据已经按 `pdmask` 和 `bc_vec` 收齐。

### 9.2 TXDAT entry 仲裁

`txdat_select` 使用 `poll_with_start_entry`：

```verilog
txdat_select(
    .entry_vec     (txdat_select_rdy_w),
    .start_entry   (txdat_select_ptr_q),
    .entry_ptr_sel (txdat_select_vec_w),
    .found         (txdat_select_success_w)
);
```

选择成功还要看 `wb_not_busy_d1_i`：

```verilog
assign txdat_select_entry_two_packets_w =
    wb_not_busy_d1_i
    & txdat_select_success_w
    & |(txdat_select_vec_w & awctrl_entry_two_packets_current_q);

assign txdat_select_new_entry_w =
    wb_not_busy_d1_i
    & txdat_select_success_w
    & ~txdat_select_entry_two_packets_w;
```

`wb_not_busy_d1_i` 表示 `rni_wr_buffer` 当前 TXDAT 通路没有被上一笔 flit 阻塞。

### 9.3 two packets 设计

当前参数通常是：

```text
CHIE_DATA_WIDTH_PARAM = 256 bit = 32B
cache line = 64B
RNI_DMASK_CT_WIDTH = 4，每 bit 代表 16B bank
```

一个 64B segment 最多需要两个 32B TXDAT flit：

```text
低半 cacheline: bank0/bank1
高半 cacheline: bank2/bank3
```

代码用 `pdmask` 判断是否需要两笔 TXDAT：

```verilog
assign txdat_packet_0_s2_w =
    awlink_valid_s2_q
    & |awlink_dmask_s2_w[`RNI_DMASK_PD_LSB + 1:`RNI_DMASK_PD_LSB];

assign txdat_packet_1_s2_w =
    awlink_valid_s2_q
    & |awlink_dmask_s2_w[`RNI_DMASK_PD_LSB + 3:`RNI_DMASK_PD_LSB + 2];

assign txdat_two_packets_s2_w =
    txdat_packet_0_s2_w & txdat_packet_1_s2_w;
```

相关状态：

```text
awctrl_entry_two_packets_flag_q
    记录该 entry 是否原本需要两笔 TXDAT。

awctrl_entry_two_packets_current_q
    记录该 entry 当前是否还处于第一笔/仍需特殊处理的 two-packets 状态。
```

TXDAT 的 `ctmask` 输出：

```verilog
txdat_ctmask_d1_r =
    (awctrl_entry_two_packets_flag_q[i] & ~awctrl_entry_two_packets_current_q[i])
    ? {awctrl_entry_ctmask_q[i][1:0], awctrl_entry_ctmask_q[i][3:2]}
    : awctrl_entry_ctmask_q[i];
```

含义是：

```text
第一笔 TXDAT:
    使用 awctrl_entry_ctmask_q[i]

第二笔 TXDAT:
    使用 {awctrl_entry_ctmask_q[i][1:0], awctrl_entry_ctmask_q[i][3:2]}
    将高低半区选择关系交换，配合 rni_wr_buffer 选择另一半 256-bit 数据。
```

### 9.4 输出给 rni_wr_buffer 的 TXDAT 信息

```verilog
assign awctrl_txdat_rdy_v_d2_o       = txdat_rdy_v_d2_q;
assign awctrl_txdat_rdy_entry_d2_o   = txdat_rdy_entry_d2_q;
assign awctrl_txdat_ctmask_d2_o      = txdat_ctmask_d2_q;
assign awctrl_txdat_ccid_d2_o        = 0;
assign awctrl_txdat_compack_d2_o     = 1'b0;
```

`awctrl_txdat_qos_d2_o` 来自 `awctrl_entry_info_q[i][AXI4_AWQOS_RANGE]`。

`awctrl_txdat_dbid_d2_o` 来自 `rxrsp_dbidresp_dbid_q[i]`。

`awctrl_txdat_tgtid_d2_o` 来自 `rxrsp_dbidresp_srcid_q[i]`。

`rni_wr_buffer` 后续将这些信息拼成 TXDAT：

```text
TXDAT Opcode = CHIE_NONCOPYBACKWRDATA
TXDAT TgtID  = awctrl_txdat_tgtid_d2_o
TXDAT TxnID  = awctrl_txdat_dbid_d2_o
TXDAT DBID   = {write标志1, entry index}
TXDAT DataID = 2'b00 或 2'b10
TXDAT Data   = 写数据 bank
TXDAT BE     = WSTRB 生成的 byte enable
```

当前 `awctrl_txdat_compack_d2_o` 固定为 0，所以 `rni_wr_buffer` 不会用 `CHIE_NCBWRDATACOMPACK`，CompAck 由 `rni_awctrl` 的 TXRSP 路径单独发送。

### 9.5 txdat_send_vec_q

```verilog
assign txdat_send_vec_ns_w =
    (txdat_send_vec_q
     | ({N{awctrl_txdat_not_busy_d2_i}}
        & txdat_rdy_entry_d3_q
        & txdat_select_vec_d3_q))
    & ~awctrl_entry_dealloc_vec_w;
```

`txdat_send_vec_q[entry]` 表示该 entry 至少有一笔 TXDAT 已经被 `rni_wr_buffer` 接收并进入发送路径。

它是后续 B response ready 的必要条件之一。

## 10. TXRSP CompAck 设计

### 10.1 CompAck ready 条件

```verilog
assign txrsp_select_rdy_w =
    txdat_send_vec_q
    & rxrsp_comp_recv_vec_q
    & ~awctrl_entry_compack_dep_v_q
    & awctrl_entry_expcompack_q
    & ~txrsp_select_vec_q;
```

一个 entry 可以发送 CompAck 的条件是：

```text
TXDAT 已经发送过
已经收到 Comp
没有 compack chain 依赖
该 entry 的 TXREQ 设置了 ExpCompAck
尚未被 TXRSP select
```

`~awctrl_entry_compack_dep_v_q` 是 compack chain 真正约束 CompAck 顺序的位置。

### 10.2 CompAck flit 字段

`aw_txrspflit_info_r` 生成 `CHIE_COMPACK`：

```text
TGTID  : HNF_NID_PARAM
SRCID  : RNI_NID_PARAM
TXNID  : rxrsp_dbidresp_dbid_q[i]
Opcode : CHIE_COMPACK
QOS    : AWQOS
```

这里 `TXNID` 使用前面 DBIDResp 返回的 DBID。

### 10.3 TXRSP 保持逻辑

```verilog
assign awctrl_txrspflitv_d0_o =
    txrsp_select_success_flag_q
    | (aw_txrspflitv_d0_q & ~aw_txrspflit_sent_d0_q);

assign awctrl_txrspflit_d0_o =
    (aw_txrspflitv_d0_q & ~aw_txrspflit_sent_d0_q)
    ? aw_txrspflit_d0_q
    : aw_txrspflit_info_r;
```

如果上一拍 CompAck valid 但没有 sent，则当前拍继续保持上一拍 flit。

### 10.4 CompAck 发送完成记录

```verilog
assign txrsp_compack_send_vec_ns_w =
    (txrsp_compack_send_vec_q
     | (txrsp_select_ptr_q & {N{awctrl_txrspflitv_d0_o & awctrl_txrspflit_sent_d0_i}}))
    & ~awctrl_entry_dealloc_vec_w;
```

`txrsp_compack_send_vec_q[entry]` 表示该 entry 的 CompAck 已经发送完成。

它同时用于：

```text
1. 清理 compack chain
2. 允许后续 B response 调度
```

## 11. B response 调度设计

### 11.1 B response ready 条件

```verilog
assign bresp_select_rdy_w =
    awctrl_entry_v_q
    & rxrsp_comp_recv_vec_q
    & txdat_send_vec_q
    & (txrsp_compack_send_vec_q | ~awctrl_entry_expcompack_q)
    & ~awctrl_entry_bresp_dep_v_q
    & ~bresp_select_vec_q;
```

一个 entry 可以产生 B response 调度项的条件是：

```text
entry 有效
已经收到 Comp
TXDAT 已经发送
如果需要 CompAck，则 CompAck 已经发送
如果不需要 CompAck，则无需等待 CompAck
没有 bresp chain 依赖
尚未被 B response select
```

`~awctrl_entry_bresp_dep_v_q` 是 bresp chain 真正约束 AXI B response 顺序的位置。

### 11.2 B response 仲裁与 credit FIFO

`bresp_select` 仲裁出一个 entry：

```verilog
bresp_select(
    .entry_vec     (bresp_select_rdy_w),
    .start_entry   (bresp_select_ptr_q),
    .entry_ptr_sel (bresp_select_vec_w),
    .found         (bresp_select_success_w)
);
```

为了和 `rni_wr_buffer` 的 B response FIFO 解耦，`rni_awctrl` 内部还有：

```verilog
sync_fifo bresp_credit(...)
```

它保存的是 `bresp_select_vec_w`，也就是被调度的 entry one-hot。

`bresp_credit_avail_w = !bresp_credit_full_w`，只有 credit FIFO 未满时才允许新 B response 调度。

### 11.3 输出给 rni_wr_buffer

```verilog
assign awctrl_brsp_rdy_v_d2_o    = brsp_rdy_v_d2_q;
assign awctrl_brsp_last_v_d2_o   = brsp_last_v_d2_q;
assign awctrl_brsp_axid_d2_o     = brsp_axid_d2_q;
assign awctrl_brsp_resperr_d2_o  = 0;
```

`brsp_last_v_d2_q` 来自：

```verilog
brsp_last_v_d2_ns_r =
    |(bresp_select_vec_w[i] & awctrl_entry_segburst_last_q[i]);
```

如果当前 entry 是原始 AXI AW burst 的最后一个 segment，才会最终对 AXI 输出 BVALID。

`brsp_axid_d2_q` 来自：

```text
awctrl_entry_info_q[i][AXI4_AWID_RANGE]
```

### 11.4 rni_wr_buffer 中的 B 输出策略

`rni_wr_buffer` 接收 `awctrl_brsp_*` 后放入 `brsp_fifo`。

它的 pop 逻辑是：

```verilog
assign wb_brsp_fifo_pop_d3_o =
    (~brsp_fifo_empty_w & ~brsp_fifo_out_d3_w[`BRSP_FIFO_LAST_RANGE])
    | (BVALID0 & BREADY0);
```

含义：

```text
如果不是最后 segment:
    brsp_fifo 自动 pop，不对 AXI 输出 BVALID。

如果是最后 segment:
    BVALID0 拉高，等待 BREADY0 握手后 pop。
```

因此 `rni_awctrl` 可以对每个 segment 产生 B response 调度项，但 AXI 侧只在原始 burst 最后 segment 返回一次 B。

### 11.5 entry 释放

entry 释放由：

```verilog
assign awctrl_entry_dealloc_vec_w =
    {N{awctrl_brsp_fifo_pop_d3_i}} & bresp_send_ptr_w;
```

其中：

```text
awctrl_brsp_fifo_pop_d3_i
    来自 rni_wr_buffer，表示它已经消费一个 B response 调度项。

bresp_send_ptr_w
    来自 awctrl 内部 bresp_credit FIFO，表示被消费的是哪个 entry。
```

释放后：

```text
awctrl_entry_v_q 对应 bit 清零
三套 chain 中和该 entry 相关的状态按各自逻辑清理
rxrsp_dbid_recv_vec_q / rxrsp_comp_recv_vec_q / retry/pcrdgrant 状态清理
wdata_recv_done_q / txdat_select_vec_q / txdat_send_vec_q 清理
```

## 12. 典型事务流程

### 12.1 无 Retry，普通写事务

一个普通写事务大致经历：

```text
1. AXI AWVALID0 & AWREADY0
   AW 被 rni_awlink 接收。

2. rni_segburst 输出 awlink_valid_s1_w
   当前 AW burst 被拆成一个或多个 segment。

3. awctrl_alloc_ptr_s1_w 分配 entry
   awctrl_entry_info_q / addr / len / qos / last 等保存。

4. S2 输出 awctrl_alloc_valid_s2_o
   rni_wr_buffer 收到 entry、ctmask、pdmask、bc_vec。

5. TXREQ 仲裁
   如果没有 awctrl_entry_req_dep_v_q 依赖，entry 进入 awctrl_req_new_rdy_w。

6. awctrl_txreqflit_s4_o 发送 CHIE_WRITEUNIQUEPTL
   TXNID = {1'b1, entry index}。

7. CHI 返回 DBIDResp
   rxrsp_dbid_recv_vec_q[entry] = 1，保存 DBID 和 SrcID。

8. rni_wr_buffer 收齐 WDATA
   wb_req_done_d3_i = 1，wdata_recv_done_q[entry] = 1。

9. TXDAT 仲裁
   txdat_select_rdy_w[entry] = 1，awctrl_txdat_rdy_* 输出给 rni_wr_buffer。

10. rni_wr_buffer 发送 TXDAT
    txdat_send_vec_q[entry] 置位。

11. CHI 返回 Comp
    rxrsp_comp_recv_vec_q[entry] = 1。

12. 如果 awctrl_entry_expcompack_q[entry] = 1
    发送 TXRSP CompAck。

13. B response 仲裁
    bresp_select_rdy_w[entry] = 1。

14. rni_wr_buffer 消费 B response 调度项
    awctrl_entry_dealloc_vec_w[entry] = 1，entry 释放。
```

### 12.2 Retry 流程

如果 TXREQ 之后收到 `RetryAck`：

```text
1. rxrsp_retryack_recv_vec_q[entry] = 1
2. rxrsp_retryack_pcrdtype_q[entry] 保存 PCRDType
3. awctrl_entry_req_select_vec_q[entry] 被清掉
4. entry 不再走 new request ready
5. 等待 PCRDGrant 匹配
6. rxrsp_pcrdgrant_recv_vec_q[entry] = 1
7. entry 进入 awctrl_req_retry_ready_w
8. 重新发送 TXREQ，AllowRetry=0，PCRDType 使用 RetryAck 保存值
```

### 12.3 同 AWID 的顺序例子

假设同一个 `AWID` 连续产生三个 entry：

```text
entry0 -> entry1 -> entry2
```

request chain 中：

```text
entry1 的 awctrl_entry_req_dep_v_q = 1，依赖 entry0
entry2 的 awctrl_entry_req_dep_v_q = 1，依赖 entry1
```

当 `entry0` 收到 DBID：

```text
rxrsp_dbid_recv_vec_w[entry0] = 1
awctrl_entry_is_req_dep_num_q[entry0] 指向 entry1
entry1 的 request dep 被清掉
entry1 可以参与 TXREQ new 仲裁
```

当 `entry1` 收到 DBID 后，`entry2` 才能参与 TXREQ new 仲裁。

bresp chain 的清除更晚。即使 `entry1` 比 `entry0` 更早完成 Comp 和 TXDAT，它也不能先返回 AXI B response，必须等 `entry0` dealloc 后才能清除 `entry1` 的 bresp dep。

## 13. 与 rni_awlink 的关系

`rni_awlink` 的核心职责是：

```text
1. 使用 AW FIFO 接收 AXI AW
2. 调用 rni_segburst 拆分 AXI burst
3. 输出 awlink_valid_s1_o / awlink_addr_s1_o / awlink_done_s1_o
4. 输出 awlink_bc_vec_s2_o / awlink_dmask_s2_o / awlink_size_s2_o
```

`rni_awctrl` 不直接解析 AXI burst 的地址递增和边界拆分，它消费的是 `rni_awlink` 已经拆好的 segment。

## 14. 与 rni_wr_buffer 的关系

`rni_awctrl` 和 `rni_wr_buffer` 是写路径的两个半边：

```text
rni_awctrl:
    管控制、顺序、DBID、Comp、Retry、CompAck、B response 调度。

rni_wr_buffer:
    管 WDATA 存储、WSTRB/BE、TXDAT 数据拼接、TXDAT link 发送握手、AXI B 输出。
```

关键交互：

```text
awctrl_alloc_valid_s2_o / awctrl_alloc_entry_s2_o
    awctrl 告诉 wr_buffer 新 entry 分配。

awctrl_ctmask_s2_o / awctrl_pdmask_s2_o / awctrl_bc_vec_s2_o
    awctrl 告诉 wr_buffer 当前 segment 需要收哪些数据 bank，以及每个 bank 对应多少 AXI beat。

wb_req_done_d3_i / wb_req_entry_d3_i
    wr_buffer 告诉 awctrl 某个 entry 的 WDATA 已收齐。

awctrl_txdat_rdy_*_o
    awctrl 授权 wr_buffer 发送某个 entry 的 TXDAT。

awctrl_txdat_not_busy_d2_i / wb_not_busy_d1_i
    wr_buffer 告诉 awctrl TXDAT 输出通路是否可以接收新授权。

awctrl_brsp_*_o
    awctrl 给 wr_buffer 一个 B response 调度项。

awctrl_brsp_fifo_pop_d3_i
    wr_buffer 告诉 awctrl 某个 B response 调度项已消费，可释放 entry。
```

## 15. 与 rni_arctrl 的主要区别

`rni_awctrl` 和 `rni_arctrl` 都有：

```text
entry 池
segburst segment 接收
request chain
TXREQ 仲裁
RetryAck / PCRDGrant 处理
TXREQ S4/S5 保持逻辑
```

但 `rni_awctrl` 比 `rni_arctrl` 多了写事务特有的内容：

```text
1. 需要和 rni_wr_buffer 协同收集 AXI WDATA
2. 需要等待 DBID 后才能发送 TXDAT
3. 需要处理 Comp / CompDBIDResp
4. 可能需要发送 TXRSP CompAck
5. 需要产生 AXI B response 调度
6. 需要 bresp chain 保证同 AWID 的 B response 顺序
7. 需要 compack chain 保证 CompAck 顺序
```

读路径的 `rni_arctrl` 重点是 RXDAT 收齐后返回 AXI RDATA；写路径的 `rni_awctrl` 重点是 AW 控制、WDATA 授权、DBID/Comp/CompAck/B response 的多阶段同步。

## 16. 需要特别注意的设计点

### 16.1 `awctrl_entry_req_select_rdy_q` 是 entry valid 的打一拍

TXREQ ready 中同时使用：

```verilog
awctrl_entry_v_q & awctrl_entry_req_select_rdy_q
```

这让新分配 entry 不会在刚 valid 的同一拍立即进入 TXREQ 仲裁，给 entry 信息保存和链路判断留出时序边界。

### 16.2 `awctrl_entry_req_select_vec_q` 不是完成标志

`awctrl_entry_req_select_vec_q[entry] = 1` 表示 TXREQ 已经被 select 过，防止重复发 new request。

它不是事务完成标志。收到 `RetryAck` 会清掉该 bit，以允许后续 retry。

### 16.3 `rxrsp_dbid_recv_vec_q` 和 `rxrsp_comp_recv_vec_q` 是两个独立阶段

写事务可能先收到 DBID，再收到 Comp；也可能收到 `CompDBIDResp` 同时满足二者。

因此代码分开维护：

```text
rxrsp_dbid_recv_vec_q
rxrsp_comp_recv_vec_q
```

TXDAT 需要 DBID；B response 需要 Comp。

### 16.4 `txdat_send_vec_q` 表示 TXDAT 已进入发送路径

`txdat_send_vec_q` 不是 DBID，也不是 WDATA done，而是 awctrl 授权后，wr_buffer TXDAT 通路接受了该 entry 的标记。

B response 需要：

```text
rxrsp_comp_recv_vec_q & txdat_send_vec_q
```

### 16.5 `awctrl_entry_expcompack_q` 由 compack chain 决定

当前代码：

```verilog
assign aw_txreq_expcompack_w = awctrl_new_entry_compack_dep_w;
```

如果新 entry 和已有同 AWID entry 建立 compack chain，则新 entry 的 TXREQ 会设置 `ExpCompAck`。

这说明当前设计不是所有写请求都发 CompAck，而是在链路顺序需要时才打开 ExpCompAck。

### 16.6 当前 B response error 固定为 0

`awctrl_brsp_resperr_d2_o` 当前固定清零。也就是说，即使 CHI RSP 中可能携带错误信息，本模块当前没有把错误传播到 AXI BRESP。

### 16.7 TXDAT CompAck 当前固定关闭

`awctrl_txdat_compack_d2_o` 当前为 0。`rni_wr_buffer` 虽然支持根据 `txdat_compack_d3_q` 选择 `CHIE_NCBWRDATACOMPACK`，但在当前连接下不会使用这条合并路径。

CompAck 由 `rni_awctrl` 的 TXRSP `CHIE_COMPACK` 单独发送。

## 17. 一句话总结

`rni_awctrl` 的设计思想是：把每个 AW segment 放入 32 个 AW entry 中，用三套同 AWID 依赖链分别约束 TXREQ、CompAck 和 AXI B response 的顺序；同时跟踪 DBID、Comp、Retry/PCRDGrant、WDATA done 和 TXDAT send 状态，最终在所有写事务条件满足后调度 B response 并释放 entry。
