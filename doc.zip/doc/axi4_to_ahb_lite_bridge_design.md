# AXI4 to AHB-Lite Bridge 详细设计文档

本文档对应当前工程中的两个 RTL 文件：

```text
rtl/axi2ahb_bridge/axi4_to_ahb_lite_bridge.v
rtl/axi2ahb_bridge/axi4_to_ahb_lite_fifo.v
```

配套 testbench：

```text
sim/tb_axi4_to_ahb_lite_bridge.sv
```

这个模块的目标是：把一个 AXI4 slave 接口桥接到一个 AHB-Lite master 接口。AXI 侧支持 burst 传输、独立读写地址通道、独立写数据通道和响应通道；AHB-Lite 侧是单 master、单线程、顺序执行的总线接口。因此这个 bridge 的核心工作就是：

```text
AXI 侧多通道请求
    -> 入口 FIFO 缓冲
    -> 单线程 AHB-Lite executor 串行执行
    -> AXI B/R 响应恢复
```

## 1. 总体定位

从协议关系看：

```text
AXI4 master
    |
    | AW/W/B/AR/R
    v
axi4_to_ahb_lite_bridge
    |
    | HADDR/HTRANS/HWRITE/HSIZE/HBURST/HWDATA/HRDATA/HREADY/HRESP
    v
AHB-Lite slave
```

当前 bridge 不是一个高并发 AXI fabric，而是一个协议转换器。它的特点是：

```text
AXI 入口侧有 AW/AR/W FIFO，可以吸收上游请求
AHB-Lite 出口侧一次只执行一个 burst
响应顺序严格串行，不支持乱序完成
```

所以它支持“入口排队”，但不支持真正意义上的多 outstanding 并行执行。

## 2. 当前支持能力

当前 RTL 支持：

```text
AXI4 AW/W/B/AR/R 基本握手
AW/AR/W 入口 FIFO 缓冲
AXI INCR burst
AXI WRAP burst，合法长度 4/8/16 beat
AXI FIXED burst 地址保持
最大 AXI burst 长度 256 beat
AXI ID 保存与 B/R 响应 ID 恢复
4KB 边界检测
读请求非法时返回 DECERR R burst
写请求非法时 drain 掉 W burst 后返回 DECERR B response
AHB-Lite NONSEQ/SEQ 访问
AHB HRESP 到 AXI SLVERR 的转换
WSTRB partial write 到 AHB byte write 的拆分
```

当前 RTL 不支持：

```text
真正多 outstanding 并行执行
读写同时进入 AHB executor
AXI 响应乱序返回
AXI write interleaving
AXI 属性信号完整透传，例如 AWPROT/ARPROT/AWCACHE/ARCACHE
AXI 和 AHB 数据宽度转换
跨时钟域
exclusive/locked transaction
```

## 3. 参数说明

```verilog
parameter AXI_ID_WIDTH = 8;
parameter ADDR_WIDTH = 32;
parameter DATA_WIDTH = 32;
parameter MAX_BURST_LEN = 256;
parameter REQ_BUFFER_DEPTH = 2;
parameter W_BUFFER_DEPTH = MAX_BURST_LEN*2;
```

| 参数 | 作用 |
| --- | --- |
| `AXI_ID_WIDTH` | AXI ID 宽度，用于保存 AWID/ARID 并在 BID/RID 中恢复 |
| `ADDR_WIDTH` | AXI 和 AHB 地址宽度 |
| `DATA_WIDTH` | AXI 和 AHB 数据宽度 |
| `MAX_BURST_LEN` | 内部读写 buffer 深度，AXI4 最大 256 beat |
| `REQ_BUFFER_DEPTH` | AW/AR 请求 FIFO 深度 |
| `W_BUFFER_DEPTH` | W 数据 FIFO 深度，默认可以缓存两个最大长度 burst |

内部派生参数：

```verilog
localparam STRB_WIDTH = DATA_WIDTH/8;
localparam SIZE_WIDTH = (STRB_WIDTH <= 1) ? 1 : $clog2(STRB_WIDTH);
localparam REQ_WIDTH = AXI_ID_WIDTH + ADDR_WIDTH + 8 + 3 + 2;
localparam W_FIFO_WIDTH = DATA_WIDTH + STRB_WIDTH + 1;
```

其中：

```text
REQ_WIDTH    = ID + ADDR + LEN + SIZE + BURST
W_FIFO_WIDTH = WDATA + WSTRB + WLAST
```

## 4. 顶层架构

可以把 bridge 分成 6 个部分：

```text
1. AXI ingress FIFO
2. active request register
3. write data collector
4. AHB-Lite executor
5. read data buffer
6. AXI response generator
```

结构图：

```text
AXI AW  ---> aw_req_fifo ---+
                            |
AXI AR  ---> ar_req_fifo ---+--> active request register
                            |
AXI W   ---> w_data_fifo ---+--> write data collector

active request
    |
    +--> write path --> AHB write executor --> AXI B response
    |
    +--> read path  --> AHB read executor  --> read data buffer --> AXI R response
```

关键设计思想：

```text
AXI 入口用 FIFO 解耦
AHB 后端保持单线程
读写响应在 AXI 侧重新组装
```

## 5. 入口 FIFO 设计

入口 FIFO 模块是：

```verilog
axi4_to_ahb_lite_fifo
```

它是一个同步 ready/valid FIFO，接口为：

```verilog
input  wire [WIDTH-1:0] in_data;
input  wire             in_valid;
output wire             in_ready;

output wire [WIDTH-1:0] out_data;
output wire             out_valid;
input  wire             out_ready;
```

握手规则：

```text
push = in_valid  && in_ready
pop  = out_valid && out_ready
```

内部核心寄存器：

```verilog
reg [WIDTH-1:0]     mem [0:DEPTH-1];
reg [PTR_WIDTH-1:0] wr_ptr_reg;
reg [PTR_WIDTH-1:0] rd_ptr_reg;
reg [CNT_WIDTH-1:0] count_reg;
```

含义：

```text
mem         保存 FIFO entry
wr_ptr_reg  指向下一次写入位置
rd_ptr_reg  指向当前读出位置
count_reg   当前 FIFO 内 entry 数量
```

满空判断：

```verilog
assign in_ready  = (count_reg < CNT_DEPTH);
assign out_valid = (count_reg != CNT_ZERO);
```

也就是说：

```text
FIFO 未满 -> 可以继续接收输入
FIFO 非空 -> 可以向内部状态机输出数据
```

在 bridge 中实例化了三个 FIFO：

```verilog
aw_req_fifo
ar_req_fifo
w_data_fifo
```

打包格式：

```verilog
assign aw_fifo_in_data = {s_axi_awid, s_axi_awaddr, s_axi_awlen, s_axi_awsize, s_axi_awburst};
assign ar_fifo_in_data = {s_axi_arid, s_axi_araddr, s_axi_arlen, s_axi_arsize, s_axi_arburst};
assign w_fifo_in_data  = {s_axi_wdata, s_axi_wstrb, s_axi_wlast};
```

AXI ready 直接由 FIFO 空间决定：

```verilog
assign s_axi_awready = aw_fifo_ready;
assign s_axi_arready = ar_fifo_ready;
assign s_axi_wready  = w_fifo_ready;
```

这就是 buffer 的核心意义：即使 AHB-Lite executor 正在忙，只要 FIFO 没满，AXI 上游仍然可以继续提交 AW/AR/W。

## 6. active request 寄存器

状态机真正开始执行一个请求时，会从 AW FIFO 或 AR FIFO 取出 entry，保存到 active request 寄存器中：

```verilog
active_id_reg
active_addr_reg
active_len_reg
active_size_reg
active_burst_reg
```

它们分别表示：

| 寄存器 | 作用 |
| --- | --- |
| `active_id_reg` | 当前 burst 的 AXI ID |
| `active_addr_reg` | 当前 burst 起始地址 |
| `active_len_reg` | 当前 burst 长度，AXI LEN 编码，实际 beat 数为 LEN+1 |
| `active_size_reg` | 每 beat 传输大小 |
| `active_burst_reg` | burst 类型，FIXED/INCR/WRAP |

取请求时，写请求优先：

```verilog
assign aw_fifo_pop = (state_reg == ST_IDLE) && aw_fifo_valid;
assign ar_fifo_pop = (state_reg == ST_IDLE) && !aw_fifo_valid && ar_fifo_valid;
```

也就是说：

```text
ST_IDLE 时如果 AW FIFO 非空，先处理写
只有 AW FIFO 为空时，才处理 AR FIFO
```

这是一个简单固定优先级策略。它容易实现，但如果写请求持续很多，读请求可能被推迟。后续可以改成 round-robin。

## 7. 主状态机

状态定义：

```verilog
localparam ST_IDLE         = 4'd0;
localparam ST_WR_RECV      = 4'd1;
localparam ST_WR_DRAIN     = 4'd2;
localparam ST_WR_AHB       = 4'd3;
localparam ST_WR_PART_ADDR = 4'd4;
localparam ST_WR_PART_DATA = 4'd5;
localparam ST_WR_RESP      = 4'd6;
localparam ST_RD_AHB       = 4'd7;
localparam ST_RD_RESP      = 4'd8;
localparam ST_RD_DECERR    = 4'd9;
```

各状态作用：

| 状态 | 作用 |
| --- | --- |
| `ST_IDLE` | 空闲，从 AW/AR FIFO 取下一笔请求 |
| `ST_WR_RECV` | 正常写请求，接收并缓存完整 AXI W burst |
| `ST_WR_DRAIN` | 写地址非法，丢弃对应 W burst，等 WLAST 后返回错误 |
| `ST_WR_AHB` | full-width/full-strobe 写请求，向 AHB-Lite 发起 burst 写 |
| `ST_WR_PART_ADDR` | partial write 拆分后的 AHB byte 写地址 phase |
| `ST_WR_PART_DATA` | partial write 拆分后的 AHB byte 写数据/响应 phase |
| `ST_WR_RESP` | 返回 AXI B 通道写响应 |
| `ST_RD_AHB` | 向 AHB-Lite 发起读 burst，并缓存 HRDATA/HRESP |
| `ST_RD_RESP` | 将缓存的读数据通过 AXI R 通道逐拍返回 |
| `ST_RD_DECERR` | 读地址非法，不访问 AHB，直接返回 DECERR R burst |

整体状态流：

```text
写正常路径：
ST_IDLE -> ST_WR_RECV -> ST_WR_AHB/ST_WR_PART_ADDR -> ST_WR_RESP -> ST_IDLE

写非法路径：
ST_IDLE -> ST_WR_DRAIN -> ST_WR_RESP -> ST_IDLE

读正常路径：
ST_IDLE -> ST_RD_AHB -> ST_RD_RESP -> ST_IDLE

读非法路径：
ST_IDLE -> ST_RD_DECERR -> ST_IDLE
```

## 8. 写通路设计

### 8.1 AW 接收

AW 通道先进入 `aw_req_fifo`。主状态机在 `ST_IDLE` 中看到 `aw_fifo_valid` 后，取出 AW entry，保存到 active request。

然后调用：

```verilog
invalid_request(...)
```

判断请求是否合法。

如果合法：

```text
进入 ST_WR_RECV
```

如果非法：

```text
进入 ST_WR_DRAIN
```

### 8.2 W 接收

W 通道先进入 `w_data_fifo`。进入 `ST_WR_RECV` 后，状态机从 W FIFO 中逐拍取出数据，写入内部 burst buffer：

```verilog
wdata_buf[recv_count_reg] <= w_fifo_data;
wstrb_buf[recv_count_reg] <= w_fifo_strb;
```

同时统计是否所有 beat 都是 full strobe：

```verilog
all_full_strobe_reg <= all_full_strobe_reg && (w_fifo_strb == {STRB_WIDTH{1'b1}});
```

当收到最后一拍：

```text
如果 WLAST 与 AWLEN 不匹配 -> DECERR
如果 full-width/full-strobe -> ST_WR_AHB
否则 -> partial write 拆分路径
```

### 8.3 full write 路径

如果满足：

```text
所有 WSTRB 都是全 1
AXI SIZE 等于总线宽度
```

则可以直接映射为 AHB burst 写：

```text
ST_WR_AHB
```

AHB 地址 phase：

```text
第 0 拍 HTRANS = NONSEQ
后续拍 HTRANS = SEQ
```

写数据通过：

```verilog
m_ahb_hwdata = wdata_buf[ahb_data_index_reg];
```

AHB 写完成后，收集 `HRESP`：

```text
HRESP = 0 -> OKAY
HRESP = 1 -> SLVERR
```

最后返回 AXI B response。

### 8.4 partial write 路径

AHB-Lite 没有 AXI `WSTRB` 对应信号。如果 AXI 写不是 full strobe，不能直接做 word 写，否则会覆盖不该写的 byte。

因此当前设计把 partial write 拆成 byte write：

```text
遍历 WSTRB
每个置 1 的 byte lane 发起一次 AHB byte write
WSTRB 为 0 的 byte lane 不访问 AHB
```

相关状态：

```text
ST_WR_PART_ADDR
ST_WR_PART_DATA
```

相关函数：

```verilog
next_strb_lane(...)
```

它负责从当前 lane 开始查找下一个置位的 WSTRB bit。

例子：

```text
AXI WDATA = 32'hAABB_CCDD
WSTRB    = 4'b0101
ADDR     = 0x200
```

实际 AHB 访问：

```text
byte write addr 0x200, data DD
byte write addr 0x202, data BB
```

## 9. 读通路设计

AR 通道先进入 `ar_req_fifo`。主状态机在 `ST_IDLE` 且 AW FIFO 为空时，取出 AR entry。

如果请求非法：

```text
ST_RD_DECERR
```

直接返回 `ARLEN+1` 拍 AXI R response：

```text
RDATA = 0
RRESP = DECERR
RLAST 在最后一拍拉高
```

如果请求合法：

```text
ST_RD_AHB
```

读 AHB 时，状态机会发出地址 phase，并在数据 phase 保存：

```verilog
rdata_buf[ahb_data_index_reg] <= m_ahb_hrdata;
rresp_buf[ahb_data_index_reg] <= m_ahb_hresp ? AXI_RESP_SLVERR : AXI_RESP_OKAY;
```

AHB 读 burst 全部完成后：

```text
进入 ST_RD_RESP
```

再通过 AXI R 通道逐拍返回：

```verilog
s_axi_rdata = rdata_buf[resp_index_reg];
s_axi_rresp = rresp_buf[resp_index_reg];
s_axi_rlast = (resp_index_reg == active_len_reg);
```

当前设计是“先读完 AHB，再返回 AXI R”，控制简单，但读延迟较高。

## 10. Burst 地址生成

地址生成函数：

```verilog
calc_burst_addr(base_addr, beat, size, burst, len)
```

支持三种 AXI burst：

### 10.1 FIXED

```text
每拍地址都等于 base_addr
```

### 10.2 INCR

```text
beat_bytes = 1 << size
addr = base_addr + beat * beat_bytes
```

### 10.3 WRAP

```text
wrap_bytes = beat_bytes * (len + 1)
wrap_mask  = wrap_bytes - 1
wrap_base  = base_addr & ~wrap_mask
linear     = base_addr + beat * beat_bytes
addr       = wrap_base | (linear & wrap_mask)
```

WRAP 合法长度只允许：

```text
4 beat
8 beat
16 beat
```

也就是 AXI LEN：

```text
3
7
15
```

## 11. AXI burst 到 AHB HBURST 映射

映射函数：

```verilog
map_ahb_burst(burst, len)
```

映射关系：

| AXI burst | AXI LEN | AHB HBURST |
| --- | --- | --- |
| 任意 | 0 | `SINGLE` |
| `INCR` | 3 | `INCR4` |
| `INCR` | 7 | `INCR8` |
| `INCR` | 15 | `INCR16` |
| `INCR` | 其他 | `INCR` |
| `WRAP` | 3 | `WRAP4` |
| `WRAP` | 7 | `WRAP8` |
| `WRAP` | 15 | `WRAP16` |
| `FIXED` | 任意 | `SINGLE` 或默认单地址访问语义 |

## 12. AHB-Lite 信号生成

### 12.1 HADDR

普通 burst：

```verilog
m_ahb_haddr = ahb_burst_addr;
```

partial write：

```verilog
m_ahb_haddr = part_base_addr + part_lane_reg;
```

### 12.2 HTRANS

```verilog
assign m_ahb_htrans = ahb_addr_valid ?
                      ((ahb_addr_index_reg == 0) ? HTRANS_NONSEQ : HTRANS_SEQ) :
                      ((state_reg == ST_WR_PART_ADDR) ? HTRANS_NONSEQ : HTRANS_IDLE);
```

含义：

```text
burst 第 0 拍地址 phase -> NONSEQ
burst 后续地址 phase    -> SEQ
partial byte write      -> NONSEQ
无传输                  -> IDLE
```

### 12.3 HWRITE

写相关状态拉高：

```verilog
ST_WR_AHB
ST_WR_PART_ADDR
ST_WR_PART_DATA
```

其他状态为读或空闲。

### 12.4 HSIZE

普通读写：

```text
HSIZE = active_size_reg
```

partial write：

```text
HSIZE = 3'd0
```

也就是 byte transfer。

### 12.5 HPROT 和 HMASTLOCK

当前固定：

```verilog
assign m_ahb_hprot = 4'b0011;
assign m_ahb_hmastlock = 1'b0;
```

含义：

```text
HPROT 固定为默认数据访问/特权访问属性
HMASTLOCK 固定为 0，不发起 locked transfer
```

## 13. 错误处理

请求合法性检查由：

```verilog
invalid_request(...)
```

完成。

当前判错条件：

```text
burst == 2'b11
size 超过总线宽度
WRAP 长度不是 4/8/16 beat
burst 跨越 4KB 边界
```

写请求非法：

```text
ST_WR_DRAIN
继续接收/丢弃对应 W burst
等 WLAST 后进入 ST_WR_RESP
BRESP = DECERR
```

为什么要 drain W？

```text
AXI 写响应不能在对应 W burst 结束前随意提前返回
否则上游仍然在发送 W，bridge 却已经认为事务完成，会破坏协议关系
```

读请求非法：

```text
ST_RD_DECERR
不访问 AHB
返回 ARLEN+1 拍 DECERR R response
```

AHB 访问期间出错：

```text
HRESP = 1
写 -> BRESP SLVERR
读 -> 对应 RRESP SLVERR
```

## 14. Buffer 的作用

这个 bridge 的前后端吞吐并不总是一样。

AXI 入口侧：

```text
AW 可以一拍提交
W 可以连续每拍一个 beat
AR 可以独立提交
```

AHB-Lite 出口侧：

```text
只有一个 executor
读写不能并行进入 AHB
HREADY 可以插 wait state
partial write 可能一个 AXI beat 拆成多个 AHB byte write
```

因此需要入口 buffer 吸收速率差：

```text
AXI 上游快
AHB 下游慢
FIFO 暂存请求和数据
```

当前 TB 中有一个专门体现 buffer 作用的混合读写场景：

```text
TEST: ingress buffers queue read and write while AHB executor is busy
```

场景设计：

```text
1. 打开 ahb_slow_mode，让 HREADY 周期性为 0
2. 发一笔 16-beat 写，使 bridge 进入 ST_WR_AHB
3. AHB executor 正忙时，继续发送一笔 AR
4. 再发送下一笔 AW 和 4 拍 W
5. 此时 AHB 仍在执行第一笔写，但 FIFO 已经接住后续读写请求
```

仿真输出中可以看到：

```text
BUFFER_DEMO_RW_BUFFERED: slow AHB still busy, state=3 aw_cnt=1 ar_cnt=1 w_cnt=4 buffered_w_beats=4
```

这说明：

```text
state=3  -> bridge 仍在 ST_WR_AHB，后端 AHB executor 忙
aw_cnt=1 -> 后续写地址已经进入 AW FIFO
ar_cnt=1 -> 后续读地址已经进入 AR FIFO
w_cnt=4  -> 后续 4 拍写数据已经进入 W FIFO
```

这就是 buffer 的价值：虽然后端是单线程，但前端还能继续接收 AXI 多通道请求，减少上游 backpressure。

## 15. 为什么不是多 outstanding

虽然 AW/AR/W FIFO 可以排队多个请求，但当前 bridge 仍不是真正多 outstanding。

原因是：

```text
同一时刻只有一个 active request
AHB-Lite executor 一次只执行一个 burst
B/R response 也按执行顺序返回
```

所以更准确的能力描述是：

```text
支持入口请求排队
支持 AXI 前端与 AHB 后端解耦
不支持多个 AHB 事务同时在飞
不支持乱序完成
```

## 16. 学习阅读路线

建议按下面顺序读代码：

```text
1. 先看端口，理解 AXI slave 和 AHB-Lite master 的方向
2. 看三个 FIFO 的打包/解包
3. 看 ready 信号如何由 FIFO ready 产生
4. 看 ST_IDLE 如何从 AW/AR FIFO 选择请求
5. 看 ST_WR_RECV 如何从 W FIFO 收集完整 burst
6. 看 ST_WR_AHB 如何产生 AHB 写 burst
7. 看 ST_RD_AHB 如何产生 AHB 读 burst
8. 看 ST_WR_RESP/ST_RD_RESP 如何恢复 AXI 响应
9. 看 calc_burst_addr 理解 INCR/WRAP 地址
10. 看 partial write 拆分逻辑
```

最关键的三条主线：

```text
AW/AR/W FIFO 是入口解耦
state_reg 是单线程执行核心
wdata_buf/rdata_buf 是 AXI burst 和 AHB 顺序访问之间的缓冲
```

## 17. 验证方法

从 `rtl` 目录运行：

```powershell
cd F:\codex_proj\axi_inter\rtl
iverilog -g2012 -Wall -o ..\sim\tb_axi4_to_ahb_lite_bridge.vvp axi2ahb_bridge\axi4_to_ahb_lite_fifo.v axi2ahb_bridge\axi4_to_ahb_lite_bridge.v ..\sim\tb_axi4_to_ahb_lite_bridge.sv
vvp ..\sim\tb_axi4_to_ahb_lite_bridge.vvp
```

当前 testbench 覆盖：

```text
4-beat INCR write -> AHB INCR4
16-beat INCR write -> AHB INCR16
4-beat WRAP read -> AHB WRAP4
partial WSTRB byte 更新
sparse WSTRB 从非 0 byte lane 开始
慢速 AHB 下读写请求同时进入 AW/AR/W buffer
```

期望输出包含：

```text
PASS: tb_axi4_to_ahb_lite_bridge
```

