# rni_arctrl 设计文档

## 1. 模块定位

`rni_arctrl` 是 RNI 读请求控制模块，负责把 AXI4 `AR` 通道请求转换为 CHI-E `TXREQ` 读请求，并跟踪后续 `RXDAT` 返回数据，最终驱动 `rni_rd_buffer` 向 AXI `R` 通道返回数据。

从系统视角看，它处在三个模块之间：

```text
AXI AR
  -> rni_arlink
  -> rni_arctrl
  -> TXREQ ReadOnce
  -> CHI fabric / HN
  -> RXDAT CompData
  -> rni_rd_buffer
  -> AXI R
```

它不是数据缓冲本体。真正的 `RXDAT` 数据存储和 AXI `RDATA` 输出在 `rni_rd_buffer` 中完成。`rni_arctrl` 主要负责：

1. 接收并拆分 AXI AR burst。
2. 分配 AR transaction entry。
3. 生成 CHI `ReadOnce` 请求 flit。
4. 处理 `RetryAck` 和 `PCRDGrant`。
5. 跟踪每个读事务有哪些数据片段已经回来。
6. 按 AXI ID ordering 要求选择可以返回的读数据。
7. 在读数据全部被返回后释放 entry。

## 2. 外部接口分组

### 2.1 AXI AR 输入侧

```verilog
input  wire [`AXI4_AR_WIDTH-1:0] AR_CH_S0;
input  wire                      ARVALID0;
output wire                      ARREADY0;
```

`AR_CH_S0` 是打包后的 AXI AR bus，内部包含 `ARID/ARADDR/ARLEN/ARSIZE/ARBURST/ARLOCK/ARCACHE/ARQOS` 等字段。  
`ARREADY0` 不是直接由 `rni_arctrl` 手写产生，而是由内部例化的 `rni_arlink` 根据 AR FIFO 是否满、entry 是否有空位等条件产生。

### 2.2 CHI TXREQ 输出侧

```verilog
output wire                            arctrl_txreqflitv_s4_o;
output wire [`CHIE_REQ_FLIT_WIDTH-1:0] arctrl_txreqflit_s4_o;
input  wire                            arctrl_txreqflit_sent_s4_i;
```

这一组信号送到 `rni_link_ctl`，用于发出 CHI Request flit。  
本模块读请求固定生成：

```text
Opcode = ReadOnce
```

`arctrl_txreqflit_sent_s4_i` 表示 link 层已经真正接收/发送该 REQ flit。只有 TXREQ 通道空闲或上一笔已经被发送，`rni_arctrl` 才会选择新的 entry 生成请求。

### 2.3 RXRSP 输入侧

```verilog
input wire                            rxrspflitv_d1_i;
input wire [`CHIE_RSP_FLIT_WIDTH-1:0] rxrspflit_d1_i;
```

读请求正常完成主要依靠 `RXDAT CompData`，但如果请求被 HN 拒绝并要求重试，会通过 `RXRSP RetryAck` 返回。因此 `rni_arctrl` 需要监听 `RXRSP`：

```text
RetryAck   -> 记录 PCRDType，等待 PCRDGrant
PCRDGrant  -> 由 rni_misc 提取后送入本模块，允许重发
```

### 2.4 RXDAT / rd_buffer 协作接口

```verilog
input  wire                                      rxdatflitv_d1_i;
input  wire [`CHIE_DAT_FLIT_TXNID_WIDTH-1:0]     rxdatflit_txnid_d1_i;
input  wire [`CHIE_DAT_FLIT_DATAID_WIDTH-1:0]    rxdatflit_dataid_d1_i;

input  wire                                      rp_fifo_acpt_d4_i;
output wire                                      arctrl_rb_valid_d4_o;
output wire [`RNI_DMASK_CT_WIDTH-1:0]            arctrl_rb_ctmask_d4_o;
output wire                                      arctrl_rb_rlast_d4_o;
output wire [`AXI4_ARID_WIDTH-1:0]               arctrl_rb_rid_d4_o;
output wire [`RNI_AR_ENTRIES_WIDTH-1:0]          arctrl_rb_idx_d4_o;
output wire [`RNI_BC_WIDTH-1:0]                  arctrl_rb_bc_d4_o;
```

`rni_rd_buffer` 负责保存 `RXDAT` 数据，`rni_arctrl` 负责告诉它现在应该从哪个 entry、哪个 data bank 取数据发给 AXI R。  
其中：

```text
arctrl_rb_valid_d4_o : 当前有一段读数据可以返回
arctrl_rb_ctmask_d4_o: 当前选择的 cacheline quarter / data bank mask
arctrl_rb_rlast_d4_o : 当前返回 beat 是否是 AXI burst 最后一拍
arctrl_rb_rid_d4_o   : 对应 AXI RID
arctrl_rb_idx_d4_o   : 对应 AR entry index
arctrl_rb_bc_d4_o    : 当前返回数据的 beat count 信息
rp_fifo_acpt_d4_i    : rd_buffer 接收了这次返回调度
```

### 2.5 PCRDGrant 仲裁接口

```verilog
input  wire                           pcrdgnt_pkt_v_d2_i;
input  wire [`PCRDGRANT_PKT_WIDTH-1:0]pcrdgnt_pkt_d2_i;
output wire                           arctrl_pcrdgnt_h_present_d3_o;
output wire                           arctrl_pcrdgnt_l_present_d3_o;
input  wire                           ar_pcrdgnt_h_win_d3_i;
input  wire                           ar_pcrdgnt_l_win_d3_i;
```

`rni_misc` 会从 `RXRSP PCRDGrant` 中提取 `PCRDType/SrcID/TgtID`，形成 `pcrdgnt_pkt`。  
`rni_arctrl` 检查这个 grant 是否匹配某个被 Retry 的读 entry。如果匹配，会向 `rni_misc` 表示 high/low QoS grant present。`rni_misc` 再在 AR/AW 之间仲裁，返回 win 信号。

## 3. 内部核心数据结构

### 3.1 AR entry 表

模块维护一个参数化数量的 AR entry 表：

```text
entry 数量 = RNI_AR_ENTRIES_NUM_PARAM，默认 32
entry index 宽度 = RNI_AR_ENTRIES_WIDTH
```

重要寄存器包括：

```text
arctrl_entry_v_q            : entry 是否有效
arctrl_entry_info_q         : 原始 AXI AR bus
arctrl_entry_addr_q         : 当前 CHI 请求地址
arctrl_entry_size_q         : CHI size
arctrl_entry_lsmask_q       : last beat mask
arctrl_entry_bcvec_q        : beat count vector
arctrl_entry_qos_hi_q       : 是否 high QoS
arctrl_entry_rvmask_q       : 已经收到的 RXDAT data bank mask
arctrl_entry_ctmask_q       : 已经/将要返回给 AXI R 的 bank mask
arctrl_entry_pdmask_q       : 该 entry 需要等待/返回的数据 bank mask
```

一个 entry 大致表示一个经过 `rni_segburst` 切分后的 CHI 读请求。一个 AXI burst 如果跨 cache line，可能会被 `rni_segburst` 切成多笔 CHI request，因此会占用多个 AR entry。

### 3.2 mask 的含义

本设计把一个 cache line 的返回数据划分成若干 data bank，相关 mask 用于跟踪数据完成和返回进度：

```text
PD mask : pending data mask，该请求需要哪些 data bank
RV mask : received valid mask，哪些 RXDAT data bank 已经收到
CT mask : current transmit mask，哪些 bank 已经被选中/正在返回
LS mask : last signal mask，用于判断哪个返回 beat 是 RLAST
BC vec  : beat count vector，辅助 rni_rd_buffer 生成 AXI R beat 数
```

这组 mask 是理解 `rni_arctrl` 后半部分 `rdata` 逻辑的关键。

## 4. AR 接收与 entry 分配

### 4.1 rni_arlink 预处理

`rni_arctrl` 内部例化 `rni_arlink`。`rni_arlink` 先用一个小 FIFO 接收 AXI AR，然后调用 `rni_segburst`：

```text
AXI AR burst
  -> FIFO
  -> rni_segburst
  -> 一个或多个 cacheline 粒度的 CHI request segment
```

`rni_segburst` 输出：

```text
arlink_valid_s1_w
arlink_addr_s1_w
arlink_dmask_s2_w
arlink_bc_vec_s2_w
arlink_size_s2_w
```

`arlink_valid_s1_w` 表示当前有一个 segment 可以分配 entry。

### 4.2 entry 空闲检测与分配

所有 entry 的有效位是：

```verilog
arctrl_entry_v_q
```

模块先计算是否所有 entry 都满：

```text
arctrl_entry_full_r = 所有 arctrl_entry_v_q 都为 1
alloc_busy_s1_w     = arctrl_entry_full_r
```

然后生成可分配 entry 向量：

```text
arctrl_entry_rdy_s1_w = ~arctrl_entry_v_q & arlink_valid_s1_w
```

通过 `poll_function` 选择一个空 entry：

```text
arctrl_alloc_ptr_s1_w = one-hot free entry
```

entry 有效位更新逻辑：

```text
entry_v_next = (entry_v_old | alloc_ptr) & ~dealloc_vec
```

这说明 entry 生命周期是：

```text
alloc -> valid -> request sent -> data received -> data returned -> dealloc
```

## 5. 读请求依赖关系

模块有两套重要依赖链：

```text
request chain
rdata chain
```

### 5.1 request chain

request chain 用来限制同一 AXI ID、同一 cache line 上的读请求发送顺序。

判断条件核心是：

```text
新 ARID == 老 entry ARID
新 ARADDR cacheline 高位 == 老 entry ARADDR cacheline 高位
老 entry 尚未 RXDAT 完成
```

其中 cacheline 判断使用：

```verilog
[`AXI4_ARADDR_WIDTH-1:`L3_CACHELINE_OFFSET]
```

如果新 entry 依赖老 entry：

```text
新 entry 的 req_dep 置位
老 entry 记录自己被哪个新 entry 依赖
```

当老 entry 的 RXDAT 完成后，相关依赖释放，年轻 entry 才能参与 TXREQ 选择。

这样做的目的：

```text
避免同 ID 同 cache line 的多个读请求在 CHI 侧乱序发出，引入数据一致性或返回顺序风险。
```

### 5.2 rdata chain

rdata chain 用来保证 AXI R 通道返回顺序。

判断条件更宽一些：

```text
新 ARID == 老 entry ARID
```

只要 AXI ID 相同，后来的读返回就要等待前面的读返回完成后再输出到 AXI R。这符合 AXI 对同 ID read response ordering 的要求。

注意：

```text
request chain 管 TXREQ 发出顺序
rdata chain 管 AXI R 返回顺序
```

两者不完全一样，因此代码中分成两套依赖位维护。

## 6. TXREQ 选择策略

当 entry 已经有效、依赖已解除、没有 Retry 阻塞，就可以参与 TXREQ 仲裁。

候选请求分为四类：

```text
1. high QoS retry request
2. high QoS new request
3. low QoS retry request
4. low QoS new request
```

优先级由下面的选择逻辑体现：

```text
hi retry
hi new
lo retry
lo new
```

每一类都通过 `poll_with_start_entry` 做轮询选择，`arctrl_entry_req_ptr_q` 作为下一轮起点，避免永远从 entry 0 开始导致不公平。

一个 entry 能参与 new request 选择，需要满足：

```text
entry valid
entry 已进入 request-select-ready 集合
没有 req_dep
没有处在 RetryAck 等待状态
没有已经被选中过
```

一个 entry 能参与 retry request 选择，需要满足：

```text
entry valid
entry select-ready
已经收到匹配的 PCRDGrant
没有已经被选中过
```

如果 TXREQ 输出当前还有未发送完成的 flit，新的选择不会覆盖旧 flit：

```text
arctrl_entry_req_select_success_flag_w =
    found & (arctrl_txreqflit_sent_s4_i | ~arctrl_txreqflitv_s4_o)
```

这保证了 TXREQ flit 的 valid/data 在 link 层接受前保持稳定。

## 7. TXREQ flit 编码

`rni_arctrl` 发出的 CHI request opcode 固定为：

```verilog
CHIE_READONCE
```

主要字段含义如下：

```text
TgtID      = HNF_NID_PARAM
SrcID      = RNI_NID_PARAM
TxnID      = {1'b0, entry_index}
Opcode     = ReadOnce
AllowRetry = 第一次发送为 1，Retry 重发时为 0
Order      = 2'b00
EarlyWrAck = 1
Device     = 0
Cacheable  = 1
SnpAttr    = 1
LPID       = 0
Size       = 3'b110
QoS        = AXI ARQOS
Addr       = 当前 segment 地址
PCRDType   = Retry 重发时使用之前 RetryAck 返回的 PCRDType
```

这里 `TxnID` 最高位写 0：

```text
读事务 TxnID = 0 + AR entry index
写事务 TxnID = 1 + AW entry index
```

这样 `RXRSP/RXDAT` 返回时，只看 `TxnID` 就能判断属于读 entry 还是写 entry。

`arctrl_txreqflitv_s4_o` 的产生方式是：

```text
本拍新选择成功
或者上一拍 valid 但 link 层还没有 sent
```

如果 link 层没接收，模块会用 `ar_txreqflit_s5_q` 保存并重放上一笔 flit。

## 8. RetryAck / PCRDGrant 处理

### 8.1 RetryAck 接收

`rni_arctrl` 从 `RXRSP` 中提取：

```text
TgtID
SrcID
TxnID
Opcode
PCRDType
```

读请求的 RXRSP 合法条件：

```text
RXRSP valid
TxnID 最高位为 0
TgtID == RNI_NID_PARAM
```

如果 opcode 是：

```text
RetryAck
```

则根据 `TxnID` 低位找到 AR entry，记录：

```text
rxrsp_retryack_recv_vec_q[entry] = 1
rxrsp_retryack_pcrdtype_q[entry] = RXRSP.PCRDType
```

同时，原先的 request selected 状态会被清掉，使该 entry 未来可以重发。

### 8.2 PCRDGrant 匹配

`PCRDGrant` 由 `rni_misc` 从 RXRSP 中抽取后送入本模块。`rni_arctrl` 对每个等待 Retry 的 entry 检查：

```text
PCRDGrant.PCRDType == entry 保存的 RetryAck.PCRDType
PCRDGrant.SrcID    == HNF_NID_PARAM
PCRDGrant.TgtID    == RNI_NID_PARAM
QoS high/low 分类匹配
```

如果匹配，则产生 high/low present 信号给 `rni_misc`。  
`rni_misc` 在 AR/AW 之间仲裁后，返回：

```text
ar_pcrdgnt_h_win_d3_i
ar_pcrdgnt_l_win_d3_i
```

获胜后，该 entry 的：

```text
rxrsp_pcrdgrant_recv_vec_q[entry]
```

被置位，进入 retry request ready 集合，等待 TXREQ 选择器重发 `ReadOnce`。

## 9. RXDAT 跟踪与 RDATA 返回

### 9.1 RXDAT 到 entry 的定位

`rni_rd_buffer` 会把 `RXDAT` 的：

```text
TxnID
DataID
```

送给 `rni_arctrl`。`rni_arctrl` 用 `TxnID` 低位匹配 AR entry：

```text
entry == RXDAT.TxnID[AR_ENTRY_WIDTH-1:0]
```

收到一个 `RXDAT` 后，模块根据 `DataID` 更新该 entry 的 `RV mask`：

```text
DataID[1] = 0 -> 对应低两个 bank
DataID[1] = 1 -> 对应高两个 bank
```

代码用：

```verilog
{{2{rxdat_dataid_q[1]}}, {2{~rxdat_dataid_q[1]}}}
```

生成对应的 bank mask。

### 9.2 判断一个 entry 是否 RXDAT 收齐

模块用：

```text
(RV mask | 当前 RXDAT mask) & PD mask == PD mask
```

判断该 entry 需要的数据是否全部收到。  
如果全部收到，就产生 `rxdat_recv_done_vec_r`，这会释放 request chain 依赖。

### 9.3 选择可返回的 RDATA

一个 entry 可以向 `rni_rd_buffer` 发起返回调度，需要满足：

```text
该 entry 有已收到且未返回的数据 bank
该 entry 没有 rdata_dep
当前 rd_buffer 可以接收，或者当前没有 outstanding rb_valid
```

选择器 `arctrl_rdata_entry` 从 `arctrl_rdata_rdy_r` 中轮询选择一个 entry，输出：

```text
arctrl_rdata_send_q
```

然后组合出：

```text
arctrl_rb_valid_d4_o
arctrl_rb_ctmask_d4_o
arctrl_rb_rlast_d4_o
arctrl_rb_rid_d4_o
arctrl_rb_idx_d4_o
arctrl_rb_bc_d4_o
```

这些信号送给 `rni_rd_buffer`，由它真正从 data bank 中读出数据并推入 AXI R FIFO。

### 9.4 CT/PD mask 更新与 entry 释放

当 `rni_rd_buffer` 接收本次调度：

```text
rp_fifo_acpt_d4_i = 1
```

模块更新：

```text
CT mask: 标记当前已经返回了哪些 bank
PD mask: 清掉已经返回的 bank
```

如果更新后的 `PD mask` 全 0，说明这个 entry 需要返回的数据都已经被 rd_buffer 接收，entry 可以释放：

```text
arctrl_entry_dealloc_vec_w = rp_fifo_acpt_d4_i && PD mask next == 0
```

## 10. 一笔读事务的完整时序

```text
1. AXI master 发 ARVALID/AR_CH_S0。
2. rni_arlink FIFO 未满时拉高 ARREADY0，完成 AR 握手。
3. rni_arlink 调用 rni_segburst，把 AXI burst 切成 cacheline 粒度 segment。
4. rni_arctrl 为每个 segment 分配 AR entry。
5. entry 保存 ARID、地址、size、dmask、bcvec、qos 等信息。
6. 如果存在同 ID 同 cacheline 依赖，则新 entry 等待老 entry RXDAT 完成。
7. TXREQ selector 选择可发送 entry。
8. rni_arctrl 生成 ReadOnce flit。
9. rni_link_ctl 发送 TXREQ。
10. 如果收到 RetryAck，entry 记录 PCRDType，等待 PCRDGrant 后重发。
11. 如果收到 RXDAT CompData，rni_rd_buffer 保存数据，rni_arctrl 更新 RV mask。
12. 当 entry 有可返回数据且不违反同 ID 返回顺序时，rni_arctrl 调度 rd_buffer 返回。
13. rd_buffer 推出 AXI R beat。
14. 当该 entry 所有 PD mask 清空，entry 释放。
```

## 11. 乱序和 outstanding 能力

该模块支持多个 AR entry 同时存在，因此读请求可以 outstanding。  
但它通过两类依赖链限制乱序行为：

```text
同 ID 同 cacheline 的 request 发出顺序受 request chain 限制
同 ID 的 RDATA 返回顺序受 rdata chain 限制
不同 ID 之间可以并行/乱序返回
```

这符合 AXI 的基本思想：不同 ID 可以乱序，同 ID 返回顺序需要保持。

## 12. 阅读建议

建议按下面顺序阅读源码：

1. 先看端口和 `rni_arlink` 例化，确认 AR 如何进入。
2. 看 entry allocation，理解 `arctrl_entry_v_q` 的生命周期。
3. 看 request chain 和 rdata chain，理解为什么需要两套依赖。
4. 看 TXREQ select，确认 new/retry/high/low 的优先级。
5. 看 TXREQ flit 编码，重点看 `Opcode/TxnID/AllowRetry/PCRDType`。
6. 看 RXRSP RetryAck/PCRDGrant。
7. 最后看 rdata mask 和 dealloc。

一句话总结：

```text
rni_arctrl 是读事务 entry 管理器和 ReadOnce 请求生成器；
它不保存真实 RDATA，但决定什么时候发读请求、什么时候重试、什么时候允许 rd_buffer 返回某个 entry 的数据。
```
