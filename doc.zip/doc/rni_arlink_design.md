# rni_arlink 设计说明

## 1. 模块定位

`rni_arlink` 是 RNI 读地址通道的入口适配模块。它连接 AXI AR 通道和 RNI 内部读控制器 `rni_arctrl`，负责把 AXI 侧输入的一笔读 burst 请求缓存起来，然后交给 `rni_segburst` 按 64B cacheline 粒度切成一个或多个 segment。

整体数据流如下：

```text
AXI AR channel
    -> rni_arlink
        -> 2-entry AR FIFO
        -> rni_segburst
            -> arlink_valid/addr/dmask/bc_vec/size
                -> rni_arctrl
                    -> allocate AR entry
                    -> send CHI ReadOnce request
```

所以 `rni_arlink` 本身不负责 CHI flit 生成，也不负责 outstanding entry 管理。它的主要职责是：

- 接收 AXI AR 请求。
- 用小 FIFO 解耦 AXI AR 握手和后级切段逻辑。
- 在一笔 AXI burst 被完全切完前，保持该 burst 的 AR 信息稳定。
- 调用 `rni_segburst` 生成读 segment。
- 接收 `rni_arctrl` 的反压，暂停 segment 输出。

## 2. 接口含义

模块接口分为三组。

第一组是 AXI AR 输入：

```verilog
input  wire                      ARVALID;
input  wire [`AXI4_AR_WIDTH-1:0] AR_CH_S0;
output wire                      ARREADY;
```

`AR_CH_S0` 是已经打包后的 AXI AR 总线，里面包含 `ARID/ARADDR/ARLEN/ARSIZE/ARBURST/ARLOCK/ARCACHE/ARPROT/ARQOS/ARREGION` 等字段。

第二组是后级反压输入：

```verilog
input wire alloc_busy_s1_i;
```

这个信号来自 `rni_arctrl`。当 `rni_arctrl` 的 AR entry 全部被占用时，`alloc_busy_s1_i` 拉高，表示后级暂时无法为新的读 segment 分配 entry。

第三组是输出给 `rni_arctrl` 的 segment 信息：

```verilog
output wire [`AXI4_AR_WIDTH-1:0]            arlink_arbus_s1_o;
output wire                                 arlink_valid_s1_o;
output wire [`AXI4_ARADDR_WIDTH-1:0]        arlink_addr_s1_o;
output wire [`RNI_BCVEC_WIDTH-1:0]          arlink_bc_vec_s2_o;
output wire [`RNI_DMASK_WIDTH-1:0]          arlink_dmask_s2_o;
output wire [`CHIE_REQ_FLIT_SIZE_WIDTH-1:0] arlink_size_s2_o;
output wire                                 arlink_lock_s2_o;
```

这些信号中，`arlink_valid_s1_o` 和 `arlink_addr_s1_o` 是当前 segment 的 S1 阶段输出；`arlink_bc_vec_s2_o`、`arlink_dmask_s2_o`、`arlink_size_s2_o` 是 `rni_segburst` 内部打一拍后的 S2 阶段信息。

## 3. 内部结构

`rni_arlink` 的内部很小，主要由两部分组成：

```text
1. AR FIFO
2. rni_segburst
```

AR FIFO 负责缓存原始 AXI AR burst：

```verilog
sync_fifo #(
    .FIFO_ENTRIES_WIDTH (`AXI4_AR_WIDTH),
    .FIFO_ENTRIES_DEPTH (2),
    .FIFO_BYP_ENABLE    (1'b0)
) u_arlink_fifo (...);
```

`rni_segburst` 负责把 FIFO 头部的原始 AXI burst 切成 segment：

```verilog
rni_segburst u_segburst (
    .axi_valid_s1_i  (arvalid_s1),
    .axi_addr_in_s1_i(ar_addr_in_s1_w),
    .axi_len_in_s1_i (ar_len_in_s1_w),
    .axi_size_in_s1_i(ar_size_in_s1_w),
    .axi_burst_s1_i (ar_burst_in_s1_w),
    .axi_lock_in_s1_i(ar_lock_in_s1_w),
    .stall_flag_s1_i(segburst_busy_s1_w),
    ...
);
```

## 4. AR FIFO 的设计思路

FIFO 的 push 条件是：

```verilog
assign arlink_fifo_push_s1_w = ARVALID & ARREADY;
```

也就是 AXI AR 通道握手成功时，把当前 `AR_CH_S0` 写入 FIFO。

FIFO 的 pop 条件是：

```verilog
assign arlink_fifo_pop_s1_w = ~arlink_fifo_empty_s1_w & segburst_done_s1_w;
```

这里有一个很重要的设计点：FIFO 不是每输出一个 segment 就 pop，而是等 `segburst_done_s1_w` 拉高后才 pop。

原因是 FIFO 中保存的是一笔完整的 AXI AR burst。如果这笔 burst 跨多个 64B cacheline，`rni_segburst` 需要连续多拍使用同一份 `ARADDR/ARLEN/ARSIZE/ARBURST` 信息来生成多个 segment。在所有 segment 输出完之前，FIFO 头部不能被弹走。

举例：

```text
AXI AR0 覆盖 3 条 cacheline

cycle 0: AR0 写入 FIFO
cycle 1: 输出 AR0 segment0, done=0
cycle 2: 输出 AR0 segment1, done=0
cycle 3: 输出 AR0 segment2, done=1, FIFO pop AR0
```

这样可以保证一笔 AXI burst 的切段过程是连续且稳定的。

## 5. 为什么 ARREADY 直接由 FIFO full 决定

代码中：

```verilog
assign ARREADY = ~arlink_fifo_full_s1_w;
```

这表示 AXI AR 入口只关心本地 FIFO 是否还有空间。只要 FIFO 没满，就允许 AXI master 继续发送 AR。

这样做的好处是解耦：

```text
AXI AR 接收速度
    与
rni_segburst / rni_arctrl 当前处理速度
```

不必完全同步。

如果当前 FIFO 头部 burst 正在切段，FIFO 还有空位，那么 AXI 侧仍然可以提前送入下一笔 AR。等当前 burst 切完后，下一笔已经在 FIFO 中，`rni_segburst` 可以立刻继续处理，减少入口空泡。

## 6. FIFO 输出如何送入 rni_segburst

FIFO 输出是：

```verilog
assign arlink_arbus_s1_o = arbus_out_s1_w;
assign arvalid_s1        = ~arlink_fifo_empty_s1_w;
```

当 FIFO 非空时，`arvalid_s1=1`，表示 FIFO 头部存在一笔待切段 AR。

接着模块从 `arlink_arbus_s1_o` 中解析出 AXI AR 字段：

```verilog
assign ar_addr_in_s1_w   = arlink_arbus_s1_o[`AXI4_ARADDR_RANGE];
assign ar_len_in_s1_w    = arlink_arbus_s1_o[`AXI4_ARLEN_RANGE];
assign ar_size_in_s1_w   = arlink_arbus_s1_o[`AXI4_ARSIZE_RANGE];
assign ar_burst_in_s1_w  = arlink_arbus_s1_o[`AXI4_ARBURST_RANGE];
assign ar_lock_in_s1_w   = arlink_arbus_s1_o[`AXI4_ARLOCK_RANGE];
```

这些字段是 `rni_segburst` 进行切段所需的全部信息。

## 7. segburst_busy_s1_w 的作用

当前你关注的信号是：

```verilog
assign segburst_busy_s1_w = alloc_busy_s1_i;
```

它会连接到 `rni_segburst` 的 `stall_flag_s1_i`：

```verilog
.stall_flag_s1_i(segburst_busy_s1_w)
```

所以 `segburst_busy_s1_w` 本质就是 `rni_segburst` 的暂停信号。

它的设计含义是：

```text
如果 rni_arctrl 没有空闲 AR entry，
那么 rni_arlink 不能继续从当前 AXI burst 切出新的 segment。
```

这是必要的。因为每个读 segment 后面都需要在 `rni_arctrl` 中分配一个 AR entry，用来记录 AXI ID、地址、mask、返回数据状态、retry 状态等信息。如果 entry 满了还继续输出 segment，就会出现 segment 无处存放的问题。

因此反压路径是：

```text
rni_arctrl entry full
    -> alloc_busy_s1_w = 1
        -> rni_arlink.alloc_busy_s1_i = 1
            -> segburst_busy_s1_w = 1
                -> rni_segburst.stall_flag_s1_i = 1
                    -> 停止输出新的 read segment
```

## 8. alloc_busy_s1_i 从哪里来

在 `rni_arctrl` 中，AR entry valid 向量是：

```verilog
arctrl_entry_v_q[RNI_AR_ENTRIES_NUM_PARAM-1:0]
```

模块用下面逻辑判断是否所有 entry 都被占用：

```verilog
always @* begin
    arctrl_entry_full_r = 1'b1;
    for (i=0; i < RNI_AR_ENTRIES_NUM_PARAM; i=i+1)
        arctrl_entry_full_r = arctrl_entry_full_r & arctrl_entry_v_q[i];
end

assign alloc_busy_s1_w = arctrl_entry_full_r;
```

`alloc_busy_s1_w` 传给 `rni_arlink` 的 `alloc_busy_s1_i`。所以读路径的 stall 条件非常直接：AR entry 全满就 stall。

## 9. stall 时 rni_segburst 会发生什么

`rni_segburst` 收到 `stall_flag_s1_i=1` 后，会停止推进切段流程。

它会做几件事：

- `segburst_valid_s1_o` 拉低。
- 状态机 `state_q` 不更新。
- 当前 segment 计数 `txn_cnt_q` 不更新。
- 当前地址寄存器 `axi_addr_q` 不更新。
- FIFO 不会 pop，因为 `segburst_done_s1_w` 不会正常产生最后一段完成信号。

因此它不会丢 segment，也不会在后级没有 entry 时继续推进。

可以理解成：

```text
stall=1: 切段器暂停在当前位置
stall=0: 从暂停点继续输出后续 segment
```

## 10. 与 rni_awlink 的区别

`rni_arlink` 和 `rni_awlink` 都调用 `rni_segburst`，但反压条件不同。

读路径：

```text
stall = AR entry full
```

写路径：

```text
stall = AW entry full 或 wr_buffer 请求 FIFO almost full
```

原因是写路径除了要分配 AW entry，还要保证后面的写数据 buffer 能记录这笔 segment 对应的写数据收集信息；读路径只需要保证 AR entry 有空间。

另外，`rni_arlink` 的 `ARREADY` 直接由 FIFO full 控制：

```verilog
ARREADY = ~arlink_fifo_full_s1_w;
```

而 `rni_awlink` 中 `AWREADY` 使用了额外的提前关断逻辑。两者写法不同，说明作者对 AW 通道的缓存和切段关系做了更谨慎的 ready 预测。

## 11. 一笔读 burst 的处理过程

假设 AXI master 发来一笔 AR：

```text
ARADDR = 0x30
ARLEN  = 若干
ARSIZE = 4, 每 beat 16B
ARBURST = INCR
```

如果这笔 burst 跨 64B cacheline，流程如下：

```text
cycle 0:
    AXI AR 握手成功
    AR_CH_S0 push 到 arlink FIFO

cycle 1:
    FIFO 非空，arvalid_s1=1
    rni_segburst 输出 segment0
    arlink_valid_s1_o=1
    arlink_addr_s1_o=0x30
    segburst_done_s1_w=0
    FIFO 不 pop

cycle 2:
    rni_segburst 输出 segment1
    arlink_addr_s1_o=0x40
    segburst_done_s1_w=0
    FIFO 不 pop

cycle 3:
    rni_segburst 输出最后一个 segment
    segburst_done_s1_w=1
    FIFO pop 当前 AR

cycle 4:
    如果 FIFO 中已有下一笔 AR，继续处理下一笔
```

如果中间 `rni_arctrl` entry 满：

```text
alloc_busy_s1_i=1
segburst_busy_s1_w=1
rni_segburst 暂停
当前 FIFO 头部 AR 保持不变
等待 entry 释放后继续切段
```

## 12. 设计优点

这个模块的设计比较简洁，优点主要有：

- AXI AR 输入和内部切段处理解耦。
- FIFO 头部保持原始 AR burst，使多 segment 切分容易实现。
- AR entry 满时可以安全暂停，不会丢 segment。
- `rni_segburst` 被 AR/AW 复用，读写切段规则一致。
- FIFO 深度为 2，可以吸收少量入口突发，减少 AXI 侧不必要反压。

## 13. 需要注意的点

第一，FIFO 中存的是原始 AXI burst，不是切好的 segment。

这意味着如果一笔 burst 切成多个 segment，它会一直占据 FIFO 头部，直到最后一个 segment 输出完成。

第二，`rni_arlink` 本身不限制 outstanding 数量。

真正的 outstanding 限制在 `rni_arctrl` 的 AR entry 数量上。`rni_arlink` 只通过 `alloc_busy_s1_i` 感知 entry 是否满。

第三，`ARREADY` 只看 FIFO full，不直接看 `alloc_busy_s1_i`。

这意味着即使 `rni_arctrl` entry 满，只要 `rni_arlink` FIFO 还有空间，AXI 侧仍然可能继续送入少量 AR。这是有意的弹性缓冲设计。等 FIFO 满后，`ARREADY` 才会拉低。

## 14. 总结

`rni_arlink` 是读地址入口的缓存与切段适配层。它用一个 2-entry FIFO 接收 AXI AR burst，通过 `rni_segburst` 将 FIFO 头部 burst 切成 64B cacheline segment，再送给 `rni_arctrl` 分配读 entry 并生成 CHI 读请求。

`segburst_busy_s1_w` 是这个模块里的关键反压桥梁。它把 `rni_arctrl` 的 entry full 状态传递给 `rni_segburst`，保证后级没有 entry 时不会继续生成 segment。

一句话概括：

```text
rni_arlink = AXI AR 小缓存 + 读 burst 切段入口 + AR entry 反压适配。
```
