# RNI 详细设计文档

本文档针对当前工程中的 `rtl/rni` 目录编写，用于理解 `rni` 模块如何把 AXI4 请求转换为 CHI-E flit，并把 CHI-E 响应重新恢复成 AXI4 的 R/B 通道响应。文档中的结论均以当前 RTL 实现为准。

## 1. 模块定位

`rni` 可以理解为一个 AXI4 到 CHI-E 网络侧的 RN-I 接口模块。

它的 AXI 侧表现为一个 AXI slave interface，接收上游 AXI master 的读写请求；CHI-E 侧表现为一个 flit 接口，向 CHI 网络发送 request/data/response flit，并接收 response/data flit。

当前顶层接口只暴露了：

- AXI AW/W/B/AR/R 五个通道。
- CHI-E RXRSP、RXDAT、TXREQ、TXRSP、TXDAT 通道。
- Link active handshake 和 L-credit 信号。

当前代码没有暴露 RXREQ/SNP 侧接口，因此本文只按“AXI master 请求经 RNI 进入 CHI 网络，并接收 CHI 响应”的路径分析。

## 2. 顶层文件与子模块

顶层文件：

- `rtl/rni/rni.v`

主要子模块：

| 子模块 | 作用 |
|---|---|
| `rni_axi_bus` | 将 AXI 独立字段打包为内部 AW/W/B/AR/R bus，也将内部 R/B bus 解包回 AXI 端口 |
| `rni_awlink` | 接收 AXI AW，请求 FIFO 缓冲，并调用 `rni_segburst` 做写地址突发切分 |
| `rni_arlink` | 接收 AXI AR，请求 FIFO 缓冲，并调用 `rni_segburst` 做读地址突发切分 |
| `rni_awctrl` | 管理写事务 entry，生成 CHI TXREQ，处理 RXRSP，调度 TXDAT、TXRSP 和 AXI B 响应 |
| `rni_arctrl` | 管理读事务 entry，生成 CHI TXREQ，处理 Retry/PCRDGrant，跟踪 RXDAT 到齐情况并调度 R 数据返回 |
| `rni_wr_buffer` | 缓冲 AXI W 数据，按 CHI DAT flit 格式组织写数据，生成 AXI B 响应 FIFO |
| `rni_rd_buffer` | 接收 CHI RXDAT 数据，按 TxnID/DataID 写入读数据 bank，然后生成 AXI R 通道数据 |
| `rni_link_ctl` | CHI link 管理，处理 link active handshake、L-credit、TX/RX flit pipeline 和 TXREQ 仲裁 |
| `rni_link_handshake` | TX/RX link active 状态机 |
| `rni_lcrd_hdlr` | L-credit 计数器模块 |
| `rni_misc` | 提取并缓存 PCRDGrant，用于 Retry 后重发 |
| `rni_segburst` | AXI burst 到 CHI cache-line 粒度请求的切分模块 |
| `rni_bcount_ctl` | 写数据 beat/bank 计数，判断某个写请求的数据是否收齐 |
| `rni_datbuf_bank` | 读数据 bank RAM，用于 RXDAT 数据缓存 |

辅助公共模块：

- `rtl/misc/sync_fifo.v`
- `rtl/misc/poll_function.v`
- `rtl/misc/poll_with_start_entry.v`

## 3. 参数配置

RNI 参数定义在 `rtl/include/rni_param.v` 中，通过宏 `RNI_PARAM` 注入到 `rni` 及其子模块。

当前默认关键参数如下：

| 参数 | 默认值 | 含义 |
|---|---:|---|
| `AXI4_PA_WIDTH_PARAM` | 44 | AXI 地址宽度 |
| `AXI4_AXDATA_WIDTH_PARAM` | 128 | AXI W/R data 宽度 |
| `CHIE_NID_WIDTH_PARAM` | 11 | CHI Node ID 字段宽度 |
| `CHIE_REQ_ADDR_WIDTH_PARAM` | 44 | CHI REQ 地址字段宽度 |
| `CHIE_DATA_WIDTH_PARAM` | 256 | CHI DAT flit 数据字段宽度 |
| `CHIE_BE_WIDTH_PARAM` | 32 | CHI DAT flit byte enable 宽度 |
| `RNI_AR_ENTRIES_NUM_PARAM` | 32 | 读事务 entry 数量 |
| `RNI_AW_ENTRIES_NUM_PARAM` | 32 | 写事务 entry 数量 |
| `HNF_NID_PARAM` | 0 | 目标 HNF 节点 ID |
| `RNI_NID_PARAM` | 6 | 当前 RNI 节点 ID |

当前默认位宽可以推导为：

| 信号/字段 | 当前位宽 | 说明 |
|---|---:|---|
| AXI ID | 11 bit | `AWID/ARID/BID/RID` |
| AXI 地址 | 44 bit | `AWADDR/ARADDR` |
| AXI data | 128 bit | `WDATA/RDATA` |
| CHI REQ flit | 143 bit | `44 + 3*11 + 66` |
| CHI RSP flit | 73 bit | `2*11 + 51` |
| CHI DAT flit | 382 bit | `3*11 + 256 + 32 + 8 + 2 + 51` |

注意：AXI ID 和 CHI Node ID 虽然当前都是 11 bit，但含义完全不同。

- AXI ID 用来标识 AXI outstanding transaction。
- CHI Node ID 用来标识网络节点，例如 `SRCID`、`TGTID`。

## 4. 顶层数据流

整体数据流可以抽象成：

```text
AXI AW/AR
  -> rni_axi_bus
  -> rni_awlink / rni_arlink
  -> rni_segburst
  -> rni_awctrl / rni_arctrl entry
  -> TXREQ flit
  -> rni_link_ctl
  -> CHI network

AXI W
  -> rni_axi_bus
  -> rni_wr_buffer
  -> TXDAT flit
  -> rni_link_ctl
  -> CHI network

CHI RXRSP
  -> rni_link_ctl
  -> rni_awctrl / rni_arctrl / rni_misc

CHI RXDAT
  -> rni_link_ctl
  -> rni_rd_buffer
  -> AXI R

写完成路径
  -> rni_awctrl
  -> rni_wr_buffer B response FIFO
  -> AXI B
```

顶层 `rni.v` 自身不直接实现复杂控制，它主要完成模块连接。真正的读写事务管理分别在 `rni_arctrl` 和 `rni_awctrl` 中完成。

## 5. AXI 字段打包：`rni_axi_bus`

`rni_axi_bus` 的作用比较简单：把 AXI 每个通道的字段拼成内部宽 bus。

例如 AW 通道被打包为：

```text
AW_CH_S0 = {
  AWREGION,
  AWQOS,
  AWPROT,
  AWCACHE,
  AWLOCK,
  AWBURST,
  AWSIZE,
  AWLEN,
  AWADDR,
  AWID
}
```

W 通道被打包为：

```text
W_CH_S0 = {
  WLAST,
  WSTRB,
  WDATA
}
```

B/R 通道则反过来，将内部 `B_CH_S0`、`R_CH_S0` 解包到 AXI 顶层端口。

这个模块不做协议控制，只做字段重组，方便后续控制模块按统一 bus 处理。

## 6. 地址入口与 burst 切分

AW 和 AR 的入口路径类似：

```text
AXI AW/AR handshake
  -> 2-entry FIFO
  -> rni_segburst
  -> 分段后的 CHI request 信息
```

### 6.1 `rni_awlink`

`rni_awlink` 内部有一个深度为 2 的 AW FIFO。`AWREADY` 由 FIFO 可用空间和 `rni_segburst` 消耗进度共同决定。

它输出：

- `awlink_valid_s1_o`
- `awlink_addr_s1_o`
- `awlink_bc_vec_s2_o`
- `awlink_dmask_s2_o`
- `awlink_size_s2_o`
- `awlink_lock_s2_o`
- `awlink_done_s1_o`

这些信息被 `rni_awctrl` 用于分配写 entry、生成 CHI TXREQ、通知 `rni_wr_buffer` 写数据如何落 bank。

### 6.2 `rni_arlink`

`rni_arlink` 与 AW 侧类似，也有一个 2-entry FIFO，并调用 `rni_segburst`。

区别是它受到 `alloc_busy_s1_i` 控制。当 AR entry 已满时，`rni_segburst` 会被 stall，避免继续向 `rni_arctrl` 发出无法分配的请求。

### 6.3 `rni_segburst`

`rni_segburst` 是 RNI 里很关键的模块。它负责把 AXI burst 转换成 CHI 更适合处理的 cache-line 粒度请求。

它支持的输入 burst 类型包括：

- FIXED
- INCR
- WRAP

内部按 64B cache line 切分，`SEGB_CACHE_OFFSET = 6`。也就是把请求拆成不跨 64B cache line 的 CHI 请求片段。

它的状态包括：

| 状态 | 作用 |
|---|---|
| `SEGB_PASS` | 当前 AXI 请求可直接通过，或开始判断是否需要切分 |
| `SEGB_INCR` | 处理跨 cache line 的 INCR burst 后续片段 |
| `SEGB_MULTILINE_WRAP` | 处理跨多个 cache line 的 WRAP burst |
| `SEGB_SINGLELINE_WRAP` | 处理单 cache line 内 WRAP 的特殊情况 |
| `SEGB_SINGLELINE_WRAP_FIRST_PART` | 单 cache line WRAP 第一段 |
| `SEGB_SINGLELINE_WRAP_SECOND_PART` | 单 cache line WRAP 第二段 |

输出中的 `dmask` 是后续读写 buffer 组织数据的关键。它被拆成四组 4-bit mask：

| mask | 含义 |
|---|---|
| `CT mask` | 当前需要传输的 data bank |
| `PD mask` | pending data bank |
| `LS mask` | 哪个 bank 对应 AXI `LAST` |
| `RV mask` | 接收/有效数据跟踪用 |

每个 bit 对应一个 16B bank。4 个 bank 合起来就是一个 64B cache line。

## 7. 读路径设计

读路径从 AXI AR 开始，到 AXI R 返回结束。

### 7.1 AR 请求接收

路径如下：

```text
ARVALID/ARREADY
  -> rni_arlink FIFO
  -> rni_segburst
  -> rni_arctrl 分配 AR entry
```

`rni_arctrl` 维护 `RNI_AR_ENTRIES_NUM_PARAM` 个读 entry。默认是 32 个。

每个 entry 保存：

- 原始 AXI AR 信息。
- 分段后的地址。
- size。
- QoS。
- `ctmask/pdmask/lsmask/rvmask`。
- beat count vector。
- RetryAck/PCRDGrant 状态。
- 是否已经发出 TXREQ。
- 是否已经收到全部 RXDAT。

### 7.2 CHI TXREQ 生成

`rni_arctrl` 将读请求生成为 CHI `ReadOnce`：

```text
Opcode  = CHIE_READONCE
TgtID   = HNF_NID_PARAM
SrcID   = RNI_NID_PARAM
TxnID   = {read/write区分位, entry index}
Addr    = ARADDR 或切分后的地址
QoS     = ARQOS
Size    = 当前 CHI 请求片段 size
```

读请求的 `TxnID` 最高位被置为 0：

```text
读 TxnID[11] = 0
低位         = AR entry index
```

这样 RXRSP/RXDAT 回来时，控制器可以根据 TxnID 找到对应读 entry。

### 7.3 请求选择与 Retry

`rni_arctrl` 的请求发送不是简单 FIFO，它维护多组 ready vector：

- 新请求 high QoS。
- 新请求 low QoS。
- Retry 请求 high QoS。
- Retry 请求 low QoS。

选择优先级大致是：

```text
Retry high QoS
  -> New high QoS
  -> Retry low QoS
  -> New low QoS
```

当收到 CHI `RetryAck` 时，entry 不会立即完成，而是记录返回的 `PCrdType`。之后 `rni_misc` 从 RXRSP 中收集 `PCRDGrant`，`rni_arctrl` 匹配到对应 grant 后重新发送该请求。

第一次请求：

```text
AllowRetry = 1
PCrdType   = 0
```

Retry 后重发：

```text
AllowRetry = 0
PCrdType   = RetryAck 返回的类型
```

### 7.4 RXDAT 接收与读数据缓存

读数据从 CHI 网络侧以 `RXDATFLIT` 进入：

```text
RXDATFLIT
  -> rni_link_ctl
  -> rni_rd_buffer
```

`rni_rd_buffer` 解码：

- `TxnID`
- `DataID`
- `Data`
- `RespErr`

然后按 `TxnID` 和 `DataID` 写入内部 4 个 data bank。

当前设计中，一个 64B cache line 被组织成 4 个 128-bit bank：

```text
bank0 = 16B
bank1 = 16B
bank2 = 16B
bank3 = 16B
```

当 `CHIE_DATA_WIDTH_PARAM = 256` 时，一个 CHI DAT flit 携带 32B 数据，因此一次可能写两个 128-bit bank。

### 7.5 AXI R 返回

`rni_arctrl` 根据 RXDAT 到齐情况、data mask 和同 ID 顺序依赖，选择可以返回的读 entry，并向 `rni_rd_buffer` 发出：

- entry index。
- 当前要读出的 bank mask。
- AXI RID。
- RLAST。
- beat count。

`rni_rd_buffer` 从 data bank 取出数据，先进入 `rp_fifo`，再进入 `rd_fifo`，最后驱动 AXI R 通道：

```text
RVALID0 = ~rd_fifo_empty
R_CH_S0 = rd_fifo_data_out
```

`RID` 来自原始 AXI `ARID`，因此 AXI master 能通过 `RID` 识别响应属于哪个读事务。

### 7.6 读顺序控制

代码中有两类主要依赖：

1. request dependency：
   - 对相同 AXI ID 且落在相同 cache line 的请求建立依赖，避免违反 CHI/AXI 侧的可见顺序。

2. rdata dependency：
   - 对相同 AXI ID 的读数据返回建立依赖，保证同 ID 返回顺序。

因此该 RNI 可以有多个读 entry 同时 outstanding，但不会随意打乱同 ID 的 AXI R 返回顺序。

## 8. 写路径设计

写路径涉及 AW、W、RXRSP、TXDAT、TXRSP、B，比读路径更复杂。

### 8.1 AW 请求接收

路径如下：

```text
AWVALID/AWREADY
  -> rni_awlink FIFO
  -> rni_segburst
  -> rni_awctrl 分配 AW entry
```

`rni_awctrl` 默认维护 32 个写 entry。

每个 entry 主要保存：

- 原始 AXI AW 信息。
- 分段后的地址。
- AXI ID。
- size、QoS。
- dmask、bc_vec。
- 是否收到 DBID。
- 是否收到 Comp。
- 是否收到 W 数据。
- 是否已发送 TXDAT。
- 是否需要 CompAck。
- 是否可以返回 AXI B。

### 8.2 CHI 写请求 TXREQ

`rni_awctrl` 将 AXI 写地址转换成 CHI `WriteUniquePtl`：

```text
Opcode       = CHIE_WRITEUNIQUEPTL
TgtID        = HNF_NID_PARAM
SrcID        = RNI_NID_PARAM
TxnID[11]    = 1
TxnID[低位]  = AW entry index
Addr         = AWADDR 或切分后的地址
QoS          = AWQOS
Size         = 当前 CHI 请求片段 size
Order        = 2'b10
EarlyWrAck   = 1
SnpAttr      = 1
```

写请求的 `TxnID` 最高位被置为 1：

```text
写 TxnID[11] = 1
低位         = AW entry index
```

这样 RXRSP 回来时，`rni_awctrl` 可以区分这是写请求响应，而 `rni_arctrl` 会忽略它。

### 8.3 W 数据接收与写数据 buffer

AXI W 通道进入 `rni_wr_buffer`：

```text
WVALID/WREADY
  -> WD FIFO
  -> 根据 AW entry 和 dmask 写入内部 data bank
```

`rni_wr_buffer` 内部有：

- `WD FIFO`：缓存 AXI W beat。
- `AW Req FIFO`：缓存 AW entry 对应的 mask 和 beat count 信息。
- 写数据 bank：按 entry 和 bank 保存 WDATA/WSTRB。
- `BRSP FIFO`：缓存待返回 AXI B 响应。

`WREADY0` 主要由 `WD FIFO` 是否满决定：

```text
WREADY0 = ~wd_fifo_full | wd_fifo_pop
```

因此 W 通道可在一定程度上与 CHI 侧发送解耦。

### 8.4 DBID/Comp 接收

CHI 写请求发送后，HNF 可能返回：

- `DBIDResp`
- `Comp`
- `CompDBIDResp`
- `RetryAck`

`rni_awctrl` 解码 RXRSP：

```text
如果 TxnID[11] = 1 且 TgtID = RNI_NID_PARAM，则认为是写响应
```

收到 DBID 后，说明 HNF 给了写数据发送目标信息，之后 `rni_awctrl` 会通知 `rni_wr_buffer` 可以组织 TXDAT。

收到 Comp 后，说明写事务完成条件之一满足。

### 8.5 TXDAT 发送

当以下条件满足时，`rni_awctrl` 选择写 entry 发送数据：

- 已经收到 DBID。
- AXI W 数据已收齐或相应 bank 已准备好。
- 同 ID/CompAck/response 依赖允许。
- `rni_wr_buffer` 不忙。
- CHI TXDAT 有 L-credit。

`rni_wr_buffer` 根据 entry 中缓存的数据生成 `TXDATFLIT`，主要字段包括：

- `TgtID`
- `SrcID`
- `TxnID`
- `DBID`
- `Opcode`
- `DataID`
- `BE`
- `Data`
- `CCID`
- `QoS`

### 8.6 TXRSP CompAck

当前写控制中，`rni_awctrl` 还会生成 CHI `CompAck`：

```text
Opcode = CHIE_COMPACK
TgtID  = HNF_NID_PARAM
SrcID  = RNI_NID_PARAM
TxnID  = DBID 或相关响应 ID
```

它通过 `TXRSPFLIT` 发回 CHI 网络，用于完成需要 CompAck 的写事务流程。

### 8.7 AXI B 响应

AXI B 响应由 `rni_wr_buffer` 输出。

流程是：

```text
rni_awctrl 判断某个写 entry 可以返回 B
  -> brsp info 进入 rni_wr_buffer 的 BRSP FIFO
  -> BVALID0 拉高
  -> BREADY0 握手
```

当前代码中 `awctrl_brsp_resperr_d2_o` 被赋值为 0，因此写响应 `BRESP` 默认返回 OKAY。也就是说，当前实现没有把 CHI 写响应错误完整映射到 AXI `BRESP`。

`BID` 来自原始 AXI `AWID`，用于恢复 AXI 写响应归属。

### 8.8 写顺序控制

写侧依赖比读侧更多，主要包括：

- request dependency：同 AXI ID 的写请求发送顺序。
- CompAck dependency：同 AXI ID 的 CompAck 相关顺序。
- B response dependency：同 AXI ID 的 AXI B 返回顺序。

这些依赖通过多组 vector 保存，保证同 ID 写事务不会乱序返回，避免违反 AXI 同 ID ordering 要求。

## 9. CHI flit 与 L-credit/link 控制

`rni_link_ctl` 是 RNI 与 CHI link 的集中控制模块。

### 9.1 Link active handshake

顶层有四个 link active 信号：

```text
TXLINKACTIVEREQ
TXLINKACTIVEACK
RXLINKACTIVEREQ
RXLINKACTIVEACK
```

它们由 `rni_link_handshake` 管理，内部 link 状态包括：

| 状态 | 含义 |
|---|---|
| `LL_STOP` | link 停止 |
| `LL_ACTIVATE` | 正在激活 |
| `LL_RUN` | link 可正常传输 flit |
| `LL_DEACTIVATE` | 正在关闭 |

TX 方向有待发送 flit 时，RNI 会请求激活 TX link。RX 方向收到对端激活请求后，RNI 在合适条件下确认接收方向可用。

### 9.2 RX L-credit 返回

RXRSP/RXDAT 方向：

```text
RXRSPFLITV / RXDATFLITV 表示收到 flit
RXRSPLCRDV / RXDATLCRDV 表示 RNI 向对端归还 credit
```

`rni_link_ctl` 用 `rni_lcrd_hdlr` 维护 RX credit 计数。收到 flit 后计数增加；向对端返回 L-credit 后计数减少。

### 9.3 TX L-credit 使用

TXREQ/TXRSP/TXDAT 方向：

```text
TXREQLCRDV / TXRSPLCRDV / TXDATLCRDV 表示对端给 RNI credit
TXREQFLITV / TXRSPFLITV / TXDATFLITV 表示 RNI 发送 flit
```

只有当对应 TX channel 有 L-credit 且 TX link 处于 `LL_RUN` 时，RNI 才真正发送 flit。

### 9.4 TXREQ 仲裁

TXREQ 通道同时可能有：

- `rni_arctrl` 的 ReadOnce。
- `rni_awctrl` 的 WriteUniquePtl。
- L-credit return flit。

`rni_link_ctl` 使用 `poll_function` 在 AR/AW TXREQ 之间选择。选择成功后，会给对应控制器返回 `*_txreqflit_sent`，控制器再更新自己的 entry 状态。

### 9.5 PEND 信号

当定义了 `LINKFLITPEND_EN` 时，`TX*FLITPEND` 表示后续可能有 flit 要发送；否则当前代码把 PEND 常置为 1。

RX 侧在 `LINKFLITPEND_EN` 打开时也会检查：

```text
不能在上一拍 PEND 为 0 的情况下突然收到 FLITV
```

这部分主要服务于 link 低功耗/提前唤醒语义。

## 10. PCRDGrant 与 Retry 机制

CHI 中 request 可能收到 `RetryAck`。收到 RetryAck 后，requester 需要等待匹配的 `PCRDGrant` 后重发。

当前实现中：

1. `rni_awctrl` / `rni_arctrl` 收到 `RetryAck` 后，记录该 entry 的 `PCrdType`。
2. `rni_misc` 从 RXRSP 中识别 `PCRDGrant`，将 `{PCrdType, SrcID, TgtID}` 写入 FIFO。
3. AW/AR 控制器检查 `PCRDGrant` 是否匹配目标 HNF 和当前 RNI。
4. 匹配后，将该 entry 重新放入 request 选择集合。
5. 重发时 `AllowRetry` 置低，并带上对应 `PCrdType`。

这个设计使 RNI 能够处理 CHI 网络侧的 request retry，而不是简单丢弃或报错。

## 11. TxnID 与 entry 映射

当前代码使用 CHI `TxnID` 来索引本地 entry。

`TxnID` 宽度为 12 bit。设计中最高位用来区分读写：

```text
读请求：TxnID[11] = 0
写请求：TxnID[11] = 1
```

低位保存 entry index：

```text
TxnID[低位] = entry index
```

默认 entry 数量是 32，因此 entry index 需要 5 bit。

这种映射的好处是：

- RXRSP/RXDAT 回来时，可以直接根据 TxnID 找到读/写 entry。
- 读写 entry 空间相互独立。
- AXI ID 不需要直接暴露到 CHI 网络中，而是存在 entry 内部，响应回来后再恢复成 AXI `RID/BID`。

## 12. Outstanding 与乱序能力

当前 RNI 支持多个读写事务同时挂起。

原因是：

- 读侧有 `RNI_AR_ENTRIES_NUM_PARAM` 个 entry，默认 32。
- 写侧有 `RNI_AW_ENTRIES_NUM_PARAM` 个 entry，默认 32。
- 每个 entry 可以独立等待 TXREQ 发送、Retry/PCRD、RXDAT/RXRSP、数据返回。

但它不是完全任意乱序。

对于不同 AXI ID 的事务，RNI 可以更自由地并行处理。对于相同 AXI ID，代码中显式维护依赖链，约束 request、read data、B response 和 CompAck 顺序。

可以概括为：

```text
支持 outstanding。
支持不同 ID 间的并行和一定程度乱序。
对相同 AXI ID 保持 AXI 所要求的顺序约束。
```

## 13. 当前设计能力总结

当前 RNI 具备以下能力：

- 接收 AXI4 AW/W/AR 请求。
- 支持 AXI burst 到 CHI cache-line 粒度请求的切分。
- 支持 INCR、FIXED、WRAP burst 的地址处理逻辑。
- 支持 64B cache line 粒度的 data mask 和 bank 管理。
- 读请求转换为 CHI `ReadOnce`。
- 写请求转换为 CHI `WriteUniquePtl`。
- 支持 CHI RetryAck/PCRDGrant 重发流程。
- 支持 CHI link active handshake。
- 支持 TX/RX L-credit 计数和 flit 发送 gating。
- 支持读写 outstanding entry。
- 支持同 AXI ID 顺序依赖控制。
- 支持 CHI RXDAT 到 AXI R 数据恢复。
- 支持 CHI 写完成到 AXI B 响应恢复。

## 14. 当前实现限制与注意点

按当前 RTL 观察，需要注意以下限制：

1. 顶层只看到一个 AXI 接口，端口名后缀为 `0`。

2. 当前没有暴露 CHI SNP/RXREQ 相关顶层接口，不能按完整 snoop-capable CHI node 来理解。

3. 写响应 `BRESP` 当前基本返回 OKAY，`awctrl_brsp_resperr_d2_o` 被置为 0，没有完整映射 CHI 写错误。

4. 读侧 `RXDAT` 的 `RespErr` 会进入 RRESP 路径，但错误处理主要是断言检查和响应字段传播，不是复杂错误恢复。

5. 当前 TXREQ opcode 固定为：

   - 读：`ReadOnce`
   - 写：`WriteUniquePtl`

   没有覆盖 AXI cache/prot 属性到更多 CHI opcode 的完整映射。

6. CHI DAT 宽度默认是 256 bit，而 AXI data 默认是 128 bit，因此读写 buffer 中有 128-bit bank 与 256-bit CHI data 的拼接/拆分逻辑。

7. `rni_segburst` 以 64B cache line 为切分边界，这和 CHI cache-line 事务模型紧密相关。修改 cacheline 相关参数时，需要同步检查 mask、bank、beat count 逻辑。

## 15. 推荐阅读顺序

建议按下面顺序阅读代码：

1. `include/rni_param.v`
   - 先理解所有参数，尤其是 AXI/CHI 位宽和 entry 数量。

2. `include/axi4_defines.v` 与 `include/chie_defines.v`
   - 理解 AXI channel bus 和 CHI flit 字段布局。

3. `rni/rni.v`
   - 看顶层端口和模块连接，建立整体框图。

4. `rni/rni_axi_bus.v`
   - 理解 AXI 字段如何打包/解包。

5. `rni/rni_awlink.v`、`rni/rni_arlink.v`
   - 理解 AW/AR 入口 FIFO 和 segburst 调用。

6. `rni/rni_segburst.v`
   - 重点理解 burst 切分、WRAP/INCR 地址处理、dmask/bc_vec 生成。

7. `rni/rni_link_ctl.v`
   - 理解 CHI flit 发送、接收、credit 和 link handshake。

8. `rni/rni_arctrl.v`
   - 读路径主控制，重点看 entry 分配、TXREQ 生成、RXDAT 跟踪、R 返回。

9. `rni/rni_rd_buffer.v`
   - 看 RXDAT 如何写 bank，如何恢复 AXI R。

10. `rni/rni_awctrl.v`
    - 写路径主控制，重点看 DBID/Comp/Retry、TXDAT ready、CompAck、B response。

11. `rni/rni_wr_buffer.v`
    - 看 W 数据缓存、写 data bank、TXDAT 组包、B FIFO。

12. `rni/rni_misc.v`
    - 看 PCRDGrant 如何被提取和分配给 AW/AR retry entry。

## 16. 面试表达版本

可以这样概括这个 RNI：

```text
该 RNI 模块实现 AXI4 master 到 CHI-E 网络侧的请求节点接口。AXI 侧接收 AW/W/AR 请求，通过 awlink/arlink 和 segburst 将 AXI burst 切分为 cache-line 粒度 CHI 请求；读路径由 arctrl 生成 ReadOnce，接收 RXDAT 后通过 rd_buffer 按 TxnID/DataID 重组为 AXI R；写路径由 awctrl 生成 WriteUniquePtl，wr_buffer 缓存 W 数据并在 DBID/Comp 条件满足后发送 TXDAT，最终返回 AXI B。模块支持读写 entry 化 outstanding、同 ID 顺序依赖控制、RetryAck/PCRDGrant 重发，以及 CHI link active 和 L-credit 流控。
```

## 17. 一句话理解

```text
RNI 的核心价值是：把 AXI 的五通道事务模型，转换成 CHI 的 flit + TxnID + credit + retry 模型，同时用 entry 和 buffer 保存 AXI 事务上下文，确保响应回来后还能恢复成 AXI 所要求的 RID/BID、RDATA/BRESP 和同 ID 顺序。
```
