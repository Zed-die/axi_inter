# rni_rd_buffer 设计说明

## 1. 模块定位

`rni_rd_buffer` 是 RNI 读返回路径上的数据缓存和 AXI R 通道发送模块。它位于 `rni_link_ctl`、`rni_arctrl` 和 `rni_axi_bus` 之间。

整体数据流可以概括为：

```text
CHI RXDAT flit
    -> rni_rd_buffer
        -> 解析 TxnID/DataID 并通知 rni_arctrl
        -> 按 entry index 和 bank index 写入本地 data bank

rni_arctrl
    -> 判断哪个 entry 的哪个 bank 可以返回 AXI R 通道
    -> 给 rni_rd_buffer 发送读返回调度

rni_rd_buffer
    -> 根据 entry index + ctmask 读出 data bank
    -> 组装 AXI R channel
    -> 经 rd_fifo 输出到 AXI master
```

所以 `rni_rd_buffer` 不负责发 CHI TXREQ，也不负责维护 read entry 的 dependency/order。它的主要职责是：

1. 接收 CHI RXDAT，并把真实 data payload 存入 `rni_datbuf_bank`。
2. 把 RXDAT 的 `TxnID/DataID` 旁路给 `rni_arctrl`，让 `rni_arctrl` 更新 `arctrl_entry_rvmask_q`。
3. 接收 `rni_arctrl` 的 AXI RDATA 返回调度，从 data bank 读出对应数据。
4. 通过 `rp_fifo`、`bcount_q`、`rd_fifo` 生成 AXI R channel 输出。

## 2. 关键概念

### 2.1 entry

`rni_arctrl` 发 CHI ReadOnce TXREQ 时，会把 AR entry index 编进 CHI `TxnID`。RXDAT 返回时，`rni_rd_buffer` 使用 RXDAT `TxnID` 作为 data bank 的写地址。

```text
RXDAT.TxnID -> read entry index -> datbankX_q[entry]
```

因此每个 AR entry 在 `rni_rd_buffer` 中拥有一组 4 个 bank 的缓存位置。

### 2.2 bank

`rni_datbuf_bank` 内部固定有 4 个 data bank：

```verilog
datbank0_q[RNI_AR_ENTRIES_NUM_PARAM-1:0]
datbank1_q[RNI_AR_ENTRIES_NUM_PARAM-1:0]
datbank2_q[RNI_AR_ENTRIES_NUM_PARAM-1:0]
datbank3_q[RNI_AR_ENTRIES_NUM_PARAM-1:0]
```

每个 bank 的宽度是：

```verilog
`RNI_RD_BANK_DATA_WIDTH = 128
```

也就是 16B。4 个 bank 合起来对应一条 64B cacheline：

```text
bank0: offset 0x00 ~ 0x0f
bank1: offset 0x10 ~ 0x1f
bank2: offset 0x20 ~ 0x2f
bank3: offset 0x30 ~ 0x3f
```

### 2.3 DataID

`rxdatflit_d1_i[`CHIE_DAT_FLIT_DATAID_RANGE]` 用于表示 RXDAT data payload 对应 cacheline 内的哪一部分。

在当前断言约束下：

```verilog
CHIE_DATA_WIDTH_PARAM == 256
AXI4_AXDATA_WIDTH_PARAM == 128
```

也就是一个 CHI RXDAT flit 携带 256 bit = 32B 数据，而内部 bank 是 128 bit = 16B，所以一个 RXDAT flit 会写两个相邻 bank：

| `dataid_d2_q` | 写入 bank | 数据切片 |
|---|---|---|
| `2'b00` | bank0、bank1 | `data_d2_q[127:0]` -> bank0，`data_d2_q[255:128]` -> bank1 |
| `2'b10` | bank2、bank3 | `data_d2_q[127:0]` -> bank2，`data_d2_q[255:128]` -> bank3 |

代码里也保留了 `CHIE_DATA_WIDTH_PARAM == 128` 和 `512` 的 generate 分支，但 assertion 表明当前主要验证目标是 `CHIE_DATA_WIDTH_PARAM == 256`。

### 2.4 ctmask

`arctrl_rb_ctmask_d4_i` 来自 `rni_arctrl`，表示当前要从哪个 bank 读数据返回 AXI。

```text
arctrl_rb_ctmask_d4_i[0] -> bank0
arctrl_rb_ctmask_d4_i[1] -> bank1
arctrl_rb_ctmask_d4_i[2] -> bank2
arctrl_rb_ctmask_d4_i[3] -> bank3
```

在当前 `AXI4_AXDATA_WIDTH_PARAM == 128` 的配置下，`arctrl_rb_ctmask_d4_i` 正常应当是 one-hot。也就是说一次调度一个 16B bank，刚好形成一个 128-bit AXI R beat 的 data payload。

### 2.5 BC

`arctrl_rb_bc_d4_i` 是当前 bank 对应的 beat count，来自 `rni_arctrl` 从 `arctrl_entry_bcvec_q` 中选出的 bank-local `BC`。

它的语义是：

```text
BC = 当前 bank 需要输出的 AXI R beat 数量 - 1
```

例如：

```text
BC = 0 -> 当前 bank 输出 1 个 AXI R beat
BC = 3 -> 当前 bank 输出 4 个 AXI R beat
```

`rni_rd_buffer` 使用 `bcount_q` 控制一个 `rp_fifo` entry 要在 `rd_fifo` 中展开多少个 AXI R beat，并保证 `RLAST` 只在最后一个 beat 拉高。

## 3. 端口分组

### 3.1 来自 rni_link_ctl

```verilog
rxdatflitv_d1_i
rxdatflit_d1_i
```

这是 CHI DAT 通道返回的 RXDAT flit。`rni_rd_buffer` 从 `rxdatflit_d1_i` 中解析：

```verilog
txnid_d1_w
dataid_d1_w
data_d1_w
resperr_d1_w
```

### 3.2 输出给 rni_arctrl

```verilog
rxdatflitv_d1_o
rxdatflit_txnid_d1_o
rxdatflit_dataid_d1_o
rp_fifo_acpt_d4_o
```

前三个信号把 RXDAT 的到达信息转发给 `rni_arctrl`：

```text
rxdatflitv_d1_o       -> 当前有 RXDAT 到达
rxdatflit_txnid_d1_o  -> RXDAT 属于哪个 entry
rxdatflit_dataid_d1_o -> RXDAT 属于 cacheline 哪个 data chunk
```

`rni_arctrl` 使用这些信号更新：

```verilog
arctrl_entry_rvmask_q
rxdat_recv_done_vec_r
```

`rp_fifo_acpt_d4_o` 表示 `rni_rd_buffer` 已经接收了 `rni_arctrl` 发来的一次 RDATA 返回调度。`rni_arctrl` 会据此推进：

```verilog
arctrl_entry_pdmask_q
arctrl_entry_ctmask_q
arctrl_entry_dealloc_vec_w
```

### 3.3 来自 rni_arctrl

```verilog
arctrl_rb_valid_d4_i
arctrl_rb_idx_d4_i
arctrl_rb_ctmask_d4_i
arctrl_rb_rlast_d4_i
arctrl_rb_rid_d4_i
arctrl_rb_bc_d4_i
```

这组信号描述一次 AXI RDATA 返回调度：

| 信号 | 含义 |
|---|---|
| `arctrl_rb_valid_d4_i` | 当前 D4 有有效 RDATA 返回调度 |
| `arctrl_rb_idx_d4_i` | 要读取的 AR entry index |
| `arctrl_rb_ctmask_d4_i` | 要读取哪个 16B bank |
| `arctrl_rb_rlast_d4_i` | 当前 bank 是否对应原始 AXI burst 的最后部分 |
| `arctrl_rb_rid_d4_i` | AXI `RID` |
| `arctrl_rb_bc_d4_i` | 当前 bank 需要输出的 AXI beat count |

### 3.4 输出给 rni_axi_bus

```verilog
R_CH_S0
RVALID0
RREADY0
```

`R_CH_S0` 是打包后的 AXI R channel：

```text
RID
RDATA
RRESP
RLAST
```

`RVALID0` 由 `rd_fifo` 非空产生：

```verilog
assign RVALID0 = ~rd_fifo_empty_w;
assign R_CH_S0 = rd_fifo_data_out_d6_w;
```

`RREADY0` 来自 AXI master 侧，用来 pop `rd_fifo`。

## 4. 内部流水和数据路径

模块可以按 D1 到 D6 理解：

```text
D1:
  解析 RXDAT flit，得到 TxnID/DataID/Data/RespErr。
  同时把 valid/TxnID/DataID 旁路给 rni_arctrl。

D2:
  锁存 RXDAT 字段。
  根据 DataID 和 TxnID 写入 rni_datbuf_bank。

D3:
  按 entry/bank 记录 RespErr。

D4:
  接收 rni_arctrl 的 RDATA 返回调度。
  根据 entry index 和 ctmask 读 data bank。
  组装 AXI R payload，并 push 到 rp_fifo。

D5:
  从 rp_fifo 取 pending RDATA。
  根据 BC 通过 bcount_q 展开一个或多个 AXI R beat。
  push 到 rd_fifo。

D6:
  rd_fifo 输出 AXI R channel。
```

## 5. RXDAT 写入路径

### 5.1 RXDAT 字段解析

代码直接从 `rxdatflit_d1_i` 中切字段：

```verilog
assign txnid_d1_w   = rxdatflit_d1_i[`CHIE_DAT_FLIT_TXNID_RANGE];
assign dataid_d1_w  = rxdatflit_d1_i[`CHIE_DAT_FLIT_DATAID_RANGE];
assign data_d1_w    = rxdatflit_d1_i[`CHIE_DAT_FLIT_DATA_RANGE];
assign resperr_d1_w = rxdatflit_d1_i[`CHIE_DAT_FLIT_RESPERR_RANGE];
```

其中只有 `TxnID/DataID/valid` 会转发给 `rni_arctrl`：

```verilog
assign rxdatflitv_d1_o       = rxdatflitv_d1_i;
assign rxdatflit_txnid_d1_o  = txnid_d1_w;
assign rxdatflit_dataid_d1_o = dataid_d1_w;
```

真实数据 `data_d1_w` 不进入 `rni_arctrl`，而是在本模块内写入 `rni_datbuf_bank`。

### 5.2 D2 锁存

当 `rxdatflitv_d1_i` 为 1 时，模块锁存：

```verilog
dataid_d2_q
data_d2_q
txnid_d2_q
resperr_d2_q
```

`rxdatflitv_d2_q` 每拍跟随 `rxdatflitv_d1_i`。

### 5.3 写 data bank

当前主要配置是 `CHIE_DATA_WIDTH_PARAM == 256`。写入规则为：

```verilog
bank0_wr_en_d2_w = (dataid_d2_q == 2'b00) & rxdatflitv_d2_q;
bank1_wr_en_d2_w = bank0_wr_en_d2_w;

bank2_wr_en_d2_w = (dataid_d2_q == 2'b10) & rxdatflitv_d2_q;
bank3_wr_en_d2_w = bank2_wr_en_d2_w;
```

写地址统一是：

```verilog
bankX_wr_addr_d2_w = txnid_d2_q;
```

也就是说：

```text
RXDAT.TxnID 选择 entry
RXDAT.DataID 选择 bank 组
RXDAT.Data 写入对应 bank
```

例子：

```text
txnid_d2_q  = 5
dataid_d2_q = 2'b00

data_d2_q[127:0]   -> datbank0_q[5]
data_d2_q[255:128] -> datbank1_q[5]
```

再比如：

```text
txnid_d2_q  = 5
dataid_d2_q = 2'b10

data_d2_q[127:0]   -> datbank2_q[5]
data_d2_q[255:128] -> datbank3_q[5]
```

### 5.4 写 RespErr

模块还维护每个 entry、每个 bank 的 `RespErr`：

```verilog
resperr_bank_d3_q[entry][bank]
```

在 `CHIE_DATA_WIDTH_PARAM == 256` 时：

```text
DataID 00 -> resperr_bank_d3_q[entry][0] 和 [1]
DataID 10 -> resperr_bank_d3_q[entry][2] 和 [3]
```

后续 `rni_arctrl` 调度某个 bank 返回 AXI 时，本模块会根据 `arctrl_rb_idx_d4_i` 和 `arctrl_rb_ctmask_d4_i` 取出对应 bank 的 `RespErr`，作为 AXI `RRESP`。

## 6. rni_datbuf_bank

`rni_rd_buffer` 实例化了 `rni_datbuf_bank`：

```verilog
rni_datbuf_bank rni_datbuf_bank_inst (...)
```

`rni_datbuf_bank` 本质是 4 个并行的 128-bit data buffer bank：

```text
bank0[entry]
bank1[entry]
bank2[entry]
bank3[entry]
```

写入是同步写：

```text
posedge clk_i 时，如果 bankX_wr_en_i 为 1，则写 datbankX_q[bankX_wr_addr_i]
```

读出是组合读：

```text
如果 bankX_rd_en_i 为 1，则输出 datbankX_q[bankX_rd_addr_i]
```

这个模块不理解 CHI/AXI 协议，也不处理 ordering。它只是按照 entry index 保存和读出 16B data bank。

## 7. arctrl 调度读 bank 路径

当 `rni_arctrl` 判断某个 entry 的某个 bank 可以返回 AXI 时，会送出：

```verilog
arctrl_rb_valid_d4_i
arctrl_rb_idx_d4_i
arctrl_rb_ctmask_d4_i
```

`rni_rd_buffer` 只有在 `rp_fifo` 未满时才接收：

```verilog
assign rp_fifo_avail_d4_w = ~rp_fifo_full_w;
```

每个 bank 的读使能由下面逻辑产生：

```verilog
data_bank_vec_d4_w[bank] =
    arctrl_rb_valid_d4_i &
    rp_fifo_avail_d4_w &
    arctrl_rb_ctmask_d4_i[bank];
```

所以：

```verilog
assign rp_fifo_acpt_d4_o = |data_bank_vec_d4_w;
```

含义是：

```text
只要 arctrl 有 valid、rp_fifo 未满、ctmask 选择了某个 bank，
rni_rd_buffer 就接收本次调度，并向 rni_arctrl 返回 rp_fifo_acpt_d4_o。
```

读地址为：

```verilog
data_bank_idx_d4_w[bank] = arctrl_rb_idx_d4_i;
```

即从当前 entry 的对应 bank 中读数据。

## 8. AXI RDATA 组包

### 8.1 当前主要配置：AXI4_AXDATA_WIDTH_PARAM == 128

断言要求：

```verilog
AXI4_AXDATA_WIDTH_PARAM == 128
```

所以一个 AXI R beat 宽度是 128 bit，刚好等于一个 `rni_datbuf_bank` bank 的宽度。

组包逻辑是：

```verilog
rdata_data_d4_w =
    ctmask[0] ? bank0_rd_data :
    ctmask[1] ? bank1_rd_data :
    ctmask[2] ? bank2_rd_data :
    ctmask[3] ? bank3_rd_data : 0;
```

RTL 使用 mask OR 写法实现：

```verilog
assign rdata_data_d4_w =
    {`AXI4_RDATA_WIDTH{data_bank_ctmask_d4_w[0]}} & rdata_128_d4_w[0] |
    {`AXI4_RDATA_WIDTH{data_bank_ctmask_d4_w[1]}} & rdata_128_d4_w[1] |
    {`AXI4_RDATA_WIDTH{data_bank_ctmask_d4_w[2]}} & rdata_128_d4_w[2] |
    {`AXI4_RDATA_WIDTH{data_bank_ctmask_d4_w[3]}} & rdata_128_d4_w[3];
```

`RRESP` 的选择方式相同，只是数据源是 `data_bank_resperr_d4_w[bank]`。

### 8.2 AXI4_AXDATA_WIDTH_PARAM == 256 分支

代码中还保留了 256-bit AXI RDATA 组包分支：

```text
ctmask[0] & ctmask[1] -> RDATA = {bank1, bank0}
ctmask[2] & ctmask[3] -> RDATA = {bank3, bank2}
```

但当前 assertion 要求 `AXI4_AXDATA_WIDTH_PARAM == 128`，所以阅读和验证时应优先按照 128-bit AXI RDATA 配置理解。

## 9. rp_fifo

`rp_fifo` 是 read pending FIFO。它保存 D4 阶段已经从 data bank 读出的 AXI R 返回信息，以及额外的 `BC` 字段。

写入条件：

```verilog
assign rp_fifo_push_d4_w = rp_fifo_acpt_d4_o;
```

写入内容：

```verilog
rp_fifo_data_in_d4_w[`AXI4_RID_RANGE]   = rdata_rid_d4_w;
rp_fifo_data_in_d4_w[`AXI4_RDATA_RANGE] = rdata_data_d4_w;
rp_fifo_data_in_d4_w[`AXI4_RRESP_RANGE] = rdata_resperr_d4_w;
rp_fifo_data_in_d4_w[`AXI4_RLAST_RANGE] = rdata_last_d4_w;
rp_fifo_data_in_d4_w[`AXI4_RLAST_MSB+`RNI_BC_WIDTH:`AXI4_RLAST_MSB+1] = rdata_bc_d4_w;
```

可以把 `rp_fifo` 的每条记录理解成：

```text
{BC, RLAST, RRESP, RDATA, RID}
```

`rp_fifo` 的 pop 条件是：

```verilog
assign rp_fifo_pop_d5_w = ~rp_fifo_empty_w & bcount_done_w;
```

也就是当前这条 pending 记录对应的 beat count 已经展开完成，才 pop 下一条。

## 10. beat count 控制

`bcount_q` 用于控制一个 `rp_fifo` entry 需要向 `rd_fifo` 输出多少个 AXI R beat。

相关逻辑：

```verilog
assign bcount_v_d5_w = ~rp_fifo_empty_w & ~rd_fifo_full_w;
assign bcount_d5_w   = rp_fifo_data_out_d5_w[`AXI4_RLAST_MSB+`RNI_BC_WIDTH:`AXI4_RLAST_MSB+1];
assign bcount_w      = (bcount_q == 0) ? bcount_d5_w : (bcount_q - 1'b1);
```

行为可以理解为：

```text
如果 bcount_q 当前为 0，说明刚开始处理一条 rp_fifo 记录，装载 bcount_d5_w。
如果 bcount_q 当前非 0，说明这条记录还要继续输出，bcount_q 每个有效输出 beat 减 1。
```

完成判断：

```verilog
assign bcount_zero_w = (bcount_d5_w == 0) | (bcount_w == 0);
assign bcount_done_w = bcount_v_d5_w & bcount_zero_w;
```

例子：

```text
BC = 0:
  输出 1 个 AXI R beat，当拍 bcount_done_w 为 1，rp_fifo 可以 pop。

BC = 2:
  输出 3 个 AXI R beat。
  前两个 beat 不 pop rp_fifo，最后一个 beat bcount_done_w 为 1。
```

注意：如果 `BC > 0`，本模块会重复使用同一条 `rp_fifo_data_out_d5_w` 的 `RDATA/RRESP/RID` 输出多个 AXI R beat。这个语义依赖上游 `rni_segburst` 对窄读请求的 `BC` 编码和数据组织方式。

## 11. rd_fifo 和 AXI R 输出

`rd_fifo` 是面向 AXI R channel 的 dispatch FIFO。

push 条件：

```verilog
assign rd_fifo_push_d5_w = bcount_v_d5_w & ~rd_fifo_full_w;
```

pop 条件：

```verilog
assign rd_fifo_pop_d5_w = RREADY0 & RVALID0;
```

写入内容来自 `rp_fifo_data_out_d5_w`：

```verilog
rd_fifo_data_in_d5_w[`AXI4_RID_RANGE]   = rp_fifo_data_out_d5_w[`AXI4_RID_RANGE];
rd_fifo_data_in_d5_w[`AXI4_RDATA_RANGE] = rp_fifo_data_out_d5_w[`AXI4_RDATA_RANGE];
rd_fifo_data_in_d5_w[`AXI4_RRESP_RANGE] = rp_fifo_data_out_d5_w[`AXI4_RRESP_RANGE];
```

`RLAST` 有额外约束：

```verilog
rd_fifo_data_in_d5_w[`AXI4_RLAST_RANGE] =
    rp_fifo_data_out_d5_w[`AXI4_RLAST_RANGE] &
    bcount_v_d5_w &
    bcount_zero_w;
```

也就是说，`arctrl_rb_rlast_d4_i` 只是说明这条 bank 调度对应原始 AXI burst 的最后部分，但真正输出 AXI `RLAST` 时，还必须等当前 `BC` 展开到最后一个 beat。

输出：

```verilog
assign RVALID0 = ~rd_fifo_empty_w;
assign R_CH_S0 = rd_fifo_data_out_d6_w;
```

## 12. rni_arctrl 与 rni_rd_buffer 的分工

`rni_arctrl` 负责控制和顺序：

```text
AR entry 分配
TXREQ 发送
RetryAck / PCRDGrant
RXDAT 到达状态 arctrl_entry_rvmask_q
RDATA chain
PD/CT/LS/BC 调度
entry dealloc
```

`rni_rd_buffer` 负责数据和 AXI R 输出：

```text
RXDAT data payload 存储
entry/bank 维度的 RespErr 存储
根据 arctrl 调度读出 bank
通过 rp_fifo 和 rd_fifo 输出 AXI R channel
```

两者之间形成一个清晰的控制/数据分离：

```text
RXDAT 到达:
  rni_rd_buffer 存 data
  rni_rd_buffer 通知 rni_arctrl valid/TxnID/DataID
  rni_arctrl 更新 RVMASK

AXI R 返回:
  rni_arctrl 判断哪个 entry/bank 可以返回
  rni_arctrl 输出 arctrl_rb_*_d4_i
  rni_rd_buffer 读 data bank 并输出 AXI R channel
  rni_rd_buffer 用 rp_fifo_acpt_d4_o 通知 arctrl 调度已接收
```

## 13. 典型例子

### 13.1 RXDAT 低 32B 到达

假设：

```text
CHIE_DATA_WIDTH_PARAM = 256
rxdatflitv_d1_i = 1
TxnID  = 5
DataID = 2'b00
Data   = {high_16B, low_16B}
```

D2 写入：

```text
datbank0_q[5] <= low_16B
datbank1_q[5] <= high_16B
```

同时 `rni_rd_buffer` 在 D1 旁路：

```text
rxdatflit_txnid_d1_o  = 5
rxdatflit_dataid_d1_o = 2'b00
```

`rni_arctrl` 据此把该 entry 的低 32B 对应的 RV mask 置位。

### 13.2 arctrl 调度 bank1 返回 AXI

假设 `rni_arctrl` 输出：

```text
arctrl_rb_valid_d4_i  = 1
arctrl_rb_idx_d4_i    = 5
arctrl_rb_ctmask_d4_i = 4'b0010
arctrl_rb_rid_d4_i    = ARID
arctrl_rb_rlast_d4_i  = 0
arctrl_rb_bc_d4_i     = 0
```

如果 `rp_fifo` 未满，则：

```text
data_bank_vec_d4_w[1] = 1
rp_fifo_acpt_d4_o     = 1
```

读出：

```text
bank1_rd_data_d4_w = datbank1_q[5]
```

在 128-bit AXI 配置下：

```text
RDATA = bank1_rd_data_d4_w
RRESP = resperr_bank_d3_q[5][1]
RLAST = 0
RID   = ARID
```

该记录写入 `rp_fifo`，随后进入 `rd_fifo`，最后从 `R_CH_S0` 输出。

### 13.3 最后一个 bank 且 BC 为 2

假设：

```text
arctrl_rb_rlast_d4_i = 1
arctrl_rb_bc_d4_i    = 2
```

含义是当前 bank 是原始 AXI burst 的最后 bank，但它需要展开为 3 个 AXI R beat。

输出行为：

```text
第 1 个 beat: RLAST = 0
第 2 个 beat: RLAST = 0
第 3 个 beat: RLAST = 1
```

这是由：

```verilog
rp_fifo_data_out_d5_w[`AXI4_RLAST_RANGE] & bcount_zero_w
```

保证的。

## 14. 当前断言和设计假设

`ASSERT_CHECKER_ON` 打开时，模块会检查：

1. `CHIE_DATA_WIDTH_PARAM` 必须是 `256`。
2. `AXI4_AXDATA_WIDTH_PARAM` 必须是 `128`。
3. `arctrl_rb_valid_d4_i` 为 1 时，`arctrl_rb_ctmask_d4_i` 不能为 0。
4. RXDAT opcode 必须是 `CHIE_COMPDATA`。
5. RXDAT `TgtID` 必须等于当前 `RNI_NID_PARAM`。
6. RXDAT `RespErr` 不能是 data error 或 non-data error。

因此阅读当前设计时，最重要的默认配置是：

```text
CHI RXDAT flit data width = 256 bit = 32B
AXI RDATA width           = 128 bit = 16B
rni_datbuf_bank bank      = 128 bit = 16B
```

在这个配置下：

```text
一个 RXDAT flit 写两个 bank
一次 arctrl RDATA 调度读一个 bank
一个 bank 通常形成一个 AXI R beat
```

## 15. 阅读建议

建议按下面顺序阅读 `rni_rd_buffer.v`：

1. 先看端口，分清 `rni_link_ctl`、`rni_arctrl`、`rni_axi_bus` 三组接口。
2. 看 D1 decode，理解为什么 `TxnID/DataID` 要旁路给 `rni_arctrl`。
3. 看 `write data bank`，理解 `DataID` 到 bank 的映射。
4. 看 `resperr_bank_d3_q`，理解错误响应如何按 entry/bank 保存。
5. 看 `read data and resperr bank`，理解 `arctrl_rb_ctmask_d4_i` 如何选择 bank。
6. 看 AXI RDATA pack generate，当前重点看 `AXI4_AXDATA_WIDTH_PARAM == 128` 分支。
7. 最后看 `rp_fifo`、`bcount_q`、`rd_fifo`，理解 `BC` 和 `RLAST` 的关系。

一句话总结：

```text
rni_rd_buffer = RXDAT data bank 存储 + arctrl RDATA 调度执行 + AXI R channel FIFO 输出
```
