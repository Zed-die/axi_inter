module dmem(
    input              clk,
    input              ce,
    input      [7:0]   addr,
    input      [127:0] we,
    input      [127:0] wr_data,
    output reg [127:0] rd_data
);

reg [127:0] mem [0:255];

integer i;
integer j;

initial begin
    for (i = 0; i < 256; i = i + 1)
        mem[i] = 128'b0;
end

always @(posedge clk) begin
    if (ce) begin
        rd_data <= mem[addr];
        for (j = 0; j < 128; j = j + 1) begin
            if (we[j])
                mem[addr][j] <= wr_data[j];
        end
    end
end

endmodule
