`include "emoki_defs.v"
module idu(
    input             clk,
    input             rst_n,

    input             flush_id,
    input             stall_id,

    input      [31:0] id_pc,
    input      [31:0] id_inst,
    input             id_pc_valid,
    input             id_pc_unaligned,

    output            rf_rs1_en,
    output     [4:0]  rf_rs1_addr,
    input      [31:0] rf_rs1_data,

    output            rf_rs2_en,
    output     [4:0]  rf_rs2_addr,
    input      [31:0] rf_rs2_data,

    input      [31:0] ex_rd_data,
    input             me_rd_we,
    input             me_load_en,
    input      [4:0]  me_rd_addr,
    input      [31:0] me_rd_data,

    input             wb_rd_we,
    input      [4:0]  wb_rd_addr,
    input      [31:0] wb_rd_data,

    output reg [31:0] ex_pc,
    output reg        ex_pc_valid,
    output reg [31:0] ex_op_data1,
    output reg [31:0] ex_op_data2,
    output reg [31:0] ex_rf_rs2,
    output reg        ex_rd_we,
    output reg [4:0]  ex_rd_addr,
    output reg [3:0]  ex_alu_op,
    output reg        ex_branch,
    output reg [2:0]  ex_branch_funct3,
    output reg        ex_jump,
    output reg        ex_jalr,
    output reg        ex_load_en,
    output reg        ex_store_en,
    output reg [1:0]  ex_mem_size,
    output reg        ex_mem_unsigned,
    output reg        ex_wfi,
    output     [1:0]  id_exception,
    output reg        id_wfi,
    output reg        load_use_hazard,
    output reg [1:0]  ex_exception
);

reg        use_rs1;
reg        use_rs2;
reg [31:0] id_op_data1;
reg [31:0] id_op_data2;
reg [31:0] id_rf_rs2;
reg [31:0] rs2_forward_data;
reg [31:0] imm;
reg [3:0]  alu_op;
reg        branch;
reg        jump;
reg        id_jalr;
reg        id_load_en;
reg        id_store_en;
reg [1:0]  id_mem_size;
reg        id_mem_unsigned;
reg        id_rd_we;
reg        illegal;

wire [6:0] opcode;
wire [2:0] funct3;
wire [6:0] funct7;
wire [4:0] id_rd_addr;
wire       id_has_exception;

assign opcode      = id_inst[6:0];
assign funct3      = id_inst[14:12];
assign funct7      = id_inst[31:25];
assign id_rd_addr  = id_inst[11:7];

assign rf_rs1_en   = use_rs1;
assign rf_rs1_addr = id_inst[19:15];
assign rf_rs2_en   = use_rs2;
assign rf_rs2_addr = id_inst[24:20];

assign id_exception = id_pc_valid ? {illegal, id_pc_unaligned} : 2'b0;
assign id_has_exception = |id_exception;

// forwarding
always @(*) begin
    if (use_rs1 == 1'b1 && ex_rd_we && ex_rd_addr == rf_rs1_addr && !ex_load_en)
        id_op_data1 = ex_rd_data;
    else if (use_rs1 == 1'b1 && me_rd_we && me_rd_addr == rf_rs1_addr && !me_load_en)
        id_op_data1 = me_rd_data;
    else if (use_rs1 == 1'b1 && wb_rd_we && wb_rd_addr == rf_rs1_addr)
        id_op_data1 = wb_rd_data;
    else if (use_rs1 == 1'b1)
        id_op_data1 = rf_rs1_data;
    else
        id_op_data1 = id_pc;
end

always @(*) begin
    if (use_rs2 == 1'b1 && ex_rd_we && ex_rd_addr == rf_rs2_addr && !ex_load_en)
        rs2_forward_data = ex_rd_data;
    else if (use_rs2 == 1'b1 && me_rd_we && me_rd_addr == rf_rs2_addr && !me_load_en)
        rs2_forward_data = me_rd_data;
    else if (use_rs2 == 1'b1 && wb_rd_we && wb_rd_addr == rf_rs2_addr)
        rs2_forward_data = wb_rd_data;
    else
        rs2_forward_data = rf_rs2_data;
end

//只有S和B指令会在use_rs2拉高的时候既要imm又要rs2
always @(*) begin
    if (use_rs2 == 1'b1 && !branch && !id_store_en)
        id_op_data2 = rs2_forward_data;
    else
        id_op_data2 = imm;
end

always @(*) begin
    id_rf_rs2 = rs2_forward_data;
end

// load use hazard
always @(*) begin
    if (ex_load_en && ex_rd_we && ((use_rs1 && ex_rd_addr == rf_rs1_addr) || (use_rs2 && ex_rd_addr == rf_rs2_addr)))
        load_use_hazard = 1'b1;
    else if (me_load_en && me_rd_we && ((use_rs1 && me_rd_addr == rf_rs1_addr) || (use_rs2 && me_rd_addr == rf_rs2_addr)))
        load_use_hazard = 1'b1;
    else
        load_use_hazard = 1'b0;
end

always @(*) begin
    use_rs1             = 1'b0;
    use_rs2             = 1'b0;
    imm                 = 32'b0;
    alu_op              = `ALU_ADD;
    branch              = 1'b0;
    jump                = 1'b0;
    id_jalr             = 1'b0;
    id_load_en          = 1'b0;
    id_store_en         = 1'b0;
    id_mem_size         = `MEM_WORD;
    id_mem_unsigned     = 1'b0;
    id_rd_we            = 1'b0;
    id_wfi              = 1'b0;
    illegal             = 1'b0;
    case (opcode)
        `OPCODE_LUI: begin
            imm      = {id_inst[31:12], 12'b0};
            alu_op   = `ALU_COPY_B;
            id_rd_we = (id_rd_addr != 5'd0);
        end
        `OPCODE_AUIPC: begin
            imm   = {id_inst[31:12], 12'b0};
            id_rd_we = (id_rd_addr != 5'd0);
        end
        `OPCODE_JAL: begin
            imm   = {{11{id_inst[31]}}, id_inst[31], id_inst[19:12], id_inst[20], id_inst[30:21], 1'b0};
            jump  = 1'b1;
            id_rd_we = (id_rd_addr != 5'd0);
        end
        `OPCODE_JALR: begin
            imm     = {{20{id_inst[31]}}, id_inst[31:20]};
            use_rs1 = 1'b1;
            jump    = 1'b1;
            id_jalr = 1'b1;
            id_rd_we   = (id_rd_addr != 5'd0);
            if (funct3 != 3'b000)
                illegal = 1'b1;
        end
        `OPCODE_BRANCH: begin
            imm     = {{19{id_inst[31]}}, id_inst[31], id_inst[7], id_inst[30:25], id_inst[11:8], 1'b0};
            use_rs1 = 1'b1;
            use_rs2 = 1'b1;
            branch  = 1'b1;
            if (!(funct3 == 3'b000 || funct3 == 3'b001 || funct3 == 3'b100 ||
                  funct3 == 3'b101 || funct3 == 3'b110 || funct3 == 3'b111)) begin
                illegal = 1'b1;
            end
        end
        `OPCODE_LOAD: begin
            imm      = {{20{id_inst[31]}}, id_inst[31:20]};
            use_rs1  = 1'b1;
            id_load_en = 1'b1;
            id_rd_we    = (id_rd_addr != 5'd0);

            case (funct3)
                3'b000: begin
                    id_mem_size     = `MEM_BYTE;
                    id_mem_unsigned = 1'b0;
                end
                3'b001: begin
                    id_mem_size     = `MEM_HALF;
                    id_mem_unsigned = 1'b0;
                end
                3'b010: begin
                    id_mem_size     = `MEM_WORD;
                    id_mem_unsigned = 1'b0;
                end
                3'b100: begin
                    id_mem_size     = `MEM_BYTE;
                    id_mem_unsigned = 1'b1;
                end
                3'b101: begin
                    id_mem_size     = `MEM_HALF;
                    id_mem_unsigned = 1'b1;
                end
                default: illegal = 1'b1;
            endcase
        end
        `OPCODE_STORE: begin
            imm       = {{20{id_inst[31]}}, id_inst[31:25], id_inst[11:7]};
            use_rs1   = 1'b1;
            use_rs2   = 1'b1;
            id_store_en = 1'b1;

            case (funct3)
                3'b000: id_mem_size = `MEM_BYTE;
                3'b001: id_mem_size = `MEM_HALF;
                3'b010: id_mem_size = `MEM_WORD;
                default: illegal = 1'b1;
            endcase
        end
        `OPCODE_OP_IMM: begin
            imm     = {{20{id_inst[31]}}, id_inst[31:20]};
            use_rs1 = 1'b1;
            id_rd_we   = (id_rd_addr != 5'd0);

            case (funct3)
                3'b000: alu_op = `ALU_ADD;
                3'b010: alu_op = `ALU_SLT;
                3'b011: alu_op = `ALU_SLTU;
                3'b100: alu_op = `ALU_XOR;
                3'b110: alu_op = `ALU_OR;
                3'b111: alu_op = `ALU_AND;
                3'b001: begin
                    alu_op = `ALU_SLL;
                    imm    = {27'b0, id_inst[24:20]};
                    if (funct7 != 7'b0000000) illegal = 1'b1;
                end
                3'b101: begin
                    imm = {27'b0, id_inst[24:20]};
                    if (funct7 == 7'b0000000) alu_op = `ALU_SRL;
                    else if (funct7 == 7'b0100000) alu_op = `ALU_SRA;
                    else illegal = 1'b1;
                end
                default: illegal = 1'b1;
            endcase
        end
        `OPCODE_OP: begin
            use_rs1 = 1'b1;
            use_rs2 = 1'b1;
            id_rd_we   = (id_rd_addr != 5'd0);
            case ({funct7, funct3})
                {7'b0000000, 3'b000}: alu_op = `ALU_ADD;
                {7'b0100000, 3'b000}: alu_op = `ALU_SUB;
                {7'b0000000, 3'b001}: alu_op = `ALU_SLL;
                {7'b0000000, 3'b010}: alu_op = `ALU_SLT;
                {7'b0000000, 3'b011}: alu_op = `ALU_SLTU;
                {7'b0000000, 3'b100}: alu_op = `ALU_XOR;
                {7'b0000000, 3'b101}: alu_op = `ALU_SRL;
                {7'b0100000, 3'b101}: alu_op = `ALU_SRA;
                {7'b0000000, 3'b110}: alu_op = `ALU_OR;
                {7'b0000000, 3'b111}: alu_op = `ALU_AND;
                default: illegal = 1'b1;
            endcase
        end
        `OPCODE_SYSTEM: begin
            if (id_inst == 32'h1050_0073) begin
                id_wfi = 1'b1;
            end
            else begin
                illegal = 1'b1;
            end
        end
        default: illegal = 1'b1;
    endcase
end

always @(posedge clk or negedge rst_n) begin
    if (rst_n == 1'b0)
        ex_rd_we <= 1'b0;
    else if (stall_id)
        ex_rd_we <= 1'b0;
    else if (flush_id)
        ex_rd_we <= 1'b0;
    else
        ex_rd_we <= id_pc_valid && !id_has_exception && id_rd_we;
end

always @(posedge clk or negedge rst_n) begin
    if (rst_n == 1'b0)
        ex_pc_valid <= 1'b0;
    else if (flush_id)
        ex_pc_valid <= 1'b0;
    else if (stall_id)
        ex_pc_valid <= 1'b0;
    else
        ex_pc_valid <= id_pc_valid;
end

always @(posedge clk) begin
    if (flush_id == 1'b0 && stall_id == 1'b0 && id_pc_valid == 1'b1)
        ex_pc <= id_pc;
end

always @(posedge clk) begin
    if (flush_id == 1'b1) begin
        ex_wfi       <= 1'b0;
        ex_exception <= 2'b0;
    end
    else if (stall_id == 1'b1) begin
        ex_wfi       <= 1'b0;
        ex_exception <= 2'b0;
    end
    else if (id_pc_valid) begin
        ex_wfi       <= id_has_exception ? 1'b0 : id_wfi;
        ex_exception <= id_exception;
    end
    else begin
        ex_wfi       <= 1'b0;
        ex_exception <= 2'b0;
    end
end

always @(posedge clk) begin
    if (flush_id == 1'b1 || stall_id == 1'b1 || id_pc_valid == 1'b0 || id_has_exception == 1'b1) begin
        ex_op_data1      <= 32'b0;
        ex_op_data2      <= 32'b0;
        ex_rf_rs2        <= 32'b0;
        ex_rd_addr       <= 5'b0;
        ex_alu_op        <= 4'b0;
        ex_branch        <= 1'b0;
        ex_branch_funct3 <= 3'b0;
        ex_jump          <= 1'b0;
        ex_jalr          <= 1'b0;
        ex_load_en       <= 1'b0;
        ex_store_en      <= 1'b0;
        ex_mem_size      <= 2'b0;
        ex_mem_unsigned  <= 1'b0;
    end
    else begin
        ex_op_data1      <= id_op_data1;
        ex_op_data2      <= id_op_data2;
        ex_rf_rs2        <= id_rf_rs2;
        ex_rd_addr       <= id_rd_addr;
        ex_alu_op        <= alu_op;
        ex_branch        <= branch;
        ex_branch_funct3 <= funct3;
        ex_jump          <= jump;
        ex_jalr          <= id_jalr;
        ex_load_en       <= id_load_en;
        ex_store_en      <= id_store_en;
        ex_mem_size      <= id_mem_size;
        ex_mem_unsigned  <= id_mem_unsigned;
    end
end

endmodule
