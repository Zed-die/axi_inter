module ifu(
    input             clk,
    input             rst_n,
    input             start_pulse_sync,
    input      [31:0] start_pc_sync,
    input             flush_if,
    input             stall_if,

    input             if_pc_valid_next,
    input             redirect_en,
    input      [31:0] redirect_pc,
    output reg        imm_ce,
    output reg [7:0]  imm_addr,
    input      [31:0] imm_data,

    output reg [31:0] id_pc,
    output reg [31:0] id_inst,
    output reg        id_pc_unaligned,
    output reg        id_pc_valid
);

reg [31:0] if_pc_next;
reg [31:0] if_pc_reg;
reg        if_pc_valid;

wire if_pc_unaligned;
assign if_pc_unaligned = if_pc_reg[1:0] != 0;

always @(*) begin
    if (start_pulse_sync)
        if_pc_next = start_pc_sync;
    else if (redirect_en)
        if_pc_next = redirect_pc;
    else if (stall_if)
        if_pc_next = if_pc_reg;
    else if (if_pc_valid_next)
        if_pc_next = if_pc_reg + 4;
    else
        if_pc_next = 32'b0;
end

always @(posedge clk or negedge rst_n) begin
    if(rst_n == 1'b0)begin
        if_pc_reg   <= 32'b0;
        if_pc_valid <= 1'b0;
    end else begin
        if_pc_reg   <= if_pc_next;
        if_pc_valid <= if_pc_valid_next;
    end
end

always @(*) begin
    imm_ce   = if_pc_valid_next;
    imm_addr = if_pc_next[9:2];
end

always @(posedge clk or negedge rst_n) begin
    if (rst_n == 1'b0) begin
        id_pc_valid     <= 1'b0;
        id_pc_unaligned <= 1'b0;
    end
    else if (flush_if) begin
        id_pc_valid     <= 1'b0;
        id_pc_unaligned <= 1'b0;
    end
    else if (stall_if) begin
        id_pc_valid     <= id_pc_valid;
        id_pc_unaligned <= id_pc_unaligned;
    end
    else begin
        id_pc_valid     <= if_pc_valid;
        id_pc_unaligned <= if_pc_unaligned;
    end
end

always @(posedge clk) begin
    if (stall_if) begin
        id_pc   <= id_pc;
        id_inst <= id_inst;
    end
    else if(if_pc_valid)begin
        id_pc   <= if_pc_reg;
        id_inst <= imm_data;
    end
end

endmodule
