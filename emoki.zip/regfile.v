module regfile(
    input             clk,
    input             rst_n,

    input             rs1_en,
    input      [4:0]  rs1_addr,
    output     [31:0] rs1_data,

    input             rs2_en,
    input      [4:0]  rs2_addr,
    output     [31:0] rs2_data,

    input             rd_we,
    input      [4:0]  rd_addr,
    input      [31:0] rd_data
);

reg [31:0] rf [0:31];

integer i;

assign rs1_data = (rs1_en && rs1_addr != 5'b0) ? rf[rs1_addr] : 32'b0;
assign rs2_data = (rs2_en && rs2_addr != 5'b0) ? rf[rs2_addr] : 32'b0;

always @(posedge clk or negedge rst_n) begin
    if (rst_n == 1'b0) begin
        for (i = 0; i < 32; i = i + 1)
            rf[i] <= 32'b0;
    end
    else if (rd_we && rd_addr != 5'b0) begin
        rf[rd_addr] <= rd_data;
    end
end

endmodule
