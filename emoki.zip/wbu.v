`include "emoki_defs.v"
module wbu(
    input             wb_rd_we,
    input  [127:0]    wb_rdata,
    input  [4:0]      wb_rd_addr,
    input  [31:0]     wb_rd_data,
    input  [3:0]      wb_load_sel,
    input             wb_load_en,
    input  [2:0]      wb_load_size,

    output reg        rf_rd_we,
    output reg [4:0]  rf_rd_addr,
    output reg [31:0] rf_rd_data
);

always@(*)begin
    rf_rd_addr = wb_rd_addr;
    rf_rd_we   = wb_rd_we;
    if(wb_load_en == 1'b1)begin
        case(wb_load_size)
            `LB: rf_rd_data = {{24{wb_rdata[{wb_load_sel,3'b0}+7]}}, wb_rdata[{wb_load_sel,3'b0}+:8]};
            `LH: rf_rd_data = {{16{wb_rdata[{wb_load_sel,3'b0}+15]}}, wb_rdata[{wb_load_sel,3'b0}+:16]};
            `LW: rf_rd_data = wb_rdata[{wb_load_sel,3'b0}+:32];
            `LBU:rf_rd_data = {24'b0, wb_rdata[{wb_load_sel,3'b0}+:8]};
            `LHU:rf_rd_data = {16'b0, wb_rdata[{wb_load_sel,3'b0}+:16]};
            default:rf_rd_data = 32'b0;
        endcase
    end
    else
        rf_rd_data = wb_rd_data;
end


endmodule