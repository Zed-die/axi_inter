`define  OPCODE_LOAD     7'b0000011
`define  OPCODE_OP_IMM   7'b0010011
`define  OPCODE_AUIPC    7'b0010111
`define  OPCODE_STORE    7'b0100011
`define  OPCODE_OP       7'b0110011
`define  OPCODE_LUI      7'b0110111
`define  OPCODE_BRANCH   7'b1100011
`define  OPCODE_JALR     7'b1100111
`define  OPCODE_JAL      7'b1101111
`define  OPCODE_SYSTEM   7'b1110011

`define  ALU_ADD    4'd0
`define  ALU_SUB    4'd1
`define  ALU_SLL    4'd2
`define  ALU_SLT    4'd3
`define  ALU_SLTU   4'd4
`define  ALU_XOR    4'd5
`define  ALU_SRL    4'd6
`define  ALU_SRA    4'd7
`define  ALU_OR     4'd8
`define  ALU_AND    4'd9
`define  ALU_COPY_B 4'd10

`define  WB_ALU     2'd0
`define  WB_MEM     2'd1
`define  WB_PC4     2'd2
`define  WB_CSR     2'd3

`define  MEM_BYTE   2'd0
`define  MEM_HALF   2'd1
`define  MEM_WORD   2'd2

`define  CSR_CMD_NONE 2'd0
`define  CSR_CMD_RW   2'd1
`define  CSR_CMD_RC   2'd2

`define  FWD_RF     2'd0
`define  FWD_EX_MEM 2'd1
`define  FWD_MEM_WB 2'd2

`define  STATUS_IDLE    2'b00
`define  STATUS_RUNNING 2'b01

`define  EXC_NONE        2'b00
`define  EXC_PC_ALIGN    2'b01
`define  EXC_ILLEGAL_MEM 2'b10
 
`define  CSR_STALL_CYCLE 12'h7c0
`define  CSR_MISPREDICT  12'h7c1

`define  LB   3'b000
`define  LH   3'b001
`define  LW   3'b010
`define  LBU  3'b100
`define  LHU  3'b101
