module memu(
    input              clk,
    input              rst_n,

    input              me_rd_we,
    input      [4:0]   me_rd_addr,
    input      [31:0]  me_rd_data,
    input      [3:0]   me_load_sel,
    input              me_load_en,
    input      [2:0]   me_load_size,

    input      [127:0] dmm_rdata,

    output reg         wb_rd_we,
    output reg [127:0] wb_rdata,
    output reg [4:0]   wb_rd_addr,
    output reg [31:0]  wb_rd_data,
    output reg [3:0]   wb_load_sel,
    output reg         wb_load_en,
    output reg [2:0]   wb_load_size
);

always@(posedge clk or negedge rst_n) begin
    if (rst_n == 1'b0)begin
        wb_rd_we <= 1'b0;
        wb_load_en <= 1'b0;
    end
    else begin
        wb_rd_we <= me_rd_we;
        wb_load_en <= me_load_en;
    end
end

always@(posedge clk) begin
    if (me_rd_we == 1'b1) begin
        wb_rdata     <= dmm_rdata;
        wb_rd_addr   <= me_rd_addr;
        wb_rd_data   <= me_rd_data;
        wb_load_sel  <= me_load_sel;
        wb_load_size <= me_load_size;
    end
end

endmodule
