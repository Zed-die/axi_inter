`include "emoki_defs.v"
module exu(
    input              clk,
    input              rst_n,
    input              flush_ex,
    input      [31:0]  ex_pc,
    input              ex_pc_valid,
    input      [31:0]  ex_op_data1,
    input      [31:0]  ex_op_data2,
    input      [31:0]  ex_rf_rs2,
    input              ex_rd_we,
    input      [4:0]   ex_rd_addr,
    input      [3:0]   ex_alu_op,
    input              ex_branch,
    input      [2:0]   ex_branch_funct3,
    input              ex_jump,
    input              ex_jalr,
    input              ex_load_en,
    input              ex_store_en,
    input      [1:0]   ex_mem_size,
    input              ex_mem_unsigned,

    input      [1:0]   ex_exception,
    input              ex_wfi,
    output             redirect_en,
    output     [31:0]  redirect_pc,

    output     [31:0]  ex_rd_data,
    output             dmm_ce,
    output     [7:0]   dmm_addr,
    output     [127:0] dmm_we,
    output     [127:0] dmm_data,

    output reg         me_rd_we,
    output reg [4:0]   me_rd_addr,
    output reg [31:0]  me_rd_data,
    output reg [3:0]   me_load_sel,
    output reg         me_load_en,
    output reg [2:0]   me_load_size,
    output reg [31:0]  me_pc,
    output reg         me_wfi,
    output reg [1:0]   me_exception
);

reg [31:0]  alu_result;
reg         branch_en;
reg [31:0]  branch_pc;
reg [31:0]  ex_rd_data_reg;

reg         dmm_ce_reg;
reg [127:0] dmm_we_reg;
reg [7:0]   dmm_addr_reg;
reg [127:0] dmm_data_reg;

wire redirect_pc_unaligned;
wire [1:0] ex_exception_sum;

assign dmm_ce      = dmm_ce_reg;
assign dmm_addr    = dmm_addr_reg;
assign dmm_we      = dmm_we_reg;
assign dmm_data    = dmm_data_reg;
assign ex_rd_data  = ex_rd_data_reg;

assign redirect_pc_unaligned = ex_pc_valid && (flush_ex == 1'b0) && (|ex_exception == 1'b0) && branch_en && (branch_pc[1:0] != 2'b00);
assign ex_exception_sum      = {ex_exception[1], ex_exception[0] | redirect_pc_unaligned};
assign redirect_en           = ex_pc_valid && (flush_ex == 1'b0) && (|ex_exception == 1'b0) && branch_en && (branch_pc[1:0] == 2'b00);
assign redirect_pc           = branch_pc;

always @(*) begin
    case (ex_alu_op)
        `ALU_ADD:    alu_result = ex_op_data1 + ex_op_data2;
        `ALU_SUB:    alu_result = ex_op_data1 - ex_op_data2;
        `ALU_SLL:    alu_result = ex_op_data1 << ex_op_data2[4:0];
        `ALU_SLT:    alu_result = ($signed(ex_op_data1) < $signed(ex_op_data2)) ? 32'b1 : 32'b0;
        `ALU_SLTU:   alu_result = (ex_op_data1 < ex_op_data2) ? 32'b1 : 32'b0;
        `ALU_XOR:    alu_result = ex_op_data1 ^ ex_op_data2;
        `ALU_SRL:    alu_result = ex_op_data1 >> ex_op_data2[4:0];
        `ALU_SRA:    alu_result = $signed(ex_op_data1) >>> ex_op_data2[4:0];
        `ALU_OR:     alu_result = ex_op_data1 | ex_op_data2;
        `ALU_AND:    alu_result = ex_op_data1 & ex_op_data2;
        `ALU_COPY_B: alu_result = ex_op_data2;
        default:     alu_result = 32'b0;
    endcase
end

always @(*) begin
    case ({ex_jump, ex_branch})
        2'b01: begin
            case (ex_branch_funct3)
                3'b000:  branch_en = (ex_op_data1 == ex_rf_rs2);                  // BEQ
                3'b001:  branch_en = (ex_op_data1 != ex_rf_rs2);                  // BNE
                3'b100:  branch_en = ($signed(ex_op_data1) <  $signed(ex_rf_rs2));// BLT
                3'b101:  branch_en = ($signed(ex_op_data1) >= $signed(ex_rf_rs2));// BGE
                3'b110:  branch_en = (ex_op_data1 <  ex_rf_rs2);                  // BLTU
                3'b111:  branch_en = (ex_op_data1 >= ex_rf_rs2);                  // BGEU
                default: branch_en = 1'b0;
            endcase
        end
        2'b10:   branch_en = 1'b1;
        default: branch_en = 1'b0;
    endcase
end

always @(*) begin
    if (branch_en) begin
        if (ex_branch)
            branch_pc = ex_pc + ex_op_data2;
        else if (ex_jalr)
            branch_pc = {alu_result[31:1], 1'b0};
        else
            branch_pc = alu_result;
    end
    else
        branch_pc = 32'b0;
end

always @(*) begin
    if (ex_jump)
        ex_rd_data_reg = ex_pc + 32'd4;
    else
        ex_rd_data_reg = alu_result;
end

always @(*) begin
    if (ex_store_en) begin
        dmm_ce_reg   = (ex_pc_valid == 1'b1 && flush_ex == 1'b0);
        dmm_addr_reg = alu_result[11:4];
        case (ex_mem_size)
            `MEM_BYTE: begin
                dmm_data_reg = {16{ex_rf_rs2[7:0]}};
                case (alu_result[3:0])
                    4'h0:    dmm_we_reg = 128'h0000_0000_0000_0000_0000_0000_0000_00ff;
                    4'h1:    dmm_we_reg = 128'h0000_0000_0000_0000_0000_0000_0000_ff00;
                    4'h2:    dmm_we_reg = 128'h0000_0000_0000_0000_0000_0000_00ff_0000;
                    4'h3:    dmm_we_reg = 128'h0000_0000_0000_0000_0000_0000_ff00_0000;
                    4'h4:    dmm_we_reg = 128'h0000_0000_0000_0000_0000_00ff_0000_0000;
                    4'h5:    dmm_we_reg = 128'h0000_0000_0000_0000_0000_ff00_0000_0000;
                    4'h6:    dmm_we_reg = 128'h0000_0000_0000_0000_00ff_0000_0000_0000;
                    4'h7:    dmm_we_reg = 128'h0000_0000_0000_0000_ff00_0000_0000_0000;
                    4'h8:    dmm_we_reg = 128'h0000_0000_0000_00ff_0000_0000_0000_0000;
                    4'h9:    dmm_we_reg = 128'h0000_0000_0000_ff00_0000_0000_0000_0000;
                    4'ha:    dmm_we_reg = 128'h0000_0000_00ff_0000_0000_0000_0000_0000;
                    4'hb:    dmm_we_reg = 128'h0000_0000_ff00_0000_0000_0000_0000_0000;
                    4'hc:    dmm_we_reg = 128'h0000_00ff_0000_0000_0000_0000_0000_0000;
                    4'hd:    dmm_we_reg = 128'h0000_ff00_0000_0000_0000_0000_0000_0000;
                    4'he:    dmm_we_reg = 128'h00ff_0000_0000_0000_0000_0000_0000_0000;
                    4'hf:    dmm_we_reg = 128'hff00_0000_0000_0000_0000_0000_0000_0000;
                    default: dmm_we_reg = 128'b0;
                endcase
            end
            `MEM_HALF: begin
                dmm_data_reg = {8{ex_rf_rs2[15:0]}};
                case (alu_result[3:1])
                    3'h0:    dmm_we_reg = 128'h0000_0000_0000_0000_0000_0000_0000_ffff;
                    3'h1:    dmm_we_reg = 128'h0000_0000_0000_0000_0000_0000_ffff_0000;
                    3'h2:    dmm_we_reg = 128'h0000_0000_0000_0000_0000_ffff_0000_0000;
                    3'h3:    dmm_we_reg = 128'h0000_0000_0000_0000_ffff_0000_0000_0000;
                    3'h4:    dmm_we_reg = 128'h0000_0000_0000_ffff_0000_0000_0000_0000;
                    3'h5:    dmm_we_reg = 128'h0000_0000_ffff_0000_0000_0000_0000_0000;
                    3'h6:    dmm_we_reg = 128'h0000_ffff_0000_0000_0000_0000_0000_0000;
                    3'h7:    dmm_we_reg = 128'hffff_0000_0000_0000_0000_0000_0000_0000;
                    default: dmm_we_reg = 128'b0;
                endcase
            end
            `MEM_WORD: begin
                dmm_data_reg = {4{ex_rf_rs2[31:0]}};
                case (alu_result[3:2])
                    2'h0:    dmm_we_reg = 128'h0000_0000_0000_0000_0000_0000_ffff_ffff;
                    2'h1:    dmm_we_reg = 128'h0000_0000_0000_0000_ffff_ffff_0000_0000;
                    2'h2:    dmm_we_reg = 128'h0000_0000_ffff_ffff_0000_0000_0000_0000;
                    2'h3:    dmm_we_reg = 128'hffff_ffff_0000_0000_0000_0000_0000_0000;
                    default: dmm_we_reg = 128'b0;
                endcase
            end
            default: begin
                dmm_data_reg = 128'b0;
                dmm_we_reg   = 128'b0;
            end
        endcase
    end
    else if (ex_load_en) begin
        dmm_ce_reg   = (ex_pc_valid == 1'b1 && flush_ex == 1'b0);
        dmm_addr_reg = alu_result[11:4];
        dmm_we_reg   = 128'b0;
        dmm_data_reg = 128'b0;
    end
    else begin
        dmm_ce_reg   = 1'b0;
        dmm_addr_reg = 8'b0;
        dmm_we_reg   = 128'b0;
        dmm_data_reg = 128'b0;
    end
end

always @(posedge clk or negedge rst_n) begin
    if (rst_n == 1'b0)
        me_rd_we <= 1'b0;
    else if (flush_ex == 1'b1)
        me_rd_we <= 1'b0;
    else
        me_rd_we <= ex_pc_valid && (ex_exception_sum == 2'b0) && ex_rd_we;
end

always @(posedge clk) begin
    if (flush_ex == 1'b1)
        me_pc <= 32'b0;
    else if (ex_pc_valid == 1'b1)
        me_pc <= ex_pc;
end

always @(posedge clk or negedge rst_n) begin
    if (rst_n == 1'b0) begin
        me_load_en   <= 1'b0;
        me_wfi       <= 1'b0;
        me_exception <= 2'b0;
    end
    else if (flush_ex == 1'b1) begin
        me_load_en   <= 1'b0;
        me_wfi       <= 1'b0;
        me_exception <= 2'b0;
    end
    else begin
        me_load_en   <= ex_pc_valid && ex_load_en;
        me_wfi       <= ex_pc_valid && ex_wfi;
        me_exception <= ex_pc_valid ? ex_exception_sum : 2'b0;
    end
end

always @(posedge clk) begin
    if (ex_rd_we == 1'b1 || ex_load_en == 1'b1) begin
        me_rd_addr   <= ex_rd_addr;
        me_rd_data   <= ex_rd_data;
        me_load_sel  <= alu_result[3:0];
        me_load_size <= {ex_mem_unsigned, ex_mem_size};
    end
end

endmodule
