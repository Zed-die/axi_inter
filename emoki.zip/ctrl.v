module ctrl(
    input             clk,
    input             rst_n,
    input             start_pulse,
    input      [31:0] start_pc,
    input      [1:0]  core_configuration,
    input             redirect_en,
    input      [1:0]  id_exception,
    input             id_pc_valid,
    input      [31:0] me_pc,
    input      [1:0]  me_exception,

    input             load_use_hazard,
    input             id_wfi,
    input             ex_wfi,
    input             me_wfi,
    output reg        start_pulse_sync,
    output reg [31:0] start_pc_sync,
    output wire       if_pc_valid_next,

    output reg        stall_if,
    output reg        stall_id,
    output reg        flush_if,
    output reg        flush_id,
    output reg        flush_ex,

    output reg [1:0]  core_status,
    output reg [1:0]  core_exceptions,
    output reg [31:0] core_exceptions_pc
);

reg wfi_status;
reg idle_status;
reg start_pulse_d1;
reg start_pulse_d2;
reg start_pulse_d3;
reg core_running;

wire start_pulse_rise;
wire id_wfi_valid;

assign start_pulse_rise = start_pulse_d2 & ~start_pulse_d3;
assign id_wfi_valid     = id_pc_valid & id_wfi & ~redirect_en & ~(|id_exception);
assign if_pc_valid_next = core_running | start_pulse_sync;

//跨时钟域
always @(posedge clk or negedge rst_n) begin
    if (rst_n == 1'b0) begin
        start_pulse_d1   <= 1'b0;
        start_pulse_d2   <= 1'b0;
        start_pulse_d3   <= 1'b0;
        start_pulse_sync <= 1'b0;
        start_pc_sync    <= 32'b0;
    end
    else begin
        start_pulse_d1   <= start_pulse;
        start_pulse_d2   <= start_pulse_d1;
        start_pulse_d3   <= start_pulse_d2;
        start_pulse_sync <= start_pulse_rise;
        if (start_pulse_rise)
            start_pc_sync <= start_pc;
    end
end

//IF阶段的valid产生
always @(posedge clk or negedge rst_n) begin
    if (rst_n == 1'b0)
        core_running <= 1'b0;
    else if (me_wfi)
        core_running <= 1'b0;
    else if (|me_exception)
        core_running <= 1'b0;
    else if (start_pulse_sync)
        core_running <= 1'b1;
end

always @(posedge clk or negedge rst_n) begin
    if (rst_n == 1'b0)
        wfi_status <= 1'b0;
    else if (me_wfi)
        wfi_status <= 1'b1;
    else if (start_pulse_sync)
        wfi_status <= 1'b0;
end

always @(posedge clk or negedge rst_n) begin
    if (rst_n == 1'b0)
        idle_status <= 1'b1;
    else if (start_pulse_sync)
        idle_status <= 1'b0;
    else if (me_wfi)
        idle_status <= 1'b1;
    else if (|me_exception)
        idle_status <= 1'b1;
end

always @(*) begin
    if (|me_exception) begin
        flush_if = 1'b1;
        flush_id = 1'b1;
        flush_ex = 1'b1;
    end
    else if (me_wfi) begin
        flush_if = 1'b1;
        flush_id = 1'b1;
        flush_ex = 1'b1;
    end
    else if (redirect_en) begin
        flush_if = 1'b1;
        flush_id = 1'b1;
        flush_ex = 1'b0;
    end
    else begin
        flush_if = 1'b0;
        flush_id = 1'b0;
        flush_ex = 1'b0;
    end
end

always @(*) begin
    if (id_wfi_valid | ex_wfi | me_wfi)
        stall_if = 1'b1;
    else if (load_use_hazard)
        stall_if = 1'b1;
    else
        stall_if = 1'b0;
end

always @(*) begin
    if (id_wfi_valid | ex_wfi | me_wfi)
        stall_id = 1'b0;
    else if (load_use_hazard)
        stall_id = 1'b1;
    else
        stall_id = 1'b0;
end

always @(posedge clk or negedge rst_n) begin
    if (rst_n == 1'b0) begin
        core_status        <= 2'b01;
        core_exceptions    <= 2'b0;
        core_exceptions_pc <= 32'b0;
    end
    else begin
        core_status <= {wfi_status, idle_status};
        core_exceptions    <= 2'b0;
        core_exceptions_pc <= 32'b0;
        if (me_exception[1] == 1'b1) begin
            core_exceptions    <= core_configuration[1] ? 2'b0 : 2'b10;
            core_exceptions_pc <= core_configuration[1] ? 32'b0 : me_pc;
        end
        else if (me_exception[0] == 1'b1) begin
            core_exceptions    <= core_configuration[0] ? 2'b0 : 2'b01;
            core_exceptions_pc <= core_configuration[0] ? 32'b0 : me_pc;
        end
    end
end

endmodule
