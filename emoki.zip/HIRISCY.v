module HIRISCY(
    input         clk,
    input         rst_n,
    input         start_pulse,
    input  [31:0] start_pc,
    input  [1:0]  core_configuration,
    output [1:0]  core_status,
    output [1:0]  core_exceptions,
    output [31:0] core_exceptions_pc
);

wire        start_pulse_sync;
wire [31:0] start_pc_sync;
wire        if_pc_valid_next;

wire        stall_if;
wire        stall_id;
wire        flush_if;
wire        flush_id;
wire        flush_ex;

wire        imm_ce;
wire [7:0]  imm_addr;
wire [31:0] imm_data;

wire [31:0] id_pc;
wire [31:0] id_inst;
wire        id_pc_unaligned;
wire        id_pc_valid;
wire [1:0]  id_exception;
wire        id_wfi;
wire        load_use_hazard;

wire        rf_rs1_en;
wire [4:0]  rf_rs1_addr;
wire [31:0] rf_rs1_data;
wire        rf_rs2_en;
wire [4:0]  rf_rs2_addr;
wire [31:0] rf_rs2_data;
wire        rf_rd_we;
wire [4:0]  rf_rd_addr;
wire [31:0] rf_rd_data;

wire [31:0] ex_pc;
wire        ex_pc_valid;
wire [31:0] ex_op_data1;
wire [31:0] ex_op_data2;
wire [31:0] ex_rf_rs2;
wire        ex_rd_we;
wire [4:0]  ex_rd_addr;
wire [3:0]  ex_alu_op;
wire        ex_branch;
wire [2:0]  ex_branch_funct3;
wire        ex_jump;
wire        ex_jalr;
wire        ex_load_en;
wire        ex_store_en;
wire [1:0]  ex_mem_size;
wire        ex_mem_unsigned;
wire        ex_wfi;
wire [1:0]  ex_exception;
wire [31:0] ex_rd_data;
wire        redirect_en;
wire [31:0] redirect_pc;

wire         dmm_ce;
wire [7:0]   dmm_addr;
wire [127:0] dmm_we;
wire [127:0] dmm_data;
wire [127:0] dmm_rdata;

wire        me_rd_we;
wire [4:0]  me_rd_addr;
wire [31:0] me_rd_data;
wire [3:0]  me_load_sel;
wire        me_load_en;
wire [2:0]  me_load_size;
wire [31:0] me_pc;
wire        me_wfi;
wire [1:0]  me_exception;

wire         wb_rd_we;
wire [127:0] wb_rdata;
wire [4:0]   wb_rd_addr;
wire [31:0]  wb_rd_data;
wire [3:0]   wb_load_sel;
wire         wb_load_en;
wire [2:0]   wb_load_size;

ctrl u_ctrl(
    .clk                 (clk               ),
    .rst_n               (rst_n             ),
    .start_pulse         (start_pulse       ),
    .start_pc            (start_pc          ),
    .core_configuration  (core_configuration),
    .redirect_en         (redirect_en       ),
    .id_exception        (id_exception      ),
    .id_pc_valid         (id_pc_valid       ),
    .me_pc               (me_pc             ),
    .me_exception        (me_exception      ),
    .load_use_hazard     (load_use_hazard   ),
    .id_wfi              (id_wfi            ),
    .ex_wfi              (ex_wfi            ),
    .me_wfi              (me_wfi            ),
    .start_pulse_sync    (start_pulse_sync  ),
    .start_pc_sync       (start_pc_sync     ),
    .if_pc_valid_next    (if_pc_valid_next  ),
    .stall_if            (stall_if          ),
    .stall_id            (stall_id          ),
    .flush_if            (flush_if          ),
    .flush_id            (flush_id          ),
    .flush_ex            (flush_ex          ),
    .core_status         (core_status       ),
    .core_exceptions     (core_exceptions   ),
    .core_exceptions_pc  (core_exceptions_pc)
);

ifu u_ifu(
    .clk                 (clk               ),
    .rst_n               (rst_n             ),
    .start_pulse_sync    (start_pulse_sync  ),
    .start_pc_sync       (start_pc_sync     ),
    .flush_if            (flush_if          ),
    .stall_if            (stall_if          ),
    .if_pc_valid_next    (if_pc_valid_next  ),
    .redirect_en         (redirect_en       ),
    .redirect_pc         (redirect_pc       ),
    .imm_ce              (imm_ce            ),
    .imm_addr            (imm_addr          ),
    .imm_data            (imm_data          ),
    .id_pc               (id_pc             ),
    .id_inst             (id_inst           ),
    .id_pc_unaligned     (id_pc_unaligned   ),
    .id_pc_valid         (id_pc_valid       )
);

imem u_imem(
    .clk                 (clk               ),
    .ce                  (imm_ce            ),
    .addr                (imm_addr          ),
    .rd_data             (imm_data          )
);

idu u_idu(
    .clk                 (clk               ),
    .rst_n               (rst_n             ),
    .flush_id            (flush_id          ),
    .stall_id            (stall_id          ),
    .id_pc               (id_pc             ),
    .id_inst             (id_inst           ),
    .id_pc_valid         (id_pc_valid       ),
    .id_pc_unaligned     (id_pc_unaligned   ),
    .rf_rs1_en           (rf_rs1_en         ),
    .rf_rs1_addr         (rf_rs1_addr       ),
    .rf_rs1_data         (rf_rs1_data       ),
    .rf_rs2_en           (rf_rs2_en         ),
    .rf_rs2_addr         (rf_rs2_addr       ),
    .rf_rs2_data         (rf_rs2_data       ),
    .ex_rd_data          (ex_rd_data        ),
    .me_rd_we            (me_rd_we          ),
    .me_load_en          (me_load_en        ),
    .me_rd_addr          (me_rd_addr        ),
    .me_rd_data          (me_rd_data        ),
    .wb_rd_we            (rf_rd_we          ),
    .wb_rd_addr          (rf_rd_addr        ),
    .wb_rd_data          (rf_rd_data        ),
    .ex_pc               (ex_pc             ),
    .ex_pc_valid         (ex_pc_valid       ),
    .ex_op_data1         (ex_op_data1       ),
    .ex_op_data2         (ex_op_data2       ),
    .ex_rf_rs2           (ex_rf_rs2         ),
    .ex_rd_we            (ex_rd_we          ),
    .ex_rd_addr          (ex_rd_addr        ),
    .ex_alu_op           (ex_alu_op         ),
    .ex_branch           (ex_branch         ),
    .ex_branch_funct3    (ex_branch_funct3  ),
    .ex_jump             (ex_jump           ),
    .ex_jalr             (ex_jalr           ),
    .ex_load_en          (ex_load_en        ),
    .ex_store_en         (ex_store_en       ),
    .ex_mem_size         (ex_mem_size       ),
    .ex_mem_unsigned     (ex_mem_unsigned   ),
    .ex_wfi              (ex_wfi            ),
    .id_exception        (id_exception      ),
    .id_wfi              (id_wfi            ),
    .load_use_hazard     (load_use_hazard   ),
    .ex_exception        (ex_exception      )
);

regfile u_regfile(
    .clk                 (clk               ),
    .rst_n               (rst_n             ),
    .rs1_en              (rf_rs1_en         ),
    .rs1_addr            (rf_rs1_addr       ),
    .rs1_data            (rf_rs1_data       ),
    .rs2_en              (rf_rs2_en         ),
    .rs2_addr            (rf_rs2_addr       ),
    .rs2_data            (rf_rs2_data       ),
    .rd_we               (rf_rd_we          ),
    .rd_addr             (rf_rd_addr        ),
    .rd_data             (rf_rd_data        )
);

exu u_exu(
    .clk                 (clk               ),
    .rst_n               (rst_n             ),
    .flush_ex            (flush_ex          ),
    .ex_pc               (ex_pc             ),
    .ex_pc_valid         (ex_pc_valid       ),
    .ex_op_data1         (ex_op_data1       ),
    .ex_op_data2         (ex_op_data2       ),
    .ex_rf_rs2           (ex_rf_rs2         ),
    .ex_rd_we            (ex_rd_we          ),
    .ex_rd_addr          (ex_rd_addr        ),
    .ex_alu_op           (ex_alu_op         ),
    .ex_branch           (ex_branch         ),
    .ex_branch_funct3    (ex_branch_funct3  ),
    .ex_jump             (ex_jump           ),
    .ex_jalr             (ex_jalr           ),
    .ex_load_en          (ex_load_en        ),
    .ex_store_en         (ex_store_en       ),
    .ex_mem_size         (ex_mem_size       ),
    .ex_mem_unsigned     (ex_mem_unsigned   ),
    .ex_exception        (ex_exception      ),
    .ex_wfi              (ex_wfi            ),
    .redirect_en         (redirect_en       ),
    .redirect_pc         (redirect_pc       ),
    .ex_rd_data          (ex_rd_data        ),
    .dmm_ce              (dmm_ce            ),
    .dmm_addr            (dmm_addr          ),
    .dmm_we              (dmm_we            ),
    .dmm_data            (dmm_data          ),
    .me_rd_we            (me_rd_we          ),
    .me_rd_addr          (me_rd_addr        ),
    .me_rd_data          (me_rd_data        ),
    .me_load_sel         (me_load_sel       ),
    .me_load_en          (me_load_en        ),
    .me_load_size        (me_load_size      ),
    .me_pc               (me_pc             ),
    .me_wfi              (me_wfi            ),
    .me_exception        (me_exception      )
);

dmem u_dmem(
    .clk                 (clk               ),
    .ce                  (dmm_ce            ),
    .addr                (dmm_addr          ),
    .we                  (dmm_we            ),
    .wr_data             (dmm_data          ),
    .rd_data             (dmm_rdata         )
);

memu u_memu(
    .clk                 (clk               ),
    .rst_n               (rst_n             ),
    .me_rd_we            (me_rd_we          ),
    .me_rd_addr          (me_rd_addr        ),
    .me_rd_data          (me_rd_data        ),
    .me_load_sel         (me_load_sel       ),
    .me_load_en          (me_load_en        ),
    .me_load_size        (me_load_size      ),
    .dmm_rdata           (dmm_rdata         ),
    .wb_rd_we            (wb_rd_we          ),
    .wb_rdata            (wb_rdata          ),
    .wb_rd_addr          (wb_rd_addr        ),
    .wb_rd_data          (wb_rd_data        ),
    .wb_load_sel         (wb_load_sel       ),
    .wb_load_en          (wb_load_en        ),
    .wb_load_size        (wb_load_size      )
);

wbu u_wbu(
    .wb_rd_we            (wb_rd_we          ),
    .wb_rdata            (wb_rdata          ),
    .wb_rd_addr          (wb_rd_addr        ),
    .wb_rd_data          (wb_rd_data        ),
    .wb_load_sel         (wb_load_sel       ),
    .wb_load_en          (wb_load_en        ),
    .wb_load_size        (wb_load_size      ),
    .rf_rd_we            (rf_rd_we          ),
    .rf_rd_addr          (rf_rd_addr        ),
    .rf_rd_data          (rf_rd_data        )
);

endmodule
