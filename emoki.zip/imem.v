module imem(
    input             clk,
    input             ce,
    input      [7:0]  addr,
    output reg [31:0] rd_data
);

reg [31:0] mem [0:255];

integer i;

initial begin
    for (i = 0; i < 256; i = i + 1)
        mem[i] = 32'b0;
end

always @(posedge clk) begin
    if (ce)
        rd_data <= mem[addr];
end

endmodule
