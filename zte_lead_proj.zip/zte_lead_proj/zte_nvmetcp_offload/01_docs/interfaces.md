# 顶层接口说明

顶层模块为`nvmetcp_offload_top`。所有ready/valid接口在`valid=1 && ready=0`期间保持数据稳定。

## 写入侧（`wr_clk`）

| 端口 | 方向 | 位宽 | 说明 |
|---|---|---:|---|
| `wr_valid` | 输入 | 1 | 当前写拍有效 |
| `wr_ready` | 输出 | 1 | 所选连接有缓存空间 |
| `wr_conn` | 输入 | 3 | 连接编号0至7 |
| `wr_data` | 输入 | 512 | byte 0位于`[7:0]`，按NVMe/TCP小端字节序 |
| `wr_keep` | 输入 | 64 | 每bit对应8 bit有效字节，仅末拍允许非全1 |
| `wr_last` | 输入 | 1 | 当前拍结束一个完整PDU并提交doorbell |

接口约定每个PDU从新的512 bit拍开始；不同连接可以交错写入，同一连接内保持PDU字节顺序。上游必须在`wr_ready=1`时才推进数据。

## 动作与payload（`core_clk`）

| 端口 | 方向 | 说明 |
|---|---|---|
| `action_valid`/`action_ready` | 出/入 | 单拍结构化解析结果握手 |
| `action_meta` | 输出 | 200 bit 扁平总线，包含连接、opcode、action、flags、PLEN、CCCID、TTAG、offset、length、FES/FEI和error |
| `payload_valid`/`payload_ready` | 出/入 | 原始PDU数据流握手 |
| `payload_data` | 输出 | 512 bit原始PDU拍 |
| `payload_keep` | 输出 | 64 bit字节有效掩码 |
| `payload_start`/`payload_last` | 输出 | PDU首拍/末拍 |
| `payload_conn` | 输出 | payload所属连接 |

动作必须先被接收，随后该PDU的payload开始输出。下游背压会反向停止缓存读取，不丢包。

`action_meta[199:0]` 位段固定如下，验证侧 packed struct 与此布局逐位兼容：

| 位段 | 字段 |
|---:|---|
| `[199:197]` | `conn_id` |
| `[196:189]` | `pdu_type` |
| `[188:185]` | `action` |
| `[184:177]` | `flags` |
| `[176:145]` | `plen` |
| `[144:129]` | `cccid` |
| `[128:113]` | `ttag` |
| `[112:81]` | `data_offset` |
| `[80:49]` | `data_length` |
| `[48:33]` | `fes` |
| `[32:1]` | `fei` |
| `[0]` | `error` |

## 回复流（`core_clk`）

`tx_valid`、`tx_ready`、`tx_data`、`tx_keep`、`tx_last`和`tx_conn`组成512 bit回复接口。ICResp固定输出两拍；当前无错误头部回显的TermReq输出一拍24 B。

## 监控接口

`mon_addr`为12 bit组合读地址，`mon_rdata`为32 bit读数据，`mon_clear`同步清零全部计数。地址`000h-01Ch`为连接PDU计数，`040h-05Ch`为调度计数，`080h-0A0h`为opcode计数，`0C0h/0C4h/0C8h`分别为错误/溢出尝试/背压计数，`0D0h-0DCh`为最近错误，`100h-118h`为FES分类计数。

## 复位与时钟

`wr_rst_n`在`wr_clk`域同步使用，`core_rst_n`在`core_clk`域同步使用。外部集成时应分别同步释放复位。XDC把两个时钟组声明为异步，并仅允许Gray指针跨域。
