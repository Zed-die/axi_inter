# 协议支持矩阵

基线为NVMe/TCP Transport Specification 1.0d第3.6.2节。Common Header字段按byte 0至7解析：PDU-Type、FLAGS、HLEN、PDO、PLEN。

| Opcode | PDU | 固定HLEN | 输出行为 |
|---:|---|---:|---|
| 00h | ICReq | 128 B | `ACT_ICREQ`并自动生成ICResp |
| 01h | ICResp | 128 B | `ACT_ICRESP` |
| 02h | H2CTermReq | 24 B | `ACT_TERMINATE`通知 |
| 03h | C2HTermReq | 24 B | `ACT_TERMINATE`通知 |
| 04h | CapsuleCmd | 72 B | `ACT_CAPSULE_CMD`，输出CCSQE及可选数据流 |
| 05h | CapsuleResp | 24 B | `ACT_CAPSULE_RESP`，提取CCCID |
| 06h | H2CData | 24 B | `ACT_H2C_DATA`，提取CCCID、TTAG、DATAO、DATAL |
| 07h | C2HData | 24 B | `ACT_C2H_DATA`，提取CCCID、DATAO、DATAL、SUCCESS |
| 09h | R2T | 24 B | `ACT_R2T`，提取CCCID、TTAG、R2TO、R2TL |

## 校验规则

- 未列opcode、错误HLEN/PLEN/PDO、保留flags和字段对齐错误映射到FES 01h；
- HDGSTF、DDGSTF或连接初始化中的digest请求映射到FES 06h；
- PFV必须为0，HPDA/CPDA必须为0；
- H2CData、C2HData和R2T的offset与length必须按dword对齐；
- Data PDU的DATAL必须与`PLEN-PDO`一致；
- 对H2C方向错误生成C2HTermReq，对C2H方向错误生成H2CTermReq。

CapsuleCmd只解析传输层可独立获得的字段；NVMe命令opcode、队列状态和介质结果由外部命令执行模块负责。
