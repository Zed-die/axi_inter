# 架构说明

## 数据路径

写入侧以512 bit数据、64 bit keep和last写入8个独立逻辑环形缓存。每个连接只在完整PDU的last拍写入后更新提交指针，因此核心侧不会读取半包。提交指针和读指针采用Gray Code，经带`ASYNC_REG`属性的两级同步器跨越`wr_clk`与`core_clk`。

核心侧轮询调度器以完整PDU为授权粒度，从上次完成连接的下一连接开始搜索。读取器将缓存拍转换为start/last流，检查PLEN对应的拍数及末拍keep。解析器读取NVMe/TCP Common Header和类型专用字段，输出结构化动作，同时把原始PDU作为payload流交给后续数据或命令模块。

回复生成器只自动处理无需NVMe命令上下文的两种情况：ICReq生成ICResp，致命传输层字段错误生成方向相反的TermReq。Capsule、Data、R2T和对端通知通过动作接口输出，避免伪造存储业务语义。

## 公平性和吞吐

调度器只在当前PDU完成后更新优先级。持续非空的连接最多等待其他7个PDU，不会被同一连接连续抢占。512 bit通路在200 MHz下原始能力为102.4 Gb/s；当前缓存读取和解析流稳态每2周期接受一拍，仿真实测51.603 Gb/s，高于40 Gb/s要求。

## 可维护性

CDC、缓存、调度、读取、解析、回复、监控和顶层分别位于独立的 Verilog-2001 `.v` 文件。`nvmetcp_defs.vh` 集中定义 opcode、动作、FES 和 200 bit 元数据位段；模块内函数负责小端提取。验证侧 `03_tb/sv/nvmetcp_pkg.sv` 使用相同二进制布局提供 SystemVerilog 结构体。监控模块提供每连接、每 opcode、每 FES 饱和计数及最近错误快照。

## 非目标

工程不实现TCP/IP、TLS、HDGST/DDGST计算、NVMe队列/命令执行、DDR控制器、PCIe或板级引脚。Vivado脚本用于纯RTL综合及时序检查；具体开发板只需新增器件和引脚约束，不改变协议核心。
