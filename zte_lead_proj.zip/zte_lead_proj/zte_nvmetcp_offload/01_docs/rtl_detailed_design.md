# NVMe/TCP 硬卸载 RTL 详细设计说明

## 1. 文档目的与设计边界

本文面向 RTL 设计、验证、综合和集成人员，解释 `zte_nvmetcp_offload` 当前实现的硬件结构。描述以 `02_rtl/` 中的 Verilog-2001 源码为准，重点说明模块边界、组合/时序逻辑、状态机、跨时钟域、背压、错误路径和验证对应关系。

设计完成的工作是：

- 接收来自上游的 512 bit NVMe/TCP PDU 数据拍；
- 按 8 个连接分别缓存数据，并在两个异步时钟域之间安全发布完整 PDU；
- 以完整 PDU 为粒度进行 round-robin 调度；
- 校验 PDU 拍数、末拍 `keep`、Common Header 和类型专用字段；
- 输出 200 bit 结构化动作和原始 payload；
- 对 ICReq 自动生成 ICResp，对传输层错误生成 TermReq；
- 提供可软件读取的调度、PDU、错误、溢出和背压计数。

当前明确的非目标如下：

- TCP/IP：未实现。输入已经是按连接标识的 NVMe/TCP PDU，不负责以太网、IP、TCP 重组或重传。
- TLS：未实现。
- DDR：未实现。缓存由可综合 RTL memory 描述，未连接外部 DDR 控制器。
- NVMe 命令执行：未实现。CapsuleCmd 只产生动作和 payload，不执行读写命令或维护 NVMe 队列。
- HDGST/DDGST 计算：未实现。请求使用 digest 时，parser 报告不支持参数。
- PCIe、板级引脚和上位机驱动：未实现。

设计 RTL 使用 Verilog-2001；验证 package、testbench 和断言使用 SystemVerilog。设计不实例化 Xilinx FIFO Generator、Block Memory Generator 或 ILA 等 IP。

## 2. 工程基线与源码统计

### 2.1 主要参数

| 项目 | 当前值 | 说明 |
|---|---:|---|
| 连接数 | 8 | 顶层 `NUM_CONN=8` |
| 数据宽度 | 512 bit | 每拍 64 B |
| `keep` 宽度 | 64 bit | 每 bit 对应一个有效字节 |
| 顶层每连接缓存深度 | 128 拍 | 顶层 `DEPTH_WORDS=128` |
| 最大 PDU | 8,264 B | `NVMETCP_MAX_PDU_BYTES` |
| 核心目标频率 | 200 MHz | 周期 5.000 ns |
| 元数据宽度 | 200 bit | `action_meta[199:0]` |

`nvmetcp_async_buffer_bank.v` 自身的 `DEPTH_WORDS` 默认值为 32；顶层实例化时覆盖为 128。深度必须不小于 2 且为 2 的幂。

### 2.2 物理代码行统计

统计日期为 2026-07-26。统计的是源码物理行数，包含空行和注释；排除 Markdown、PDF、ZIP、仿真生成物、Vivado生成目录和缓存。

| 类别 | 文件数 | 物理行数 |
|---|---:|---:|
| RTL 设计 | 9 | 1,388 |
| SystemVerilog 验证 | 10 | 1,355 |
| Python 工具与测试 | 8 | 964 |
| Vivado Tcl | 2 | 54 |
| PowerShell 脚本 | 4 | 207 |
| XDC 约束 | 1 | 11 |
| 源码合计 | 34 | 3,979 |

RTL 设计逐文件统计如下：

| RTL 文件 | 行数 |
|---|---:|
| `02_rtl/nvmetcp_defs.vh` | 58 |
| `02_rtl/nvmetcp_gray_sync.v` | 33 |
| `02_rtl/nvmetcp_async_buffer_bank.v` | 162 |
| `02_rtl/nvmetcp_rr_scheduler.v` | 60 |
| `02_rtl/nvmetcp_pdu_reader.v` | 146 |
| `02_rtl/nvmetcp_parser.v` | 389 |
| `02_rtl/nvmetcp_response_gen.v` | 136 |
| `02_rtl/nvmetcp_monitor.v` | 153 |
| `02_rtl/nvmetcp_offload_top.v` | 251 |
| RTL 合计 | 1,388 |

统计可以通过递归枚举上述扩展名并对 `Get-Content` 的行数求和复现。`test_docs.py` 也会从当前源码重新计算各分类行数，并检查本表是否同步。

## 3. 总体架构

### 3.1 模块连接

```mermaid
flowchart LR
    U[上游 PDU 写入<br/>wr_clk] --> B[nvmetcp_async_buffer_bank<br/>8连接异步缓存]
    B -->|pending[7:0]| S[nvmetcp_rr_scheduler]
    S -->|grant| R[nvmetcp_pdu_reader]
    R -->|rd_req / rd_consume| B
    R -->|规范化512 bit流| P[nvmetcp_parser]
    P -->|action_meta| A[外部动作消费者]
    P -->|原始 payload| D[命令/数据处理模块]
    P -->|错误或ICReq动作| T[nvmetcp_response_gen]
    T -->|512 bit tx流| N[下游发送接口]
    R -->|frame_error| X[顶层错误仲裁]
    X --> A
    A --> M[nvmetcp_monitor]
    S --> M
    B --> M
```

模块之间的主控制关系为：

1. 写侧把数据、`keep` 和 `last` 存入连接对应的环形缓冲。
2. 只有包含 `wr_last` 的拍被接受后，完整 PDU 才通过提交指针对核心侧可见。
3. `pending` 告诉调度器哪些连接至少有一个已提交而未读取的 beat。
4. 调度器选择连接后，reader 独占该连接直到读到 PDU 的 `last`。
5. parser 在第一拍产生动作元数据；动作被接受后，原始 PDU 才从 payload 接口送出。
6. 顶层把动作同时交给外部消费者和 response generator。需要回复时，response generator 独立产生 `tx` 流。
7. monitor 在实际握手事件上计数，不参与数据通路决策。

### 3.2 数据通路与控制通路

数据通路包括三个 512 bit 接口：

- `wr_data`：上游写入缓存；
- `payload_data`：原始接收 PDU 输出；
- `tx_data`：本地生成的协议回复。

控制通路包括：

- 每连接 Gray 指针和 `pending`；
- `grant_valid/grant_ready/grant_done`；
- reader 的 `rd_req/rd_valid/rd_consume`；
- parser 的动作和 payload ready/valid；
- response generator 的请求和发送 ready/valid；
- monitor 事件脉冲。

## 4. 时钟、复位与 CDC

### 4.1 时钟域划分

| 时钟域 | 状态/接口 |
|---|---|
| `wr_clk` | `wr_work_bin`、`wr_commit_bin`、写端 memory、`overflow_attempt`、同步后的读指针 `rd_wr` |
| `core_clk` | 同步后的提交指针 `wr_commit_core`、`rd_bin`、读端输出寄存器、scheduler、reader、parser、response generator、monitor、顶层错误寄存器 |

`wr_rst_n` 和 `core_rst_n` 都是低有效、各自在所属 `always @(posedge clk)` 中同步采样的复位。系统集成时应保证每个时钟域的复位释放满足本域时序要求。

### 4.2 Gray Code 指针同步

`nvmetcp_gray_sync.v` 先计算：

```text
gray = binary XOR (binary >> 1)
```

Gray Code 相邻计数值只改变一位，因此异步采样时不会像二进制计数器那样同时观察到多个翻转位。Gray 向量进入目的时钟域后经过两个带 `ASYNC_REG="TRUE"` 属性的寄存器，再组合转换回二进制。

设计跨域传递的是：

- 写提交指针：`wr_commit_bin` 从 `wr_clk` 到 `core_clk`；
- 读指针：`rd_bin` 从 `core_clk` 到 `wr_clk`。

多位二进制指针不直接跨域。memory 数据本身不经过逐位同步器；它依赖异步 FIFO 的所有权规则：写侧先写 memory，最后通过 `wr_last` 更新提交指针，核心侧看到同步后的提交指针时，对应 memory 数据已经稳定。

### 4.3 CDC 工程注意事项

- Gray 输入必须来自单调递增且源域注册的二进制指针；当前两个源指针都满足该条件。
- `ASYNC_REG` 只标记同步寄存器，不替代异步时钟约束。
- XDC 使用 `set_clock_groups -asynchronous` 隔离 `wr_clk` 与 `core_clk`。
- memory 为双时钟访问模式。是否最终推断为 BRAM、LUTRAM 或寄存器阵列，必须以 Vivado 综合报告为准。
- 当前机器没有 Vivado，综合、时序、CDC 和资源报告状态为 `NOT_RUN_NO_VIVADO`。

## 5. 流控、包所有权与背压

### 5.1 ready/valid 规则

所有 ready/valid 通道都遵循：

```text
fire = valid && ready
```

发送方在 `valid=1 && ready=0` 时必须保持数据和旁带信号稳定。数据只在 `fire` 的时钟沿完成所有权转移。

### 5.2 PDU 原子提交

写侧每接受一拍都推进 `wr_work_bin[wr_conn]`，但只有该拍同时带 `wr_last=1` 时才把新指针写入 `wr_commit_bin[wr_conn]`。因此：

- 半包占用 memory 空间，但不会出现在核心侧 `pending` 中；
- 核心侧只读取已提交 PDU；
- 不同连接可以交错写入；
- 同一连接内部必须保持 PDU beat 顺序。

### 5.3 包粒度调度所有权

scheduler 的一次授权从 `grant_valid && grant_ready` 开始。reader 保存 `grant_id` 为 `active_conn`，直到读到并消费 `rd_last` 后发出 `grant_done`。scheduler 在此之前不改变活动连接。

因此公平性单位是 PDU，而不是 beat。长 PDU 不会在中间被其他连接抢占。

### 5.4 背压传播

主要背压链路如下：

```text
action_ready / payload_ready
        ↓
nvmetcp_parser.in_ready
        ↓
nvmetcp_pdu_reader.out_ready
        ↓
rd_consume
        ↓
async_buffer.rd_valid 保持
```

其他背压点：

- 缓冲满时，`wr_ready=0`，只阻止当前 `wr_conn` 的写入；
- `tx_ready=0` 时，response generator 保持当前回复拍；
- response generator 不空闲时，顶层通过 `response_request_ready` 阻止新动作完成；
- monitor 只观察 `backpressure`，不会改变流控。

## 6. 协议字段与 action_meta

### 6.1 Common Header

第一拍低 64 bit 按小端字节顺序解释：

| 字节偏移 | 字段 | 宽度 |
|---:|---|---:|
| 0 | PDU Type | 8 bit |
| 1 | FLAGS | 8 bit |
| 2 | HLEN | 8 bit |
| 3 | PDO | 8 bit |
| 4–7 | PLEN | 32 bit，小端 |

parser 使用 `get_byte512`、`get_le16_512` 和 `get_le32_512` 从 512 bit 第一拍提取字段。

### 6.2 PDU 与动作映射

| Opcode | PDU | 固定 HLEN | action | 主要提取字段 |
|---:|---|---:|---:|---|
| `00h` | ICReq | 128 | `ACT_ICREQ=1` | PFV/HPDA/digest协商字段必须为0 |
| `01h` | ICResp | 128 | `ACT_ICRESP=2` | PFV/CPDA/digest协商字段必须为0 |
| `02h` | H2CTermReq | 24 | `ACT_TERMINATE=3` | FES、FEI |
| `03h` | C2HTermReq | 24 | `ACT_TERMINATE=3` | FES、FEI |
| `04h` | CapsuleCmd | 72 | `ACT_CAPSULE_CMD=4` | CCCID、可选数据长度 |
| `05h` | CapsuleResp | 24 | `ACT_CAPSULE_RESP=5` | CCCID |
| `06h` | H2CData | 24 | `ACT_H2C_DATA=6` | CCCID、TTAG、DATAO、DATAL |
| `07h` | C2HData | 24 | `ACT_C2H_DATA=7` | CCCID、DATAO、DATAL |
| `09h` | R2T | 24 | `ACT_R2T=8` | CCCID、TTAG、R2TO、R2TL |

### 6.3 200 bit 元数据

`action_meta[199:0]` 是 RTL 模块之间的扁平总线。验证侧 `nvmetcp_pkg.sv` 用同样的 packed struct 排列字段，因此可直接连接并按字段名检查。

| 位段 | 字段 | 含义 |
|---:|---|---|
| `[199:197]` | `conn_id` | 连接 0–7 |
| `[196:189]` | `pdu_type` | Common Header byte 0 |
| `[188:185]` | `action` | 本地处理动作 |
| `[184:177]` | `flags` | Common Header byte 1 |
| `[176:145]` | `plen` | PDU 总长度 |
| `[144:129]` | `cccid` | 命令上下文标识 |
| `[128:113]` | `ttag` | 传输标签 |
| `[112:81]` | `data_offset` | DATAO 或 R2TO |
| `[80:49]` | `data_length` | DATAL 或 R2TL |
| `[48:33]` | `fes` | Fatal Error Status |
| `[32:1]` | `fei` | Fatal Error Information |
| `[0]` | `error` | 本地校验失败标志 |

### 6.4 错误码

公共头文件定义：

| FES | 宏 | 当前用途 |
|---:|---|---|
| `0001h` | `FES_INVALID_HEADER` | 未知类型、长度、PDO、flags、对齐、拍封装错误 |
| `0002h` | `FES_PDU_SEQUENCE` | 预留给序列错误；当前 parser 不产生 |
| `0003h` | `FES_HEADER_DIGEST` | 预留给 digest 错误；当前不计算 digest |
| `0004h` | `FES_DATA_OUT_OF_RANGE` | 已定义，当前 parser 不产生 |
| `0005h` | `FES_TRANSFER_LIMIT` | 已定义，当前 parser 不产生 |
| `0006h` | `FES_UNSUPPORTED_PARAM` | digest 请求、IC 协商参数非零 |

`make_error` 会把动作改成 `ACT_TERMINATE`，清零 CCCID、TTAG、offset 和 length，保留连接、PDU type、flags 和 PLEN，并写入 FES、FEI、`error=1`。

## 7. RTL 模块详细设计

### 7.1 `nvmetcp_defs.vh`

#### 作用

该文件是所有 Verilog RTL 的公共编译期定义，使用 include guard 防止重复展开。它不产生硬件实例。

#### 定义内容

- 最大 PDU 长度 8,264 B；
- 动作元数据宽度 200 bit；
- 9 个 PDU opcode；
- 9 个 action 编码（含 `ACT_NONE`）；
- 6 个 FES 编码；
- `action_meta` 每个字段的 MSB/LSB。

#### 工程注意事项

修改字段宽度或位段时，必须同步更新：

- parser、response、monitor、top 的切片；
- 验证侧 `03_tb/sv/nvmetcp_pkg.sv` packed struct；
- `tb_pkg.sv` 的位宽/布局检查；
- 本文的元数据表。

对应验证为 `tb_pkg.sv` 和 `test_verilog2001_rtl.py`。

### 7.2 `nvmetcp_gray_sync.v`

#### 作用与参数

把源域二进制计数器转换为 Gray Code，在目的时钟域同步后再恢复为二进制。

| 参数/端口 | 方向 | 说明 |
|---|---|---|
| `WIDTH` | 参数 | 指针宽度，默认 6 |
| `src_bin` | 输入 | 源域稳定的二进制计数器 |
| `src_gray` | 输出 | 组合 Gray 编码 |
| `dst_clk` | 输入 | 目的时钟 |
| `dst_rst_n` | 输入 | 目的域同步低有效复位 |
| `dst_gray` | 输出 | 两级同步后的 Gray |
| `dst_bin` | 输出 | 组合恢复的二进制值 |

#### 内部逻辑

`sync_gray_ff1` 和 `sync_gray_ff2` 是两级同步寄存器。恢复二进制时：

```text
dst_bin[MSB] = dst_gray[MSB]
dst_bin[i]   = dst_bin[i+1] XOR dst_gray[i]
```

#### 时序与 CDC

组合 Gray 编码依赖 `src_bin` 的源域注册特性。同步寄存器只在 `dst_clk` 更新。`dst_bin` 是同步后 Gray 的组合函数，不形成新的跨域路径。

对应验证：`tb_gray_sync.sv` 检查 Gray 单 bit 变化、同步延迟和二进制恢复。

### 7.3 `nvmetcp_async_buffer_bank.v`

#### 作用

为每个连接提供逻辑独立的异步环形缓冲，并用“工作指针/提交指针”区分半包和完整 PDU。

#### 参数

| 参数 | 默认值 | 顶层值 | 说明 |
|---|---:|---:|---|
| `NUM_CONN` | 8 | 8 | 连接数 |
| `DEPTH_WORDS` | 32 | 128 | 每连接 beat 深度 |
| `DATA_W` | 512 | 512 | 数据宽度 |
| `CONN_W` | 3 | 3 | 连接编号宽度 |

`ADDR_W=clog2(DEPTH_WORDS)`，`PTR_W=ADDR_W+1`。最高位是环回 phase bit。

#### 端口分组

| 分组 | 端口 | 行为 |
|---|---|---|
| 写入 | `wr_valid/ready/conn/data/keep/last` | 在 `wr_clk` 接受 beat |
| 状态 | `overflow_attempt` | `wr_valid && !wr_ready` 的单周期记录 |
| 可用图 | `pending` | 每连接提交指针与读指针不等 |
| 读取请求 | `rd_req/rd_conn` | core 域选择连接 |
| 读取返回 | `rd_valid/data/keep/last` | 注册输出并保持到消费 |
| 消费 | `rd_consume` | 推进所选连接读指针 |

#### memory 组织

三组一维 memory 按 `connection * DEPTH_WORDS + address` 展平：

- `mem_data`：512 bit 数据；
- `mem_keep`：64 bit 字节有效位；
- `mem_last`：PDU 末拍标志。

写端口位于 `wr_clk` always 块，读端口位于 `core_clk` always 块。综合器可能识别为双时钟双端口 RAM，但最终资源类型需由 Vivado 报告确认。

#### 指针

| 指针 | 时钟域 | 含义 |
|---|---|---|
| `wr_work_bin` | `wr_clk` | 每接受一个 beat 都推进 |
| `wr_commit_bin` | `wr_clk` | 仅接受 `wr_last` 时推进到工作指针的新值 |
| `wr_commit_core` | `core_clk` | 同步后的提交指针 |
| `rd_bin` | `core_clk` | 每消费一个 beat 都推进 |
| `rd_wr` | `wr_clk` | 同步后的读指针 |

满判断比较当前工作指针与“读指针 phase bit 取反、地址位保持”的值。满时 `wr_ready=0`。`pending[i] = wr_commit_core[i] != rd_bin[i]`。

#### 每周期行为

写侧：

1. 计算当前 `wr_conn` 的下一工作指针和满状态。
2. `wr_valid && wr_ready` 时写三组 memory。
3. 工作指针加一。
4. 如果 `wr_last=1`，提交指针更新到同一个下一值。

读侧：

1. 空闲且 `rd_req && pending[rd_conn]` 时，把该地址数据读入输出寄存器并置 `rd_valid`。
2. `rd_valid && rd_consume` 时推进 `rd_conn_hold` 对应的读指针，并清 `rd_valid`。
3. `rd_valid=1` 且未消费时，输出寄存器保持。

#### 风险与约束

- `DEPTH_WORDS` 必须为 2 的幂，否则仿真在 initial 参数检查中结束。
- 写满保护只针对当前连接，不阻塞其他连接。
- 不检查上游是否在同一连接内嵌套 PDU；该顺序属于接口约束。
- 双时钟 memory 和 Gray 指针路径应在 Vivado CDC 报告中复核。

对应验证：`tb_async_buffer_bank.sv` 覆盖提交可见性、不同连接、异步时钟、回绕、满/空和保持行为。

### 7.4 `nvmetcp_rr_scheduler.v`

#### 作用

对 `pending[7:0]` 中的连接做包粒度 round-robin 仲裁。

| 端口 | 方向 | 说明 |
|---|---|---|
| `pending[7:0]` | 输入 | 每连接是否有已提交数据 |
| `grant_valid` | 输出 | 当前授权有效 |
| `grant_ready` | 输入 | reader 接受授权 |
| `grant_id[2:0]` | 输出 | 授权连接 |
| `grant_done` | 输入 | 当前 PDU 已完成 |

#### 候选搜索

组合逻辑从 `offset=1` 到 8 搜索：

```text
candidate_index = (last_grant + offset) & 7
```

第一个 pending 连接成为候选。复位时 `last_grant=7`，因此第一次搜索从连接 0 开始。

#### 内部控制

该模块没有显式 enum FSM，但 `offer_valid` 和 `active` 构成三种逻辑阶段：

| 阶段 | 条件 | 动作 |
|---|---|---|
| 空闲 | `!active && !offer_valid` | 若存在候选，锁存到 `offer_id` |
| 提议 | `offer_valid=1` | 保持 `grant_valid/grant_id`，等待 reader |
| 活动 | 授权握手后 | 保存 `active_id`，等待 `grant_done` |

`grant_done` 时清 `active`，并令 `last_grant=active_id`。即使其他连接 pending 变化，活动 PDU 也不会被抢占。

持续非空的连接最多等待其他 7 个已授权 PDU，前提是每个 PDU 最终都会产生 `grant_done`。

对应验证：`tb_rr_scheduler.sv` 检查顺序、保持和公平轮转。

### 7.5 `nvmetcp_pdu_reader.v`

#### 作用

把 buffer 的请求/返回接口转换成带 `start/last/conn` 的连续 PDU 流，并校验 PLEN 对应的 beat 数和末拍 `keep`。

#### 接口

| 接口 | 主要信号 | 说明 |
|---|---|---|
| scheduler | `grant_valid/ready/id/done` | 获取并释放 PDU 所有权 |
| buffer | `rd_req/conn/valid/data/keep/last/consume` | 拉取一个 beat |
| parser | `out_valid/ready/data/keep/start/last/conn` | 输出规范化流 |
| 错误 | `frame_error_valid/conn` | 拍数或末拍 keep 不一致 |

#### 状态机

| 状态 | 输出/含义 | 转移 |
|---|---|---|
| `STATE_IDLE` | `grant_ready=1` | 授权握手后保存连接，转 `REQUEST` |
| `STATE_REQUEST` | `rd_req=1` | `rd_valid && !out_ready` 转 `HOLD`；消费非末拍保持/返回 `REQUEST`；消费末拍转 `IDLE` |
| `STATE_HOLD` | 保持当前 buffer beat | `out_ready` 后按末拍决定 `IDLE` 或 `REQUEST` |

#### 长度计算

第一拍从 `rd_data[63:32]` 读取 PLEN：

```text
expected_beats = (PLEN + 63) >> 6 = ceil(PLEN / 64)
```

末拍期望条件：

```text
expected_last = (beat_index + 1) == expected_beats
```

末拍 `keep`：

- `PLEN[5:0]==0`：64 bit 全 1；
- 否则：低 `PLEN mod 64` 位为 1。

reader 在 beat 被下游实际接受时检查：

- `rd_last` 是否等于 `expected_last`；
- 如果 `rd_last=1`，`rd_keep` 是否等于 `expected_keep`。

失败时发出一个周期 `frame_error_valid`。无论是否错误，收到 `rd_last` 后都会结束当前授权，避免连接永久占用。

#### 背压

`out_valid` 直接依赖 buffer 的 `rd_valid`。`rd_consume=out_valid && out_ready`。buffer 在未消费时保持输出，因此 reader 的 `HOLD` 状态不会丢失数据。

对应验证：`tb_pdu_reader.sv` 覆盖单拍、多拍、背压、PLEN/last/keep 错误和授权完成。

### 7.6 `nvmetcp_parser.v`

#### 作用

解析第一拍 Common Header 和类型专用字段，生成动作元数据；在动作先完成握手后，再逐拍输出原始 PDU。

#### 端口

| 分组 | 信号 | 说明 |
|---|---|---|
| 输入流 | `in_valid/ready/data/keep/start/last/conn` | reader 输出 |
| 动作 | `action_valid/ready/meta` | 单个 PDU 一个动作 |
| payload | `payload_valid/ready/data/keep/start/last/conn` | 原始 PDU |

#### 状态机

| 状态 | 行为 | 转移 |
|---|---|---|
| `STATE_IDLE` | `in_ready=1`，等待第一拍 | 接受后锁存第一拍和 decode 结果，转 `ACTION` |
| `STATE_ACTION` | `action_valid=1`，元数据保持 | 动作握手后转 `STREAM` |
| `STATE_STREAM` | 输出已锁存 beat | 末拍消费后转 `IDLE`；非末拍消费后转 `LOAD` |
| `STATE_LOAD` | `in_ready=1`，装载下一拍 | 接受后转 `STREAM` |

这种顺序保证每个 PDU 的动作一定先于 payload。如果动作消费者背压，第一拍数据和元数据都保持。

#### 通用校验顺序

`decode_header` 按确定顺序执行，前一个错误会阻止后续检查覆盖 FES/FEI：

1. opcode 映射；未知 opcode → FES `0001h`、FEI 0。
2. HLEN 必须等于类型固定值 → FEI 2。
3. `HLEN <= PLEN <= 8264` → FEI 4。
4. digest flag → FES `0006h`、FEI 1。
5. 其他不允许 flag → FES `0001h`、FEI 1。
6. 类型专用长度、PDO、协商字段、DATAL 和对齐检查。

#### 类型专用校验

| PDU | 校验 | 成功时写入 |
|---|---|---|
| ICReq/ICResp | PLEN=128、PDO=0、byte 8–11 协商字段为0 | action、公共字段 |
| H2CTermReq/C2HTermReq | PLEN≤152、PDO=0 | FES=`bytes[9:8]`，FEI=`bytes[13:10]` |
| CapsuleCmd | PLEN=72 时 PDO=0，否则 PDO=72 | CCCID=`bytes[11:10]`，可选数据长度 |
| CapsuleResp | PLEN=24、PDO=0 | CCCID=`bytes[21:20]` |
| H2CData | PDO=24、DATAL=PLEN−24、DATAO/DATAL 4B 对齐 | CCCID、TTAG、DATAO、DATAL |
| C2HData | PDO=24、DATAL=PLEN−24、DATAO/DATAL 4B 对齐 | CCCID、DATAO、DATAL |
| R2T | PLEN=24、PDO=0、R2TO/R2TL 4B 对齐 | CCCID、TTAG、R2TO、R2TL |

H2CData 允许 flag bit 2；C2HData 允许 bit 2 和 bit 3。digest bit 0/1 仍优先报告不支持参数。

#### 组合函数与时序

`decode_header` 是较大的组合函数，包含多层 case、比较和动态字节切片。它位于“输入第一拍 → `meta_reg` D 输入”的路径上，可能成为 200 MHz 综合的关键组合路径。若 Vivado 时序不满足，可把通用校验和类型专用校验流水化，但这会改变动作延迟和状态机。

对应验证：`tb_parser.sv` 覆盖 9 类 PDU、未知类型、长度、flags、协商参数、PDO、DATAL 和对齐错误，并检查背压期间动作稳定。

### 7.7 `nvmetcp_response_gen.v`

#### 作用

根据动作元数据生成无需 NVMe 命令上下文的回复：

- 合法 ICReq → 128 B ICResp，两拍；
- `error=1` → 24 B TermReq，一拍；
- 其他动作不生成回复。

#### 接口

| 信号 | 说明 |
|---|---|
| `request_valid/ready` | 接受一个 200 bit 动作 |
| `request_meta` | 动作元数据 |
| `tx_valid/ready` | 回复拍握手 |
| `tx_data/keep/last/conn` | 512 bit 回复和连接 |

#### 状态机

| 状态 | 输出 | 转移 |
|---|---|---|
| `STATE_IDLE` | `request_ready=1`、`tx_valid=0` | 错误或 ICReq 请求转 `SEND0` |
| `STATE_SEND0` | 输出 `response0` | 单拍回复握手后回 `IDLE`；ICResp 第一拍后转 `SEND1` |
| `STATE_SEND1` | 输出 `response1`、`tx_last=1` | 握手后回 `IDLE` |

`response0/1`、`keep0/1` 和连接号都是寄存器，因此 `tx_ready=0` 时输出稳定。

#### ICResp

`build_icresp` 构造：

- opcode=`01h`；
- HLEN=128；
- PLEN=128；
- PFV/CPDA/digest=0；
- MAXH2CDATA=4096；
- 两拍 `keep` 均全 1，第二拍 `last=1`。

#### TermReq 方向

输入 PDU type bit 0 为 1（C2H 方向类型）时生成 H2CTermReq；bit 0 为 0（H2C 方向类型）时生成 C2HTermReq。回复包含 FES 和 FEI，`keep=0x00ff_ffff`，表示低 24 B 有效。

对应验证：`tb_response_gen.sv` 做 ICResp、两个方向 TermReq 和背压稳定性逐字节检查。

### 7.8 `nvmetcp_monitor.v`

#### 作用

对数据通路事件做 32 bit 饱和计数，并提供 12 bit 地址的组合读接口。

#### 输入事件

| 事件 | 计数行为 |
|---|---|
| `action_fire` | 连接 PDU 计数、opcode 计数；错误时更新错误统计 |
| `schedule_fire` | 对应连接调度次数加一 |
| `overflow_attempt` | 溢出尝试计数加一 |
| `backpressure` | 任一顶层输出背压周期计数加一 |
| `mon_clear` | 同步清零全部统计 |

`sat_inc32` 在计数器已经为 `32'hffff_ffff` 时保持不变。

#### 地址映射

| 地址范围 | 内容 |
|---|---|
| `000h–01Ch` | 连接 0–7 的 `conn_packets` |
| `040h–05Ch` | 连接 0–7 的 `schedule_count` |
| `080h–0A0h` | 9 个支持 opcode 的计数 |
| `0C0h` | `total_errors` |
| `0C4h` | `overflow_count` |
| `0C8h` | `backpressure_count` |
| `0D0h` | 最近错误连接 |
| `0D4h` | 最近错误 opcode |
| `0D8h` | 最近错误 FES |
| `0DCh` | 最近错误 FEI |
| `100h–118h` | FES 索引 0–6 的计数 |

范围寄存器要求地址 4 B 对齐。未定义或未对齐地址读 0。

#### 时序注意事项

`mon_rdata` 是组合读取，包含地址范围比较和 memory 索引。若集成到高扇出软件总线，可在外层增加读数据寄存器；当前接口没有读使能或等待周期。

对应验证：`tb_monitor.sv` 检查地址映射、饱和、最近错误、清零、溢出和背压计数。

### 7.9 `nvmetcp_offload_top.v`

#### 作用

顶层实例化并连接 buffer、scheduler、reader、parser、response generator 和 monitor，同时完成 reader 帧错误与 parser 动作的仲裁。

#### 顶层参数和接口

| 项目 | 说明 |
|---|---|
| `NUM_CONN` | 默认 8；scheduler 和外部连接端口当前固定为 3 bit/8连接 |
| `DEPTH_WORDS` | 默认 128，每连接缓存 beat 数 |
| `wr_*` | 异步写入接口 |
| `action_*` | 结构化动作接口 |
| `payload_*` | 原始接收 PDU 接口 |
| `tx_*` | 本地回复接口 |
| `mon_*` | 统计清零和组合读取接口 |

尽管 `NUM_CONN` 是参数，scheduler 使用固定 `pending[7:0]`，连接 ID 固定 3 bit。因此当前可验证配置是 8 连接；若扩展连接数，必须同步参数化 scheduler 和所有连接端口。

#### 帧错误仲裁

reader 检测到 PLEN/last/keep 不一致时，顶层通过 `make_frame_error_meta` 构造：

- `action=ACT_TERMINATE`；
- `FES=FES_INVALID_HEADER`；
- `FEI=4`；
- `error=1`。

`frame_error_pending` 的优先级高于 parser 正常动作。错误元数据保持到动作真正完成。

#### 动作与回复请求的原子握手

顶层组合关系是：

```text
action_valid            = selected_action_valid && response_request_ready
response_request_valid  = selected_action_valid && action_ready
action_fire             = selected_action_valid &&
                          action_ready &&
                          response_request_ready
```

这形成一个“双消费者同时接受”的事务：外部动作消费者和内部 response generator 必须在同一个周期都 ready，动作才被视为完成。这样不会出现外部已经接受错误动作、但回复请求丢失的情况。

正常 parser 动作的 ready 还要求：

```text
!frame_error_pending && action_ready && response_request_ready
```

#### 监控事件

- `schedule_fire = grant_valid && grant_ready`；
- `backpressure` 为 action、payload、tx 三个输出任一 `valid && !ready`；
- monitor 使用 `selected_action_meta` 和 `action_fire`，只统计实际被接受的动作。

#### 组合路径注意事项

动作通路存在 ready 互锁，但没有纯组合环路：response generator 的 `request_ready` 只由其状态决定，外部 `action_ready` 是顶层输入。集成方不应从 `action_valid` 组合生成带环路的 `action_ready`。

对应验证：`tb_offload_top.sv` 覆盖端到端写入、调度、解析、动作、payload、回复、错误路径、多连接公平性和吞吐率。

## 8. 端到端工作示例

### 8.1 合法 ICReq

```mermaid
sequenceDiagram
    participant U as 上游
    participant B as async buffer
    participant S as scheduler/reader
    participant P as parser
    participant A as action consumer
    participant G as response generator

    U->>B: 写入2拍 ICReq，第二拍 wr_last
    B-->>S: 提交指针同步后 pending=1
    S->>B: grant连接并读取第一拍
    B->>P: Common Header beat
    P->>A: ACT_ICREQ + action_meta
    A-->>P: action_ready
    P->>G: 同周期提交回复请求
    P->>A: 随后输出原始payload两拍
    G->>U: ICResp第1拍
    G->>U: ICResp第2拍，tx_last=1
```

关键顺序是“动作先于 payload”。ICResp 和 payload 是两个独立输出通道，各自可能背压；设计不保证二者之间固定绝对周期差。

### 8.2 非法 PDU

非法 PDU 有两类来源：

1. parser 发现 header/字段错误，直接把 `error=1` 的动作送到顶层；
2. reader 发现 PLEN 与 beat/last/keep 不一致，顶层生成 `frame_error_meta`。

动作完成时，response generator 使用 PDU type bit 0 选择相反方向的 TermReq，并把 FES/FEI写入低 24 B 回复。parser 的 `make_error` 清零命令相关字段，避免错误 PDU 的部分解析值被误用。

### 8.3 多连接轮询

假设 `last_grant=2`，连接 2、3、5 同时 pending：

1. 搜索从 `(2+1)&7=3` 开始，首先选择连接 3。
2. reader 接受授权后，连接 3 保持活动直到该 PDU 的末拍被消费。
3. `grant_done` 令 `last_grant=3`。
4. 下一次从连接 4 搜索，选择连接 5。
5. 再下一次从连接 6 绕回，最终选择仍 pending 的连接 2。

pending 在活动期间的变化不会切断当前 PDU。

## 9. 吞吐、综合与时序分析

### 9.1 带宽

512 bit 通路在 200 MHz 下的原始位宽-频率乘积：

```text
512 bit × 200,000,000 cycle/s = 102.4 Gb/s
```

当前端到端 testbench 报告：

- `MEASURED_THROUGHPUT_GBPS 51.603`；
- `MAX_GAP_CYCLES 2`。

最大两周期接受一拍对应约 51.2 Gb/s 的稳态量级；testbench 的 51.603 Gb/s 来自其有限测量窗口。验收要求为不低于 40 Gb/s。

### 9.2 可能的关键路径

- parser 的 `decode_header` 大型组合函数；
- scheduler 的 8 路串行优先搜索；
- buffer 的动态连接/memory 索引和满判断；
- monitor 的组合地址译码；
- 顶层动作 ready 互锁。

Icarus Verilog 只能证明语言编译和功能仿真，不能证明 FPGA 时序。Vivado 尚未在当前机器运行，因此不得把 200 MHz 标记为已完成布局布线验证。

### 9.3 资源推断

预期主要资源包括：

- 三组 `NUM_CONN*DEPTH_WORDS` 深度的双时钟 memory；
- 每连接两套二进制/Gray 指针；
- parser 比较、case 和多路选择逻辑；
- response 的两个 512 bit 回复寄存器；
- monitor 的计数器阵列。

这些是代码结构推断，不是综合结果。最终 BRAM、LUT、FF、WNS 和 CDC 结论必须来自 `04_vivado/run_synth.tcl` 生成的报告。

## 10. 验证结构与运行方法

### 10.1 验证分层

| 层次 | 内容 |
|---|---|
| Python 模型 | 报文生成、协议字段和期望动作 |
| SystemVerilog 单元测试 | 每个 RTL 模块的直接激励与自检 |
| 顶层测试 | 8连接、异步时钟、错误、背压、公平性、吞吐 |
| 语言检查 | RTL目录无 `.sv`，禁止 SystemVerilog 构造，`-g2001` 编译 |
| Vivado流程 | 综合、利用率、timing、CDC、methodology |

验证侧 `03_tb/sv/nvmetcp_pkg.sv` 只用于 testbench，不属于设计 RTL。

### 10.2 本地完整回归

```powershell
powershell -NoProfile -ExecutionPolicy Bypass `
  -File .\06_scripts\run_regression.ps1
```

期望看到：

- Python 测试全部通过；
- `VERILOG_2001_COMPILE_PASS`；
- 9 个 `TB_PASS`；
- `MEASURED_THROUGHPUT_GBPS` 不低于 40；
- `REGRESSION_PASS`。

### 10.3 Vivado

```powershell
powershell -NoProfile -ExecutionPolicy Bypass `
  -File .\06_scripts\run_vivado.ps1
```

当前状态为 `NOT_RUN_NO_VIVADO`。只有脚本在安装了 Vivado 的机器返回 0，且 WNS 不小于 0，才能把综合及时序状态改为 PASS。

## 11. 集成约束、已知边界与扩展方向

### 11.1 集成约束

- 每个 PDU 从新的 512 bit beat 开始。
- 同一连接内 PDU 字节顺序不能乱序。
- `wr_keep` 只允许末拍非全 1，并应与 PLEN 一致。
- 外部动作和 payload 消费者必须遵守 ready/valid 稳定性规则。
- `wr_rst_n` 与 `core_rst_n` 应分别在所属时钟域同步释放。
- 当前连接数实际固定为 8。

### 11.2 已知边界

- parser 只查看第一拍中可获得的类型专用字段，不执行 NVMe 语义。
- 本设计拒绝 digest，而不是验证 digest。
- reader 的帧错误仍会释放 PDU，不维护长期连接关闭状态。
- monitor 是组合读接口，无总线超时或访问保护。
- 未取得真实 Vivado 综合、时序、CDC 和资源证据。

### 11.3 可扩展方向

合理的后续扩展顺序是：

1. 在保持当前动作接口的前提下增加 NVMe 命令执行/队列模块；
2. 增加 TCP 接收重组适配层，而不是把 TCP 状态机塞入 parser；
3. 若需要 digest，增加独立流水 CRC 模块并扩展错误分类；
4. 对 parser 组合 decode 做流水化以提高频率；
5. 将连接数和 scheduler 完整参数化；
6. 根据 Vivado 报告调整 memory 模板、寄存器切分和约束；
7. 最后增加 DDR/PCIe/板级封装。

这些扩展均不属于当前已实现范围。
