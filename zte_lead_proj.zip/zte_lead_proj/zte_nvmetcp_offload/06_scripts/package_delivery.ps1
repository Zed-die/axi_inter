$ErrorActionPreference = 'Stop'
$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$PackageRoot = [System.IO.Path]::GetFullPath((Join-Path $ProjectRoot '08_delivery/package'))
$DeliveryRoot = [System.IO.Path]::GetFullPath((Join-Path $ProjectRoot '08_delivery'))
$ZipPath = [System.IO.Path]::GetFullPath((Join-Path $ProjectRoot '08_delivery/zte_nvmetcp_offload_delivery.zip'))

if (-not $PackageRoot.StartsWith($DeliveryRoot + [System.IO.Path]::DirectorySeparatorChar)) {
    throw "Unsafe package path: $PackageRoot"
}
if ($PackageRoot -eq $DeliveryRoot -or $DeliveryRoot -eq $ProjectRoot) {
    throw 'Refusing to delete a non-package directory'
}

if (Test-Path -LiteralPath $PackageRoot) {
    Remove-Item -LiteralPath $PackageRoot -Recurse -Force
}
New-Item -ItemType Directory -Path $PackageRoot | Out-Null

$IncludeDirectories = @(
    '00_requirements',
    '01_docs',
    '02_rtl',
    '03_tb',
    '04_vivado',
    '05_constraints',
    '06_scripts',
    '07_reports'
)
foreach ($Directory in $IncludeDirectories) {
    $Source = Join-Path $ProjectRoot $Directory
    if (Test-Path -LiteralPath $Source) {
        Copy-Item -LiteralPath $Source -Destination $PackageRoot -Recurse
    }
}
Copy-Item -LiteralPath (Join-Path $ProjectRoot 'README.md') -Destination $PackageRoot

$PackageDelivery = Join-Path $PackageRoot '08_delivery'
New-Item -ItemType Directory -Path $PackageDelivery | Out-Null
Copy-Item -LiteralPath (Join-Path $DeliveryRoot 'README.md') -Destination $PackageDelivery
$StatusFile = Join-Path $DeliveryRoot 'acceptance_status.md'
if (Test-Path -LiteralPath $StatusFile) {
    Copy-Item -LiteralPath $StatusFile -Destination $PackageDelivery
}

$SafePackagePrefix = $PackageRoot + [System.IO.Path]::DirectorySeparatorChar
$CacheDirectories = Get-ChildItem -LiteralPath $PackageRoot -Recurse -Directory |
    Where-Object { $_.Name -in @('__pycache__', '.pytest_cache', '.Xil') } |
    Sort-Object FullName -Descending
foreach ($CacheDirectory in $CacheDirectories) {
    $Candidate = [System.IO.Path]::GetFullPath($CacheDirectory.FullName)
    if (-not $Candidate.StartsWith($SafePackagePrefix)) {
        throw "Unsafe cache path: $Candidate"
    }
    Remove-Item -LiteralPath $Candidate -Recurse -Force
}

$VivadoGenerated = [System.IO.Path]::GetFullPath(
    (Join-Path $PackageRoot '04_vivado/generated')
)
if (Test-Path -LiteralPath $VivadoGenerated) {
    if (-not $VivadoGenerated.StartsWith($SafePackagePrefix)) {
        throw "Unsafe Vivado generated path: $VivadoGenerated"
    }
    Remove-Item -LiteralPath $VivadoGenerated -Recurse -Force
}

Get-ChildItem -LiteralPath $PackageRoot -Recurse -File |
    Where-Object { $_.Extension.ToLowerInvariant() -in @('.pyc', '.vvp', '.vcd', '.wdb', '.jou', '.log') } |
    ForEach-Object {
        $Candidate = [System.IO.Path]::GetFullPath($_.FullName)
        if (-not $Candidate.StartsWith($SafePackagePrefix)) {
            throw "Unsafe generated file path: $Candidate"
        }
        Remove-Item -LiteralPath $Candidate -Force
    }

$ManifestPath = Join-Path $PackageRoot 'MANIFEST.sha256'
$ManifestLines = Get-ChildItem -LiteralPath $PackageRoot -Recurse -File |
    Where-Object { $_.FullName -ne $ManifestPath } |
    Sort-Object FullName |
    ForEach-Object {
        $Relative = $_.FullName.Substring($PackageRoot.Length + 1).Replace('\', '/')
        $Hash = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
        "$Hash  $Relative"
    }
[System.IO.File]::WriteAllLines(
    $ManifestPath,
    [string[]]$ManifestLines,
    [System.Text.UTF8Encoding]::new($false)
)

if (-not $ZipPath.StartsWith($DeliveryRoot + [System.IO.Path]::DirectorySeparatorChar)) {
    throw "Unsafe ZIP path: $ZipPath"
}
if (Test-Path -LiteralPath $ZipPath) {
    Remove-Item -LiteralPath $ZipPath -Force
}
Compress-Archive -Path (Join-Path $PackageRoot '*') -DestinationPath $ZipPath -CompressionLevel Optimal
Write-Output "DELIVERY_PACKAGE=$ZipPath"
