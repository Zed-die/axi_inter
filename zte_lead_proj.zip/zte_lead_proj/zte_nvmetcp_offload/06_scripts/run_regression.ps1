$ErrorActionPreference = 'Stop'
$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$ReportDir = Join-Path $ProjectRoot '07_reports/generated/simulation'
$ExpectedBenches = 'tb_pkg tb_rr_scheduler tb_gray_sync tb_async_buffer_bank tb_pdu_reader tb_parser tb_response_gen tb_monitor tb_offload_top'
New-Item -ItemType Directory -Force -Path $ReportDir | Out-Null

& python (Join-Path $ProjectRoot '03_tb/python/generate_vectors.py')
if ($LASTEXITCODE -ne 0) { throw 'generate_vectors.py failed' }

& pytest (Join-Path $ProjectRoot '03_tb/python') -q
if ($LASTEXITCODE -ne 0) { throw 'pytest failed' }

$Output = & (Join-Path $PSScriptRoot 'run_unit.ps1') -SkipPython 2>&1
$Output | ForEach-Object { Write-Output $_ }
if ($LASTEXITCODE -ne 0) { throw 'RTL unit regression failed' }

$Throughput = $Output | Select-String 'MEASURED_THROUGHPUT_GBPS' | Select-Object -Last 1
$Summary = @(
    'STATUS=PASS'
    "BENCHES=$ExpectedBenches"
    "PYTHON=$(python --version 2>&1)"
    "PYTEST=$(pytest --version 2>&1)"
    "IVERILOG=$((iverilog -V 2>&1 | Select-Object -First 1))"
    "THROUGHPUT=$Throughput"
)
$Summary | Set-Content -Encoding UTF8 (Join-Path $ReportDir 'regression_summary.txt')
Write-Output 'REGRESSION_PASS'
