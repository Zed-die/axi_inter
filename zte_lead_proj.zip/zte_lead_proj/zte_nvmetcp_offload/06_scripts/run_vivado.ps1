$ErrorActionPreference = 'Stop'
$Vivado = Get-Command vivado -ErrorAction SilentlyContinue
if (-not $Vivado) {
    Write-Output 'Vivado executable not found; RTL regression remains available.'
    exit 2
}

$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$Tcl = Join-Path $ProjectRoot '04_vivado/run_synth.tcl'
& $Vivado.Source -mode batch -source $Tcl -tclargs $ProjectRoot
exit $LASTEXITCODE
