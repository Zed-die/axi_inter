param(
    [switch]$SkipPython
)

$ErrorActionPreference = 'Stop'
$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$TempRoot = Join-Path ([System.IO.Path]::GetTempPath()) 'zte_nvmetcp_offload_sim'
$CommonDir = Join-Path $ProjectRoot '02_rtl'
New-Item -ItemType Directory -Force -Path $TempRoot | Out-Null

function Require-Command([string]$Name) {
    if (-not (Get-Command $Name -ErrorAction SilentlyContinue)) {
        throw "Required command not found: $Name"
    }
}

function Run-Sim([string]$Top, [string[]]$Sources) {
    $Output = Join-Path $TempRoot "$Top.vvp"
    & iverilog -g2012 -I $CommonDir -s $Top -o $Output @Sources
    if ($LASTEXITCODE -ne 0) { throw "iverilog failed for $Top" }
    & vvp $Output
    if ($LASTEXITCODE -ne 0) { throw "simulation failed for $Top" }
}

Require-Command iverilog
Require-Command vvp
if (-not $SkipPython) {
    Require-Command pytest
    & pytest (Join-Path $ProjectRoot '03_tb/python') -q
    if ($LASTEXITCODE -ne 0) { throw 'pytest failed' }
}

$Pkg = Join-Path $ProjectRoot '03_tb/sv/nvmetcp_pkg.sv'
Run-Sim 'tb_pkg' @($Pkg, (Join-Path $ProjectRoot '03_tb/sv/tb_pkg.sv'))
Run-Sim 'tb_rr_scheduler' @(
    (Join-Path $ProjectRoot '02_rtl/nvmetcp_rr_scheduler.v'),
    (Join-Path $ProjectRoot '03_tb/sv/tb_rr_scheduler.sv'))
Run-Sim 'tb_gray_sync' @(
    (Join-Path $ProjectRoot '02_rtl/nvmetcp_gray_sync.v'),
    (Join-Path $ProjectRoot '03_tb/sv/tb_gray_sync.sv'))
Run-Sim 'tb_async_buffer_bank' @(
    (Join-Path $ProjectRoot '02_rtl/nvmetcp_gray_sync.v'),
    (Join-Path $ProjectRoot '02_rtl/nvmetcp_async_buffer_bank.v'),
    (Join-Path $ProjectRoot '03_tb/sv/tb_async_buffer_bank.sv'))
Run-Sim 'tb_pdu_reader' @(
    (Join-Path $ProjectRoot '02_rtl/nvmetcp_pdu_reader.v'),
    (Join-Path $ProjectRoot '03_tb/sv/tb_pdu_reader.sv'))
Run-Sim 'tb_parser' @(
    $Pkg,
    (Join-Path $ProjectRoot '02_rtl/nvmetcp_parser.v'),
    (Join-Path $ProjectRoot '03_tb/sv/tb_parser.sv'))
Run-Sim 'tb_response_gen' @(
    $Pkg,
    (Join-Path $ProjectRoot '02_rtl/nvmetcp_response_gen.v'),
    (Join-Path $ProjectRoot '03_tb/sv/tb_response_gen.sv'))
Run-Sim 'tb_monitor' @(
    $Pkg,
    (Join-Path $ProjectRoot '02_rtl/nvmetcp_monitor.v'),
    (Join-Path $ProjectRoot '03_tb/sv/tb_monitor.sv'))

$RtlSources = Get-Content (Join-Path $ProjectRoot '03_tb/sv/filelist.f') | ForEach-Object {
    Join-Path (Split-Path $ProjectRoot -Parent) $_
}
$RtlOnlySources = $RtlSources | Where-Object { $_.EndsWith('.v') }
& iverilog -g2001 -tnull -s nvmetcp_offload_top -I $CommonDir @RtlOnlySources
if ($LASTEXITCODE -ne 0) { throw 'Verilog-2001 RTL compile failed' }
Write-Output 'VERILOG_2001_COMPILE_PASS'
Run-Sim 'tb_offload_top' @($RtlSources + (Join-Path $ProjectRoot '03_tb/sv/tb_offload_top.sv'))

Write-Output 'UNIT_REGRESSION_PASS'
