# 需求追踪矩阵

证据状态以实际脚本输出为准。本机没有 Vivado 时，综合、时序和 CDC 项标记为 `NOT_RUN_NO_VIVADO`，不得用 Icarus 结果代替。

| ID | 原始要求 | RTL实现 | 验证用例 | 验收证据 |
|---|---|---|---|---|
| REQ-001 | 8个独立连接、异步doorbell、公平调度 | `02_rtl/nvmetcp_async_buffer_bank.v`、`02_rtl/nvmetcp_gray_sync.v`、`02_rtl/nvmetcp_rr_scheduler.v` | `tb_async_buffer_bank`、`tb_gray_sync`、`tb_rr_scheduler`、`tb_offload_top` | `07_reports/generated/simulation/regression_summary.txt` |
| REQ-002 | 对PDU产生合理回复或动作 | `02_rtl/nvmetcp_parser.v`、`02_rtl/nvmetcp_response_gen.v` | `tb_parser`、`tb_response_gen`、`tb_offload_top` | `07_reports/generated/simulation/regression_summary.txt` |
| REQ-003 | 200 MHz、缓存读取达到40 Gb/s | `02_rtl/nvmetcp_pdu_reader.v`、`02_rtl/nvmetcp_offload_top.v` | `tb_offload_top`吞吐测量 | `07_reports/generated/simulation/regression_summary.txt`、`07_reports/generated/vivado/timing_summary.rpt` |
| REQ-004 | 输入RAM及输出数据位宽64 B | `02_rtl/nvmetcp_async_buffer_bank.v`、`02_rtl/nvmetcp_offload_top.v` | `tb_async_buffer_bank`、`tb_pdu_reader`、`tb_offload_top` | `07_reports/generated/simulation/regression_summary.txt` |
| REQ-005 | 代码内部可维可测 | `02_rtl/nvmetcp_monitor.v` | `tb_monitor`、`test_docs.py` | `07_reports/generated/simulation/regression_summary.txt` |
| REQ-006 | 不支持HDGST/DDGST，CPDA/HPDA为0 | `02_rtl/nvmetcp_parser.v`、`02_rtl/nvmetcp_response_gen.v` | `test_nvmetcp_model.py`、`tb_parser`、`tb_response_gen` | `07_reports/generated/simulation/regression_summary.txt` |
| REQ-007 | SV/Python生成报文合集并验证分类解析 | `02_rtl/nvmetcp_parser.v` | `test_generate_vectors.py`、`tb_parser`、`tb_offload_top` | `07_reports/generated/simulation/regression_summary.txt` |
| REQ-008 | DDR及上位机上板测试为进阶项 | `02_rtl/nvmetcp_offload_top.v`保留纯RTL边界 | `test_scripts.py`检查Vivado入口 | `07_reports/generated/vivado/`，本阶段状态为`NOT_RUN_NO_VIVADO`或真实Vivado报告 |
