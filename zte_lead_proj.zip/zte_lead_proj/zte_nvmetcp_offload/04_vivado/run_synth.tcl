set project_root [file normalize [lindex $argv 0]]
set report_dir [file join $project_root 07_reports generated vivado]
set part_name "xc7a200tsbg484-1"
if {[info exists ::env(PART)] && $::env(PART) ne ""} {
  set part_name $::env(PART)
}
file mkdir $report_dir

set include_dir [file join $project_root 02_rtl]
set rtl_files [glob -nocomplain [file join $project_root 02_rtl *.v]]
read_verilog -include_dirs [list $include_dir] $rtl_files
read_xdc [file join $project_root 05_constraints nvmetcp_offload.xdc]
synth_design -top nvmetcp_offload_top -part $part_name

report_utilization -file [file join $report_dir utilization.rpt]
report_timing_summary -delay_type max -max_paths 20 -file [file join $report_dir timing_summary.rpt]
report_cdc -details -file [file join $report_dir cdc.rpt]
report_methodology -file [file join $report_dir methodology.rpt]
check_timing -verbose -file [file join $report_dir check_timing.rpt]

set worst_path [get_timing_paths -delay_type max -max_paths 1]
if {[llength $worst_path] == 0} {
  puts stderr "ERROR: no timing path found"
  exit 3
}
set worst_slack [get_property SLACK $worst_path]
puts "WORST_SLACK_NS=$worst_slack"
if {$worst_slack < 0.0} {
  puts stderr "ERROR: 200 MHz timing requirement failed"
  exit 4
}
exit 0
