set project_root [file normalize [lindex $argv 0]]
set generated_dir [file join $project_root 04_vivado generated]
set part_name "xc7a200tsbg484-1"
if {[info exists ::env(PART)] && $::env(PART) ne ""} {
  set part_name $::env(PART)
}

file mkdir $generated_dir
create_project nvmetcp_offload $generated_dir -part $part_name -force
set include_dir [file join $project_root 02_rtl]
set rtl_files [glob -nocomplain [file join $project_root 02_rtl *.v]]
set header_files [glob -nocomplain [file join $include_dir *.vh]]
add_files -norecurse $rtl_files
foreach header_file $header_files {
  add_files -norecurse $header_file
  set_property file_type {Verilog Header} [get_files $header_file]
}
set_property include_dirs [list $include_dir] [current_fileset]
add_files -fileset constrs_1 -norecurse [file join $project_root 05_constraints nvmetcp_offload.xdc]
set_property top nvmetcp_offload_top [current_fileset]
update_compile_order -fileset sources_1
save_project_as nvmetcp_offload $generated_dir -force
