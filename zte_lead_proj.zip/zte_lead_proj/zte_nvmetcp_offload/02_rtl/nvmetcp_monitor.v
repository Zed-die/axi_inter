`include "//?/F:/codex_proj/zte_lead_proj/zte_nvmetcp_offload/02_rtl/nvmetcp_defs.vh"

module nvmetcp_monitor (
  input                       clk,
  input                       rst_n,
  input                       action_fire,
  input [`NVMETCP_ACTION_META_W-1:0] action_meta,
  input                       schedule_fire,
  input  [2:0]                schedule_conn,
  input                       overflow_attempt,
  input                       backpressure,
  input                       mon_clear,
  input  [11:0]               mon_addr,
  output reg [31:0]           mon_rdata
);
  reg [31:0] conn_packets [0:7];
  reg [31:0] schedule_count [0:7];
  reg [31:0] opcode_count [0:8];
  reg [31:0] fes_count [0:6];
  reg [31:0] total_errors;
  reg [31:0] overflow_count;
  reg [31:0] backpressure_count;
  reg [2:0]  latest_error_conn;
  reg [7:0]  latest_error_opcode;
  reg [15:0] latest_error_fes;
  reg [31:0] latest_error_fei;
  reg [3:0]  action_opcode_slot;
  integer reset_index;
  integer read_index;

  wire [2:0] action_conn;
  wire [7:0] action_pdu_type;
  wire [15:0] action_fes;
  wire [31:0] action_fei;
  wire action_error;

  assign action_conn =
      action_meta[`NVMETCP_META_CONN_ID_MSB:`NVMETCP_META_CONN_ID_LSB];
  assign action_pdu_type =
      action_meta[`NVMETCP_META_PDU_TYPE_MSB:`NVMETCP_META_PDU_TYPE_LSB];
  assign action_fes =
      action_meta[`NVMETCP_META_FES_MSB:`NVMETCP_META_FES_LSB];
  assign action_fei =
      action_meta[`NVMETCP_META_FEI_MSB:`NVMETCP_META_FEI_LSB];
  assign action_error = action_meta[`NVMETCP_META_ERROR_BIT];

  function [3:0] opcode_slot;
    input [7:0] pdu_type;
    begin
      case (pdu_type)
        `NVMETCP_PDU_ICREQ:       opcode_slot = 4'd0;
        `NVMETCP_PDU_ICRESP:      opcode_slot = 4'd1;
        `NVMETCP_PDU_H2CTERMREQ:  opcode_slot = 4'd2;
        `NVMETCP_PDU_C2HTERMREQ:  opcode_slot = 4'd3;
        `NVMETCP_PDU_CAPSULECMD:  opcode_slot = 4'd4;
        `NVMETCP_PDU_CAPSULERESP: opcode_slot = 4'd5;
        `NVMETCP_PDU_H2CDATA:     opcode_slot = 4'd6;
        `NVMETCP_PDU_C2HDATA:     opcode_slot = 4'd7;
        `NVMETCP_PDU_R2T:         opcode_slot = 4'd8;
        default:                   opcode_slot = 4'hf;
      endcase
    end
  endfunction

  function [31:0] sat_inc32;
    input [31:0] value;
    begin
      sat_inc32 = (&value) ? value : value + 32'd1;
    end
  endfunction

  always @* begin
    action_opcode_slot = opcode_slot(action_pdu_type);
    mon_rdata = 32'd0;
    if (mon_addr <= 12'h01c && mon_addr[1:0] == 0) begin
      read_index = mon_addr[6:2];
      if (read_index < 8)
        mon_rdata = conn_packets[read_index];
    end else if (mon_addr >= 12'h040 && mon_addr <= 12'h05c &&
                 mon_addr[1:0] == 0) begin
      read_index = (mon_addr - 12'h040) >> 2;
      if (read_index < 8)
        mon_rdata = schedule_count[read_index];
    end else if (mon_addr >= 12'h080 && mon_addr <= 12'h0a0 &&
                 mon_addr[1:0] == 0) begin
      read_index = (mon_addr - 12'h080) >> 2;
      if (read_index < 9)
        mon_rdata = opcode_count[read_index];
    end else if (mon_addr >= 12'h100 && mon_addr <= 12'h118 &&
                 mon_addr[1:0] == 0) begin
      read_index = (mon_addr - 12'h100) >> 2;
      if (read_index < 7)
        mon_rdata = fes_count[read_index];
    end else begin
      case (mon_addr)
        12'h0c0: mon_rdata = total_errors;
        12'h0c4: mon_rdata = overflow_count;
        12'h0c8: mon_rdata = backpressure_count;
        12'h0d0: mon_rdata = {29'd0, latest_error_conn};
        12'h0d4: mon_rdata = {24'd0, latest_error_opcode};
        12'h0d8: mon_rdata = {16'd0, latest_error_fes};
        12'h0dc: mon_rdata = latest_error_fei;
        default: mon_rdata = 32'd0;
      endcase
    end
  end

  always @(posedge clk) begin
    if (!rst_n || mon_clear) begin
      for (reset_index = 0; reset_index < 8;
           reset_index = reset_index + 1) begin
        conn_packets[reset_index] <= 32'd0;
        schedule_count[reset_index] <= 32'd0;
      end
      for (reset_index = 0; reset_index < 9;
           reset_index = reset_index + 1)
        opcode_count[reset_index] <= 32'd0;
      for (reset_index = 0; reset_index < 7;
           reset_index = reset_index + 1)
        fes_count[reset_index] <= 32'd0;
      total_errors <= 32'd0;
      overflow_count <= 32'd0;
      backpressure_count <= 32'd0;
      latest_error_conn <= 3'd0;
      latest_error_opcode <= 8'd0;
      latest_error_fes <= 16'd0;
      latest_error_fei <= 32'd0;
    end else begin
      if (action_fire) begin
        conn_packets[action_conn] <= sat_inc32(conn_packets[action_conn]);
        if (action_opcode_slot < 9)
          opcode_count[action_opcode_slot] <=
              sat_inc32(opcode_count[action_opcode_slot]);
        if (action_error) begin
          total_errors <= sat_inc32(total_errors);
          if (action_fes <= 6)
            fes_count[action_fes] <= sat_inc32(fes_count[action_fes]);
          latest_error_conn <= action_conn;
          latest_error_opcode <= action_pdu_type;
          latest_error_fes <= action_fes;
          latest_error_fei <= action_fei;
        end
      end
      if (schedule_fire)
        schedule_count[schedule_conn] <=
            sat_inc32(schedule_count[schedule_conn]);
      if (overflow_attempt)
        overflow_count <= sat_inc32(overflow_count);
      if (backpressure)
        backpressure_count <= sat_inc32(backpressure_count);
    end
  end
endmodule
