module nvmetcp_rr_scheduler (
  input        clk,
  input        rst_n,
  input  [7:0] pending,
  output       grant_valid,
  input        grant_ready,
  output [2:0] grant_id,
  input        grant_done
);
  reg [2:0] last_grant;
  reg [2:0] active_id;
  reg       active;
  reg       offer_valid;
  reg [2:0] offer_id;
  reg       candidate_valid;
  reg [2:0] candidate_id;
  integer   offset;
  integer   candidate_index;

  always @* begin
    candidate_valid = 1'b0;
    candidate_id = 3'd0;
    for (offset = 1; offset <= 8; offset = offset + 1) begin
      candidate_index = (last_grant + offset) & 7;
      if (!candidate_valid && pending[candidate_index]) begin
        candidate_valid = 1'b1;
        candidate_id = candidate_index[2:0];
      end
    end
  end

  assign grant_valid = offer_valid;
  assign grant_id = offer_id;

  always @(posedge clk) begin
    if (!rst_n) begin
      last_grant <= 3'd7;
      active_id <= 3'd0;
      active <= 1'b0;
      offer_valid <= 1'b0;
      offer_id <= 3'd0;
    end else begin
      if (!active && !offer_valid && candidate_valid) begin
        offer_valid <= 1'b1;
        offer_id <= candidate_id;
      end

      if (offer_valid && grant_ready) begin
        offer_valid <= 1'b0;
        active <= 1'b1;
        active_id <= offer_id;
      end

      if (active && grant_done) begin
        active <= 1'b0;
        last_grant <= active_id;
      end
    end
  end
endmodule
