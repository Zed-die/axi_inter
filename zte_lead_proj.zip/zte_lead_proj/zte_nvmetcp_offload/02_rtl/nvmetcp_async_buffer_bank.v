module nvmetcp_async_buffer_bank #(
  parameter integer NUM_CONN = 8,
  parameter integer DEPTH_WORDS = 32,
  parameter integer DATA_W = 512,
  parameter integer CONN_W = 3
) (
  input                         wr_clk,           //写入侧时钟，可以与核心处理时钟不同
  input                         wr_rst_n,         //写入侧低有效复位 
  input                         wr_valid,         //当前周期的wr_data有效 
  output reg                    wr_ready,         //当前连接缓存还有空间，可以接收数据 
  input  [CONN_W-1:0]           wr_conn,          //当前数据所属的连接编号，3-bit对应0～7号连接 
  input  [DATA_W-1:0]           wr_data,          //512-bit报文数据，每拍最多64 B 
  input  [(DATA_W/8)-1:0]       wr_keep,          //字节有效标志，每一位对应wr_data中的一个字节 
  input                         wr_last,          //当前拍是一个完整PDU的最后一拍 
  output reg                    overflow_attempt, //上游在缓存已满时仍尝试写入         

  input                         core_clk,         //仲裁、读取和解析模块使用的核心时钟
  input                         core_rst_n,       //核心时钟域低有效复位
  output reg [NUM_CONN-1:0]     pending,          //8路连接的数据就绪位，每一位对应一路连接
  input  [CONN_W-1:0]           rd_conn,          //指定读取哪一路连接  
  input                         rd_req,           //发起一次读取请求
  output reg                    rd_valid,         //当前rd_data、rd_keep和rd_last有效  
  output reg [DATA_W-1:0]       rd_data,          //从指定连接读出的512-bit数据  
  output reg [(DATA_W/8)-1:0]   rd_keep,          //当前拍的字节有效标志  
  output reg                    rd_last,          //当前拍是否为PDU最后一拍  
  input                         rd_consume        //下级确认已经接收当前输出数据    
);



  function integer clog2;
    input integer value;
    integer work;
    begin
      work = value - 1;
      clog2 = 0;
      while (work > 0) begin
        clog2 = clog2 + 1;
        work = work >> 1;
      end
    end
  endfunction

  localparam integer KEEP_W = DATA_W / 8;
  localparam integer ADDR_W = clog2(DEPTH_WORDS);
  localparam integer PTR_W = ADDR_W + 1;

  reg [DATA_W-1:0] mem_data [0:NUM_CONN*DEPTH_WORDS-1]; //保存真正的报文数据，512位宽，8通道各个通道32深度
  reg [KEEP_W-1:0] mem_keep [0:NUM_CONN*DEPTH_WORDS-1]; //保存报文字节有效标志
  reg              mem_last [0:NUM_CONN*DEPTH_WORDS-1]; //保存报文是否为PDU最后一拍

  reg  [PTR_W-1:0] wr_work_bin [0:NUM_CONN-1];
  reg  [PTR_W-1:0] wr_commit_bin [0:NUM_CONN-1];
  wire [PTR_W-1:0] wr_commit_gray [0:NUM_CONN-1];
  wire [PTR_W-1:0] wr_commit_core [0:NUM_CONN-1];
  wire [PTR_W-1:0] wr_commit_core_gray [0:NUM_CONN-1];

  reg  [PTR_W-1:0] rd_bin [0:NUM_CONN-1];
  wire [PTR_W-1:0] rd_gray [0:NUM_CONN-1];
  wire [PTR_W-1:0] rd_wr [0:NUM_CONN-1];
  wire [PTR_W-1:0] rd_wr_gray [0:NUM_CONN-1];

  reg [PTR_W-1:0] selected_wr_next;
  reg             selected_full;
  reg [CONN_W-1:0] rd_conn_hold;
  integer reset_index;
  integer pending_index;
  genvar connection;

  initial begin
    if (DEPTH_WORDS < 2 || (DEPTH_WORDS & (DEPTH_WORDS - 1)) != 0) begin
      $display("DEPTH_WORDS must be a power of two and at least two");
      $finish;
    end
  end

  generate
    for (connection = 0; connection < NUM_CONN; connection = connection + 1) begin : g_pointer_cdc
      nvmetcp_gray_sync #(.WIDTH(PTR_W)) u_commit_sync (
        .src_bin(wr_commit_bin[connection]),
        .src_gray(wr_commit_gray[connection]),
        .dst_clk(core_clk),
        .dst_rst_n(core_rst_n),
        .dst_gray(wr_commit_core_gray[connection]),
        .dst_bin(wr_commit_core[connection])
      );

      nvmetcp_gray_sync #(.WIDTH(PTR_W)) u_read_sync (
        .src_bin(rd_bin[connection]),
        .src_gray(rd_gray[connection]),
        .dst_clk(wr_clk),
        .dst_rst_n(wr_rst_n),
        .dst_gray(rd_wr_gray[connection]),
        .dst_bin(rd_wr[connection])
      );
    end
  endgenerate

  always @* begin
    selected_wr_next = wr_work_bin[wr_conn] + {{(PTR_W-1){1'b0}}, 1'b1};
    selected_full = wr_work_bin[wr_conn] == {
      ~rd_wr[wr_conn][PTR_W-1], rd_wr[wr_conn][PTR_W-2:0]
    };
    wr_ready = !selected_full;

    for (pending_index = 0; pending_index < NUM_CONN;
         pending_index = pending_index + 1)
      pending[pending_index] =
          wr_commit_core[pending_index] != rd_bin[pending_index];
  end

  always @(posedge wr_clk) begin
    if (!wr_rst_n) begin
      overflow_attempt <= 1'b0;
      for (reset_index = 0; reset_index < NUM_CONN;
           reset_index = reset_index + 1) begin
        wr_work_bin[reset_index] <= {PTR_W{1'b0}};
        wr_commit_bin[reset_index] <= {PTR_W{1'b0}};
      end
    end else begin
      overflow_attempt <= wr_valid && !wr_ready;
      if (wr_valid && wr_ready) begin
        mem_data[(wr_conn * DEPTH_WORDS) +
                 wr_work_bin[wr_conn][ADDR_W-1:0]] <= wr_data;
        mem_keep[(wr_conn * DEPTH_WORDS) +
                 wr_work_bin[wr_conn][ADDR_W-1:0]] <= wr_keep;
        mem_last[(wr_conn * DEPTH_WORDS) +
                 wr_work_bin[wr_conn][ADDR_W-1:0]] <= wr_last;
        wr_work_bin[wr_conn] <= selected_wr_next;
        if (wr_last)
          wr_commit_bin[wr_conn] <= selected_wr_next;
      end
    end
  end

  always @(posedge core_clk) begin
    if (!core_rst_n) begin
      rd_valid <= 1'b0;
      rd_data <= {DATA_W{1'b0}};
      rd_keep <= {KEEP_W{1'b0}};
      rd_last <= 1'b0;
      rd_conn_hold <= {CONN_W{1'b0}};
      for (reset_index = 0; reset_index < NUM_CONN;
           reset_index = reset_index + 1)
        rd_bin[reset_index] <= {PTR_W{1'b0}};
    end else begin
      if (rd_valid && rd_consume) begin
        rd_bin[rd_conn_hold] <=
            rd_bin[rd_conn_hold] + {{(PTR_W-1){1'b0}}, 1'b1};
        rd_valid <= 1'b0;
      end

      if (!rd_valid && rd_req && pending[rd_conn]) begin
        rd_conn_hold <= rd_conn;
        rd_data <= mem_data[(rd_conn * DEPTH_WORDS) +
                            rd_bin[rd_conn][ADDR_W-1:0]];
        rd_keep <= mem_keep[(rd_conn * DEPTH_WORDS) +
                            rd_bin[rd_conn][ADDR_W-1:0]];
        rd_last <= mem_last[(rd_conn * DEPTH_WORDS) +
                            rd_bin[rd_conn][ADDR_W-1:0]];
        rd_valid <= 1'b1;
      end
    end
  end
endmodule
