`include "//?/F:/codex_proj/zte_lead_proj/zte_nvmetcp_offload/02_rtl/nvmetcp_defs.vh"

module nvmetcp_response_gen (
  input                       clk,
  input                       rst_n,
  input                       request_valid,
  output reg                  request_ready,
  input [`NVMETCP_ACTION_META_W-1:0] request_meta,
  output reg                  tx_valid,
  input                       tx_ready,
  output reg [511:0]          tx_data,
  output reg [63:0]           tx_keep,
  output reg                  tx_last,
  output reg [2:0]            tx_conn
);
  localparam [1:0] STATE_IDLE = 2'd0;
  localparam [1:0] STATE_SEND0 = 2'd1;
  localparam [1:0] STATE_SEND1 = 2'd2;

  reg [1:0] state;
  reg [511:0] response0;
  reg [511:0] response1;
  reg [63:0] keep0;
  reg [63:0] keep1;
  reg        last0;
  reg [2:0]  response_conn;

  function [511:0] build_icresp;
    input unused;
    reg [511:0] result;
    begin
      result = 512'd0;
      result[7:0] = `NVMETCP_PDU_ICRESP;
      result[15:8] = 8'h00;
      result[23:16] = 8'd128;
      result[31:24] = 8'h00;
      result[63:32] = 32'd128;
      result[79:64] = 16'h0000;
      result[87:80] = 8'h00;
      result[95:88] = 8'h00;
      result[127:96] = 32'd4096;
      build_icresp = result;
    end
  endfunction

  function [511:0] build_termreq;
    input [`NVMETCP_ACTION_META_W-1:0] meta;
    reg [511:0] result;
    begin
      result = 512'd0;
      result[7:0] =
          meta[`NVMETCP_META_PDU_TYPE_LSB] ?
          `NVMETCP_PDU_H2CTERMREQ : `NVMETCP_PDU_C2HTERMREQ;
      result[15:8] = 8'h00;
      result[23:16] = 8'd24;
      result[31:24] = 8'h00;
      result[63:32] = 32'd24;
      result[79:64] =
          meta[`NVMETCP_META_FES_MSB:`NVMETCP_META_FES_LSB];
      result[111:80] =
          meta[`NVMETCP_META_FEI_MSB:`NVMETCP_META_FEI_LSB];
      build_termreq = result;
    end
  endfunction

  always @* begin
    request_ready = state == STATE_IDLE;
    tx_valid = state != STATE_IDLE;
    tx_conn = response_conn;
    if (state == STATE_SEND1) begin
      tx_data = response1;
      tx_keep = keep1;
      tx_last = 1'b1;
    end else begin
      tx_data = response0;
      tx_keep = keep0;
      tx_last = last0;
    end
  end

  always @(posedge clk) begin
    if (!rst_n) begin
      state <= STATE_IDLE;
      response0 <= 512'd0;
      response1 <= 512'd0;
      keep0 <= 64'd0;
      keep1 <= 64'd0;
      last0 <= 1'b0;
      response_conn <= 3'd0;
    end else begin
      case (state)
        STATE_IDLE: begin
          if (request_valid && request_ready) begin
            if (request_meta[`NVMETCP_META_ERROR_BIT]) begin
              response0 <= build_termreq(request_meta);
              response1 <= 512'd0;
              keep0 <= 64'h0000_0000_00ff_ffff;
              keep1 <= 64'd0;
              last0 <= 1'b1;
              response_conn <= request_meta[
                  `NVMETCP_META_CONN_ID_MSB:`NVMETCP_META_CONN_ID_LSB];
              state <= STATE_SEND0;
            end else if (request_meta[
                `NVMETCP_META_ACTION_MSB:`NVMETCP_META_ACTION_LSB]
                == `NVMETCP_ACT_ICREQ) begin
              response0 <= build_icresp(1'b0);
              response1 <= 512'd0;
              keep0 <= 64'hffff_ffff_ffff_ffff;
              keep1 <= 64'hffff_ffff_ffff_ffff;
              last0 <= 1'b0;
              response_conn <= request_meta[
                  `NVMETCP_META_CONN_ID_MSB:`NVMETCP_META_CONN_ID_LSB];
              state <= STATE_SEND0;
            end
          end
        end

        STATE_SEND0: begin
          if (tx_valid && tx_ready) begin
            if (last0)
              state <= STATE_IDLE;
            else
              state <= STATE_SEND1;
          end
        end

        STATE_SEND1: begin
          if (tx_valid && tx_ready)
            state <= STATE_IDLE;
        end

        default: state <= STATE_IDLE;
      endcase
    end
  end
endmodule
