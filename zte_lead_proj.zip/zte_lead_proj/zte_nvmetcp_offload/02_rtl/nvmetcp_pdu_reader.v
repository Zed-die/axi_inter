module nvmetcp_pdu_reader (
  input          clk,
  input          rst_n,

  input          grant_valid,
  output reg     grant_ready,
  input  [2:0]   grant_id,
  output reg     grant_done,

  output reg     rd_req,
  output reg [2:0] rd_conn,
  input          rd_valid,
  input  [511:0] rd_data,
  input  [63:0]  rd_keep,
  input          rd_last,
  output reg     rd_consume,

  output reg     out_valid,
  input          out_ready,
  output reg [511:0] out_data,
  output reg [63:0]  out_keep,
  output reg     out_start,
  output reg     out_last,
  output reg [2:0] out_conn,

  output reg     frame_error_valid,
  output reg [2:0] frame_error_conn
);
  localparam [1:0] STATE_IDLE = 2'd0;
  localparam [1:0] STATE_REQUEST = 2'd1;
  localparam [1:0] STATE_HOLD = 2'd2;

  reg [1:0]  state;
  reg [2:0]  active_conn;
  reg [31:0] plen;
  reg [31:0] expected_beats;
  reg [31:0] beat_index;
  reg [31:0] current_plen;
  reg [31:0] current_expected_beats;
  reg        expected_last;
  reg [63:0] expected_keep;

  function [63:0] keep_for_plen;
    input [31:0] length;
    reg [5:0] remainder;
    begin
      remainder = length[5:0];
      if (remainder == 0)
        keep_for_plen = 64'hffff_ffff_ffff_ffff;
      else
        keep_for_plen = (64'h1 << remainder) - 64'h1;
    end
  endfunction

  always @* begin
    grant_ready = state == STATE_IDLE;
    rd_req = state == STATE_REQUEST;
    rd_conn = active_conn;

    out_valid = ((state == STATE_REQUEST) || (state == STATE_HOLD)) && rd_valid;
    out_data = rd_data;
    out_keep = rd_keep;
    out_start = beat_index == 0;
    out_last = rd_last;
    out_conn = active_conn;
    rd_consume = out_valid && out_ready;

    current_plen = (beat_index == 0) ? rd_data[63:32] : plen;
    current_expected_beats = (beat_index == 0) ?
                             ((rd_data[63:32] + 32'd63) >> 6) : expected_beats;
    expected_last = (beat_index + 32'd1) == current_expected_beats;
    expected_keep = keep_for_plen(current_plen);
  end

  always @(posedge clk) begin
    if (!rst_n) begin
      state <= STATE_IDLE;
      active_conn <= 3'd0;
      plen <= 32'd0;
      expected_beats <= 32'd0;
      beat_index <= 32'd0;
      grant_done <= 1'b0;
      frame_error_valid <= 1'b0;
      frame_error_conn <= 3'd0;
    end else begin
      grant_done <= 1'b0;
      frame_error_valid <= 1'b0;

      case (state)
        STATE_IDLE: begin
          if (grant_valid && grant_ready) begin
            active_conn <= grant_id;
            beat_index <= 32'd0;
            state <= STATE_REQUEST;
          end
        end

        STATE_REQUEST: begin
          if (rd_valid) begin
            if (beat_index == 0) begin
              plen <= rd_data[63:32];
              expected_beats <= (rd_data[63:32] + 32'd63) >> 6;
            end
            if (out_ready) begin
              if ((rd_last != expected_last) ||
                  (rd_last && (rd_keep != expected_keep))) begin
                frame_error_valid <= 1'b1;
                frame_error_conn <= active_conn;
              end

              if (rd_last) begin
                grant_done <= 1'b1;
                state <= STATE_IDLE;
              end else begin
                beat_index <= beat_index + 32'd1;
                state <= STATE_REQUEST;
              end
            end else begin
              state <= STATE_HOLD;
            end
          end
        end

        STATE_HOLD: begin
          if (out_valid && out_ready) begin
            if ((rd_last != expected_last) ||
                (rd_last && (rd_keep != expected_keep))) begin
              frame_error_valid <= 1'b1;
              frame_error_conn <= active_conn;
            end

            if (rd_last) begin
              grant_done <= 1'b1;
              state <= STATE_IDLE;
            end else begin
              beat_index <= beat_index + 32'd1;
              state <= STATE_REQUEST;
            end
          end
        end

        default: state <= STATE_IDLE;
      endcase
    end
  end
endmodule
