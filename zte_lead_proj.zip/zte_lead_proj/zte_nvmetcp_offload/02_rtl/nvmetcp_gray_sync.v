//跨时钟域模块
module nvmetcp_gray_sync #(
  parameter integer WIDTH = 6
) (
  input  [WIDTH-1:0]     src_bin,
  output [WIDTH-1:0]     src_gray,
  input                  dst_clk,
  input                  dst_rst_n,
  output [WIDTH-1:0]     dst_gray,
  output reg [WIDTH-1:0] dst_bin
);
  (* ASYNC_REG = "TRUE" *) reg [WIDTH-1:0] sync_gray_ff1;
  (* ASYNC_REG = "TRUE" *) reg [WIDTH-1:0] sync_gray_ff2;
  integer bit_index;

  assign src_gray = (src_bin >> 1) ^ src_bin;
  assign dst_gray = sync_gray_ff2;

  always @(posedge dst_clk) begin
    if (!dst_rst_n) begin
      sync_gray_ff1 <= {WIDTH{1'b0}};
      sync_gray_ff2 <= {WIDTH{1'b0}};
    end else begin
      sync_gray_ff1 <= src_gray;
      sync_gray_ff2 <= sync_gray_ff1;
    end
  end

  always @* begin
    dst_bin[WIDTH-1] = sync_gray_ff2[WIDTH-1];
    for (bit_index = WIDTH - 2; bit_index >= 0; bit_index = bit_index - 1)
      dst_bin[bit_index] = dst_bin[bit_index + 1] ^ sync_gray_ff2[bit_index];
  end
endmodule
