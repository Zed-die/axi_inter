`include "//?/F:/codex_proj/zte_lead_proj/zte_nvmetcp_offload/02_rtl/nvmetcp_defs.vh"

module nvmetcp_parser (
  input                         clk,
  input                         rst_n,
  input                         in_valid,
  output reg                    in_ready,
  input  [511:0]                in_data,
  input  [63:0]                 in_keep,
  input                         in_start,
  input                         in_last,
  input  [2:0]                  in_conn,
  output reg                    action_valid,
  input                         action_ready,
  output reg [`NVMETCP_ACTION_META_W-1:0] action_meta,
  output reg                    payload_valid,
  input                         payload_ready,
  output reg [511:0]            payload_data,
  output reg [63:0]             payload_keep,
  output reg                    payload_start,
  output reg                    payload_last,
  output reg [2:0]              payload_conn
);
  localparam [1:0] STATE_IDLE = 2'd0;
  localparam [1:0] STATE_ACTION = 2'd1;
  localparam [1:0] STATE_STREAM = 2'd2;
  localparam [1:0] STATE_LOAD = 2'd3;

  reg [1:0] state;
  reg [`NVMETCP_ACTION_META_W-1:0] meta_reg;
  reg [511:0] beat_data;
  reg [63:0]  beat_keep;
  reg         beat_start;
  reg         beat_last;
  reg [2:0]   beat_conn;

  function [7:0] fixed_hlen;
    input [7:0] pdu_type;
    begin
      case (pdu_type)
        `NVMETCP_PDU_ICREQ,
        `NVMETCP_PDU_ICRESP:      fixed_hlen = 8'd128;
        `NVMETCP_PDU_CAPSULECMD:  fixed_hlen = 8'd72;
        `NVMETCP_PDU_H2CTERMREQ,
        `NVMETCP_PDU_C2HTERMREQ,
        `NVMETCP_PDU_CAPSULERESP,
        `NVMETCP_PDU_H2CDATA,
        `NVMETCP_PDU_C2HDATA,
        `NVMETCP_PDU_R2T:         fixed_hlen = 8'd24;
        default:                   fixed_hlen = 8'd0;
      endcase
    end
  endfunction

  function [7:0] get_byte512;
    input [511:0] data; 
    input integer index;
    begin
      get_byte512 = data[index*8 +: 8];
    end
  endfunction

  function [15:0] get_le16_512;
    input [511:0] data;
    input integer index;
    begin
      get_le16_512 = {
        get_byte512(data, index + 1), get_byte512(data, index)
      };
    end
  endfunction

  function [31:0] get_le32_512;
    input [511:0] data;
    input integer index;
    begin
      get_le32_512 = {
        get_byte512(data, index + 3),
        get_byte512(data, index + 2),
        get_byte512(data, index + 1),
        get_byte512(data, index)
      };
    end
  endfunction

  function [`NVMETCP_ACTION_META_W-1:0] make_error;
    input [`NVMETCP_ACTION_META_W-1:0] base;
    input [15:0] fes;
    input [31:0] fei;
    reg [`NVMETCP_ACTION_META_W-1:0] result;
    begin
      result = base;
      result[`NVMETCP_META_ACTION_MSB:`NVMETCP_META_ACTION_LSB] =
          `NVMETCP_ACT_TERMINATE;
      result[`NVMETCP_META_CCCID_MSB:`NVMETCP_META_CCCID_LSB] = 16'd0;
      result[`NVMETCP_META_TTAG_MSB:`NVMETCP_META_TTAG_LSB] = 16'd0;
      result[`NVMETCP_META_DATA_OFFSET_MSB:
             `NVMETCP_META_DATA_OFFSET_LSB] = 32'd0;
      result[`NVMETCP_META_DATA_LENGTH_MSB:
             `NVMETCP_META_DATA_LENGTH_LSB] = 32'd0;
      result[`NVMETCP_META_FES_MSB:`NVMETCP_META_FES_LSB] = fes;
      result[`NVMETCP_META_FEI_MSB:`NVMETCP_META_FEI_LSB] = fei;
      result[`NVMETCP_META_ERROR_BIT] = 1'b1;
      make_error = result;
    end
  endfunction

  function [`NVMETCP_ACTION_META_W-1:0] decode_header;
    input [511:0] data;
    input [2:0] conn;
    reg [`NVMETCP_ACTION_META_W-1:0] result;
    reg [7:0] pdu_type;
    reg [7:0] flags;
    reg [7:0] hlen;
    reg [7:0] pdo;
    reg [31:0] plen;
    reg [7:0] digest_mask;
    reg [7:0] allowed_mask;
    reg [31:0] field_length;
    begin
      result = {`NVMETCP_ACTION_META_W{1'b0}};
      pdu_type = get_byte512(data, 0);
      flags = get_byte512(data, 1);
      hlen = get_byte512(data, 2);
      pdo = get_byte512(data, 3);
      plen = get_le32_512(data, 4);
      result[`NVMETCP_META_CONN_ID_MSB:`NVMETCP_META_CONN_ID_LSB] = conn;
      result[`NVMETCP_META_PDU_TYPE_MSB:`NVMETCP_META_PDU_TYPE_LSB] =
          pdu_type;
      result[`NVMETCP_META_FLAGS_MSB:`NVMETCP_META_FLAGS_LSB] = flags;
      result[`NVMETCP_META_PLEN_MSB:`NVMETCP_META_PLEN_LSB] = plen;

      case (pdu_type)
        `NVMETCP_PDU_ICREQ:
          result[`NVMETCP_META_ACTION_MSB:`NVMETCP_META_ACTION_LSB] =
              `NVMETCP_ACT_ICREQ;
        `NVMETCP_PDU_ICRESP:
          result[`NVMETCP_META_ACTION_MSB:`NVMETCP_META_ACTION_LSB] =
              `NVMETCP_ACT_ICRESP;
        `NVMETCP_PDU_H2CTERMREQ,
        `NVMETCP_PDU_C2HTERMREQ:
          result[`NVMETCP_META_ACTION_MSB:`NVMETCP_META_ACTION_LSB] =
              `NVMETCP_ACT_TERMINATE;
        `NVMETCP_PDU_CAPSULECMD:
          result[`NVMETCP_META_ACTION_MSB:`NVMETCP_META_ACTION_LSB] =
              `NVMETCP_ACT_CAPSULE_CMD;
        `NVMETCP_PDU_CAPSULERESP:
          result[`NVMETCP_META_ACTION_MSB:`NVMETCP_META_ACTION_LSB] =
              `NVMETCP_ACT_CAPSULE_RESP;
        `NVMETCP_PDU_H2CDATA:
          result[`NVMETCP_META_ACTION_MSB:`NVMETCP_META_ACTION_LSB] =
              `NVMETCP_ACT_H2C_DATA;
        `NVMETCP_PDU_C2HDATA:
          result[`NVMETCP_META_ACTION_MSB:`NVMETCP_META_ACTION_LSB] =
              `NVMETCP_ACT_C2H_DATA;
        `NVMETCP_PDU_R2T:
          result[`NVMETCP_META_ACTION_MSB:`NVMETCP_META_ACTION_LSB] =
              `NVMETCP_ACT_R2T;
        default:
          result = make_error(result, `NVMETCP_FES_INVALID_HEADER, 32'd0);
      endcase

      if (!result[`NVMETCP_META_ERROR_BIT]) begin
        if (hlen != fixed_hlen(pdu_type))
          result = make_error(result, `NVMETCP_FES_INVALID_HEADER, 32'd2);
        else if (plen < hlen || plen > `NVMETCP_MAX_PDU_BYTES)
          result = make_error(result, `NVMETCP_FES_INVALID_HEADER, 32'd4);
      end

      digest_mask = 8'h00;
      allowed_mask = 8'h00;
      case (pdu_type)
        `NVMETCP_PDU_CAPSULECMD:  digest_mask = 8'h03;
        `NVMETCP_PDU_CAPSULERESP: digest_mask = 8'h01;
        `NVMETCP_PDU_H2CDATA: begin
          digest_mask = 8'h03;
          allowed_mask = 8'h04;
        end
        `NVMETCP_PDU_C2HDATA: begin
          digest_mask = 8'h03;
          allowed_mask = 8'h0c;
        end
        `NVMETCP_PDU_R2T: digest_mask = 8'h01;
        default: begin
          digest_mask = 8'h00;
          allowed_mask = 8'h00;
        end
      endcase

      if (!result[`NVMETCP_META_ERROR_BIT]) begin
        if ((flags & digest_mask) != 0)
          result = make_error(result, `NVMETCP_FES_UNSUPPORTED_PARAM, 32'd1);
        else if ((flags & ~allowed_mask) != 0)
          result = make_error(result, `NVMETCP_FES_INVALID_HEADER, 32'd1);
      end

      if (!result[`NVMETCP_META_ERROR_BIT]) begin
        case (pdu_type)
          `NVMETCP_PDU_ICREQ,
          `NVMETCP_PDU_ICRESP: begin
            if (plen != 32'd128)
              result = make_error(result, `NVMETCP_FES_INVALID_HEADER, 32'd4);
            else if (pdo != 0)
              result = make_error(result, `NVMETCP_FES_INVALID_HEADER, 32'd3);
            else if (get_le16_512(data, 8) != 0)
              result = make_error(result, `NVMETCP_FES_UNSUPPORTED_PARAM, 32'd8);
            else if (get_byte512(data, 10) != 0)
              result = make_error(result, `NVMETCP_FES_UNSUPPORTED_PARAM,
                                  32'd10);
            else if (get_byte512(data, 11) != 0)
              result = make_error(result, `NVMETCP_FES_UNSUPPORTED_PARAM,
                                  32'd11);
          end

          `NVMETCP_PDU_H2CTERMREQ,
          `NVMETCP_PDU_C2HTERMREQ: begin
            if (plen > 32'd152)
              result = make_error(result, `NVMETCP_FES_INVALID_HEADER, 32'd4);
            else if (pdo != 0)
              result = make_error(result, `NVMETCP_FES_INVALID_HEADER, 32'd3);
            else begin
              result[`NVMETCP_META_FES_MSB:`NVMETCP_META_FES_LSB] =
                  get_le16_512(data, 8);
              result[`NVMETCP_META_FEI_MSB:`NVMETCP_META_FEI_LSB] =
                  get_le32_512(data, 10);
            end
          end

          `NVMETCP_PDU_CAPSULECMD: begin
            if (pdo != ((plen == 32'd72) ? 8'd0 : 8'd72))
              result = make_error(result, `NVMETCP_FES_INVALID_HEADER, 32'd3);
            else begin
              result[`NVMETCP_META_CCCID_MSB:`NVMETCP_META_CCCID_LSB] =
                  get_le16_512(data, 10);
              result[`NVMETCP_META_DATA_LENGTH_MSB:
                     `NVMETCP_META_DATA_LENGTH_LSB] =
                  (pdo == 0) ? 32'd0 : plen - pdo;
            end
          end

          `NVMETCP_PDU_CAPSULERESP: begin
            if (plen != 32'd24)
              result = make_error(result, `NVMETCP_FES_INVALID_HEADER, 32'd4);
            else if (pdo != 0)
              result = make_error(result, `NVMETCP_FES_INVALID_HEADER, 32'd3);
            else
              result[`NVMETCP_META_CCCID_MSB:`NVMETCP_META_CCCID_LSB] =
                  get_le16_512(data, 20);
          end

          `NVMETCP_PDU_H2CDATA: begin
            field_length = get_le32_512(data, 16);
            if (pdo != 8'd24)
              result = make_error(result, `NVMETCP_FES_INVALID_HEADER, 32'd3);
            else if (field_length != (plen - 32'd24))
              result = make_error(result, `NVMETCP_FES_INVALID_HEADER,
                                  32'd16);
            else if ((get_le32_512(data, 12) & 32'h3) != 0 ||
                     (field_length & 32'h3) != 0)
              result = make_error(result, `NVMETCP_FES_INVALID_HEADER,
                                  32'd12);
            else begin
              result[`NVMETCP_META_CCCID_MSB:`NVMETCP_META_CCCID_LSB] =
                  get_le16_512(data, 8);
              result[`NVMETCP_META_TTAG_MSB:`NVMETCP_META_TTAG_LSB] =
                  get_le16_512(data, 10);
              result[`NVMETCP_META_DATA_OFFSET_MSB:
                     `NVMETCP_META_DATA_OFFSET_LSB] = get_le32_512(data, 12);
              result[`NVMETCP_META_DATA_LENGTH_MSB:
                     `NVMETCP_META_DATA_LENGTH_LSB] = field_length;
            end
          end

          `NVMETCP_PDU_C2HDATA: begin
            field_length = get_le32_512(data, 16);
            if (pdo != 8'd24)
              result = make_error(result, `NVMETCP_FES_INVALID_HEADER, 32'd3);
            else if (field_length != (plen - 32'd24))
              result = make_error(result, `NVMETCP_FES_INVALID_HEADER,
                                  32'd16);
            else if ((get_le32_512(data, 12) & 32'h3) != 0 ||
                     (field_length & 32'h3) != 0)
              result = make_error(result, `NVMETCP_FES_INVALID_HEADER,
                                  32'd12);
            else begin
              result[`NVMETCP_META_CCCID_MSB:`NVMETCP_META_CCCID_LSB] =
                  get_le16_512(data, 8);
              result[`NVMETCP_META_DATA_OFFSET_MSB:
                     `NVMETCP_META_DATA_OFFSET_LSB] = get_le32_512(data, 12);
              result[`NVMETCP_META_DATA_LENGTH_MSB:
                     `NVMETCP_META_DATA_LENGTH_LSB] = field_length;
            end
          end

          `NVMETCP_PDU_R2T: begin
            if (plen != 32'd24)
              result = make_error(result, `NVMETCP_FES_INVALID_HEADER, 32'd4);
            else if (pdo != 0)
              result = make_error(result, `NVMETCP_FES_INVALID_HEADER, 32'd3);
            else if ((get_le32_512(data, 12) & 32'h3) != 0 ||
                     (get_le32_512(data, 16) & 32'h3) != 0)
              result = make_error(result, `NVMETCP_FES_INVALID_HEADER,
                                  32'd12);
            else begin
              result[`NVMETCP_META_CCCID_MSB:`NVMETCP_META_CCCID_LSB] =
                  get_le16_512(data, 8);
              result[`NVMETCP_META_TTAG_MSB:`NVMETCP_META_TTAG_LSB] =
                  get_le16_512(data, 10);
              result[`NVMETCP_META_DATA_OFFSET_MSB:
                     `NVMETCP_META_DATA_OFFSET_LSB] = get_le32_512(data, 12);
              result[`NVMETCP_META_DATA_LENGTH_MSB:
                     `NVMETCP_META_DATA_LENGTH_LSB] = get_le32_512(data, 16);
            end
          end

          default:
            result = make_error(result, `NVMETCP_FES_INVALID_HEADER, 32'd0);
        endcase
      end

      decode_header = result;
    end
  endfunction

  always @* begin
    in_ready = (state == STATE_IDLE) || (state == STATE_LOAD);
    action_valid = state == STATE_ACTION;
    action_meta = meta_reg;
    payload_valid = state == STATE_STREAM;
    payload_data = beat_data;
    payload_keep = beat_keep;
    payload_start = beat_start;
    payload_last = beat_last;
    payload_conn = beat_conn;
  end

  always @(posedge clk) begin
    if (!rst_n) begin
      state <= STATE_IDLE;
      meta_reg <= {`NVMETCP_ACTION_META_W{1'b0}};
      beat_data <= 512'd0;
      beat_keep <= 64'd0;
      beat_start <= 1'b0;
      beat_last <= 1'b0;
      beat_conn <= 3'd0;
    end else begin
      case (state)
        STATE_IDLE: begin
          if (in_valid && in_ready) begin
            beat_data <= in_data;
            beat_keep <= in_keep;
            beat_start <= in_start;
            beat_last <= in_last;
            beat_conn <= in_conn;
            meta_reg <= decode_header(in_data, in_conn);
            state <= STATE_ACTION;
          end
        end

        STATE_ACTION: begin
          if (action_valid && action_ready)
            state <= STATE_STREAM;
        end

        STATE_STREAM: begin
          if (payload_valid && payload_ready) begin
            if (beat_last)
              state <= STATE_IDLE;
            else
              state <= STATE_LOAD;
          end
        end

        STATE_LOAD: begin
          if (in_valid && in_ready) begin
            beat_data <= in_data;
            beat_keep <= in_keep;
            beat_start <= in_start;
            beat_last <= in_last;
            beat_conn <= in_conn;
            state <= STATE_STREAM;
          end
        end

        default: state <= STATE_IDLE;
      endcase
    end
  end
endmodule
