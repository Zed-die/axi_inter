import json

from generate_vectors import build_cases, write_vectors


def test_cases_cover_every_opcode_and_error_class():
    cases = build_cases()
    names = {case["name"] for case in cases}

    assert {
        "valid_icreq",
        "valid_icresp",
        "valid_h2ctermreq",
        "valid_c2htermreq",
        "valid_capsulecmd",
        "valid_capsuleresp",
        "valid_h2cdata",
        "valid_c2hdata",
        "valid_r2t",
    } <= names
    assert {
        "invalid_opcode",
        "invalid_hlen",
        "invalid_plen",
        "invalid_digest",
        "invalid_pfv",
        "invalid_alignment",
        "invalid_pdo",
        "invalid_data_length",
    } <= names


def test_vector_files_are_self_consistent(tmp_path):
    write_vectors(tmp_path)

    manifest = json.loads((tmp_path / "manifest.json").read_text(encoding="utf-8"))
    packet_bytes = bytes.fromhex((tmp_path / "packets.hex").read_text(encoding="ascii"))

    assert len(manifest) >= 17
    for case in manifest:
        assert case["offset"] + case["length"] <= len(packet_bytes)
