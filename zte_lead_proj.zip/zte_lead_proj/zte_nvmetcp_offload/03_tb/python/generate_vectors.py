"""Generate deterministic byte streams and expected parser outcomes."""

import json
from pathlib import Path

from nvmetcp_model import PduType, ProtocolError, build_pdu, parse_pdu


def _mutate(raw, offset, value, size=1):
    changed = bytearray(raw)
    changed[offset : offset + size] = int(value).to_bytes(size, "little")
    return bytes(changed)


def _case(name, raw):
    try:
        parsed = parse_pdu(raw)
        expected = {
            key: int(value) if isinstance(value, (PduType, bool)) else value
            for key, value in parsed.items()
        }
        expected.update({"error": 0, "fes": 0, "fei": 0})
    except ProtocolError as error:
        expected = {"error": 1, "fes": error.fes, "fei": error.fei}
    return {"name": name, "raw": raw, "expected": expected}


def build_cases():
    valid = [
        ("valid_icreq", build_pdu(PduType.ICREQ)),
        ("valid_icresp", build_pdu(PduType.ICRESP)),
        ("valid_h2ctermreq", build_pdu(PduType.H2CTERMREQ, fes=2, fei=4)),
        ("valid_c2htermreq", build_pdu(PduType.C2HTERMREQ, fes=6, fei=11)),
        ("valid_capsulecmd", build_pdu(PduType.CAPSULECMD, cccid=0x1010)),
        ("valid_capsuleresp", build_pdu(PduType.CAPSULERESP, cccid=0x2020)),
        (
            "valid_h2cdata",
            build_pdu(
                PduType.H2CDATA,
                cccid=0x3030,
                ttag=0x4040,
                data_offset=0x100,
                data=b"\x11\x22\x33\x44",
                last_pdu=True,
            ),
        ),
        (
            "valid_c2hdata",
            build_pdu(
                PduType.C2HDATA,
                cccid=0x5050,
                data_offset=0x200,
                data=b"\x55\x66\x77\x88",
                last_pdu=True,
                success=True,
            ),
        ),
        (
            "valid_r2t",
            build_pdu(
                PduType.R2T,
                cccid=0x6060,
                ttag=0x7070,
                data_offset=0x400,
                data_length=0x1000,
            ),
        ),
    ]

    r2t = build_pdu(PduType.R2T)
    capsule_response = build_pdu(PduType.CAPSULERESP)
    icreq = build_pdu(PduType.ICREQ)
    h2cdata = build_pdu(PduType.H2CDATA, data=b"\x01\x02\x03\x04")
    invalid = [
        ("invalid_opcode", _mutate(r2t, 0, 0x08)),
        ("invalid_hlen", _mutate(r2t, 2, 25)),
        ("invalid_plen", _mutate(capsule_response, 4, 28, 4)),
        ("invalid_digest", _mutate(capsule_response, 1, 1)),
        ("invalid_pfv", _mutate(icreq, 8, 1)),
        ("invalid_alignment", _mutate(icreq, 10, 1)),
        ("invalid_pdo", _mutate(r2t, 3, 4)),
        ("invalid_data_length", _mutate(h2cdata, 16, 8, 4)),
    ]

    return [_case(name, raw) for name, raw in valid + invalid]


def write_vectors(output_dir):
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    packet_stream = bytearray()
    manifest = []
    for case in build_cases():
        offset = len(packet_stream)
        packet_stream.extend(case["raw"])
        manifest.append(
            {
                "name": case["name"],
                "offset": offset,
                "length": len(case["raw"]),
                "expected": case["expected"],
            }
        )

    (output_dir / "packets.hex").write_text(
        "\n".join(f"{byte:02x}" for byte in packet_stream) + "\n",
        encoding="ascii",
    )
    (output_dir / "manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    write_vectors(Path(__file__).resolve().parents[1] / "vectors")
