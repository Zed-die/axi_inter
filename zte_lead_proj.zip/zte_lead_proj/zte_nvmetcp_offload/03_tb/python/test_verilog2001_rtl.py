from pathlib import Path
import re
import subprocess


ROOT = Path(__file__).resolve().parents[2]
RTL = ROOT / "02_rtl"
COMMON = RTL
FORBIDDEN = re.compile(
    r"\b(package|import|logic|bit|typedef|struct|enum|always_ff|always_comb|"
    r"always_latch|interface|modport)\b|::|\$clog2"
)


def assert_verilog2001(*paths: Path) -> None:
    for path in paths:
        assert path.suffix in {".v", ".vh"}
        text = path.read_text(encoding="utf-8")
        assert not FORBIDDEN.search(text), path


def compile_verilog2001(top: str, *sources: Path) -> None:
    result = subprocess.run(
        [
            "iverilog",
            "-g2001",
            "-tnull",
            "-s",
            top,
            "-I",
            str(COMMON),
            *(str(path) for path in sources),
        ],
        cwd=ROOT,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, result.stdout + result.stderr


def test_common_rtl_is_header_only_verilog2001():
    header = RTL / "nvmetcp_defs.vh"
    assert header.is_file()
    assert_verilog2001(header)


def test_metadata_layout_is_stable():
    text = (COMMON / "nvmetcp_defs.vh").read_text(encoding="utf-8")
    expected = {
        "NVMETCP_ACTION_META_W": "200",
        "NVMETCP_META_ERROR_BIT": "0",
        "NVMETCP_META_FEI_MSB": "32",
        "NVMETCP_META_CONN_ID_MSB": "199",
    }
    for name, value in expected.items():
        assert re.search(rf"`define\s+{name}\s+{value}\b", text)


def test_metadata_consumers_use_approved_absolute_include():
    approved = (
        '`include "//?/F:/codex_proj/zte_lead_proj/zte_nvmetcp_offload/'
        '02_rtl/nvmetcp_defs.vh"'
    )
    consumers = [
        RTL / "nvmetcp_offload_top.v",
        RTL / "nvmetcp_parser.v",
        RTL / "nvmetcp_monitor.v",
        RTL / "nvmetcp_response_gen.v",
        ROOT / "03_tb" / "sv" / "nvmetcp_pkg.sv",
    ]
    for consumer in consumers:
        first_line = consumer.read_text(encoding="utf-8").splitlines()[0]
        assert first_line == approved, consumer


def test_leaf_modules_compile_as_verilog2001():
    sources = [
        RTL / "nvmetcp_gray_sync.v",
        RTL / "nvmetcp_rr_scheduler.v",
        RTL / "nvmetcp_pdu_reader.v",
    ]
    assert_verilog2001(*sources)
    tops = [
        "nvmetcp_gray_sync",
        "nvmetcp_rr_scheduler",
        "nvmetcp_pdu_reader",
    ]
    for source, top in zip(sources, tops):
        compile_verilog2001(top, source)


def test_async_buffer_compiles_as_verilog2001():
    gray = RTL / "nvmetcp_gray_sync.v"
    buffer_bank = RTL / "nvmetcp_async_buffer_bank.v"
    assert_verilog2001(buffer_bank)
    compile_verilog2001("nvmetcp_async_buffer_bank", gray, buffer_bank)


def test_parser_compiles_as_verilog2001():
    parser = RTL / "nvmetcp_parser.v"
    assert_verilog2001(parser)
    compile_verilog2001("nvmetcp_parser", parser)


def test_metadata_consumers_compile_as_verilog2001():
    sources = [
        RTL / "nvmetcp_response_gen.v",
        RTL / "nvmetcp_monitor.v",
    ]
    assert_verilog2001(*sources)
    for source, top in zip(
        sources, ["nvmetcp_response_gen", "nvmetcp_monitor"]
    ):
        compile_verilog2001(top, source)


def test_entire_rtl_tree_is_flat_verilog2001():
    expected = [
        "nvmetcp_async_buffer_bank.v",
        "nvmetcp_defs.vh",
        "nvmetcp_gray_sync.v",
        "nvmetcp_monitor.v",
        "nvmetcp_offload_top.v",
        "nvmetcp_parser.v",
        "nvmetcp_pdu_reader.v",
        "nvmetcp_response_gen.v",
        "nvmetcp_rr_scheduler.v",
    ]
    files = sorted(path.name for path in RTL.iterdir() if path.is_file())
    assert files == expected
    assert not [path for path in RTL.iterdir() if path.is_dir()]
    verilog_sources = sorted(RTL.glob("*.v"))
    sources = verilog_sources + sorted(RTL.glob("*.vh"))
    assert_verilog2001(*sources)


def test_filelist_uses_verilog_rtl():
    lines = (
        ROOT / "03_tb" / "sv" / "filelist.f"
    ).read_text(encoding="utf-8").splitlines()
    assert any("03_tb/sv/nvmetcp_pkg.sv" in line for line in lines)
    assert all("02_rtl" not in line or line.endswith(".v") for line in lines)


def test_top_compiles_as_verilog2001():
    sources = sorted(RTL.glob("*.v"))
    compile_verilog2001("nvmetcp_offload_top", *sources)
