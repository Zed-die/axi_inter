from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]


def test_acceptance_directories_exist():
    expected = [
        f"{number:02d}_{name}"
        for number, name in [
            (0, "requirements"),
            (1, "docs"),
            (2, "rtl"),
            (3, "tb"),
            (4, "vivado"),
            (5, "constraints"),
            (6, "scripts"),
            (7, "reports"),
            (8, "delivery"),
        ]
    ]
    assert all((ROOT / name).is_dir() for name in expected)


def test_source_requirement_is_preserved():
    assert (
        ROOT / "00_requirements" / "IC开发岗位领军班课题资料.pdf"
    ).is_file()
