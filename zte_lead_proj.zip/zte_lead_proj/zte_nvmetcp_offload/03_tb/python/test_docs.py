from pathlib import Path
import hashlib
import re
import subprocess


ROOT = Path(__file__).resolve().parents[2]


def test_every_source_requirement_has_implementation_test_and_evidence():
    text = (ROOT / "00_requirements" / "requirements_traceability.md").read_text(
        encoding="utf-8"
    )
    rows = [line for line in text.splitlines() if line.startswith("| REQ-")]
    assert len(rows) == 8
    for number in range(1, 9):
        row = next(line for line in rows if f"REQ-{number:03d}" in line)
        assert "02_rtl/" in row
        assert "tb_" in row or "test_" in row
        assert "07_reports/" in row


def test_protocol_document_lists_all_nine_pdus():
    text = (ROOT / "01_docs" / "protocol_support.md").read_text(encoding="utf-8")
    for name in [
        "ICReq",
        "ICResp",
        "H2CTermReq",
        "C2HTermReq",
        "CapsuleCmd",
        "CapsuleResp",
        "H2CData",
        "C2HData",
        "R2T",
    ]:
        assert name in text


def test_interface_document_lists_top_level_contract():
    text = (ROOT / "01_docs" / "interfaces.md").read_text(encoding="utf-8")
    for port in [
        "wr_valid",
        "wr_ready",
        "wr_conn",
        "wr_data",
        "wr_keep",
        "wr_last",
        "action_valid",
        "action_meta",
        "payload_valid",
        "tx_valid",
        "mon_addr",
        "mon_rdata",
    ]:
        assert f"`{port}`" in text


def test_rtl_detailed_design_covers_modules_topics_and_line_counts():
    path = ROOT / "01_docs" / "rtl_detailed_design.md"
    assert path.is_file()
    text = path.read_text(encoding="utf-8")

    modules = [
        "nvmetcp_defs.vh",
        "nvmetcp_gray_sync.v",
        "nvmetcp_async_buffer_bank.v",
        "nvmetcp_rr_scheduler.v",
        "nvmetcp_pdu_reader.v",
        "nvmetcp_parser.v",
        "nvmetcp_response_gen.v",
        "nvmetcp_monitor.v",
        "nvmetcp_offload_top.v",
    ]
    for module in modules:
        assert module in text

    topics = [
        "Verilog-2001",
        "action_meta[199:0]",
        "ready/valid",
        "Gray Code",
        "51.603 Gb/s",
        "NOT_RUN_NO_VIVADO",
        "ICReq",
        "非法 PDU",
        "多连接轮询",
    ]
    for topic in topics:
        assert topic in text

    categories = {
        "RTL 设计": ["02_rtl/**/*.v", "02_rtl/**/*.vh"],
        "SystemVerilog 验证": ["03_tb/sv/*.sv"],
        "Python 工具与测试": ["03_tb/python/*.py"],
        "Vivado Tcl": ["04_vivado/*.tcl"],
        "PowerShell 脚本": ["06_scripts/*.ps1"],
        "XDC 约束": ["05_constraints/*.xdc"],
    }
    total_files = 0
    total_lines = 0
    for label, patterns in categories.items():
        files = sorted({
            source
            for pattern in patterns
            for source in ROOT.glob(pattern)
            if source.is_file()
        })
        lines = sum(
            len(source.read_text(encoding="utf-8").splitlines())
            for source in files
        )
        total_files += len(files)
        total_lines += lines
        row = (
            rf"\|\s*{re.escape(label)}\s*\|\s*{len(files)}\s*\|"
            rf"\s*{lines:,}\s*\|"
        )
        assert re.search(row, text)

    total_row = (
        rf"\|\s*源码合计\s*\|\s*{total_files}\s*\|\s*{total_lines:,}\s*\|"
    )
    assert re.search(total_row, text)

    for non_goal in ["TCP/IP", "TLS", "DDR", "NVMe 命令执行"]:
        assert f"{non_goal}：未实现" in text


def test_documents_declare_verilog_rtl_and_systemverilog_verification():
    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    interfaces = (ROOT / "01_docs" / "interfaces.md").read_text(
        encoding="utf-8"
    )
    traceability = (
        ROOT / "00_requirements" / "requirements_traceability.md"
    ).read_text(encoding="utf-8")
    assert "Verilog-2001 RTL" in readme
    assert "SystemVerilog 验证" in readme
    assert "200 bit" in interfaces
    assert "02_rtl/" in traceability
    assert "02_rtl/" not in "\n".join(
        line for line in traceability.splitlines() if ".sv" in line
    )


def test_delivery_readme_has_real_commands_and_status_semantics():
    text = (ROOT / "08_delivery" / "README.md").read_text(encoding="utf-8")
    assert "run_regression.ps1" in text
    assert "run_vivado.ps1" in text
    assert "ExecutionPolicy Bypass" in text
    assert "NOT_RUN_NO_VIVADO" in text


def test_packaging_script_is_scoped_and_hashes_manifest():
    text = (ROOT / "06_scripts" / "package_delivery.ps1").read_text(
        encoding="utf-8"
    )
    assert "GetFullPath" in text
    assert "08_delivery/package" in text
    assert "MANIFEST.sha256" in text
    assert "Compress-Archive" in text


def test_generated_delivery_excludes_build_and_python_caches():
    script = ROOT / "06_scripts" / "package_delivery.ps1"
    result = subprocess.run(
        [
            "powershell",
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            str(script),
        ],
        cwd=ROOT,
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 0, result.stderr

    package = ROOT / "08_delivery" / "package"
    files = [path for path in package.rglob("*") if path.is_file()]
    forbidden = [
        path
        for path in files
        if "__pycache__" in path.parts
        or ".pytest_cache" in path.parts
        or path.suffix.lower() in {".pyc", ".vvp", ".vcd", ".wdb", ".jou", ".log"}
    ]
    assert forbidden == []

    manifest = (package / "MANIFEST.sha256").read_text(encoding="utf-8").splitlines()
    assert len(manifest) == len(files) - 1
    for line in manifest:
        expected_hash, relative = line.split("  ", 1)
        packaged_file = package / Path(relative)
        assert packaged_file.is_file()
        assert hashlib.sha256(packaged_file.read_bytes()).hexdigest() == expected_hash


def test_acceptance_status_distinguishes_verified_and_unavailable_checks():
    text = (ROOT / "08_delivery" / "acceptance_status.md").read_text(
        encoding="utf-8"
    )
    assert "LOCAL_REGRESSION: PASS" in text
    assert "VIVADO: NOT_RUN_NO_VIVADO" in text
    assert "51.603 Gb/s" in text
    assert "pytest 8.4.1" in text
    assert "Icarus Verilog version 12.0" in text
    assert "VERIFIED_SOURCE_COMMIT" in text
