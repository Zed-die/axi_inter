"""Executable byte-level golden model for the scoped NVMe/TCP transport PDUs."""

from enum import IntEnum


class PduType(IntEnum):
    ICREQ = 0x00
    ICRESP = 0x01
    H2CTERMREQ = 0x02
    C2HTERMREQ = 0x03
    CAPSULECMD = 0x04
    CAPSULERESP = 0x05
    H2CDATA = 0x06
    C2HDATA = 0x07
    R2T = 0x09


FIXED_HLEN = {
    PduType.ICREQ: 128,
    PduType.ICRESP: 128,
    PduType.H2CTERMREQ: 24,
    PduType.C2HTERMREQ: 24,
    PduType.CAPSULECMD: 72,
    PduType.CAPSULERESP: 24,
    PduType.H2CDATA: 24,
    PduType.C2HDATA: 24,
    PduType.R2T: 24,
}

MAX_PDU_BYTES = 8264


class ProtocolError(ValueError):
    def __init__(self, fes, fei, message):
        self.fes = int(fes)
        self.fei = int(fei)
        super().__init__(message)


def _put_le(buffer, offset, value, size):
    buffer[offset : offset + size] = int(value).to_bytes(size, "little")


def _get_le(buffer, offset, size):
    return int.from_bytes(buffer[offset : offset + size], "little")


def build_common_header(pdu_type, flags, hlen, pdo, plen):
    return bytes((int(pdu_type), flags, hlen, pdo)) + int(plen).to_bytes(
        4, "little"
    )


def parse_common_header(raw):
    if len(raw) < 8:
        raise ProtocolError(0x01, 4, "truncated common header")
    try:
        pdu_type = PduType(raw[0])
    except ValueError as exc:
        raise ProtocolError(0x01, 0, "unsupported opcode") from exc
    return pdu_type, raw[1], raw[2], raw[3], int.from_bytes(raw[4:8], "little")


def build_pdu(
    pdu_type,
    *,
    cccid=0,
    ttag=0,
    data_offset=0,
    data_length=0,
    data=b"",
    last_pdu=False,
    success=False,
    fes=1,
    fei=0,
    maxh2cdata=4096,
):
    pdu_type = PduType(pdu_type)
    data = bytes(data)
    if len(data) % 4:
        raise ValueError("PDU data length must be dword aligned")

    hlen = FIXED_HLEN[pdu_type]
    flags = 0
    pdo = 0

    if pdu_type == PduType.H2CDATA:
        flags = 0x04 if last_pdu else 0
        pdo = hlen
    elif pdu_type == PduType.C2HDATA:
        flags = (0x04 if last_pdu else 0) | (0x08 if success else 0)
        pdo = hlen
    elif pdu_type == PduType.CAPSULECMD and data:
        pdo = hlen

    plen = hlen + len(data)
    raw = bytearray(plen)
    raw[0:8] = build_common_header(pdu_type, flags, hlen, pdo, plen)

    if pdu_type == PduType.ICRESP:
        _put_le(raw, 12, maxh2cdata, 4)
    elif pdu_type in (PduType.H2CTERMREQ, PduType.C2HTERMREQ):
        _put_le(raw, 8, fes, 2)
        _put_le(raw, 10, fei, 4)
    elif pdu_type == PduType.CAPSULECMD:
        _put_le(raw, 10, cccid, 2)
    elif pdu_type == PduType.CAPSULERESP:
        _put_le(raw, 20, cccid, 2)
    elif pdu_type == PduType.H2CDATA:
        _put_le(raw, 8, cccid, 2)
        _put_le(raw, 10, ttag, 2)
        _put_le(raw, 12, data_offset, 4)
        _put_le(raw, 16, len(data), 4)
    elif pdu_type == PduType.C2HDATA:
        _put_le(raw, 8, cccid, 2)
        _put_le(raw, 12, data_offset, 4)
        _put_le(raw, 16, len(data), 4)
    elif pdu_type == PduType.R2T:
        _put_le(raw, 8, cccid, 2)
        _put_le(raw, 10, ttag, 2)
        _put_le(raw, 12, data_offset, 4)
        _put_le(raw, 16, data_length, 4)

    if data:
        raw[pdo : pdo + len(data)] = data
    return bytes(raw)


def _validate_flags(pdu_type, flags):
    digest_mask = {
        PduType.CAPSULECMD: 0x03,
        PduType.CAPSULERESP: 0x01,
        PduType.H2CDATA: 0x03,
        PduType.C2HDATA: 0x03,
        PduType.R2T: 0x01,
    }.get(pdu_type, 0)
    allowed_mask = {
        PduType.H2CDATA: 0x04,
        PduType.C2HDATA: 0x0C,
    }.get(pdu_type, 0)
    if flags & digest_mask:
        raise ProtocolError(0x06, 1, "unsupported digest flag")
    if flags & ~allowed_mask:
        raise ProtocolError(0x01, 1, "reserved flag is nonzero")


def _validate_pdo(pdu_type, pdo, plen, hlen):
    no_data_offset = {
        PduType.ICREQ,
        PduType.ICRESP,
        PduType.H2CTERMREQ,
        PduType.C2HTERMREQ,
        PduType.CAPSULERESP,
        PduType.R2T,
    }
    if pdu_type in no_data_offset and pdo != 0:
        raise ProtocolError(0x01, 3, "PDO is reserved")
    if pdu_type == PduType.CAPSULECMD:
        expected = 0 if plen == hlen else hlen
        if pdo != expected or pdo % 4:
            raise ProtocolError(0x01, 3, "invalid capsule data offset")
    if pdu_type in (PduType.H2CDATA, PduType.C2HDATA):
        if pdo != hlen or pdo % 4:
            raise ProtocolError(0x01, 3, "invalid data offset")


def parse_pdu(raw):
    raw = bytes(raw)
    pdu_type, flags, hlen, pdo, plen = parse_common_header(raw)
    expected_hlen = FIXED_HLEN[pdu_type]
    if hlen != expected_hlen:
        raise ProtocolError(0x01, 2, "invalid fixed header length")
    if plen != len(raw) or plen < hlen or plen > MAX_PDU_BYTES:
        raise ProtocolError(0x01, 4, "invalid PDU length")

    _validate_flags(pdu_type, flags)
    _validate_pdo(pdu_type, pdo, plen, hlen)

    if pdu_type in (PduType.ICREQ, PduType.ICRESP):
        if raw[8:10] != b"\x00\x00":
            raise ProtocolError(0x06, 8, "unsupported protocol format version")
        if raw[10] != 0:
            raise ProtocolError(0x06, 10, "unsupported PDU data alignment")
        if raw[11] != 0:
            raise ProtocolError(0x06, 11, "unsupported digest request")

    result = {
        "pdu_type": pdu_type,
        "flags": flags,
        "hlen": hlen,
        "pdo": pdo,
        "plen": plen,
        "cccid": 0,
        "ttag": 0,
        "data_offset": 0,
        "data_length": 0,
        "last_pdu": bool(flags & 0x04),
        "success": bool(flags & 0x08),
        "fes": 0,
        "fei": 0,
    }

    if pdu_type in (PduType.H2CTERMREQ, PduType.C2HTERMREQ):
        result["fes"] = _get_le(raw, 8, 2)
        result["fei"] = _get_le(raw, 10, 4)
    elif pdu_type == PduType.CAPSULECMD:
        result["cccid"] = _get_le(raw, 10, 2)
        result["data_length"] = plen - pdo if pdo else 0
    elif pdu_type == PduType.CAPSULERESP:
        result["cccid"] = _get_le(raw, 20, 2)
    elif pdu_type == PduType.H2CDATA:
        result["cccid"] = _get_le(raw, 8, 2)
        result["ttag"] = _get_le(raw, 10, 2)
        result["data_offset"] = _get_le(raw, 12, 4)
        result["data_length"] = _get_le(raw, 16, 4)
    elif pdu_type == PduType.C2HDATA:
        result["cccid"] = _get_le(raw, 8, 2)
        result["data_offset"] = _get_le(raw, 12, 4)
        result["data_length"] = _get_le(raw, 16, 4)
    elif pdu_type == PduType.R2T:
        result["cccid"] = _get_le(raw, 8, 2)
        result["ttag"] = _get_le(raw, 10, 2)
        result["data_offset"] = _get_le(raw, 12, 4)
        result["data_length"] = _get_le(raw, 16, 4)

    if pdu_type in (PduType.H2CDATA, PduType.C2HDATA):
        actual_data_length = plen - pdo
        if result["data_length"] != actual_data_length:
            raise ProtocolError(0x01, 16, "data length does not match PLEN")
        if result["data_length"] % 4 or result["data_offset"] % 4:
            raise ProtocolError(0x01, 12, "data fields are not dword aligned")
    elif pdu_type == PduType.R2T:
        if result["data_length"] % 4 or result["data_offset"] % 4:
            raise ProtocolError(0x01, 12, "R2T fields are not dword aligned")

    return result
