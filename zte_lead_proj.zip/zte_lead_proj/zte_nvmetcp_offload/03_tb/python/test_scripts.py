from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]


def test_vivado_script_is_guarded():
    text = (ROOT / "06_scripts" / "run_vivado.ps1").read_text(encoding="utf-8")
    assert "Get-Command vivado" in text
    assert "exit 2" in text
    assert "Vivado executable not found" in text


def test_xdc_declares_core_and_asynchronous_clocks():
    text = (ROOT / "05_constraints" / "nvmetcp_offload.xdc").read_text(
        encoding="utf-8"
    )
    assert "create_clock -period 5.000" in text
    assert "set_clock_groups -asynchronous" in text
    assert "ASYNC_REG" in text


def test_local_regression_runs_model_and_all_sv_benches():
    text = (ROOT / "06_scripts" / "run_regression.ps1").read_text(
        encoding="utf-8"
    )
    assert "generate_vectors.py" in text
    assert "pytest" in text
    for bench in [
        "tb_pkg",
        "tb_rr_scheduler",
        "tb_gray_sync",
        "tb_async_buffer_bank",
        "tb_pdu_reader",
        "tb_parser",
        "tb_response_gen",
        "tb_monitor",
        "tb_offload_top",
    ]:
        assert bench in text


def test_vivado_flow_emits_required_reports():
    text = (ROOT / "04_vivado" / "run_synth.tcl").read_text(encoding="utf-8")
    assert "report_utilization" in text
    assert "report_timing_summary" in text
    assert "report_cdc" in text
    assert "report_methodology" in text


def test_vivado_reads_design_as_verilog_not_systemverilog():
    create = (ROOT / "04_vivado" / "create_project.tcl").read_text(
        encoding="utf-8"
    )
    synth = (ROOT / "04_vivado" / "run_synth.tcl").read_text(
        encoding="utf-8"
    )
    assert "*.v" in create
    assert "*.sv" not in create
    assert "include_dirs" in create
    assert "read_verilog -sv" not in synth
    assert "read_verilog -include_dirs" in synth
