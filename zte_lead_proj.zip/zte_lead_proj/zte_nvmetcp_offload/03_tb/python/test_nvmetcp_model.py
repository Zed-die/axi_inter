import pytest

from nvmetcp_model import PduType, ProtocolError, build_pdu, parse_pdu


@pytest.mark.parametrize(
    "pdu_type,hlen",
    [
        (PduType.ICREQ, 128),
        (PduType.ICRESP, 128),
        (PduType.H2CTERMREQ, 24),
        (PduType.C2HTERMREQ, 24),
        (PduType.CAPSULECMD, 72),
        (PduType.CAPSULERESP, 24),
        (PduType.H2CDATA, 24),
        (PduType.C2HDATA, 24),
        (PduType.R2T, 24),
    ],
)
def test_each_supported_type_round_trips(pdu_type, hlen):
    raw = build_pdu(pdu_type)

    result = parse_pdu(raw)

    assert result["pdu_type"] == pdu_type
    assert result["hlen"] == hlen
    assert result["plen"] == len(raw)


def test_data_fields_round_trip():
    raw = build_pdu(
        PduType.H2CDATA,
        cccid=0x1234,
        ttag=0x5678,
        data_offset=0x100,
        data=b"\x11\x22\x33\x44\x55\x66\x77\x88",
        last_pdu=True,
    )

    result = parse_pdu(raw)

    assert result["cccid"] == 0x1234
    assert result["ttag"] == 0x5678
    assert result["data_offset"] == 0x100
    assert result["data_length"] == 8
    assert result["last_pdu"] is True


def test_r2t_fields_round_trip():
    raw = build_pdu(
        PduType.R2T,
        cccid=0x1020,
        ttag=0x3040,
        data_offset=0x400,
        data_length=0x1000,
    )

    result = parse_pdu(raw)

    assert result["cccid"] == 0x1020
    assert result["ttag"] == 0x3040
    assert result["data_offset"] == 0x400
    assert result["data_length"] == 0x1000


def test_digest_flag_is_rejected():
    raw = bytearray(build_pdu(PduType.CAPSULERESP))
    raw[1] = 1

    with pytest.raises(ProtocolError, match="unsupported digest") as error:
        parse_pdu(bytes(raw))

    assert error.value.fes == 0x06
    assert error.value.fei == 1


def test_wrong_hlen_is_rejected_at_byte_two():
    raw = bytearray(build_pdu(PduType.R2T))
    raw[2] = 25

    with pytest.raises(ProtocolError) as error:
        parse_pdu(bytes(raw))

    assert error.value.fes == 0x01
    assert error.value.fei == 2


def test_wrong_plen_is_rejected_at_byte_four():
    raw = bytearray(build_pdu(PduType.CAPSULERESP))
    raw[4:8] = (28).to_bytes(4, "little")

    with pytest.raises(ProtocolError) as error:
        parse_pdu(bytes(raw))

    assert error.value.fes == 0x01
    assert error.value.fei == 4


def test_unknown_opcode_is_rejected_at_byte_zero():
    raw = bytearray(build_pdu(PduType.R2T))
    raw[0] = 0x08

    with pytest.raises(ProtocolError) as error:
        parse_pdu(bytes(raw))

    assert error.value.fes == 0x01
    assert error.value.fei == 0


def test_nonzero_connection_alignment_is_rejected():
    raw = bytearray(build_pdu(PduType.ICREQ))
    raw[10] = 1

    with pytest.raises(ProtocolError) as error:
        parse_pdu(bytes(raw))

    assert error.value.fes == 0x06
    assert error.value.fei == 10


def test_non_dword_data_is_rejected():
    with pytest.raises(ValueError, match="dword aligned"):
        build_pdu(PduType.H2CDATA, data=b"abc")
