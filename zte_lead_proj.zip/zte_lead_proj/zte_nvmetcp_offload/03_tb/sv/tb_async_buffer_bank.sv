`timescale 1ns/1ps

module tb_async_buffer_bank;
  logic         wr_clk = 1'b0;
  logic         wr_rst_n = 1'b0;
  logic         core_clk = 1'b0;
  logic         core_rst_n = 1'b0;
  logic         wr_valid = 1'b0;
  logic         wr_ready;
  logic [2:0]   wr_conn = 3'd0;
  logic [511:0] wr_data = '0;
  logic [63:0]  wr_keep = '0;
  logic         wr_last = 1'b0;
  logic         overflow_attempt;
  logic [7:0]   pending;
  logic [2:0]   rd_conn = 3'd0;
  logic         rd_req = 1'b0;
  logic         rd_valid;
  logic [511:0] rd_data;
  logic [63:0]  rd_keep;
  logic         rd_last;
  logic         rd_consume = 1'b0;
  integer       index;

  initial begin
    #10000;
    $display(
      "WATCHDOG pending=%b wr_conn=%0d wr_ready=%b rd_conn=%0d rd_req=%b rd_valid=%b rd_consume=%b",
      pending, wr_conn, wr_ready, rd_conn, rd_req, rd_valid, rd_consume
    );
    $display(
      "WATCHDOG c3 wr_work=%0d wr_commit=%0d wr_core=%0d rd=%0d",
      dut.wr_work_bin[3], dut.wr_commit_bin[3], dut.wr_commit_core[3], dut.rd_bin[3]
    );
    $display(
      "WATCHDOG c1 wr_work=%0d wr_commit=%0d wr_core=%0d rd_wr=%0d rd=%0d",
      dut.wr_work_bin[1], dut.wr_commit_bin[1], dut.wr_commit_core[1],
      dut.rd_wr[1], dut.rd_bin[1]
    );
    $fatal(1, "buffer test watchdog expired");
  end

  always #3.5 wr_clk = ~wr_clk;
  always #2.5 core_clk = ~core_clk;

  nvmetcp_async_buffer_bank #(
    .NUM_CONN(8),
    .DEPTH_WORDS(4),
    .DATA_W(512)
  ) dut (
    .wr_clk,
    .wr_rst_n,
    .wr_valid,
    .wr_ready,
    .wr_conn,
    .wr_data,
    .wr_keep,
    .wr_last,
    .overflow_attempt,
    .core_clk,
    .core_rst_n,
    .pending,
    .rd_conn,
    .rd_req,
    .rd_valid,
    .rd_data,
    .rd_keep,
    .rd_last,
    .rd_consume
  );

  task automatic write_beat(
    input logic [2:0] connection,
    input logic [511:0] data,
    input logic [63:0] keep,
    input logic last
  );
    integer wait_cycles;
    begin
      @(negedge wr_clk);
      wr_conn = connection;
      wr_data = data;
      wr_keep = keep;
      wr_last = last;
      wr_valid = 1'b1;
      wait_cycles = 0;
      while (!wr_ready) begin
        @(negedge wr_clk);
        wait_cycles = wait_cycles + 1;
        if (wait_cycles == 8)
          $fatal(1, "write did not become ready on connection %0d", connection);
      end
      @(posedge wr_clk);
      #1;
      wr_valid = 1'b0;
    end
  endtask

  task automatic read_beat(
    input logic [2:0] connection,
    input logic [511:0] wanted_data,
    input logic [63:0] wanted_keep,
    input logic wanted_last
  );
    begin
      @(negedge core_clk);
      rd_conn = connection;
      rd_req = 1'b1;
      @(posedge core_clk);
      #1;
      rd_req = 1'b0;
      while (!rd_valid) @(posedge core_clk);
      #1;
      if (rd_data !== wanted_data || rd_keep !== wanted_keep || rd_last !== wanted_last)
        $fatal(1, "read data mismatch on connection %0d", connection);
      @(negedge core_clk);
      rd_consume = 1'b1;
      @(posedge core_clk);
      #1;
      rd_consume = 1'b0;
    end
  endtask

  initial begin
    repeat (3) @(posedge core_clk);
    core_rst_n = 1'b1;
    repeat (2) @(posedge wr_clk);
    wr_rst_n = 1'b1;

    write_beat(3'd3, 512'h1111, 64'hffff_ffff_ffff_ffff, 1'b0);
    repeat (4) @(posedge core_clk);
    #1;
    if (pending[3]) $fatal(1, "partial PDU became visible before commit");

    write_beat(3'd3, 512'h2222, 64'h0000_0000_00ff_ffff, 1'b1);
    repeat (4) @(posedge core_clk);
    #1;
    if (!pending[3]) $fatal(1, "committed PDU did not become visible");
    read_beat(3'd3, 512'h1111, 64'hffff_ffff_ffff_ffff, 1'b0);
    read_beat(3'd3, 512'h2222, 64'h0000_0000_00ff_ffff, 1'b1);
    repeat (2) @(posedge core_clk);
    #1;
    if (pending[3]) $fatal(1, "connection remained pending after consumption");

    for (index = 0; index < 8; index = index + 1) begin
      write_beat(3'd5, index, 64'h1, 1'b1);
      repeat (3) @(posedge core_clk);
      read_beat(3'd5, index, 64'h1, 1'b1);
      repeat (3) @(posedge wr_clk);
    end

    for (index = 0; index < 4; index = index + 1)
      write_beat(3'd1, 512'h100 + index, 64'h1, 1'b1);
    @(negedge wr_clk);
    wr_conn = 3'd1;
    #1;
    if (wr_ready) $fatal(1, "full connection still asserted wr_ready");
    wr_valid = 1'b1;
    @(posedge wr_clk);
    #1;
    if (!overflow_attempt) $fatal(1, "full write attempt was not reported");
    wr_valid = 1'b0;

    repeat (4) @(posedge core_clk);
    read_beat(3'd1, 512'h100, 64'h1, 1'b1);
    repeat (4) @(posedge wr_clk);
    wr_conn = 3'd1;
    #1;
    if (!wr_ready) $fatal(1, "write side did not observe consumed space");

    $display("TB_PASS tb_async_buffer_bank");
    $finish;
  end
endmodule
