`timescale 1ns/1ps

module tb_pkg;
  import nvmetcp_pkg::*;

  action_meta_t meta;
  logic [`NVMETCP_ACTION_META_W-1:0] meta_bits;

  initial begin
    if (PDU_ICREQ !== 8'h00 || PDU_R2T !== 8'h09)
      $fatal(1, "opcode mismatch");
    if (fixed_hlen(PDU_CAPSULECMD) !== 8'd72)
      $fatal(1, "HLEN mismatch");
    if (fixed_hlen(8'h08) !== 8'd0)
      $fatal(1, "reserved opcode HLEN mismatch");
    if (sat_inc32(32'hffff_ffff) !== 32'hffff_ffff)
      $fatal(1, "saturation mismatch");
    if (sat_inc32(32'd41) !== 32'd42)
      $fatal(1, "counter increment mismatch");
    if ($bits(action_meta_t) != `NVMETCP_ACTION_META_W)
      $fatal(1, "metadata width mismatch");
    meta = '0;
    meta.conn_id = 3'b101;
    meta.error = 1'b1;
    meta_bits = meta;
    if (meta_bits[`NVMETCP_META_CONN_ID_MSB:`NVMETCP_META_CONN_ID_LSB]
        !== 3'b101 || meta_bits[`NVMETCP_META_ERROR_BIT] !== 1'b1)
      $fatal(1, "metadata packed layout mismatch");
    $display("TB_PASS tb_pkg");
    $finish;
  end
endmodule
