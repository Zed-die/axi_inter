`timescale 1ns/1ps

module tb_offload_top;
  import nvmetcp_pkg::*;

  logic         wr_clk = 1'b0;
  logic         wr_rst_n = 1'b0;
  logic         core_clk = 1'b0;
  logic         core_rst_n = 1'b0;
  logic         wr_valid = 1'b0;
  logic         wr_ready;
  logic [2:0]   wr_conn = 3'd0;
  logic [511:0] wr_data = '0;
  logic [63:0]  wr_keep = '0;
  logic         wr_last = 1'b0;
  logic         action_valid;
  logic         action_ready = 1'b0;
  action_meta_t action_meta;
  logic         payload_valid;
  logic         payload_ready = 1'b1;
  logic [511:0] payload_data;
  logic [63:0]  payload_keep;
  logic         payload_start;
  logic         payload_last;
  logic [2:0]   payload_conn;
  logic         tx_valid;
  logic         tx_ready = 1'b0;
  logic [511:0] tx_data;
  logic [63:0]  tx_keep;
  logic         tx_last;
  logic [2:0]   tx_conn;
  logic         mon_clear = 1'b0;
  logic [11:0]  mon_addr = 12'd0;
  logic [31:0]  mon_rdata;
  logic [511:0] packet;
  integer       connection;
  integer       round_index;
  integer       beat_index;
  integer       active_cycles;
  integer       accepted_beats;
  integer       last_accept_cycle;
  integer       gap_cycles;
  integer       max_gap_cycles;
  real          throughput_gbps;

  initial begin
    if ($bits(action_meta) != `NVMETCP_ACTION_META_W)
      $fatal(1, "DUT/testbench metadata width mismatch");
  end

  always #3.5 wr_clk = ~wr_clk;
  always #2.5 core_clk = ~core_clk;

  nvmetcp_offload_top #(
    .NUM_CONN(8),
    .DEPTH_WORDS(128)
  ) dut (
    .wr_clk,
    .wr_rst_n,
    .wr_valid,
    .wr_ready,
    .wr_conn,
    .wr_data,
    .wr_keep,
    .wr_last,
    .core_clk,
    .core_rst_n,
    .action_valid,
    .action_ready,
    .action_meta,
    .payload_valid,
    .payload_ready,
    .payload_data,
    .payload_keep,
    .payload_start,
    .payload_last,
    .payload_conn,
    .tx_valid,
    .tx_ready,
    .tx_data,
    .tx_keep,
    .tx_last,
    .tx_conn,
    .mon_clear,
    .mon_addr,
    .mon_rdata
  );

  task automatic make_header(
    input logic [7:0] opcode,
    input logic [7:0] flags,
    input logic [7:0] hlen,
    input logic [7:0] pdo,
    input logic [31:0] plen
  );
    begin
      packet = '0;
      packet[7:0] = opcode;
      packet[15:8] = flags;
      packet[23:16] = hlen;
      packet[31:24] = pdo;
      packet[63:32] = plen;
    end
  endtask

  task automatic write_beat(
    input logic [2:0] connection_id,
    input logic [511:0] data,
    input logic [63:0] keep,
    input logic last
  );
    integer wait_count;
    begin
      @(negedge wr_clk);
      wr_conn = connection_id;
      wr_data = data;
      wr_keep = keep;
      wr_last = last;
      wr_valid = 1'b1;
      wait_count = 0;
      while (!wr_ready) begin
        @(negedge wr_clk);
        wait_count = wait_count + 1;
        if (wait_count == 500)
          $fatal(1, "write timeout on connection %0d", connection_id);
      end
      @(posedge wr_clk);
      #1;
      wr_valid = 1'b0;
    end
  endtask

  task automatic write_r2t(input logic [2:0] connection_id);
    begin
      make_header(PDU_R2T, 0, 24, 0, 24);
      packet[79:64] = {13'd0, connection_id};
      write_beat(connection_id, packet, 64'h00ff_ffff, 1'b1);
    end
  endtask

  task automatic expect_action(
    input logic [2:0] wanted_conn,
    input logic [3:0] wanted_action,
    input logic wanted_error
  );
    begin
      while (!action_valid) @(negedge core_clk);
      if (action_meta.conn_id !== wanted_conn ||
          action_meta.action !== wanted_action ||
          action_meta.error !== wanted_error)
        $fatal(1, "action mismatch wanted conn=%0d action=%0d got conn=%0d action=%0d error=%0d",
               wanted_conn, wanted_action, action_meta.conn_id,
               action_meta.action, action_meta.error);
      @(posedge core_clk);
      #1;
    end
  endtask

  task automatic accept_tx(
    input logic [7:0] wanted_opcode,
    input logic wanted_last
  );
    begin
      while (!tx_valid) @(negedge core_clk);
      if (tx_data[7:0] !== wanted_opcode || tx_last !== wanted_last)
        $fatal(1, "response mismatch wanted opcode=%02x last=%0d got opcode=%02x last=%0d",
               wanted_opcode, wanted_last, tx_data[7:0], tx_last);
      tx_ready = 1'b1;
      @(posedge core_clk);
      #1;
      tx_ready = 1'b0;
    end
  endtask

  initial begin
    repeat (4) @(posedge core_clk);
    core_rst_n = 1'b1;
    repeat (3) @(posedge wr_clk);
    wr_rst_n = 1'b1;

    action_ready = 1'b0;
    for (connection = 0; connection < 8; connection = connection + 1)
      write_r2t(connection[2:0]);
    action_ready = 1'b1;
    for (connection = 0; connection < 8; connection = connection + 1)
      expect_action(connection[2:0], ACT_R2T, 1'b0);

    action_ready = 1'b0;
    for (round_index = 0; round_index < 4; round_index = round_index + 1)
      for (connection = 0; connection < 8; connection = connection + 1)
        write_r2t(connection[2:0]);
    action_ready = 1'b1;
    for (round_index = 0; round_index < 4; round_index = round_index + 1)
      for (connection = 0; connection < 8; connection = connection + 1)
        expect_action(connection[2:0], ACT_R2T, 1'b0);

    tx_ready = 1'b0;
    make_header(PDU_ICREQ, 0, 128, 0, 128);
    write_beat(3'd2, packet, ~64'd0, 1'b0);
    write_beat(3'd2, '0, ~64'd0, 1'b1);
    expect_action(3'd2, ACT_ICREQ, 1'b0);
    accept_tx(PDU_ICRESP, 1'b0);
    accept_tx(8'h00, 1'b1);

    make_header(PDU_R2T, 0, 25, 0, 24);
    write_beat(3'd4, packet, 64'h00ff_ffff, 1'b1);
    expect_action(3'd4, ACT_TERMINATE, 1'b1);
    accept_tx(PDU_H2CTERMREQ, 1'b1);

    make_header(PDU_R2T, 0, 24, 0, 24);
    write_beat(3'd5, packet, 64'h000f_ffff, 1'b1);
    expect_action(3'd5, ACT_R2T, 1'b0);
    expect_action(3'd5, ACT_TERMINATE, 1'b1);
    accept_tx(PDU_H2CTERMREQ, 1'b1);

    make_header(PDU_H2CDATA, 8'h04, 24, 24, 4096);
    packet[159:128] = 32'd4072;
    write_beat(3'd0, packet, ~64'd0, 1'b0);
    for (beat_index = 1; beat_index < 64; beat_index = beat_index + 1)
      write_beat(3'd0, beat_index, ~64'd0, beat_index == 63);
    expect_action(3'd0, ACT_H2C_DATA, 1'b0);

    active_cycles = 0;
    accepted_beats = 0;
    last_accept_cycle = 0;
    max_gap_cycles = 0;
    while (accepted_beats < 64) begin
      @(posedge core_clk);
      active_cycles = active_cycles + 1;
      if (payload_valid && payload_ready) begin
        gap_cycles = active_cycles - last_accept_cycle;
        if (accepted_beats != 0 && gap_cycles > max_gap_cycles)
          max_gap_cycles = gap_cycles;
        last_accept_cycle = active_cycles;
        accepted_beats = accepted_beats + 1;
      end
      if (active_cycles > 300)
        $fatal(1, "payload throughput phase timed out");
    end
    throughput_gbps = (accepted_beats * 512.0 * 0.2) / active_cycles;
    $display("MEASURED_THROUGHPUT_GBPS %.3f MAX_GAP_CYCLES %0d",
             throughput_gbps, max_gap_cycles);
    if (throughput_gbps < 40.0)
      $fatal(1, "throughput below 40 Gb/s: %.3f", throughput_gbps);

    mon_addr = 12'h000;
    #1;
    if (mon_rdata < 32'd6)
      $fatal(1, "connection zero monitor count is too small");

    $display("TB_PASS tb_offload_top");
    $finish;
  end

  initial begin
    #500000;
    $fatal(1, "top-level test watchdog expired");
  end
endmodule
