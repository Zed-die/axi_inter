`timescale 1ns/1ps

module tb_response_gen;
  import nvmetcp_pkg::*;

  logic         clk = 1'b0;
  logic         rst_n = 1'b0;
  logic         request_valid = 1'b0;
  logic         request_ready;
  action_meta_t request_meta;
  logic         tx_valid;
  logic         tx_ready = 1'b0;
  logic [511:0] tx_data;
  logic [63:0]  tx_keep;
  logic         tx_last;
  logic [2:0]   tx_conn;
  logic [511:0] held_data;

  always #2.5 clk = ~clk;

  nvmetcp_response_gen dut (
    .clk,
    .rst_n,
    .request_valid,
    .request_ready,
    .request_meta,
    .tx_valid,
    .tx_ready,
    .tx_data,
    .tx_keep,
    .tx_last,
    .tx_conn
  );

  task automatic submit_request;
    begin
      while (!request_ready) @(posedge clk);
      @(negedge clk);
      request_valid = 1'b1;
      @(posedge clk);
      #1;
      request_valid = 1'b0;
    end
  endtask

  task automatic accept_tx_beat;
    begin
      while (!tx_valid) @(posedge clk);
      @(negedge clk);
      tx_ready = 1'b1;
      @(posedge clk);
      #1;
      tx_ready = 1'b0;
    end
  endtask

  initial begin
    request_meta = '0;
    repeat (3) @(posedge clk);
    rst_n = 1'b1;

    request_meta.conn_id = 3'd2;
    request_meta.pdu_type = PDU_ICREQ;
    request_meta.action = ACT_ICREQ;
    submit_request();
    while (!tx_valid) @(posedge clk);
    #1;
    if (tx_data[7:0] !== PDU_ICRESP || tx_data[15:8] !== 0 ||
        tx_data[23:16] !== 8'd128 || tx_data[31:24] !== 0 ||
        tx_data[63:32] !== 32'd128)
      $fatal(1, "ICResp common header mismatch");
    if (tx_data[95:64] !== 32'd0 || tx_data[127:96] !== 32'd4096)
      $fatal(1, "ICResp negotiation fields mismatch");
    if (tx_keep !== ~64'd0 || tx_last || tx_conn !== 3'd2)
      $fatal(1, "ICResp first beat framing mismatch");
    held_data = tx_data;
    repeat (2) begin
      @(posedge clk);
      #1;
      if (!tx_valid || tx_data !== held_data)
        $fatal(1, "response changed while tx_ready was low");
    end
    accept_tx_beat();
    while (!tx_valid) @(posedge clk);
    #1;
    if (tx_data !== '0 || tx_keep !== ~64'd0 || !tx_last || tx_conn !== 3'd2)
      $fatal(1, "ICResp second beat mismatch");
    accept_tx_beat();

    request_meta = '0;
    request_meta.conn_id = 3'd3;
    request_meta.pdu_type = PDU_H2CDATA;
    request_meta.action = ACT_TERMINATE;
    request_meta.error = 1'b1;
    request_meta.fes = FES_INVALID_HEADER;
    request_meta.fei = 32'd2;
    submit_request();
    while (!tx_valid) @(posedge clk);
    #1;
    if (tx_data[7:0] !== PDU_C2HTERMREQ || tx_data[23:16] !== 8'd24 ||
        tx_data[63:32] !== 32'd24 || tx_data[79:64] !== FES_INVALID_HEADER ||
        tx_data[111:80] !== 32'd2 || tx_keep !== 64'h00ff_ffff || !tx_last)
      $fatal(1, "C2HTermReq response mismatch");
    accept_tx_beat();

    request_meta = '0;
    request_meta.conn_id = 3'd4;
    request_meta.pdu_type = PDU_C2HDATA;
    request_meta.action = ACT_TERMINATE;
    request_meta.error = 1'b1;
    request_meta.fes = FES_UNSUPPORTED_PARAM;
    request_meta.fei = 32'd1;
    submit_request();
    while (!tx_valid) @(posedge clk);
    #1;
    if (tx_data[7:0] !== PDU_H2CTERMREQ || tx_data[79:64] !== FES_UNSUPPORTED_PARAM ||
        tx_data[111:80] !== 32'd1 || tx_conn !== 3'd4)
      $fatal(1, "H2CTermReq response mismatch");
    accept_tx_beat();

    request_meta = '0;
    request_meta.action = ACT_CAPSULE_CMD;
    request_meta.pdu_type = PDU_CAPSULECMD;
    submit_request();
    repeat (3) begin
      @(posedge clk);
      #1;
      if (tx_valid) $fatal(1, "action-only PDU created a response");
    end

    $display("TB_PASS tb_response_gen");
    $finish;
  end

  initial begin
    #20000;
    $fatal(1, "response generator test watchdog expired");
  end
endmodule
