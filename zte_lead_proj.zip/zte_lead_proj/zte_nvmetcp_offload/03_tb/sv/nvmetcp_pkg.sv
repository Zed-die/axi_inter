`include "//?/F:/codex_proj/zte_lead_proj/zte_nvmetcp_offload/02_rtl/nvmetcp_defs.vh"

package nvmetcp_pkg;
  parameter integer NUM_CONN = 8;
  parameter integer DATA_W = 512;
  parameter integer KEEP_W = DATA_W / 8;
  parameter integer MAX_PDU_BYTES = `NVMETCP_MAX_PDU_BYTES;

  localparam logic [7:0] PDU_ICREQ       = `NVMETCP_PDU_ICREQ;
  localparam logic [7:0] PDU_ICRESP      = `NVMETCP_PDU_ICRESP;
  localparam logic [7:0] PDU_H2CTERMREQ  = `NVMETCP_PDU_H2CTERMREQ;
  localparam logic [7:0] PDU_C2HTERMREQ  = `NVMETCP_PDU_C2HTERMREQ;
  localparam logic [7:0] PDU_CAPSULECMD  = `NVMETCP_PDU_CAPSULECMD;
  localparam logic [7:0] PDU_CAPSULERESP = `NVMETCP_PDU_CAPSULERESP;
  localparam logic [7:0] PDU_H2CDATA     = `NVMETCP_PDU_H2CDATA;
  localparam logic [7:0] PDU_C2HDATA     = `NVMETCP_PDU_C2HDATA;
  localparam logic [7:0] PDU_R2T         = `NVMETCP_PDU_R2T;

  localparam logic [3:0] ACT_NONE         = `NVMETCP_ACT_NONE;
  localparam logic [3:0] ACT_ICREQ        = `NVMETCP_ACT_ICREQ;
  localparam logic [3:0] ACT_ICRESP       = `NVMETCP_ACT_ICRESP;
  localparam logic [3:0] ACT_TERMINATE    = `NVMETCP_ACT_TERMINATE;
  localparam logic [3:0] ACT_CAPSULE_CMD  = `NVMETCP_ACT_CAPSULE_CMD;
  localparam logic [3:0] ACT_CAPSULE_RESP = `NVMETCP_ACT_CAPSULE_RESP;
  localparam logic [3:0] ACT_H2C_DATA     = `NVMETCP_ACT_H2C_DATA;
  localparam logic [3:0] ACT_C2H_DATA     = `NVMETCP_ACT_C2H_DATA;
  localparam logic [3:0] ACT_R2T          = `NVMETCP_ACT_R2T;

  localparam logic [15:0] FES_INVALID_HEADER =
      `NVMETCP_FES_INVALID_HEADER;
  localparam logic [15:0] FES_PDU_SEQUENCE =
      `NVMETCP_FES_PDU_SEQUENCE;
  localparam logic [15:0] FES_HEADER_DIGEST =
      `NVMETCP_FES_HEADER_DIGEST;
  localparam logic [15:0] FES_DATA_OUT_OF_RANGE =
      `NVMETCP_FES_DATA_OUT_OF_RANGE;
  localparam logic [15:0] FES_TRANSFER_LIMIT =
      `NVMETCP_FES_TRANSFER_LIMIT;
  localparam logic [15:0] FES_UNSUPPORTED_PARAM =
      `NVMETCP_FES_UNSUPPORTED_PARAM;

  typedef struct packed {
    logic [2:0]  conn_id;
    logic [7:0]  pdu_type;
    logic [3:0]  action;
    logic [7:0]  flags;
    logic [31:0] plen;
    logic [15:0] cccid;
    logic [15:0] ttag;
    logic [31:0] data_offset;
    logic [31:0] data_length;
    logic [15:0] fes;
    logic [31:0] fei;
    logic        error;
  } action_meta_t;

  function automatic logic [7:0] fixed_hlen(input logic [7:0] pdu_type);
    case (pdu_type)
      PDU_ICREQ,
      PDU_ICRESP:      fixed_hlen = 8'd128;
      PDU_CAPSULECMD:  fixed_hlen = 8'd72;
      PDU_H2CTERMREQ,
      PDU_C2HTERMREQ,
      PDU_CAPSULERESP,
      PDU_H2CDATA,
      PDU_C2HDATA,
      PDU_R2T:         fixed_hlen = 8'd24;
      default:         fixed_hlen = 8'd0;
    endcase
  endfunction

  function automatic logic [7:0] get_byte512(
    input logic [511:0] data,
    input integer      index
  );
    get_byte512 = data[index*8 +: 8];
  endfunction

  function automatic logic [15:0] get_le16_512(
    input logic [511:0] data,
    input integer      index
  );
    get_le16_512 = {get_byte512(data, index + 1), get_byte512(data, index)};
  endfunction

  function automatic logic [31:0] get_le32_512(
    input logic [511:0] data,
    input integer      index
  );
    get_le32_512 = {
      get_byte512(data, index + 3),
      get_byte512(data, index + 2),
      get_byte512(data, index + 1),
      get_byte512(data, index)
    };
  endfunction

  function automatic logic [31:0] sat_inc32(input logic [31:0] value);
    sat_inc32 = (&value) ? value : value + 32'd1;
  endfunction
endpackage
