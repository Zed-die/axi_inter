`timescale 1ns/1ps

module tb_gray_sync;
  logic       src_clk = 1'b0;
  logic       dst_clk = 1'b0;
  logic       dst_rst_n = 1'b0;
  logic [5:0] src_bin = 6'd0;
  logic [5:0] src_gray;
  logic [5:0] dst_gray;
  logic [5:0] dst_bin;
  logic [5:0] previous_gray;
  logic [5:0] delta;
  integer     index;

  always #3.5 src_clk = ~src_clk;
  always #2.5 dst_clk = ~dst_clk;

  nvmetcp_gray_sync #(.WIDTH(6)) dut (
    .src_bin(src_bin),
    .src_gray(src_gray),
    .dst_clk(dst_clk),
    .dst_rst_n(dst_rst_n),
    .dst_gray(dst_gray),
    .dst_bin(dst_bin)
  );

  initial begin
    repeat (3) @(posedge dst_clk);
    dst_rst_n = 1'b1;
    previous_gray = src_gray;

    for (index = 0; index < 20; index = index + 1) begin
      @(posedge src_clk);
      src_bin <= src_bin + 6'd1;
      #1;
      delta = src_gray ^ previous_gray;
      if (delta == 0 || ((delta & (delta - 1'b1)) != 0))
        $fatal(1, "Gray code changed by more than one bit: %b", delta);
      previous_gray = src_gray;
    end

    repeat (4) @(posedge dst_clk);
    #1;
    if (dst_bin !== src_bin)
      $fatal(1, "destination pointer did not converge: src=%0d dst=%0d", src_bin, dst_bin);

    $display("TB_PASS tb_gray_sync");
    $finish;
  end
endmodule
