`timescale 1ns/1ps

module tb_pdu_reader;
  logic         clk = 1'b0;
  logic         rst_n = 1'b0;
  logic         grant_valid = 1'b0;
  logic         grant_ready;
  logic [2:0]   grant_id = 3'd0;
  logic         grant_done;
  logic         rd_req;
  logic [2:0]   rd_conn;
  logic         rd_valid = 1'b0;
  logic [511:0] rd_data = '0;
  logic [63:0]  rd_keep = '0;
  logic         rd_last = 1'b0;
  logic         rd_consume;
  logic         out_valid;
  logic         out_ready = 1'b1;
  logic [511:0] out_data;
  logic [63:0]  out_keep;
  logic         out_start;
  logic         out_last;
  logic [2:0]   out_conn;
  logic         frame_error_valid;
  logic [2:0]   frame_error_conn;

  logic [511:0] model_data [0:1];
  logic [63:0]  model_keep [0:1];
  logic         model_last [0:1];
  integer       model_count = 0;
  integer       model_index = 0;
  integer       output_index;
  integer       error_count = 0;

  always #2.5 clk = ~clk;

  nvmetcp_pdu_reader dut (
    .clk,
    .rst_n,
    .grant_valid,
    .grant_ready,
    .grant_id,
    .grant_done,
    .rd_req,
    .rd_conn,
    .rd_valid,
    .rd_data,
    .rd_keep,
    .rd_last,
    .rd_consume,
    .out_valid,
    .out_ready,
    .out_data,
    .out_keep,
    .out_start,
    .out_last,
    .out_conn,
    .frame_error_valid,
    .frame_error_conn
  );

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      rd_valid <= 1'b0;
      model_index <= 0;
    end else begin
      if (rd_valid && rd_consume) begin
        rd_valid <= 1'b0;
        model_index <= model_index + 1;
      end else if (!rd_valid && rd_req && model_index < model_count) begin
        rd_data <= model_data[model_index];
        rd_keep <= model_keep[model_index];
        rd_last <= model_last[model_index];
        rd_valid <= 1'b1;
      end
      if (frame_error_valid)
        error_count <= error_count + 1;
    end
  end

  task automatic issue_grant(input logic [2:0] connection);
    begin
      while (!grant_ready) @(posedge clk);
      @(negedge clk);
      grant_id = connection;
      grant_valid = 1'b1;
      @(posedge clk);
      #1;
      grant_valid = 1'b0;
    end
  endtask

  task automatic check_outputs(
    input integer wanted_count,
    input logic [2:0] wanted_connection
  );
    begin
      output_index = 0;
      while (output_index < wanted_count) begin
        @(negedge clk);
        out_ready = (output_index != 0) || ($time % 3 != 0);
        @(posedge clk);
        #1;
        if (out_valid && out_ready) begin
          if (out_data !== model_data[output_index])
            $fatal(1, "reader data mismatch at beat %0d", output_index);
          if (out_keep !== model_keep[output_index])
            $fatal(1, "reader keep mismatch at beat %0d", output_index);
          if (out_start !== (output_index == 0))
            $fatal(1, "reader start mismatch at beat %0d", output_index);
          if (out_last !== model_last[output_index])
            $fatal(1, "reader last mismatch at beat %0d", output_index);
          if (out_conn !== wanted_connection)
            $fatal(1, "reader connection mismatch");
          output_index = output_index + 1;
        end
      end
      out_ready = 1'b1;
      while (!grant_done) @(posedge clk);
      @(posedge clk);
      #1;
    end
  endtask

  task automatic prepare_one_beat(
    input logic [31:0] plen,
    input logic [63:0] keep
  );
    begin
      model_count = 1;
      model_index = 0;
      model_data[0] = '0;
      model_data[0][63:32] = plen;
      model_keep[0] = keep;
      model_last[0] = 1'b1;
    end
  endtask

  initial begin
    repeat (3) @(posedge clk);
    rst_n = 1'b1;

    model_count = 2;
    model_index = 0;
    model_data[0] = '0;
    model_data[0][7:0] = 8'h00;
    model_data[0][23:16] = 8'd128;
    model_data[0][63:32] = 32'd128;
    model_keep[0] = 64'hffff_ffff_ffff_ffff;
    model_last[0] = 1'b0;
    model_data[1] = 512'h1234;
    model_keep[1] = 64'hffff_ffff_ffff_ffff;
    model_last[1] = 1'b1;
    issue_grant(3'd2);
    check_outputs(2, 3'd2);
    if (error_count != 0) $fatal(1, "valid ICReq reported a frame error");

    prepare_one_beat(32'd24, 64'h0000_0000_00ff_ffff);
    model_data[0][7:0] = 8'h09;
    issue_grant(3'd6);
    check_outputs(1, 3'd6);
    if (error_count != 0) $fatal(1, "valid R2T reported a frame error");

    prepare_one_beat(32'd24, 64'h0000_0000_000f_ffff);
    model_data[0][7:0] = 8'h09;
    issue_grant(3'd1);
    check_outputs(1, 3'd1);
    if (error_count != 1 || frame_error_conn !== 3'd1)
      $fatal(1, "malformed final keep was not reported exactly once");

    $display("TB_PASS tb_pdu_reader");
    $finish;
  end

  initial begin
    #10000;
    $fatal(1, "PDU reader test watchdog expired");
  end
endmodule
