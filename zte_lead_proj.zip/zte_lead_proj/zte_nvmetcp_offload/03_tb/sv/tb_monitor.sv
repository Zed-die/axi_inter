`timescale 1ns/1ps

module tb_monitor;
  import nvmetcp_pkg::*;

  logic         clk = 1'b0;
  logic         rst_n = 1'b0;
  logic         action_fire = 1'b0;
  action_meta_t action_meta;
  logic         schedule_fire = 1'b0;
  logic [2:0]   schedule_conn = 3'd0;
  logic         overflow_attempt = 1'b0;
  logic         backpressure = 1'b0;
  logic         mon_clear = 1'b0;
  logic [11:0]  mon_addr = 12'd0;
  logic [31:0]  mon_rdata;

  always #2.5 clk = ~clk;

  nvmetcp_monitor dut (
    .clk,
    .rst_n,
    .action_fire,
    .action_meta,
    .schedule_fire,
    .schedule_conn,
    .overflow_attempt,
    .backpressure,
    .mon_clear,
    .mon_addr,
    .mon_rdata
  );

  task automatic pulse_action(
    input logic [2:0] connection,
    input logic [7:0] pdu_type,
    input logic error,
    input logic [15:0] fes,
    input logic [31:0] fei
  );
    begin
      @(negedge clk);
      action_meta = '0;
      action_meta.conn_id = connection;
      action_meta.pdu_type = pdu_type;
      action_meta.error = error;
      action_meta.fes = fes;
      action_meta.fei = fei;
      action_fire = 1'b1;
      @(posedge clk);
      #1;
      action_fire = 1'b0;
    end
  endtask

  task automatic expect_register(
    input logic [11:0] address,
    input logic [31:0] expected
  );
    begin
      mon_addr = address;
      #1;
      if (mon_rdata !== expected)
        $fatal(1, "monitor address %03x expected %08x got %08x",
               address, expected, mon_rdata);
    end
  endtask

  initial begin
    action_meta = '0;
    repeat (3) @(posedge clk);
    rst_n = 1'b1;

    pulse_action(3'd0, PDU_ICREQ, 1'b0, 0, 0);
    pulse_action(3'd7, PDU_R2T, 1'b1, FES_UNSUPPORTED_PARAM, 32'd11);

    @(negedge clk);
    schedule_conn = 3'd7;
    schedule_fire = 1'b1;
    overflow_attempt = 1'b1;
    backpressure = 1'b1;
    @(posedge clk);
    #1;
    schedule_fire = 1'b0;
    overflow_attempt = 1'b0;
    backpressure = 1'b0;

    expect_register(12'h000, 1);
    expect_register(12'h01c, 1);
    expect_register(12'h05c, 1);
    expect_register(12'h080, 1);
    expect_register(12'h0a0, 1);
    expect_register(12'h0c0, 1);
    expect_register(12'h0c4, 1);
    expect_register(12'h0c8, 1);
    expect_register(12'h0d0, 7);
    expect_register(12'h0d4, PDU_R2T);
    expect_register(12'h0d8, FES_UNSUPPORTED_PARAM);
    expect_register(12'h0dc, 11);
    expect_register(12'h118, 1);

    dut.conn_packets[0] = 32'hffff_fffe;
    pulse_action(3'd0, PDU_ICREQ, 1'b0, 0, 0);
    pulse_action(3'd0, PDU_ICREQ, 1'b0, 0, 0);
    expect_register(12'h000, 32'hffff_ffff);

    @(negedge clk);
    mon_clear = 1'b1;
    @(posedge clk);
    #1;
    mon_clear = 1'b0;
    expect_register(12'h000, 0);
    expect_register(12'h0c0, 0);
    expect_register(12'h0dc, 0);

    $display("TB_PASS tb_monitor");
    $finish;
  end
endmodule
