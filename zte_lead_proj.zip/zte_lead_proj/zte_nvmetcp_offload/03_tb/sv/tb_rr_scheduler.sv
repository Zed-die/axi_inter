`timescale 1ns/1ps

module tb_rr_scheduler;
  logic       clk = 1'b0;
  logic       rst_n = 1'b0;
  logic [7:0] pending = 8'h00;
  logic       grant_valid;
  logic       grant_ready = 1'b0;
  logic [2:0] grant_id;
  logic       grant_done = 1'b0;
  integer     index;
  logic [2:0] expected;

  always #2.5 clk = ~clk;

  nvmetcp_rr_scheduler dut (
    .clk(clk),
    .rst_n(rst_n),
    .pending(pending),
    .grant_valid(grant_valid),
    .grant_ready(grant_ready),
    .grant_id(grant_id),
    .grant_done(grant_done)
  );

  task automatic accept_and_finish(input logic [2:0] wanted);
    begin
      while (!grant_valid) @(posedge clk);
      if (grant_id !== wanted)
        $fatal(1, "expected grant %0d got %0d", wanted, grant_id);
      grant_ready = 1'b1;
      @(posedge clk);
      #1;
      grant_ready = 1'b0;
      if (grant_valid)
        $fatal(1, "grant must be consumed before packet completion");
      grant_done = 1'b1;
      @(posedge clk);
      #1;
      grant_done = 1'b0;
    end
  endtask

  initial begin
    repeat (3) @(posedge clk);
    rst_n = 1'b1;
    pending = 8'hff;

    while (!grant_valid) @(posedge clk);
    if (grant_id !== 3'd0) $fatal(1, "first grant must be connection zero");
    repeat (2) begin
      @(posedge clk);
      if (!grant_valid || grant_id !== 3'd0)
        $fatal(1, "grant changed while ready was low");
    end

    for (index = 0; index < 16; index = index + 1) begin
      expected = index % 8;
      accept_and_finish(expected);
    end

    pending = 8'h44;
    accept_and_finish(3'd2);
    accept_and_finish(3'd6);
    accept_and_finish(3'd2);
    accept_and_finish(3'd6);

    pending = 8'h00;
    @(posedge clk);
    #1;
    if (grant_valid) $fatal(1, "grant valid while no connection is pending");

    $display("TB_PASS tb_rr_scheduler");
    $finish;
  end
endmodule
