`timescale 1ns/1ps

module tb_parser;
  import nvmetcp_pkg::*;

  logic         clk = 1'b0;
  logic         rst_n = 1'b0;
  logic         in_valid = 1'b0;
  logic         in_ready;
  logic [511:0] in_data = '0;
  logic [63:0]  in_keep = '0;
  logic         in_start = 1'b0;
  logic         in_last = 1'b0;
  logic [2:0]   in_conn = 3'd5;
  logic         action_valid;
  logic         action_ready = 1'b0;
  action_meta_t action_meta;
  logic         payload_valid;
  logic         payload_ready = 1'b1;
  logic [511:0] payload_data;
  logic [63:0]  payload_keep;
  logic         payload_start;
  logic         payload_last;
  logic [2:0]   payload_conn;
  logic [511:0] packet;
  action_meta_t held_meta;

  initial begin
    if ($bits(action_meta) != `NVMETCP_ACTION_META_W)
      $fatal(1, "DUT/testbench metadata width mismatch");
  end

  always #2.5 clk = ~clk;

  nvmetcp_parser dut (
    .clk,
    .rst_n,
    .in_valid,
    .in_ready,
    .in_data,
    .in_keep,
    .in_start,
    .in_last,
    .in_conn,
    .action_valid,
    .action_ready,
    .action_meta,
    .payload_valid,
    .payload_ready,
    .payload_data,
    .payload_keep,
    .payload_start,
    .payload_last,
    .payload_conn
  );

  task automatic make_header(
    input logic [7:0] opcode,
    input logic [7:0] flags,
    input logic [7:0] hlen,
    input logic [7:0] pdo,
    input logic [31:0] plen
  );
    begin
      packet = '0;
      packet[7:0] = opcode;
      packet[15:8] = flags;
      packet[23:16] = hlen;
      packet[31:24] = pdo;
      packet[63:32] = plen;
    end
  endtask

  task automatic drive_and_check(
    input logic [3:0] wanted_action,
    input logic wanted_error,
    input logic [15:0] wanted_fes,
    input logic [31:0] wanted_fei,
    input logic [15:0] wanted_cccid,
    input logic [15:0] wanted_ttag,
    input logic [31:0] wanted_offset,
    input logic [31:0] wanted_length,
    input logic [63:0] wanted_keep
  );
    begin
      while (!in_ready) @(posedge clk);
      @(negedge clk);
      in_data = packet;
      in_keep = wanted_keep;
      in_start = 1'b1;
      in_last = 1'b1;
      in_valid = 1'b1;
      @(posedge clk);
      #1;
      in_valid = 1'b0;
      in_start = 1'b0;
      in_last = 1'b0;

      while (!action_valid) @(posedge clk);
      #1;
      if (action_meta.conn_id !== 3'd5 || action_meta.action !== wanted_action)
        $fatal(1, "action routing mismatch for opcode %02x", packet[7:0]);
      if (action_meta.pdu_type !== packet[7:0] || action_meta.plen !== packet[63:32])
        $fatal(1, "common metadata mismatch for opcode %02x", packet[7:0]);
      if (action_meta.error !== wanted_error ||
          action_meta.fes !== wanted_fes || action_meta.fei !== wanted_fei)
        $fatal(1, "error metadata mismatch for opcode %02x", packet[7:0]);
      if (action_meta.cccid !== wanted_cccid || action_meta.ttag !== wanted_ttag ||
          action_meta.data_offset !== wanted_offset ||
          action_meta.data_length !== wanted_length)
        $fatal(1, "type metadata mismatch for opcode %02x", packet[7:0]);

      held_meta = action_meta;
      repeat (2) begin
        @(posedge clk);
        #1;
        if (!action_valid || action_meta !== held_meta)
          $fatal(1, "action changed under backpressure");
      end

      @(negedge clk);
      action_ready = 1'b1;
      @(posedge clk);
      #1;
      action_ready = 1'b0;

      while (!payload_valid) @(posedge clk);
      #1;
      if (payload_data !== packet || payload_keep !== wanted_keep ||
          !payload_start || !payload_last || payload_conn !== 3'd5)
        $fatal(1, "payload stream mismatch for opcode %02x", packet[7:0]);
      @(posedge clk);
      #1;
      while (!in_ready) @(posedge clk);
    end
  endtask

  initial begin
    repeat (3) @(posedge clk);
    rst_n = 1'b1;

    make_header(PDU_ICREQ, 0, 128, 0, 128);
    drive_and_check(ACT_ICREQ, 0, 0, 0, 0, 0, 0, 0, ~64'd0);

    make_header(PDU_ICRESP, 0, 128, 0, 128);
    packet[127:96] = 32'd4096;
    drive_and_check(ACT_ICRESP, 0, 0, 0, 0, 0, 0, 0, ~64'd0);

    make_header(PDU_H2CTERMREQ, 0, 24, 0, 24);
    packet[79:64] = 16'h0002;
    packet[111:80] = 32'h0000_0004;
    drive_and_check(ACT_TERMINATE, 0, 2, 4, 0, 0, 0, 0, 64'h00ff_ffff);

    make_header(PDU_C2HTERMREQ, 0, 24, 0, 24);
    packet[79:64] = 16'h0006;
    packet[111:80] = 32'h0000_000b;
    drive_and_check(ACT_TERMINATE, 0, 6, 11, 0, 0, 0, 0, 64'h00ff_ffff);

    make_header(PDU_CAPSULECMD, 0, 72, 0, 72);
    packet[95:80] = 16'h1010;
    drive_and_check(ACT_CAPSULE_CMD, 0, 0, 0, 16'h1010, 0, 0, 0, ~64'd0);

    make_header(PDU_CAPSULERESP, 0, 24, 0, 24);
    packet[175:160] = 16'h2020;
    drive_and_check(ACT_CAPSULE_RESP, 0, 0, 0, 16'h2020, 0, 0, 0, 64'h00ff_ffff);

    make_header(PDU_H2CDATA, 8'h04, 24, 24, 28);
    packet[79:64] = 16'h3030;
    packet[95:80] = 16'h4040;
    packet[127:96] = 32'h0000_0100;
    packet[159:128] = 32'd4;
    packet[223:192] = 32'h4433_2211;
    drive_and_check(ACT_H2C_DATA, 0, 0, 0, 16'h3030, 16'h4040,
                    32'h100, 4, 64'h0fff_ffff);

    make_header(PDU_C2HDATA, 8'h0c, 24, 24, 28);
    packet[79:64] = 16'h5050;
    packet[127:96] = 32'h0000_0200;
    packet[159:128] = 32'd4;
    packet[223:192] = 32'h8877_6655;
    drive_and_check(ACT_C2H_DATA, 0, 0, 0, 16'h5050, 0,
                    32'h200, 4, 64'h0fff_ffff);

    make_header(PDU_R2T, 0, 24, 0, 24);
    packet[79:64] = 16'h6060;
    packet[95:80] = 16'h7070;
    packet[127:96] = 32'h0000_0400;
    packet[159:128] = 32'h0000_1000;
    drive_and_check(ACT_R2T, 0, 0, 0, 16'h6060, 16'h7070,
                    32'h400, 32'h1000, 64'h00ff_ffff);

    make_header(8'h08, 0, 24, 0, 24);
    drive_and_check(ACT_TERMINATE, 1, FES_INVALID_HEADER, 0,
                    0, 0, 0, 0, 64'h00ff_ffff);

    make_header(PDU_R2T, 0, 25, 0, 24);
    drive_and_check(ACT_TERMINATE, 1, FES_INVALID_HEADER, 2,
                    0, 0, 0, 0, 64'h00ff_ffff);

    make_header(PDU_CAPSULERESP, 1, 24, 0, 24);
    drive_and_check(ACT_TERMINATE, 1, FES_UNSUPPORTED_PARAM, 1,
                    0, 0, 0, 0, 64'h00ff_ffff);

    make_header(PDU_ICREQ, 0, 128, 0, 128);
    packet[87:80] = 8'h01;
    drive_and_check(ACT_TERMINATE, 1, FES_UNSUPPORTED_PARAM, 10,
                    0, 0, 0, 0, ~64'd0);

    make_header(PDU_R2T, 0, 24, 4, 24);
    drive_and_check(ACT_TERMINATE, 1, FES_INVALID_HEADER, 3,
                    0, 0, 0, 0, 64'h00ff_ffff);

    make_header(PDU_H2CDATA, 0, 24, 24, 28);
    packet[159:128] = 32'd8;
    drive_and_check(ACT_TERMINATE, 1, FES_INVALID_HEADER, 16,
                    0, 0, 0, 0, 64'h0fff_ffff);

    $display("TB_PASS tb_parser");
    $finish;
  end

  initial begin
    #50000;
    $fatal(1, "parser test watchdog expired");
  end
endmodule
