# NVMe/TCP 硬卸载 RTL 工程

本工程以 Verilog-2001 RTL 实现 8 连接 NVMe/TCP PDU 缓存、跨时钟域、公平轮询、解析、动作和单包回复，SystemVerilog 验证环境负责自检与协议覆盖。数据通路为 512 bit，目标核心时钟为 200 MHz。

设计文件仅位于 `02_rtl/`，扩展名为 `.v/.vh`；`03_tb/sv/` 中的 `.sv` 文件仅用于验证。RTL 不依赖 Xilinx IP 核，Vivado 以 Verilog 模式读取设计。

支持 ICReq、ICResp、H2CTermReq、C2HTermReq、CapsuleCmd、CapsuleResp、H2CData、C2HData 和 R2T。HDGST、DDGST、TLS、TCP/IP、NVMe 命令执行及板级 DDR 不在本阶段范围内。

本地完整回归：

```powershell
& .\06_scripts\run_regression.ps1
```

Vivado 综合及时序检查：

```powershell
& .\06_scripts\run_vivado.ps1
```

验收入口位于 `08_delivery/README.md`，实际生成结果位于 `07_reports/generated/`。
