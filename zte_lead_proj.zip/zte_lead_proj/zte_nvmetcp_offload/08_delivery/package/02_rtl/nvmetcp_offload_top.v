`include "//?/F:/codex_proj/zte_lead_proj/zte_nvmetcp_offload/02_rtl/nvmetcp_defs.vh"

module nvmetcp_offload_top #(
  parameter integer NUM_CONN = 8,
  parameter integer DEPTH_WORDS = 128
) (
  input                       wr_clk,
  input                       wr_rst_n,
  input                       wr_valid,
  output                      wr_ready,
  input  [2:0]                wr_conn,
  input  [511:0]              wr_data,
  input  [63:0]               wr_keep,
  input                       wr_last,

  input                       core_clk,
  input                       core_rst_n,
  output                      action_valid,
  input                       action_ready,
  output [`NVMETCP_ACTION_META_W-1:0] action_meta,
  output                      payload_valid,
  input                       payload_ready,
  output [511:0]              payload_data,
  output [63:0]               payload_keep,
  output                      payload_start,
  output                      payload_last,
  output [2:0]                payload_conn,
  output                      tx_valid,
  input                       tx_ready,
  output [511:0]              tx_data,
  output [63:0]               tx_keep,
  output                      tx_last,
  output [2:0]                tx_conn,

  input                       mon_clear,
  input  [11:0]               mon_addr,
  output [31:0]               mon_rdata
);
  wire [NUM_CONN-1:0] pending;
  wire                 overflow_attempt;
  wire                 buffer_rd_req;
  wire [2:0]           buffer_rd_conn;
  wire                 buffer_rd_valid;
  wire [511:0]         buffer_rd_data;
  wire [63:0]          buffer_rd_keep;
  wire                 buffer_rd_last;
  wire                 buffer_rd_consume;

  wire                 grant_valid;
  wire                 grant_ready;
  wire [2:0]           grant_id;
  wire                 grant_done;

  wire                 reader_valid;
  wire                 reader_ready;
  wire [511:0]         reader_data;
  wire [63:0]          reader_keep;
  wire                 reader_start;
  wire                 reader_last;
  wire [2:0]           reader_conn;
  wire                 frame_error_valid;
  wire [2:0]           frame_error_conn;

  wire                 parser_action_valid;
  wire                 parser_action_ready;
  wire [`NVMETCP_ACTION_META_W-1:0] parser_action_meta;
  wire                 response_request_valid;
  wire                 response_request_ready;
  reg                  selected_action_valid;
  reg [`NVMETCP_ACTION_META_W-1:0] selected_action_meta;
  reg                  frame_error_pending;
  reg [`NVMETCP_ACTION_META_W-1:0] frame_error_meta;
  wire                 action_fire;
  wire                 schedule_fire;
  wire                 backpressure;

  nvmetcp_async_buffer_bank #(
    .NUM_CONN(NUM_CONN),
    .DEPTH_WORDS(DEPTH_WORDS),
    .DATA_W(512),
    .CONN_W(3)
  ) u_buffer (
    .wr_clk(wr_clk),
    .wr_rst_n(wr_rst_n),
    .wr_valid(wr_valid),
    .wr_ready(wr_ready),
    .wr_conn(wr_conn),
    .wr_data(wr_data),
    .wr_keep(wr_keep),
    .wr_last(wr_last),
    .overflow_attempt(overflow_attempt),
    .core_clk(core_clk),
    .core_rst_n(core_rst_n),
    .pending(pending),
    .rd_conn(buffer_rd_conn),
    .rd_req(buffer_rd_req),
    .rd_valid(buffer_rd_valid),
    .rd_data(buffer_rd_data),
    .rd_keep(buffer_rd_keep),
    .rd_last(buffer_rd_last),
    .rd_consume(buffer_rd_consume)
  );

  nvmetcp_rr_scheduler u_scheduler (
    .clk(core_clk),
    .rst_n(core_rst_n),
    .pending(pending[7:0]),
    .grant_valid(grant_valid),
    .grant_ready(grant_ready),
    .grant_id(grant_id),
    .grant_done(grant_done)
  );

  nvmetcp_pdu_reader u_reader (
    .clk(core_clk),
    .rst_n(core_rst_n),
    .grant_valid(grant_valid),
    .grant_ready(grant_ready),
    .grant_id(grant_id),
    .grant_done(grant_done),
    .rd_req(buffer_rd_req),
    .rd_conn(buffer_rd_conn),
    .rd_valid(buffer_rd_valid),
    .rd_data(buffer_rd_data),
    .rd_keep(buffer_rd_keep),
    .rd_last(buffer_rd_last),
    .rd_consume(buffer_rd_consume),
    .out_valid(reader_valid),
    .out_ready(reader_ready),
    .out_data(reader_data),
    .out_keep(reader_keep),
    .out_start(reader_start),
    .out_last(reader_last),
    .out_conn(reader_conn),
    .frame_error_valid(frame_error_valid),
    .frame_error_conn(frame_error_conn)
  );

  nvmetcp_parser u_parser (
    .clk(core_clk),
    .rst_n(core_rst_n),
    .in_valid(reader_valid),
    .in_ready(reader_ready),
    .in_data(reader_data),
    .in_keep(reader_keep),
    .in_start(reader_start),
    .in_last(reader_last),
    .in_conn(reader_conn),
    .action_valid(parser_action_valid),
    .action_ready(parser_action_ready),
    .action_meta(parser_action_meta),
    .payload_valid(payload_valid),
    .payload_ready(payload_ready),
    .payload_data(payload_data),
    .payload_keep(payload_keep),
    .payload_start(payload_start),
    .payload_last(payload_last),
    .payload_conn(payload_conn)
  );

  function [`NVMETCP_ACTION_META_W-1:0] make_frame_error_meta;
    input [2:0] conn;
    input [7:0] pdu_type;
    input [31:0] plen;
    reg [`NVMETCP_ACTION_META_W-1:0] result;
    begin
      result = {`NVMETCP_ACTION_META_W{1'b0}};
      result[`NVMETCP_META_CONN_ID_MSB:`NVMETCP_META_CONN_ID_LSB] = conn;
      result[`NVMETCP_META_PDU_TYPE_MSB:`NVMETCP_META_PDU_TYPE_LSB] =
          pdu_type;
      result[`NVMETCP_META_ACTION_MSB:`NVMETCP_META_ACTION_LSB] =
          `NVMETCP_ACT_TERMINATE;
      result[`NVMETCP_META_PLEN_MSB:`NVMETCP_META_PLEN_LSB] = plen;
      result[`NVMETCP_META_FES_MSB:`NVMETCP_META_FES_LSB] =
          `NVMETCP_FES_INVALID_HEADER;
      result[`NVMETCP_META_FEI_MSB:`NVMETCP_META_FEI_LSB] = 32'd4;
      result[`NVMETCP_META_ERROR_BIT] = 1'b1;
      make_frame_error_meta = result;
    end
  endfunction

  always @* begin
    if (frame_error_pending) begin
      selected_action_valid = 1'b1;
      selected_action_meta = frame_error_meta;
    end else begin
      selected_action_valid = parser_action_valid;
      selected_action_meta = parser_action_meta;
    end
  end

  assign action_valid = selected_action_valid && response_request_ready;
  assign action_meta = selected_action_meta;
  assign response_request_valid = selected_action_valid && action_ready;
  assign parser_action_ready = !frame_error_pending && action_ready &&
                               response_request_ready;
  assign action_fire = selected_action_valid && action_ready &&
                       response_request_ready;

  always @(posedge core_clk) begin
    if (!core_rst_n) begin
      frame_error_pending <= 1'b0;
      frame_error_meta <= {`NVMETCP_ACTION_META_W{1'b0}};
    end else begin
      if (frame_error_pending && action_fire)
        frame_error_pending <= 1'b0;
      if (frame_error_valid) begin
        frame_error_pending <= 1'b1;
        frame_error_meta <= make_frame_error_meta(
          frame_error_conn,
          parser_action_meta[
              `NVMETCP_META_PDU_TYPE_MSB:`NVMETCP_META_PDU_TYPE_LSB],
          parser_action_meta[`NVMETCP_META_PLEN_MSB:`NVMETCP_META_PLEN_LSB]
        );
      end
    end
  end

  nvmetcp_response_gen u_response (
    .clk(core_clk),
    .rst_n(core_rst_n),
    .request_valid(response_request_valid),
    .request_ready(response_request_ready),
    .request_meta(selected_action_meta),
    .tx_valid(tx_valid),
    .tx_ready(tx_ready),
    .tx_data(tx_data),
    .tx_keep(tx_keep),
    .tx_last(tx_last),
    .tx_conn(tx_conn)
  );

  assign schedule_fire = grant_valid && grant_ready;
  assign backpressure = (action_valid && !action_ready) ||
                        (payload_valid && !payload_ready) ||
                        (tx_valid && !tx_ready);

  nvmetcp_monitor u_monitor (
    .clk(core_clk),
    .rst_n(core_rst_n),
    .action_fire(action_fire),
    .action_meta(selected_action_meta),
    .schedule_fire(schedule_fire),
    .schedule_conn(grant_id),
    .overflow_attempt(overflow_attempt),
    .backpressure(backpressure),
    .mon_clear(mon_clear),
    .mon_addr(mon_addr),
    .mon_rdata(mon_rdata)
  );
endmodule
