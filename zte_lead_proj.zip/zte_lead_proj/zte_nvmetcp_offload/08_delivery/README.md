# 验收说明

## 1. 本地回归

在工程根目录执行：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\06_scripts\run_regression.ps1
```

期望看到40项或更多Python测试通过、`VERILOG_2001_COMPILE_PASS`、9个`TB_PASS`、`MEASURED_THROUGHPUT_GBPS`不低于40以及最终`REGRESSION_PASS`。摘要写入`07_reports/generated/simulation/regression_summary.txt`。

## 2. Vivado验收

安装Vivado并加入PATH后执行：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\06_scripts\run_vivado.ps1
```

可以通过环境变量`PART`替换默认器件`xc7a200tsbg484-1`。脚本生成utilization、timing summary、CDC、methodology和check timing报告。WNS小于0时脚本失败。

未安装Vivado时脚本明确输出缺失信息并返回2，验收状态必须写为`NOT_RUN_NO_VIVADO`，不能写成PASS。

## 3. 结果定位

- 原始需求：`00_requirements/`
- 架构、接口和协议：`01_docs/`
- Verilog-2001可综合RTL：`02_rtl/`（仅`.v/.vh`）
- Python/SystemVerilog验证：`03_tb/`
- Vivado脚本/XDC：`04_vivado/`、`05_constraints/`
- 运行脚本：`06_scripts/`
- 实际报告：`07_reports/generated/`
- 交付压缩包及状态：`08_delivery/`

## 4. 打包

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\06_scripts\package_delivery.ps1
```

脚本生成`08_delivery/zte_nvmetcp_offload_delivery.zip`和包内`MANIFEST.sha256`。
