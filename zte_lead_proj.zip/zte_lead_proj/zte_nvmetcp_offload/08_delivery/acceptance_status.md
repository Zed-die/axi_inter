# 验收状态

`LOCAL_REGRESSION: PASS`

`VIVADO: NOT_RUN_NO_VIVADO`

`VERIFIED_SOURCE_COMMIT: e1fc51e`

## 本机环境

- Python 3.9.8
- pytest 8.4.1
- Icarus Verilog version 12.0 (devel)
- Vivado：当前机器未安装或未加入PATH

## 已执行验证

执行命令：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\06_scripts\run_regression.ps1
```

- Python协议模型、向量、脚本、文档、打包和Verilog-2001合规检查：43项；
- `02_rtl/`仅包含8个`.v`设计模块和1个`.vh`公共定义文件，不包含`.sv`；
- Icarus Verilog `-g2001`独立编译完整RTL顶层：`VERILOG_2001_COMPILE_PASS`；
- SystemVerilog：9个自检testbench全部输出`TB_PASS`；
- 8连接公平轮询：PASS；
- 异步指针、缓存提交、回绕、满/空：PASS；
- 9类PDU解析及错误分类：PASS；
- ICResp与双向TermReq逐字节检查：PASS；
- PLEN/末拍keep不一致时的FES=01h终止路径：PASS；
- 长PDU稳态吞吐：51.603 Gb/s，最大拍间隔2个200 MHz周期，要求为40 Gb/s；
- 交付包缓存排除和SHA256清单：PASS。

## 尚未执行

当前环境没有Vivado，因此下列项目没有伪装为通过：

- Xilinx器件综合；
- 5.000 ns约束下的WNS检查；
- Vivado `report_cdc`、`report_methodology`和资源利用率报告。

在装有Vivado的机器执行`06_scripts/run_vivado.ps1`后，只有脚本返回0且WNS不小于0时，才可把Vivado状态更新为PASS。
