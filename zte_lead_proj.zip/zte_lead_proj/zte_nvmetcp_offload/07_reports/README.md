# 报告目录

`generated/` 中的结果必须由工程脚本从真实运行产生。缺少 Vivado 时，综合、时序和 CDC 状态记为 `NOT_RUN_NO_VIVADO`，不得标记为通过。
