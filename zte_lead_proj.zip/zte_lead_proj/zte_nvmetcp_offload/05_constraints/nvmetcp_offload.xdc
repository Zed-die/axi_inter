create_clock -period 5.000 -name core_clk [get_ports core_clk]
create_clock -period 7.000 -name wr_clk [get_ports wr_clk]

set_clock_groups -asynchronous \
  -group [get_clocks core_clk] \
  -group [get_clocks wr_clk]

set async_first_stage [get_cells -hier -filter {ASYNC_REG == TRUE && NAME =~ *sync_gray_ff1*}]
if {[llength $async_first_stage] > 0} {
  set_false_path -to [get_pins -of_objects $async_first_stage -filter {REF_PIN_NAME == D}]
}
