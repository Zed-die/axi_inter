# Verilog 头文件绝对路径变更设计

## 目标

将工程中全部 `` `include "nvmetcp_defs.vh" `` 引用统一改为当前工作区中的绝对路径：

```verilog
`include "//?/F:/codex_proj/zte_lead_proj/zte_nvmetcp_offload/02_rtl/common/nvmetcp_defs.vh"
```

使用正斜杠和 Windows 扩展绝对路径前缀 `//?/`。当前 Icarus
Verilog 12.0 无法从 `` `include `` 中打开普通盘符形式 `F:/...`，
但已验证能够打开 `//?/F:/...`；该写法同时避免反斜杠被工具解释为
转义字符。

## 变更范围

修改以下 5 个文件的第一行：

1. `zte_nvmetcp_offload/02_rtl/top/nvmetcp_offload_top.v`
2. `zte_nvmetcp_offload/02_rtl/parser/nvmetcp_parser.v`
3. `zte_nvmetcp_offload/02_rtl/monitor/nvmetcp_monitor.v`
4. `zte_nvmetcp_offload/02_rtl/response/nvmetcp_response_gen.v`
5. `zte_nvmetcp_offload/03_tb/sv/nvmetcp_pkg.sv`

不修改 RTL 逻辑、端口、时序、约束或模块层次。现有 Icarus `-I` 参数和 Vivado `include_dirs` 设置予以保留，避免改变其他编译行为。

## 可移植性影响

修改后源码绑定到：

`F:/codex_proj/zte_lead_proj`

工程复制到其他目录或计算机后，必须同步修改这 5 处绝对路径。交付 ZIP 中的源码也将保留该绝对路径，因此脱离当前工作区不能直接编译。

## 验收标准

1. 5 个目标文件均使用完全一致的绝对路径。
2. 设计目录不再出现相对引用 `` `include "nvmetcp_defs.vh" ``。
3. Verilog-2001 顶层严格编译通过。
4. 9 个 SystemVerilog testbench 全部通过。
5. 全部 Python 检查通过。
6. 吞吐率回归仍不低于 40 Gb/s。

