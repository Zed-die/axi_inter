# NVMe/TCP RTL 详细设计说明文档设计

## 1. 目标

新增 `zte_nvmetcp_offload/01_docs/rtl_detailed_design.md`，以 RTL 工程师为目标读者，对当前 Verilog-2001 实现进行可独立阅读、可用于设计评审和工程交接的详细说明。

文档必须以实际 RTL 为唯一实现依据，不把需求设想、验证侧便利类型或尚未实现的协议功能描述成设计现状。

## 2. 文档形式

采用单篇 Markdown，而不是拆成多个模块文档。单篇形式便于从顶层数据流连续阅读到模块内部实现，也便于课程验收者从一个入口检查完整设计。

文档放入现有 `01_docs/`，与 `architecture.md`、`interfaces.md` 和 `protocol_support.md` 并列。原有文档保留，新文档提供更深的 RTL 级解释，并在适当位置链接现有文档和源文件。

## 3. 读者层级与写作原则

目标读者熟悉 Verilog、同步时序逻辑、ready/valid 和基本 CDC 概念。文档不重复讲授 Verilog 语法，但必须解释：

- 每个模块在系统中的职责和上下游依赖；
- 端口握手语义与稳定性要求；
- 组合逻辑、寄存器、memory 和状态机之间的边界；
- 每个关键状态转换发生的条件；
- 指针、长度、拍数、keep、位段和吞吐率的计算方式；
- CDC 假设、综合推断和可能的工程风险；
- 对应 testbench 验证了什么。

描述以准确和可追溯为优先，避免只把代码逐行翻译成自然语言。

## 4. 总体章节结构

最终文档按以下顺序组织：

1. 文档目的、设计范围和非目标；
2. 设计参数、语言边界和目录映射；
3. 顶层模块连接图；
4. 写入、调度、读取、解析、动作、payload、回复和监控的端到端数据流；
5. `wr_clk`/`core_clk` 时钟域、复位和 Gray Code CDC；
6. ready/valid、背压和包粒度所有权规则；
7. NVMe/TCP Common Header、9 类 PDU 和 200 bit `action_meta` 编码；
8. 每个 RTL 文件的详细设计；
9. 三个端到端时序示例；
10. 吞吐率、资源推断、关键时序和 Vivado 注意事项；
11. 验证结构、运行命令和结果定位；
12. 集成约束、已知边界和可扩展方向。

顶层连接使用 Mermaid flowchart，并提供等价的文字说明，避免阅读器不支持 Mermaid 时丢失关键信息。状态机使用表格表达，复杂链路可使用 Mermaid sequence diagram。

## 5. 模块覆盖范围

文档必须逐一覆盖下列设计文件：

1. `02_rtl/common/nvmetcp_defs.vh`
2. `02_rtl/cdc/nvmetcp_gray_sync.v`
3. `02_rtl/buffer/nvmetcp_async_buffer_bank.v`
4. `02_rtl/scheduler/nvmetcp_rr_scheduler.v`
5. `02_rtl/parser/nvmetcp_pdu_reader.v`
6. `02_rtl/parser/nvmetcp_parser.v`
7. `02_rtl/response/nvmetcp_response_gen.v`
8. `02_rtl/monitor/nvmetcp_monitor.v`
9. `02_rtl/top/nvmetcp_offload_top.v`

每个模块小节至少包括：

- 作用与设计边界；
- 参数和端口分组；
- 内部数据结构或寄存器；
- 组合与时序行为；
- 状态机或关键算法；
- 背压、异常和复位行为；
- CDC、综合与时序注意事项；
- 上下游关系和验证用例。

公共定义文件需要解释全部 opcode、action、FES 和元数据位段。parser 小节需要逐类说明 9 类 PDU 的字段提取和校验。monitor 小节需要列出完整地址映射。

## 6. 必须准确说明的实现细节

文档必须明确以下事实：

- RTL 使用 Verilog-2001，验证 package 和 testbench 使用 SystemVerilog；
- 数据宽度为 512 bit，keep 宽度为 64 bit；
- 默认连接数为 8，顶层默认每连接缓冲深度为 128 拍；
- 写侧只在 `wr_last` 时推进提交指针，核心侧只能看到已提交的完整 PDU；
- 跨域传递的是 Gray Code 指针，而不是多位二进制指针；
- 轮询授权以完整 PDU 为粒度，`grant_done` 后才轮换；
- reader 根据 PLEN 计算期望拍数，并校验末拍 last/keep；
- parser 先输出动作，动作握手后才输出对应 payload；
- `action_meta` 为 200 bit，验证侧 packed struct 与其逐位兼容；
- response generator 只自动生成 ICResp 和 TermReq；
- monitor 计数器为 32 bit 饱和计数；
- 顶层将 parser 动作和 reader 帧错误合并，并保证动作与回复请求同步接受；
- 200 MHz 下 512 bit 原始带宽为 102.4 Gb/s，当前实测吞吐率为 51.603 Gb/s；
- 本机没有 Vivado，综合、时序和 CDC 报告状态仍为 `NOT_RUN_NO_VIVADO`。

## 7. 端到端示例

文档包含三个实现级示例：

1. 合法 ICReq：写入、提交、跨域可见、调度、读取、解析、动作握手、payload 和两拍 ICResp；
2. 非法 PDU：parser 生成错误动作和 TermReq，说明 FES/FEI 及方向选择；
3. 多连接同时 pending：round-robin 从 `last_grant+1` 搜索，并在 PDU 完成后更新优先级。

示例只描述代码可以保证的相对顺序，不承诺未由 RTL 固定的绝对周期数。

## 8. 验证与验收

新增 Python 文档测试，检查：

- 最终 Markdown 文件存在；
- 9 个设计文件名均被覆盖；
- 关键主题 `Verilog-2001`、`action_meta[199:0]`、`ready/valid`、Gray Code、51.603 Gb/s 和 `NOT_RUN_NO_VIVADO` 均出现；
- 文档不声称 TCP/IP、TLS、DDR、NVMe 命令执行已经实现。

完成后运行全部 Python 测试，并运行现有 RTL 单元回归，确认纯文档变更没有破坏工程入口。最终文件加入交付打包范围，因为 `01_docs/` 已由打包脚本整体复制。

## 9. 完成条件

只有在以下条件同时满足时，任务才算完成：

- 单篇 Markdown 覆盖总体设计和全部 RTL 模块；
- 所有数值、位段、状态和握手关系与当前源代码一致；
- 文档可作为 RTL 设计评审材料独立阅读；
- 文档测试、现有 Python 测试和 RTL 回归通过；
- 原始课题 PDF 与无关文件未被修改或纳入提交。
