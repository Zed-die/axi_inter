# RTL 目录扁平化设计

## 目标

将 `zte_nvmetcp_offload/02_rtl/` 整理为只包含设计源码的单层目录。
8 个 Verilog-2001 模块和 1 个 Verilog 头文件直接放在 `02_rtl/`
根目录；SystemVerilog testbench、Python 测试及其他验证内容继续保留在
`03_tb/`，不移入设计目录。

目标结构为：

```text
02_rtl/
├── nvmetcp_defs.vh
├── nvmetcp_gray_sync.v
├── nvmetcp_async_buffer_bank.v
├── nvmetcp_rr_scheduler.v
├── nvmetcp_pdu_reader.v
├── nvmetcp_parser.v
├── nvmetcp_response_gen.v
├── nvmetcp_monitor.v
└── nvmetcp_offload_top.v
```

## 文件移动

| 原路径 | 新路径 |
|---|---|
| `02_rtl/common/nvmetcp_defs.vh` | `02_rtl/nvmetcp_defs.vh` |
| `02_rtl/cdc/nvmetcp_gray_sync.v` | `02_rtl/nvmetcp_gray_sync.v` |
| `02_rtl/buffer/nvmetcp_async_buffer_bank.v` | `02_rtl/nvmetcp_async_buffer_bank.v` |
| `02_rtl/scheduler/nvmetcp_rr_scheduler.v` | `02_rtl/nvmetcp_rr_scheduler.v` |
| `02_rtl/parser/nvmetcp_pdu_reader.v` | `02_rtl/nvmetcp_pdu_reader.v` |
| `02_rtl/parser/nvmetcp_parser.v` | `02_rtl/nvmetcp_parser.v` |
| `02_rtl/response/nvmetcp_response_gen.v` | `02_rtl/nvmetcp_response_gen.v` |
| `02_rtl/monitor/nvmetcp_monitor.v` | `02_rtl/nvmetcp_monitor.v` |
| `02_rtl/top/nvmetcp_offload_top.v` | `02_rtl/nvmetcp_offload_top.v` |

Git 不跟踪空目录。移动完成后，`buffer`、`cdc`、`common`、`monitor`、
`parser`、`response`、`scheduler` 和 `top` 子目录自然消失。
`02_rtl/.gitkeep` 在目录已有真实设计文件后不再需要，随本次整理删除。

## 路径更新

四个 RTL 消费者和验证 package 的头文件引用统一更新为：

```verilog
`include "//?/F:/codex_proj/zte_lead_proj/zte_nvmetcp_offload/02_rtl/nvmetcp_defs.vh"
```

同步更新以下工程入口：

- `03_tb/sv/filelist.f`；
- `06_scripts/run_unit.ps1`；
- `04_vivado/create_project.tcl`；
- `04_vivado/run_synth.tcl`；
- `03_tb/python/test_verilog2001_rtl.py`；
- `00_requirements/requirements_traceability.md`；
- `01_docs/rtl_detailed_design.md`。

Vivado 脚本改为从 `02_rtl/*.v` 读取设计模块，并以 `02_rtl/` 作为
include directory。Python 测试应断言 `02_rtl` 顶层恰好包含 8 个
`.v` 和 1 个 `.vh`，且不再存在设计分类子目录或 `.sv` 文件。

## 未提交修改保护

当前工作区中：

- `02_rtl/cdc/nvmetcp_gray_sync.v` 有未提交的注释与排版修改；
- `02_rtl/parser/nvmetcp_parser.v` 有未提交的空白修改。

实施时必须原样移动这两个工作区文件，不能用 Git 中的旧版本覆盖。
原始课题 PDF 同样保持未跟踪、未修改。

## 非目标

- 不移动、删除或合并 `03_tb/` 中的验证文件；
- 不修改 RTL 行为、端口、参数或时序；
- 不改变 Verilog-2001 设计、SystemVerilog 验证的语言边界；
- 不删除文档、脚本、约束、报告或交付目录；
- 不将任何用户未提交修改自动加入重构提交。

## 验收标准

1. `02_rtl/` 顶层恰好只有 8 个 `.v` 和 1 个 `.vh`；
2. `02_rtl/` 下不存在分类子目录和 `.sv`；
3. 所有工程脚本、filelist、文档和追踪表指向新路径；
4. 5 处 `` `include `` 使用新的绝对头文件路径；
5. Verilog-2001 严格顶层编译通过；
6. 9 个 SystemVerilog testbench 通过；
7. Python 路径、文档和打包检查通过；
8. 长 PDU 吞吐回归不低于 40 Gb/s；
9. 交付 ZIP 中的 `02_rtl/` 同样为扁平结构。
