# NVMe/TCP RTL Verilog-2001 迁移设计

## 1. 目标

将 `zte_nvmetcp_offload/02_rtl` 下的全部设计代码从 SystemVerilog 迁移为可综合的 Verilog-2001，同时保持现有模块功能、时钟域划分、ready/valid 握手、PDU 解析行为、调度公平性和吞吐率指标不变。

验证代码继续使用 SystemVerilog。迁移完成后，设计与验证的语言边界为：

- `02_rtl/`：仅允许 `.v` 和 `.vh`；
- `03_tb/sv/`：允许 `.sv`，负责激励、自检、断言及验证侧类型封装；
- Vivado 对 RTL 使用 Verilog 读取模式，不使用 `read_verilog -sv`；
- RTL 必须能够由 Icarus Verilog 的 Verilog-2001 模式独立完成语法编译。

## 2. 方案选择

采用“完整原生 Verilog-2001 迁移”方案。所有设计模块直接改写为 Verilog-2001，不通过 Verilog 外壳包裹 SystemVerilog 内核，也不在各模块中重复维护协议常量。

公共常量和总线位段集中放入头文件；SystemVerilog package、枚举和 packed struct 均从 RTL 中移除。该方案改动范围较大，但语言边界明确，适合 Vivado 及传统 Verilog 工具直接验收。

## 3. 文件与公共定义

`nvmetcp_pkg.sv` 替换为 `nvmetcp_defs.vh`。头文件使用 include guard，并集中定义：

- PDU opcode；
- 动作类型；
- FES 错误码；
- 动作元数据总线宽度和字段位段；
- 多个模块共同使用且与参数无关的常量。

参数化宽度仍由对应模块的 `parameter`/`localparam` 定义。依赖模块参数的运算不放入全局宏，以避免宏展开造成宽度或作用域问题。

原 package 中的函数按用途迁入实际使用它们的模块，并采用 Verilog-2001 函数声明形式。`$clog2` 不作为 RTL 依赖；需要地址宽度时使用模块内的整数 `clog2` 函数和 `localparam`。

## 4. 接口迁移

### 4.1 动作元数据

原 `action_meta_t` packed struct 改为 200 bit 扁平总线 `action_meta[199:0]`。为保持当前 packed struct 的二进制布局，字段固定如下：

| 字段 | 位段 |
|---|---:|
| `error` | `[0]` |
| `fei` | `[32:1]` |
| `fes` | `[48:33]` |
| `data_length` | `[80:49]` |
| `data_offset` | `[112:81]` |
| `ttag` | `[128:113]` |
| `cccid` | `[144:129]` |
| `plen` | `[176:145]` |
| `flags` | `[184:177]` |
| `action` | `[188:185]` |
| `pdu_type` | `[196:189]` |
| `conn_id` | `[199:197]` |

`nvmetcp_defs.vh` 为每个字段定义 `MSB`/`LSB` 常量。RTL 只通过固定切片读写字段，验证侧可继续使用 SystemVerilog struct，但必须通过显式 pack/unpack 函数与 DUT 扁平端口连接。

### 4.2 其他端口

所有依赖 SystemVerilog 多维 packed/unpacked 端口的接口统一扁平化。内部存储器仍可使用 Verilog-2001 支持的 memory 声明，例如 `reg [DATA_W-1:0] mem [0:DEPTH-1]`。模块边界不暴露 unpacked array。

端口方向和驱动类型明确区分：组合输出使用 `wire` 或由连续赋值驱动，过程块输出声明为 `reg`。顶层对外的信号名称、握手语义和数值编码保持不变；仅类型表达和必要的总线形态发生变化。

## 5. 语法迁移规则

RTL 中不允许出现以下 SystemVerilog 构造：

- `package`、`import`、作用域运算符 `::`；
- `logic`、`bit`、`typedef`、`struct`、`enum`；
- `always_ff`、`always_comb`、`always_latch`；
- `interface`、`modport`；
- SystemVerilog assertion；
- `$clog2` 及 SystemVerilog 专有的端口、数组和类型语法。

对应替换规则为：

- 时序逻辑使用 `always @(posedge clk ...)`；
- 组合逻辑使用 `always @*`；
- 状态编码使用 `localparam`；
- 信号使用 `wire`/`reg`；
- 类型化接口使用显式位宽向量；
- 字节提取和小端转换使用模块内 Verilog 函数。

允许保留 Vivado 识别的综合属性，例如 CDC 同步寄存器上的 `(* ASYNC_REG = "TRUE" *)`。它不改变 RTL 语言结构，Icarus 与 Vivado 均可接受。

## 6. 验证与脚本

采用测试先行方式增加语言合规性检查，再逐模块迁移。自动检查至少覆盖：

1. `02_rtl/` 不存在 `.sv` 文件；
2. RTL 文件仅使用 `.v/.vh`；
3. RTL 中不存在约定禁止的 SystemVerilog 关键字和作用域语法；
4. 全部 RTL 能在 Verilog-2001 模式下独立编译；
5. SystemVerilog testbench 在 Verilog DUT 上完成现有全部功能回归；
6. filelist、Vivado Tcl 和一键回归脚本引用新的 `.v/.vh` 文件；
7. Vivado Tcl 以 Verilog 模式读取 RTL。

迁移按公共定义、基础 CDC/缓冲、调度、PDU 读取、解析、响应、监控、顶层的依赖顺序进行。每一阶段保持编译通过，最后运行 Python 测试、全部 SystemVerilog testbench、吞吐率测试和可用的 Vivado流程。若环境没有 Vivado，报告必须明确记录 `NOT_RUN_NO_VIVADO`，不得将其标记为通过。

## 7. 文档和交付

同步修改架构、接口、验证、Vivado 使用说明、验收状态和交付清单中关于“纯 SystemVerilog RTL”的描述。最终目录按以下规则验收：

```text
02_rtl/**/*.v, *.vh    Verilog-2001 设计
03_tb/sv/**/*.sv       SystemVerilog 验证
```

旧 `.sv` RTL 不保留兼容副本，避免 filelist 或 Vivado 工程误选旧实现。迁移后重新生成交付结果，输出仍按仿真、覆盖率、综合、时序和交付目录分类。

## 8. 完成条件

只有同时满足以下条件，迁移才算完成：

- `02_rtl/` 的语言合规性检查通过；
- RTL 的 Verilog-2001 独立编译通过；
- 现有功能回归和吞吐率验收无退化；
- 所有工程脚本和文档均指向 Verilog RTL；
- 验收报告可区分真实通过、失败和因工具缺失未执行的项目；
- 工作区中不包含由本次迁移造成的临时生成物或旧 RTL 副本。
