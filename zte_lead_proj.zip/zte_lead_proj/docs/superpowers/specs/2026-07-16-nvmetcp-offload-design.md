# NVMe/TCP 硬卸载 RTL 工程设计说明

## 1. 目标与验收边界

本工程实现一个面向 Xilinx Vivado 的纯 SystemVerilog NVMe/TCP PDU 解析与动作生成模块。RTL 不依赖 FIFO Generator、Block Memory Generator、ILA 或其他 Xilinx IP 核；缓存、跨时钟域、仲裁、解析、回复生成和统计逻辑均使用可综合 RTL 描述。

本阶段验收目标如下：

- 支持 8 个独立连接缓存，每个连接具有独立读写指针和地址空间；
- 写入侧与 200 MHz 解析核心允许异步时钟；
- 使用包粒度轮询算法公平调度 8 个连接；
- 输入及输出数据通路宽度为 512 bit（64 B）；
- 分类并解析 NVMe/TCP 1.0d Figure 10 定义的 9 类 PDU；
- 对需要本地处理的 PDU 产生结构化动作，对初始化或协议错误产生单包回复；
- 不支持 HDGST、DDGST，HPDA 和 CPDA 固定为 0；
- 提供 SystemVerilog 自检 testbench、Python 报文与黄金结果生成器、Vivado 批处理脚本；
- 提供仿真、覆盖、综合、时序和验收报告模板及一键回归入口。

本阶段不包含 TCP/IP 协议栈、TLS、NVMe 命令语义执行、真实介质访问、PCIe、DDR、板级引脚和上位机。上板能力通过顶层适配接口保留，但不作为首阶段完成条件。

## 2. 规范基线与明确假设

设计基线为 NVM Express TCP Transport Specification Revision 1.0d（2023-12-27）第 3.3 节和第 3.6.2 节。Common Header 按小端字节序解释：byte 0 为 PDU-Type，byte 1 为 FLAGS，byte 2 为 HLEN，byte 3 为 PDO，byte 4 至 7 为 PLEN。

为消除课题描述中未定义的上游缓存行为，采用以下可验收接口约定：

1. 上游以 512 bit beat 写入完整 PDU，每个 PDU 从新 beat 开始，`wr_last` 标记最后一个 beat，`wr_keep` 标记末拍有效字节；
2. 上游可在 beat 之间切换连接，但同一连接的 PDU 字节顺序不可乱序；
3. 仅在收到 `wr_last` 后，写侧才通过 Gray Code 提交指针发布完整 PDU；解析侧不会看到半包；
4. 单个 PDU 最大长度参数化，默认 8,264 B，可覆盖 8 KiB in-capsule data 与 72 B CapsuleCmd Header；
5. 所有数值字段按 NVMe/TCP 规定的小端顺序从字节流解码；
6. 上下文相关的 NVMe 命令合法性不在本模块判断范围内，模块只验证传输层可独立判断的字段。

## 3. 方案选择

采用模块化流水线方案，而非单一大状态机或微码表驱动方案。

- 单状态机方案代码初期较少，但缓存调度、协议校验和回复生成耦合，难以独立验证；
- 表驱动方案扩展性最好，但需要微码存储与通用字段执行器，超过本课题所需规模；
- 模块化流水线将 CDC、调度、取数、解析、动作、回复和监控解耦，便于分别测试及综合，是本工程的选定方案。

## 4. 总体架构

数据流如下：

```text
异步写接口
    |
    v
8 连接异步缓存银行 -- Gray doorbell --> 可用连接位图
                                          |
                                          v
                                    Round-Robin 调度器
                                          |
                                          v
                                     PDU 缓存读取器
                                          |
                         +----------------+----------------+
                         v                                 v
                  Common Header 校验                 Payload 512b 流
                         |
                         v
                    类型专用解析器
                         |
                +--------+---------+
                v                  v
           结构化动作接口       回复/终止报文生成器
                |                  |
                +--------+---------+
                         v
                    统计与调试寄存器
```

核心采用 ready/valid 流控。获得连接授权后，读取器处理一个完整 PDU；PDU 完成或被判错并丢弃后，调度器将优先级移到该连接的下一个连接。只要下游不持续背压，数据阶段支持每周期一个 512 bit beat。

## 5. RTL 模块划分

### 5.1 公共定义

`nvmetcp_pkg.sv` 定义参数、9 个 PDU opcode、动作类型、错误码、解析元数据结构及字节提取函数。所有跨模块接口使用 package 中的明确类型，避免重复魔数。

### 5.2 连接缓存与 CDC

`nvmetcp_async_buffer_bank.sv` 包含 8 个逻辑环形缓存分区。存储体使用双口数组模板描述，写口工作在 `wr_clk`，读口工作在 `core_clk`，由 Vivado 推断双口 BRAM 或分布式 RAM。

每个连接维护二进制读写指针及其 Gray Code 表示。跨域只同步 Gray Code 指针，使用带 `ASYNC_REG` 属性的两级同步器。写侧通过 `wr_last` 原子提交完整 PDU；读侧在 PDU 消费或错误丢弃后提交读指针。缓存满时只对对应连接撤销 `wr_ready`，不阻塞其他连接。

### 5.3 公平调度器

`nvmetcp_rr_scheduler.sv` 接收 8 bit 非空位图，从上次授权连接的后一项开始循环查找。每次授权恰好一个完整 PDU，而不是固定周期数，从而避免长 PDU 在中途被切换，同时保证持续有数据的任一连接最多等待其他 7 个 PDU 完成。

### 5.4 PDU 读取与字节流

`nvmetcp_pdu_reader.sv` 根据第一拍 Common Header 中的 PLEN 计算需要读取的 beat 数，校验 `wr_keep` 与 PLEN 一致性，并输出规范化 512 bit 数据、64 bit keep、start/last 和连接编号。读取延迟通过状态机吸收，不假设组合读 RAM。

### 5.5 Common Header 与类型解析

`nvmetcp_parser.sv` 首先完成通用检查，再调用类型专用组合函数或小状态机提取字段。支持项如下：

| Opcode | PDU | 主要字段/行为 |
|---:|---|---|
| 00h | ICReq | PFV、HPDA、DGST、MAXR2T；合法时请求生成 ICResp |
| 01h | ICResp | PFV、CPDA、DGST、MAXH2CDATA；输出连接初始化动作 |
| 02h | H2CTermReq | FES、FEI 和错误头部；输出对端终止动作 |
| 03h | C2HTermReq | FES、FEI 和错误头部；输出对端终止动作 |
| 04h | CapsuleCmd | 64 B CCSQE 及可选 in-capsule data；输出命令动作 |
| 05h | CapsuleResp | 16 B RCCQE；输出完成动作 |
| 06h | H2CData | CCCID、TTAG、DATAO、DATAL、LAST_PDU 及数据流 |
| 07h | C2HData | CCCID、DATAO、DATAL、LAST_PDU、SUCCESS 及数据流 |
| 09h | R2T | CCCID、TTAG、R2TO、R2TL；输出传输请求动作 |

类型解析不实现 NVMe 队列和命令上下文，因此不会伪造具有业务含义的读写结果。

### 5.6 动作接口

`nvmetcp_action_router.sv` 输出单拍结构化动作，至少包含：连接号、PDU 类型、动作类型、PLEN、CCCID、TTAG、DATAO/R2TO、DATAL/R2TL、FES、FEI、标志位以及校验结果。Capsule 和 Data 的变长内容通过独立 512 bit ready/valid 数据流输出。

当动作消费者背压时，当前 PDU 保持不丢失；统计事件只在动作真正握手时计数。

### 5.7 回复生成

`nvmetcp_response_gen.sv` 生成两类无需命令上下文的合理单包回复：

- 合法 ICReq：生成 128 B ICResp，PFV=0、CPDA=0、HDGST_ENABLE=0、DDGST_ENABLE=0，MAXH2CDATA 使用参数值，默认 4096 B；
- 致命传输层错误：按输入方向生成 H2CTermReq 或 C2HTermReq，填入 FES、最低错误字段偏移 FEI，并最多回显允许长度内的错误 PDU Header。

其他合法 PDU 产生动作而不是自动协议回复：CapsuleCmd 应交给命令执行模块，Data 应交给数据搬移模块，R2T 应交给发送控制模块，CapsuleResp/TermReq/ICResp 属于接收通知。这符合“回复报文或者动作”的课题要求，并避免超出无上下文边界。

### 5.8 监控与可测试性

`nvmetcp_monitor.sv` 提供只读状态总线和可选清零输入，包含：

- 每连接接收 PDU 数、接收字节数和调度次数；
- 每种 PDU 类型计数；
- 总错误数及每类错误计数；
- 缓存满、下游背压和最大等待观测值；
- 最近一次错误的连接、opcode、FES、FEI；
- 当前调度连接和各连接非空状态。

计数器饱和而不回卷。调试信号通过端口与寄存器暴露，不依赖 ILA。

## 6. 协议校验与错误处理

通用检查按确定性优先顺序执行，报告最低字节偏移错误：

1. opcode 是否在 9 类支持集合内；
2. HLEN 是否等于对应类型固定值：ICReq/ICResp 为 128 B，CapsuleCmd 为 72 B，其余为 24 B；
3. PLEN 是否不小于 HLEN、未超过参数上限且与已提交 beat/keep 一致；
4. FLAGS 保留位是否为 0，HDGSTF/DDGSTF 是否为 0；
5. PDO 是否满足类型规定，数据 PDU 的 PDO、DATAL、DATAO/R2TO 和 R2TL 是否按 dword 对齐；
6. PFV 是否为 0，HPDA/CPDA 是否为 0；
7. 类型专用保留字段是否为 0，IC 和 TermReq 长度是否满足固定/最大限制。

错误分类如下：

- 字段、长度、保留位或未知 opcode 错误：FES=01h（Invalid PDU Header Field）；
- 接收到要求使用 HDGST/DDGST 的 PDU：FES=06h（Unsupported Parameter）；
- 上游在已提交 PDU 中提供与 PLEN 不一致的末拍：本地接口错误，丢弃 PDU、记录计数，并产生 FES=01h 终止请求；
- 缓存溢出：写侧通过 `wr_ready` 防止覆盖未读数据，同时记录 overflow attempt；
- 对端 TermReq：输出终止动作，不生成循环终止回复。

检测到致命错误后只丢弃当前 PDU，生成一个终止请求并释放连接缓存读空间。由于课题明确无需握手和上下文，模块不维护长期连接关闭状态。

## 7. 时序与吞吐设计

核心时钟约束为 5.000 ns。512 bit × 200 MHz 的原始数据能力为 102.4 Gb/s，高于 40 Gb/s 目标。实现目标是数据阶段一拍一 beat；包头解析、包尾提交和连接切换允许少量固定气泡，但综合后必须报告：

- 核心时钟 WNS 不小于 0；
- 数据稳态吞吐不低于 40 Gb/s；
- 公平性测试中任一持续非空连接不被饿死；
- CDC 报告中不存在未约束的多位二进制指针直跨时钟域。

若默认综合器件尚未指定，综合脚本使用可配置 `PART`，仓库默认采用 `xc7a200tsbg484-1` 仅作自动综合及时序检查；更换器件不改变 RTL。

## 8. 验证设计

### 8.1 Python 黄金模型

Python 工具按小端格式生成 9 类 PDU、非法变体和期望动作/回复，输出十六进制向量及 JSON manifest。随机测试使用显式 seed，任何失败均可复现。

### 8.2 SystemVerilog 自检环境

testbench 在不同相位和频率的 `wr_clk`/`core_clk` 下驱动 8 个连接，自动比较动作元数据、payload、回复字节、read doorbell 和统计计数。无需 UVM，保持环境可直接由 XSim 运行。

### 8.3 测试矩阵

至少包含：

- 9 类 PDU 各自最小合法包；
- ICReq 到 ICResp 的逐字节黄金比较；
- 每种固定 HLEN、PLEN、PDO、FLAGS、保留字段错误；
- HDGST/DDGST 请求或标志被拒绝；
- 多 beat CapsuleCmd、H2CData、C2HData 和 TermReq；
- 1 至 63 B 非整 beat 尾包 keep 校验；
- 输出随机背压期间数据稳定性；
- 8 连接同时持续输入时的轮询顺序和最大等待界；
- 单连接持续输入、稀疏连接插入、缓存回绕、满/空边界；
- 异步时钟比例与复位释放顺序；
- 长流吞吐测量达到 40 Gb/s；
- assertion 检查指针不越界、满时不写、空时不读、valid 且非 ready 时数据稳定。

### 8.4 验收命令

一键脚本应能完成：生成向量、编译、XSim 回归、汇总 PASS/FAIL、综合和时序检查。若机器未找到 Vivado，脚本应明确报告缺失，而不是伪造通过结果。

## 9. 工程与交付目录

```text
zte_nvmetcp_offload/
├─ 00_requirements/          原始课题 PDF、需求追踪矩阵
├─ 01_docs/                  架构、接口、协议、验证和验收文档
├─ 02_rtl/
│  ├─ common/
│  ├─ cdc/
│  ├─ buffer/
│  ├─ scheduler/
│  ├─ parser/
│  ├─ response/
│  ├─ monitor/
│  └─ top/
├─ 03_tb/
│  ├─ sv/
│  ├─ python/
│  └─ vectors/
├─ 04_vivado/                Tcl 与工程生成入口，不提交生成缓存
├─ 05_constraints/           XDC 时钟与 CDC 约束
├─ 06_scripts/               一键生成、仿真、综合、验收脚本
├─ 07_reports/
│  ├─ simulation/
│  ├─ coverage/
│  ├─ synthesis/
│  ├─ timing/
│  └─ waves/
└─ 08_delivery/              最终清单、报告副本和验收说明
```

Vivado 自动产生的 `.Xil`、仿真临时库、run 目录和大型波形不进入版本控制；验收所需摘要、关键波形截图或小型 WDB/VCD 按清单保留。

## 10. 完成标准

工程只有在以下条件同时满足时才标记完成：

1. 需求追踪矩阵中的每条课题要求均映射到 RTL、测试和证据；
2. 9 类合法 PDU 与约定非法 PDU 测试全部通过；
3. 8 连接公平性、CDC、背压、回绕和吞吐测试通过；
4. Vivado 批量综合无 error，目标 200 MHz 时序通过；
5. 所有报告均由脚本从实际运行结果生成；
6. `08_delivery/README.md` 能指导验收者从零执行仿真并定位结果；
7. 交付目录不包含无关缓存或无法复现的手工结果。

## 11. 参考资料

- 课题原始资料：`IC开发岗位领军班课题资料.pdf`
- NVM Express TCP Transport Specification, Revision 1.0d, 2023-12-27：<https://nvmexpress.org/wp-content/uploads/NVM-Express-TCP-Transport-Specification-1.0d-2023.12.27-Ratified.pdf>
