# NVMe/TCP Offload RTL Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a pure-SystemVerilog, eight-connection NVMe/TCP PDU parser with fair scheduling, CDC-safe buffering, deterministic actions/responses, self-checking simulation, and acceptance-ready documentation.

**Architecture:** A dual-clock per-connection buffer bank publishes complete-PDU write pointers through Gray-code synchronizers. A packet-granular round-robin scheduler feeds a 512-bit PDU reader, parser, response generator, action stream, and saturating monitor. Python generates byte-accurate golden vectors; SystemVerilog testbenches verify focused units and the integrated top.

**Tech Stack:** SystemVerilog 2012, Python 3.9+, pytest, Icarus Verilog 12 for local regression, Xilinx Vivado Tcl/XDC for synthesis and XSim, PowerShell automation.

---

## File map

The implementation creates the following focused files:

- `zte_nvmetcp_offload/00_requirements/README.md`: requirement source and scope notes.
- `zte_nvmetcp_offload/00_requirements/requirements_traceability.md`: requirement-to-RTL/test/evidence matrix.
- `zte_nvmetcp_offload/01_docs/architecture.md`: implementer-facing architecture summary.
- `zte_nvmetcp_offload/01_docs/interfaces.md`: cycle-level port contracts.
- `zte_nvmetcp_offload/01_docs/protocol_support.md`: opcode, field, action, and error mapping.
- `zte_nvmetcp_offload/02_rtl/common/nvmetcp_pkg.sv`: parameters, opcodes, action/error constants, metadata types, byte helpers.
- `zte_nvmetcp_offload/02_rtl/cdc/nvmetcp_gray_sync.sv`: binary/Gray conversion and two-flop pointer synchronizer.
- `zte_nvmetcp_offload/02_rtl/buffer/nvmetcp_async_buffer_bank.sv`: eight logical dual-clock PDU buffers.
- `zte_nvmetcp_offload/02_rtl/scheduler/nvmetcp_rr_scheduler.sv`: packet-granular fair arbiter.
- `zte_nvmetcp_offload/02_rtl/parser/nvmetcp_pdu_reader.sv`: committed-buffer beat reader and packet framing.
- `zte_nvmetcp_offload/02_rtl/parser/nvmetcp_parser.sv`: common/type-specific header extraction and validation.
- `zte_nvmetcp_offload/02_rtl/response/nvmetcp_response_gen.sv`: ICResp and TermReq packet construction.
- `zte_nvmetcp_offload/02_rtl/monitor/nvmetcp_monitor.sv`: saturating per-connection/type/error counters.
- `zte_nvmetcp_offload/02_rtl/top/nvmetcp_offload_top.sv`: subsystem integration and external interfaces.
- `zte_nvmetcp_offload/03_tb/python/nvmetcp_model.py`: golden PDU builders and parser.
- `zte_nvmetcp_offload/03_tb/python/generate_vectors.py`: deterministic vector/manifest generator.
- `zte_nvmetcp_offload/03_tb/python/test_nvmetcp_model.py`: pytest coverage of protocol model.
- `zte_nvmetcp_offload/03_tb/sv/tb_rr_scheduler.sv`: scheduler self-check.
- `zte_nvmetcp_offload/03_tb/sv/tb_gray_sync.sv`: CDC pointer convergence check.
- `zte_nvmetcp_offload/03_tb/sv/tb_async_buffer_bank.sv`: dual-clock buffer ordering/full/wrap check.
- `zte_nvmetcp_offload/03_tb/sv/tb_parser.sv`: nine-opcode and invalid-header checks.
- `zte_nvmetcp_offload/03_tb/sv/tb_response_gen.sv`: byte-accurate response checks.
- `zte_nvmetcp_offload/03_tb/sv/tb_offload_top.sv`: eight-connection integration, fairness, backpressure, and throughput check.
- `zte_nvmetcp_offload/03_tb/sv/filelist.f`: ordered RTL compilation list.
- `zte_nvmetcp_offload/04_vivado/create_project.tcl`: reproducible Vivado project creation.
- `zte_nvmetcp_offload/04_vivado/run_synth.tcl`: batch synthesis, timing, utilization, and CDC reports.
- `zte_nvmetcp_offload/05_constraints/nvmetcp_offload.xdc`: 200 MHz core clock, asynchronous groups, synchronizer constraints.
- `zte_nvmetcp_offload/06_scripts/run_unit.ps1`: focused pytest and Icarus unit tests.
- `zte_nvmetcp_offload/06_scripts/run_regression.ps1`: vector generation and all local simulations.
- `zte_nvmetcp_offload/06_scripts/run_vivado.ps1`: guarded Vivado batch entry.
- `zte_nvmetcp_offload/06_scripts/package_delivery.ps1`: deterministic acceptance bundle assembly.
- `zte_nvmetcp_offload/07_reports/README.md`: generated-evidence policy.
- `zte_nvmetcp_offload/08_delivery/README.md`: acceptance procedure and result interpretation.
- `zte_nvmetcp_offload/README.md`: project entry point.

## Task 1: Establish the acceptance-oriented repository layout

**Files:**
- Create: `zte_nvmetcp_offload/03_tb/python/test_layout.py`
- Create: `zte_nvmetcp_offload/README.md`
- Create: `zte_nvmetcp_offload/00_requirements/README.md`
- Create: `zte_nvmetcp_offload/07_reports/README.md`
- Create: `zte_nvmetcp_offload/.gitignore`
- Copy: `IC开发岗位领军班课题资料.pdf` to `zte_nvmetcp_offload/00_requirements/IC开发岗位领军班课题资料.pdf`

- [ ] **Step 1: Write the failing layout test**

```python
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

def test_acceptance_directories_exist():
    expected = [f"{n:02d}_{name}" for n, name in [
        (0, "requirements"), (1, "docs"), (2, "rtl"), (3, "tb"),
        (4, "vivado"), (5, "constraints"), (6, "scripts"),
        (7, "reports"), (8, "delivery")]]
    assert all((ROOT / name).is_dir() for name in expected)

def test_source_requirement_is_preserved():
    assert (ROOT / "00_requirements" / "IC开发岗位领军班课题资料.pdf").is_file()
```

- [ ] **Step 2: Run the test and verify the expected failure**

Run: `pytest zte_nvmetcp_offload/03_tb/python/test_layout.py -q`

Expected: FAIL because the numbered acceptance directories do not yet exist.

- [ ] **Step 3: Create the numbered directories and entry files**

Use `apply_patch` for text files. The root README must state the supported PDU list, 512-bit/200 MHz target, local `run_regression.ps1` command, and Vivado `run_vivado.ps1` command. Use `Copy-Item -LiteralPath` only for the binary PDF. The ignore file must contain exactly these generated classes:

```gitignore
.pytest_cache/
__pycache__/
*.pyc
*.vvp
*.vcd
*.wdb
.Xil/
*.jou
*.log
04_vivado/generated/
07_reports/generated/
08_delivery/package/
```

- [ ] **Step 4: Re-run the layout test**

Run: `pytest zte_nvmetcp_offload/03_tb/python/test_layout.py -q`

Expected: `2 passed`.

- [ ] **Step 5: Commit the scaffold**

```powershell
git add zte_nvmetcp_offload
git -c user.name=Codex -c user.email=codex@local commit -m "chore: scaffold acceptance-oriented RTL project"
```

## Task 2: Implement the executable Python protocol model

**Files:**
- Create: `zte_nvmetcp_offload/03_tb/python/nvmetcp_model.py`
- Create: `zte_nvmetcp_offload/03_tb/python/test_nvmetcp_model.py`

- [ ] **Step 1: Write failing tests for all supported opcodes and common validation**

```python
import pytest
from nvmetcp_model import PduType, build_pdu, parse_pdu, ProtocolError

@pytest.mark.parametrize("pdu_type,hlen", [
    (PduType.ICREQ, 128), (PduType.ICRESP, 128),
    (PduType.H2CTERMREQ, 24), (PduType.C2HTERMREQ, 24),
    (PduType.CAPSULECMD, 72), (PduType.CAPSULERESP, 24),
    (PduType.H2CDATA, 24), (PduType.C2HDATA, 24), (PduType.R2T, 24),
])
def test_each_supported_type_round_trips(pdu_type, hlen):
    raw = build_pdu(pdu_type)
    result = parse_pdu(raw)
    assert result["pdu_type"] == pdu_type
    assert result["hlen"] == hlen
    assert result["plen"] == len(raw)

def test_digest_flag_is_rejected():
    raw = bytearray(build_pdu(PduType.CAPSULERESP))
    raw[1] = 1
    with pytest.raises(ProtocolError, match="unsupported digest"):
        parse_pdu(bytes(raw))

def test_wrong_hlen_is_rejected_at_byte_two():
    raw = bytearray(build_pdu(PduType.R2T))
    raw[2] = 25
    with pytest.raises(ProtocolError) as error:
        parse_pdu(bytes(raw))
    assert error.value.fes == 0x01
    assert error.value.fei == 2
```

- [ ] **Step 2: Verify the model test fails**

Run: `pytest zte_nvmetcp_offload/03_tb/python/test_nvmetcp_model.py -q`

Expected: collection error because `nvmetcp_model` does not exist.

- [ ] **Step 3: Implement constants, builders, and parser**

Implement `PduType(IntEnum)` with values `00,01,02,03,04,05,06,07,09`; `FIXED_HLEN`; `ProtocolError(fes, fei, message)`; `build_common_header`; `build_pdu`; and `parse_pdu`. The common header implementation is:

```python
def build_common_header(pdu_type, flags, hlen, pdo, plen):
    return bytes((int(pdu_type), flags, hlen, pdo)) + int(plen).to_bytes(4, "little")

def parse_common_header(raw):
    if len(raw) < 8:
        raise ProtocolError(0x01, 4, "truncated common header")
    try:
        pdu_type = PduType(raw[0])
    except ValueError as exc:
        raise ProtocolError(0x01, 0, "unsupported opcode") from exc
    return pdu_type, raw[1], raw[2], raw[3], int.from_bytes(raw[4:8], "little")
```

`build_pdu` must create zero-filled valid headers, set PFV/HPDA/CPDA/digests to zero, set IC lengths to 128, and populate H2CData/C2HData/R2T fields from keyword arguments `cccid`, `ttag`, `data_offset`, `data_length`. `parse_pdu` must validate opcode, fixed HLEN, PLEN equality, digest flags, IC PFV/alignment, PDO rules, and dword alignment.

- [ ] **Step 4: Run model tests**

Run: `pytest zte_nvmetcp_offload/03_tb/python/test_nvmetcp_model.py -q`

Expected: all parameterized cases pass.

- [ ] **Step 5: Commit the golden model**

```powershell
git add zte_nvmetcp_offload/03_tb/python
git -c user.name=Codex -c user.email=codex@local commit -m "test: add executable NVMe TCP golden model"
```

## Task 3: Define shared RTL protocol types and prove compilation

**Files:**
- Create: `zte_nvmetcp_offload/02_rtl/common/nvmetcp_pkg.sv`
- Create: `zte_nvmetcp_offload/03_tb/sv/tb_pkg.sv`
- Create: `zte_nvmetcp_offload/03_tb/sv/filelist.f`

- [ ] **Step 1: Write a package compilation test**

```systemverilog
module tb_pkg;
  import nvmetcp_pkg::*;
  initial begin
    if (PDU_ICREQ !== 8'h00 || PDU_R2T !== 8'h09) $fatal(1, "opcode mismatch");
    if (fixed_hlen(PDU_CAPSULECMD) !== 8'd72) $fatal(1, "HLEN mismatch");
    if (sat_inc32(32'hffff_ffff) !== 32'hffff_ffff) $fatal(1, "saturation mismatch");
    $display("TB_PASS tb_pkg");
    $finish;
  end
endmodule
```

- [ ] **Step 2: Verify compilation fails**

Run: `iverilog -g2012 -o tb_pkg.vvp zte_nvmetcp_offload/02_rtl/common/nvmetcp_pkg.sv zte_nvmetcp_offload/03_tb/sv/tb_pkg.sv`

Expected: FAIL because `nvmetcp_pkg.sv` does not exist.

- [ ] **Step 3: Implement the package**

Define `NUM_CONN=8`, `DATA_W=512`, `KEEP_W=64`, opcode constants, action constants `ACT_ICREQ`, `ACT_ICRESP`, `ACT_TERMINATE`, `ACT_CAPSULE_CMD`, `ACT_CAPSULE_RESP`, `ACT_H2C_DATA`, `ACT_C2H_DATA`, `ACT_R2T`, error constants, packed `action_meta_t`, `fixed_hlen`, `get_byte512`, `get_le16_512`, `get_le32_512`, and `sat_inc32`. The metadata must include `conn_id[2:0]`, `pdu_type[7:0]`, `action[3:0]`, `flags[7:0]`, `plen[31:0]`, `cccid[15:0]`, `ttag[15:0]`, `data_offset[31:0]`, `data_length[31:0]`, `fes[15:0]`, `fei[31:0]`, and `error`.

- [ ] **Step 4: Compile and run the package test**

Run: `iverilog -g2012 -o tb_pkg.vvp ...; vvp tb_pkg.vvp`

Expected: `TB_PASS tb_pkg`.

- [ ] **Step 5: Commit package and test**

```powershell
git add zte_nvmetcp_offload/02_rtl/common zte_nvmetcp_offload/03_tb/sv
git -c user.name=Codex -c user.email=codex@local commit -m "feat: define shared NVMe TCP RTL types"
```

## Task 4: Build and verify packet-granular round-robin scheduling

**Files:**
- Create: `zte_nvmetcp_offload/02_rtl/scheduler/nvmetcp_rr_scheduler.sv`
- Create: `zte_nvmetcp_offload/03_tb/sv/tb_rr_scheduler.sv`

- [ ] **Step 1: Write the failing scheduler test**

The test drives `pending=8'b11111111`, pulses `grant_done` after every grant, and records 16 accepted `grant_id` values. It must compare against `0,1,2,3,4,5,6,7,0,1,2,3,4,5,6,7`. A second phase drives only bits 2 and 6 and expects `2,6,2,6`. The DUT interface is:

```systemverilog
nvmetcp_rr_scheduler dut (
  .clk, .rst_n, .pending,
  .grant_valid, .grant_ready(1'b1), .grant_id,
  .grant_done
);
```

- [ ] **Step 2: Compile to prove the test fails**

Run: `iverilog -g2012 -o tb_rr.vvp nvmetcp_rr_scheduler.sv tb_rr_scheduler.sv`

Expected: FAIL because the scheduler module is missing.

- [ ] **Step 3: Implement minimal round-robin logic**

Use a three-bit `last_grant` register. Combinationally scan offsets 1 through 8 from `last_grant`, select the first asserted pending bit, and hold `grant_id` stable until `grant_done`. Reset `last_grant` to 7 so the first grant is connection 0. Do not advance priority on `grant_valid` alone.

- [ ] **Step 4: Run the scheduler test**

Run the compiled simulation and require `TB_PASS tb_rr_scheduler` with no `$fatal`.

- [ ] **Step 5: Commit scheduler**

```powershell
git add zte_nvmetcp_offload/02_rtl/scheduler zte_nvmetcp_offload/03_tb/sv/tb_rr_scheduler.sv
git -c user.name=Codex -c user.email=codex@local commit -m "feat: add fair packet round robin scheduler"
```

## Task 5: Implement Gray-code synchronization and asynchronous buffer bank

**Files:**
- Create: `zte_nvmetcp_offload/02_rtl/cdc/nvmetcp_gray_sync.sv`
- Create: `zte_nvmetcp_offload/02_rtl/buffer/nvmetcp_async_buffer_bank.sv`
- Create: `zte_nvmetcp_offload/03_tb/sv/tb_gray_sync.sv`
- Create: `zte_nvmetcp_offload/03_tb/sv/tb_async_buffer_bank.sv`

- [ ] **Step 1: Write failing CDC tests**

`tb_gray_sync.sv` increments a 6-bit source pointer on a 7 ns clock and samples it through a two-flop synchronizer on a 5 ns clock. After source activity stops, the destination binary value must converge to the final source value within four destination cycles. It also asserts `$onehot0(gray ^ $past(gray))` after each source increment.

`tb_async_buffer_bank.sv` writes two PDU beats for connection 3 using 7 ns `wr_clk`, verifies `pending[3]` stays low before the `wr_last` commit, then reads on 5 ns `core_clk` and compares both 512-bit beats and keeps. It repeats across pointer wrap and exercises connection-local full backpressure.

- [ ] **Step 2: Compile to confirm missing-module failures**

Run both tests with Icarus.

Expected: FAIL because CDC and buffer modules do not exist.

- [ ] **Step 3: Implement Gray synchronizer**

Create parameterized `nvmetcp_gray_sync #(WIDTH)` with `src_bin`, `src_gray`, `dst_clk`, `dst_rst_n`, `dst_gray`, and `dst_bin`. Compute source Gray as `(src_bin >> 1) ^ src_bin`; synchronize using two registers declared `(* ASYNC_REG = "TRUE" *)`; reconstruct binary using cumulative XOR from MSB to LSB.

- [ ] **Step 4: Implement the buffer bank**

Use parameters `NUM_CONN=8`, `DEPTH_WORDS=32`, `DATA_W=512`. Store `{keep,last,data}` in a per-connection logical array with independent write and committed pointers. Required interfaces are write ready/valid/conn/data/keep/last, core `pending`, scheduler-selected `rd_conn`, read request/valid/data/keep/last, and `rd_consume`. Publish only the committed write pointer after a last beat; synchronize consumed read pointers back for full detection. Reject non-contiguous packets for one connection while that connection has an uncommitted packet.

- [ ] **Step 5: Run CDC and buffer tests**

Expected: `TB_PASS tb_gray_sync` and `TB_PASS tb_async_buffer_bank`.

- [ ] **Step 6: Commit CDC and buffer**

```powershell
git add zte_nvmetcp_offload/02_rtl/cdc zte_nvmetcp_offload/02_rtl/buffer zte_nvmetcp_offload/03_tb/sv/tb_gray_sync.sv zte_nvmetcp_offload/03_tb/sv/tb_async_buffer_bank.sv
git -c user.name=Codex -c user.email=codex@local commit -m "feat: add CDC safe connection buffer bank"
```

## Task 6: Frame committed buffer data into complete PDUs

**Files:**
- Create: `zte_nvmetcp_offload/02_rtl/parser/nvmetcp_pdu_reader.sv`
- Create: `zte_nvmetcp_offload/03_tb/sv/tb_pdu_reader.sv`

- [ ] **Step 1: Write the failing reader test**

Drive a 128 B ICReq as two beats, a 24 B R2T as one beat with `keep=64'h00ff_ffff`, and a malformed R2T whose PLEN says 24 while keep says 20. Check start/last framing, beat order, computed beat count, and `frame_error` on only the malformed case. Apply random `out_ready` and assert output data remains stable while stalled.

- [ ] **Step 2: Verify failure before implementation**

Run: `iverilog -g2012 -o tb_reader.vvp ... tb_pdu_reader.sv`

Expected: missing `nvmetcp_pdu_reader` failure.

- [ ] **Step 3: Implement the reader FSM**

Use states `IDLE`, `REQUEST`, `HOLD`, `FINISH`. Latch connection ID, extract PLEN from bytes 4:7 of the first beat, compute `(plen+63)>>6`, count beats, and compare final keep against `(plen % 64 == 0) ? ~0 : ((1<<remainder)-1)`. Hold all output fields under backpressure. Pulse `grant_done` only after the final beat handshakes or a malformed frame is reported.

- [ ] **Step 4: Run reader test**

Expected: `TB_PASS tb_pdu_reader`.

- [ ] **Step 5: Commit reader**

```powershell
git add zte_nvmetcp_offload/02_rtl/parser/nvmetcp_pdu_reader.sv zte_nvmetcp_offload/03_tb/sv/tb_pdu_reader.sv
git -c user.name=Codex -c user.email=codex@local commit -m "feat: frame buffered beats into NVMe TCP PDUs"
```

## Task 7: Parse and validate all nine PDU types

**Files:**
- Create: `zte_nvmetcp_offload/02_rtl/parser/nvmetcp_parser.sv`
- Create: `zte_nvmetcp_offload/03_tb/sv/tb_parser.sv`
- Create: `zte_nvmetcp_offload/03_tb/python/generate_vectors.py`
- Create: `zte_nvmetcp_offload/03_tb/vectors/.gitkeep`

- [ ] **Step 1: Generate deterministic golden headers and expected metadata**

`generate_vectors.py` imports the model, emits one valid PDU for each opcode and invalid cases for unknown opcode, wrong HLEN, wrong PLEN, digest flag, nonzero PFV, nonzero HPDA/CPDA, invalid PDO, and non-dword data lengths. It writes `packets.hex` as one byte per line and `manifest.json` with `name`, `offset`, `length`, expected metadata, FES, and FEI. Seed random extensions with `0x4e564d45`.

- [ ] **Step 2: Write the failing parser test**

The SV test loads generated vectors, packs each PDU into 512-bit beats in byte-zero-at-`[7:0]` order, and checks one action per packet. For valid PDU types it compares action, opcode, PLEN, CCCID, TTAG, offset, length, and flags. For invalid packets it checks `error=1` and exact FES/FEI.

- [ ] **Step 3: Prove parser test failure**

Run vector generation, then compile the parser test.

Expected: missing parser module failure.

- [ ] **Step 4: Implement parser validation and extraction**

Buffer the first two beats because IC and CapsuleCmd fields extend beyond 64 B. Validate in this order: supported opcode; fixed HLEN; PLEN range/equality; reserved/digest flags; PDO; PFV/alignment; type-reserved fields; dword alignment. Populate one `action_meta_t` per PDU. Stream payload beats unchanged with start/last/keep after metadata acceptance. Map valid types to the eight action constants and errors to `ACT_TERMINATE`.

- [ ] **Step 5: Run Python and SV parser tests**

Expected: pytest passes and `TB_PASS tb_parser`.

- [ ] **Step 6: Commit parser and vectors**

```powershell
git add zte_nvmetcp_offload/02_rtl/parser/nvmetcp_parser.sv zte_nvmetcp_offload/03_tb
git -c user.name=Codex -c user.email=codex@local commit -m "feat: parse and validate nine NVMe TCP PDU types"
```

## Task 8: Generate ICResp and directional TermReq replies

**Files:**
- Create: `zte_nvmetcp_offload/02_rtl/response/nvmetcp_response_gen.sv`
- Create: `zte_nvmetcp_offload/03_tb/sv/tb_response_gen.sv`

- [ ] **Step 1: Write the failing byte-accurate response test**

For a valid ICReq action, expect two 512-bit beats representing a 128 B ICResp: opcode `01`, flags `00`, HLEN `80`, PDO `00`, PLEN `80 00 00 00`, PFV `00 00`, CPDA `00`, DGST `00`, and MAXH2CDATA `00 10 00 00`, with all other bytes zero. For an invalid H2C packet expect opcode `03` C2HTermReq, HLEN 24, FES/FEI copied; for invalid C2H expect opcode `02` H2CTermReq.

- [ ] **Step 2: Verify failure before implementation**

Expected: missing response generator module.

- [ ] **Step 3: Implement registered packet construction**

Create a two-beat response buffer with ready/valid stability. ICResp always disables digests and uses CPDA=0. TermReq uses exactly 24 B when no offending header capture is provided, sets keep to `64'h00ff_ffff`, and writes FES at bytes 8:9 and FEI at bytes 10:13. Inputs that require only an action must not create a response.

- [ ] **Step 4: Run response tests**

Expected: `TB_PASS tb_response_gen`.

- [ ] **Step 5: Commit response generator**

```powershell
git add zte_nvmetcp_offload/02_rtl/response zte_nvmetcp_offload/03_tb/sv/tb_response_gen.sv
git -c user.name=Codex -c user.email=codex@local commit -m "feat: generate initialization and terminate responses"
```

## Task 9: Add saturating observability counters

**Files:**
- Create: `zte_nvmetcp_offload/02_rtl/monitor/nvmetcp_monitor.sv`
- Create: `zte_nvmetcp_offload/03_tb/sv/tb_monitor.sv`

- [ ] **Step 1: Write failing monitor test**

Pulse accepted actions for connections 0 and 7, each PDU type, two errors, buffer-full attempt, and backpressure cycle. Read counters through `mon_addr`/`mon_rdata`; check per-connection, per-type, total error, error class, and latest error fields. Force a selected counter to `32'hffff_fffe` through a simulation-only hierarchical assignment, pulse twice, and check saturation.

- [ ] **Step 2: Confirm missing-module failure**

Run the focused Icarus compilation and expect failure.

- [ ] **Step 3: Implement monitor register map**

Use `sat_inc32` for all 32-bit counters. Map `0x000-0x01c` to per-connection packet counters, `0x040-0x05c` to scheduling counters, `0x080-0x0a0` to opcode counters, `0x0c0` total errors, `0x0c4` overflow attempts, `0x0c8` backpressure cycles, and `0x0d0-0x0dc` latest error fields. Synchronous `mon_clear` clears counters and latest-error state.

- [ ] **Step 4: Run monitor test**

Expected: `TB_PASS tb_monitor`.

- [ ] **Step 5: Commit monitor**

```powershell
git add zte_nvmetcp_offload/02_rtl/monitor zte_nvmetcp_offload/03_tb/sv/tb_monitor.sv
git -c user.name=Codex -c user.email=codex@local commit -m "feat: add saturating parser observability counters"
```

## Task 10: Integrate the offload top and verify eight connections

**Files:**
- Create: `zte_nvmetcp_offload/02_rtl/top/nvmetcp_offload_top.sv`
- Create: `zte_nvmetcp_offload/03_tb/sv/tb_offload_top.sv`
- Modify: `zte_nvmetcp_offload/03_tb/sv/filelist.f`

- [ ] **Step 1: Write the failing integration test**

Instantiate the top with `DEPTH_WORDS=32`. Drive a 7 ns write clock and 5 ns core clock. Submit one valid packet to each connection before accepting actions, then require action connection order `0..7`. Continue feeding all eight connections for 32 rounds, inject random action/response backpressure, and assert every connection receives exactly 32 actions with maximum grant distance at most 8 completed packets. Separately inject valid ICReq and invalid R2T and compare response bytes. Measure accepted payload bits divided by active core cycles and require at least 40 Gb/s during a long H2CData phase without backpressure.

- [ ] **Step 2: Confirm integration compile failure**

Run: `iverilog -g2012 -f zte_nvmetcp_offload/03_tb/sv/filelist.f -s tb_offload_top -o tb_top.vvp`

Expected: missing top module failure.

- [ ] **Step 3: Wire buffer, scheduler, reader, parser, response, and monitor**

Expose write-side `wr_valid/ready/conn/data/keep/last`, core action metadata and payload streams, response stream, and monitor read interface. Propagate backpressure without combinational loops. Reset each clock domain synchronously after external active-low reset synchronization. Keep all payload and response outputs stable under valid-without-ready.

- [ ] **Step 4: Run the full integration simulation**

Expected: `TB_PASS tb_offload_top`, all assertions silent, reported throughput at least `40.000 Gb/s`.

- [ ] **Step 5: Commit integrated RTL**

```powershell
git add zte_nvmetcp_offload/02_rtl/top zte_nvmetcp_offload/03_tb/sv
git -c user.name=Codex -c user.email=codex@local commit -m "feat: integrate eight connection NVMe TCP offload top"
```

## Task 11: Add repeatable local and Vivado automation

**Files:**
- Create: `zte_nvmetcp_offload/06_scripts/run_unit.ps1`
- Create: `zte_nvmetcp_offload/06_scripts/run_regression.ps1`
- Create: `zte_nvmetcp_offload/06_scripts/run_vivado.ps1`
- Create: `zte_nvmetcp_offload/04_vivado/create_project.tcl`
- Create: `zte_nvmetcp_offload/04_vivado/run_synth.tcl`
- Create: `zte_nvmetcp_offload/05_constraints/nvmetcp_offload.xdc`
- Create: `zte_nvmetcp_offload/03_tb/python/test_scripts.py`

- [ ] **Step 1: Write failing script-content tests**

```python
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]

def test_vivado_script_is_guarded():
    text = (ROOT / "06_scripts/run_vivado.ps1").read_text(encoding="utf-8")
    assert "Get-Command vivado" in text
    assert "exit 2" in text

def test_xdc_declares_async_clock_groups():
    text = (ROOT / "05_constraints/nvmetcp_offload.xdc").read_text(encoding="utf-8")
    assert "create_clock -period 5.000" in text
    assert "set_clock_groups -asynchronous" in text
```

- [ ] **Step 2: Run tests and confirm missing-file failures**

Run the focused pytest file and expect failure.

- [ ] **Step 3: Implement local regression scripts**

`run_unit.ps1` runs pytest and every focused Icarus bench, stops on first nonzero exit, and writes a timestamped summary under `07_reports/generated/simulation`. `run_regression.ps1` first regenerates vectors, then calls unit and integration flows. Both resolve paths from `$PSScriptRoot` and never assume the current directory.

- [ ] **Step 4: Implement Vivado scripts and XDC**

`run_vivado.ps1` must print `Vivado executable not found; RTL regression remains available.` and exit 2 when absent. Tcl reads `PART` from the environment or uses `xc7a200tsbg484-1`, imports all RTL and XDC, runs `synth_design -top nvmetcp_offload_top`, and writes utilization, timing summary, methodology, and CDC reports to `07_reports/generated`. XDC defines 200 MHz `core_clk`, a named write clock, asynchronous clock groups, and synchronizer false paths restricted to ASYNC_REG cells.

- [ ] **Step 5: Run script tests and local regression**

Expected: pytest passes; `run_regression.ps1` exits 0; `run_vivado.ps1` exits 2 with the exact absence message on the present machine.

- [ ] **Step 6: Commit automation**

```powershell
git add zte_nvmetcp_offload/04_vivado zte_nvmetcp_offload/05_constraints zte_nvmetcp_offload/06_scripts zte_nvmetcp_offload/03_tb/python/test_scripts.py
git -c user.name=Codex -c user.email=codex@local commit -m "build: add reproducible RTL and Vivado automation"
```

## Task 12: Complete traceability, user documentation, and delivery packaging

**Files:**
- Create: `zte_nvmetcp_offload/00_requirements/requirements_traceability.md`
- Create: `zte_nvmetcp_offload/01_docs/architecture.md`
- Create: `zte_nvmetcp_offload/01_docs/interfaces.md`
- Create: `zte_nvmetcp_offload/01_docs/protocol_support.md`
- Create: `zte_nvmetcp_offload/06_scripts/package_delivery.ps1`
- Create: `zte_nvmetcp_offload/08_delivery/README.md`
- Create: `zte_nvmetcp_offload/03_tb/python/test_docs.py`

- [ ] **Step 1: Write failing documentation checks**

The test must require all eight numbered source requirements to appear as `REQ-001` through `REQ-008`, each row containing an RTL path, test name, and evidence path. It must require all nine PDU names in `protocol_support.md`, all top ports in `interfaces.md`, and both local and Vivado acceptance commands in `08_delivery/README.md`.

- [ ] **Step 2: Verify documentation tests fail**

Run the focused pytest and expect missing-file failures.

- [ ] **Step 3: Write architecture, interfaces, protocol, and traceability documents**

Document little-endian byte order, packet-aligned 64 B input assumption, write commit semantics, ready/valid stability, register map, reset sequencing, supported checks, action/reply table, non-goals, and actual local-tool limitations. Map each REQ row to exact modules and focused tests; use `NOT_RUN_NO_VIVADO` rather than PASS for synthesis/timing evidence until Vivado produces reports.

- [ ] **Step 4: Implement deterministic packaging**

`package_delivery.ps1` deletes only `08_delivery/package` after resolving and checking it is within the project root, copies requirements/docs/RTL/TB/scripts/constraints and generated text reports, excludes caches and raw build directories, writes `MANIFEST.sha256`, and creates `08_delivery/zte_nvmetcp_offload_delivery.zip`.

- [ ] **Step 5: Run docs tests and packaging**

Expected: documentation pytest passes; package exists; manifest contains every packaged file except itself.

- [ ] **Step 6: Commit documentation and delivery flow**

```powershell
git add zte_nvmetcp_offload/00_requirements zte_nvmetcp_offload/01_docs zte_nvmetcp_offload/06_scripts/package_delivery.ps1 zte_nvmetcp_offload/08_delivery
git -c user.name=Codex -c user.email=codex@local commit -m "docs: add acceptance traceability and delivery workflow"
```

## Task 13: Final evidence-backed verification

**Files:**
- Modify: `zte_nvmetcp_offload/07_reports/README.md`
- Create when generated: `zte_nvmetcp_offload/07_reports/generated/simulation/regression_summary.txt`
- Create when generated: `zte_nvmetcp_offload/08_delivery/acceptance_status.md`

- [ ] **Step 1: Run the complete local regression from a clean generated-output state**

Run:

```powershell
& .\zte_nvmetcp_offload\06_scripts\run_regression.ps1
```

Expected: exit 0, all pytest and Icarus tests pass, throughput line is at least 40 Gb/s.

- [ ] **Step 2: Check Vivado availability and record the real result**

Run:

```powershell
& .\zte_nvmetcp_offload\06_scripts\run_vivado.ps1
```

Expected on the current machine: exit 2 and an explicit unavailable message. If Vivado becomes available, require synthesis completion, WNS >= 0 at 5 ns, and report files that contain no critical methodology/CDC violations attributable to the RTL.

- [ ] **Step 3: Inspect repository cleanliness and delivery manifest**

Run `git status --short`, list tracked generated evidence, and verify no `.Xil`, VVP, VCD, WDB, cache, or Vivado run directories are staged.

- [ ] **Step 4: Write the acceptance status with exact evidence**

The status document must list local tool versions, commands, exit codes, test counts, measured throughput, Git commit, and the Vivado state as either `PASS` with report links or `NOT_RUN_NO_VIVADO`. It must not describe unexecuted synthesis or timing checks as passed.

- [ ] **Step 5: Repackage and commit final reproducible evidence**

```powershell
& .\zte_nvmetcp_offload\06_scripts\package_delivery.ps1
git add zte_nvmetcp_offload/07_reports zte_nvmetcp_offload/08_delivery
git -c user.name=Codex -c user.email=codex@local commit -m "test: record final NVMe TCP acceptance evidence"
```

## Self-review record

- Spec coverage: all eight source requirements map to Tasks 5 through 13; all nine PDU types map to Tasks 2, 7, 8, and 10.
- Scope: TCP/IP, TLS, digest calculation, NVMe command execution, DDR, and board integration remain explicit non-goals.
- Type consistency: `action_meta_t`, ready/valid streams, PDU/action/error constants, and monitor addresses are defined once and consumed under the same names.
- Environment realism: local verification uses installed Python/pytest/Icarus; Vivado absence is a recorded incomplete external check, not a simulated success.
- Placeholder scan: the plan contains no deferred implementation fields or ambiguous pass criteria.

