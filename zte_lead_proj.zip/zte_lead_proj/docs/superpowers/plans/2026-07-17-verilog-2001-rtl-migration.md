# NVMe/TCP RTL Verilog-2001 Migration Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Convert every design unit under `zte_nvmetcp_offload/02_rtl` to strict Verilog-2001 while retaining SystemVerilog verification and preserving all existing behavior and measured throughput.

**Architecture:** Replace the RTL package with a macro-only Verilog header and represent `action_meta_t` as a stable 200-bit packed vector at every DUT boundary. Keep a verification-only SystemVerilog package with the original struct layout so existing self-checking benches remain readable and connect bit-for-bit to the flattened DUT ports. Migrate leaf modules before the parser and top, then switch scripts, Vivado, documentation, and delivery artifacts.

**Tech Stack:** Verilog-2001, SystemVerilog testbenches, Icarus Verilog 12, pytest 8, PowerShell, Xilinx Vivado Tcl.

---

## File map

**Create**

- `zte_nvmetcp_offload/02_rtl/common/nvmetcp_defs.vh`: include-guarded opcode, action, FES, maximum-length, and metadata bit-position macros.
- `zte_nvmetcp_offload/03_tb/sv/nvmetcp_pkg.sv`: verification-only package retaining the original constants, struct, and helper functions.
- `zte_nvmetcp_offload/03_tb/python/test_verilog2001_rtl.py`: structural, forbidden-token, strict-compile, filelist, and Vivado language-boundary tests.

**Rename and modify**

- All nine `zte_nvmetcp_offload/02_rtl/**/*.sv` design files become `.v`; `nvmetcp_pkg.sv` is replaced rather than renamed.
- `nvmetcp_gray_sync.v`, `nvmetcp_rr_scheduler.v`, `nvmetcp_pdu_reader.v`: leaf Verilog conversions.
- `nvmetcp_async_buffer_bank.v`: custom constant `clog2`, flattened storage memory, and Verilog declarations.
- `nvmetcp_parser.v`, `nvmetcp_response_gen.v`, `nvmetcp_monitor.v`, `nvmetcp_offload_top.v`: flattened metadata and shared macro usage.

**Modify**

- `zte_nvmetcp_offload/03_tb/sv/filelist.f`: point at `.v` RTL and verification-only package.
- `zte_nvmetcp_offload/06_scripts/run_unit.ps1`: add the common include directory, use the verification package, and add a strict `-g2001` RTL compile before SV benches.
- `zte_nvmetcp_offload/04_vivado/create_project.tcl`: glob `.v`, add `.vh`, and configure the include directory.
- `zte_nvmetcp_offload/04_vivado/run_synth.tcl`: use `read_verilog` without `-sv` and add include directories.
- `zte_nvmetcp_offload/README.md`, `01_docs/architecture.md`, `01_docs/interfaces.md`, `00_requirements/requirements_traceability.md`, `08_delivery/README.md`, and `08_delivery/acceptance_status.md`: document the Verilog/SV boundary and fresh evidence.

### Task 1: Establish the Verilog-2001 language contract

**Files:**

- Create: `zte_nvmetcp_offload/03_tb/python/test_verilog2001_rtl.py`
- Create: `zte_nvmetcp_offload/02_rtl/common/nvmetcp_defs.vh`
- Create: `zte_nvmetcp_offload/03_tb/sv/nvmetcp_pkg.sv`
- Delete: `zte_nvmetcp_offload/02_rtl/common/nvmetcp_pkg.sv`
- Modify: `zte_nvmetcp_offload/03_tb/sv/tb_pkg.sv`

- [ ] **Step 1: Write the first failing contract tests**

Create the test helper and common-definition tests:

```python
from pathlib import Path
import re
import subprocess


ROOT = Path(__file__).resolve().parents[2]
RTL = ROOT / "02_rtl"
COMMON = RTL / "common"
FORBIDDEN = re.compile(
    r"\b(package|import|logic|bit|typedef|struct|enum|always_ff|always_comb|"
    r"always_latch|interface|modport)\b|::|\$clog2"
)


def assert_verilog2001(*paths: Path) -> None:
    for path in paths:
        assert path.suffix in {".v", ".vh"}
        text = path.read_text(encoding="utf-8")
        assert not FORBIDDEN.search(text), path


def compile_verilog2001(top: str, *sources: Path) -> None:
    result = subprocess.run(
        [
            "iverilog", "-g2001", "-tnull", "-s", top,
            "-I", str(COMMON), *(str(path) for path in sources),
        ],
        cwd=ROOT,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, result.stdout + result.stderr


def test_common_rtl_is_header_only_verilog2001():
    files = sorted(path for path in COMMON.iterdir() if path.is_file())
    assert [path.name for path in files] == ["nvmetcp_defs.vh"]
    assert_verilog2001(*files)


def test_metadata_layout_is_stable():
    text = (COMMON / "nvmetcp_defs.vh").read_text(encoding="utf-8")
    expected = {
        "NVMETCP_ACTION_META_W": "200",
        "NVMETCP_META_ERROR_BIT": "0",
        "NVMETCP_META_FEI_MSB": "32",
        "NVMETCP_META_CONN_ID_MSB": "199",
    }
    for name, value in expected.items():
        assert re.search(rf"`define\s+{name}\s+{value}\b", text)
```

- [ ] **Step 2: Run the tests and verify RED**

Run:

```powershell
pytest .\zte_nvmetcp_offload\03_tb\python\test_verilog2001_rtl.py -q
```

Expected: failures because `nvmetcp_pkg.sv` still exists and `nvmetcp_defs.vh` does not.

- [ ] **Step 3: Add the shared Verilog header and verification-only package**

Define all protocol constants with the `NVMETCP_` prefix and the exact metadata layout:

```verilog
`ifndef NVMETCP_DEFS_VH
`define NVMETCP_DEFS_VH
`define NVMETCP_MAX_PDU_BYTES 8264
`define NVMETCP_ACTION_META_W 200
`define NVMETCP_PDU_ICREQ 8'h00
`define NVMETCP_PDU_ICRESP 8'h01
`define NVMETCP_PDU_H2CTERMREQ 8'h02
`define NVMETCP_PDU_C2HTERMREQ 8'h03
`define NVMETCP_PDU_CAPSULECMD 8'h04
`define NVMETCP_PDU_CAPSULERESP 8'h05
`define NVMETCP_PDU_H2CDATA 8'h06
`define NVMETCP_PDU_C2HDATA 8'h07
`define NVMETCP_PDU_R2T 8'h09
`define NVMETCP_ACT_NONE 4'h0
`define NVMETCP_ACT_ICREQ 4'h1
`define NVMETCP_ACT_ICRESP 4'h2
`define NVMETCP_ACT_TERMINATE 4'h3
`define NVMETCP_ACT_CAPSULE_CMD 4'h4
`define NVMETCP_ACT_CAPSULE_RESP 4'h5
`define NVMETCP_ACT_H2C_DATA 4'h6
`define NVMETCP_ACT_C2H_DATA 4'h7
`define NVMETCP_ACT_R2T 4'h8
`define NVMETCP_FES_INVALID_HEADER 16'h0001
`define NVMETCP_FES_PDU_SEQUENCE 16'h0002
`define NVMETCP_FES_HEADER_DIGEST 16'h0003
`define NVMETCP_FES_DATA_OUT_OF_RANGE 16'h0004
`define NVMETCP_FES_TRANSFER_LIMIT 16'h0005
`define NVMETCP_FES_UNSUPPORTED_PARAM 16'h0006
`define NVMETCP_META_ERROR_BIT 0
`define NVMETCP_META_FEI_LSB 1
`define NVMETCP_META_FEI_MSB 32
`define NVMETCP_META_FES_LSB 33
`define NVMETCP_META_FES_MSB 48
`define NVMETCP_META_DATA_LENGTH_LSB 49
`define NVMETCP_META_DATA_LENGTH_MSB 80
`define NVMETCP_META_DATA_OFFSET_LSB 81
`define NVMETCP_META_DATA_OFFSET_MSB 112
`define NVMETCP_META_TTAG_LSB 113
`define NVMETCP_META_TTAG_MSB 128
`define NVMETCP_META_CCCID_LSB 129
`define NVMETCP_META_CCCID_MSB 144
`define NVMETCP_META_PLEN_LSB 145
`define NVMETCP_META_PLEN_MSB 176
`define NVMETCP_META_FLAGS_LSB 177
`define NVMETCP_META_FLAGS_MSB 184
`define NVMETCP_META_ACTION_LSB 185
`define NVMETCP_META_ACTION_MSB 188
`define NVMETCP_META_PDU_TYPE_LSB 189
`define NVMETCP_META_PDU_TYPE_MSB 196
`define NVMETCP_META_CONN_ID_LSB 197
`define NVMETCP_META_CONN_ID_MSB 199
`endif
```

Create `03_tb/sv/nvmetcp_pkg.sv` as a verification-only package. Include `nvmetcp_defs.vh`; alias every PDU/action/FES macro to the existing package names; declare the 200-bit packed struct in this exact member order: `conn_id`, `pdu_type`, `action`, `flags`, `plen`, `cccid`, `ttag`, `data_offset`, `data_length`, `fes`, `fei`, `error`; and copy the existing `fixed_hlen`, `get_byte512`, `get_le16_512`, `get_le32_512`, and `sat_inc32` function bodies unchanged. Extend `tb_pkg.sv` with `$bits(action_meta_t) == 200` and a struct-to-vector layout check for `conn_id` and `error`.

- [ ] **Step 4: Run the common tests and package bench**

Run:

```powershell
pytest .\zte_nvmetcp_offload\03_tb\python\test_verilog2001_rtl.py -q
iverilog -g2012 -I .\zte_nvmetcp_offload\02_rtl\common -s tb_pkg -o $env:TEMP\tb_pkg.vvp .\zte_nvmetcp_offload\03_tb\sv\nvmetcp_pkg.sv .\zte_nvmetcp_offload\03_tb\sv\tb_pkg.sv
vvp $env:TEMP\tb_pkg.vvp
```

Expected: pytest passes and `TB_PASS tb_pkg`.

- [ ] **Step 5: Commit**

```powershell
git add zte_nvmetcp_offload/02_rtl/common zte_nvmetcp_offload/03_tb/sv zte_nvmetcp_offload/03_tb/python/test_verilog2001_rtl.py
git commit -m "test: define Verilog-2001 RTL language contract"
```

### Task 2: Convert the leaf control and reader modules

**Files:**

- Rename: `02_rtl/cdc/nvmetcp_gray_sync.sv` → `nvmetcp_gray_sync.v`
- Rename: `02_rtl/scheduler/nvmetcp_rr_scheduler.sv` → `nvmetcp_rr_scheduler.v`
- Rename: `02_rtl/parser/nvmetcp_pdu_reader.sv` → `nvmetcp_pdu_reader.v`
- Modify: `03_tb/python/test_verilog2001_rtl.py`

- [ ] **Step 1: Add a failing leaf-module test**

```python
def test_leaf_modules_compile_as_verilog2001():
    sources = [
        RTL / "cdc/nvmetcp_gray_sync.v",
        RTL / "scheduler/nvmetcp_rr_scheduler.v",
        RTL / "parser/nvmetcp_pdu_reader.v",
    ]
    assert_verilog2001(*sources)
    for source, top in zip(sources, [
        "nvmetcp_gray_sync", "nvmetcp_rr_scheduler", "nvmetcp_pdu_reader"
    ]):
        compile_verilog2001(top, source)
```

- [ ] **Step 2: Verify RED**

Run the new test. Expected: missing `.v` files.

- [ ] **Step 3: Convert the three modules**

Use ANSI Verilog-2001 ports with `input`, `output`, and `output reg`; replace internal `logic` with `wire`/`reg`, `always_ff` with `always @(posedge ...)`, and unsized `'0` with width-safe `{WIDTH{1'b0}}` or explicit constants. Replace both enum state declarations with exact localparams:

```verilog
localparam [1:0] STATE_IDLE = 2'd0;
localparam [1:0] STATE_REQUEST = 2'd1;
localparam [1:0] STATE_HOLD = 2'd2;
reg [1:0] state;
```

Declare `keep_for_plen` using classic Verilog function ports:

```verilog
function [63:0] keep_for_plen;
  input [31:0] length;
  reg [5:0] remainder;
  begin
    remainder = length[5:0];
    if (remainder == 0)
      keep_for_plen = 64'hffff_ffff_ffff_ffff;
    else
      keep_for_plen = (64'h1 << remainder) - 64'h1;
  end
endfunction
```

Do not change scheduling order, reader backpressure, frame-error behavior, or CDC attributes.

- [ ] **Step 4: Verify GREEN and behavior**

Run the targeted pytest test, then compile/run `tb_gray_sync`, `tb_rr_scheduler`, and `tb_pdu_reader` against the `.v` files. Expected: three strict compiles pass and three `TB_PASS` lines.

- [ ] **Step 5: Commit**

```powershell
git add zte_nvmetcp_offload/02_rtl zte_nvmetcp_offload/03_tb/python/test_verilog2001_rtl.py
git commit -m "refactor: convert leaf RTL to Verilog-2001"
```

### Task 3: Convert the asynchronous buffer bank

**Files:**

- Rename: `02_rtl/buffer/nvmetcp_async_buffer_bank.sv` → `nvmetcp_async_buffer_bank.v`
- Modify: `03_tb/python/test_verilog2001_rtl.py`

- [ ] **Step 1: Add and run a failing strict-compile test**

Compile the buffer with `nvmetcp_gray_sync.v` using top `nvmetcp_async_buffer_bank`; expect failure before the `.v` conversion.

- [ ] **Step 2: Replace SystemVerilog-only parameter and memory constructs**

Add `parameter integer CONN_W = 3`, replace `$clog2(DEPTH_WORDS)` with a classic integer `clog2` constant function, and flatten each two-dimensional memory:

```verilog
reg [DATA_W-1:0] mem_data [0:NUM_CONN*DEPTH_WORDS-1];
reg [KEEP_W-1:0] mem_keep [0:NUM_CONN*DEPTH_WORDS-1];
reg              mem_last [0:NUM_CONN*DEPTH_WORDS-1];
wire [CONN_W+ADDR_W-1:0] wr_mem_index;
wire [CONN_W+ADDR_W-1:0] rd_mem_index;
assign wr_mem_index = (wr_conn * DEPTH_WORDS) + wr_work_bin[wr_conn][ADDR_W-1:0];
assign rd_mem_index = (rd_conn * DEPTH_WORDS) + rd_bin[rd_conn][ADDR_W-1:0];
```

Replace `$error` with a Verilog-2001-compatible parameter guard using `$display` and `$finish`. Preserve pointer arrays as legal one-dimensional memories, Gray synchronization, full detection, commit-on-`wr_last`, and read-consume ordering.

- [ ] **Step 3: Verify strict compile and buffer behavior**

Run the targeted pytest test and `tb_async_buffer_bank`. Expected: strict compile passes and `TB_PASS tb_async_buffer_bank`.

- [ ] **Step 4: Commit**

```powershell
git add zte_nvmetcp_offload/02_rtl/buffer zte_nvmetcp_offload/03_tb/python/test_verilog2001_rtl.py
git commit -m "refactor: convert async buffer to Verilog-2001"
```

### Task 4: Convert the parser and flatten metadata

**Files:**

- Rename: `02_rtl/parser/nvmetcp_parser.sv` → `nvmetcp_parser.v`
- Modify: `03_tb/python/test_verilog2001_rtl.py`
- Modify: `03_tb/sv/tb_parser.sv`

- [ ] **Step 1: Add and run the failing parser strict-compile test**

Assert the `.v` file has no forbidden tokens and compile top `nvmetcp_parser` with `-g2001`; expect missing file/failure.

- [ ] **Step 2: Convert parser types and helpers**

Include `nvmetcp_defs.vh`, declare `output reg [NVMETCP_ACTION_META_W-1:0] action_meta`, replace enum states with four `localparam [1:0]` values, and define `meta_reg` as a 200-bit reg. Convert `make_error` and `decode_header` to functions returning `[199:0]`; replace every struct member access with the matching macro slice, for example:

```verilog
result[`NVMETCP_META_CONN_ID_MSB:`NVMETCP_META_CONN_ID_LSB] = conn;
result[`NVMETCP_META_ACTION_MSB:`NVMETCP_META_ACTION_LSB] = `NVMETCP_ACT_TERMINATE;
result[`NVMETCP_META_ERROR_BIT] = 1'b1;
```

Implement local classic-style `fixed_hlen`, `get_byte512`, `get_le16_512`, and `get_le32_512` functions. Preserve all nine PDU cases, exact FES/FEI values, digest/flag checks, and output backpressure behavior.

- [ ] **Step 3: Strengthen the SV boundary check**

Keep `action_meta_t action_meta` in the testbench and add:

```systemverilog
initial begin
  if ($bits(action_meta) != `NVMETCP_ACTION_META_W)
    $fatal(1, "DUT/testbench metadata width mismatch");
end
```

- [ ] **Step 4: Verify parser compile and all PDU cases**

Run strict pytest compile and `tb_parser` with the verification package first. Expected: `TB_PASS tb_parser`.

- [ ] **Step 5: Commit**

```powershell
git add zte_nvmetcp_offload/02_rtl/parser zte_nvmetcp_offload/03_tb
git commit -m "refactor: flatten parser metadata for Verilog-2001"
```

### Task 5: Convert response generation and monitoring

**Files:**

- Rename: `02_rtl/response/nvmetcp_response_gen.sv` → `nvmetcp_response_gen.v`
- Rename: `02_rtl/monitor/nvmetcp_monitor.sv` → `nvmetcp_monitor.v`
- Modify: `03_tb/python/test_verilog2001_rtl.py`

- [ ] **Step 1: Add and run failing strict-compile tests**

Add both `.v` paths to the compliance test and independently compile tops `nvmetcp_response_gen` and `nvmetcp_monitor`; expect missing files before conversion.

- [ ] **Step 2: Convert metadata consumers**

For both modules include the shared header and declare metadata input as `[199:0]`. Replace field selection with macro slices. Convert state encoding and all functions to classic Verilog syntax. In the monitor, implement local `sat_inc32` and retain one-dimensional counter memories. Example field extraction:

```verilog
wire [7:0] action_pdu_type;
assign action_pdu_type = action_meta[`NVMETCP_META_PDU_TYPE_MSB:`NVMETCP_META_PDU_TYPE_LSB];
```

Preserve byte-exact ICResp/TermReq construction, response backpressure stability, saturating counters, register map, and latest-error fields.

- [ ] **Step 3: Verify behavior**

Run targeted strict tests plus `tb_response_gen` and `tb_monitor`. Expected: both `TB_PASS` lines.

- [ ] **Step 4: Commit**

```powershell
git add zte_nvmetcp_offload/02_rtl/response zte_nvmetcp_offload/02_rtl/monitor zte_nvmetcp_offload/03_tb/python/test_verilog2001_rtl.py
git commit -m "refactor: convert response and monitor RTL to Verilog-2001"
```

### Task 6: Convert and integrate the top-level RTL

**Files:**

- Rename: `02_rtl/top/nvmetcp_offload_top.sv` → `nvmetcp_offload_top.v`
- Modify: `03_tb/sv/filelist.f`
- Modify: `03_tb/sv/tb_offload_top.sv`
- Modify: `06_scripts/run_unit.ps1`
- Modify: `03_tb/python/test_verilog2001_rtl.py`

- [ ] **Step 1: Add final-tree, filelist, and strict-top failing tests**

```python
def test_entire_rtl_tree_is_verilog2001():
    assert not list(RTL.rglob("*.sv"))
    sources = sorted(RTL.rglob("*.v")) + sorted(RTL.rglob("*.vh"))
    assert len(list(RTL.rglob("*.v"))) == 8
    assert_verilog2001(*sources)


def test_filelist_uses_verilog_rtl():
    lines = (ROOT / "03_tb/sv/filelist.f").read_text(encoding="utf-8").splitlines()
    assert any("03_tb/sv/nvmetcp_pkg.sv" in line for line in lines)
    assert all("02_rtl" not in line or line.endswith(".v") for line in lines)


def test_top_compiles_as_verilog2001():
    sources = sorted(RTL.rglob("*.v"))
    compile_verilog2001("nvmetcp_offload_top", *sources)
```

- [ ] **Step 2: Convert the top**

Flatten all metadata regs/ports to 200-bit vectors, convert `make_frame_error_meta` to a vector-returning classic function, replace parser field access with bit slices, change sequential/process declarations, and preserve the action/response atomic handshake and frame-error priority.

- [ ] **Step 3: Switch filelist and unit script**

Put `03_tb/sv/nvmetcp_pkg.sv` first in the mixed-language filelist, followed by the eight `.v` modules in dependency order. Update `Run-Sim` to pass `-I $CommonDir`; add a separate command before testbenches:

```powershell
& iverilog -g2001 -tnull -s nvmetcp_offload_top -I $CommonDir @RtlSources
if ($LASTEXITCODE -ne 0) { throw 'Verilog-2001 RTL compile failed' }
Write-Output 'VERILOG_2001_COMPILE_PASS'
```

Use `03_tb/sv/nvmetcp_pkg.sv` as `$Pkg`; do not pass the verification package to the strict RTL compile.

- [ ] **Step 4: Run all structural tests and nine benches**

Run:

```powershell
pytest .\zte_nvmetcp_offload\03_tb\python -q
powershell -NoProfile -ExecutionPolicy Bypass -File .\zte_nvmetcp_offload\06_scripts\run_unit.ps1 -SkipPython
```

Expected: all Python tests pass, `VERILOG_2001_COMPILE_PASS`, nine `TB_PASS` lines, throughput at least 40 Gb/s, and `UNIT_REGRESSION_PASS`.

- [ ] **Step 5: Commit**

```powershell
git add zte_nvmetcp_offload/02_rtl/top zte_nvmetcp_offload/03_tb zte_nvmetcp_offload/06_scripts/run_unit.ps1
git commit -m "refactor: integrate Verilog-2001 offload top"
```

### Task 7: Switch Vivado and project documentation

**Files:**

- Modify: `04_vivado/create_project.tcl`
- Modify: `04_vivado/run_synth.tcl`
- Modify: `03_tb/python/test_scripts.py`
- Modify: `README.md`
- Modify: `00_requirements/requirements_traceability.md`
- Modify: `01_docs/architecture.md`
- Modify: `01_docs/interfaces.md`
- Modify: `08_delivery/README.md`

- [ ] **Step 1: Add failing Vivado language-mode assertions**

```python
def test_vivado_reads_design_as_verilog_not_systemverilog():
    create = (ROOT / "04_vivado/create_project.tcl").read_text(encoding="utf-8")
    synth = (ROOT / "04_vivado/run_synth.tcl").read_text(encoding="utf-8")
    assert "*.v" in create and "*.sv" not in create
    assert "read_verilog -sv" not in synth
    assert "read_verilog $rtl_files" in synth
    assert "include_dirs" in create
```

- [ ] **Step 2: Update Vivado Tcl**

Glob only `.v` source units; add `02_rtl/common/nvmetcp_defs.vh`; set the source fileset `include_dirs` to `02_rtl/common`; and use plain `read_verilog` in batch synthesis. Keep the existing part override, reports, top, constraints, and WNS failure behavior unchanged.

- [ ] **Step 3: Update user-facing documentation**

Replace “纯 SystemVerilog RTL” with “Verilog-2001 RTL，SystemVerilog 验证”. Document the 200-bit metadata field table and explicit language boundary. Update paths from `.sv` to `.v/.vh`, state that no Xilinx IP is used, and retain `NOT_RUN_NO_VIVADO` until Vivado actually runs.

- [ ] **Step 4: Verify tests and documentation scan**

Run all Python tests and `rg -n "02_rtl.*\.sv|read_verilog -sv|纯 SystemVerilog RTL" zte_nvmetcp_offload`. Expected: pytest passes; ripgrep has no current-flow matches.

- [ ] **Step 5: Commit**

```powershell
git add zte_nvmetcp_offload/04_vivado zte_nvmetcp_offload/03_tb/python zte_nvmetcp_offload/README.md zte_nvmetcp_offload/00_requirements zte_nvmetcp_offload/01_docs zte_nvmetcp_offload/08_delivery/README.md
git commit -m "docs: switch Vivado and delivery to Verilog RTL"
```

### Task 8: Full regression, acceptance evidence, and delivery package

**Files:**

- Modify: `08_delivery/acceptance_status.md`
- Generate ignored: `07_reports/generated/simulation/regression_summary.txt`
- Generate ignored: `08_delivery/zte_nvmetcp_offload_delivery.zip`

- [ ] **Step 1: Run full local regression from a clean generated state**

Run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\zte_nvmetcp_offload\06_scripts\run_regression.ps1
```

Expected: all Python tests pass, strict Verilog compile passes, nine benches pass, measured throughput is at least 40 Gb/s, and final output is `REGRESSION_PASS`.

- [ ] **Step 2: Check Vivado availability without falsifying results**

Run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\zte_nvmetcp_offload\06_scripts\run_vivado.ps1
```

Expected on this host: exit code 2 and `Vivado executable not found`; record `NOT_RUN_NO_VIVADO`. If Vivado is present, require exit 0 and WNS ≥ 0 before recording PASS.

- [ ] **Step 3: Update acceptance evidence**

Record the new commit, Python count, nine benches, `VERILOG_2001_COMPILE_PASS`, measured throughput, and actual Vivado status in `08_delivery/acceptance_status.md`.

- [ ] **Step 4: Build and inspect the delivery archive**

Run the packaging script, list the ZIP, and assert the archive contains `.v/.vh` RTL but no `02_rtl/*.sv`, caches, or generated Vivado projects.

- [ ] **Step 5: Final clean verification and commit**

Run `git diff --check`, `git status --short`, pytest, unit regression, and the language grep. Commit only tracked source/evidence changes; keep generated reports and ZIP ignored.

```powershell
git add zte_nvmetcp_offload/08_delivery/acceptance_status.md
git commit -m "docs: record Verilog-2001 migration evidence"
```
