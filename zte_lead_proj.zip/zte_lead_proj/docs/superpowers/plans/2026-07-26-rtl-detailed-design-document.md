# NVMe/TCP RTL Detailed Design Document Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Create one engineer-focused Markdown document that explains the complete NVMe/TCP RTL design, every design module, and a reproducible source-line count.

**Architecture:** Add a self-checking documentation test before writing the document. The document will derive all behavior from the current Verilog-2001 source, organize the explanation from system data flow down to module internals, and report physical source lines by language/tool category while excluding Markdown, PDFs, and generated artifacts.

**Tech Stack:** Markdown, Mermaid, Verilog-2001, SystemVerilog, Python/pytest, PowerShell, Icarus Verilog.

---

### Task 1: Add a failing completeness and line-count test

**Files:**

- Modify: `zte_nvmetcp_offload/03_tb/python/test_docs.py`
- Test: `zte_nvmetcp_offload/03_tb/python/test_docs.py`

- [ ] **Step 1: Add the document coverage test**

Append this test and its `re` import:

```python
import re


def test_rtl_detailed_design_covers_modules_topics_and_line_counts():
    path = ROOT / "01_docs" / "rtl_detailed_design.md"
    assert path.is_file()
    text = path.read_text(encoding="utf-8")

    modules = [
        "nvmetcp_defs.vh",
        "nvmetcp_gray_sync.v",
        "nvmetcp_async_buffer_bank.v",
        "nvmetcp_rr_scheduler.v",
        "nvmetcp_pdu_reader.v",
        "nvmetcp_parser.v",
        "nvmetcp_response_gen.v",
        "nvmetcp_monitor.v",
        "nvmetcp_offload_top.v",
    ]
    for module in modules:
        assert module in text

    topics = [
        "Verilog-2001",
        "action_meta[199:0]",
        "ready/valid",
        "Gray Code",
        "51.603 Gb/s",
        "NOT_RUN_NO_VIVADO",
        "ICReq",
        "非法 PDU",
        "多连接轮询",
    ]
    for topic in topics:
        assert topic in text

    categories = {
        "RTL 设计": ["02_rtl/**/*.v", "02_rtl/**/*.vh"],
        "SystemVerilog 验证": ["03_tb/sv/*.sv"],
        "Python 工具与测试": ["03_tb/python/*.py"],
        "Vivado Tcl": ["04_vivado/*.tcl"],
        "PowerShell 脚本": ["06_scripts/*.ps1"],
        "XDC 约束": ["05_constraints/*.xdc"],
    }
    total_files = 0
    total_lines = 0
    for label, patterns in categories.items():
        files = sorted({
            source
            for pattern in patterns
            for source in ROOT.glob(pattern)
            if source.is_file()
        })
        lines = sum(len(source.read_text(encoding="utf-8").splitlines())
                    for source in files)
        total_files += len(files)
        total_lines += lines
        row = rf"\|\s*{re.escape(label)}\s*\|\s*{len(files)}\s*\|\s*{lines:,}\s*\|"
        assert re.search(row, text)

    total_row = rf"\|\s*源码合计\s*\|\s*{total_files}\s*\|\s*{total_lines:,}\s*\|"
    assert re.search(total_row, text)

    for non_goal in ["TCP/IP", "TLS", "DDR", "NVMe 命令执行"]:
        assert f"{non_goal}：未实现" in text
```

- [ ] **Step 2: Run the test and verify RED**

Run:

```powershell
pytest .\zte_nvmetcp_offload\03_tb\python\test_docs.py::test_rtl_detailed_design_covers_modules_topics_and_line_counts -q
```

Expected: FAIL at `assert path.is_file()` because `01_docs/rtl_detailed_design.md` does not yet exist.

- [ ] **Step 3: Commit only after the document makes the test green**

Do not commit a red state. Keep this test staged locally until Task 2 completes.

### Task 2: Write the complete RTL engineering explanation

**Files:**

- Create: `zte_nvmetcp_offload/01_docs/rtl_detailed_design.md`
- Modify: `zte_nvmetcp_offload/03_tb/python/test_docs.py`

- [ ] **Step 1: Recompute final physical line counts**

Count the post-test source tree using these exact categories:

```powershell
$root = Resolve-Path zte_nvmetcp_offload
$groups = [ordered]@{
  'RTL 设计' = @('02_rtl/**/*.v', '02_rtl/**/*.vh')
  'SystemVerilog 验证' = @('03_tb/sv/*.sv')
  'Python 工具与测试' = @('03_tb/python/*.py')
  'Vivado Tcl' = @('04_vivado/*.tcl')
  'PowerShell 脚本' = @('06_scripts/*.ps1')
  'XDC 约束' = @('05_constraints/*.xdc')
}
```

For each category, deduplicate files, sum `Get-Content` line counts, and record the number of files and physical lines. The RTL subtotal must remain 9 files and 1,388 lines. The overall total is calculated after the new Python test is present.

- [ ] **Step 2: Create the document with the exact top-level structure**

Create `zte_nvmetcp_offload/01_docs/rtl_detailed_design.md` with these headings:

```markdown
# NVMe/TCP 硬卸载 RTL 详细设计说明

## 1. 文档目的与设计边界
## 2. 工程基线与源码统计
## 3. 总体架构
## 4. 时钟、复位与 CDC
## 5. 流控、包所有权与背压
## 6. 协议字段与 action_meta
## 7. RTL 模块详细设计
### 7.1 nvmetcp_defs.vh
### 7.2 nvmetcp_gray_sync.v
### 7.3 nvmetcp_async_buffer_bank.v
### 7.4 nvmetcp_rr_scheduler.v
### 7.5 nvmetcp_pdu_reader.v
### 7.6 nvmetcp_parser.v
### 7.7 nvmetcp_response_gen.v
### 7.8 nvmetcp_monitor.v
### 7.9 nvmetcp_offload_top.v
## 8. 端到端工作示例
### 8.1 合法 ICReq
### 8.2 非法 PDU
### 8.3 多连接轮询
## 9. 吞吐、综合与时序分析
## 10. 验证结构与运行方法
## 11. 集成约束、已知边界与扩展方向
```

- [ ] **Step 3: Populate the system-level sections**

The system sections must include:

- A Mermaid flowchart from asynchronous write input through the buffer, scheduler, reader, parser, action/payload outputs, response generator, and monitor.
- A two-clock-domain table that locates every state element in `wr_clk` or `core_clk`.
- The atomic commit rule: `wr_work_bin` advances per accepted beat, while `wr_commit_bin` advances only on an accepted `wr_last`.
- Gray conversion, two-stage synchronization, and the rule that no multi-bit binary pointer crosses directly.
- Packet-granular round-robin ownership from grant acceptance through `grant_done`.
- The ready/valid stability rule and every backpressure path.
- The full 200-bit metadata table from `[199:197] conn_id` through `[0] error`.
- The 9 supported PDU types, fixed HLEN values, extracted fields, and action encodings.

- [ ] **Step 4: Populate every module section**

For each of the nine module/file sections, include:

- purpose and dependencies;
- parameter/port table;
- internal registers, wires, memories, or macros;
- combinational and sequential behavior;
- complete state transition table when a state machine exists;
- reset, backpressure, error, CDC, synthesis, and timing notes;
- the corresponding SystemVerilog testbench.

The parser section must explain all validation order and FES/FEI mappings visible in the code. The monitor section must include the entire address map. The top section must explain frame-error priority and the joint acceptance of the external action and internal response request.

- [ ] **Step 5: Add examples, performance, verification, and non-goals**

Document:

- legal ICReq through the two-beat ICResp;
- illegal-header termination flow and response-direction selection;
- simultaneous pending connections and `last_grant+1` search;
- 512 bit × 200 MHz = 102.4 Gb/s raw width-rate product;
- measured 51.603 Gb/s and maximum two-cycle accepted-beat gap;
- Vivado status `NOT_RUN_NO_VIVADO`;
- exact regression and Vivado commands;
- explicit statements `TCP/IP：未实现`, `TLS：未实现`, `DDR：未实现`, and `NVMe 命令执行：未实现`.

- [ ] **Step 6: Run the document test and verify GREEN**

Run:

```powershell
pytest .\zte_nvmetcp_offload\03_tb\python\test_docs.py::test_rtl_detailed_design_covers_modules_topics_and_line_counts -q
```

Expected: PASS.

- [ ] **Step 7: Run all Python tests**

Run:

```powershell
pytest .\zte_nvmetcp_offload\03_tb\python -q
```

Expected: 44 tests pass.

- [ ] **Step 8: Commit the document and test**

```powershell
git add zte_nvmetcp_offload/01_docs/rtl_detailed_design.md zte_nvmetcp_offload/03_tb/python/test_docs.py
git commit -m "docs: explain complete RTL design"
```

### Task 3: Verify regression and delivery inclusion

**Files:**

- Verify: `zte_nvmetcp_offload/01_docs/rtl_detailed_design.md`
- Verify: `zte_nvmetcp_offload/08_delivery/zte_nvmetcp_offload_delivery.zip`

- [ ] **Step 1: Run the complete local regression**

Run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\zte_nvmetcp_offload\06_scripts\run_regression.ps1
```

Expected: 44 Python tests, `VERILOG_2001_COMPILE_PASS`, nine `TB_PASS` lines, `MEASURED_THROUGHPUT_GBPS 51.603`, and `REGRESSION_PASS`.

- [ ] **Step 2: Rebuild the delivery archive**

Run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\zte_nvmetcp_offload\06_scripts\package_delivery.ps1
```

Expected: `DELIVERY_PACKAGE=...zte_nvmetcp_offload_delivery.zip`.

- [ ] **Step 3: Verify the new document is packaged**

Open the ZIP entry list and require `01_docs/rtl_detailed_design.md`. Also require eight `.v` files, one `.vh`, and zero `.sv` files under `02_rtl/`.

- [ ] **Step 4: Run final repository checks**

Run:

```powershell
git diff --check
git status --short
```

Expected: no tracked modifications after commits; the original root-level course PDF may remain untracked and must not be added.
