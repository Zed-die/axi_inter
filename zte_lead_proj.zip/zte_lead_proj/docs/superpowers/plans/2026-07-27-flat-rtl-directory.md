# Flat RTL Directory Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Move all nine Verilog-2001 design files directly under `zte_nvmetcp_offload/02_rtl/`, remove obsolete category directories, and update every build, test and documentation path.

**Architecture:** The RTL module boundaries and behavior remain unchanged; only filesystem paths and path consumers change. A Python structure assertion first locks the required flat layout, then Git renames preserve file history while scripts, includes, Vivado Tcl, traceability and documentation are updated to the new paths.

**Tech Stack:** Verilog-2001, SystemVerilog verification, Python/pytest, PowerShell, Vivado Tcl, Icarus Verilog, Git

---

### Task 1: Lock the flat RTL layout with a failing test

**Files:**
- Modify: `zte_nvmetcp_offload/03_tb/python/test_verilog2001_rtl.py`
- Test: `zte_nvmetcp_offload/03_tb/python/test_verilog2001_rtl.py`

- [ ] **Step 1: Replace the existing tree-shape assertion**

Replace `test_entire_rtl_tree_is_verilog2001` with:

```python
def test_entire_rtl_tree_is_flat_verilog2001():
    expected = [
        "nvmetcp_async_buffer_bank.v",
        "nvmetcp_defs.vh",
        "nvmetcp_gray_sync.v",
        "nvmetcp_monitor.v",
        "nvmetcp_offload_top.v",
        "nvmetcp_parser.v",
        "nvmetcp_pdu_reader.v",
        "nvmetcp_response_gen.v",
        "nvmetcp_rr_scheduler.v",
    ]
    files = sorted(path.name for path in RTL.iterdir() if path.is_file())
    assert files == expected
    assert not [path for path in RTL.iterdir() if path.is_dir()]
    verilog_sources = sorted(RTL.glob("*.v"))
    sources = verilog_sources + sorted(RTL.glob("*.vh"))
    assert_verilog2001(*sources)
```

- [ ] **Step 2: Run the test and verify RED**

Run:

```powershell
pytest .\zte_nvmetcp_offload\03_tb\python\test_verilog2001_rtl.py::test_entire_rtl_tree_is_flat_verilog2001 -q
```

Expected: FAIL because `.gitkeep` is present and the design files are still inside category directories.

### Task 2: Move the nine design files and update compiler paths

**Files:**
- Move: `zte_nvmetcp_offload/02_rtl/common/nvmetcp_defs.vh` → `zte_nvmetcp_offload/02_rtl/nvmetcp_defs.vh`
- Move: `zte_nvmetcp_offload/02_rtl/cdc/nvmetcp_gray_sync.v` → `zte_nvmetcp_offload/02_rtl/nvmetcp_gray_sync.v`
- Move: `zte_nvmetcp_offload/02_rtl/buffer/nvmetcp_async_buffer_bank.v` → `zte_nvmetcp_offload/02_rtl/nvmetcp_async_buffer_bank.v`
- Move: `zte_nvmetcp_offload/02_rtl/scheduler/nvmetcp_rr_scheduler.v` → `zte_nvmetcp_offload/02_rtl/nvmetcp_rr_scheduler.v`
- Move: `zte_nvmetcp_offload/02_rtl/parser/nvmetcp_pdu_reader.v` → `zte_nvmetcp_offload/02_rtl/nvmetcp_pdu_reader.v`
- Move: `zte_nvmetcp_offload/02_rtl/parser/nvmetcp_parser.v` → `zte_nvmetcp_offload/02_rtl/nvmetcp_parser.v`
- Move: `zte_nvmetcp_offload/02_rtl/response/nvmetcp_response_gen.v` → `zte_nvmetcp_offload/02_rtl/nvmetcp_response_gen.v`
- Move: `zte_nvmetcp_offload/02_rtl/monitor/nvmetcp_monitor.v` → `zte_nvmetcp_offload/02_rtl/nvmetcp_monitor.v`
- Move: `zte_nvmetcp_offload/02_rtl/top/nvmetcp_offload_top.v` → `zte_nvmetcp_offload/02_rtl/nvmetcp_offload_top.v`
- Delete: `zte_nvmetcp_offload/02_rtl/.gitkeep`
- Modify: `zte_nvmetcp_offload/03_tb/python/test_verilog2001_rtl.py`
- Modify: `zte_nvmetcp_offload/03_tb/sv/nvmetcp_pkg.sv`
- Modify: `zte_nvmetcp_offload/03_tb/sv/filelist.f`
- Modify: `zte_nvmetcp_offload/06_scripts/run_unit.ps1`
- Modify: `zte_nvmetcp_offload/04_vivado/create_project.tcl`
- Modify: `zte_nvmetcp_offload/04_vivado/run_synth.tcl`

- [ ] **Step 1: Move tracked design files with Git**

Run nine `git mv` commands using the exact source and destination paths above, then:

```powershell
git rm -- zte_nvmetcp_offload/02_rtl/.gitkeep
```

The eight now-empty category directories must no longer exist.

- [ ] **Step 2: Update the absolute header include**

Set the first line of these five consumers:

- `02_rtl/nvmetcp_offload_top.v`
- `02_rtl/nvmetcp_parser.v`
- `02_rtl/nvmetcp_monitor.v`
- `02_rtl/nvmetcp_response_gen.v`
- `03_tb/sv/nvmetcp_pkg.sv`

to exactly:

```verilog
`include "//?/F:/codex_proj/zte_lead_proj/zte_nvmetcp_offload/02_rtl/nvmetcp_defs.vh"
```

- [ ] **Step 3: Update Python source paths**

In `test_verilog2001_rtl.py`:

```python
COMMON = RTL
```

Replace the old header-directory test with:

```python
def test_common_rtl_is_header_only_verilog2001():
    header = RTL / "nvmetcp_defs.vh"
    assert header.is_file()
    assert_verilog2001(header)
```

Read metadata definitions from `RTL / "nvmetcp_defs.vh"`. Point all module paths directly below `RTL`, for example:

```python
RTL / "nvmetcp_gray_sync.v"
RTL / "nvmetcp_async_buffer_bank.v"
RTL / "nvmetcp_rr_scheduler.v"
RTL / "nvmetcp_pdu_reader.v"
RTL / "nvmetcp_parser.v"
RTL / "nvmetcp_response_gen.v"
RTL / "nvmetcp_monitor.v"
RTL / "nvmetcp_offload_top.v"
```

Update the approved include suffix to `02_rtl/nvmetcp_defs.vh"` and use `RTL.glob("*.v")`/`RTL.glob("*.vh")` for whole-tree compilation.

- [ ] **Step 4: Update filelist and PowerShell simulation paths**

`03_tb/sv/filelist.f` must list:

```text
zte_nvmetcp_offload/03_tb/sv/nvmetcp_pkg.sv
zte_nvmetcp_offload/02_rtl/nvmetcp_gray_sync.v
zte_nvmetcp_offload/02_rtl/nvmetcp_async_buffer_bank.v
zte_nvmetcp_offload/02_rtl/nvmetcp_rr_scheduler.v
zte_nvmetcp_offload/02_rtl/nvmetcp_pdu_reader.v
zte_nvmetcp_offload/02_rtl/nvmetcp_parser.v
zte_nvmetcp_offload/02_rtl/nvmetcp_response_gen.v
zte_nvmetcp_offload/02_rtl/nvmetcp_monitor.v
zte_nvmetcp_offload/02_rtl/nvmetcp_offload_top.v
```

In `run_unit.ps1`, set:

```powershell
$CommonDir = Join-Path $ProjectRoot '02_rtl'
```

Replace every category path with its direct `02_rtl/<filename>` path.

- [ ] **Step 5: Flatten both Vivado source lists**

In both Tcl files, use:

```tcl
set include_dir [file join $project_root 02_rtl]
set rtl_files [glob -nocomplain [file join $project_root 02_rtl *.v]]
```

Keep header loading, `include_dirs`, top selection, constraints and report behavior unchanged.

- [ ] **Step 6: Run focused checks and verify GREEN**

Run:

```powershell
pytest .\zte_nvmetcp_offload\03_tb\python\test_verilog2001_rtl.py -q
powershell -NoProfile -ExecutionPolicy Bypass -File .\zte_nvmetcp_offload\06_scripts\run_unit.ps1 -SkipPython
```

Expected: all Verilog-2001 path/compile tests pass; 9 testbenches pass; output includes `VERILOG_2001_COMPILE_PASS`, `MEASURED_THROUGHPUT_GBPS 51.603`, and `UNIT_REGRESSION_PASS`.

- [ ] **Step 7: Commit the structural and build-path change**

```powershell
git add -A -- zte_nvmetcp_offload/02_rtl zte_nvmetcp_offload/03_tb/python/test_verilog2001_rtl.py zte_nvmetcp_offload/03_tb/sv/nvmetcp_pkg.sv zte_nvmetcp_offload/03_tb/sv/filelist.f zte_nvmetcp_offload/06_scripts/run_unit.ps1 zte_nvmetcp_offload/04_vivado/create_project.tcl zte_nvmetcp_offload/04_vivado/run_synth.tcl
git commit -m "refactor: flatten RTL source directory"
```

### Task 3: Update traceability and detailed design paths

**Files:**
- Modify: `zte_nvmetcp_offload/00_requirements/requirements_traceability.md`
- Modify: `zte_nvmetcp_offload/01_docs/rtl_detailed_design.md`
- Test: `zte_nvmetcp_offload/03_tb/python/test_docs.py`

- [ ] **Step 1: Update every active project path**

Replace category paths in `requirements_traceability.md` and the detailed design per-file statistics table with direct paths:

```text
02_rtl/nvmetcp_defs.vh
02_rtl/nvmetcp_gray_sync.v
02_rtl/nvmetcp_async_buffer_bank.v
02_rtl/nvmetcp_rr_scheduler.v
02_rtl/nvmetcp_pdu_reader.v
02_rtl/nvmetcp_parser.v
02_rtl/nvmetcp_response_gen.v
02_rtl/nvmetcp_monitor.v
02_rtl/nvmetcp_offload_top.v
```

Update the source-statistics table to the live physical line counts after the Python and Tcl edits.

- [ ] **Step 2: Prove no active path is stale**

Run:

```powershell
rg -n '02_rtl/(buffer|cdc|common|monitor|parser|response|scheduler|top)' .\zte_nvmetcp_offload
```

Expected: no matches.

- [ ] **Step 3: Run documentation and script tests**

Run:

```powershell
pytest .\zte_nvmetcp_offload\03_tb\python\test_docs.py .\zte_nvmetcp_offload\03_tb\python\test_scripts.py -q
```

Expected: all selected tests pass.

- [ ] **Step 4: Commit documentation updates**

```powershell
git add -- zte_nvmetcp_offload/00_requirements/requirements_traceability.md zte_nvmetcp_offload/01_docs/rtl_detailed_design.md
git commit -m "docs: update flattened RTL paths"
```

### Task 4: Run complete acceptance and package verification

**Files:**
- Verify: `zte_nvmetcp_offload/08_delivery/zte_nvmetcp_offload_delivery.zip`

- [ ] **Step 1: Run the full regression**

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\zte_nvmetcp_offload\06_scripts\run_regression.ps1
```

Expected: all Python tests and 9 testbenches pass, strict Verilog-2001 compile passes, measured throughput is at least 40 Gb/s, and `REGRESSION_PASS` is printed.

- [ ] **Step 2: Rebuild the delivery ZIP**

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\zte_nvmetcp_offload\06_scripts\package_delivery.ps1
```

Expected: `DELIVERY_PACKAGE=...zte_nvmetcp_offload_delivery.zip`.

- [ ] **Step 3: Inspect the ZIP layout**

Normalize ZIP entry separators and assert:

- exactly 8 entries match `^02_rtl/[^/]+\.v$`;
- exactly 1 entry matches `^02_rtl/nvmetcp_defs\.vh$`;
- no entry matches `^02_rtl/[^/]+/`;
- no entry matches `^02_rtl/.+\.sv$`.

- [ ] **Step 4: Check final branch state**

```powershell
git diff --check
git status --short
```

Expected: no uncommitted tracked changes.

### Task 5: Preserve user work during local integration

**Files:**
- Preserve old working content: `zte_nvmetcp_offload/02_rtl/cdc/nvmetcp_gray_sync.v`
- Preserve old working content: `zte_nvmetcp_offload/02_rtl/parser/nvmetcp_parser.v`
- Restore under new paths: `zte_nvmetcp_offload/02_rtl/nvmetcp_gray_sync.v`
- Restore under new paths: `zte_nvmetcp_offload/02_rtl/nvmetcp_parser.v`

- [ ] **Step 1: Back up and hash the two user-modified files**

Copy both files into a verified directory below `.worktrees/user-preserve-flat-rtl/` and record SHA-256 hashes. Do not include the untracked source PDF.

- [ ] **Step 2: Restore only those two old paths to committed `HEAD`**

After backup verification, restore the two tracked worktree paths so the clean feature branch can be fast-forward merged. Leave all unrelated untracked files untouched.

- [ ] **Step 3: Merge the verified feature branch locally**

Fast-forward `master` to `refactor/flat-rtl-directory`. Do not push.

- [ ] **Step 4: Restore user content under the new flat paths**

Copy the backed-up files to `02_rtl/nvmetcp_gray_sync.v` and `02_rtl/nvmetcp_parser.v`. Verify their SHA-256 hashes exactly match the pre-merge hashes.

- [ ] **Step 5: Remove the verified temporary backup**

After hash equality is proven, verify the resolved backup directory is below `.worktrees/`, remove it, then report the two restored files as user-owned uncommitted modifications.
