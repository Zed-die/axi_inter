# Absolute Verilog Include Path Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace all five relative `nvmetcp_defs.vh` includes with the approved absolute Windows-workspace path and prove that the RTL and verification suite still compile and pass.

**Architecture:** This is a compile-time source lookup change only. A Python regression test will lock the exact include string in the four metadata-consuming RTL modules and the SystemVerilog verification package; the existing Icarus and Vivado include-directory configuration remains unchanged.

**Tech Stack:** Verilog-2001, SystemVerilog, Python/pytest, Icarus Verilog, PowerShell

---

### Task 1: Add an absolute-include regression test

**Files:**
- Modify: `zte_nvmetcp_offload/03_tb/python/test_verilog2001_rtl.py`
- Test: `zte_nvmetcp_offload/03_tb/python/test_verilog2001_rtl.py`

- [ ] **Step 1: Write the failing test**

Add the following test after `test_metadata_layout_is_stable`:

```python
def test_metadata_consumers_use_approved_absolute_include():
    approved = (
        '`include "//?/F:/codex_proj/zte_lead_proj/zte_nvmetcp_offload/'
        '02_rtl/common/nvmetcp_defs.vh"'
    )
    consumers = [
        RTL / "top" / "nvmetcp_offload_top.v",
        RTL / "parser" / "nvmetcp_parser.v",
        RTL / "monitor" / "nvmetcp_monitor.v",
        RTL / "response" / "nvmetcp_response_gen.v",
        ROOT / "03_tb" / "sv" / "nvmetcp_pkg.sv",
    ]
    for consumer in consumers:
        first_line = consumer.read_text(encoding="utf-8").splitlines()[0]
        assert first_line == approved, consumer
```

- [ ] **Step 2: Run the test to verify it fails**

Run:

```powershell
pytest .\zte_nvmetcp_offload\03_tb\python\test_verilog2001_rtl.py::test_metadata_consumers_use_approved_absolute_include -q
```

Expected: FAIL because the current first line is `` `include "nvmetcp_defs.vh" ``.

### Task 2: Replace all five include directives

**Files:**
- Modify: `zte_nvmetcp_offload/02_rtl/top/nvmetcp_offload_top.v:1`
- Modify: `zte_nvmetcp_offload/02_rtl/parser/nvmetcp_parser.v:1`
- Modify: `zte_nvmetcp_offload/02_rtl/monitor/nvmetcp_monitor.v:1`
- Modify: `zte_nvmetcp_offload/02_rtl/response/nvmetcp_response_gen.v:1`
- Modify: `zte_nvmetcp_offload/03_tb/sv/nvmetcp_pkg.sv:1`
- Test: `zte_nvmetcp_offload/03_tb/python/test_verilog2001_rtl.py`

- [ ] **Step 1: Apply the minimal source change**

Replace the first line of every listed consumer with exactly:

```verilog
`include "//?/F:/codex_proj/zte_lead_proj/zte_nvmetcp_offload/02_rtl/common/nvmetcp_defs.vh"
```

Do not modify any module logic, interfaces, scripts or include-directory options.

- [ ] **Step 2: Run the targeted test to verify it passes**

Run:

```powershell
pytest .\zte_nvmetcp_offload\03_tb\python\test_verilog2001_rtl.py::test_metadata_consumers_use_approved_absolute_include -q
```

Expected: `1 passed`.

- [ ] **Step 3: Compile all RTL as strict Verilog-2001**

Run:

```powershell
pytest .\zte_nvmetcp_offload\03_tb\python\test_verilog2001_rtl.py -q
```

Expected: all tests pass, including `test_top_compiles_as_verilog2001`.

- [ ] **Step 4: Commit the tested source change**

```powershell
git add -- zte_nvmetcp_offload/03_tb/python/test_verilog2001_rtl.py zte_nvmetcp_offload/02_rtl/top/nvmetcp_offload_top.v zte_nvmetcp_offload/02_rtl/parser/nvmetcp_parser.v zte_nvmetcp_offload/02_rtl/monitor/nvmetcp_monitor.v zte_nvmetcp_offload/02_rtl/response/nvmetcp_response_gen.v zte_nvmetcp_offload/03_tb/sv/nvmetcp_pkg.sv
git commit -m "build: use absolute Verilog include path"
```

### Task 3: Run acceptance regression and rebuild delivery

**Files:**
- Verify: `zte_nvmetcp_offload/07_reports/generated/simulation/regression_summary.txt`
- Verify: `zte_nvmetcp_offload/08_delivery/zte_nvmetcp_offload_delivery.zip`

- [ ] **Step 1: Scan for stale relative includes**

Run:

```powershell
rg -n -F '`include "nvmetcp_defs.vh"' .\zte_nvmetcp_offload\02_rtl .\zte_nvmetcp_offload\03_tb\sv
```

Expected: no matches.

- [ ] **Step 2: Run the complete regression**

Run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\zte_nvmetcp_offload\06_scripts\run_regression.ps1
```

Expected: Python tests pass, 9 testbenches print `TB_PASS`, strict compilation prints `VERILOG_2001_COMPILE_PASS`, throughput is at least 40 Gb/s, and the script prints `REGRESSION_PASS`.

- [ ] **Step 3: Rebuild the delivery ZIP**

Run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\zte_nvmetcp_offload\06_scripts\package_delivery.ps1
```

Expected: exit code 0 and a `DELIVERY_PACKAGE=...zte_nvmetcp_offload_delivery.zip` result.

- [ ] **Step 4: Check repository cleanliness**

Run:

```powershell
git diff --check
git status --short
```

Expected: no uncommitted tracked source changes.
