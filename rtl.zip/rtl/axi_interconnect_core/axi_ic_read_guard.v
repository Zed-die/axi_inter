`resetall
`timescale 1ns / 1ps
`default_nettype none

/*
 * AXI read ingress guard
 *
 * Legal reads pass through untouched. Unsupported or invalid reads are
 * rewritten to DECERR_ADDR so the downstream fabric can use its normal
 * decode-error path.
 */
module axi_ic_read_guard #
(
    parameter DATA_WIDTH = 32,
    parameter ADDR_WIDTH = 32,
    parameter ID_WIDTH = 8,
    parameter ARUSER_ENABLE = 0,
    parameter ARUSER_WIDTH = 1,
    parameter RUSER_ENABLE = 0,
    parameter RUSER_WIDTH = 1,
    parameter [ADDR_WIDTH-1:0] DECERR_ADDR = {ADDR_WIDTH{1'b1}}
)
(
    input  wire                     clk,
    input  wire                     rst,
    input  wire                     cfg_master_enable,
    input  wire                     cfg_allow_reads,
    input  wire [ID_WIDTH-1:0]      s_axi_arid,
    input  wire [ADDR_WIDTH-1:0]    s_axi_araddr,
    input  wire [7:0]               s_axi_arlen,
    input  wire [2:0]               s_axi_arsize,
    input  wire [1:0]               s_axi_arburst,
    input  wire                     s_axi_arlock,
    input  wire [3:0]               s_axi_arcache,
    input  wire [2:0]               s_axi_arprot,
    input  wire [3:0]               s_axi_arqos,
    input  wire [ARUSER_WIDTH-1:0]  s_axi_aruser,
    input  wire                     s_axi_arvalid,
    output wire                     s_axi_arready,
    output wire [ID_WIDTH-1:0]      s_axi_rid,
    output wire [DATA_WIDTH-1:0]    s_axi_rdata,
    output wire [1:0]               s_axi_rresp,
    output wire                     s_axi_rlast,
    output wire [RUSER_WIDTH-1:0]   s_axi_ruser,
    output wire                     s_axi_rvalid,
    input  wire                     s_axi_rready,

    output wire [ID_WIDTH-1:0]      m_axi_arid,
    output wire [ADDR_WIDTH-1:0]    m_axi_araddr,
    output wire [7:0]               m_axi_arlen,
    output wire [2:0]               m_axi_arsize,
    output wire [1:0]               m_axi_arburst,
    output wire                     m_axi_arlock,
    output wire [3:0]               m_axi_arcache,
    output wire [2:0]               m_axi_arprot,
    output wire [3:0]               m_axi_arqos,
    output wire [ARUSER_WIDTH-1:0]  m_axi_aruser,
    output wire                     m_axi_arvalid,
    input  wire                     m_axi_arready,
    input  wire [ID_WIDTH-1:0]      m_axi_rid,
    input  wire [DATA_WIDTH-1:0]    m_axi_rdata,
    input  wire [1:0]               m_axi_rresp,
    input  wire                     m_axi_rlast,
    input  wire [RUSER_WIDTH-1:0]   m_axi_ruser,
    input  wire                     m_axi_rvalid,
    output wire                     m_axi_rready,

    output wire                     stat_read_req_pulse,
    output wire                     stat_read_decerr_pulse,
    output wire                     fault_valid,
    output wire [7:0]               fault_code,
    output wire [ADDR_WIDTH-1:0]    fault_addr,
    output wire [ID_WIDTH-1:0]      fault_id
);

wire burst_valid;
wire unused_crosses_4k;
wire unused_unsupported_burst;
wire [8:0] unused_beat_count;
wire [ADDR_WIDTH-1:0] unused_bytes_per_beat;
wire [ADDR_WIDTH-1:0] unused_burst_bytes;
wire [ADDR_WIDTH-1:0] unused_span_start;
wire [ADDR_WIDTH-1:0] unused_span_end;

axi_ic_burst_guard #(
    .ADDR_WIDTH(ADDR_WIDTH)
)
burst_guard_inst (
    .addr(s_axi_araddr),
    .len(s_axi_arlen),
    .size(s_axi_arsize),
    .burst(s_axi_arburst),
    .valid(burst_valid),
    .crosses_4k(unused_crosses_4k),
    .unsupported_burst(unused_unsupported_burst),
    .beat_count(unused_beat_count),
    .bytes_per_beat(unused_bytes_per_beat),
    .burst_bytes(unused_burst_bytes),
    .span_start(unused_span_start),
    .span_end(unused_span_end)
);

wire master_read_allowed = cfg_master_enable && cfg_allow_reads;
wire local_fault_active = !master_read_allowed || !burst_valid;
wire upstream_ar_handshake = s_axi_arvalid && s_axi_arready;

assign s_axi_arready = m_axi_arready;

assign m_axi_arid = s_axi_arid;
assign m_axi_araddr = local_fault_active ? DECERR_ADDR : s_axi_araddr;
assign m_axi_arlen = s_axi_arlen;
assign m_axi_arsize = s_axi_arsize;
assign m_axi_arburst = s_axi_arburst;
assign m_axi_arlock = s_axi_arlock;
assign m_axi_arcache = s_axi_arcache;
assign m_axi_arprot = s_axi_arprot;
assign m_axi_arqos = s_axi_arqos;
assign m_axi_aruser = ARUSER_ENABLE ? s_axi_aruser : {ARUSER_WIDTH{1'b0}};
assign m_axi_arvalid = s_axi_arvalid;

assign s_axi_rid = m_axi_rid;
assign s_axi_rdata = m_axi_rdata;
assign s_axi_rresp = m_axi_rresp;
assign s_axi_rlast = m_axi_rlast;
assign s_axi_ruser = RUSER_ENABLE ? m_axi_ruser : {RUSER_WIDTH{1'b0}};
assign s_axi_rvalid = m_axi_rvalid;
assign m_axi_rready = s_axi_rready;

assign stat_read_req_pulse = upstream_ar_handshake && master_read_allowed && !local_fault_active;
assign stat_read_decerr_pulse = upstream_ar_handshake && local_fault_active;
assign fault_valid = upstream_ar_handshake && local_fault_active;
assign fault_code = master_read_allowed ? 8'h03 : 8'h04;
assign fault_addr = s_axi_araddr;
assign fault_id = s_axi_arid;

endmodule

`resetall
