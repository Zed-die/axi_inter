`resetall
`timescale 1ns / 1ps
`default_nettype none

/*
 * AXI burst legality and span checker
 */
module axi_ic_burst_guard #
(
    parameter ADDR_WIDTH = 32
)
(
    input  wire [ADDR_WIDTH-1:0] addr,
    input  wire [7:0]            len,
    input  wire [2:0]            size,
    input  wire [1:0]            burst,

    output wire                  valid,
    output wire                  crosses_4k,
    output wire                  unsupported_burst,
    output wire [8:0]            beat_count,
    output wire [ADDR_WIDTH-1:0] bytes_per_beat,
    output wire [ADDR_WIDTH-1:0] burst_bytes,
    output wire [ADDR_WIDTH-1:0] span_start,
    output wire [ADDR_WIDTH-1:0] span_end
);

wire is_fixed = burst == 2'b00;
wire is_incr  = burst == 2'b01;
wire is_wrap  = burst == 2'b10;
wire wrap_len_ok = len == 8'd1 || len == 8'd3 || len == 8'd7 || len == 8'd15;  //合法的WRAP burst长度
wire use_wrap_window = is_wrap && wrap_len_ok;

assign unsupported_burst = !(is_fixed || is_incr || is_wrap);

assign beat_count = {1'b0, len} + 9'd1;
assign bytes_per_beat = {{(ADDR_WIDTH-1){1'b0}}, 1'b1} << size;
assign burst_bytes = bytes_per_beat * beat_count;

wire [ADDR_WIDTH-1:0] burst_end = addr + burst_bytes - {{(ADDR_WIDTH-1){1'b0}}, 1'b1};
wire [ADDR_WIDTH-1:0] wrap_mask = burst_bytes - {{(ADDR_WIDTH-1){1'b0}}, 1'b1};
wire [ADDR_WIDTH-1:0] wrap_base = addr & ~wrap_mask;
wire [ADDR_WIDTH-1:0] wrap_end = wrap_base + burst_bytes - {{(ADDR_WIDTH-1){1'b0}}, 1'b1};

assign span_start = use_wrap_window ? wrap_base : addr;
assign span_end = use_wrap_window ? wrap_end : burst_end;

assign crosses_4k = span_start[ADDR_WIDTH-1:12] != span_end[ADDR_WIDTH-1:12];

assign valid = !unsupported_burst && (!is_wrap || wrap_len_ok) && !crosses_4k;

endmodule

`resetall
