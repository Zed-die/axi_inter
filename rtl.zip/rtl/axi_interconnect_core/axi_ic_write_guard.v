`resetall
`timescale 1ns / 1ps
`default_nettype none

/*
 * AXI write ingress guard
 *
 * Legal writes pass through untouched. Illegal writes are handled locally so
 * the master still sees W channel consumption followed by a DECERR only after
 * the terminating WLAST beat.
 */
module axi_ic_write_guard #
(
    parameter DATA_WIDTH = 32,
    parameter ADDR_WIDTH = 32,
    parameter STRB_WIDTH = (DATA_WIDTH/8),
    parameter ID_WIDTH = 8,
    parameter AWUSER_ENABLE = 0,
    parameter AWUSER_WIDTH = 1,
    parameter WUSER_ENABLE = 0,
    parameter WUSER_WIDTH = 1,
    parameter BUSER_ENABLE = 0,
    parameter BUSER_WIDTH = 1,
    parameter OUTSTANDING_WIDTH = 8,
    parameter [ADDR_WIDTH-1:0] DECERR_ADDR = {ADDR_WIDTH{1'b1}}
)
(
    input  wire                     clk,
    input  wire                     rst,
    input  wire                     cfg_master_enable,
    input  wire                     cfg_allow_writes,
    input  wire [ID_WIDTH-1:0]      s_axi_awid,
    input  wire [ADDR_WIDTH-1:0]    s_axi_awaddr,
    input  wire [7:0]               s_axi_awlen,
    input  wire [2:0]               s_axi_awsize,
    input  wire [1:0]               s_axi_awburst,
    input  wire                     s_axi_awlock,
    input  wire [3:0]               s_axi_awcache,
    input  wire [2:0]               s_axi_awprot,
    input  wire [3:0]               s_axi_awqos,
    input  wire [AWUSER_WIDTH-1:0]  s_axi_awuser,
    input  wire                     s_axi_awvalid,
    output wire                     s_axi_awready,
    input  wire [DATA_WIDTH-1:0]    s_axi_wdata,
    input  wire [STRB_WIDTH-1:0]    s_axi_wstrb,
    input  wire                     s_axi_wlast,
    input  wire [WUSER_WIDTH-1:0]   s_axi_wuser,
    input  wire                     s_axi_wvalid,
    output wire                     s_axi_wready,
    output wire [ID_WIDTH-1:0]      s_axi_bid,
    output wire [1:0]               s_axi_bresp,
    output wire [BUSER_WIDTH-1:0]   s_axi_buser,
    output wire                     s_axi_bvalid,
    input  wire                     s_axi_bready,

    output wire [ID_WIDTH-1:0]      m_axi_awid,
    output wire [ADDR_WIDTH-1:0]    m_axi_awaddr,
    output wire [7:0]               m_axi_awlen,
    output wire [2:0]               m_axi_awsize,
    output wire [1:0]               m_axi_awburst,
    output wire                     m_axi_awlock,
    output wire [3:0]               m_axi_awcache,
    output wire [2:0]               m_axi_awprot,
    output wire [3:0]               m_axi_awqos,
    output wire [AWUSER_WIDTH-1:0]  m_axi_awuser,
    output wire                     m_axi_awvalid,
    input  wire                     m_axi_awready,
    output wire [DATA_WIDTH-1:0]    m_axi_wdata,
    output wire [STRB_WIDTH-1:0]    m_axi_wstrb,
    output wire                     m_axi_wlast,
    output wire [WUSER_WIDTH-1:0]   m_axi_wuser,
    output wire                     m_axi_wvalid,
    input  wire                     m_axi_wready,
    input  wire [ID_WIDTH-1:0]      m_axi_bid,
    input  wire [1:0]               m_axi_bresp,
    input  wire [BUSER_WIDTH-1:0]   m_axi_buser,
    input  wire                     m_axi_bvalid,
    output wire                     m_axi_bready,

    output wire                     stat_write_req_pulse,
    output wire                     stat_write_decerr_pulse,
    output wire                     fault_valid,
    output wire [7:0]               fault_code,
    output wire [ADDR_WIDTH-1:0]    fault_addr,
    output wire [ID_WIDTH-1:0]      fault_id
);

wire burst_valid;
wire unused_crosses_4k;
wire unused_unsupported_burst;
wire [8:0] unused_beat_count;
wire [ADDR_WIDTH-1:0] unused_bytes_per_beat;
wire [ADDR_WIDTH-1:0] unused_burst_bytes;
wire [ADDR_WIDTH-1:0] unused_span_start;
wire [ADDR_WIDTH-1:0] unused_span_end;

reg [OUTSTANDING_WIDTH-1:0] pass_write_count_reg = {OUTSTANDING_WIDTH{1'b0}};
reg                         local_write_active_reg = 1'b0;
reg                         local_bvalid_reg = 1'b0;
reg [ID_WIDTH-1:0]          local_bid_reg = {ID_WIDTH{1'b0}};

wire master_write_allowed = cfg_master_enable && cfg_allow_writes;
wire local_fault_active = !burst_valid || !master_write_allowed;
wire invalid_aw_blocked = pass_write_count_reg != {OUTSTANDING_WIDTH{1'b0}};
wire can_accept_local_aw = !local_write_active_reg && !local_bvalid_reg && !invalid_aw_blocked;
wire local_aw_handshake = s_axi_awvalid && local_fault_active && can_accept_local_aw;
wire pass_aw_active = s_axi_awvalid && !local_fault_active && !local_write_active_reg && !local_bvalid_reg;
wire pass_aw_handshake = pass_aw_active && m_axi_awready;
wire local_w_active = local_write_active_reg || local_aw_handshake;
wire local_w_handshake = local_w_active && s_axi_wvalid;
wire local_w_last_handshake = local_w_handshake && s_axi_wlast;
wire pass_w_active = s_axi_wvalid && !local_w_active && !local_bvalid_reg;
wire pass_b_handshake = m_axi_bvalid && m_axi_bready;
wire local_b_handshake = local_bvalid_reg && s_axi_bready;

axi_ic_burst_guard #(
    .ADDR_WIDTH(ADDR_WIDTH)
)
burst_guard_inst (
    .addr(s_axi_awaddr),
    .len(s_axi_awlen),
    .size(s_axi_awsize),
    .burst(s_axi_awburst),
    .valid(burst_valid),
    .crosses_4k(unused_crosses_4k),
    .unsupported_burst(unused_unsupported_burst),
    .beat_count(unused_beat_count),
    .bytes_per_beat(unused_bytes_per_beat),
    .burst_bytes(unused_burst_bytes),
    .span_start(unused_span_start),
    .span_end(unused_span_end)
);

always @(posedge clk) begin
    if (rst) begin
        pass_write_count_reg <= {OUTSTANDING_WIDTH{1'b0}};
        local_write_active_reg <= 1'b0;
        local_bvalid_reg <= 1'b0;
        local_bid_reg <= {ID_WIDTH{1'b0}};
    end else begin
        if (pass_aw_handshake && !pass_b_handshake) begin
            pass_write_count_reg <= pass_write_count_reg + 1'b1;
        end else if (!pass_aw_handshake && pass_b_handshake) begin
            pass_write_count_reg <= pass_write_count_reg - 1'b1;
        end

        if (local_b_handshake) begin
            local_bvalid_reg <= 1'b0;
        end

        if (local_aw_handshake) begin
            local_bid_reg <= s_axi_awid;
            local_write_active_reg <= !local_w_last_handshake;
            if (local_w_last_handshake) begin
                local_bvalid_reg <= 1'b1;
            end
        end else if (local_write_active_reg && local_w_last_handshake) begin
            local_write_active_reg <= 1'b0;
            local_bvalid_reg <= 1'b1;
        end
    end
end

assign m_axi_awid = s_axi_awid;
assign m_axi_awaddr = s_axi_awaddr;
assign m_axi_awlen = s_axi_awlen;
assign m_axi_awsize = s_axi_awsize;
assign m_axi_awburst = s_axi_awburst;
assign m_axi_awlock = s_axi_awlock;
assign m_axi_awcache = s_axi_awcache;
assign m_axi_awprot = s_axi_awprot;
assign m_axi_awqos = s_axi_awqos;
assign m_axi_awuser = AWUSER_ENABLE ? s_axi_awuser : {AWUSER_WIDTH{1'b0}};
assign m_axi_awvalid = pass_aw_active;
assign s_axi_awready = local_fault_active ? can_accept_local_aw : (!local_write_active_reg && !local_bvalid_reg && m_axi_awready);

assign m_axi_wdata = s_axi_wdata;
assign m_axi_wstrb = s_axi_wstrb;
assign m_axi_wlast = s_axi_wlast;
assign m_axi_wuser = WUSER_ENABLE ? s_axi_wuser : {WUSER_WIDTH{1'b0}};
assign m_axi_wvalid = pass_w_active;
assign s_axi_wready = local_w_active ? 1'b1 : (!local_bvalid_reg && m_axi_wready);

assign s_axi_bid = local_bvalid_reg ? local_bid_reg : m_axi_bid;
assign s_axi_bresp = local_bvalid_reg ? 2'b11 : m_axi_bresp;
assign s_axi_buser = local_bvalid_reg ? {BUSER_WIDTH{1'b0}} : (BUSER_ENABLE ? m_axi_buser : {BUSER_WIDTH{1'b0}});
assign s_axi_bvalid = local_bvalid_reg ? 1'b1 : m_axi_bvalid;
assign m_axi_bready = local_bvalid_reg ? 1'b0 : s_axi_bready;

assign stat_write_req_pulse = pass_aw_handshake;
assign stat_write_decerr_pulse = local_b_handshake;
assign fault_valid = local_aw_handshake;
assign fault_code = master_write_allowed ? 8'h01 : 8'h02;
assign fault_addr = s_axi_awaddr;
assign fault_id = s_axi_awid;

endmodule

`resetall
