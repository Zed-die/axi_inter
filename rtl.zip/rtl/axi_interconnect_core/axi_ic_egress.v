`resetall
`timescale 1ns / 1ps
`default_nettype none

/*
 * AXI egress shell
 *
 * Direct mode preserves AXI passthrough behavior.
 * Bridge mode wraps axi4_to_ahb_lite_bridge and restores the full internal ID width.
 * Target-disable handling sits above both modes and returns local DECERRs.
 */
module axi_ic_egress #
(
    parameter S_COUNT = 1,
    parameter S_ID_WIDTH = 8,
    parameter TARGET_INDEX = 0,
    parameter DATA_WIDTH = 32,
    parameter ADDR_WIDTH = 32,
    parameter STRB_WIDTH = (DATA_WIDTH/8),
    parameter ID_WIDTH = 8,
    parameter AWUSER_ENABLE = 0,
    parameter AWUSER_WIDTH = 1,
    parameter WUSER_ENABLE = 0,
    parameter WUSER_WIDTH = 1,
    parameter BUSER_ENABLE = 0,
    parameter BUSER_WIDTH = 1,
    parameter ARUSER_ENABLE = 0,
    parameter ARUSER_WIDTH = 1,
    parameter RUSER_ENABLE = 0,
    parameter RUSER_WIDTH = 1,
    parameter TARGET_TYPE = 0,
    parameter BRIDGE_ID_FIFO_DEPTH = 16
)
(
    input  wire                     clk,
    input  wire                     rst,
    input  wire                     cfg_target_enable,
    input  wire [ID_WIDTH-1:0]      s_axi_awid,
    input  wire [ADDR_WIDTH-1:0]    s_axi_awaddr,
    input  wire [7:0]               s_axi_awlen,
    input  wire [2:0]               s_axi_awsize,
    input  wire [1:0]               s_axi_awburst,
    input  wire                     s_axi_awlock,
    input  wire [3:0]               s_axi_awcache,
    input  wire [2:0]               s_axi_awprot,
    input  wire [3:0]               s_axi_awqos,
    input  wire [3:0]               s_axi_awregion,
    input  wire [AWUSER_WIDTH-1:0]  s_axi_awuser,
    input  wire                     s_axi_awvalid,
    output wire                     s_axi_awready,
    input  wire [DATA_WIDTH-1:0]    s_axi_wdata,
    input  wire [STRB_WIDTH-1:0]    s_axi_wstrb,
    input  wire                     s_axi_wlast,
    input  wire [WUSER_WIDTH-1:0]   s_axi_wuser,
    input  wire                     s_axi_wvalid,
    output wire                     s_axi_wready,
    output wire [ID_WIDTH-1:0]      s_axi_bid,
    output wire [1:0]               s_axi_bresp,
    output wire [BUSER_WIDTH-1:0]   s_axi_buser,
    output wire                     s_axi_bvalid,
    input  wire                     s_axi_bready,
    input  wire [ID_WIDTH-1:0]      s_axi_arid,
    input  wire [ADDR_WIDTH-1:0]    s_axi_araddr,
    input  wire [7:0]               s_axi_arlen,
    input  wire [2:0]               s_axi_arsize,
    input  wire [1:0]               s_axi_arburst,
    input  wire                     s_axi_arlock,
    input  wire [3:0]               s_axi_arcache,
    input  wire [2:0]               s_axi_arprot,
    input  wire [3:0]               s_axi_arqos,
    input  wire [3:0]               s_axi_arregion,
    input  wire [ARUSER_WIDTH-1:0]  s_axi_aruser,
    input  wire                     s_axi_arvalid,
    output wire                     s_axi_arready,
    output wire [ID_WIDTH-1:0]      s_axi_rid,
    output wire [DATA_WIDTH-1:0]    s_axi_rdata,
    output wire [1:0]               s_axi_rresp,
    output wire                     s_axi_rlast,
    output wire [RUSER_WIDTH-1:0]   s_axi_ruser,
    output wire                     s_axi_rvalid,
    input  wire                     s_axi_rready,

    output wire [ID_WIDTH-1:0]      m_axi_awid,
    output wire [ADDR_WIDTH-1:0]    m_axi_awaddr,
    output wire [7:0]               m_axi_awlen,
    output wire [2:0]               m_axi_awsize,
    output wire [1:0]               m_axi_awburst,
    output wire                     m_axi_awlock,
    output wire [3:0]               m_axi_awcache,
    output wire [2:0]               m_axi_awprot,
    output wire [3:0]               m_axi_awqos,
    output wire [3:0]               m_axi_awregion,
    output wire [AWUSER_WIDTH-1:0]  m_axi_awuser,
    output wire                     m_axi_awvalid,
    input  wire                     m_axi_awready,
    output wire [DATA_WIDTH-1:0]    m_axi_wdata,
    output wire [STRB_WIDTH-1:0]    m_axi_wstrb,
    output wire                     m_axi_wlast,
    output wire [WUSER_WIDTH-1:0]   m_axi_wuser,
    output wire                     m_axi_wvalid,
    input  wire                     m_axi_wready,
    input  wire [ID_WIDTH-1:0]      m_axi_bid,
    input  wire [1:0]               m_axi_bresp,
    input  wire [BUSER_WIDTH-1:0]   m_axi_buser,
    input  wire                     m_axi_bvalid,
    output wire                     m_axi_bready,
    output wire [ID_WIDTH-1:0]      m_axi_arid,
    output wire [ADDR_WIDTH-1:0]    m_axi_araddr,
    output wire [7:0]               m_axi_arlen,
    output wire [2:0]               m_axi_arsize,
    output wire [1:0]               m_axi_arburst,
    output wire                     m_axi_arlock,
    output wire [3:0]               m_axi_arcache,
    output wire [2:0]               m_axi_arprot,
    output wire [3:0]               m_axi_arqos,
    output wire [3:0]               m_axi_arregion,
    output wire [ARUSER_WIDTH-1:0]  m_axi_aruser,
    output wire                     m_axi_arvalid,
    input  wire                     m_axi_arready,
    input  wire [ID_WIDTH-1:0]      m_axi_rid,
    input  wire [DATA_WIDTH-1:0]    m_axi_rdata,
    input  wire [1:0]               m_axi_rresp,
    input  wire                     m_axi_rlast,
    input  wire [RUSER_WIDTH-1:0]   m_axi_ruser,
    input  wire                     m_axi_rvalid,
    output wire                     m_axi_rready,

    output wire [31:0]              ahb_haddr,
    output wire [1:0]               ahb_htrans,
    output wire                     ahb_hwrite,
    output wire [2:0]               ahb_hsize,
    output wire [2:0]               ahb_hburst,
    output wire [63:0]              ahb_hwdata,
    output wire                     ahb_hbusreq,
    output wire                     ahb_hlock,
    input  wire [63:0]              ahb_hrdata,
    input  wire                     ahb_hready,
    input  wire [1:0]               ahb_hresp,
    input  wire                     ahb_hgrant,
    input  wire [3:0]               ahb_hmaster,

    output wire [S_COUNT-1:0]       stat_write_decerr_pulse,
    output wire [S_COUNT-1:0]       stat_read_decerr_pulse,
    output wire                     fault_valid,
    output wire [7:0]               fault_code,
    output wire [ADDR_WIDTH-1:0]    fault_addr,
    output wire [7:0]               fault_id,
    output wire [7:0]               fault_src_port,
    output wire [7:0]               fault_dst_port
);

localparam TARGET_TYPE_AXI = 0;
localparam TARGET_TYPE_AXI2AHB = 1;
localparam BRIDGE_TRACK_DEPTH = BRIDGE_ID_FIFO_DEPTH < 2 ? 2 : BRIDGE_ID_FIFO_DEPTH;
localparam BRIDGE_TRACK_PTR_W = $clog2(BRIDGE_TRACK_DEPTH);
localparam BRIDGE_TRACK_COUNT_W = $clog2(BRIDGE_TRACK_DEPTH+1);

function [7:0] decode_src_port;
    input [ID_WIDTH-1:0] id;
    begin
        decode_src_port = 8'd0;
        if (ID_WIDTH > S_ID_WIDTH) begin
            decode_src_port = id >> S_ID_WIDTH;
        end
    end
endfunction

function [7:0] truncate_id;
    input [ID_WIDTH-1:0] id;
    begin
        truncate_id = id;
    end
endfunction

reg                         target_local_write_active_reg = 1'b0;
reg                         target_local_bvalid_reg = 1'b0;
reg [ID_WIDTH-1:0]          target_local_bid_reg = {ID_WIDTH{1'b0}};
reg [7:0]                   target_local_bsrc_reg = 8'd0;
reg                         target_local_rvalid_reg = 1'b0;
reg [ID_WIDTH-1:0]          target_local_rid_reg = {ID_WIDTH{1'b0}};
reg [7:0]                   target_local_rsrc_reg = 8'd0;

wire target_local_aw_handshake = s_axi_awvalid && !cfg_target_enable && !target_local_write_active_reg && !target_local_bvalid_reg;
wire target_local_w_active = target_local_write_active_reg || target_local_aw_handshake;
wire target_local_w_handshake = target_local_w_active && s_axi_wvalid;
wire target_local_wlast_handshake = target_local_w_handshake && s_axi_wlast;
wire target_local_b_handshake = target_local_bvalid_reg && s_axi_bready;

wire target_local_ar_handshake = s_axi_arvalid && !cfg_target_enable && !target_local_rvalid_reg;
wire target_local_r_handshake = target_local_rvalid_reg && s_axi_rready;

wire path_awvalid_in = s_axi_awvalid && cfg_target_enable && !target_local_write_active_reg && !target_local_bvalid_reg;
wire path_wvalid_in = s_axi_wvalid && cfg_target_enable && !target_local_w_active && !target_local_bvalid_reg;
wire path_arvalid_in = s_axi_arvalid && cfg_target_enable && !target_local_rvalid_reg;

wire                     path_s_axi_awready;
wire                     path_s_axi_wready;
wire [ID_WIDTH-1:0]      path_s_axi_bid;
wire [1:0]               path_s_axi_bresp;
wire [BUSER_WIDTH-1:0]   path_s_axi_buser;
wire                     path_s_axi_bvalid;
wire                     path_s_axi_bready;
wire                     path_s_axi_arready;
wire [ID_WIDTH-1:0]      path_s_axi_rid;
wire [DATA_WIDTH-1:0]    path_s_axi_rdata;
wire [1:0]               path_s_axi_rresp;
wire                     path_s_axi_rlast;
wire [RUSER_WIDTH-1:0]   path_s_axi_ruser;
wire                     path_s_axi_rvalid;
wire                     path_s_axi_rready;

wire [ID_WIDTH-1:0]      target_axi_awid;
wire [ADDR_WIDTH-1:0]    target_axi_awaddr;
wire [7:0]               target_axi_awlen;
wire [2:0]               target_axi_awsize;
wire [1:0]               target_axi_awburst;
wire                     target_axi_awlock;
wire [3:0]               target_axi_awcache;
wire [2:0]               target_axi_awprot;
wire [3:0]               target_axi_awqos;
wire [3:0]               target_axi_awregion;
wire [AWUSER_WIDTH-1:0]  target_axi_awuser;
wire                     target_axi_awvalid;
wire                     target_axi_awready;
wire [DATA_WIDTH-1:0]    target_axi_wdata;
wire [STRB_WIDTH-1:0]    target_axi_wstrb;
wire                     target_axi_wlast;
wire [WUSER_WIDTH-1:0]   target_axi_wuser;
wire                     target_axi_wvalid;
wire                     target_axi_wready;
wire [ID_WIDTH-1:0]      target_axi_bid;
wire [1:0]               target_axi_bresp;
wire [BUSER_WIDTH-1:0]   target_axi_buser;
wire                     target_axi_bvalid;
wire                     target_axi_bready;
wire [ID_WIDTH-1:0]      target_axi_arid;
wire [ADDR_WIDTH-1:0]    target_axi_araddr;
wire [7:0]               target_axi_arlen;
wire [2:0]               target_axi_arsize;
wire [1:0]               target_axi_arburst;
wire                     target_axi_arlock;
wire [3:0]               target_axi_arcache;
wire [2:0]               target_axi_arprot;
wire [3:0]               target_axi_arqos;
wire [3:0]               target_axi_arregion;
wire [ARUSER_WIDTH-1:0]  target_axi_aruser;
wire                     target_axi_arvalid;
wire                     target_axi_arready;
wire [ID_WIDTH-1:0]      target_axi_rid;
wire [DATA_WIDTH-1:0]    target_axi_rdata;
wire [1:0]               target_axi_rresp;
wire                     target_axi_rlast;
wire [RUSER_WIDTH-1:0]   target_axi_ruser;
wire                     target_axi_rvalid;
wire                     target_axi_rready;

reg [S_COUNT-1:0] stat_write_decerr_pulse_reg;
reg [S_COUNT-1:0] stat_read_decerr_pulse_reg;
integer i;

always @(posedge clk) begin
    if (rst) begin
        target_local_write_active_reg <= 1'b0;
        target_local_bvalid_reg <= 1'b0;
        target_local_bid_reg <= {ID_WIDTH{1'b0}};
        target_local_bsrc_reg <= 8'd0;
        target_local_rvalid_reg <= 1'b0;
        target_local_rid_reg <= {ID_WIDTH{1'b0}};
        target_local_rsrc_reg <= 8'd0;
    end else begin
        if (target_local_b_handshake) begin
            target_local_bvalid_reg <= 1'b0;
        end

        if (target_local_aw_handshake) begin
            target_local_bid_reg <= s_axi_awid;
            target_local_bsrc_reg <= decode_src_port(s_axi_awid);
            target_local_write_active_reg <= !target_local_wlast_handshake;
            if (target_local_wlast_handshake) begin
                target_local_bvalid_reg <= 1'b1;
            end
        end else if (target_local_write_active_reg && target_local_wlast_handshake) begin
            target_local_write_active_reg <= 1'b0;
            target_local_bvalid_reg <= 1'b1;
        end

        if (target_local_r_handshake) begin
            target_local_rvalid_reg <= 1'b0;
        end

        if (target_local_ar_handshake) begin
            target_local_rvalid_reg <= 1'b1;
            target_local_rid_reg <= s_axi_arid;
            target_local_rsrc_reg <= decode_src_port(s_axi_arid);
        end
    end
end

always @* begin
    stat_write_decerr_pulse_reg = {S_COUNT{1'b0}};
    stat_read_decerr_pulse_reg = {S_COUNT{1'b0}};

    for (i = 0; i < S_COUNT; i = i + 1) begin
        if (target_local_b_handshake && target_local_bsrc_reg == i[7:0]) begin
            stat_write_decerr_pulse_reg[i] = 1'b1;
        end
        if (target_local_r_handshake && target_local_rsrc_reg == i[7:0]) begin
            stat_read_decerr_pulse_reg[i] = 1'b1;
        end
    end
end

assign stat_write_decerr_pulse = stat_write_decerr_pulse_reg;
assign stat_read_decerr_pulse = stat_read_decerr_pulse_reg;

assign fault_valid = target_local_aw_handshake || target_local_ar_handshake;
assign fault_code = target_local_aw_handshake ? 8'h05 : 8'h06;
assign fault_addr = target_local_aw_handshake ? s_axi_awaddr : s_axi_araddr;
assign fault_id = target_local_aw_handshake ? truncate_id(s_axi_awid) : truncate_id(s_axi_arid);
assign fault_src_port = target_local_aw_handshake ? decode_src_port(s_axi_awid) : decode_src_port(s_axi_arid);
assign fault_dst_port = TARGET_INDEX[7:0];

assign s_axi_awready = cfg_target_enable ? path_s_axi_awready : (!target_local_write_active_reg && !target_local_bvalid_reg);
assign s_axi_wready = target_local_w_active ? 1'b1 : (cfg_target_enable ? path_s_axi_wready : 1'b0);
assign s_axi_bid = target_local_bvalid_reg ? target_local_bid_reg : path_s_axi_bid;
assign s_axi_bresp = target_local_bvalid_reg ? 2'b11 : path_s_axi_bresp;
assign s_axi_buser = target_local_bvalid_reg ? {BUSER_WIDTH{1'b0}} : path_s_axi_buser;
assign s_axi_bvalid = target_local_bvalid_reg ? 1'b1 : path_s_axi_bvalid;
assign path_s_axi_bready = target_local_bvalid_reg ? 1'b0 : s_axi_bready;

assign s_axi_arready = cfg_target_enable ? path_s_axi_arready : !target_local_rvalid_reg;
assign s_axi_rid = target_local_rvalid_reg ? target_local_rid_reg : path_s_axi_rid;
assign s_axi_rdata = target_local_rvalid_reg ? {DATA_WIDTH{1'b0}} : path_s_axi_rdata;
assign s_axi_rresp = target_local_rvalid_reg ? 2'b11 : path_s_axi_rresp;
assign s_axi_rlast = target_local_rvalid_reg ? 1'b1 : path_s_axi_rlast;
assign s_axi_ruser = target_local_rvalid_reg ? {RUSER_WIDTH{1'b0}} : path_s_axi_ruser;
assign s_axi_rvalid = target_local_rvalid_reg ? 1'b1 : path_s_axi_rvalid;
assign path_s_axi_rready = target_local_rvalid_reg ? 1'b0 : s_axi_rready;

assign target_axi_awid = s_axi_awid;
assign target_axi_awaddr = s_axi_awaddr;
assign target_axi_awlen = s_axi_awlen;
assign target_axi_awsize = s_axi_awsize;
assign target_axi_awburst = s_axi_awburst;
assign target_axi_awlock = s_axi_awlock;
assign target_axi_awcache = s_axi_awcache;
assign target_axi_awprot = s_axi_awprot;
assign target_axi_awqos = s_axi_awqos;
assign target_axi_awregion = s_axi_awregion;
assign target_axi_awuser = AWUSER_ENABLE ? s_axi_awuser : {AWUSER_WIDTH{1'b0}};
assign target_axi_awvalid = path_awvalid_in;
assign path_s_axi_awready = target_axi_awready;

assign target_axi_wdata = s_axi_wdata;
assign target_axi_wstrb = s_axi_wstrb;
assign target_axi_wlast = s_axi_wlast;
assign target_axi_wuser = WUSER_ENABLE ? s_axi_wuser : {WUSER_WIDTH{1'b0}};
assign target_axi_wvalid = path_wvalid_in;
assign path_s_axi_wready = target_axi_wready;

assign path_s_axi_bid = target_axi_bid;
assign path_s_axi_bresp = target_axi_bresp;
assign path_s_axi_buser = BUSER_ENABLE ? target_axi_buser : {BUSER_WIDTH{1'b0}};
assign path_s_axi_bvalid = target_axi_bvalid;
assign target_axi_bready = path_s_axi_bready;

assign target_axi_arid = s_axi_arid;
assign target_axi_araddr = s_axi_araddr;
assign target_axi_arlen = s_axi_arlen;
assign target_axi_arsize = s_axi_arsize;
assign target_axi_arburst = s_axi_arburst;
assign target_axi_arlock = s_axi_arlock;
assign target_axi_arcache = s_axi_arcache;
assign target_axi_arprot = s_axi_arprot;
assign target_axi_arqos = s_axi_arqos;
assign target_axi_arregion = s_axi_arregion;
assign target_axi_aruser = ARUSER_ENABLE ? s_axi_aruser : {ARUSER_WIDTH{1'b0}};
assign target_axi_arvalid = path_arvalid_in;
assign path_s_axi_arready = target_axi_arready;

assign path_s_axi_rid = target_axi_rid;
assign path_s_axi_rdata = target_axi_rdata;
assign path_s_axi_rresp = target_axi_rresp;
assign path_s_axi_rlast = target_axi_rlast;
assign path_s_axi_ruser = RUSER_ENABLE ? target_axi_ruser : {RUSER_WIDTH{1'b0}};
assign path_s_axi_rvalid = target_axi_rvalid;
assign target_axi_rready = path_s_axi_rready;

generate
if (TARGET_TYPE == TARGET_TYPE_AXI2AHB) begin : bridge_mode

    reg [7:0] write_data_id_mem[0:BRIDGE_TRACK_DEPTH-1];
    reg [ID_WIDTH-1:0] write_resp_id_mem[0:BRIDGE_TRACK_DEPTH-1];
    reg [ID_WIDTH-1:0] read_resp_id_mem[0:BRIDGE_TRACK_DEPTH-1];

    reg [BRIDGE_TRACK_PTR_W-1:0] write_data_head_reg = {BRIDGE_TRACK_PTR_W{1'b0}};
    reg [BRIDGE_TRACK_PTR_W-1:0] write_data_tail_reg = {BRIDGE_TRACK_PTR_W{1'b0}};
    reg [BRIDGE_TRACK_COUNT_W-1:0] write_data_count_reg = {BRIDGE_TRACK_COUNT_W{1'b0}};

    reg [BRIDGE_TRACK_PTR_W-1:0] write_resp_head_reg = {BRIDGE_TRACK_PTR_W{1'b0}};
    reg [BRIDGE_TRACK_PTR_W-1:0] write_resp_tail_reg = {BRIDGE_TRACK_PTR_W{1'b0}};
    reg [BRIDGE_TRACK_COUNT_W-1:0] write_resp_count_reg = {BRIDGE_TRACK_COUNT_W{1'b0}};

    reg [BRIDGE_TRACK_PTR_W-1:0] read_resp_head_reg = {BRIDGE_TRACK_PTR_W{1'b0}};
    reg [BRIDGE_TRACK_PTR_W-1:0] read_resp_tail_reg = {BRIDGE_TRACK_PTR_W{1'b0}};
    reg [BRIDGE_TRACK_COUNT_W-1:0] read_resp_count_reg = {BRIDGE_TRACK_COUNT_W{1'b0}};

    reg [ID_WIDTH-1:0] b_stage_id_reg = {ID_WIDTH{1'b0}};
    reg [1:0] b_stage_resp_reg = 2'b00;
    reg b_stage_valid_reg = 1'b0;

    reg [ID_WIDTH-1:0] r_stage_id_reg = {ID_WIDTH{1'b0}};
    reg [DATA_WIDTH-1:0] r_stage_data_reg = {DATA_WIDTH{1'b0}};
    reg [1:0] r_stage_resp_reg = 2'b00;
    reg r_stage_last_reg = 1'b0;
    reg r_stage_valid_reg = 1'b0;

    wire bridge_awready;
    wire bridge_wready;
    wire [7:0] bridge_bid;
    wire [1:0] bridge_bresp;
    wire bridge_bvalid;
    wire bridge_bready;
    wire bridge_arready;
    wire [7:0] bridge_rid;
    wire [63:0] bridge_rdata;
    wire [1:0] bridge_rresp;
    wire bridge_rlast;
    wire bridge_rvalid;
    wire bridge_rready;
    wire [3:0] bridge_hprot;
    wire bridge_hresp = |ahb_hresp;

    wire write_data_full = write_data_count_reg == BRIDGE_TRACK_DEPTH;
    wire write_data_empty = write_data_count_reg == {BRIDGE_TRACK_COUNT_W{1'b0}};
    wire write_resp_full = write_resp_count_reg == BRIDGE_TRACK_DEPTH;
    wire write_resp_empty = write_resp_count_reg == {BRIDGE_TRACK_COUNT_W{1'b0}};
    wire read_resp_full = read_resp_count_reg == BRIDGE_TRACK_DEPTH;
    wire read_resp_empty = read_resp_count_reg == {BRIDGE_TRACK_COUNT_W{1'b0}};

    wire aw_can_accept = !write_data_full && !write_resp_full;
    wire bridge_awvalid = target_axi_awvalid;
    wire aw_handshake = bridge_awvalid && bridge_awready && aw_can_accept;

    wire [7:0] bridge_wid = !write_data_empty ? write_data_id_mem[write_data_head_reg] : target_axi_awid[7:0];
    wire write_stream_available = !write_data_empty || aw_handshake;
    wire bridge_wvalid = target_axi_wvalid && write_stream_available;
    wire w_handshake = bridge_wvalid && bridge_wready;
    wire write_data_pop = w_handshake && target_axi_wlast;

    wire bridge_arvalid = target_axi_arvalid;
    wire ar_handshake = bridge_arvalid && bridge_arready && !read_resp_full;

    wire b_handshake = bridge_bvalid && bridge_bready;
    wire r_handshake = bridge_rvalid && bridge_rready;
    wire read_resp_pop = r_handshake && bridge_rlast;
    wire resp_stage_busy = b_stage_valid_reg || r_stage_valid_reg;

    integer j;
    initial begin
        if (ADDR_WIDTH != 32) begin
            $error("Error: AXI2AHB bridge mode requires ADDR_WIDTH=32 (instance %m)");
            $finish;
        end
        if (DATA_WIDTH != 64) begin
            $error("Error: AXI2AHB bridge mode requires DATA_WIDTH=64 (instance %m)");
            $finish;
        end
        if (STRB_WIDTH != 8) begin
            $error("Error: AXI2AHB bridge mode requires STRB_WIDTH=8 (instance %m)");
            $finish;
        end
        if (ID_WIDTH < 8) begin
            $error("Error: AXI2AHB bridge mode requires ID_WIDTH>=8 (instance %m)");
            $finish;
        end
        if (BRIDGE_ID_FIFO_DEPTH < 1) begin
            $error("Error: BRIDGE_ID_FIFO_DEPTH must be at least 1 (instance %m)");
            $finish;
        end
        for (j = 0; j < BRIDGE_TRACK_DEPTH; j = j + 1) begin
            write_data_id_mem[j] = 8'd0;
            write_resp_id_mem[j] = {ID_WIDTH{1'b0}};
            read_resp_id_mem[j] = {ID_WIDTH{1'b0}};
        end
    end

    always @(posedge clk) begin
        if (rst) begin
            write_data_head_reg <= {BRIDGE_TRACK_PTR_W{1'b0}};
            write_data_tail_reg <= {BRIDGE_TRACK_PTR_W{1'b0}};
            write_data_count_reg <= {BRIDGE_TRACK_COUNT_W{1'b0}};
            write_resp_head_reg <= {BRIDGE_TRACK_PTR_W{1'b0}};
            write_resp_tail_reg <= {BRIDGE_TRACK_PTR_W{1'b0}};
            write_resp_count_reg <= {BRIDGE_TRACK_COUNT_W{1'b0}};
            read_resp_head_reg <= {BRIDGE_TRACK_PTR_W{1'b0}};
            read_resp_tail_reg <= {BRIDGE_TRACK_PTR_W{1'b0}};
            read_resp_count_reg <= {BRIDGE_TRACK_COUNT_W{1'b0}};
            b_stage_id_reg <= {ID_WIDTH{1'b0}};
            b_stage_resp_reg <= 2'b00;
            b_stage_valid_reg <= 1'b0;
            r_stage_id_reg <= {ID_WIDTH{1'b0}};
            r_stage_data_reg <= {DATA_WIDTH{1'b0}};
            r_stage_resp_reg <= 2'b00;
            r_stage_last_reg <= 1'b0;
            r_stage_valid_reg <= 1'b0;
        end else begin
            case ({aw_handshake, write_data_pop})
                2'b10: begin
                    write_data_id_mem[write_data_tail_reg] <= target_axi_awid[7:0];
                    write_data_tail_reg <= write_data_tail_reg == BRIDGE_TRACK_DEPTH-1 ? {BRIDGE_TRACK_PTR_W{1'b0}} : write_data_tail_reg + 1'b1;
                    write_data_count_reg <= write_data_count_reg + 1'b1;
                end
                2'b01: begin
                    write_data_head_reg <= write_data_head_reg == BRIDGE_TRACK_DEPTH-1 ? {BRIDGE_TRACK_PTR_W{1'b0}} : write_data_head_reg + 1'b1;
                    write_data_count_reg <= write_data_count_reg - 1'b1;
                end
                2'b11: begin
                    write_data_id_mem[write_data_tail_reg] <= target_axi_awid[7:0];
                    write_data_tail_reg <= write_data_tail_reg == BRIDGE_TRACK_DEPTH-1 ? {BRIDGE_TRACK_PTR_W{1'b0}} : write_data_tail_reg + 1'b1;
                    write_data_head_reg <= write_data_head_reg == BRIDGE_TRACK_DEPTH-1 ? {BRIDGE_TRACK_PTR_W{1'b0}} : write_data_head_reg + 1'b1;
                end
            endcase

            case ({aw_handshake, b_handshake})
                2'b10: begin
                    write_resp_id_mem[write_resp_tail_reg] <= target_axi_awid;
                    write_resp_tail_reg <= write_resp_tail_reg == BRIDGE_TRACK_DEPTH-1 ? {BRIDGE_TRACK_PTR_W{1'b0}} : write_resp_tail_reg + 1'b1;
                    write_resp_count_reg <= write_resp_count_reg + 1'b1;
                end
                2'b01: begin
                    write_resp_head_reg <= write_resp_head_reg == BRIDGE_TRACK_DEPTH-1 ? {BRIDGE_TRACK_PTR_W{1'b0}} : write_resp_head_reg + 1'b1;
                    write_resp_count_reg <= write_resp_count_reg - 1'b1;
                end
                2'b11: begin
                    write_resp_id_mem[write_resp_tail_reg] <= target_axi_awid;
                    write_resp_tail_reg <= write_resp_tail_reg == BRIDGE_TRACK_DEPTH-1 ? {BRIDGE_TRACK_PTR_W{1'b0}} : write_resp_tail_reg + 1'b1;
                    write_resp_head_reg <= write_resp_head_reg == BRIDGE_TRACK_DEPTH-1 ? {BRIDGE_TRACK_PTR_W{1'b0}} : write_resp_head_reg + 1'b1;
                end
            endcase

            case ({ar_handshake, read_resp_pop})
                2'b10: begin
                    read_resp_id_mem[read_resp_tail_reg] <= target_axi_arid;
                    read_resp_tail_reg <= read_resp_tail_reg == BRIDGE_TRACK_DEPTH-1 ? {BRIDGE_TRACK_PTR_W{1'b0}} : read_resp_tail_reg + 1'b1;
                    read_resp_count_reg <= read_resp_count_reg + 1'b1;
                end
                2'b01: begin
                    read_resp_head_reg <= read_resp_head_reg == BRIDGE_TRACK_DEPTH-1 ? {BRIDGE_TRACK_PTR_W{1'b0}} : read_resp_head_reg + 1'b1;
                    read_resp_count_reg <= read_resp_count_reg - 1'b1;
                end
                2'b11: begin
                    read_resp_id_mem[read_resp_tail_reg] <= target_axi_arid;
                    read_resp_tail_reg <= read_resp_tail_reg == BRIDGE_TRACK_DEPTH-1 ? {BRIDGE_TRACK_PTR_W{1'b0}} : read_resp_tail_reg + 1'b1;
                    read_resp_head_reg <= read_resp_head_reg == BRIDGE_TRACK_DEPTH-1 ? {BRIDGE_TRACK_PTR_W{1'b0}} : read_resp_head_reg + 1'b1;
                end
            endcase

            if (b_stage_valid_reg && target_axi_bready) begin
                b_stage_valid_reg <= 1'b0;
            end

            if (r_stage_valid_reg && target_axi_rready) begin
                r_stage_valid_reg <= 1'b0;
            end

            if (!resp_stage_busy) begin
                if (bridge_bvalid && !write_resp_empty) begin
                    b_stage_id_reg <= write_resp_id_mem[write_resp_head_reg];
                    b_stage_resp_reg <= bridge_bresp;
                    b_stage_valid_reg <= 1'b1;
                end else if (bridge_rvalid && !read_resp_empty) begin
                    r_stage_id_reg <= read_resp_id_mem[read_resp_head_reg];
                    r_stage_data_reg <= bridge_rdata;
                    r_stage_resp_reg <= bridge_rresp;
                    r_stage_last_reg <= bridge_rlast;
                    r_stage_valid_reg <= 1'b1;
                end
            end
        end
    end

    axi4_to_ahb_lite_bridge #(
        .AXI_ID_WIDTH(8),
        .ADDR_WIDTH(ADDR_WIDTH),
        .DATA_WIDTH(DATA_WIDTH)
    )
    bridge_inst (
        .clk(clk),
        .rst(rst),
        .s_axi_awid(target_axi_awid[7:0]),
        .s_axi_awaddr(target_axi_awaddr),
        .s_axi_awlen(target_axi_awlen),
        .s_axi_awsize(target_axi_awsize),
        .s_axi_awburst(target_axi_awburst),
        .s_axi_awvalid(bridge_awvalid && aw_can_accept),
        .s_axi_awready(bridge_awready),
        .s_axi_wdata(target_axi_wdata),
        .s_axi_wstrb(target_axi_wstrb),
        .s_axi_wlast(target_axi_wlast),
        .s_axi_wvalid(bridge_wvalid),
        .s_axi_wready(bridge_wready),
        .s_axi_bid(bridge_bid),
        .s_axi_bresp(bridge_bresp),
        .s_axi_bvalid(bridge_bvalid),
        .s_axi_bready(bridge_bready),
        .s_axi_arid(target_axi_arid[7:0]),
        .s_axi_araddr(target_axi_araddr),
        .s_axi_arlen(target_axi_arlen),
        .s_axi_arsize(target_axi_arsize),
        .s_axi_arburst(target_axi_arburst),
        .s_axi_arvalid(bridge_arvalid && !read_resp_full),
        .s_axi_arready(bridge_arready),
        .s_axi_rid(bridge_rid),
        .s_axi_rdata(bridge_rdata),
        .s_axi_rresp(bridge_rresp),
        .s_axi_rlast(bridge_rlast),
        .s_axi_rvalid(bridge_rvalid),
        .s_axi_rready(bridge_rready),
        .m_ahb_haddr(ahb_haddr),
        .m_ahb_htrans(ahb_htrans),
        .m_ahb_hwrite(ahb_hwrite),
        .m_ahb_hsize(ahb_hsize),
        .m_ahb_hburst(ahb_hburst),
        .m_ahb_hprot(bridge_hprot),
        .m_ahb_hmastlock(ahb_hlock),
        .m_ahb_hwdata(ahb_hwdata),
        .m_ahb_hrdata(ahb_hrdata),
        .m_ahb_hready(ahb_hready),
        .m_ahb_hresp(bridge_hresp)
    );

    assign ahb_hbusreq = ahb_htrans != 2'b00;

    assign target_axi_awready = bridge_awready && aw_can_accept;
    assign target_axi_wready = bridge_wready && write_stream_available;
    assign target_axi_bid = b_stage_id_reg;
    assign target_axi_bresp = b_stage_resp_reg;
    assign target_axi_buser = {BUSER_WIDTH{1'b0}};
    assign target_axi_bvalid = b_stage_valid_reg;
    assign bridge_bready = !resp_stage_busy;

    assign target_axi_arready = bridge_arready && !read_resp_full;
    assign target_axi_rid = r_stage_id_reg;
    assign target_axi_rdata = r_stage_data_reg;
    assign target_axi_rresp = r_stage_resp_reg;
    assign target_axi_rlast = r_stage_last_reg;
    assign target_axi_ruser = {RUSER_WIDTH{1'b0}};
    assign target_axi_rvalid = r_stage_valid_reg;
    assign bridge_rready = !resp_stage_busy;

    assign m_axi_awid = {ID_WIDTH{1'b0}};
    assign m_axi_awaddr = {ADDR_WIDTH{1'b0}};
    assign m_axi_awlen = 8'd0;
    assign m_axi_awsize = 3'd0;
    assign m_axi_awburst = 2'd0;
    assign m_axi_awlock = 1'b0;
    assign m_axi_awcache = 4'd0;
    assign m_axi_awprot = 3'd0;
    assign m_axi_awqos = 4'd0;
    assign m_axi_awregion = 4'd0;
    assign m_axi_awuser = {AWUSER_WIDTH{1'b0}};
    assign m_axi_awvalid = 1'b0;
    assign m_axi_wdata = {DATA_WIDTH{1'b0}};
    assign m_axi_wstrb = {STRB_WIDTH{1'b0}};
    assign m_axi_wlast = 1'b0;
    assign m_axi_wuser = {WUSER_WIDTH{1'b0}};
    assign m_axi_wvalid = 1'b0;
    assign m_axi_bready = 1'b0;
    assign m_axi_arid = {ID_WIDTH{1'b0}};
    assign m_axi_araddr = {ADDR_WIDTH{1'b0}};
    assign m_axi_arlen = 8'd0;
    assign m_axi_arsize = 3'd0;
    assign m_axi_arburst = 2'd0;
    assign m_axi_arlock = 1'b0;
    assign m_axi_arcache = 4'd0;
    assign m_axi_arprot = 3'd0;
    assign m_axi_arqos = 4'd0;
    assign m_axi_arregion = 4'd0;
    assign m_axi_aruser = {ARUSER_WIDTH{1'b0}};
    assign m_axi_arvalid = 1'b0;
    assign m_axi_rready = 1'b0;

end else begin : direct_mode

    assign m_axi_awid = target_axi_awid;
    assign m_axi_awaddr = target_axi_awaddr;
    assign m_axi_awlen = target_axi_awlen;
    assign m_axi_awsize = target_axi_awsize;
    assign m_axi_awburst = target_axi_awburst;
    assign m_axi_awlock = target_axi_awlock;
    assign m_axi_awcache = target_axi_awcache;
    assign m_axi_awprot = target_axi_awprot;
    assign m_axi_awqos = target_axi_awqos;
    assign m_axi_awregion = target_axi_awregion;
    assign m_axi_awuser = target_axi_awuser;
    assign m_axi_awvalid = target_axi_awvalid;
    assign target_axi_awready = m_axi_awready;

    assign m_axi_wdata = target_axi_wdata;
    assign m_axi_wstrb = target_axi_wstrb;
    assign m_axi_wlast = target_axi_wlast;
    assign m_axi_wuser = target_axi_wuser;
    assign m_axi_wvalid = target_axi_wvalid;
    assign target_axi_wready = m_axi_wready;

    assign target_axi_bid = m_axi_bid;
    assign target_axi_bresp = m_axi_bresp;
    assign target_axi_buser = BUSER_ENABLE ? m_axi_buser : {BUSER_WIDTH{1'b0}};
    assign target_axi_bvalid = m_axi_bvalid;
    assign m_axi_bready = target_axi_bready;

    assign m_axi_arid = target_axi_arid;
    assign m_axi_araddr = target_axi_araddr;
    assign m_axi_arlen = target_axi_arlen;
    assign m_axi_arsize = target_axi_arsize;
    assign m_axi_arburst = target_axi_arburst;
    assign m_axi_arlock = target_axi_arlock;
    assign m_axi_arcache = target_axi_arcache;
    assign m_axi_arprot = target_axi_arprot;
    assign m_axi_arqos = target_axi_arqos;
    assign m_axi_arregion = target_axi_arregion;
    assign m_axi_aruser = target_axi_aruser;
    assign m_axi_arvalid = target_axi_arvalid;
    assign target_axi_arready = m_axi_arready;

    assign target_axi_rid = m_axi_rid;
    assign target_axi_rdata = m_axi_rdata;
    assign target_axi_rresp = m_axi_rresp;
    assign target_axi_rlast = m_axi_rlast;
    assign target_axi_ruser = RUSER_ENABLE ? m_axi_ruser : {RUSER_WIDTH{1'b0}};
    assign target_axi_rvalid = m_axi_rvalid;
    assign m_axi_rready = target_axi_rready;

    assign ahb_haddr = 32'd0;
    assign ahb_htrans = 2'd0;
    assign ahb_hwrite = 1'b0;
    assign ahb_hsize = 3'd0;
    assign ahb_hburst = 3'd0;
    assign ahb_hwdata = 64'd0;
    assign ahb_hbusreq = 1'b0;
    assign ahb_hlock = 1'b0;

end
endgenerate

endmodule

`resetall
