`resetall
`timescale 1ns / 1ps
`default_nettype none

/*
 * AXI interconnect core
 */
module axi_interconnect_core #
(
    parameter S_COUNT = 4,
    parameter M_COUNT = 4,
    parameter DATA_WIDTH = 32,
    parameter ADDR_WIDTH = 32,
    parameter STRB_WIDTH = (DATA_WIDTH/8),
    parameter S_ID_WIDTH = 8,
    parameter M_ID_WIDTH = S_ID_WIDTH+$clog2(S_COUNT),
    parameter AWUSER_ENABLE = 0,
    parameter AWUSER_WIDTH = 1,
    parameter WUSER_ENABLE = 0,
    parameter WUSER_WIDTH = 1,
    parameter BUSER_ENABLE = 0,
    parameter BUSER_WIDTH = 1,
    parameter ARUSER_ENABLE = 0,
    parameter ARUSER_WIDTH = 1,
    parameter RUSER_ENABLE = 0,
    parameter RUSER_WIDTH = 1,
    parameter S_THREADS = {S_COUNT{32'd2}},
    parameter S_ACCEPT = {S_COUNT{32'd16}},
    parameter M_REGIONS = 1,
    parameter M_BASE_ADDR = 0,
    parameter M_ADDR_WIDTH = {M_COUNT{{M_REGIONS{32'd24}}}},
    parameter M_CONNECT_READ = {M_COUNT{{S_COUNT{1'b1}}}},
    parameter M_CONNECT_WRITE = {M_COUNT{{S_COUNT{1'b1}}}},
    parameter M_ISSUE = {M_COUNT{32'd4}},
    parameter M_SECURE = {M_COUNT{1'b0}},
    parameter S_AW_REG_TYPE = {S_COUNT{2'd0}},
    parameter S_W_REG_TYPE = {S_COUNT{2'd0}},
    parameter S_B_REG_TYPE = {S_COUNT{2'd1}},
    parameter S_AR_REG_TYPE = {S_COUNT{2'd0}},
    parameter S_R_REG_TYPE = {S_COUNT{2'd2}},
    parameter M_AW_REG_TYPE = {M_COUNT{2'd1}},
    parameter M_W_REG_TYPE = {M_COUNT{2'd2}},
    parameter M_B_REG_TYPE = {M_COUNT{2'd0}},
    parameter M_AR_REG_TYPE = {M_COUNT{2'd1}},
    parameter M_R_REG_TYPE = {M_COUNT{2'd0}},
    parameter M_TARGET_TYPE = {M_COUNT{1'b1}},
    parameter [ADDR_WIDTH-1:0] DECERR_ADDR = {ADDR_WIDTH{1'b1}}
)
(
    input  wire                             clk,
    input  wire                             rst,

    //APB接口
    input  wire [11:0]                      cfg_paddr,
    input  wire                             cfg_psel,
    input  wire                             cfg_penable,
    input  wire                             cfg_pwrite,
    input  wire [31:0]                      cfg_pwdata,
    output wire [31:0]                      cfg_prdata,
    output wire                             cfg_pready,
    output wire                             cfg_pslverr,

    //输入端口
    input  wire [S_COUNT*S_ID_WIDTH-1:0]    s_axi_awid,
    input  wire [S_COUNT*ADDR_WIDTH-1:0]    s_axi_awaddr,
    input  wire [S_COUNT*8-1:0]             s_axi_awlen,
    input  wire [S_COUNT*3-1:0]             s_axi_awsize,
    input  wire [S_COUNT*2-1:0]             s_axi_awburst,
    input  wire [S_COUNT-1:0]               s_axi_awlock,
    input  wire [S_COUNT*4-1:0]             s_axi_awcache,
    input  wire [S_COUNT*3-1:0]             s_axi_awprot,
    input  wire [S_COUNT*4-1:0]             s_axi_awqos,
    input  wire [S_COUNT*AWUSER_WIDTH-1:0]  s_axi_awuser,
    input  wire [S_COUNT-1:0]               s_axi_awvalid,
    output wire [S_COUNT-1:0]               s_axi_awready,
    input  wire [S_COUNT*DATA_WIDTH-1:0]    s_axi_wdata,
    input  wire [S_COUNT*STRB_WIDTH-1:0]    s_axi_wstrb,
    input  wire [S_COUNT-1:0]               s_axi_wlast,
    input  wire [S_COUNT*WUSER_WIDTH-1:0]   s_axi_wuser,
    input  wire [S_COUNT-1:0]               s_axi_wvalid,
    output wire [S_COUNT-1:0]               s_axi_wready,
    output wire [S_COUNT*S_ID_WIDTH-1:0]    s_axi_bid,
    output wire [S_COUNT*2-1:0]             s_axi_bresp,
    output wire [S_COUNT*BUSER_WIDTH-1:0]   s_axi_buser,
    output wire [S_COUNT-1:0]               s_axi_bvalid,
    input  wire [S_COUNT-1:0]               s_axi_bready,
    input  wire [S_COUNT*S_ID_WIDTH-1:0]    s_axi_arid,
    input  wire [S_COUNT*ADDR_WIDTH-1:0]    s_axi_araddr,
    input  wire [S_COUNT*8-1:0]             s_axi_arlen,
    input  wire [S_COUNT*3-1:0]             s_axi_arsize,
    input  wire [S_COUNT*2-1:0]             s_axi_arburst,
    input  wire [S_COUNT-1:0]               s_axi_arlock,
    input  wire [S_COUNT*4-1:0]             s_axi_arcache,
    input  wire [S_COUNT*3-1:0]             s_axi_arprot,
    input  wire [S_COUNT*4-1:0]             s_axi_arqos,
    input  wire [S_COUNT*ARUSER_WIDTH-1:0]  s_axi_aruser,
    input  wire [S_COUNT-1:0]               s_axi_arvalid,
    output wire [S_COUNT-1:0]               s_axi_arready,
    output wire [S_COUNT*S_ID_WIDTH-1:0]    s_axi_rid,
    output wire [S_COUNT*DATA_WIDTH-1:0]    s_axi_rdata,
    output wire [S_COUNT*2-1:0]             s_axi_rresp,
    output wire [S_COUNT-1:0]               s_axi_rlast,
    output wire [S_COUNT*RUSER_WIDTH-1:0]   s_axi_ruser,
    output wire [S_COUNT-1:0]               s_axi_rvalid,
    input  wire [S_COUNT-1:0]               s_axi_rready,

    //输出端口
    output wire [M_COUNT*M_ID_WIDTH-1:0]    m_axi_awid,
    output wire [M_COUNT*ADDR_WIDTH-1:0]    m_axi_awaddr,
    output wire [M_COUNT*8-1:0]             m_axi_awlen,
    output wire [M_COUNT*3-1:0]             m_axi_awsize,
    output wire [M_COUNT*2-1:0]             m_axi_awburst,
    output wire [M_COUNT-1:0]               m_axi_awlock,
    output wire [M_COUNT*4-1:0]             m_axi_awcache,
    output wire [M_COUNT*3-1:0]             m_axi_awprot,
    output wire [M_COUNT*4-1:0]             m_axi_awqos,
    output wire [M_COUNT*4-1:0]             m_axi_awregion,
    output wire [M_COUNT*AWUSER_WIDTH-1:0]  m_axi_awuser,
    output wire [M_COUNT-1:0]               m_axi_awvalid,
    input  wire [M_COUNT-1:0]               m_axi_awready,
    output wire [M_COUNT*DATA_WIDTH-1:0]    m_axi_wdata,
    output wire [M_COUNT*STRB_WIDTH-1:0]    m_axi_wstrb,
    output wire [M_COUNT-1:0]               m_axi_wlast,
    output wire [M_COUNT*WUSER_WIDTH-1:0]   m_axi_wuser,
    output wire [M_COUNT-1:0]               m_axi_wvalid,
    input  wire [M_COUNT-1:0]               m_axi_wready,
    input  wire [M_COUNT*M_ID_WIDTH-1:0]    m_axi_bid,
    input  wire [M_COUNT*2-1:0]             m_axi_bresp,
    input  wire [M_COUNT*BUSER_WIDTH-1:0]   m_axi_buser,
    input  wire [M_COUNT-1:0]               m_axi_bvalid,
    output wire [M_COUNT-1:0]               m_axi_bready,
    output wire [M_COUNT*M_ID_WIDTH-1:0]    m_axi_arid,
    output wire [M_COUNT*ADDR_WIDTH-1:0]    m_axi_araddr,
    output wire [M_COUNT*8-1:0]             m_axi_arlen,
    output wire [M_COUNT*3-1:0]             m_axi_arsize,
    output wire [M_COUNT*2-1:0]             m_axi_arburst,
    output wire [M_COUNT-1:0]               m_axi_arlock,
    output wire [M_COUNT*4-1:0]             m_axi_arcache,
    output wire [M_COUNT*3-1:0]             m_axi_arprot,
    output wire [M_COUNT*4-1:0]             m_axi_arqos,
    output wire [M_COUNT*4-1:0]             m_axi_arregion,
    output wire [M_COUNT*ARUSER_WIDTH-1:0]  m_axi_aruser,
    output wire [M_COUNT-1:0]               m_axi_arvalid,
    input  wire [M_COUNT-1:0]               m_axi_arready,
    input  wire [M_COUNT*M_ID_WIDTH-1:0]    m_axi_rid,
    input  wire [M_COUNT*DATA_WIDTH-1:0]    m_axi_rdata,
    input  wire [M_COUNT*2-1:0]             m_axi_rresp,
    input  wire [M_COUNT-1:0]               m_axi_rlast,
    input  wire [M_COUNT*RUSER_WIDTH-1:0]   m_axi_ruser,
    input  wire [M_COUNT-1:0]               m_axi_rvalid,
    output wire [M_COUNT-1:0]               m_axi_rready,

    //AHB桥接
    output wire [M_COUNT*32-1:0]            m_ahb_haddr,
    output wire [M_COUNT*2-1:0]             m_ahb_htrans,
    output wire [M_COUNT-1:0]               m_ahb_hwrite,
    output wire [M_COUNT*3-1:0]             m_ahb_hsize,
    output wire [M_COUNT*3-1:0]             m_ahb_hburst,
    output wire [M_COUNT*64-1:0]            m_ahb_hwdata,
    output wire [M_COUNT-1:0]               m_ahb_hbusreq,
    output wire [M_COUNT-1:0]               m_ahb_hlock,
    input  wire [M_COUNT*64-1:0]            m_ahb_hrdata,
    input  wire [M_COUNT-1:0]               m_ahb_hready,
    input  wire [M_COUNT*2-1:0]             m_ahb_hresp,
    input  wire [M_COUNT-1:0]               m_ahb_hgrant,
    input  wire [M_COUNT*4-1:0]             m_ahb_hmaster
);

wire [S_COUNT*S_ID_WIDTH-1:0]    guard_awid;
wire [S_COUNT*ADDR_WIDTH-1:0]    guard_awaddr;
wire [S_COUNT*8-1:0]             guard_awlen;
wire [S_COUNT*3-1:0]             guard_awsize;
wire [S_COUNT*2-1:0]             guard_awburst;
wire [S_COUNT-1:0]               guard_awlock;
wire [S_COUNT*4-1:0]             guard_awcache;
wire [S_COUNT*3-1:0]             guard_awprot;
wire [S_COUNT*4-1:0]             guard_awqos;
wire [S_COUNT*AWUSER_WIDTH-1:0]  guard_awuser;
wire [S_COUNT-1:0]               guard_awvalid;
wire [S_COUNT-1:0]               guard_awready;
wire [S_COUNT*DATA_WIDTH-1:0]    guard_wdata;
wire [S_COUNT*STRB_WIDTH-1:0]    guard_wstrb;
wire [S_COUNT-1:0]               guard_wlast;
wire [S_COUNT*WUSER_WIDTH-1:0]   guard_wuser;
wire [S_COUNT-1:0]               guard_wvalid;
wire [S_COUNT-1:0]               guard_wready;
wire [S_COUNT*S_ID_WIDTH-1:0]    guard_bid;
wire [S_COUNT*2-1:0]             guard_bresp;
wire [S_COUNT*BUSER_WIDTH-1:0]   guard_buser;
wire [S_COUNT-1:0]               guard_bvalid;
wire [S_COUNT-1:0]               guard_bready;
wire [S_COUNT*S_ID_WIDTH-1:0]    guard_arid;
wire [S_COUNT*ADDR_WIDTH-1:0]    guard_araddr;
wire [S_COUNT*8-1:0]             guard_arlen;
wire [S_COUNT*3-1:0]             guard_arsize;
wire [S_COUNT*2-1:0]             guard_arburst;
wire [S_COUNT-1:0]               guard_arlock;
wire [S_COUNT*4-1:0]             guard_arcache;
wire [S_COUNT*3-1:0]             guard_arprot;
wire [S_COUNT*4-1:0]             guard_arqos;
wire [S_COUNT*ARUSER_WIDTH-1:0]  guard_aruser;
wire [S_COUNT-1:0]               guard_arvalid;
wire [S_COUNT-1:0]               guard_arready;
wire [S_COUNT*S_ID_WIDTH-1:0]    guard_rid;
wire [S_COUNT*DATA_WIDTH-1:0]    guard_rdata;
wire [S_COUNT*2-1:0]             guard_rresp;
wire [S_COUNT-1:0]               guard_rlast;
wire [S_COUNT*RUSER_WIDTH-1:0]   guard_ruser;
wire [S_COUNT-1:0]               guard_rvalid;
wire [S_COUNT-1:0]               guard_rready;

wire [M_COUNT*M_ID_WIDTH-1:0]    xbar_awid;
wire [M_COUNT*ADDR_WIDTH-1:0]    xbar_awaddr;
wire [M_COUNT*8-1:0]             xbar_awlen;
wire [M_COUNT*3-1:0]             xbar_awsize;
wire [M_COUNT*2-1:0]             xbar_awburst;
wire [M_COUNT-1:0]               xbar_awlock;
wire [M_COUNT*4-1:0]             xbar_awcache;
wire [M_COUNT*3-1:0]             xbar_awprot;
wire [M_COUNT*4-1:0]             xbar_awqos;
wire [M_COUNT*4-1:0]             xbar_awregion;
wire [M_COUNT*AWUSER_WIDTH-1:0]  xbar_awuser;
wire [M_COUNT-1:0]               xbar_awvalid;
wire [M_COUNT-1:0]               xbar_awready;
wire [M_COUNT*DATA_WIDTH-1:0]    xbar_wdata;
wire [M_COUNT*STRB_WIDTH-1:0]    xbar_wstrb;
wire [M_COUNT-1:0]               xbar_wlast;
wire [M_COUNT*WUSER_WIDTH-1:0]   xbar_wuser;
wire [M_COUNT-1:0]               xbar_wvalid;
wire [M_COUNT-1:0]               xbar_wready;
wire [M_COUNT*M_ID_WIDTH-1:0]    xbar_bid;
wire [M_COUNT*2-1:0]             xbar_bresp;
wire [M_COUNT*BUSER_WIDTH-1:0]   xbar_buser;
wire [M_COUNT-1:0]               xbar_bvalid;
wire [M_COUNT-1:0]               xbar_bready;
wire [M_COUNT*M_ID_WIDTH-1:0]    xbar_arid;
wire [M_COUNT*ADDR_WIDTH-1:0]    xbar_araddr;
wire [M_COUNT*8-1:0]             xbar_arlen;
wire [M_COUNT*3-1:0]             xbar_arsize;
wire [M_COUNT*2-1:0]             xbar_arburst;
wire [M_COUNT-1:0]               xbar_arlock;
wire [M_COUNT*4-1:0]             xbar_arcache;
wire [M_COUNT*3-1:0]             xbar_arprot;
wire [M_COUNT*4-1:0]             xbar_arqos;
wire [M_COUNT*4-1:0]             xbar_arregion;
wire [M_COUNT*ARUSER_WIDTH-1:0]  xbar_aruser;
wire [M_COUNT-1:0]               xbar_arvalid;
wire [M_COUNT-1:0]               xbar_arready;
wire [M_COUNT*M_ID_WIDTH-1:0]    xbar_rid;
wire [M_COUNT*DATA_WIDTH-1:0]    xbar_rdata;
wire [M_COUNT*2-1:0]             xbar_rresp;
wire [M_COUNT-1:0]               xbar_rlast;
wire [M_COUNT*RUSER_WIDTH-1:0]   xbar_ruser;
wire [M_COUNT-1:0]               xbar_rvalid;
wire [M_COUNT-1:0]               xbar_rready;

wire                             cfg_core_enable;
wire [S_COUNT-1:0]               cfg_master_enable;
wire [S_COUNT-1:0]               cfg_master_allow_reads;
wire [S_COUNT-1:0]               cfg_master_allow_writes;
wire [M_COUNT-1:0]               cfg_target_enable;

wire [S_COUNT-1:0]               ingress_write_req_pulse;
wire [S_COUNT-1:0]               ingress_write_decerr_pulse;
wire [S_COUNT-1:0]               ingress_write_fault_valid;
wire [S_COUNT*8-1:0]             ingress_write_fault_code;
wire [S_COUNT*ADDR_WIDTH-1:0]    ingress_write_fault_addr;
wire [S_COUNT*S_ID_WIDTH-1:0]    ingress_write_fault_id;

wire [S_COUNT-1:0]               ingress_read_req_pulse;
wire [S_COUNT-1:0]               ingress_read_decerr_pulse;
wire [S_COUNT-1:0]               ingress_read_fault_valid;
wire [S_COUNT*8-1:0]             ingress_read_fault_code;
wire [S_COUNT*ADDR_WIDTH-1:0]    ingress_read_fault_addr;
wire [S_COUNT*S_ID_WIDTH-1:0]    ingress_read_fault_id;

wire [M_COUNT*S_COUNT-1:0]       egress_write_decerr_pulse;
wire [M_COUNT*S_COUNT-1:0]       egress_read_decerr_pulse;
wire [M_COUNT-1:0]               egress_fault_valid;
wire [M_COUNT*8-1:0]             egress_fault_code;
wire [M_COUNT*ADDR_WIDTH-1:0]    egress_fault_addr;
wire [M_COUNT*8-1:0]             egress_fault_id;
wire [M_COUNT*8-1:0]             egress_fault_src_port;
wire [M_COUNT*8-1:0]             egress_fault_dst_port;

reg [S_COUNT-1:0]                stat_write_decerr_pulse_mux;
reg [S_COUNT-1:0]                stat_read_decerr_pulse_mux;
reg                              fault_valid_mux;
reg [7:0]                        fault_code_mux;
reg [7:0]                        fault_src_port_mux;
reg [7:0]                        fault_dst_port_mux;
reg [7:0]                        fault_id_mux;
reg [ADDR_WIDTH-1:0]             fault_addr_mux;

integer p;
integer q;

always @* begin
    stat_write_decerr_pulse_mux = ingress_write_decerr_pulse;
    stat_read_decerr_pulse_mux = ingress_read_decerr_pulse;

    for (p = 0; p < M_COUNT; p = p + 1) begin
        for (q = 0; q < S_COUNT; q = q + 1) begin
            stat_write_decerr_pulse_mux[q] = stat_write_decerr_pulse_mux[q] | egress_write_decerr_pulse[p*S_COUNT + q];
            stat_read_decerr_pulse_mux[q] = stat_read_decerr_pulse_mux[q] | egress_read_decerr_pulse[p*S_COUNT + q];
        end
    end
end

always @* begin
    fault_valid_mux = 1'b0;
    fault_code_mux = 8'd0;
    fault_src_port_mux = 8'd0;
    fault_dst_port_mux = 8'd0;
    fault_id_mux = 8'd0;
    fault_addr_mux = {ADDR_WIDTH{1'b0}};

    for (p = 0; p < S_COUNT; p = p + 1) begin
        if (!fault_valid_mux && ingress_write_fault_valid[p]) begin
            fault_valid_mux = 1'b1;
            fault_code_mux = ingress_write_fault_code[p*8 +: 8];
            fault_src_port_mux = p[7:0];
            fault_dst_port_mux = 8'hFF;
            fault_id_mux = ingress_write_fault_id[p*S_ID_WIDTH +: S_ID_WIDTH];
            fault_addr_mux = ingress_write_fault_addr[p*ADDR_WIDTH +: ADDR_WIDTH];
        end
        if (!fault_valid_mux && ingress_read_fault_valid[p]) begin
            fault_valid_mux = 1'b1;
            fault_code_mux = ingress_read_fault_code[p*8 +: 8];
            fault_src_port_mux = p[7:0];
            fault_dst_port_mux = 8'hFF;
            fault_id_mux = ingress_read_fault_id[p*S_ID_WIDTH +: S_ID_WIDTH];
            fault_addr_mux = ingress_read_fault_addr[p*ADDR_WIDTH +: ADDR_WIDTH];
        end
    end

    for (p = 0; p < M_COUNT; p = p + 1) begin
        if (!fault_valid_mux && egress_fault_valid[p]) begin
            fault_valid_mux = 1'b1;
            fault_code_mux = egress_fault_code[p*8 +: 8];
            fault_src_port_mux = egress_fault_src_port[p*8 +: 8];
            fault_dst_port_mux = egress_fault_dst_port[p*8 +: 8];
            fault_id_mux = egress_fault_id[p*8 +: 8];
            fault_addr_mux = egress_fault_addr[p*ADDR_WIDTH +: ADDR_WIDTH];
        end
    end
end

axi_ic_apb_cfg #(
    .S_COUNT(S_COUNT),
    .M_COUNT(M_COUNT),
    .ADDR_WIDTH(ADDR_WIDTH),
    .M_TARGET_TYPE(M_TARGET_TYPE)
)
apb_cfg_inst (
    .clk(clk),
    .rst(rst),
    .s_apb_paddr(cfg_paddr),
    .s_apb_psel(cfg_psel),
    .s_apb_penable(cfg_penable),
    .s_apb_pwrite(cfg_pwrite),
    .s_apb_pwdata(cfg_pwdata),
    .s_apb_prdata(cfg_prdata),
    .s_apb_pready(cfg_pready),
    .s_apb_pslverr(cfg_pslverr),
    .stat_write_req_pulse(ingress_write_req_pulse),
    .stat_read_req_pulse(ingress_read_req_pulse),
    .stat_write_decerr_pulse(stat_write_decerr_pulse_mux),
    .stat_read_decerr_pulse(stat_read_decerr_pulse_mux),
    .fault_valid(fault_valid_mux),
    .fault_code(fault_code_mux),
    .fault_src_port(fault_src_port_mux),
    .fault_dst_port(fault_dst_port_mux),
    .fault_id(fault_id_mux),
    .fault_addr(fault_addr_mux),
    .core_enable(cfg_core_enable),
    .master_enable(cfg_master_enable),
    .master_allow_reads(cfg_master_allow_reads),
    .master_allow_writes(cfg_master_allow_writes),
    .target_enable(cfg_target_enable)
);

genvar n;

generate
    for (n = 0; n < S_COUNT; n = n + 1) begin : ingress_ports
        axi_ic_write_guard #(
            .DATA_WIDTH(DATA_WIDTH),
            .ADDR_WIDTH(ADDR_WIDTH),
            .STRB_WIDTH(STRB_WIDTH),
            .ID_WIDTH(S_ID_WIDTH),
            .AWUSER_ENABLE(AWUSER_ENABLE),
            .AWUSER_WIDTH(AWUSER_WIDTH),
            .WUSER_ENABLE(WUSER_ENABLE),
            .WUSER_WIDTH(WUSER_WIDTH),
            .BUSER_ENABLE(BUSER_ENABLE),
            .BUSER_WIDTH(BUSER_WIDTH),
            .DECERR_ADDR(DECERR_ADDR)
        )
        write_guard_inst (
            .clk(clk),
            .rst(rst),
            .cfg_master_enable(cfg_core_enable && cfg_master_enable[n]),
            .cfg_allow_writes(cfg_master_allow_writes[n]),
            .s_axi_awid(s_axi_awid[n*S_ID_WIDTH +: S_ID_WIDTH]),
            .s_axi_awaddr(s_axi_awaddr[n*ADDR_WIDTH +: ADDR_WIDTH]),
            .s_axi_awlen(s_axi_awlen[n*8 +: 8]),
            .s_axi_awsize(s_axi_awsize[n*3 +: 3]),
            .s_axi_awburst(s_axi_awburst[n*2 +: 2]),
            .s_axi_awlock(s_axi_awlock[n]),
            .s_axi_awcache(s_axi_awcache[n*4 +: 4]),
            .s_axi_awprot(s_axi_awprot[n*3 +: 3]),
            .s_axi_awqos(s_axi_awqos[n*4 +: 4]),
            .s_axi_awuser(s_axi_awuser[n*AWUSER_WIDTH +: AWUSER_WIDTH]),
            .s_axi_awvalid(s_axi_awvalid[n]),
            .s_axi_awready(s_axi_awready[n]),
            .s_axi_wdata(s_axi_wdata[n*DATA_WIDTH +: DATA_WIDTH]),
            .s_axi_wstrb(s_axi_wstrb[n*STRB_WIDTH +: STRB_WIDTH]),
            .s_axi_wlast(s_axi_wlast[n]),
            .s_axi_wuser(s_axi_wuser[n*WUSER_WIDTH +: WUSER_WIDTH]),
            .s_axi_wvalid(s_axi_wvalid[n]),
            .s_axi_wready(s_axi_wready[n]),
            .s_axi_bid(s_axi_bid[n*S_ID_WIDTH +: S_ID_WIDTH]),
            .s_axi_bresp(s_axi_bresp[n*2 +: 2]),
            .s_axi_buser(s_axi_buser[n*BUSER_WIDTH +: BUSER_WIDTH]),
            .s_axi_bvalid(s_axi_bvalid[n]),
            .s_axi_bready(s_axi_bready[n]),
            .m_axi_awid(guard_awid[n*S_ID_WIDTH +: S_ID_WIDTH]),
            .m_axi_awaddr(guard_awaddr[n*ADDR_WIDTH +: ADDR_WIDTH]),
            .m_axi_awlen(guard_awlen[n*8 +: 8]),
            .m_axi_awsize(guard_awsize[n*3 +: 3]),
            .m_axi_awburst(guard_awburst[n*2 +: 2]),
            .m_axi_awlock(guard_awlock[n]),
            .m_axi_awcache(guard_awcache[n*4 +: 4]),
            .m_axi_awprot(guard_awprot[n*3 +: 3]),
            .m_axi_awqos(guard_awqos[n*4 +: 4]),
            .m_axi_awuser(guard_awuser[n*AWUSER_WIDTH +: AWUSER_WIDTH]),
            .m_axi_awvalid(guard_awvalid[n]),
            .m_axi_awready(guard_awready[n]),
            .m_axi_wdata(guard_wdata[n*DATA_WIDTH +: DATA_WIDTH]),
            .m_axi_wstrb(guard_wstrb[n*STRB_WIDTH +: STRB_WIDTH]),
            .m_axi_wlast(guard_wlast[n]),
            .m_axi_wuser(guard_wuser[n*WUSER_WIDTH +: WUSER_WIDTH]),
            .m_axi_wvalid(guard_wvalid[n]),
            .m_axi_wready(guard_wready[n]),
            .m_axi_bid(guard_bid[n*S_ID_WIDTH +: S_ID_WIDTH]),
            .m_axi_bresp(guard_bresp[n*2 +: 2]),
            .m_axi_buser(guard_buser[n*BUSER_WIDTH +: BUSER_WIDTH]),
            .m_axi_bvalid(guard_bvalid[n]),
            .m_axi_bready(guard_bready[n]),
            .stat_write_req_pulse(ingress_write_req_pulse[n]),
            .stat_write_decerr_pulse(ingress_write_decerr_pulse[n]),
            .fault_valid(ingress_write_fault_valid[n]),
            .fault_code(ingress_write_fault_code[n*8 +: 8]),
            .fault_addr(ingress_write_fault_addr[n*ADDR_WIDTH +: ADDR_WIDTH]),
            .fault_id(ingress_write_fault_id[n*S_ID_WIDTH +: S_ID_WIDTH])
        );

        axi_ic_read_guard #(
            .DATA_WIDTH(DATA_WIDTH),
            .ADDR_WIDTH(ADDR_WIDTH),
            .ID_WIDTH(S_ID_WIDTH),
            .ARUSER_ENABLE(ARUSER_ENABLE),
            .ARUSER_WIDTH(ARUSER_WIDTH),
            .RUSER_ENABLE(RUSER_ENABLE),
            .RUSER_WIDTH(RUSER_WIDTH),
            .DECERR_ADDR(DECERR_ADDR)
        )
        read_guard_inst (
            .clk(clk),
            .rst(rst),
            .cfg_master_enable(cfg_core_enable && cfg_master_enable[n]),
            .cfg_allow_reads(cfg_master_allow_reads[n]),
            .s_axi_arid(s_axi_arid[n*S_ID_WIDTH +: S_ID_WIDTH]),
            .s_axi_araddr(s_axi_araddr[n*ADDR_WIDTH +: ADDR_WIDTH]),
            .s_axi_arlen(s_axi_arlen[n*8 +: 8]),
            .s_axi_arsize(s_axi_arsize[n*3 +: 3]),
            .s_axi_arburst(s_axi_arburst[n*2 +: 2]),
            .s_axi_arlock(s_axi_arlock[n]),
            .s_axi_arcache(s_axi_arcache[n*4 +: 4]),
            .s_axi_arprot(s_axi_arprot[n*3 +: 3]),
            .s_axi_arqos(s_axi_arqos[n*4 +: 4]),
            .s_axi_aruser(s_axi_aruser[n*ARUSER_WIDTH +: ARUSER_WIDTH]),
            .s_axi_arvalid(s_axi_arvalid[n]),
            .s_axi_arready(s_axi_arready[n]),
            .s_axi_rid(s_axi_rid[n*S_ID_WIDTH +: S_ID_WIDTH]),
            .s_axi_rdata(s_axi_rdata[n*DATA_WIDTH +: DATA_WIDTH]),
            .s_axi_rresp(s_axi_rresp[n*2 +: 2]),
            .s_axi_rlast(s_axi_rlast[n]),
            .s_axi_ruser(s_axi_ruser[n*RUSER_WIDTH +: RUSER_WIDTH]),
            .s_axi_rvalid(s_axi_rvalid[n]),
            .s_axi_rready(s_axi_rready[n]),
            .m_axi_arid(guard_arid[n*S_ID_WIDTH +: S_ID_WIDTH]),
            .m_axi_araddr(guard_araddr[n*ADDR_WIDTH +: ADDR_WIDTH]),
            .m_axi_arlen(guard_arlen[n*8 +: 8]),
            .m_axi_arsize(guard_arsize[n*3 +: 3]),
            .m_axi_arburst(guard_arburst[n*2 +: 2]),
            .m_axi_arlock(guard_arlock[n]),
            .m_axi_arcache(guard_arcache[n*4 +: 4]),
            .m_axi_arprot(guard_arprot[n*3 +: 3]),
            .m_axi_arqos(guard_arqos[n*4 +: 4]),
            .m_axi_aruser(guard_aruser[n*ARUSER_WIDTH +: ARUSER_WIDTH]),
            .m_axi_arvalid(guard_arvalid[n]),
            .m_axi_arready(guard_arready[n]),
            .m_axi_rid(guard_rid[n*S_ID_WIDTH +: S_ID_WIDTH]),
            .m_axi_rdata(guard_rdata[n*DATA_WIDTH +: DATA_WIDTH]),
            .m_axi_rresp(guard_rresp[n*2 +: 2]),
            .m_axi_rlast(guard_rlast[n]),
            .m_axi_ruser(guard_ruser[n*RUSER_WIDTH +: RUSER_WIDTH]),
            .m_axi_rvalid(guard_rvalid[n]),
            .m_axi_rready(guard_rready[n]),
            .stat_read_req_pulse(ingress_read_req_pulse[n]),
            .stat_read_decerr_pulse(ingress_read_decerr_pulse[n]),
            .fault_valid(ingress_read_fault_valid[n]),
            .fault_code(ingress_read_fault_code[n*8 +: 8]),
            .fault_addr(ingress_read_fault_addr[n*ADDR_WIDTH +: ADDR_WIDTH]),
            .fault_id(ingress_read_fault_id[n*S_ID_WIDTH +: S_ID_WIDTH])
        );
    end

    for (n = 0; n < M_COUNT; n = n + 1) begin : egress_ports
        axi_ic_egress #(
            .S_COUNT(S_COUNT),
            .S_ID_WIDTH(S_ID_WIDTH),
            .TARGET_INDEX(n),
            .DATA_WIDTH(DATA_WIDTH),
            .ADDR_WIDTH(ADDR_WIDTH),
            .STRB_WIDTH(STRB_WIDTH),
            .ID_WIDTH(M_ID_WIDTH),
            .AWUSER_ENABLE(AWUSER_ENABLE),
            .AWUSER_WIDTH(AWUSER_WIDTH),
            .WUSER_ENABLE(WUSER_ENABLE),
            .WUSER_WIDTH(WUSER_WIDTH),
            .BUSER_ENABLE(BUSER_ENABLE),
            .BUSER_WIDTH(BUSER_WIDTH),
            .ARUSER_ENABLE(ARUSER_ENABLE),
            .ARUSER_WIDTH(ARUSER_WIDTH),
            .RUSER_ENABLE(RUSER_ENABLE),
            .RUSER_WIDTH(RUSER_WIDTH),
            .TARGET_TYPE(M_TARGET_TYPE[n]),
            .BRIDGE_ID_FIFO_DEPTH(M_ISSUE[n*32 +: 32])
        )
        egress_inst (
            .clk(clk),
            .rst(rst),
            .cfg_target_enable(cfg_core_enable && cfg_target_enable[n]),
            .s_axi_awid(xbar_awid[n*M_ID_WIDTH +: M_ID_WIDTH]),
            .s_axi_awaddr(xbar_awaddr[n*ADDR_WIDTH +: ADDR_WIDTH]),
            .s_axi_awlen(xbar_awlen[n*8 +: 8]),
            .s_axi_awsize(xbar_awsize[n*3 +: 3]),
            .s_axi_awburst(xbar_awburst[n*2 +: 2]),
            .s_axi_awlock(xbar_awlock[n]),
            .s_axi_awcache(xbar_awcache[n*4 +: 4]),
            .s_axi_awprot(xbar_awprot[n*3 +: 3]),
            .s_axi_awqos(xbar_awqos[n*4 +: 4]),
            .s_axi_awregion(xbar_awregion[n*4 +: 4]),
            .s_axi_awuser(xbar_awuser[n*AWUSER_WIDTH +: AWUSER_WIDTH]),
            .s_axi_awvalid(xbar_awvalid[n]),
            .s_axi_awready(xbar_awready[n]),
            .s_axi_wdata(xbar_wdata[n*DATA_WIDTH +: DATA_WIDTH]),
            .s_axi_wstrb(xbar_wstrb[n*STRB_WIDTH +: STRB_WIDTH]),
            .s_axi_wlast(xbar_wlast[n]),
            .s_axi_wuser(xbar_wuser[n*WUSER_WIDTH +: WUSER_WIDTH]),
            .s_axi_wvalid(xbar_wvalid[n]),
            .s_axi_wready(xbar_wready[n]),
            .s_axi_bid(xbar_bid[n*M_ID_WIDTH +: M_ID_WIDTH]),
            .s_axi_bresp(xbar_bresp[n*2 +: 2]),
            .s_axi_buser(xbar_buser[n*BUSER_WIDTH +: BUSER_WIDTH]),
            .s_axi_bvalid(xbar_bvalid[n]),
            .s_axi_bready(xbar_bready[n]),
            .s_axi_arid(xbar_arid[n*M_ID_WIDTH +: M_ID_WIDTH]),
            .s_axi_araddr(xbar_araddr[n*ADDR_WIDTH +: ADDR_WIDTH]),
            .s_axi_arlen(xbar_arlen[n*8 +: 8]),
            .s_axi_arsize(xbar_arsize[n*3 +: 3]),
            .s_axi_arburst(xbar_arburst[n*2 +: 2]),
            .s_axi_arlock(xbar_arlock[n]),
            .s_axi_arcache(xbar_arcache[n*4 +: 4]),
            .s_axi_arprot(xbar_arprot[n*3 +: 3]),
            .s_axi_arqos(xbar_arqos[n*4 +: 4]),
            .s_axi_arregion(xbar_arregion[n*4 +: 4]),
            .s_axi_aruser(xbar_aruser[n*ARUSER_WIDTH +: ARUSER_WIDTH]),
            .s_axi_arvalid(xbar_arvalid[n]),
            .s_axi_arready(xbar_arready[n]),
            .s_axi_rid(xbar_rid[n*M_ID_WIDTH +: M_ID_WIDTH]),
            .s_axi_rdata(xbar_rdata[n*DATA_WIDTH +: DATA_WIDTH]),
            .s_axi_rresp(xbar_rresp[n*2 +: 2]),
            .s_axi_rlast(xbar_rlast[n]),
            .s_axi_ruser(xbar_ruser[n*RUSER_WIDTH +: RUSER_WIDTH]),
            .s_axi_rvalid(xbar_rvalid[n]),
            .s_axi_rready(xbar_rready[n]),
            .m_axi_awid(m_axi_awid[n*M_ID_WIDTH +: M_ID_WIDTH]),
            .m_axi_awaddr(m_axi_awaddr[n*ADDR_WIDTH +: ADDR_WIDTH]),
            .m_axi_awlen(m_axi_awlen[n*8 +: 8]),
            .m_axi_awsize(m_axi_awsize[n*3 +: 3]),
            .m_axi_awburst(m_axi_awburst[n*2 +: 2]),
            .m_axi_awlock(m_axi_awlock[n]),
            .m_axi_awcache(m_axi_awcache[n*4 +: 4]),
            .m_axi_awprot(m_axi_awprot[n*3 +: 3]),
            .m_axi_awqos(m_axi_awqos[n*4 +: 4]),
            .m_axi_awregion(m_axi_awregion[n*4 +: 4]),
            .m_axi_awuser(m_axi_awuser[n*AWUSER_WIDTH +: AWUSER_WIDTH]),
            .m_axi_awvalid(m_axi_awvalid[n]),
            .m_axi_awready(m_axi_awready[n]),
            .m_axi_wdata(m_axi_wdata[n*DATA_WIDTH +: DATA_WIDTH]),
            .m_axi_wstrb(m_axi_wstrb[n*STRB_WIDTH +: STRB_WIDTH]),
            .m_axi_wlast(m_axi_wlast[n]),
            .m_axi_wuser(m_axi_wuser[n*WUSER_WIDTH +: WUSER_WIDTH]),
            .m_axi_wvalid(m_axi_wvalid[n]),
            .m_axi_wready(m_axi_wready[n]),
            .m_axi_bid(m_axi_bid[n*M_ID_WIDTH +: M_ID_WIDTH]),
            .m_axi_bresp(m_axi_bresp[n*2 +: 2]),
            .m_axi_buser(m_axi_buser[n*BUSER_WIDTH +: BUSER_WIDTH]),
            .m_axi_bvalid(m_axi_bvalid[n]),
            .m_axi_bready(m_axi_bready[n]),
            .m_axi_arid(m_axi_arid[n*M_ID_WIDTH +: M_ID_WIDTH]),
            .m_axi_araddr(m_axi_araddr[n*ADDR_WIDTH +: ADDR_WIDTH]),
            .m_axi_arlen(m_axi_arlen[n*8 +: 8]),
            .m_axi_arsize(m_axi_arsize[n*3 +: 3]),
            .m_axi_arburst(m_axi_arburst[n*2 +: 2]),
            .m_axi_arlock(m_axi_arlock[n]),
            .m_axi_arcache(m_axi_arcache[n*4 +: 4]),
            .m_axi_arprot(m_axi_arprot[n*3 +: 3]),
            .m_axi_arqos(m_axi_arqos[n*4 +: 4]),
            .m_axi_arregion(m_axi_arregion[n*4 +: 4]),
            .m_axi_aruser(m_axi_aruser[n*ARUSER_WIDTH +: ARUSER_WIDTH]),
            .m_axi_arvalid(m_axi_arvalid[n]),
            .m_axi_arready(m_axi_arready[n]),
            .m_axi_rid(m_axi_rid[n*M_ID_WIDTH +: M_ID_WIDTH]),
            .m_axi_rdata(m_axi_rdata[n*DATA_WIDTH +: DATA_WIDTH]),
            .m_axi_rresp(m_axi_rresp[n*2 +: 2]),
            .m_axi_rlast(m_axi_rlast[n]),
            .m_axi_ruser(m_axi_ruser[n*RUSER_WIDTH +: RUSER_WIDTH]),
            .m_axi_rvalid(m_axi_rvalid[n]),
            .m_axi_rready(m_axi_rready[n]),
            .ahb_haddr(m_ahb_haddr[n*32 +: 32]),
            .ahb_htrans(m_ahb_htrans[n*2 +: 2]),
            .ahb_hwrite(m_ahb_hwrite[n]),
            .ahb_hsize(m_ahb_hsize[n*3 +: 3]),
            .ahb_hburst(m_ahb_hburst[n*3 +: 3]),
            .ahb_hwdata(m_ahb_hwdata[n*64 +: 64]),
            .ahb_hbusreq(m_ahb_hbusreq[n]),
            .ahb_hlock(m_ahb_hlock[n]),
            .ahb_hrdata(m_ahb_hrdata[n*64 +: 64]),
            .ahb_hready(m_ahb_hready[n]),
            .ahb_hresp(m_ahb_hresp[n*2 +: 2]),
            .ahb_hgrant(m_ahb_hgrant[n]),
            .ahb_hmaster(m_ahb_hmaster[n*4 +: 4]),
            .stat_write_decerr_pulse(egress_write_decerr_pulse[n*S_COUNT +: S_COUNT]),
            .stat_read_decerr_pulse(egress_read_decerr_pulse[n*S_COUNT +: S_COUNT]),
            .fault_valid(egress_fault_valid[n]),
            .fault_code(egress_fault_code[n*8 +: 8]),
            .fault_addr(egress_fault_addr[n*ADDR_WIDTH +: ADDR_WIDTH]),
            .fault_id(egress_fault_id[n*8 +: 8]),
            .fault_src_port(egress_fault_src_port[n*8 +: 8]),
            .fault_dst_port(egress_fault_dst_port[n*8 +: 8])
        );
    end
endgenerate

axi_crossbar #(
    .S_COUNT(S_COUNT),
    .M_COUNT(M_COUNT),
    .DATA_WIDTH(DATA_WIDTH),
    .ADDR_WIDTH(ADDR_WIDTH),
    .STRB_WIDTH(STRB_WIDTH),
    .S_ID_WIDTH(S_ID_WIDTH),
    .M_ID_WIDTH(M_ID_WIDTH),
    .AWUSER_ENABLE(AWUSER_ENABLE),
    .AWUSER_WIDTH(AWUSER_WIDTH),
    .WUSER_ENABLE(WUSER_ENABLE),
    .WUSER_WIDTH(WUSER_WIDTH),
    .BUSER_ENABLE(BUSER_ENABLE),
    .BUSER_WIDTH(BUSER_WIDTH),
    .ARUSER_ENABLE(ARUSER_ENABLE),
    .ARUSER_WIDTH(ARUSER_WIDTH),
    .RUSER_ENABLE(RUSER_ENABLE),
    .RUSER_WIDTH(RUSER_WIDTH),
    .S_THREADS(S_THREADS),
    .S_ACCEPT(S_ACCEPT),
    .M_REGIONS(M_REGIONS),
    .M_BASE_ADDR(M_BASE_ADDR),
    .M_ADDR_WIDTH(M_ADDR_WIDTH),
    .M_CONNECT_READ(M_CONNECT_READ),
    .M_CONNECT_WRITE(M_CONNECT_WRITE),
    .M_ISSUE(M_ISSUE),
    .M_SECURE(M_SECURE),
    .S_AW_REG_TYPE(S_AW_REG_TYPE),
    .S_W_REG_TYPE(S_W_REG_TYPE),
    .S_B_REG_TYPE(S_B_REG_TYPE),
    .S_AR_REG_TYPE(S_AR_REG_TYPE),
    .S_R_REG_TYPE(S_R_REG_TYPE),
    .M_AW_REG_TYPE(M_AW_REG_TYPE),
    .M_W_REG_TYPE(M_W_REG_TYPE),
    .M_B_REG_TYPE(M_B_REG_TYPE),
    .M_AR_REG_TYPE(M_AR_REG_TYPE),
    .M_R_REG_TYPE(M_R_REG_TYPE)
)
crossbar_inst (
    .clk(clk),
    .rst(rst),
    .s_axi_awid(guard_awid),
    .s_axi_awaddr(guard_awaddr),
    .s_axi_awlen(guard_awlen),
    .s_axi_awsize(guard_awsize),
    .s_axi_awburst(guard_awburst),
    .s_axi_awlock(guard_awlock),
    .s_axi_awcache(guard_awcache),
    .s_axi_awprot(guard_awprot),
    .s_axi_awqos(guard_awqos),
    .s_axi_awuser(guard_awuser),
    .s_axi_awvalid(guard_awvalid),
    .s_axi_awready(guard_awready),
    .s_axi_wdata(guard_wdata),
    .s_axi_wstrb(guard_wstrb),
    .s_axi_wlast(guard_wlast),
    .s_axi_wuser(guard_wuser),
    .s_axi_wvalid(guard_wvalid),
    .s_axi_wready(guard_wready),
    .s_axi_bid(guard_bid),
    .s_axi_bresp(guard_bresp),
    .s_axi_buser(guard_buser),
    .s_axi_bvalid(guard_bvalid),
    .s_axi_bready(guard_bready),
    .s_axi_arid(guard_arid),
    .s_axi_araddr(guard_araddr),
    .s_axi_arlen(guard_arlen),
    .s_axi_arsize(guard_arsize),
    .s_axi_arburst(guard_arburst),
    .s_axi_arlock(guard_arlock),
    .s_axi_arcache(guard_arcache),
    .s_axi_arprot(guard_arprot),
    .s_axi_arqos(guard_arqos),
    .s_axi_aruser(guard_aruser),
    .s_axi_arvalid(guard_arvalid),
    .s_axi_arready(guard_arready),
    .s_axi_rid(guard_rid),
    .s_axi_rdata(guard_rdata),
    .s_axi_rresp(guard_rresp),
    .s_axi_rlast(guard_rlast),
    .s_axi_ruser(guard_ruser),
    .s_axi_rvalid(guard_rvalid),
    .s_axi_rready(guard_rready),
    .m_axi_awid(xbar_awid),
    .m_axi_awaddr(xbar_awaddr),
    .m_axi_awlen(xbar_awlen),
    .m_axi_awsize(xbar_awsize),
    .m_axi_awburst(xbar_awburst),
    .m_axi_awlock(xbar_awlock),
    .m_axi_awcache(xbar_awcache),
    .m_axi_awprot(xbar_awprot),
    .m_axi_awqos(xbar_awqos),
    .m_axi_awregion(xbar_awregion),
    .m_axi_awuser(xbar_awuser),
    .m_axi_awvalid(xbar_awvalid),
    .m_axi_awready(xbar_awready),
    .m_axi_wdata(xbar_wdata),
    .m_axi_wstrb(xbar_wstrb),
    .m_axi_wlast(xbar_wlast),
    .m_axi_wuser(xbar_wuser),
    .m_axi_wvalid(xbar_wvalid),
    .m_axi_wready(xbar_wready),
    .m_axi_bid(xbar_bid),
    .m_axi_bresp(xbar_bresp),
    .m_axi_buser(xbar_buser),
    .m_axi_bvalid(xbar_bvalid),
    .m_axi_bready(xbar_bready),
    .m_axi_arid(xbar_arid),
    .m_axi_araddr(xbar_araddr),
    .m_axi_arlen(xbar_arlen),
    .m_axi_arsize(xbar_arsize),
    .m_axi_arburst(xbar_arburst),
    .m_axi_arlock(xbar_arlock),
    .m_axi_arcache(xbar_arcache),
    .m_axi_arprot(xbar_arprot),
    .m_axi_arqos(xbar_arqos),
    .m_axi_arregion(xbar_arregion),
    .m_axi_aruser(xbar_aruser),
    .m_axi_arvalid(xbar_arvalid),
    .m_axi_arready(xbar_arready),
    .m_axi_rid(xbar_rid),
    .m_axi_rdata(xbar_rdata),
    .m_axi_rresp(xbar_rresp),
    .m_axi_rlast(xbar_rlast),
    .m_axi_ruser(xbar_ruser),
    .m_axi_rvalid(xbar_rvalid),
    .m_axi_rready(xbar_rready)
);

endmodule

`resetall
