`resetall
`timescale 1ns / 1ps
`default_nettype none

/*
 * AXI interconnect APB config and status block
 *
 * Address map
 *
 * Write-only/control space:
 *   0x000                  CORE_CTRL_W[0]
 *   0x004                  FAULT_CLEAR_W[0]
 *   0x020 + master*0x4     MASTER_CTRL_W[2:0] = {allow_writes, allow_reads, enable}
 *   0x040 + target*0x4     TARGET_CTRL_W[0]
 *
 * Read-only/status space:
 *   0x100                  VERSION_R
 *   0x104                  CORE_STATUS_R[0]
 *   0x108                  FAULT_STATUS_R[0]
 *   0x10C                  LAST_FAULT_ADDR_R
 *   0x110                  LAST_FAULT_INFO_R = {id, dst_port, src_port, code}
 *   0x120 + master*0x4     MASTER_STATUS_R[2:0]
 *   0x140 + target*0x4     TARGET_STATUS_R[1:0] = {target_type, enable}
 *   0x160 + master*0x4     MASTER_WRITE_REQ_COUNT_R
 *   0x180 + master*0x4     MASTER_READ_REQ_COUNT_R
 *   0x1A0 + master*0x4     MASTER_WRITE_DECERR_COUNT_R
 *   0x1C0 + master*0x4     MASTER_READ_DECERR_COUNT_R
 */
module axi_ic_apb_cfg #
(
    parameter S_COUNT = 4,
    parameter M_COUNT = 4,
    parameter ADDR_WIDTH = 32,
    parameter [M_COUNT-1:0] M_TARGET_TYPE = {M_COUNT{1'b0}}
)
(
    input  wire                     clk,
    input  wire                     rst,
    input  wire [11:0]              s_apb_paddr,
    input  wire                     s_apb_psel,
    input  wire                     s_apb_penable,
    input  wire                     s_apb_pwrite,
    input  wire [31:0]              s_apb_pwdata,
    output reg  [31:0]              s_apb_prdata, 
    output wire                     s_apb_pready, //配置模块ready持续拉高
    output wire                     s_apb_pslverr,

    input  wire [S_COUNT-1:0]       stat_write_req_pulse,
    input  wire [S_COUNT-1:0]       stat_read_req_pulse,
    input  wire [S_COUNT-1:0]       stat_write_decerr_pulse,
    input  wire [S_COUNT-1:0]       stat_read_decerr_pulse,

    input  wire                     fault_valid,
    input  wire [7:0]               fault_code,
    input  wire [7:0]               fault_src_port,
    input  wire [7:0]               fault_dst_port,
    input  wire [7:0]               fault_id,
    input  wire [ADDR_WIDTH-1:0]    fault_addr,

    output wire                     core_enable,
    output wire [S_COUNT-1:0]       master_enable,
    output wire [S_COUNT-1:0]       master_allow_reads,
    output wire [S_COUNT-1:0]       master_allow_writes,
    output wire [M_COUNT-1:0]       target_enable
);

localparam [31:0] VERSION = 32'h0001_0000;

localparam [11:0] CORE_CTRL_W = 12'h000;
localparam [11:0] FAULT_CLEAR_W = 12'h004;
localparam [11:0] MASTER_CTRL_W_BASE = 12'h020;
localparam [11:0] TARGET_CTRL_W_BASE = 12'h040;

localparam [11:0] VERSION_R = 12'h100;
localparam [11:0] CORE_STATUS_R = 12'h104;
localparam [11:0] FAULT_STATUS_R = 12'h108;
localparam [11:0] LAST_FAULT_ADDR_R = 12'h10C;
localparam [11:0] LAST_FAULT_INFO_R = 12'h110;
localparam [11:0] MASTER_STATUS_R_BASE = 12'h120;
localparam [11:0] TARGET_STATUS_R_BASE = 12'h140;
localparam [11:0] MASTER_WR_REQ_COUNT_R_BASE = 12'h160;
localparam [11:0] MASTER_RD_REQ_COUNT_R_BASE = 12'h180;
localparam [11:0] MASTER_WR_DECERR_COUNT_R_BASE = 12'h1A0;
localparam [11:0] MASTER_RD_DECERR_COUNT_R_BASE = 12'h1C0;
localparam integer REG_STRIDE = 4;

reg core_enable_reg = 1'b1;
reg fault_pending_reg = 1'b0;
reg [ADDR_WIDTH-1:0] last_fault_addr_reg = {ADDR_WIDTH{1'b0}};
reg [31:0] last_fault_info_reg = 32'd0;

reg [S_COUNT-1:0] master_enable_reg = {S_COUNT{1'b1}};
reg [S_COUNT-1:0] master_allow_reads_reg = {S_COUNT{1'b1}};
reg [S_COUNT-1:0] master_allow_writes_reg = {S_COUNT{1'b1}};
reg [M_COUNT-1:0] target_enable_reg = {M_COUNT{1'b1}};

reg [31:0] master_write_req_count_reg [0:S_COUNT-1];
reg [31:0] master_read_req_count_reg [0:S_COUNT-1];
reg [31:0] master_write_decerr_count_reg [0:S_COUNT-1];
reg [31:0] master_read_decerr_count_reg [0:S_COUNT-1];

wire apb_access = s_apb_psel && s_apb_penable;  //phase阶段
wire apb_write = apb_access && s_apb_pwrite;

integer i;
integer idx;
integer base_addr;

function automatic is_addr_in_array;
    input [11:0] addr;
    input [11:0] base;
    input integer count;
    integer k;
    begin
        is_addr_in_array = 1'b0;
        for (k = 0; k < count; k = k + 1) begin
            if (addr == ((base + k*REG_STRIDE) & 12'hfff)) begin
                is_addr_in_array = 1'b1;
            end
        end
    end
endfunction

wire apb_write_valid =
    s_apb_paddr == CORE_CTRL_W ||
    s_apb_paddr == FAULT_CLEAR_W ||
    is_addr_in_array(s_apb_paddr, MASTER_CTRL_W_BASE, S_COUNT) ||
    is_addr_in_array(s_apb_paddr, TARGET_CTRL_W_BASE, M_COUNT);

wire apb_read_valid =
    s_apb_paddr == VERSION_R ||
    s_apb_paddr == CORE_STATUS_R ||
    s_apb_paddr == FAULT_STATUS_R ||
    s_apb_paddr == LAST_FAULT_ADDR_R ||
    s_apb_paddr == LAST_FAULT_INFO_R ||
    is_addr_in_array(s_apb_paddr, MASTER_STATUS_R_BASE, S_COUNT) ||
    is_addr_in_array(s_apb_paddr, TARGET_STATUS_R_BASE, M_COUNT) ||
    is_addr_in_array(s_apb_paddr, MASTER_WR_REQ_COUNT_R_BASE, S_COUNT) ||
    is_addr_in_array(s_apb_paddr, MASTER_RD_REQ_COUNT_R_BASE, S_COUNT) ||
    is_addr_in_array(s_apb_paddr, MASTER_WR_DECERR_COUNT_R_BASE, S_COUNT) ||
    is_addr_in_array(s_apb_paddr, MASTER_RD_DECERR_COUNT_R_BASE, S_COUNT);

always @(posedge clk) begin
    if (rst) begin
        core_enable_reg <= 1'b1;
        fault_pending_reg <= 1'b0;
        last_fault_addr_reg <= {ADDR_WIDTH{1'b0}};
        last_fault_info_reg <= 32'd0;
        master_enable_reg <= {S_COUNT{1'b1}};
        master_allow_reads_reg <= {S_COUNT{1'b1}};
        master_allow_writes_reg <= {S_COUNT{1'b1}};
        target_enable_reg <= {M_COUNT{1'b1}};

        for (i = 0; i < S_COUNT; i = i + 1) begin
            master_write_req_count_reg[i] <= 32'd0;
            master_read_req_count_reg[i] <= 32'd0;
            master_write_decerr_count_reg[i] <= 32'd0;
            master_read_decerr_count_reg[i] <= 32'd0;
        end
    end else begin
        for (i = 0; i < S_COUNT; i = i + 1) begin
            if (stat_write_req_pulse[i]) begin
                master_write_req_count_reg[i] <= master_write_req_count_reg[i] + 1'b1;
            end
            if (stat_read_req_pulse[i]) begin
                master_read_req_count_reg[i] <= master_read_req_count_reg[i] + 1'b1;
            end
            if (stat_write_decerr_pulse[i]) begin
                master_write_decerr_count_reg[i] <= master_write_decerr_count_reg[i] + 1'b1;
            end
            if (stat_read_decerr_pulse[i]) begin
                master_read_decerr_count_reg[i] <= master_read_decerr_count_reg[i] + 1'b1;
            end
        end

        if (fault_valid) begin
            fault_pending_reg <= 1'b1;
            last_fault_addr_reg <= fault_addr;
            last_fault_info_reg <= {fault_id, fault_dst_port, fault_src_port, fault_code};
        end

        if (apb_write) begin
            case (s_apb_paddr)
                CORE_CTRL_W: begin
                    core_enable_reg <= s_apb_pwdata[0];
                end
                FAULT_CLEAR_W: begin
                    if (s_apb_pwdata[0]) begin
                        fault_pending_reg <= 1'b0;
                    end
                end
                default: begin
                    for (idx = 0; idx < S_COUNT; idx = idx + 1) begin
                        base_addr = MASTER_CTRL_W_BASE + idx*REG_STRIDE;
                        if (s_apb_paddr == base_addr[11:0]) begin
                            master_enable_reg[idx] <= s_apb_pwdata[0];
                            master_allow_reads_reg[idx] <= s_apb_pwdata[1];
                            master_allow_writes_reg[idx] <= s_apb_pwdata[2];
                        end
                    end

                    for (idx = 0; idx < M_COUNT; idx = idx + 1) begin
                        base_addr = TARGET_CTRL_W_BASE + idx*REG_STRIDE;
                        if (s_apb_paddr == base_addr[11:0]) begin
                            target_enable_reg[idx] <= s_apb_pwdata[0];
                        end
                    end
                end
            endcase
        end
    end
end

always @* begin
    s_apb_prdata = 32'd0;

    case (s_apb_paddr)
        VERSION_R: s_apb_prdata = VERSION;
        CORE_STATUS_R: s_apb_prdata = {31'd0, core_enable_reg};
        FAULT_STATUS_R: s_apb_prdata = {31'd0, fault_pending_reg};
        LAST_FAULT_ADDR_R: s_apb_prdata = last_fault_addr_reg[31:0];
        LAST_FAULT_INFO_R: s_apb_prdata = last_fault_info_reg;
        default: begin
            for (idx = 0; idx < S_COUNT; idx = idx + 1) begin
                base_addr = MASTER_STATUS_R_BASE + idx*REG_STRIDE;
                if (s_apb_paddr == base_addr[11:0]) begin
                    s_apb_prdata = {29'd0, master_allow_writes_reg[idx], master_allow_reads_reg[idx], master_enable_reg[idx]};
                end

                base_addr = MASTER_WR_REQ_COUNT_R_BASE + idx*REG_STRIDE;
                if (s_apb_paddr == base_addr[11:0]) begin
                    s_apb_prdata = master_write_req_count_reg[idx];
                end

                base_addr = MASTER_RD_REQ_COUNT_R_BASE + idx*REG_STRIDE;
                if (s_apb_paddr == base_addr[11:0]) begin
                    s_apb_prdata = master_read_req_count_reg[idx];
                end

                base_addr = MASTER_WR_DECERR_COUNT_R_BASE + idx*REG_STRIDE;
                if (s_apb_paddr == base_addr[11:0]) begin
                    s_apb_prdata = master_write_decerr_count_reg[idx];
                end

                base_addr = MASTER_RD_DECERR_COUNT_R_BASE + idx*REG_STRIDE;
                if (s_apb_paddr == base_addr[11:0]) begin
                    s_apb_prdata = master_read_decerr_count_reg[idx];
                end
            end

            for (idx = 0; idx < M_COUNT; idx = idx + 1) begin
                base_addr = TARGET_STATUS_R_BASE + idx*REG_STRIDE;
                if (s_apb_paddr == base_addr[11:0]) begin
                    s_apb_prdata = {30'd0, M_TARGET_TYPE[idx], target_enable_reg[idx]};
                end
            end
        end
    endcase
end

assign s_apb_pready = 1'b1;
assign s_apb_pslverr = apb_access && (s_apb_pwrite ? !apb_write_valid : !apb_read_valid);

assign core_enable = core_enable_reg;
assign master_enable = master_enable_reg;
assign master_allow_reads = master_allow_reads_reg;
assign master_allow_writes = master_allow_writes_reg;
assign target_enable = target_enable_reg;

endmodule

`resetall
