`timescale 1ns / 1ps
`default_nettype none

module tb_axi_crossbar_wr_decode_err_count;

    localparam int S_COUNT = 2;
    localparam int M_COUNT = 2;
    localparam int DATA_WIDTH = 32;
    localparam int ADDR_WIDTH = 32;
    localparam int STRB_WIDTH = DATA_WIDTH/8;
    localparam int S_ID_WIDTH = 8;
    localparam int M_ID_WIDTH = S_ID_WIDTH + $clog2(S_COUNT);
    localparam int S_THREADS_PER_SRC = 1;
    localparam int S_ACCEPT_PER_SRC = 2;
    localparam int TRANS_COUNT_W = $clog2(S_ACCEPT_PER_SRC+1);
    localparam [S_COUNT*32-1:0] S_THREADS = {32'd1, 32'd1};
    localparam [S_COUNT*32-1:0] S_ACCEPT = {32'd2, 32'd2};
    localparam [M_COUNT*32-1:0] M_ISSUE = {32'd2, 32'd2};
    localparam [M_COUNT*ADDR_WIDTH-1:0] M_BASE_ADDR = {32'h0001_0000, 32'h0000_0000};
    localparam [M_COUNT*32-1:0] M_ADDR_WIDTH = {32'd16, 32'd16};
    localparam [M_COUNT*S_COUNT-1:0] M_CONNECT = {M_COUNT{ {S_COUNT{1'b1}} }};
    localparam [TRANS_COUNT_W-1:0] TRANS_COUNT_UNDERFLOW = {TRANS_COUNT_W{1'b1}};
    localparam [ADDR_WIDTH-1:0] VALID_ADDR_M0 = 32'h0000_0010;
    localparam [ADDR_WIDTH-1:0] INVALID_ADDR  = 32'h0002_0000;

    logic clk = 1'b0;
    logic rst = 1'b0;

    logic [S_COUNT*S_ID_WIDTH-1:0] s_axi_awid = '0;
    logic [S_COUNT*ADDR_WIDTH-1:0] s_axi_awaddr = '0;
    logic [S_COUNT*8-1:0] s_axi_awlen = '0;
    logic [S_COUNT*3-1:0] s_axi_awsize = '0;
    logic [S_COUNT*2-1:0] s_axi_awburst = '0;
    logic [S_COUNT-1:0] s_axi_awlock = '0;
    logic [S_COUNT*4-1:0] s_axi_awcache = '0;
    logic [S_COUNT*3-1:0] s_axi_awprot = '0;
    logic [S_COUNT*4-1:0] s_axi_awqos = '0;
    logic [S_COUNT-1:0] s_axi_awvalid = '0;
    wire [S_COUNT-1:0] s_axi_awready;

    logic [S_COUNT*DATA_WIDTH-1:0] s_axi_wdata = '0;
    logic [S_COUNT*STRB_WIDTH-1:0] s_axi_wstrb = '0;
    logic [S_COUNT-1:0] s_axi_wlast = '0;
    logic [S_COUNT-1:0] s_axi_wvalid = '0;
    wire [S_COUNT-1:0] s_axi_wready;

    wire [S_COUNT*S_ID_WIDTH-1:0] s_axi_bid;
    wire [S_COUNT*2-1:0] s_axi_bresp;
    wire [S_COUNT-1:0] s_axi_bvalid;
    logic [S_COUNT-1:0] s_axi_bready = '0;

    wire [M_COUNT*M_ID_WIDTH-1:0] m_axi_awid;
    wire [M_COUNT*ADDR_WIDTH-1:0] m_axi_awaddr;
    wire [M_COUNT*8-1:0] m_axi_awlen;
    wire [M_COUNT*3-1:0] m_axi_awsize;
    wire [M_COUNT*2-1:0] m_axi_awburst;
    wire [M_COUNT-1:0] m_axi_awlock;
    wire [M_COUNT*4-1:0] m_axi_awcache;
    wire [M_COUNT*3-1:0] m_axi_awprot;
    wire [M_COUNT*4-1:0] m_axi_awqos;
    wire [M_COUNT*4-1:0] m_axi_awregion;
    wire [M_COUNT-1:0] m_axi_awvalid;
    logic [M_COUNT-1:0] m_axi_awready = '1;

    wire [M_COUNT*DATA_WIDTH-1:0] m_axi_wdata;
    wire [M_COUNT*STRB_WIDTH-1:0] m_axi_wstrb;
    wire [M_COUNT-1:0] m_axi_wlast;
    wire [M_COUNT-1:0] m_axi_wvalid;
    logic [M_COUNT-1:0] m_axi_wready = '1;

    logic [M_COUNT*M_ID_WIDTH-1:0] m_axi_bid = '0;
    logic [M_COUNT*2-1:0] m_axi_bresp = '0;
    logic [M_COUNT-1:0] m_axi_bvalid = '0;
    wire [M_COUNT-1:0] m_axi_bready;

    wire [M_COUNT-1:0] unused_m_axi_buser;
    wire [M_COUNT-1:0] unused_s_axi_buser;
    wire [M_COUNT-1:0] unused_m_axi_awuser;
    wire [M_COUNT-1:0] unused_m_axi_wuser;

    integer aw_handshakes_m0 = 0;
    integer aw_handshakes_m1 = 0;
    integer w_handshakes_m0 = 0;
    integer w_handshakes_m1 = 0;
    logic [M_ID_WIDTH-1:0] captured_awid_m0 = '0;

    axi_crossbar_wr #(
        .S_COUNT(S_COUNT),
        .M_COUNT(M_COUNT),
        .DATA_WIDTH(DATA_WIDTH),
        .ADDR_WIDTH(ADDR_WIDTH),
        .STRB_WIDTH(STRB_WIDTH),
        .S_ID_WIDTH(S_ID_WIDTH),
        .M_ID_WIDTH(M_ID_WIDTH),
        .S_THREADS(S_THREADS),
        .S_ACCEPT(S_ACCEPT),
        .M_BASE_ADDR(M_BASE_ADDR),
        .M_ADDR_WIDTH(M_ADDR_WIDTH),
        .M_CONNECT(M_CONNECT),
        .M_ISSUE(M_ISSUE),
        .S_AW_REG_TYPE({S_COUNT{2'd0}}),
        .S_W_REG_TYPE({S_COUNT{2'd0}}),
        .S_B_REG_TYPE({S_COUNT{2'd0}}),
        .M_AW_REG_TYPE({M_COUNT{2'd0}}),
        .M_W_REG_TYPE({M_COUNT{2'd0}}),
        .M_B_REG_TYPE({M_COUNT{2'd0}})
    )
    dut (
        .clk(clk),
        .rst(rst),
        .s_axi_awid(s_axi_awid),
        .s_axi_awaddr(s_axi_awaddr),
        .s_axi_awlen(s_axi_awlen),
        .s_axi_awsize(s_axi_awsize),
        .s_axi_awburst(s_axi_awburst),
        .s_axi_awlock(s_axi_awlock),
        .s_axi_awcache(s_axi_awcache),
        .s_axi_awprot(s_axi_awprot),
        .s_axi_awqos(s_axi_awqos),
        .s_axi_awuser({S_COUNT{1'b0}}),
        .s_axi_awvalid(s_axi_awvalid),
        .s_axi_awready(s_axi_awready),
        .s_axi_wdata(s_axi_wdata),
        .s_axi_wstrb(s_axi_wstrb),
        .s_axi_wlast(s_axi_wlast),
        .s_axi_wuser({S_COUNT{1'b0}}),
        .s_axi_wvalid(s_axi_wvalid),
        .s_axi_wready(s_axi_wready),
        .s_axi_bid(s_axi_bid),
        .s_axi_bresp(s_axi_bresp),
        .s_axi_buser(unused_s_axi_buser),
        .s_axi_bvalid(s_axi_bvalid),
        .s_axi_bready(s_axi_bready),
        .m_axi_awid(m_axi_awid),
        .m_axi_awaddr(m_axi_awaddr),
        .m_axi_awlen(m_axi_awlen),
        .m_axi_awsize(m_axi_awsize),
        .m_axi_awburst(m_axi_awburst),
        .m_axi_awlock(m_axi_awlock),
        .m_axi_awcache(m_axi_awcache),
        .m_axi_awprot(m_axi_awprot),
        .m_axi_awqos(m_axi_awqos),
        .m_axi_awregion(m_axi_awregion),
        .m_axi_awuser(unused_m_axi_awuser),
        .m_axi_awvalid(m_axi_awvalid),
        .m_axi_awready(m_axi_awready),
        .m_axi_wdata(m_axi_wdata),
        .m_axi_wstrb(m_axi_wstrb),
        .m_axi_wlast(m_axi_wlast),
        .m_axi_wuser(unused_m_axi_wuser),
        .m_axi_wvalid(m_axi_wvalid),
        .m_axi_wready(m_axi_wready),
        .m_axi_bid(m_axi_bid),
        .m_axi_bresp(m_axi_bresp),
        .m_axi_buser({M_COUNT{1'b0}}),
        .m_axi_bvalid(m_axi_bvalid),
        .m_axi_bready(m_axi_bready)
    );

    always #5 clk = ~clk;

    always @(posedge clk) begin
        if (rst) begin
            aw_handshakes_m0 <= 0;
            aw_handshakes_m1 <= 0;
            w_handshakes_m0 <= 0;
            w_handshakes_m1 <= 0;
            captured_awid_m0 <= '0;
        end else begin
            if (m_axi_awvalid[0] && m_axi_awready[0]) begin
                aw_handshakes_m0 <= aw_handshakes_m0 + 1;
                captured_awid_m0 <= m_axi_awid[0 +: M_ID_WIDTH];
            end
            if (m_axi_awvalid[1] && m_axi_awready[1]) begin
                aw_handshakes_m1 <= aw_handshakes_m1 + 1;
            end
            if (m_axi_wvalid[0] && m_axi_wready[0]) begin
                w_handshakes_m0 <= w_handshakes_m0 + 1;
            end
            if (m_axi_wvalid[1] && m_axi_wready[1]) begin
                w_handshakes_m1 <= w_handshakes_m1 + 1;
            end
        end
    end

    task automatic reset_dut;
    begin
        s_axi_awid = '0;
        s_axi_awaddr = '0;
        s_axi_awlen = '0;
        s_axi_awsize = '0;
        s_axi_awburst = '0;
        s_axi_awlock = '0;
        s_axi_awcache = '0;
        s_axi_awprot = '0;
        s_axi_awqos = '0;
        s_axi_awvalid = '0;
        s_axi_wdata = '0;
        s_axi_wstrb = '0;
        s_axi_wlast = '0;
        s_axi_wvalid = '0;
        s_axi_bready = '0;
        m_axi_bid = '0;
        m_axi_bresp = '0;
        m_axi_bvalid = '0;
        rst = 1'b1;
        repeat (4) @(posedge clk);
        rst = 1'b0;
        repeat (2) @(posedge clk);
    end
    endtask

    task automatic send_aw(
        input [S_ID_WIDTH-1:0] id,
        input [ADDR_WIDTH-1:0] addr
    );
    begin
        @(posedge clk);
        s_axi_awid[0 +: S_ID_WIDTH] = id;
        s_axi_awaddr[0 +: ADDR_WIDTH] = addr;
        s_axi_awlen[0 +: 8] = 8'd0;
        s_axi_awsize[0 +: 3] = 3'd2;
        s_axi_awburst[0 +: 2] = 2'b01;
        s_axi_awlock[0] = 1'b0;
        s_axi_awcache[0 +: 4] = 4'b0011;
        s_axi_awprot[0 +: 3] = 3'b000;
        s_axi_awqos[0 +: 4] = 4'd0;
        s_axi_awvalid[0] = 1'b1;

        begin : wait_aw_handshake
            while (1) begin
                @(posedge clk);
                if (s_axi_awvalid[0] && s_axi_awready[0]) begin
                    s_axi_awvalid[0] = 1'b0;
                    disable wait_aw_handshake;
                end
            end
        end
    end
    endtask

    task automatic send_wlast(input [DATA_WIDTH-1:0] data);
    begin
        @(posedge clk);
        s_axi_wdata[0 +: DATA_WIDTH] = data;
        s_axi_wstrb[0 +: STRB_WIDTH] = {STRB_WIDTH{1'b1}};
        s_axi_wlast[0] = 1'b1;
        s_axi_wvalid[0] = 1'b1;

        begin : wait_w_handshake
            while (1) begin
                @(posedge clk);
                if (s_axi_wvalid[0] && s_axi_wready[0]) begin
                    s_axi_wvalid[0] = 1'b0;
                    s_axi_wlast[0] = 1'b0;
                    disable wait_w_handshake;
                end
            end
        end
    end
    endtask

    task automatic accept_upstream_b(
        input [S_ID_WIDTH-1:0] expected_id,
        input [1:0] expected_resp
    );
    begin
        @(posedge clk);
        s_axi_bready[0] = 1'b1;

        begin : wait_upstream_b_handshake
            while (1) begin
                @(posedge clk);
                if (s_axi_bvalid[0] && s_axi_bready[0]) begin
                    if (s_axi_bid[0 +: S_ID_WIDTH] !== expected_id) begin
                        $display("FAIL unexpected BID: got %0h expected %0h", s_axi_bid[0 +: S_ID_WIDTH], expected_id);
                        $fatal;
                    end
                    if (s_axi_bresp[0 +: 2] !== expected_resp) begin
                        $display("FAIL unexpected BRESP: got %0h expected %0h", s_axi_bresp[0 +: 2], expected_resp);
                        $fatal;
                    end
                    s_axi_bready[0] = 1'b0;
                    disable wait_upstream_b_handshake;
                end
            end
        end
    end
    endtask

    task automatic return_downstream_b0(
        input [M_ID_WIDTH-1:0] bid,
        input [1:0] bresp
    );
    begin
        @(posedge clk);
        m_axi_bid[0 +: M_ID_WIDTH] = bid;
        m_axi_bresp[0 +: 2] = bresp;
        m_axi_bvalid[0] = 1'b1;

        begin : wait_downstream_b_handshake
            while (1) begin
                @(posedge clk);
                if (m_axi_bvalid[0] && m_axi_bready[0]) begin
                    m_axi_bvalid[0] = 1'b0;
                    disable wait_downstream_b_handshake;
                end
            end
        end
    end
    endtask

    initial begin : test_main
        integer aw_before_decode;
        integer w_before_decode;

        // Scenario 1: isolated decode error completion underflows trans_count_reg.
        reset_dut();

        send_aw(8'h11, INVALID_ADDR);
        send_wlast(32'hDEAD_B001);

        if (aw_handshakes_m0 != 0 || aw_handshakes_m1 != 0 || w_handshakes_m0 != 0 || w_handshakes_m1 != 0) begin
            $display("FAIL decode error write must not handshake on downstream AW/W");
            $fatal;
        end

        accept_upstream_b(8'h11, 2'b11);
        @(posedge clk);

        if (dut.s_ifaces[0].addr_inst.trans_count_reg !== TRANS_COUNT_UNDERFLOW) begin
            $display("FAIL expected trans_count_reg underflow, got %0d", dut.s_ifaces[0].addr_inst.trans_count_reg);
            $fatal;
        end

        $display("PASS scenario 1: isolated decode error underflow reproduced, trans_count_reg=%0d", dut.s_ifaces[0].addr_inst.trans_count_reg);

        // Scenario 2: same-ID decode error completion clears active thread.
        reset_dut();

        send_aw(8'h03, VALID_ADDR_M0);
        send_wlast(32'h1234_5678);

        repeat (2) @(posedge clk);
        $display("INFO scenario 2 route counts before decode error: aw0=%0d w0=%0d aw1=%0d w1=%0d trans=%0d thread0=%0d",
            aw_handshakes_m0, w_handshakes_m0, aw_handshakes_m1, w_handshakes_m1,
            dut.s_ifaces[0].addr_inst.trans_count_reg, dut.s_ifaces[0].addr_inst.thread_count_reg[0]);

        if (aw_handshakes_m0 != 1 || w_handshakes_m0 != 1 || aw_handshakes_m1 != 0 || w_handshakes_m1 != 0) begin
            $display("FAIL normal write did not route cleanly to M0 (aw0=%0d w0=%0d aw1=%0d w1=%0d)",
                aw_handshakes_m0, w_handshakes_m0, aw_handshakes_m1, w_handshakes_m1);
            $fatal;
        end

        if (dut.s_ifaces[0].addr_inst.thread_count_reg[0] !== 1) begin
            $display("FAIL expected one active thread after normal write, got %0d", dut.s_ifaces[0].addr_inst.thread_count_reg[0]);
            $fatal;
        end

        if (dut.s_ifaces[0].addr_inst.thread_id_reg[0] !== 8'h03) begin
            $display("FAIL expected active thread ID 0x03, got %0h", dut.s_ifaces[0].addr_inst.thread_id_reg[0]);
            $fatal;
        end

        if (dut.s_ifaces[0].addr_inst.trans_count_reg !== 1) begin
            $display("FAIL expected trans_count_reg=1 with one normal outstanding write, got %0d", dut.s_ifaces[0].addr_inst.trans_count_reg);
            $fatal;
        end

        aw_before_decode = aw_handshakes_m0;
        w_before_decode = w_handshakes_m0;

        send_aw(8'h03, INVALID_ADDR);
        send_wlast(32'hCAFE_0003);

        if (aw_handshakes_m0 != aw_before_decode || w_handshakes_m0 != w_before_decode || aw_handshakes_m1 != 0 || w_handshakes_m1 != 0) begin
            $display("FAIL decode error write must not create extra downstream AW/W handshakes");
            $fatal;
        end

        accept_upstream_b(8'h03, 2'b11);
        @(posedge clk);

        if (dut.s_ifaces[0].addr_inst.thread_count_reg[0] !== 0) begin
            $display("FAIL expected same-ID decode error to prematurely clear thread_count_reg[0], got %0d", dut.s_ifaces[0].addr_inst.thread_count_reg[0]);
            $fatal;
        end

        if (dut.s_ifaces[0].addr_inst.trans_count_reg !== 0) begin
            $display("FAIL expected trans_count_reg to drop to 0 while normal write is still outstanding, got %0d", dut.s_ifaces[0].addr_inst.trans_count_reg);
            $fatal;
        end

        if (m_axi_bvalid[0] !== 1'b0) begin
            $display("FAIL normal downstream B response should still be absent in scenario 2");
            $fatal;
        end

        $display("PASS scenario 2: same-ID decode error prematurely cleared the active thread");
        $display("PASS tb_axi_crossbar_wr_decode_err_count completed");
        $finish;
    end

endmodule

`resetall
