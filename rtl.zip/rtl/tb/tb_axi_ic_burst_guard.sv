`timescale 1ns / 1ps

module tb_axi_ic_burst_guard;

    localparam ADDR_WIDTH = 32;

    logic [ADDR_WIDTH-1:0] addr;
    logic [7:0] len;
    logic [2:0] size;
    logic [1:0] burst;

    wire valid;
    wire crosses_4k;
    wire unsupported_burst;
    wire [8:0] beat_count;
    wire [ADDR_WIDTH-1:0] bytes_per_beat;
    wire [ADDR_WIDTH-1:0] burst_bytes;
    wire [ADDR_WIDTH-1:0] span_start;
    wire [ADDR_WIDTH-1:0] span_end;

    axi_ic_burst_guard #(
        .ADDR_WIDTH(ADDR_WIDTH)
    )
    dut (
        .addr(addr),
        .len(len),
        .size(size),
        .burst(burst),
        .valid(valid),
        .crosses_4k(crosses_4k),
        .unsupported_burst(unsupported_burst),
        .beat_count(beat_count),
        .bytes_per_beat(bytes_per_beat),
        .burst_bytes(burst_bytes),
        .span_start(span_start),
        .span_end(span_end)
    );

    task expect_case(
        input [ADDR_WIDTH-1:0] t_addr,
        input [7:0] t_len,
        input [2:0] t_size,
        input [1:0] t_burst,
        input bit t_valid,
        input bit t_crosses_4k,
        input bit t_unsupported_burst,
        input [8:0] t_beat_count,
        input [ADDR_WIDTH-1:0] t_bytes_per_beat,
        input [ADDR_WIDTH-1:0] t_burst_bytes,
        input [ADDR_WIDTH-1:0] t_span_start,
        input [ADDR_WIDTH-1:0] t_span_end,
        input [255:0] name
    );
    begin
        addr = t_addr;
        len = t_len;
        size = t_size;
        burst = t_burst;
        #1;

        if (valid !== t_valid) begin
            $display("FAIL %0s: valid expected %0d got %0d", name, t_valid, valid);
            $fatal;
        end
        if (crosses_4k !== t_crosses_4k) begin
            $display("FAIL %0s: crosses_4k expected %0d got %0d", name, t_crosses_4k, crosses_4k);
            $fatal;
        end
        if (unsupported_burst !== t_unsupported_burst) begin
            $display("FAIL %0s: unsupported_burst expected %0d got %0d", name, t_unsupported_burst, unsupported_burst);
            $fatal;
        end
        if (beat_count !== t_beat_count) begin
            $display("FAIL %0s: beat_count expected %0d got %0d", name, t_beat_count, beat_count);
            $fatal;
        end
        if (bytes_per_beat !== t_bytes_per_beat) begin
            $display("FAIL %0s: bytes_per_beat expected 0x%08h got 0x%08h", name, t_bytes_per_beat, bytes_per_beat);
            $fatal;
        end
        if (burst_bytes !== t_burst_bytes) begin
            $display("FAIL %0s: burst_bytes expected 0x%08h got 0x%08h", name, t_burst_bytes, burst_bytes);
            $fatal;
        end
        if (span_start !== t_span_start) begin
            $display("FAIL %0s: span_start expected 0x%08h got 0x%08h", name, t_span_start, span_start);
            $fatal;
        end
        if (span_end !== t_span_end) begin
            $display("FAIL %0s: span_end expected 0x%08h got 0x%08h", name, t_span_end, span_end);
            $fatal;
        end
    end
    endtask

    initial begin
        expect_case(32'h0000_0020, 8'd0, 3'd2, 2'b00, 1'b1, 1'b0, 1'b0, 9'd1,
            32'd4, 32'd4, 32'h0000_0020, 32'h0000_0023,
            "fixed_single");

        expect_case(32'h0000_0FF0, 8'd3, 3'd2, 2'b01, 1'b1, 1'b0, 1'b0, 9'd4,
            32'd4, 32'd16, 32'h0000_0FF0, 32'h0000_0FFF,
            "incr_last_word_in_page");

        expect_case(32'h0000_0FFC, 8'd1, 3'd2, 2'b01, 1'b0, 1'b1, 1'b0, 9'd2,
            32'd4, 32'd8, 32'h0000_0FFC, 32'h0000_1003,
            "incr_crosses_4k");

        expect_case(32'h0000_0034, 8'd3, 3'd2, 2'b10, 1'b1, 1'b0, 1'b0, 9'd4,
            32'd4, 32'd16, 32'h0000_0030, 32'h0000_003F,
            "wrap_len4_valid");

        expect_case(32'h0000_0030, 8'd5, 3'd2, 2'b10, 1'b0, 1'b0, 1'b0, 9'd6,
            32'd4, 32'd24, 32'h0000_0030, 32'h0000_0047,
            "wrap_len6_invalid");

        expect_case(32'h0000_0000, 8'd0, 3'd2, 2'b11, 1'b0, 1'b0, 1'b1, 9'd1,
            32'd4, 32'd4, 32'h0000_0000, 32'h0000_0003,
            "unsupported_burst");

        $display("PASS tb_axi_ic_burst_guard");
        $finish;
    end

endmodule
