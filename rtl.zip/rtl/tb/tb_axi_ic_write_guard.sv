`timescale 1ns / 1ps

module tb_axi_ic_write_guard;

    localparam DATA_WIDTH = 32;
    localparam ADDR_WIDTH = 32;
    localparam STRB_WIDTH = DATA_WIDTH/8;
    localparam ID_WIDTH = 8;
    localparam DECERR_ADDR = 32'hFFFF_F000;

    logic clk = 1'b0;
    logic rst = 1'b0;

    logic [ID_WIDTH-1:0] s_axi_awid = '0;
    logic [ADDR_WIDTH-1:0] s_axi_awaddr = '0;
    logic [7:0] s_axi_awlen = '0;
    logic [2:0] s_axi_awsize = '0;
    logic [1:0] s_axi_awburst = '0;
    logic s_axi_awlock = 1'b0;
    logic [3:0] s_axi_awcache = '0;
    logic [2:0] s_axi_awprot = '0;
    logic [3:0] s_axi_awqos = '0;
    logic s_axi_awvalid = 1'b0;
    wire s_axi_awready;
    logic [DATA_WIDTH-1:0] s_axi_wdata = '0;
    logic [STRB_WIDTH-1:0] s_axi_wstrb = '0;
    logic s_axi_wlast = 1'b0;
    logic s_axi_wvalid = 1'b0;
    wire s_axi_wready;
    wire [ID_WIDTH-1:0] s_axi_bid;
    wire [1:0] s_axi_bresp;
    wire s_axi_bvalid;
    logic s_axi_bready = 1'b1;

    wire [ID_WIDTH-1:0] m_axi_awid;
    wire [ADDR_WIDTH-1:0] m_axi_awaddr;
    wire [7:0] m_axi_awlen;
    wire [2:0] m_axi_awsize;
    wire [1:0] m_axi_awburst;
    wire m_axi_awlock;
    wire [3:0] m_axi_awcache;
    wire [2:0] m_axi_awprot;
    wire [3:0] m_axi_awqos;
    wire m_axi_awvalid;
    logic m_axi_awready = 1'b1;
    wire [DATA_WIDTH-1:0] m_axi_wdata;
    wire [STRB_WIDTH-1:0] m_axi_wstrb;
    wire m_axi_wlast;
    wire m_axi_wvalid;
    logic m_axi_wready = 1'b1;
    logic [ID_WIDTH-1:0] m_axi_bid = '0;
    logic [1:0] m_axi_bresp = '0;
    logic m_axi_bvalid = 1'b0;
    wire m_axi_bready;
    logic seen_downstream_aw = 1'b0;
    logic seen_downstream_w = 1'b0;
    logic [ADDR_WIDTH-1:0] last_downstream_awaddr = '0;
    logic [1:0] last_downstream_awburst = '0;
    logic [DATA_WIDTH-1:0] last_downstream_wdata = '0;

    axi_ic_write_guard #(
        .DATA_WIDTH(DATA_WIDTH),
        .ADDR_WIDTH(ADDR_WIDTH),
        .STRB_WIDTH(STRB_WIDTH),
        .ID_WIDTH(ID_WIDTH),
        .DECERR_ADDR(DECERR_ADDR)
    )
    dut (
        .clk(clk),
        .rst(rst),
        .cfg_master_enable(1'b1),
        .cfg_allow_writes(1'b1),
        .s_axi_awid(s_axi_awid),
        .s_axi_awaddr(s_axi_awaddr),
        .s_axi_awlen(s_axi_awlen),
        .s_axi_awsize(s_axi_awsize),
        .s_axi_awburst(s_axi_awburst),
        .s_axi_awlock(s_axi_awlock),
        .s_axi_awcache(s_axi_awcache),
        .s_axi_awprot(s_axi_awprot),
        .s_axi_awqos(s_axi_awqos),
        .s_axi_awvalid(s_axi_awvalid),
        .s_axi_awready(s_axi_awready),
        .s_axi_wdata(s_axi_wdata),
        .s_axi_wstrb(s_axi_wstrb),
        .s_axi_wlast(s_axi_wlast),
        .s_axi_wvalid(s_axi_wvalid),
        .s_axi_wready(s_axi_wready),
        .s_axi_bid(s_axi_bid),
        .s_axi_bresp(s_axi_bresp),
        .s_axi_bvalid(s_axi_bvalid),
        .s_axi_bready(s_axi_bready),
        .m_axi_awid(m_axi_awid),
        .m_axi_awaddr(m_axi_awaddr),
        .m_axi_awlen(m_axi_awlen),
        .m_axi_awsize(m_axi_awsize),
        .m_axi_awburst(m_axi_awburst),
        .m_axi_awlock(m_axi_awlock),
        .m_axi_awcache(m_axi_awcache),
        .m_axi_awprot(m_axi_awprot),
        .m_axi_awqos(m_axi_awqos),
        .m_axi_awvalid(m_axi_awvalid),
        .m_axi_awready(m_axi_awready),
        .m_axi_wdata(m_axi_wdata),
        .m_axi_wstrb(m_axi_wstrb),
        .m_axi_wlast(m_axi_wlast),
        .m_axi_wvalid(m_axi_wvalid),
        .m_axi_wready(m_axi_wready),
        .m_axi_bid(m_axi_bid),
        .m_axi_bresp(m_axi_bresp),
        .m_axi_bvalid(m_axi_bvalid),
        .m_axi_bready(m_axi_bready),
        .stat_write_req_pulse(),
        .stat_write_decerr_pulse(),
        .fault_valid(),
        .fault_code(),
        .fault_addr(),
        .fault_id()
    );

    always #5 clk = ~clk;

    always @(*) begin
        if (m_axi_awvalid && m_axi_awready) begin
            seen_downstream_aw = 1'b1;
            last_downstream_awaddr = m_axi_awaddr;
            last_downstream_awburst = m_axi_awburst;
        end
        if (m_axi_wvalid && m_axi_wready) begin
            seen_downstream_w = 1'b1;
            last_downstream_wdata = m_axi_wdata;
        end
    end

    task automatic handshake_aw(
        input [ADDR_WIDTH-1:0] addr,
        input [7:0] len,
        input [2:0] size,
        input [1:0] burst,
        input [ID_WIDTH-1:0] id
    );
    begin
        @(posedge clk);
        s_axi_awaddr <= addr;
        s_axi_awlen <= len;
        s_axi_awsize <= size;
        s_axi_awburst <= burst;
        s_axi_awid <= id;
        s_axi_awvalid <= 1'b1;
        wait (s_axi_awready);
        @(posedge clk);
        s_axi_awvalid <= 1'b0;
    end
    endtask

    task automatic handshake_w(input [DATA_WIDTH-1:0] data, input bit last);
    begin
        @(posedge clk);
        s_axi_wdata <= data;
        s_axi_wstrb <= '1;
        s_axi_wlast <= last;
        s_axi_wvalid <= 1'b1;
        wait (s_axi_wready);
        @(posedge clk);
        s_axi_wvalid <= 1'b0;
        s_axi_wlast <= 1'b0;
    end
    endtask

    initial begin
        // Valid write should pass through untouched.
        s_axi_bready <= 1'b0;
        fork
            handshake_aw(32'h0000_0100, 8'd0, 3'd2, 2'b01, 8'h12);
            handshake_w(32'h1111_2222, 1'b1);
        join

        if (!seen_downstream_aw || last_downstream_awaddr !== 32'h0000_0100) begin
            $display("FAIL valid write address path");
            $fatal;
        end
        if (!seen_downstream_w || last_downstream_wdata !== 32'h1111_2222) begin
            $display("FAIL valid write data path");
            $fatal;
        end

        m_axi_bid <= 8'h12;
        m_axi_bresp <= 2'b00;
        m_axi_bvalid <= 1'b1;
        @(posedge clk);
        if (!s_axi_bvalid || s_axi_bresp !== 2'b00 || s_axi_bid !== 8'h12) begin
            $display("FAIL valid write response path");
            $fatal;
        end
        s_axi_bready <= 1'b1;
        @(posedge clk);
        m_axi_bvalid <= 1'b0;

        // Valid WRAP writes should pass through as WRAP, without local DECERR.
        seen_downstream_aw <= 1'b0;
        seen_downstream_w <= 1'b0;
        s_axi_bready <= 1'b0;
        fork
            handshake_aw(32'h0000_0034, 8'd3, 3'd2, 2'b10, 8'h22);
            begin
                handshake_w(32'h2222_0000, 1'b0);
                handshake_w(32'h2222_0001, 1'b0);
                handshake_w(32'h2222_0002, 1'b0);
                handshake_w(32'h2222_0003, 1'b1);
            end
        join

        if (!seen_downstream_aw || last_downstream_awaddr !== 32'h0000_0034 ||
                last_downstream_awburst !== 2'b10) begin
            $display("FAIL valid WRAP write address path addr=0x%08h burst=%b",
                last_downstream_awaddr, last_downstream_awburst);
            $fatal;
        end
        if (!seen_downstream_w || last_downstream_wdata !== 32'h2222_0003) begin
            $display("FAIL valid WRAP write data path");
            $fatal;
        end

        m_axi_bid <= 8'h22;
        m_axi_bresp <= 2'b00;
        m_axi_bvalid <= 1'b1;
        @(posedge clk);
        if (!s_axi_bvalid || s_axi_bresp !== 2'b00 || s_axi_bid !== 8'h22) begin
            $display("FAIL valid WRAP write response path");
            $fatal;
        end
        s_axi_bready <= 1'b1;
        @(posedge clk);
        m_axi_bvalid <= 1'b0;

        // Invalid write should be handled locally and respond only after WLAST.
        seen_downstream_aw <= 1'b0;
        seen_downstream_w <= 1'b0;
        s_axi_bready <= 1'b0;
        fork
            handshake_aw(32'h0000_0FFC, 8'd1, 3'd2, 2'b01, 8'h34);
            begin
                handshake_w(32'hAAAA_0001, 1'b0);
                handshake_w(32'hAAAA_0002, 1'b1);
            end
        join

        if (m_axi_awvalid) begin
            $display("FAIL invalid write must not forward AW downstream");
            $fatal;
        end
        if (m_axi_wvalid) begin
            $display("FAIL invalid write must not forward W downstream");
            $fatal;
        end
        #1;
        if (!s_axi_bvalid || s_axi_bresp !== 2'b11 || s_axi_bid !== 8'h34) begin
            $display("FAIL invalid write must return local DECERR after WLAST");
            $fatal;
        end

        s_axi_bready <= 1'b1;
        @(posedge clk);
        #1;
        if (s_axi_bvalid) begin
            $display("FAIL local DECERR should clear after handshake");
            $fatal;
        end

        // Invalid writes should stall until outstanding valid writes drain.
        @(posedge clk);
        s_axi_awaddr <= 32'h0000_0200;
        s_axi_awlen <= 8'd0;
        s_axi_awsize <= 3'd2;
        s_axi_awburst <= 2'b01;
        s_axi_awid <= 8'h56;
        s_axi_awvalid <= 1'b1;

        #1;
        if (!s_axi_awready) begin
            $display("FAIL valid write should be ready");
            $fatal;
        end

        @(posedge clk);
        s_axi_awvalid <= 1'b0;

        @(posedge clk);
        s_axi_awaddr <= 32'h0000_0FFC;
        s_axi_awlen <= 8'd1;
        s_axi_awsize <= 3'd2;
        s_axi_awburst <= 2'b01;
        s_axi_awid <= 8'h57;
        s_axi_awvalid <= 1'b1;

        #1;
        if (s_axi_awready) begin
            $display("FAIL invalid write should stall behind outstanding valid write");
            $fatal;
        end

        m_axi_bid <= 8'h56;
        m_axi_bresp <= 2'b00;
        m_axi_bvalid <= 1'b1;
        @(posedge clk);
        m_axi_bvalid <= 1'b0;

        wait (s_axi_awready);
        @(posedge clk);
        s_axi_awvalid <= 1'b0;

        $display("PASS tb_axi_ic_write_guard");
        $finish;
    end

endmodule
