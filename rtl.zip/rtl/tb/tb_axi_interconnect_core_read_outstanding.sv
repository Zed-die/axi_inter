`timescale 1ns / 1ps

module tb_axi_interconnect_core_read_outstanding;

    localparam S_COUNT = 2;
    localparam M_COUNT = 2;
    localparam DATA_WIDTH = 32;
    localparam ADDR_WIDTH = 32;
    localparam STRB_WIDTH = DATA_WIDTH/8;
    localparam S_ID_WIDTH = 8;
    localparam M_ID_WIDTH = S_ID_WIDTH + $clog2(S_COUNT);
    localparam [ADDR_WIDTH-1:0] DECERR_ADDR = 32'hFFFF_F000;
    localparam [S_COUNT*32-1:0] S_THREADS = {32'd4, 32'd4};
    localparam [S_COUNT*32-1:0] S_ACCEPT = {32'd16, 32'd16};
    localparam [M_COUNT*32-1:0] M_ISSUE = {32'd4, 32'd4};
    localparam [M_COUNT*ADDR_WIDTH-1:0] M_BASE_ADDR = {32'h0001_0000, 32'h0000_0000};
    localparam [M_COUNT*32-1:0] M_ADDR_WIDTH = {32'd16, 32'd16};

    logic clk = 1'b0;
    logic rst = 1'b1;
    logic [11:0] cfg_paddr = '0;
    logic cfg_psel = 1'b0;
    logic cfg_penable = 1'b0;
    logic cfg_pwrite = 1'b0;
    logic [31:0] cfg_pwdata = '0;
    wire [31:0] cfg_prdata;
    wire cfg_pready;
    wire cfg_pslverr;

    logic [S_COUNT*S_ID_WIDTH-1:0] s_axi_awid = '0;
    logic [S_COUNT*ADDR_WIDTH-1:0] s_axi_awaddr = '0;
    logic [S_COUNT*8-1:0] s_axi_awlen = '0;
    logic [S_COUNT*3-1:0] s_axi_awsize = '0;
    logic [S_COUNT*2-1:0] s_axi_awburst = '0;
    logic [S_COUNT-1:0] s_axi_awlock = '0;
    logic [S_COUNT*4-1:0] s_axi_awcache = '0;
    logic [S_COUNT*3-1:0] s_axi_awprot = '0;
    logic [S_COUNT*4-1:0] s_axi_awqos = '0;
    logic [S_COUNT-1:0] s_axi_awvalid = '0;
    wire [S_COUNT-1:0] s_axi_awready;
    logic [S_COUNT*DATA_WIDTH-1:0] s_axi_wdata = '0;
    logic [S_COUNT*STRB_WIDTH-1:0] s_axi_wstrb = '0;
    logic [S_COUNT-1:0] s_axi_wlast = '0;
    logic [S_COUNT-1:0] s_axi_wvalid = '0;
    wire [S_COUNT-1:0] s_axi_wready;
    wire [S_COUNT*S_ID_WIDTH-1:0] s_axi_bid;
    wire [S_COUNT*2-1:0] s_axi_bresp;
    wire [S_COUNT-1:0] s_axi_bvalid;
    logic [S_COUNT-1:0] s_axi_bready = '1;

    logic [S_COUNT*S_ID_WIDTH-1:0] s_axi_arid = '0;
    logic [S_COUNT*ADDR_WIDTH-1:0] s_axi_araddr = '0;
    logic [S_COUNT*8-1:0] s_axi_arlen = '0;
    logic [S_COUNT*3-1:0] s_axi_arsize = '0;
    logic [S_COUNT*2-1:0] s_axi_arburst = '0;
    logic [S_COUNT-1:0] s_axi_arlock = '0;
    logic [S_COUNT*4-1:0] s_axi_arcache = '0;
    logic [S_COUNT*3-1:0] s_axi_arprot = '0;
    logic [S_COUNT*4-1:0] s_axi_arqos = '0;
    logic [S_COUNT-1:0] s_axi_arvalid = '0;
    wire [S_COUNT-1:0] s_axi_arready;
    wire [S_COUNT*S_ID_WIDTH-1:0] s_axi_rid;
    wire [S_COUNT*DATA_WIDTH-1:0] s_axi_rdata;
    wire [S_COUNT*2-1:0] s_axi_rresp;
    wire [S_COUNT-1:0] s_axi_rlast;
    wire [S_COUNT-1:0] s_axi_rvalid;
    logic [S_COUNT-1:0] s_axi_rready = '1;

    wire [M_COUNT*M_ID_WIDTH-1:0] m_axi_awid;
    wire [M_COUNT*ADDR_WIDTH-1:0] m_axi_awaddr;
    wire [M_COUNT*8-1:0] m_axi_awlen;
    wire [M_COUNT*3-1:0] m_axi_awsize;
    wire [M_COUNT*2-1:0] m_axi_awburst;
    wire [M_COUNT-1:0] m_axi_awlock;
    wire [M_COUNT*4-1:0] m_axi_awcache;
    wire [M_COUNT*3-1:0] m_axi_awprot;
    wire [M_COUNT*4-1:0] m_axi_awqos;
    wire [M_COUNT*4-1:0] m_axi_awregion;
    wire [M_COUNT-1:0] m_axi_awvalid;
    logic [M_COUNT-1:0] m_axi_awready = '1;
    wire [M_COUNT*DATA_WIDTH-1:0] m_axi_wdata;
    wire [M_COUNT*STRB_WIDTH-1:0] m_axi_wstrb;
    wire [M_COUNT-1:0] m_axi_wlast;
    wire [M_COUNT-1:0] m_axi_wvalid;
    logic [M_COUNT-1:0] m_axi_wready = '1;
    logic [M_COUNT*M_ID_WIDTH-1:0] m_axi_bid = '0;
    logic [M_COUNT*2-1:0] m_axi_bresp = '0;
    logic [M_COUNT-1:0] m_axi_bvalid = '0;
    wire [M_COUNT-1:0] m_axi_bready;
    wire [M_COUNT*M_ID_WIDTH-1:0] m_axi_arid;
    wire [M_COUNT*ADDR_WIDTH-1:0] m_axi_araddr;
    wire [M_COUNT*8-1:0] m_axi_arlen;
    wire [M_COUNT*3-1:0] m_axi_arsize;
    wire [M_COUNT*2-1:0] m_axi_arburst;
    wire [M_COUNT-1:0] m_axi_arlock;
    wire [M_COUNT*4-1:0] m_axi_arcache;
    wire [M_COUNT*3-1:0] m_axi_arprot;
    wire [M_COUNT*4-1:0] m_axi_arqos;
    wire [M_COUNT*4-1:0] m_axi_arregion;
    wire [M_COUNT-1:0] m_axi_arvalid;
    logic [M_COUNT-1:0] m_axi_arready = '1;
    logic [M_COUNT*M_ID_WIDTH-1:0] m_axi_rid = '0;
    logic [M_COUNT*DATA_WIDTH-1:0] m_axi_rdata = '0;
    logic [M_COUNT*2-1:0] m_axi_rresp = '0;
    logic [M_COUNT-1:0] m_axi_rlast = '0;
    logic [M_COUNT-1:0] m_axi_rvalid = '0;
    wire [M_COUNT-1:0] m_axi_rready;
    wire [M_COUNT*32-1:0] m_ahb_haddr;
    wire [M_COUNT*2-1:0] m_ahb_htrans;
    wire [M_COUNT-1:0] m_ahb_hwrite;
    wire [M_COUNT*3-1:0] m_ahb_hsize;
    wire [M_COUNT*3-1:0] m_ahb_hburst;
    wire [M_COUNT*64-1:0] m_ahb_hwdata;
    wire [M_COUNT-1:0] m_ahb_hbusreq;
    wire [M_COUNT-1:0] m_ahb_hlock;
    logic [M_COUNT*64-1:0] m_ahb_hrdata = '0;
    logic [M_COUNT-1:0] m_ahb_hready = '1;
    logic [M_COUNT*2-1:0] m_ahb_hresp = '0;
    logic [M_COUNT-1:0] m_ahb_hgrant = '0;
    logic [M_COUNT*4-1:0] m_ahb_hmaster = '0;

    logic [M_ID_WIDTH-1:0] captured_port0_rid_0 = '0;
    logic [M_ID_WIDTH-1:0] captured_port0_rid_1 = '0;
    logic [M_ID_WIDTH-1:0] captured_port1_rid_0 = '0;
    logic [M_ID_WIDTH-1:0] captured_port1_rid_1 = '0;
    integer port0_ar_count = 0;
    integer port1_ar_count = 0;

    integer accepted_reads_s0 = 0;
    integer accepted_reads_s1 = 0;
    integer completed_reads_s0 = 0;
    integer completed_reads_s1 = 0;
    integer max_outstanding_s0 = 0;
    integer max_outstanding_s1 = 0;
    integer accepted_before_first_r_s0 = 0;
    integer accepted_before_first_r_s1 = 0;
    logic first_r_seen_s0 = 1'b0;
    logic first_r_seen_s1 = 1'b0;

    logic seen_s0_id10 = 1'b0;
    logic seen_s0_id20 = 1'b0;
    logic seen_s1_id30 = 1'b0;
    logic seen_s1_id40 = 1'b0;
    logic [31:0] data_s0_id10 = '0;
    logic [31:0] data_s0_id20 = '0;
    logic [31:0] data_s1_id30 = '0;
    logic [31:0] data_s1_id40 = '0;

    axi_interconnect_core #(
        .S_COUNT(S_COUNT),
        .M_COUNT(M_COUNT),
        .DATA_WIDTH(DATA_WIDTH),
        .ADDR_WIDTH(ADDR_WIDTH),
        .STRB_WIDTH(STRB_WIDTH),
        .S_ID_WIDTH(S_ID_WIDTH),
        .M_ID_WIDTH(M_ID_WIDTH),
        .S_THREADS(S_THREADS),
        .S_ACCEPT(S_ACCEPT),
        .M_ISSUE(M_ISSUE),
        .M_BASE_ADDR(M_BASE_ADDR),
        .M_ADDR_WIDTH(M_ADDR_WIDTH),
        .DECERR_ADDR(DECERR_ADDR)
    )
    dut (
        .clk(clk),
        .rst(rst),
        .cfg_paddr(cfg_paddr),
        .cfg_psel(cfg_psel),
        .cfg_penable(cfg_penable),
        .cfg_pwrite(cfg_pwrite),
        .cfg_pwdata(cfg_pwdata),
        .cfg_prdata(cfg_prdata),
        .cfg_pready(cfg_pready),
        .cfg_pslverr(cfg_pslverr),
        .s_axi_awid(s_axi_awid),
        .s_axi_awaddr(s_axi_awaddr),
        .s_axi_awlen(s_axi_awlen),
        .s_axi_awsize(s_axi_awsize),
        .s_axi_awburst(s_axi_awburst),
        .s_axi_awlock(s_axi_awlock),
        .s_axi_awcache(s_axi_awcache),
        .s_axi_awprot(s_axi_awprot),
        .s_axi_awqos(s_axi_awqos),
        .s_axi_awuser({S_COUNT{1'b0}}),
        .s_axi_awvalid(s_axi_awvalid),
        .s_axi_awready(s_axi_awready),
        .s_axi_wdata(s_axi_wdata),
        .s_axi_wstrb(s_axi_wstrb),
        .s_axi_wlast(s_axi_wlast),
        .s_axi_wuser({S_COUNT{1'b0}}),
        .s_axi_wvalid(s_axi_wvalid),
        .s_axi_wready(s_axi_wready),
        .s_axi_bid(s_axi_bid),
        .s_axi_bresp(s_axi_bresp),
        .s_axi_buser(),
        .s_axi_bvalid(s_axi_bvalid),
        .s_axi_bready(s_axi_bready),
        .s_axi_arid(s_axi_arid),
        .s_axi_araddr(s_axi_araddr),
        .s_axi_arlen(s_axi_arlen),
        .s_axi_arsize(s_axi_arsize),
        .s_axi_arburst(s_axi_arburst),
        .s_axi_arlock(s_axi_arlock),
        .s_axi_arcache(s_axi_arcache),
        .s_axi_arprot(s_axi_arprot),
        .s_axi_arqos(s_axi_arqos),
        .s_axi_aruser({S_COUNT{1'b0}}),
        .s_axi_arvalid(s_axi_arvalid),
        .s_axi_arready(s_axi_arready),
        .s_axi_rid(s_axi_rid),
        .s_axi_rdata(s_axi_rdata),
        .s_axi_rresp(s_axi_rresp),
        .s_axi_rlast(s_axi_rlast),
        .s_axi_ruser(),
        .s_axi_rvalid(s_axi_rvalid),
        .s_axi_rready(s_axi_rready),
        .m_axi_awid(m_axi_awid),
        .m_axi_awaddr(m_axi_awaddr),
        .m_axi_awlen(m_axi_awlen),
        .m_axi_awsize(m_axi_awsize),
        .m_axi_awburst(m_axi_awburst),
        .m_axi_awlock(m_axi_awlock),
        .m_axi_awcache(m_axi_awcache),
        .m_axi_awprot(m_axi_awprot),
        .m_axi_awqos(m_axi_awqos),
        .m_axi_awregion(m_axi_awregion),
        .m_axi_awuser(),
        .m_axi_awvalid(m_axi_awvalid),
        .m_axi_awready(m_axi_awready),
        .m_axi_wdata(m_axi_wdata),
        .m_axi_wstrb(m_axi_wstrb),
        .m_axi_wlast(m_axi_wlast),
        .m_axi_wuser(),
        .m_axi_wvalid(m_axi_wvalid),
        .m_axi_wready(m_axi_wready),
        .m_axi_bid(m_axi_bid),
        .m_axi_bresp(m_axi_bresp),
        .m_axi_buser({M_COUNT{1'b0}}),
        .m_axi_bvalid(m_axi_bvalid),
        .m_axi_bready(m_axi_bready),
        .m_axi_arid(m_axi_arid),
        .m_axi_araddr(m_axi_araddr),
        .m_axi_arlen(m_axi_arlen),
        .m_axi_arsize(m_axi_arsize),
        .m_axi_arburst(m_axi_arburst),
        .m_axi_arlock(m_axi_arlock),
        .m_axi_arcache(m_axi_arcache),
        .m_axi_arprot(m_axi_arprot),
        .m_axi_arqos(m_axi_arqos),
        .m_axi_arregion(m_axi_arregion),
        .m_axi_aruser(),
        .m_axi_arvalid(m_axi_arvalid),
        .m_axi_arready(m_axi_arready),
        .m_axi_rid(m_axi_rid),
        .m_axi_rdata(m_axi_rdata),
        .m_axi_rresp(m_axi_rresp),
        .m_axi_rlast(m_axi_rlast),
        .m_axi_ruser({M_COUNT{1'b0}}),
        .m_axi_rvalid(m_axi_rvalid),
        .m_axi_rready(m_axi_rready),
        .m_ahb_haddr(m_ahb_haddr),
        .m_ahb_htrans(m_ahb_htrans),
        .m_ahb_hwrite(m_ahb_hwrite),
        .m_ahb_hsize(m_ahb_hsize),
        .m_ahb_hburst(m_ahb_hburst),
        .m_ahb_hwdata(m_ahb_hwdata),
        .m_ahb_hbusreq(m_ahb_hbusreq),
        .m_ahb_hlock(m_ahb_hlock),
        .m_ahb_hrdata(m_ahb_hrdata),
        .m_ahb_hready(m_ahb_hready),
        .m_ahb_hresp(m_ahb_hresp),
        .m_ahb_hgrant(m_ahb_hgrant),
        .m_ahb_hmaster(m_ahb_hmaster)
    );

    function automatic [31:0] data_for_id(
        input [7:0] id
    );
    begin
        case (id)
            8'h10: data_for_id = 32'h1111_0010;
            8'h20: data_for_id = 32'h2222_0020;
            8'h30: data_for_id = 32'h3333_0030;
            8'h40: data_for_id = 32'h4444_0040;
            default: data_for_id = 32'hDEAD_0000 | {24'd0, id};
        endcase
    end
    endfunction

    always #5 clk = ~clk;

    always @(posedge clk) begin
        integer next_outstanding;

        if (rst) begin
            captured_port0_rid_0 <= '0;
            captured_port0_rid_1 <= '0;
            captured_port1_rid_0 <= '0;
            captured_port1_rid_1 <= '0;
            port0_ar_count <= 0;
            port1_ar_count <= 0;
            accepted_reads_s0 <= 0;
            accepted_reads_s1 <= 0;
            completed_reads_s0 <= 0;
            completed_reads_s1 <= 0;
            max_outstanding_s0 <= 0;
            max_outstanding_s1 <= 0;
            accepted_before_first_r_s0 <= 0;
            accepted_before_first_r_s1 <= 0;
            first_r_seen_s0 <= 1'b0;
            first_r_seen_s1 <= 1'b0;
            seen_s0_id10 <= 1'b0;
            seen_s0_id20 <= 1'b0;
            seen_s1_id30 <= 1'b0;
            seen_s1_id40 <= 1'b0;
            data_s0_id10 <= '0;
            data_s0_id20 <= '0;
            data_s1_id30 <= '0;
            data_s1_id40 <= '0;
            m_axi_rvalid <= '0;
            m_axi_rlast <= '0;
        end else begin
            if (s_axi_arvalid[0] && s_axi_arready[0]) begin
                accepted_reads_s0 <= accepted_reads_s0 + 1;
                next_outstanding = accepted_reads_s0 + 1 - completed_reads_s0;
                if (next_outstanding > max_outstanding_s0) begin
                    max_outstanding_s0 <= next_outstanding;
                end
                $display("%0t AR accepted on source port 0 id=%02x addr=%08x outstanding=%0d",
                    $time,
                    s_axi_arid[7:0],
                    s_axi_araddr[31:0],
                    next_outstanding);
            end

            if (s_axi_arvalid[1] && s_axi_arready[1]) begin
                accepted_reads_s1 <= accepted_reads_s1 + 1;
                next_outstanding = accepted_reads_s1 + 1 - completed_reads_s1;
                if (next_outstanding > max_outstanding_s1) begin
                    max_outstanding_s1 <= next_outstanding;
                end
                $display("%0t AR accepted on source port 1 id=%02x addr=%08x outstanding=%0d",
                    $time,
                    s_axi_arid[S_ID_WIDTH +: S_ID_WIDTH],
                    s_axi_araddr[ADDR_WIDTH +: ADDR_WIDTH],
                    next_outstanding);
            end

            if (m_axi_arvalid[0] && m_axi_arready[0]) begin
                if (port0_ar_count == 0) begin
                    captured_port0_rid_0 <= m_axi_arid[M_ID_WIDTH-1:0];
                end else if (port0_ar_count == 1) begin
                    captured_port0_rid_1 <= m_axi_arid[M_ID_WIDTH-1:0];
                end
                port0_ar_count <= port0_ar_count + 1;
            end

            if (m_axi_arvalid[1] && m_axi_arready[1]) begin
                if (port1_ar_count == 0) begin
                    captured_port1_rid_0 <= m_axi_arid[M_ID_WIDTH +: M_ID_WIDTH];
                end else if (port1_ar_count == 1) begin
                    captured_port1_rid_1 <= m_axi_arid[M_ID_WIDTH +: M_ID_WIDTH];
                end
                port1_ar_count <= port1_ar_count + 1;
            end

            if (m_axi_rvalid[0] && m_axi_rready[0]) begin
                m_axi_rvalid[0] <= 1'b0;
                m_axi_rlast[0] <= 1'b0;
            end

            if (m_axi_rvalid[1] && m_axi_rready[1]) begin
                m_axi_rvalid[1] <= 1'b0;
                m_axi_rlast[1] <= 1'b0;
            end

            if (s_axi_rvalid[0] && s_axi_rready[0]) begin
                completed_reads_s0 <= completed_reads_s0 + 1;
                if (!first_r_seen_s0) begin
                    first_r_seen_s0 <= 1'b1;
                    accepted_before_first_r_s0 <= accepted_reads_s0;
                end

                case (s_axi_rid[7:0])
                    8'h10: begin
                        seen_s0_id10 <= 1'b1;
                        data_s0_id10 <= s_axi_rdata[31:0];
                    end
                    8'h20: begin
                        seen_s0_id20 <= 1'b1;
                        data_s0_id20 <= s_axi_rdata[31:0];
                    end
                    default: begin
                        $display("FAIL unexpected response id %02x on source port 0", s_axi_rid[7:0]);
                        $fatal;
                    end
                endcase

                $display("%0t R completed on source port 0 id=%02x data=%08x outstanding=%0d",
                    $time,
                    s_axi_rid[7:0],
                    s_axi_rdata[31:0],
                    accepted_reads_s0 - completed_reads_s0 - 1);
            end

            if (s_axi_rvalid[1] && s_axi_rready[1]) begin
                completed_reads_s1 <= completed_reads_s1 + 1;
                if (!first_r_seen_s1) begin
                    first_r_seen_s1 <= 1'b1;
                    accepted_before_first_r_s1 <= accepted_reads_s1;
                end

                case (s_axi_rid[S_ID_WIDTH +: S_ID_WIDTH])
                    8'h30: begin
                        seen_s1_id30 <= 1'b1;
                        data_s1_id30 <= s_axi_rdata[DATA_WIDTH +: DATA_WIDTH];
                    end
                    8'h40: begin
                        seen_s1_id40 <= 1'b1;
                        data_s1_id40 <= s_axi_rdata[DATA_WIDTH +: DATA_WIDTH];
                    end
                    default: begin
                        $display("FAIL unexpected response id %02x on source port 1", s_axi_rid[S_ID_WIDTH +: S_ID_WIDTH]);
                        $fatal;
                    end
                endcase

                $display("%0t R completed on source port 1 id=%02x data=%08x outstanding=%0d",
                    $time,
                    s_axi_rid[S_ID_WIDTH +: S_ID_WIDTH],
                    s_axi_rdata[DATA_WIDTH +: DATA_WIDTH],
                    accepted_reads_s1 - completed_reads_s1 - 1);
            end
        end
    end

    task automatic send_ar_on_source(
        input integer src,
        input [31:0] addr,
        input [7:0] id
    );
    begin
        @(posedge clk);
        s_axi_araddr[src*ADDR_WIDTH +: ADDR_WIDTH] <= addr;
        s_axi_arlen[src*8 +: 8] <= 8'd0;
        s_axi_arsize[src*3 +: 3] <= 3'd2;
        s_axi_arburst[src*2 +: 2] <= 2'b01;
        s_axi_arid[src*S_ID_WIDTH +: S_ID_WIDTH] <= id;
        s_axi_arvalid[src] <= 1'b1;
        wait (s_axi_arready[src]);
        @(posedge clk);
        s_axi_arvalid[src] <= 1'b0;
    end
    endtask

    task automatic return_r_on_port(
        input integer port,
        input [M_ID_WIDTH-1:0] rid
    );
    begin
        @(posedge clk);
        m_axi_rid[port*M_ID_WIDTH +: M_ID_WIDTH] <= rid;
        m_axi_rdata[port*DATA_WIDTH +: DATA_WIDTH] <= data_for_id(rid[S_ID_WIDTH-1:0]);
        m_axi_rresp[port*2 +: 2] <= 2'b00;
        m_axi_rlast[port] <= 1'b1;
        m_axi_rvalid[port] <= 1'b1;
        wait (m_axi_rready[port]);
        @(posedge clk);
        m_axi_rvalid[port] <= 1'b0;
        m_axi_rlast[port] <= 1'b0;
    end
    endtask

    initial begin
        #2000;
        $display("FAIL timeout in tb_axi_interconnect_core_read_outstanding");
        $fatal;
    end

    initial begin
        repeat (4) @(posedge clk);
        rst <= 1'b0;

        fork
            send_ar_on_source(0, 32'h0000_0004, 8'h10);
            send_ar_on_source(1, 32'h0001_0008, 8'h30);
        join

        fork
            send_ar_on_source(0, 32'h0001_000C, 8'h20);
            send_ar_on_source(1, 32'h0000_0010, 8'h40);
        join

        wait (accepted_reads_s0 == 2 && accepted_reads_s1 == 2);
        wait (port0_ar_count == 2 && port1_ar_count == 2);

        return_r_on_port(1, captured_port1_rid_1);
        return_r_on_port(0, captured_port0_rid_1);
        return_r_on_port(1, captured_port1_rid_0);
        return_r_on_port(0, captured_port0_rid_0);

        wait (completed_reads_s0 == 2 && completed_reads_s1 == 2);

        if (accepted_reads_s0 != 2 || accepted_reads_s1 != 2) begin
            $display("FAIL expected 2 accepted reads per source, got s0=%0d s1=%0d",
                accepted_reads_s0,
                accepted_reads_s1);
            $fatal;
        end

        if (max_outstanding_s0 < 2 || max_outstanding_s1 < 2) begin
            $display("FAIL expected both sources to reach outstanding depth 2, got s0=%0d s1=%0d",
                max_outstanding_s0,
                max_outstanding_s1);
            $fatal;
        end

        if (accepted_before_first_r_s0 < 2 || accepted_before_first_r_s1 < 2) begin
            $display("FAIL first response arrived too early, accepted_before_first_r_s0=%0d accepted_before_first_r_s1=%0d",
                accepted_before_first_r_s0,
                accepted_before_first_r_s1);
            $fatal;
        end

        if (!seen_s0_id10 || data_s0_id10 !== 32'h1111_0010) begin
            $display("FAIL missing or incorrect response for source 0 id 10");
            $fatal;
        end

        if (!seen_s0_id20 || data_s0_id20 !== 32'h2222_0020) begin
            $display("FAIL missing or incorrect response for source 0 id 20");
            $fatal;
        end

        if (!seen_s1_id30 || data_s1_id30 !== 32'h3333_0030) begin
            $display("FAIL missing or incorrect response for source 1 id 30");
            $fatal;
        end

        if (!seen_s1_id40 || data_s1_id40 !== 32'h4444_0040) begin
            $display("FAIL missing or incorrect response for source 1 id 40");
            $fatal;
        end

        $display("PASS tb_axi_interconnect_core_read_outstanding max_outstanding_s0=%0d max_outstanding_s1=%0d",
            max_outstanding_s0,
            max_outstanding_s1);
        $finish;
    end

endmodule
