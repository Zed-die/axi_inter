`timescale 1ns / 1ps

module tb_axi_crossbar_wr_aw_block_by_w;

    localparam S_COUNT = 2;
    localparam M_COUNT = 2;
    localparam DATA_WIDTH = 32;
    localparam ADDR_WIDTH = 32;
    localparam STRB_WIDTH = DATA_WIDTH/8;
    localparam S_ID_WIDTH = 8;
    localparam M_ID_WIDTH = S_ID_WIDTH + $clog2(S_COUNT);
    localparam [M_COUNT*ADDR_WIDTH-1:0] M_BASE_ADDR = {32'h0001_0000, 32'h0000_0000};
    localparam [M_COUNT*32-1:0] M_ADDR_WIDTH = {32'd16, 32'd16};

    logic clk = 1'b0;
    logic rst = 1'b1;

    logic [S_COUNT*S_ID_WIDTH-1:0] s_axi_awid = '0;
    logic [S_COUNT*ADDR_WIDTH-1:0] s_axi_awaddr = '0;
    logic [S_COUNT*8-1:0] s_axi_awlen = '0;
    logic [S_COUNT*3-1:0] s_axi_awsize = '0;
    logic [S_COUNT*2-1:0] s_axi_awburst = '0;
    logic [S_COUNT-1:0] s_axi_awlock = '0;
    logic [S_COUNT*4-1:0] s_axi_awcache = '0;
    logic [S_COUNT*3-1:0] s_axi_awprot = '0;
    logic [S_COUNT*4-1:0] s_axi_awqos = '0;
    logic [S_COUNT-1:0] s_axi_awvalid = '0;
    wire [S_COUNT-1:0] s_axi_awready;

    logic [S_COUNT*DATA_WIDTH-1:0] s_axi_wdata = '0;
    logic [S_COUNT*STRB_WIDTH-1:0] s_axi_wstrb = '0;
    logic [S_COUNT-1:0] s_axi_wlast = '0;
    logic [S_COUNT-1:0] s_axi_wvalid = '0;
    wire [S_COUNT-1:0] s_axi_wready;

    wire [S_COUNT*S_ID_WIDTH-1:0] s_axi_bid;
    wire [S_COUNT*2-1:0] s_axi_bresp;
    wire [S_COUNT-1:0] s_axi_bvalid;
    logic [S_COUNT-1:0] s_axi_bready = {S_COUNT{1'b1}};

    wire [M_COUNT*M_ID_WIDTH-1:0] m_axi_awid;
    wire [M_COUNT*ADDR_WIDTH-1:0] m_axi_awaddr;
    wire [M_COUNT*8-1:0] m_axi_awlen;
    wire [M_COUNT*3-1:0] m_axi_awsize;
    wire [M_COUNT*2-1:0] m_axi_awburst;
    wire [M_COUNT-1:0] m_axi_awlock;
    wire [M_COUNT*4-1:0] m_axi_awcache;
    wire [M_COUNT*3-1:0] m_axi_awprot;
    wire [M_COUNT*4-1:0] m_axi_awqos;
    wire [M_COUNT*4-1:0] m_axi_awregion;
    wire [M_COUNT-1:0] m_axi_awvalid;
    logic [M_COUNT-1:0] m_axi_awready = {M_COUNT{1'b1}};

    wire [M_COUNT*DATA_WIDTH-1:0] m_axi_wdata;
    wire [M_COUNT*STRB_WIDTH-1:0] m_axi_wstrb;
    wire [M_COUNT-1:0] m_axi_wlast;
    wire [M_COUNT-1:0] m_axi_wvalid;
    logic [M_COUNT-1:0] m_axi_wready = {M_COUNT{1'b1}};

    logic [M_COUNT*M_ID_WIDTH-1:0] m_axi_bid = '0;
    logic [M_COUNT*2-1:0] m_axi_bresp = '0;
    logic [M_COUNT-1:0] m_axi_bvalid = '0;
    wire [M_COUNT-1:0] m_axi_bready;

    logic [M_ID_WIDTH-1:0] bid_fifo[0:3];
    integer bid_wr_ptr = 0;
    integer bid_rd_ptr = 0;
    logic b_pending = 1'b0;

    logic s0_aw_done = 1'b0;
    logic s1_aw_done = 1'b0;
    integer b_done_count = 0;
    integer blocked_cycles = 0;
    logic saw_initial_conflict = 1'b0;
    logic saw_s1_request_after_wlast = 1'b0;

    axi_crossbar_wr #(
        .S_COUNT(S_COUNT),
        .M_COUNT(M_COUNT),
        .DATA_WIDTH(DATA_WIDTH),
        .ADDR_WIDTH(ADDR_WIDTH),
        .STRB_WIDTH(STRB_WIDTH),
        .S_ID_WIDTH(S_ID_WIDTH),
        .M_ID_WIDTH(M_ID_WIDTH),
        .S_THREADS({S_COUNT{32'd2}}),
        .S_ACCEPT({S_COUNT{32'd4}}),
        .M_REGIONS(1),
        .M_BASE_ADDR(M_BASE_ADDR),
        .M_ADDR_WIDTH(M_ADDR_WIDTH),
        .M_CONNECT({M_COUNT{{S_COUNT{1'b1}}}}),
        .M_ISSUE({M_COUNT{32'd4}}),
        .M_SECURE({M_COUNT{1'b0}}),
        .S_AW_REG_TYPE({S_COUNT{2'd0}}),
        .S_W_REG_TYPE({S_COUNT{2'd0}}),
        .S_B_REG_TYPE({S_COUNT{2'd0}}),
        .M_AW_REG_TYPE({M_COUNT{2'd0}}),
        .M_W_REG_TYPE({M_COUNT{2'd0}}),
        .M_B_REG_TYPE({M_COUNT{2'd0}})
    )
    dut (
        .clk(clk),
        .rst(rst),
        .s_axi_awid(s_axi_awid),
        .s_axi_awaddr(s_axi_awaddr),
        .s_axi_awlen(s_axi_awlen),
        .s_axi_awsize(s_axi_awsize),
        .s_axi_awburst(s_axi_awburst),
        .s_axi_awlock(s_axi_awlock),
        .s_axi_awcache(s_axi_awcache),
        .s_axi_awprot(s_axi_awprot),
        .s_axi_awqos(s_axi_awqos),
        .s_axi_awuser({S_COUNT{1'b0}}),
        .s_axi_awvalid(s_axi_awvalid),
        .s_axi_awready(s_axi_awready),
        .s_axi_wdata(s_axi_wdata),
        .s_axi_wstrb(s_axi_wstrb),
        .s_axi_wlast(s_axi_wlast),
        .s_axi_wuser({S_COUNT{1'b0}}),
        .s_axi_wvalid(s_axi_wvalid),
        .s_axi_wready(s_axi_wready),
        .s_axi_bid(s_axi_bid),
        .s_axi_bresp(s_axi_bresp),
        .s_axi_buser(),
        .s_axi_bvalid(s_axi_bvalid),
        .s_axi_bready(s_axi_bready),
        .m_axi_awid(m_axi_awid),
        .m_axi_awaddr(m_axi_awaddr),
        .m_axi_awlen(m_axi_awlen),
        .m_axi_awsize(m_axi_awsize),
        .m_axi_awburst(m_axi_awburst),
        .m_axi_awlock(m_axi_awlock),
        .m_axi_awcache(m_axi_awcache),
        .m_axi_awprot(m_axi_awprot),
        .m_axi_awqos(m_axi_awqos),
        .m_axi_awregion(m_axi_awregion),
        .m_axi_awuser(),
        .m_axi_awvalid(m_axi_awvalid),
        .m_axi_awready(m_axi_awready),
        .m_axi_wdata(m_axi_wdata),
        .m_axi_wstrb(m_axi_wstrb),
        .m_axi_wlast(m_axi_wlast),
        .m_axi_wuser(),
        .m_axi_wvalid(m_axi_wvalid),
        .m_axi_wready(m_axi_wready),
        .m_axi_bid(m_axi_bid),
        .m_axi_bresp(m_axi_bresp),
        .m_axi_buser({M_COUNT{1'b0}}),
        .m_axi_bvalid(m_axi_bvalid),
        .m_axi_bready(m_axi_bready)
    );

    always #5 clk = ~clk;

    task automatic setup_aw(
        input integer port,
        input [S_ID_WIDTH-1:0] id,
        input [7:0] len
    );
    begin
        s_axi_awid[port*S_ID_WIDTH +: S_ID_WIDTH] = id;
        s_axi_awaddr[port*ADDR_WIDTH +: ADDR_WIDTH] = 32'h0000_0100;
        s_axi_awlen[port*8 +: 8] = len;
        s_axi_awsize[port*3 +: 3] = 3'd2;
        s_axi_awburst[port*2 +: 2] = 2'b01;
        s_axi_awvalid[port] = 1'b1;
    end
    endtask

    task automatic wait_aw_handshake(input integer port);
    begin
        wait (s_axi_awready[port]);
        @(posedge clk);
        #1;
        if (port == 0) begin
            s0_aw_done = 1'b1;
        end else begin
            s1_aw_done = 1'b1;
        end
        @(negedge clk);
        s_axi_awvalid[port] = 1'b0;
    end
    endtask

    task automatic send_wbeat(
        input integer port,
        input [DATA_WIDTH-1:0] data,
        input bit last
    );
    begin
        @(negedge clk);
        s_axi_wdata[port*DATA_WIDTH +: DATA_WIDTH] = data;
        s_axi_wstrb[port*STRB_WIDTH +: STRB_WIDTH] = {STRB_WIDTH{1'b1}};
        s_axi_wlast[port] = last;
        s_axi_wvalid[port] = 1'b1;
        wait (s_axi_wready[port]);
        @(posedge clk);
        #1;
        @(negedge clk);
        s_axi_wvalid[port] = 1'b0;
        s_axi_wlast[port] = 1'b0;
    end
    endtask

    always @(posedge clk) begin
        if (rst) begin
            bid_wr_ptr <= 0;
            bid_rd_ptr <= 0;
            b_pending <= 1'b0;
            m_axi_bvalid <= '0;
            m_axi_bresp <= '0;
            m_axi_bid <= '0;
            s0_aw_done <= 1'b0;
            s1_aw_done <= 1'b0;
            b_done_count <= 0;
            blocked_cycles <= 0;
            saw_initial_conflict <= 1'b0;
            saw_s1_request_after_wlast <= 1'b0;
        end else begin
            if (dut.m_ifaces[0].a_request == 2'b11) begin
                saw_initial_conflict <= 1'b1;
            end

            if (s_axi_awvalid[1] && !s_axi_awready[1] &&
                    dut.m_ifaces[0].w_select_valid_reg &&
                    dut.m_ifaces[0].a_request == 2'b00) begin
                blocked_cycles <= blocked_cycles + 1;
            end

            if (s_axi_awvalid[1] && dut.m_ifaces[0].a_request[1] &&
                    !dut.m_ifaces[0].w_select_valid_reg) begin
                saw_s1_request_after_wlast <= 1'b1;
            end

            if (m_axi_awvalid[0] && m_axi_awready[0]) begin
                bid_fifo[bid_wr_ptr] <= m_axi_awid[0*M_ID_WIDTH +: M_ID_WIDTH];
                bid_wr_ptr <= (bid_wr_ptr + 1) & 3;
            end

            if (m_axi_bvalid[0] && m_axi_bready[0]) begin
                m_axi_bvalid[0] <= 1'b0;
            end

            if (m_axi_wvalid[0] && m_axi_wready[0] && m_axi_wlast[0]) begin
                b_pending <= 1'b1;
            end

            if (b_pending && !m_axi_bvalid[0]) begin
                m_axi_bid[0*M_ID_WIDTH +: M_ID_WIDTH] <= bid_fifo[bid_rd_ptr];
                m_axi_bresp[0*2 +: 2] <= 2'b00;
                m_axi_bvalid[0] <= 1'b1;
                bid_rd_ptr <= (bid_rd_ptr + 1) & 3;
                b_pending <= 1'b0;
            end

            if (s_axi_bvalid[0] && s_axi_bready[0]) begin
                b_done_count <= b_done_count + 1;
            end
            if (s_axi_bvalid[1] && s_axi_bready[1]) begin
                b_done_count <= b_done_count + 1;
            end
        end
    end

    always @(posedge clk) begin
        if (!rst) begin
            $display("[%0t] M0 req=%b grant=%b grant_valid=%0d enc=%0d w_sel_valid=%0d w_sel=S%0d S1_AW valid/ready=%0d/%0d",
                $time,
                dut.m_ifaces[0].a_request,
                dut.m_ifaces[0].a_grant,
                dut.m_ifaces[0].a_grant_valid,
                dut.m_ifaces[0].a_grant_encoded,
                dut.m_ifaces[0].w_select_valid_reg,
                dut.m_ifaces[0].w_select_reg,
                s_axi_awvalid[1],
                s_axi_awready[1]);

            if (m_axi_awvalid[0] && m_axi_awready[0]) begin
                $display("[%0t] M0 AW handshake src=S%0d original_id=%h len=%0d",
                    $time,
                    m_axi_awid[0*M_ID_WIDTH+S_ID_WIDTH +: $clog2(S_COUNT)],
                    m_axi_awid[0*M_ID_WIDTH +: S_ID_WIDTH],
                    m_axi_awlen[0*8 +: 8]);
            end

            if (m_axi_wvalid[0] && m_axi_wready[0]) begin
                $display("[%0t] M0 W handshake data=%h last=%0d",
                    $time,
                    m_axi_wdata[0*DATA_WIDTH +: DATA_WIDTH],
                    m_axi_wlast[0]);
            end
        end
    end

    initial begin
        $dumpfile("tb_axi_crossbar_wr_aw_block_by_w.vcd");
        $dumpvars(0, tb_axi_crossbar_wr_aw_block_by_w);

        repeat (4) @(posedge clk);
        rst = 1'b0;
        @(negedge clk);

        setup_aw(0, 8'h10, 8'd3);
        setup_aw(1, 8'h20, 8'd0);

        fork
            wait_aw_handshake(0);
            wait_aw_handshake(1);
        join_none

        wait (s0_aw_done);
        repeat (2) @(posedge clk);

        send_wbeat(0, 32'hAAAA_0000, 1'b0);
        repeat (4) @(posedge clk);
        send_wbeat(0, 32'hAAAA_0001, 1'b0);
        repeat (3) @(posedge clk);
        send_wbeat(0, 32'hAAAA_0002, 1'b0);
        repeat (3) @(posedge clk);
        send_wbeat(0, 32'hAAAA_0003, 1'b1);

        wait (s1_aw_done);
        send_wbeat(1, 32'hBBBB_0000, 1'b1);

        wait (b_done_count == 2);
        repeat (4) @(posedge clk);

        if (!saw_initial_conflict) begin
            $display("FAIL did not observe both S ports requesting M0");
            $fatal;
        end
        if (blocked_cycles < 4) begin
            $display("FAIL expected S1 a_request to stay blocked while S0 W burst is active, blocked_cycles=%0d",
                blocked_cycles);
            $fatal;
        end
        if (!saw_s1_request_after_wlast) begin
            $display("FAIL did not observe S1 a_request return after S0 WLAST");
            $fatal;
        end

        $display("PASS tb_axi_crossbar_wr_aw_block_by_w blocked_cycles=%0d", blocked_cycles);
        $finish;
    end

    initial begin
        #3000;
        $display("FAIL timeout in tb_axi_crossbar_wr_aw_block_by_w");
        $fatal;
    end

endmodule
