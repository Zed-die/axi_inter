`timescale 1ns / 1ps

module tb_axi_ic_read_guard;

    localparam DATA_WIDTH = 32;
    localparam ADDR_WIDTH = 32;
    localparam ID_WIDTH = 8;
    localparam DECERR_ADDR = 32'hFFFF_F000;

    logic clk = 1'b0;
    logic rst = 1'b0;

    logic [ID_WIDTH-1:0] s_axi_arid;
    logic [ADDR_WIDTH-1:0] s_axi_araddr;
    logic [7:0] s_axi_arlen;
    logic [2:0] s_axi_arsize;
    logic [1:0] s_axi_arburst;
    logic s_axi_arlock;
    logic [3:0] s_axi_arcache;
    logic [2:0] s_axi_arprot;
    logic [3:0] s_axi_arqos;
    logic s_axi_arvalid;
    wire s_axi_arready;
    wire [ID_WIDTH-1:0] s_axi_rid;
    wire [DATA_WIDTH-1:0] s_axi_rdata;
    wire [1:0] s_axi_rresp;
    wire s_axi_rlast;
    wire s_axi_rvalid;
    logic s_axi_rready;

    wire [ID_WIDTH-1:0] m_axi_arid;
    wire [ADDR_WIDTH-1:0] m_axi_araddr;
    wire [7:0] m_axi_arlen;
    wire [2:0] m_axi_arsize;
    wire [1:0] m_axi_arburst;
    wire m_axi_arlock;
    wire [3:0] m_axi_arcache;
    wire [2:0] m_axi_arprot;
    wire [3:0] m_axi_arqos;
    wire m_axi_arvalid;
    logic m_axi_arready;
    logic [ID_WIDTH-1:0] m_axi_rid;
    logic [DATA_WIDTH-1:0] m_axi_rdata;
    logic [1:0] m_axi_rresp;
    logic m_axi_rlast;
    logic m_axi_rvalid;
    wire m_axi_rready;

    axi_ic_read_guard #(
        .DATA_WIDTH(DATA_WIDTH),
        .ADDR_WIDTH(ADDR_WIDTH),
        .ID_WIDTH(ID_WIDTH),
        .DECERR_ADDR(DECERR_ADDR)
    )
    dut (
        .clk(clk),
        .rst(rst),
        .cfg_master_enable(1'b1),
        .cfg_allow_reads(1'b1),
        .s_axi_arid(s_axi_arid),
        .s_axi_araddr(s_axi_araddr),
        .s_axi_arlen(s_axi_arlen),
        .s_axi_arsize(s_axi_arsize),
        .s_axi_arburst(s_axi_arburst),
        .s_axi_arlock(s_axi_arlock),
        .s_axi_arcache(s_axi_arcache),
        .s_axi_arprot(s_axi_arprot),
        .s_axi_arqos(s_axi_arqos),
        .s_axi_arvalid(s_axi_arvalid),
        .s_axi_arready(s_axi_arready),
        .s_axi_rid(s_axi_rid),
        .s_axi_rdata(s_axi_rdata),
        .s_axi_rresp(s_axi_rresp),
        .s_axi_rlast(s_axi_rlast),
        .s_axi_rvalid(s_axi_rvalid),
        .s_axi_rready(s_axi_rready),
        .m_axi_arid(m_axi_arid),
        .m_axi_araddr(m_axi_araddr),
        .m_axi_arlen(m_axi_arlen),
        .m_axi_arsize(m_axi_arsize),
        .m_axi_arburst(m_axi_arburst),
        .m_axi_arlock(m_axi_arlock),
        .m_axi_arcache(m_axi_arcache),
        .m_axi_arprot(m_axi_arprot),
        .m_axi_arqos(m_axi_arqos),
        .m_axi_arvalid(m_axi_arvalid),
        .m_axi_arready(m_axi_arready),
        .m_axi_rid(m_axi_rid),
        .m_axi_rdata(m_axi_rdata),
        .m_axi_rresp(m_axi_rresp),
        .m_axi_rlast(m_axi_rlast),
        .m_axi_rvalid(m_axi_rvalid),
        .m_axi_rready(m_axi_rready),
        .stat_read_req_pulse(),
        .stat_read_decerr_pulse(),
        .fault_valid(),
        .fault_code(),
        .fault_addr(),
        .fault_id()
    );

    always #5 clk = ~clk;

    task check_ar(
        input [ADDR_WIDTH-1:0] t_addr,
        input [7:0] t_len,
        input [2:0] t_size,
        input [1:0] t_burst,
        input [ADDR_WIDTH-1:0] expected_addr,
        input [1:0] expected_burst,
        input [255:0] name
    );
    begin
        s_axi_araddr = t_addr;
        s_axi_arlen = t_len;
        s_axi_arsize = t_size;
        s_axi_arburst = t_burst;
        s_axi_arvalid = 1'b1;
        #1;
        if (m_axi_araddr !== expected_addr) begin
            $display("FAIL %0s: expected m_axi_araddr=0x%08h got 0x%08h", name, expected_addr, m_axi_araddr);
            $fatal;
        end
        if (m_axi_arburst !== expected_burst) begin
            $display("FAIL %0s: expected m_axi_arburst=%0b got %0b", name, expected_burst, m_axi_arburst);
            $fatal;
        end
    end
    endtask

    task drive_r_beat(
        input [DATA_WIDTH-1:0] data,
        input bit in_last,
        input bit expected_last,
        input [255:0] name
    );
    begin
        m_axi_rid = s_axi_arid;
        m_axi_rdata = data;
        m_axi_rresp = 2'b00;
        m_axi_rlast = in_last;
        m_axi_rvalid = 1'b1;
        #1;
        if (!s_axi_rvalid || s_axi_rdata !== data || s_axi_rlast !== expected_last) begin
            $display("FAIL %0s: expected R data=0x%08h last=%0d got valid=%0d data=0x%08h last=%0d",
                name, data, expected_last, s_axi_rvalid, s_axi_rdata, s_axi_rlast);
            $fatal;
        end
        @(posedge clk);
        #1;
        m_axi_rvalid = 1'b0;
        m_axi_rlast = 1'b0;
    end
    endtask

    task check_cross_4k_decerr_read;
    begin
        s_axi_arid = 8'h5A;
        s_axi_araddr = 32'h0000_0FF8;
        s_axi_arlen = 8'd3;
        s_axi_arsize = 3'd2;
        s_axi_arburst = 2'b01;
        s_axi_arvalid = 1'b1;
        m_axi_arready = 1'b1;

        #1;
        if (!s_axi_arready || !m_axi_arvalid || m_axi_araddr !== DECERR_ADDR ||
                m_axi_arlen !== 8'd3 || m_axi_arburst !== 2'b01) begin
            $display("FAIL cross-4KB read should route to DECERR without split: ready=%0d valid=%0d addr=0x%08h len=%0d burst=%b",
                s_axi_arready, m_axi_arvalid, m_axi_araddr, m_axi_arlen, m_axi_arburst);
            $fatal;
        end
        if (s_axi_rlast !== m_axi_rlast) begin
            $display("FAIL cross-4KB read should not mask downstream RLAST before response");
            $fatal;
        end

        @(posedge clk);
        #1;
        s_axi_arvalid = 1'b0;
        @(posedge clk);
        #1;

        drive_r_beat(32'h1111_0000, 1'b1, 1'b1, "cross-4KB decerr response");

        if (m_axi_arvalid) begin
            $display("FAIL cross-4KB read should issue only one downstream AR");
            $fatal;
        end
    end
    endtask

    initial begin
        rst = 1'b1;
        s_axi_arid = 8'h34;
        s_axi_araddr = '0;
        s_axi_arlen = '0;
        s_axi_arsize = 3'd2;
        s_axi_arburst = 2'b01;
        s_axi_arlock = 1'b0;
        s_axi_arcache = 4'h0;
        s_axi_arprot = 3'h0;
        s_axi_arqos = 4'h0;
        s_axi_arvalid = 1'b0;
        s_axi_rready = 1'b1;

        m_axi_arready = 1'b1;
        m_axi_rid = 8'hBC;
        m_axi_rdata = 32'h89AB_CDEF;
        m_axi_rresp = 2'b00;
        m_axi_rlast = 1'b1;
        m_axi_rvalid = 1'b0;

        repeat (2) @(posedge clk);
        rst = 1'b0;
        @(posedge clk);

        check_ar(32'h0000_0200, 8'd3, 3'd2, 2'b01, 32'h0000_0200, 2'b01, "valid_incr_passthrough");
        check_cross_4k_decerr_read();
        check_ar(32'h0000_0034, 8'd3, 3'd2, 2'b10, 32'h0000_0034, 2'b10, "valid_wrap_passthrough");

        #1;
        m_axi_rid = 8'hBC;
        m_axi_rdata = 32'h89AB_CDEF;
        m_axi_rresp = 2'b00;
        m_axi_rlast = 1'b1;
        m_axi_rvalid = 1'b1;
        #1;
        if (s_axi_arready !== m_axi_arready) begin
            $display("FAIL arready passthrough");
            $fatal;
        end
        if (s_axi_rid !== m_axi_rid || s_axi_rdata !== m_axi_rdata || s_axi_rresp !== m_axi_rresp ||
                s_axi_rlast !== m_axi_rlast || s_axi_rvalid !== m_axi_rvalid || m_axi_rready !== s_axi_rready) begin
            $display("FAIL r channel passthrough");
            $fatal;
        end

        $display("PASS tb_axi_ic_read_guard");
        $finish;
    end

endmodule
