`timescale 1ns / 1ps

module tb_axi_crossbar_wr_decerr_bresp;

    localparam S_COUNT = 1;
    localparam M_COUNT = 1;
    localparam DATA_WIDTH = 32;
    localparam ADDR_WIDTH = 32;
    localparam STRB_WIDTH = DATA_WIDTH/8;
    localparam S_ID_WIDTH = 8;
    localparam M_ID_WIDTH = S_ID_WIDTH + $clog2(S_COUNT);

    localparam [M_COUNT*ADDR_WIDTH-1:0] M_BASE_ADDR = {
        32'h0001_0000,
        32'h0000_0000
    };
    localparam [M_COUNT*32-1:0] M_ADDR_WIDTH = {
        32'd16,
        32'd16
    };

    logic clk = 1'b0;
    logic rst = 1'b1;

    logic [S_COUNT*S_ID_WIDTH-1:0] s_axi_awid = '0;
    logic [S_COUNT*ADDR_WIDTH-1:0] s_axi_awaddr = '0;
    logic [S_COUNT*8-1:0] s_axi_awlen = '0;
    logic [S_COUNT*3-1:0] s_axi_awsize = '0;
    logic [S_COUNT*2-1:0] s_axi_awburst = '0;
    logic [S_COUNT-1:0] s_axi_awlock = '0;
    logic [S_COUNT*4-1:0] s_axi_awcache = '0;
    logic [S_COUNT*3-1:0] s_axi_awprot = '0;
    logic [S_COUNT*4-1:0] s_axi_awqos = '0;
    logic [S_COUNT-1:0] s_axi_awvalid = '0;
    wire [S_COUNT-1:0] s_axi_awready;

    logic [S_COUNT*DATA_WIDTH-1:0] s_axi_wdata = '0;
    logic [S_COUNT*STRB_WIDTH-1:0] s_axi_wstrb = '0;
    logic [S_COUNT-1:0] s_axi_wlast = '0;
    logic [S_COUNT-1:0] s_axi_wvalid = '0;
    wire [S_COUNT-1:0] s_axi_wready;

    wire [S_COUNT*S_ID_WIDTH-1:0] s_axi_bid;
    wire [S_COUNT*2-1:0] s_axi_bresp;
    wire [S_COUNT-1:0] s_axi_bvalid;
    logic [S_COUNT-1:0] s_axi_bready = {S_COUNT{1'b1}};

    wire [M_COUNT*M_ID_WIDTH-1:0] m_axi_awid;
    wire [M_COUNT*ADDR_WIDTH-1:0] m_axi_awaddr;
    wire [M_COUNT*8-1:0] m_axi_awlen;
    wire [M_COUNT*3-1:0] m_axi_awsize;
    wire [M_COUNT*2-1:0] m_axi_awburst;
    wire [M_COUNT-1:0] m_axi_awlock;
    wire [M_COUNT*4-1:0] m_axi_awcache;
    wire [M_COUNT*3-1:0] m_axi_awprot;
    wire [M_COUNT*4-1:0] m_axi_awqos;
    wire [M_COUNT*4-1:0] m_axi_awregion;
    wire [M_COUNT-1:0] m_axi_awvalid;
    logic [M_COUNT-1:0] m_axi_awready = {M_COUNT{1'b1}};

    wire [M_COUNT*DATA_WIDTH-1:0] m_axi_wdata;
    wire [M_COUNT*STRB_WIDTH-1:0] m_axi_wstrb;
    wire [M_COUNT-1:0] m_axi_wlast;
    wire [M_COUNT-1:0] m_axi_wvalid;
    logic [M_COUNT-1:0] m_axi_wready = {M_COUNT{1'b1}};

    logic [M_COUNT*M_ID_WIDTH-1:0] m_axi_bid = '0;
    logic [M_COUNT*2-1:0] m_axi_bresp = '0;
    logic [M_COUNT-1:0] m_axi_bvalid = '0;
    wire [M_COUNT-1:0] m_axi_bready;

    logic saw_bad_aw_hs = 1'b0;
    logic saw_s_wlast_hs = 1'b0;
    logic saw_s_b_hs = 1'b0;
    logic saw_decerr_bresp = 1'b0;
    logic saw_b_before_wlast = 1'b0;
    integer master_aw_count = 0;
    integer master_w_count = 0;

    axi_crossbar_wr #(
        .S_COUNT(S_COUNT),
        .M_COUNT(M_COUNT),
        .DATA_WIDTH(DATA_WIDTH),
        .ADDR_WIDTH(ADDR_WIDTH),
        .STRB_WIDTH(STRB_WIDTH),
        .S_ID_WIDTH(S_ID_WIDTH),
        .M_ID_WIDTH(M_ID_WIDTH),
        .S_THREADS({S_COUNT{32'd2}}),
        .S_ACCEPT({S_COUNT{32'd4}}),
        .M_REGIONS(1),
        .M_BASE_ADDR(M_BASE_ADDR),
        .M_ADDR_WIDTH(M_ADDR_WIDTH),
        .M_CONNECT({M_COUNT{{S_COUNT{1'b1}}}}),
        .M_ISSUE({M_COUNT{32'd4}}),
        .M_SECURE({M_COUNT{1'b0}}),
        .S_AW_REG_TYPE({S_COUNT{2'd0}}),
        .S_W_REG_TYPE({S_COUNT{2'd0}}),
        .S_B_REG_TYPE({S_COUNT{2'd0}}),
        .M_AW_REG_TYPE({M_COUNT{2'd0}}),
        .M_W_REG_TYPE({M_COUNT{2'd0}}),
        .M_B_REG_TYPE({M_COUNT{2'd0}})
    )
    dut (
        .clk(clk),
        .rst(rst),
        .s_axi_awid(s_axi_awid),
        .s_axi_awaddr(s_axi_awaddr),
        .s_axi_awlen(s_axi_awlen),
        .s_axi_awsize(s_axi_awsize),
        .s_axi_awburst(s_axi_awburst),
        .s_axi_awlock(s_axi_awlock),
        .s_axi_awcache(s_axi_awcache),
        .s_axi_awprot(s_axi_awprot),
        .s_axi_awqos(s_axi_awqos),
        .s_axi_awuser({S_COUNT{1'b0}}),
        .s_axi_awvalid(s_axi_awvalid),
        .s_axi_awready(s_axi_awready),
        .s_axi_wdata(s_axi_wdata),
        .s_axi_wstrb(s_axi_wstrb),
        .s_axi_wlast(s_axi_wlast),
        .s_axi_wuser({S_COUNT{1'b0}}),
        .s_axi_wvalid(s_axi_wvalid),
        .s_axi_wready(s_axi_wready),
        .s_axi_bid(s_axi_bid),
        .s_axi_bresp(s_axi_bresp),
        .s_axi_buser(),
        .s_axi_bvalid(s_axi_bvalid),
        .s_axi_bready(s_axi_bready),
        .m_axi_awid(m_axi_awid),
        .m_axi_awaddr(m_axi_awaddr),
        .m_axi_awlen(m_axi_awlen),
        .m_axi_awsize(m_axi_awsize),
        .m_axi_awburst(m_axi_awburst),
        .m_axi_awlock(m_axi_awlock),
        .m_axi_awcache(m_axi_awcache),
        .m_axi_awprot(m_axi_awprot),
        .m_axi_awqos(m_axi_awqos),
        .m_axi_awregion(m_axi_awregion),
        .m_axi_awuser(),
        .m_axi_awvalid(m_axi_awvalid),
        .m_axi_awready(m_axi_awready),
        .m_axi_wdata(m_axi_wdata),
        .m_axi_wstrb(m_axi_wstrb),
        .m_axi_wlast(m_axi_wlast),
        .m_axi_wuser(),
        .m_axi_wvalid(m_axi_wvalid),
        .m_axi_wready(m_axi_wready),
        .m_axi_bid(m_axi_bid),
        .m_axi_bresp(m_axi_bresp),
        .m_axi_buser({M_COUNT{1'b0}}),
        .m_axi_bvalid(m_axi_bvalid),
        .m_axi_bready(m_axi_bready)
    );

    always #5 clk = ~clk;

    task automatic issue_bad_aw;
    begin
        @(negedge clk);
        s_axi_awid[0*S_ID_WIDTH +: S_ID_WIDTH] = 8'h5a;
        s_axi_awaddr[0*ADDR_WIDTH +: ADDR_WIDTH] = 32'h0002_0100;
        s_axi_awlen[0*8 +: 8] = 8'd3;
        s_axi_awsize[0*3 +: 3] = 3'd2;
        s_axi_awburst[0*2 +: 2] = 2'b01;
        s_axi_awvalid[0] = 1'b1;
        wait (s_axi_awready[0]);
        @(posedge clk);
        #1;
        @(negedge clk);
        s_axi_awvalid[0] = 1'b0;
    end
    endtask

    task automatic send_wbeat(input [DATA_WIDTH-1:0] data, input bit last);
    begin
        @(negedge clk);
        s_axi_wdata[0*DATA_WIDTH +: DATA_WIDTH] = data;
        s_axi_wstrb[0*STRB_WIDTH +: STRB_WIDTH] = {STRB_WIDTH{1'b1}};
        s_axi_wlast[0] = last;
        s_axi_wvalid[0] = 1'b1;
        wait (s_axi_wready[0]);
        @(posedge clk);
        #1;
        @(negedge clk);
        s_axi_wvalid[0] = 1'b0;
        s_axi_wlast[0] = 1'b0;
    end
    endtask

    always @(posedge clk) begin
        if (rst) begin
            saw_bad_aw_hs <= 1'b0;
            saw_s_wlast_hs <= 1'b0;
            saw_s_b_hs <= 1'b0;
            saw_decerr_bresp <= 1'b0;
            saw_b_before_wlast <= 1'b0;
            master_aw_count <= 0;
            master_w_count <= 0;
        end else begin
            if (s_axi_awvalid[0] && s_axi_awready[0]) begin
                saw_bad_aw_hs <= 1'b1;
                $display("[%0t] S0 AW handshake invalid_addr=%h id=%h len=%0d",
                    $time,
                    s_axi_awaddr[0*ADDR_WIDTH +: ADDR_WIDTH],
                    s_axi_awid[0*S_ID_WIDTH +: S_ID_WIDTH],
                    s_axi_awlen[0*8 +: 8]);
            end

            if (s_axi_wvalid[0] && s_axi_wready[0]) begin
                $display("[%0t] S0 W handshake data=%h last=%0d",
                    $time,
                    s_axi_wdata[0*DATA_WIDTH +: DATA_WIDTH],
                    s_axi_wlast[0]);
                if (s_axi_wlast[0]) begin
                    saw_s_wlast_hs <= 1'b1;
                end
            end

            if (s_axi_bvalid[0] && s_axi_bready[0]) begin
                saw_s_b_hs <= 1'b1;
                if (!saw_s_wlast_hs) begin
                    saw_b_before_wlast <= 1'b1;
                end
                if (s_axi_bresp[0*2 +: 2] == 2'b11) begin
                    saw_decerr_bresp <= 1'b1;
                end
                $display("[%0t] S0 B handshake bid=%h bresp=%b before_wlast=%0d",
                    $time,
                    s_axi_bid[0*S_ID_WIDTH +: S_ID_WIDTH],
                    s_axi_bresp[0*2 +: 2],
                    !saw_s_wlast_hs);
            end

            if (|m_axi_awvalid) begin
                master_aw_count <= master_aw_count + 1;
                $display("[%0t] Unexpected M AW valid=%b addr0=%h addr1=%h",
                    $time,
                    m_axi_awvalid,
                    m_axi_awaddr[0*ADDR_WIDTH +: ADDR_WIDTH],
                    m_axi_awaddr[1*ADDR_WIDTH +: ADDR_WIDTH]);
            end

            if (|m_axi_wvalid) begin
                master_w_count <= master_w_count + 1;
                $display("[%0t] Unexpected M W valid=%b", $time, m_axi_wvalid);
            end
        end
    end

    initial begin
        $dumpfile("tb_axi_crossbar_wr_decerr_bresp.vcd");
        $dumpvars(0, tb_axi_crossbar_wr_decerr_bresp);

        repeat (4) @(posedge clk);
        rst = 1'b0;

        issue_bad_aw();

        repeat (8) @(posedge clk);

        send_wbeat(32'hdead_0000, 1'b0);
        send_wbeat(32'hdead_0001, 1'b0);
        send_wbeat(32'hdead_0002, 1'b0);
        send_wbeat(32'hdead_0003, 1'b1);

        wait (saw_s_b_hs && saw_s_wlast_hs);
        repeat (4) @(posedge clk);

        if (!saw_bad_aw_hs) begin
            $display("FAIL did not observe S0 invalid AW handshake");
            $fatal;
        end
        if (!saw_decerr_bresp) begin
            $display("FAIL did not observe BRESP=DECERR");
            $fatal;
        end
        if (master_aw_count != 0 || master_w_count != 0) begin
            $display("FAIL decode-error transaction leaked to M side: aw_count=%0d w_count=%0d",
                master_aw_count,
                master_w_count);
            $fatal;
        end

        if (saw_b_before_wlast) begin
            $display("FAIL BRESP=DECERR was returned before S0 WLAST");
            $fatal;
        end

        $display("PASS tb_axi_crossbar_wr_decerr_bresp");
        $finish;
    end

    initial begin
        #3000;
        $display("FAIL timeout in tb_axi_crossbar_wr_decerr_bresp");
        $fatal;
    end

endmodule
