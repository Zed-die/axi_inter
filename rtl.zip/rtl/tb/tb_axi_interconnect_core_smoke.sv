`timescale 1ns / 1ps

module tb_axi_interconnect_core_smoke;

    localparam S_COUNT = 2;
    localparam M_COUNT = 2;
    localparam DATA_WIDTH = 32;
    localparam ADDR_WIDTH = 32;
    localparam STRB_WIDTH = DATA_WIDTH/8;
    localparam S_ID_WIDTH = 8;
    localparam M_ID_WIDTH = S_ID_WIDTH + $clog2(S_COUNT);
    localparam [ADDR_WIDTH-1:0] DECERR_ADDR = 32'hFFFF_F000;
    localparam [M_COUNT*ADDR_WIDTH-1:0] M_BASE_ADDR = {32'h0001_0000, 32'h0000_0000};
    localparam [M_COUNT*32-1:0] M_ADDR_WIDTH = {32'd16, 32'd16};

    logic clk = 1'b0;
    logic rst = 1'b1;
    logic [11:0] cfg_paddr = '0;
    logic cfg_psel = 1'b0;
    logic cfg_penable = 1'b0;
    logic cfg_pwrite = 1'b0;
    logic [31:0] cfg_pwdata = '0;
    wire [31:0] cfg_prdata;
    wire cfg_pready;
    wire cfg_pslverr;

    logic [S_COUNT*S_ID_WIDTH-1:0] s_axi_awid = '0;
    logic [S_COUNT*ADDR_WIDTH-1:0] s_axi_awaddr = '0;
    logic [S_COUNT*8-1:0] s_axi_awlen = '0;
    logic [S_COUNT*3-1:0] s_axi_awsize = '0;
    logic [S_COUNT*2-1:0] s_axi_awburst = '0;
    logic [S_COUNT-1:0] s_axi_awlock = '0;
    logic [S_COUNT*4-1:0] s_axi_awcache = '0;
    logic [S_COUNT*3-1:0] s_axi_awprot = '0;
    logic [S_COUNT*4-1:0] s_axi_awqos = '0;
    logic [S_COUNT-1:0] s_axi_awvalid = '0;
    wire [S_COUNT-1:0] s_axi_awready;
    logic [S_COUNT*DATA_WIDTH-1:0] s_axi_wdata = '0;
    logic [S_COUNT*STRB_WIDTH-1:0] s_axi_wstrb = '0;
    logic [S_COUNT-1:0] s_axi_wlast = '0;
    logic [S_COUNT-1:0] s_axi_wvalid = '0;
    wire [S_COUNT-1:0] s_axi_wready;
    wire [S_COUNT*S_ID_WIDTH-1:0] s_axi_bid;
    wire [S_COUNT*2-1:0] s_axi_bresp;
    wire [S_COUNT-1:0] s_axi_bvalid;
    logic [S_COUNT-1:0] s_axi_bready = '0;

    logic [S_COUNT*S_ID_WIDTH-1:0] s_axi_arid = '0;
    logic [S_COUNT*ADDR_WIDTH-1:0] s_axi_araddr = '0;
    logic [S_COUNT*8-1:0] s_axi_arlen = '0;
    logic [S_COUNT*3-1:0] s_axi_arsize = '0;
    logic [S_COUNT*2-1:0] s_axi_arburst = '0;
    logic [S_COUNT-1:0] s_axi_arlock = '0;
    logic [S_COUNT*4-1:0] s_axi_arcache = '0;
    logic [S_COUNT*3-1:0] s_axi_arprot = '0;
    logic [S_COUNT*4-1:0] s_axi_arqos = '0;
    logic [S_COUNT-1:0] s_axi_arvalid = '0;
    wire [S_COUNT-1:0] s_axi_arready;
    wire [S_COUNT*S_ID_WIDTH-1:0] s_axi_rid;
    wire [S_COUNT*DATA_WIDTH-1:0] s_axi_rdata;
    wire [S_COUNT*2-1:0] s_axi_rresp;
    wire [S_COUNT-1:0] s_axi_rlast;
    wire [S_COUNT-1:0] s_axi_rvalid;
    logic [S_COUNT-1:0] s_axi_rready = '1;

    wire [M_COUNT*M_ID_WIDTH-1:0] m_axi_awid;
    wire [M_COUNT*ADDR_WIDTH-1:0] m_axi_awaddr;
    wire [M_COUNT*8-1:0] m_axi_awlen;
    wire [M_COUNT*3-1:0] m_axi_awsize;
    wire [M_COUNT*2-1:0] m_axi_awburst;
    wire [M_COUNT-1:0] m_axi_awlock;
    wire [M_COUNT*4-1:0] m_axi_awcache;
    wire [M_COUNT*3-1:0] m_axi_awprot;
    wire [M_COUNT*4-1:0] m_axi_awqos;
    wire [M_COUNT*4-1:0] m_axi_awregion;
    wire [M_COUNT-1:0] m_axi_awvalid;
    logic [M_COUNT-1:0] m_axi_awready = '1;
    wire [M_COUNT*DATA_WIDTH-1:0] m_axi_wdata;
    wire [M_COUNT*STRB_WIDTH-1:0] m_axi_wstrb;
    wire [M_COUNT-1:0] m_axi_wlast;
    wire [M_COUNT-1:0] m_axi_wvalid;
    logic [M_COUNT-1:0] m_axi_wready = '1;
    logic [M_COUNT*M_ID_WIDTH-1:0] m_axi_bid = '0;
    logic [M_COUNT*2-1:0] m_axi_bresp = '0;
    logic [M_COUNT-1:0] m_axi_bvalid = '0;
    wire [M_COUNT-1:0] m_axi_bready;
    wire [M_COUNT*M_ID_WIDTH-1:0] m_axi_arid;
    wire [M_COUNT*ADDR_WIDTH-1:0] m_axi_araddr;
    wire [M_COUNT*8-1:0] m_axi_arlen;
    wire [M_COUNT*3-1:0] m_axi_arsize;
    wire [M_COUNT*2-1:0] m_axi_arburst;
    wire [M_COUNT-1:0] m_axi_arlock;
    wire [M_COUNT*4-1:0] m_axi_arcache;
    wire [M_COUNT*3-1:0] m_axi_arprot;
    wire [M_COUNT*4-1:0] m_axi_arqos;
    wire [M_COUNT*4-1:0] m_axi_arregion;
    wire [M_COUNT-1:0] m_axi_arvalid;
    logic [M_COUNT-1:0] m_axi_arready = '1;
    logic [M_COUNT*M_ID_WIDTH-1:0] m_axi_rid = '0;
    logic [M_COUNT*DATA_WIDTH-1:0] m_axi_rdata = '0;
    logic [M_COUNT*2-1:0] m_axi_rresp = '0;
    logic [M_COUNT-1:0] m_axi_rlast = '0;
    logic [M_COUNT-1:0] m_axi_rvalid = '0;
    wire [M_COUNT-1:0] m_axi_rready;
    wire [M_COUNT*32-1:0] m_ahb_haddr;
    wire [M_COUNT*2-1:0] m_ahb_htrans;
    wire [M_COUNT-1:0] m_ahb_hwrite;
    wire [M_COUNT*3-1:0] m_ahb_hsize;
    wire [M_COUNT*3-1:0] m_ahb_hburst;
    wire [M_COUNT*64-1:0] m_ahb_hwdata;
    wire [M_COUNT-1:0] m_ahb_hbusreq;
    wire [M_COUNT-1:0] m_ahb_hlock;
    logic [M_COUNT*64-1:0] m_ahb_hrdata = '0;
    logic [M_COUNT-1:0] m_ahb_hready = '1;
    logic [M_COUNT*2-1:0] m_ahb_hresp = '0;
    logic [M_COUNT-1:0] m_ahb_hgrant = '0;
    logic [M_COUNT*4-1:0] m_ahb_hmaster = '0;

    logic [M_ID_WIDTH-1:0] slave0_pending_bid = '0;
    logic slave0_issue_b = 1'b0;
    logic slave0_seen_invalid_aw = 1'b0;
    logic slave0_seen_valid_aw = 1'b0;
    logic slave0_seen_valid_b = 1'b0;
    logic [ADDR_WIDTH-1:0] slave0_last_awaddr = '0;

    axi_interconnect_core #(
        .S_COUNT(S_COUNT),
        .M_COUNT(M_COUNT),
        .DATA_WIDTH(DATA_WIDTH),
        .ADDR_WIDTH(ADDR_WIDTH),
        .STRB_WIDTH(STRB_WIDTH),
        .S_ID_WIDTH(S_ID_WIDTH),
        .M_ID_WIDTH(M_ID_WIDTH),
        .M_BASE_ADDR(M_BASE_ADDR),
        .M_ADDR_WIDTH(M_ADDR_WIDTH),
        .DECERR_ADDR(DECERR_ADDR)
    )
    dut (
        .clk(clk),
        .rst(rst),
        .cfg_paddr(cfg_paddr),
        .cfg_psel(cfg_psel),
        .cfg_penable(cfg_penable),
        .cfg_pwrite(cfg_pwrite),
        .cfg_pwdata(cfg_pwdata),
        .cfg_prdata(cfg_prdata),
        .cfg_pready(cfg_pready),
        .cfg_pslverr(cfg_pslverr),
        .s_axi_awid(s_axi_awid),
        .s_axi_awaddr(s_axi_awaddr),
        .s_axi_awlen(s_axi_awlen),
        .s_axi_awsize(s_axi_awsize),
        .s_axi_awburst(s_axi_awburst),
        .s_axi_awlock(s_axi_awlock),
        .s_axi_awcache(s_axi_awcache),
        .s_axi_awprot(s_axi_awprot),
        .s_axi_awqos(s_axi_awqos),
        .s_axi_awuser({S_COUNT{1'b0}}),
        .s_axi_awvalid(s_axi_awvalid),
        .s_axi_awready(s_axi_awready),
        .s_axi_wdata(s_axi_wdata),
        .s_axi_wstrb(s_axi_wstrb),
        .s_axi_wlast(s_axi_wlast),
        .s_axi_wuser({S_COUNT{1'b0}}),
        .s_axi_wvalid(s_axi_wvalid),
        .s_axi_wready(s_axi_wready),
        .s_axi_bid(s_axi_bid),
        .s_axi_bresp(s_axi_bresp),
        .s_axi_buser(),
        .s_axi_bvalid(s_axi_bvalid),
        .s_axi_bready(s_axi_bready),
        .s_axi_arid(s_axi_arid),
        .s_axi_araddr(s_axi_araddr),
        .s_axi_arlen(s_axi_arlen),
        .s_axi_arsize(s_axi_arsize),
        .s_axi_arburst(s_axi_arburst),
        .s_axi_arlock(s_axi_arlock),
        .s_axi_arcache(s_axi_arcache),
        .s_axi_arprot(s_axi_arprot),
        .s_axi_arqos(s_axi_arqos),
        .s_axi_aruser({S_COUNT{1'b0}}),
        .s_axi_arvalid(s_axi_arvalid),
        .s_axi_arready(s_axi_arready),
        .s_axi_rid(s_axi_rid),
        .s_axi_rdata(s_axi_rdata),
        .s_axi_rresp(s_axi_rresp),
        .s_axi_rlast(s_axi_rlast),
        .s_axi_ruser(),
        .s_axi_rvalid(s_axi_rvalid),
        .s_axi_rready(s_axi_rready),
        .m_axi_awid(m_axi_awid),
        .m_axi_awaddr(m_axi_awaddr),
        .m_axi_awlen(m_axi_awlen),
        .m_axi_awsize(m_axi_awsize),
        .m_axi_awburst(m_axi_awburst),
        .m_axi_awlock(m_axi_awlock),
        .m_axi_awcache(m_axi_awcache),
        .m_axi_awprot(m_axi_awprot),
        .m_axi_awqos(m_axi_awqos),
        .m_axi_awregion(m_axi_awregion),
        .m_axi_awuser(),
        .m_axi_awvalid(m_axi_awvalid),
        .m_axi_awready(m_axi_awready),
        .m_axi_wdata(m_axi_wdata),
        .m_axi_wstrb(m_axi_wstrb),
        .m_axi_wlast(m_axi_wlast),
        .m_axi_wuser(),
        .m_axi_wvalid(m_axi_wvalid),
        .m_axi_wready(m_axi_wready),
        .m_axi_bid(m_axi_bid),
        .m_axi_bresp(m_axi_bresp),
        .m_axi_buser({M_COUNT{1'b0}}),
        .m_axi_bvalid(m_axi_bvalid),
        .m_axi_bready(m_axi_bready),
        .m_axi_arid(m_axi_arid),
        .m_axi_araddr(m_axi_araddr),
        .m_axi_arlen(m_axi_arlen),
        .m_axi_arsize(m_axi_arsize),
        .m_axi_arburst(m_axi_arburst),
        .m_axi_arlock(m_axi_arlock),
        .m_axi_arcache(m_axi_arcache),
        .m_axi_arprot(m_axi_arprot),
        .m_axi_arqos(m_axi_arqos),
        .m_axi_arregion(m_axi_arregion),
        .m_axi_aruser(),
        .m_axi_arvalid(m_axi_arvalid),
        .m_axi_arready(m_axi_arready),
        .m_axi_rid(m_axi_rid),
        .m_axi_rdata(m_axi_rdata),
        .m_axi_rresp(m_axi_rresp),
        .m_axi_rlast(m_axi_rlast),
        .m_axi_ruser({M_COUNT{1'b0}}),
        .m_axi_rvalid(m_axi_rvalid),
        .m_axi_rready(m_axi_rready),
        .m_ahb_haddr(m_ahb_haddr),
        .m_ahb_htrans(m_ahb_htrans),
        .m_ahb_hwrite(m_ahb_hwrite),
        .m_ahb_hsize(m_ahb_hsize),
        .m_ahb_hburst(m_ahb_hburst),
        .m_ahb_hwdata(m_ahb_hwdata),
        .m_ahb_hbusreq(m_ahb_hbusreq),
        .m_ahb_hlock(m_ahb_hlock),
        .m_ahb_hrdata(m_ahb_hrdata),
        .m_ahb_hready(m_ahb_hready),
        .m_ahb_hresp(m_ahb_hresp),
        .m_ahb_hgrant(m_ahb_hgrant),
        .m_ahb_hmaster(m_ahb_hmaster)
    );

    always #5 clk = ~clk;

    always @(posedge clk) begin
        if (rst) begin
            slave0_pending_bid <= '0;
            slave0_issue_b <= 1'b0;
            slave0_seen_invalid_aw <= 1'b0;
            slave0_seen_valid_aw <= 1'b0;
            slave0_seen_valid_b <= 1'b0;
            slave0_last_awaddr <= '0;
            m_axi_bvalid[0] <= 1'b0;
            m_axi_bresp[1:0] <= 2'b00;
            m_axi_bid[M_ID_WIDTH-1:0] <= '0;
        end else begin
            if (m_axi_awvalid[0] && m_axi_awready[0]) begin
                slave0_pending_bid <= m_axi_awid[M_ID_WIDTH-1:0];
                slave0_last_awaddr <= m_axi_awaddr[ADDR_WIDTH-1:0];
                if (m_axi_awaddr[ADDR_WIDTH-1:0] == 32'h0000_0100) begin
                    slave0_seen_valid_aw <= 1'b1;
                end
                if (m_axi_awid[M_ID_WIDTH-1:0] == 9'h022) begin
                    if (m_axi_awlen[7:0] !== 8'd1 || m_axi_awburst[1:0] !== 2'b10) begin
                        $display("FAIL WRAP burst should reach target unchanged: len=%0d burst=%b",
                            m_axi_awlen[7:0], m_axi_awburst[1:0]);
                        $fatal;
                    end
                end
                if (m_axi_awaddr[ADDR_WIDTH-1:0] == DECERR_ADDR) begin
                    slave0_seen_invalid_aw <= 1'b1;
                end
            end

            if (m_axi_bvalid[0] && m_axi_bready[0]) begin
                m_axi_bvalid[0] <= 1'b0;
            end else if (slave0_issue_b && !m_axi_bvalid[0]) begin
                $display("[%0t] Slave0 generates B id=%h", $time, slave0_pending_bid);
                m_axi_bid[M_ID_WIDTH-1:0] <= slave0_pending_bid;
                m_axi_bresp[1:0] <= 2'b00;
                m_axi_bvalid[0] <= 1'b1;
            end

            if (m_axi_wvalid[0] && m_axi_wready[0] && m_axi_wlast[0]) begin
                $display("[%0t] Slave0 schedules B after WLAST", $time);
                slave0_issue_b <= 1'b1;
            end else if (slave0_issue_b && !m_axi_bvalid[0]) begin
                slave0_issue_b <= 1'b0;
            end
        end
    end

    always @(posedge clk) begin
        if (!rst) begin
            if (s_axi_awvalid[0] && s_axi_awready[0]) begin
                $display("[%0t] S0 AW handshake addr=%h len=%0d burst=%0d id=%h", $time, s_axi_awaddr[31:0], s_axi_awlen[7:0], s_axi_awburst[1:0], s_axi_awid[7:0]);
            end
            if (s_axi_wvalid[0] && s_axi_wready[0]) begin
                $display("[%0t] S0 W handshake data=%h last=%0d", $time, s_axi_wdata[31:0], s_axi_wlast[0]);
            end
            if (s_axi_bvalid[0] && s_axi_bready[0]) begin
                $display("[%0t] S0 B handshake resp=%b id=%h", $time, s_axi_bresp[1:0], s_axi_bid[7:0]);
                if (s_axi_bresp[1:0] == 2'b00 && s_axi_bid[7:0] == 8'h22) begin
                    slave0_seen_valid_b <= 1'b1;
                end
            end
            if (m_axi_awvalid[0] && m_axi_awready[0]) begin
                $display("[%0t] M0 AW handshake addr=%h id=%h", $time, m_axi_awaddr[31:0], m_axi_awid[M_ID_WIDTH-1:0]);
            end
            if (m_axi_wvalid[0] && m_axi_wready[0]) begin
                $display("[%0t] M0 W handshake data=%h last=%0d", $time, m_axi_wdata[31:0], m_axi_wlast[0]);
            end
            if (m_axi_bvalid[0] && m_axi_bready[0]) begin
                $display("[%0t] M0 B handshake resp=%b id=%h", $time, m_axi_bresp[1:0], m_axi_bid[M_ID_WIDTH-1:0]);
            end
            if (m_axi_bvalid[0] && !m_axi_bready[0]) begin
                $display("[%0t] M0 B pending resp=%b id=%h ready=%0d", $time, m_axi_bresp[1:0], m_axi_bid[M_ID_WIDTH-1:0], m_axi_bready[0]);
            end
            if (s_axi_bvalid[0] && !s_axi_bready[0]) begin
                $display("[%0t] S0 B pending resp=%b id=%h", $time, s_axi_bresp[1:0], s_axi_bid[7:0]);
            end
        end
    end

    task automatic send_aw(
        input [31:0] addr,
        input [7:0] len,
        input [2:0] size,
        input [1:0] burst,
        input [7:0] id
    );
    begin
        @(posedge clk);
        $display("[%0t] Drive S0 AW addr=%h len=%0d burst=%0d id=%h", $time, addr, len, burst, id);
        s_axi_awaddr[31:0] <= addr;
        s_axi_awlen[7:0] <= len;
        s_axi_awsize[2:0] <= size;
        s_axi_awburst[1:0] <= burst;
        s_axi_awid[7:0] <= id;
        s_axi_awvalid[0] <= 1'b1;
        wait (s_axi_awready[0]);
        $display("[%0t] Observe S0 AWREADY", $time);
        @(posedge clk);
        s_axi_awvalid[0] <= 1'b0;
    end
    endtask

    task automatic send_wbeat(input [31:0] data, input bit last);
    begin
        @(posedge clk);
        $display("[%0t] Drive S0 W data=%h last=%0d", $time, data, last);
        s_axi_wdata[31:0] <= data;
        s_axi_wstrb[3:0] <= 4'hF;
        s_axi_wlast[0] <= last;
        s_axi_wvalid[0] <= 1'b1;
        wait (s_axi_wready[0]);
        $display("[%0t] Observe S0 WREADY last=%0d", $time, last);
        @(posedge clk);
        s_axi_wvalid[0] <= 1'b0;
        s_axi_wlast[0] <= 1'b0;
    end
    endtask

    initial begin
        #2000;
        $display("FAIL timeout in tb_axi_interconnect_core_smoke");
        $fatal;
    end

    initial begin
        repeat (4) @(posedge clk);
        rst <= 1'b0;

        send_aw(32'h0000_0FFC, 8'd1, 3'd2, 2'b01, 8'h11);
        send_wbeat(32'hAAAA_0001, 1'b0);
        send_wbeat(32'hAAAA_0002, 1'b1);

        wait (s_axi_bvalid[0]);
        if (s_axi_bresp[1:0] !== 2'b11) begin
            $display("FAIL invalid burst should return DECERR");
            $fatal;
        end
        if (slave0_seen_invalid_aw) begin
            $display("FAIL invalid burst should not reach mapped downstream target");
            $fatal;
        end
        s_axi_bready[0] <= 1'b1;
        @(posedge clk);

        send_aw(32'h0000_0100, 8'd1, 3'd2, 2'b10, 8'h22);
        send_wbeat(32'hBBBB_0001, 1'b0);
        send_wbeat(32'hBBBB_0002, 1'b1);

        wait (slave0_seen_valid_aw);
        wait (slave0_seen_valid_b);
        if (slave0_last_awaddr !== 32'h0000_0100) begin
            $display("FAIL WRAP burst address changed before reaching downstream: last_awaddr=%h",
                slave0_last_awaddr);
            $fatal;
        end

        $display("PASS tb_axi_interconnect_core_smoke");
        $finish;
    end

endmodule
