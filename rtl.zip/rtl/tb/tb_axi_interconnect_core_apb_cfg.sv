`timescale 1ns / 1ps

module tb_axi_interconnect_core_apb_cfg;

    localparam S_COUNT = 1;
    localparam M_COUNT = 1;
    localparam DATA_WIDTH = 32;
    localparam ADDR_WIDTH = 32;
    localparam STRB_WIDTH = DATA_WIDTH/8;
    localparam S_ID_WIDTH = 8;
    localparam M_ID_WIDTH = S_ID_WIDTH + $clog2(S_COUNT);
    localparam [ADDR_WIDTH-1:0] DECERR_ADDR = 32'hFFFF_F000;
    localparam [M_COUNT*ADDR_WIDTH-1:0] M_BASE_ADDR = 32'h0000_0000;
    localparam [M_COUNT*32-1:0] M_ADDR_WIDTH = 32'd16;

    logic clk = 1'b0;
    logic rst = 1'b1;

    logic [11:0] cfg_paddr = '0;
    logic cfg_psel = 1'b0;
    logic cfg_penable = 1'b0;
    logic cfg_pwrite = 1'b0;
    logic [31:0] cfg_pwdata = '0;
    wire [31:0] cfg_prdata;
    wire cfg_pready;
    wire cfg_pslverr;

    logic [S_ID_WIDTH-1:0] s_axi_awid = '0;
    logic [ADDR_WIDTH-1:0] s_axi_awaddr = '0;
    logic [7:0] s_axi_awlen = '0;
    logic [2:0] s_axi_awsize = '0;
    logic [1:0] s_axi_awburst = '0;
    logic s_axi_awlock = 1'b0;
    logic [3:0] s_axi_awcache = '0;
    logic [2:0] s_axi_awprot = '0;
    logic [3:0] s_axi_awqos = '0;
    logic s_axi_awvalid = 1'b0;
    wire s_axi_awready;
    logic [DATA_WIDTH-1:0] s_axi_wdata = '0;
    logic [STRB_WIDTH-1:0] s_axi_wstrb = '0;
    logic s_axi_wlast = 1'b0;
    logic s_axi_wvalid = 1'b0;
    wire s_axi_wready;
    wire [S_ID_WIDTH-1:0] s_axi_bid;
    wire [1:0] s_axi_bresp;
    wire s_axi_bvalid;
    logic s_axi_bready = 1'b1;

    logic [S_ID_WIDTH-1:0] s_axi_arid = '0;
    logic [ADDR_WIDTH-1:0] s_axi_araddr = '0;
    logic [7:0] s_axi_arlen = '0;
    logic [2:0] s_axi_arsize = '0;
    logic [1:0] s_axi_arburst = '0;
    logic s_axi_arlock = 1'b0;
    logic [3:0] s_axi_arcache = '0;
    logic [2:0] s_axi_arprot = '0;
    logic [3:0] s_axi_arqos = '0;
    logic s_axi_arvalid = 1'b0;
    wire s_axi_arready;
    wire [S_ID_WIDTH-1:0] s_axi_rid;
    wire [DATA_WIDTH-1:0] s_axi_rdata;
    wire [1:0] s_axi_rresp;
    wire s_axi_rlast;
    wire s_axi_rvalid;
    logic s_axi_rready = 1'b1;

    wire [M_ID_WIDTH-1:0] m_axi_awid;
    wire [ADDR_WIDTH-1:0] m_axi_awaddr;
    wire [7:0] m_axi_awlen;
    wire [2:0] m_axi_awsize;
    wire [1:0] m_axi_awburst;
    wire m_axi_awlock;
    wire [3:0] m_axi_awcache;
    wire [2:0] m_axi_awprot;
    wire [3:0] m_axi_awqos;
    wire [3:0] m_axi_awregion;
    wire m_axi_awvalid;
    logic m_axi_awready = 1'b1;
    wire [DATA_WIDTH-1:0] m_axi_wdata;
    wire [STRB_WIDTH-1:0] m_axi_wstrb;
    wire m_axi_wlast;
    wire m_axi_wvalid;
    logic m_axi_wready = 1'b1;
    logic [M_ID_WIDTH-1:0] m_axi_bid = '0;
    logic [1:0] m_axi_bresp = '0;
    logic m_axi_bvalid = 1'b0;
    wire m_axi_bready;
    wire [M_ID_WIDTH-1:0] m_axi_arid;
    wire [ADDR_WIDTH-1:0] m_axi_araddr;
    wire [7:0] m_axi_arlen;
    wire [2:0] m_axi_arsize;
    wire [1:0] m_axi_arburst;
    wire m_axi_arlock;
    wire [3:0] m_axi_arcache;
    wire [2:0] m_axi_arprot;
    wire [3:0] m_axi_arqos;
    wire [3:0] m_axi_arregion;
    wire m_axi_arvalid;
    logic m_axi_arready = 1'b1;
    logic [M_ID_WIDTH-1:0] m_axi_rid = '0;
    logic [DATA_WIDTH-1:0] m_axi_rdata = '0;
    logic [1:0] m_axi_rresp = '0;
    logic m_axi_rlast = '0;
    logic m_axi_rvalid = '0;
    wire m_axi_rready;

    wire [31:0] m_ahb_haddr;
    wire [1:0] m_ahb_htrans;
    wire m_ahb_hwrite;
    wire [2:0] m_ahb_hsize;
    wire [2:0] m_ahb_hburst;
    wire [63:0] m_ahb_hwdata;
    wire m_ahb_hbusreq;
    wire m_ahb_hlock;
    logic [63:0] m_ahb_hrdata = '0;
    logic m_ahb_hready = 1'b1;
    logic [1:0] m_ahb_hresp = '0;
    logic m_ahb_hgrant = 1'b0;
    logic [3:0] m_ahb_hmaster = '0;

    logic saw_downstream_aw = 1'b0;
    logic saw_downstream_ar = 1'b0;

    axi_interconnect_core #(
        .S_COUNT(S_COUNT),
        .M_COUNT(M_COUNT),
        .DATA_WIDTH(DATA_WIDTH),
        .ADDR_WIDTH(ADDR_WIDTH),
        .STRB_WIDTH(STRB_WIDTH),
        .S_ID_WIDTH(S_ID_WIDTH),
        .M_ID_WIDTH(M_ID_WIDTH),
        .M_BASE_ADDR(M_BASE_ADDR),
        .M_ADDR_WIDTH(M_ADDR_WIDTH),
        .DECERR_ADDR(DECERR_ADDR)
    )
    dut (
        .clk(clk),
        .rst(rst),
        .cfg_paddr(cfg_paddr),
        .cfg_psel(cfg_psel),
        .cfg_penable(cfg_penable),
        .cfg_pwrite(cfg_pwrite),
        .cfg_pwdata(cfg_pwdata),
        .cfg_prdata(cfg_prdata),
        .cfg_pready(cfg_pready),
        .cfg_pslverr(cfg_pslverr),
        .s_axi_awid(s_axi_awid),
        .s_axi_awaddr(s_axi_awaddr),
        .s_axi_awlen(s_axi_awlen),
        .s_axi_awsize(s_axi_awsize),
        .s_axi_awburst(s_axi_awburst),
        .s_axi_awlock(s_axi_awlock),
        .s_axi_awcache(s_axi_awcache),
        .s_axi_awprot(s_axi_awprot),
        .s_axi_awqos(s_axi_awqos),
        .s_axi_awuser(1'b0),
        .s_axi_awvalid(s_axi_awvalid),
        .s_axi_awready(s_axi_awready),
        .s_axi_wdata(s_axi_wdata),
        .s_axi_wstrb(s_axi_wstrb),
        .s_axi_wlast(s_axi_wlast),
        .s_axi_wuser(1'b0),
        .s_axi_wvalid(s_axi_wvalid),
        .s_axi_wready(s_axi_wready),
        .s_axi_bid(s_axi_bid),
        .s_axi_bresp(s_axi_bresp),
        .s_axi_buser(),
        .s_axi_bvalid(s_axi_bvalid),
        .s_axi_bready(s_axi_bready),
        .s_axi_arid(s_axi_arid),
        .s_axi_araddr(s_axi_araddr),
        .s_axi_arlen(s_axi_arlen),
        .s_axi_arsize(s_axi_arsize),
        .s_axi_arburst(s_axi_arburst),
        .s_axi_arlock(s_axi_arlock),
        .s_axi_arcache(s_axi_arcache),
        .s_axi_arprot(s_axi_arprot),
        .s_axi_arqos(s_axi_arqos),
        .s_axi_aruser(1'b0),
        .s_axi_arvalid(s_axi_arvalid),
        .s_axi_arready(s_axi_arready),
        .s_axi_rid(s_axi_rid),
        .s_axi_rdata(s_axi_rdata),
        .s_axi_rresp(s_axi_rresp),
        .s_axi_rlast(s_axi_rlast),
        .s_axi_ruser(),
        .s_axi_rvalid(s_axi_rvalid),
        .s_axi_rready(s_axi_rready),
        .m_axi_awid(m_axi_awid),
        .m_axi_awaddr(m_axi_awaddr),
        .m_axi_awlen(m_axi_awlen),
        .m_axi_awsize(m_axi_awsize),
        .m_axi_awburst(m_axi_awburst),
        .m_axi_awlock(m_axi_awlock),
        .m_axi_awcache(m_axi_awcache),
        .m_axi_awprot(m_axi_awprot),
        .m_axi_awqos(m_axi_awqos),
        .m_axi_awregion(m_axi_awregion),
        .m_axi_awuser(),
        .m_axi_awvalid(m_axi_awvalid),
        .m_axi_awready(m_axi_awready),
        .m_axi_wdata(m_axi_wdata),
        .m_axi_wstrb(m_axi_wstrb),
        .m_axi_wlast(m_axi_wlast),
        .m_axi_wuser(),
        .m_axi_wvalid(m_axi_wvalid),
        .m_axi_wready(m_axi_wready),
        .m_axi_bid(m_axi_bid),
        .m_axi_bresp(m_axi_bresp),
        .m_axi_buser(1'b0),
        .m_axi_bvalid(m_axi_bvalid),
        .m_axi_bready(m_axi_bready),
        .m_axi_arid(m_axi_arid),
        .m_axi_araddr(m_axi_araddr),
        .m_axi_arlen(m_axi_arlen),
        .m_axi_arsize(m_axi_arsize),
        .m_axi_arburst(m_axi_arburst),
        .m_axi_arlock(m_axi_arlock),
        .m_axi_arcache(m_axi_arcache),
        .m_axi_arprot(m_axi_arprot),
        .m_axi_arqos(m_axi_arqos),
        .m_axi_arregion(m_axi_arregion),
        .m_axi_aruser(),
        .m_axi_arvalid(m_axi_arvalid),
        .m_axi_arready(m_axi_arready),
        .m_axi_rid(m_axi_rid),
        .m_axi_rdata(m_axi_rdata),
        .m_axi_rresp(m_axi_rresp),
        .m_axi_rlast(m_axi_rlast),
        .m_axi_ruser(1'b0),
        .m_axi_rvalid(m_axi_rvalid),
        .m_axi_rready(m_axi_rready),
        .m_ahb_haddr(m_ahb_haddr),
        .m_ahb_htrans(m_ahb_htrans),
        .m_ahb_hwrite(m_ahb_hwrite),
        .m_ahb_hsize(m_ahb_hsize),
        .m_ahb_hburst(m_ahb_hburst),
        .m_ahb_hwdata(m_ahb_hwdata),
        .m_ahb_hbusreq(m_ahb_hbusreq),
        .m_ahb_hlock(m_ahb_hlock),
        .m_ahb_hrdata(m_ahb_hrdata),
        .m_ahb_hready(m_ahb_hready),
        .m_ahb_hresp(m_ahb_hresp),
        .m_ahb_hgrant(m_ahb_hgrant),
        .m_ahb_hmaster(m_ahb_hmaster)
    );

    always #5 clk = ~clk;

    always @(posedge clk) begin
        if (rst) begin
            saw_downstream_aw <= 1'b0;
            saw_downstream_ar <= 1'b0;
        end else begin
            if (cfg_psel && cfg_penable && cfg_pwrite) begin
                $display("[%0t] APB write addr=%h data=%h", $time, cfg_paddr, cfg_pwdata);
            end
            if (cfg_psel && cfg_penable && !cfg_pwrite) begin
                $display("[%0t] APB read addr=%h data=%h", $time, cfg_paddr, cfg_prdata);
            end
            if (s_axi_awvalid && s_axi_awready) begin
                $display("[%0t] S AW addr=%h id=%h", $time, s_axi_awaddr, s_axi_awid);
            end
            if (s_axi_wvalid && s_axi_wready) begin
                $display("[%0t] S W data=%h last=%0d", $time, s_axi_wdata, s_axi_wlast);
            end
            if (s_axi_bvalid && s_axi_bready) begin
                $display("[%0t] S B resp=%b id=%h", $time, s_axi_bresp, s_axi_bid);
            end
            if (s_axi_arvalid && s_axi_arready) begin
                $display("[%0t] S AR addr=%h id=%h", $time, s_axi_araddr, s_axi_arid);
            end
            if (s_axi_rvalid && s_axi_rready) begin
                $display("[%0t] S R resp=%b id=%h last=%0d", $time, s_axi_rresp, s_axi_rid, s_axi_rlast);
            end
            if (m_axi_awvalid && m_axi_awready) begin
                saw_downstream_aw <= 1'b1;
                $display("[%0t] M AW addr=%h id=%h", $time, m_axi_awaddr, m_axi_awid);
            end
            if (m_axi_arvalid && m_axi_arready) begin
                saw_downstream_ar <= 1'b1;
                $display("[%0t] M AR addr=%h id=%h", $time, m_axi_araddr, m_axi_arid);
            end
        end
    end

    task automatic apb_write(input [11:0] addr, input [31:0] data);
    begin
        @(negedge clk);
        cfg_paddr = addr;
        cfg_pwdata = data;
        cfg_pwrite = 1'b1;
        cfg_psel = 1'b1;
        cfg_penable = 1'b0;
        @(negedge clk);
        cfg_penable = 1'b1;
        @(posedge clk);
        wait (cfg_pready);
        @(negedge clk);
        cfg_psel = 1'b0;
        cfg_penable = 1'b0;
        cfg_pwrite = 1'b0;
        cfg_paddr = '0;
        cfg_pwdata = '0;
    end
    endtask

    task automatic apb_read(input [11:0] addr, output [31:0] data);
    begin
        @(negedge clk);
        cfg_paddr = addr;
        cfg_psel = 1'b1;
        cfg_pwrite = 1'b0;
        cfg_penable = 1'b0;
        @(negedge clk);
        cfg_penable = 1'b1;
        @(posedge clk);
        wait (cfg_pready);
        data = cfg_prdata;
        @(negedge clk);
        cfg_psel = 1'b0;
        cfg_penable = 1'b0;
        cfg_paddr = '0;
    end
    endtask

    task automatic send_write(input [7:0] id, input [31:0] addr);
    begin
        @(posedge clk);
        s_axi_awid <= id;
        s_axi_awaddr <= addr;
        s_axi_awlen <= 8'd0;
        s_axi_awsize <= 3'd2;
        s_axi_awburst <= 2'b01;
        s_axi_awvalid <= 1'b1;
        wait (s_axi_awready);
        @(posedge clk);
        s_axi_awvalid <= 1'b0;

        s_axi_wdata <= 32'h1234_5678;
        s_axi_wstrb <= 4'hF;
        s_axi_wlast <= 1'b1;
        s_axi_wvalid <= 1'b1;
        wait (s_axi_wready);
        @(posedge clk);
        s_axi_wvalid <= 1'b0;
        s_axi_wlast <= 1'b0;
    end
    endtask

    task automatic send_read(input [7:0] id, input [31:0] addr);
    begin
        @(posedge clk);
        s_axi_arid <= id;
        s_axi_araddr <= addr;
        s_axi_arlen <= 8'd0;
        s_axi_arsize <= 3'd2;
        s_axi_arburst <= 2'b01;
        s_axi_arvalid <= 1'b1;
        wait (s_axi_arready);
        @(posedge clk);
        s_axi_arvalid <= 1'b0;
    end
    endtask

    initial begin
        #4000;
        $display("FAIL timeout in tb_axi_interconnect_core_apb_cfg");
        $fatal;
    end

    initial begin
        logic [31:0] rdata;

        repeat (4) @(posedge clk);
        rst <= 1'b0;

        apb_write(12'h020, 32'h0000_0003);
        send_write(8'h11, 32'h0000_0100);
        wait (s_axi_bvalid && s_axi_bready);
        if (s_axi_bresp !== 2'b11) begin
            $display("FAIL disabled write should return DECERR");
            $fatal;
        end
        if (saw_downstream_aw) begin
            $display("FAIL disabled write should not reach downstream target");
            $fatal;
        end

        apb_read(12'h110, rdata);
        if (rdata[7:0] !== 8'h02) begin
            $display("FAIL write disable should capture fault code 0x02");
            $fatal;
        end

        saw_downstream_aw <= 1'b0;
        apb_write(12'h020, 32'h0000_0005);
        send_read(8'h22, 32'h0000_0104);
        wait (s_axi_rvalid && s_axi_rready);
        if (s_axi_rresp !== 2'b11 || !s_axi_rlast) begin
            $display("FAIL disabled read should return single-beat DECERR");
            $fatal;
        end
        if (saw_downstream_ar) begin
            $display("FAIL disabled read should not reach downstream target");
            $fatal;
        end

        apb_read(12'h110, rdata);
        if (rdata[7:0] !== 8'h04) begin
            $display("FAIL read disable should capture fault code 0x04");
            $fatal;
        end

        saw_downstream_aw <= 1'b0;
        apb_write(12'h020, 32'h0000_0007);
        apb_write(12'h040, 32'h0000_0000);
        send_write(8'h33, 32'h0000_0108);
        wait (s_axi_bvalid && s_axi_bready);
        if (s_axi_bresp !== 2'b11) begin
            $display("FAIL disabled target write should return DECERR");
            $fatal;
        end
        if (saw_downstream_aw) begin
            $display("FAIL disabled target write should not drive direct AXI target");
            $fatal;
        end

        apb_read(12'h110, rdata);
        if (rdata[7:0] !== 8'h05) begin
            $display("FAIL target write disable should capture fault code 0x05");
            $fatal;
        end

        apb_read(12'h1A0, rdata);
        if (rdata !== 32'd2) begin
            $display("FAIL write DECERR counter should record two DECERR writes");
            $fatal;
        end
        apb_read(12'h1C0, rdata);
        if (rdata !== 32'd1) begin
            $display("FAIL read DECERR counter should record one DECERR read");
            $fatal;
        end

        $display("PASS tb_axi_interconnect_core_apb_cfg");
        $finish;
    end

endmodule
