`timescale 1ns / 1ps

module tb_arbiter_timing;

    localparam PORTS = 4;
    localparam ENC_WIDTH = $clog2(PORTS);

    logic clk = 1'b1;
    logic rst = 1'b1;

    logic [PORTS-1:0] request = '0;
    logic [PORTS-1:0] acknowledge = '0;
    wire [PORTS-1:0] grant;
    wire grant_valid;
    wire [ENC_WIDTH-1:0] grant_encoded;

    arbiter #(
        .PORTS(PORTS),
        .ARB_TYPE_ROUND_ROBIN(1),
        .ARB_BLOCK(1),
        .ARB_BLOCK_ACK(1),
        .ARB_LSB_HIGH_PRIORITY(1)
    )
    dut (
        .clk(clk),
        .rst(rst),
        .request(request),
        .acknowledge(acknowledge),
        .grant(grant),
        .grant_valid(grant_valid),
        .grant_encoded(grant_encoded)
    );

    always #5 clk = ~clk;

    task automatic show_state(input string tag);
    begin
        $display("[%0t] %-34s req=%b ack=%b grant=%b valid=%0d enc=%0d mask=%b",
            $time, tag, request, acknowledge, grant, grant_valid, grant_encoded, dut.mask_reg);
    end
    endtask

    task automatic expect_grant(
        input [PORTS-1:0] expected_grant,
        input bit expected_valid,
        input [ENC_WIDTH-1:0] expected_encoded,
        input string tag
    );
    begin
        if (grant !== expected_grant || grant_valid !== expected_valid ||
                grant_encoded !== expected_encoded) begin
            $display("FAIL %s: expected grant=%b valid=%0d enc=%0d, got grant=%b valid=%0d enc=%0d",
                tag, expected_grant, expected_valid, expected_encoded,
                grant, grant_valid, grant_encoded);
            $fatal;
        end
    end
    endtask

    task automatic tick(input string tag);
    begin
        @(posedge clk);
        #1;
        show_state(tag);
    end
    endtask

    initial begin
        $dumpfile("tb_arbiter_timing.vcd");
        $dumpvars(0, tb_arbiter_timing);

        repeat (2) tick("reset");
        rst = 1'b0;
        tick("idle after reset");
        expect_grant(4'b0000, 1'b0, 2'd0, "idle after reset");

        @(posedge clk);
        request = 4'b0011;
        #1;
        show_state("request S0/S1 before clock");
        expect_grant(4'b0000, 1'b0, 2'd0, "request before clock");

        tick("first grant after clock");
        expect_grant(4'b0001, 1'b1, 2'd0, "first grant is S0");

        tick("held without acknowledge");
        expect_grant(4'b0001, 1'b1, 2'd0, "grant held before ack");

        @(posedge clk);
        request = 4'b0010;
        acknowledge = 4'b0001;
        #1;
        show_state("ack S0 asserted before clock");
        expect_grant(4'b0001, 1'b1, 2'd0, "old grant visible before ack clock");

        tick("clock edge accepts ack S0");
        expect_grant(4'b0010, 1'b1, 2'd1, "grant moves to S1 after ack");

        @(posedge clk);
        acknowledge = 4'b0000;
        #1;
        show_state("ack cleared, S1 still requests");
        expect_grant(4'b0010, 1'b1, 2'd1, "S1 held after ack cleared");

        tick("S1 held without acknowledge");
        expect_grant(4'b0010, 1'b1, 2'd1, "S1 held another cycle");

        @(posedge clk);
        request = 4'b1100;
        acknowledge = 4'b0010;
        #1;
        show_state("ack S1, S2/S3 request");
        expect_grant(4'b0010, 1'b1, 2'd1, "old S1 before ack clock");

        tick("clock edge accepts ack S1");
        expect_grant(4'b0100, 1'b1, 2'd2, "round-robin grants S2");

        @(posedge clk);
        request = 4'b1000;
        acknowledge = 4'b0100;
        #1;
        show_state("ack S2, S3 request");
        expect_grant(4'b0100, 1'b1, 2'd2, "old S2 before ack clock");

        tick("clock edge accepts ack S2");
        expect_grant(4'b1000, 1'b1, 2'd3, "round-robin grants S3");

        @(posedge clk);
        request = 4'b0000;
        acknowledge = 4'b1000;
        #1;
        show_state("ack S3, no request");
        expect_grant(4'b1000, 1'b1, 2'd3, "old S3 before final ack clock");

        tick("clock edge releases grant");
        expect_grant(4'b0000, 1'b0, 2'd0, "no grant after final ack");

        repeat (2) tick("done");
        $display("PASS tb_arbiter_timing");
        $finish;
    end

    initial begin
        #2000;
        $display("FAIL timeout in tb_arbiter_timing");
        $fatal;
    end

endmodule
