`timescale 1ns / 1ps

module tb_axi_crossbar_wr_arb;

    localparam S_COUNT = 2;
    localparam M_COUNT = 2;
    localparam DATA_WIDTH = 32;
    localparam ADDR_WIDTH = 32;
    localparam STRB_WIDTH = DATA_WIDTH/8;
    localparam S_ID_WIDTH = 8;
    localparam M_ID_WIDTH = S_ID_WIDTH + $clog2(S_COUNT);
    localparam [M_COUNT*ADDR_WIDTH-1:0] M_BASE_ADDR = {32'h0001_0000, 32'h0000_0000};
    localparam [M_COUNT*32-1:0] M_ADDR_WIDTH = {32'd16, 32'd16};

    logic clk = 1'b0;
    logic rst = 1'b1;

    logic [S_COUNT*S_ID_WIDTH-1:0] s_axi_awid = '0;
    logic [S_COUNT*ADDR_WIDTH-1:0] s_axi_awaddr = '0;
    logic [S_COUNT*8-1:0] s_axi_awlen = '0;
    logic [S_COUNT*3-1:0] s_axi_awsize = '0;
    logic [S_COUNT*2-1:0] s_axi_awburst = '0;
    logic [S_COUNT-1:0] s_axi_awlock = '0;
    logic [S_COUNT*4-1:0] s_axi_awcache = '0;
    logic [S_COUNT*3-1:0] s_axi_awprot = '0;
    logic [S_COUNT*4-1:0] s_axi_awqos = '0;
    logic [S_COUNT-1:0] s_axi_awvalid = '0;
    wire [S_COUNT-1:0] s_axi_awready;

    logic [S_COUNT*DATA_WIDTH-1:0] s_axi_wdata = '0;
    logic [S_COUNT*STRB_WIDTH-1:0] s_axi_wstrb = '0;
    logic [S_COUNT-1:0] s_axi_wlast = '0;
    logic [S_COUNT-1:0] s_axi_wvalid = '0;
    wire [S_COUNT-1:0] s_axi_wready;

    wire [S_COUNT*S_ID_WIDTH-1:0] s_axi_bid;
    wire [S_COUNT*2-1:0] s_axi_bresp;
    wire [S_COUNT-1:0] s_axi_bvalid;
    logic [S_COUNT-1:0] s_axi_bready = {S_COUNT{1'b1}};

    wire [M_COUNT*M_ID_WIDTH-1:0] m_axi_awid;
    wire [M_COUNT*ADDR_WIDTH-1:0] m_axi_awaddr;
    wire [M_COUNT*8-1:0] m_axi_awlen;
    wire [M_COUNT*3-1:0] m_axi_awsize;
    wire [M_COUNT*2-1:0] m_axi_awburst;
    wire [M_COUNT-1:0] m_axi_awlock;
    wire [M_COUNT*4-1:0] m_axi_awcache;
    wire [M_COUNT*3-1:0] m_axi_awprot;
    wire [M_COUNT*4-1:0] m_axi_awqos;
    wire [M_COUNT*4-1:0] m_axi_awregion;
    wire [M_COUNT-1:0] m_axi_awvalid;
    logic [M_COUNT-1:0] m_axi_awready = {M_COUNT{1'b1}};

    wire [M_COUNT*DATA_WIDTH-1:0] m_axi_wdata;
    wire [M_COUNT*STRB_WIDTH-1:0] m_axi_wstrb;
    wire [M_COUNT-1:0] m_axi_wlast;
    wire [M_COUNT-1:0] m_axi_wvalid;
    logic [M_COUNT-1:0] m_axi_wready = {M_COUNT{1'b1}};

    logic [M_COUNT*M_ID_WIDTH-1:0] m_axi_bid = '0;
    logic [M_COUNT*2-1:0] m_axi_bresp = '0;
    logic [M_COUNT-1:0] m_axi_bvalid = '0;
    wire [M_COUNT-1:0] m_axi_bready;

    logic [M_ID_WIDTH-1:0] bid_fifo[0:3];
    integer bid_wr_ptr = 0;
    integer bid_rd_ptr = 0;
    logic b_response_pending = 1'b0;
    integer s_b_count = 0;

    axi_crossbar_wr #(
        .S_COUNT(S_COUNT),
        .M_COUNT(M_COUNT),
        .DATA_WIDTH(DATA_WIDTH),
        .ADDR_WIDTH(ADDR_WIDTH),
        .STRB_WIDTH(STRB_WIDTH),
        .S_ID_WIDTH(S_ID_WIDTH),
        .M_ID_WIDTH(M_ID_WIDTH),
        .S_THREADS({S_COUNT{32'd2}}),
        .S_ACCEPT({S_COUNT{32'd4}}),
        .M_REGIONS(1),
        .M_BASE_ADDR(M_BASE_ADDR),
        .M_ADDR_WIDTH(M_ADDR_WIDTH),
        .M_CONNECT({M_COUNT{{S_COUNT{1'b1}}}}),
        .M_ISSUE({M_COUNT{32'd4}}),
        .M_SECURE({M_COUNT{1'b0}}),
        .S_AW_REG_TYPE({S_COUNT{2'd0}}),
        .S_W_REG_TYPE({S_COUNT{2'd0}}),
        .S_B_REG_TYPE({S_COUNT{2'd0}}),
        .M_AW_REG_TYPE({M_COUNT{2'd0}}),
        .M_W_REG_TYPE({M_COUNT{2'd0}}),
        .M_B_REG_TYPE({M_COUNT{2'd0}})
    )
    dut (
        .clk(clk),
        .rst(rst),
        .s_axi_awid(s_axi_awid),
        .s_axi_awaddr(s_axi_awaddr),
        .s_axi_awlen(s_axi_awlen),
        .s_axi_awsize(s_axi_awsize),
        .s_axi_awburst(s_axi_awburst),
        .s_axi_awlock(s_axi_awlock),
        .s_axi_awcache(s_axi_awcache),
        .s_axi_awprot(s_axi_awprot),
        .s_axi_awqos(s_axi_awqos),
        .s_axi_awuser({S_COUNT{1'b0}}),
        .s_axi_awvalid(s_axi_awvalid),
        .s_axi_awready(s_axi_awready),
        .s_axi_wdata(s_axi_wdata),
        .s_axi_wstrb(s_axi_wstrb),
        .s_axi_wlast(s_axi_wlast),
        .s_axi_wuser({S_COUNT{1'b0}}),
        .s_axi_wvalid(s_axi_wvalid),
        .s_axi_wready(s_axi_wready),
        .s_axi_bid(s_axi_bid),
        .s_axi_bresp(s_axi_bresp),
        .s_axi_buser(),
        .s_axi_bvalid(s_axi_bvalid),
        .s_axi_bready(s_axi_bready),
        .m_axi_awid(m_axi_awid),
        .m_axi_awaddr(m_axi_awaddr),
        .m_axi_awlen(m_axi_awlen),
        .m_axi_awsize(m_axi_awsize),
        .m_axi_awburst(m_axi_awburst),
        .m_axi_awlock(m_axi_awlock),
        .m_axi_awcache(m_axi_awcache),
        .m_axi_awprot(m_axi_awprot),
        .m_axi_awqos(m_axi_awqos),
        .m_axi_awregion(m_axi_awregion),
        .m_axi_awuser(),
        .m_axi_awvalid(m_axi_awvalid),
        .m_axi_awready(m_axi_awready),
        .m_axi_wdata(m_axi_wdata),
        .m_axi_wstrb(m_axi_wstrb),
        .m_axi_wlast(m_axi_wlast),
        .m_axi_wuser(),
        .m_axi_wvalid(m_axi_wvalid),
        .m_axi_wready(m_axi_wready),
        .m_axi_bid(m_axi_bid),
        .m_axi_bresp(m_axi_bresp),
        .m_axi_buser({M_COUNT{1'b0}}),
        .m_axi_bvalid(m_axi_bvalid),
        .m_axi_bready(m_axi_bready)
    );

    always #5 clk = ~clk;

    task automatic issue_one_write(
        input integer port,
        input [S_ID_WIDTH-1:0] id,
        input [DATA_WIDTH-1:0] data
    );
    begin
        @(negedge clk);
        s_axi_awid[port*S_ID_WIDTH +: S_ID_WIDTH] = id;
        s_axi_awaddr[port*ADDR_WIDTH +: ADDR_WIDTH] = 32'h0000_0100;
        s_axi_awlen[port*8 +: 8] = 8'd0;
        s_axi_awsize[port*3 +: 3] = 3'd2;
        s_axi_awburst[port*2 +: 2] = 2'b01;
        s_axi_awvalid[port] = 1'b1;

        do begin
            @(posedge clk);
        end while (!s_axi_awready[port]);

        @(negedge clk);
        s_axi_awvalid[port] = 1'b0;

        s_axi_wdata[port*DATA_WIDTH +: DATA_WIDTH] = data;
        s_axi_wstrb[port*STRB_WIDTH +: STRB_WIDTH] = {STRB_WIDTH{1'b1}};
        s_axi_wlast[port] = 1'b1;
        s_axi_wvalid[port] = 1'b1;

        do begin
            @(posedge clk);
        end while (!s_axi_wready[port]);

        @(negedge clk);
        s_axi_wvalid[port] = 1'b0;
        s_axi_wlast[port] = 1'b0;
    end
    endtask

    always @(posedge clk) begin
        if (rst) begin
            bid_wr_ptr <= 0;
            bid_rd_ptr <= 0;
            b_response_pending <= 1'b0;
            m_axi_bvalid <= '0;
            m_axi_bresp <= '0;
            m_axi_bid <= '0;
        end else begin
            if (m_axi_awvalid[0] && m_axi_awready[0]) begin
                bid_fifo[bid_wr_ptr] <= m_axi_awid[0*M_ID_WIDTH +: M_ID_WIDTH];
                bid_wr_ptr <= (bid_wr_ptr + 1) & 3;
            end

            if (m_axi_bvalid[0] && m_axi_bready[0]) begin
                m_axi_bvalid[0] <= 1'b0;
            end

            if (m_axi_wvalid[0] && m_axi_wready[0] && m_axi_wlast[0]) begin
                b_response_pending <= 1'b1;
            end

            if (b_response_pending && !m_axi_bvalid[0]) begin
                m_axi_bid[0*M_ID_WIDTH +: M_ID_WIDTH] <= bid_fifo[bid_rd_ptr];
                m_axi_bresp[0*2 +: 2] <= 2'b00;
                m_axi_bvalid[0] <= 1'b1;
                bid_rd_ptr <= (bid_rd_ptr + 1) & 3;
                b_response_pending <= 1'b0;
            end
        end
    end

    always @(posedge clk) begin
        if (!rst) begin
            if (dut.m_ifaces[0].a_grant_valid || |dut.m_ifaces[0].a_request) begin
                $display("[%0t] ARB M0 request=%b grant=%b grant_valid=%0d a_grant_encoded=S%0d",
                    $time,
                    dut.m_ifaces[0].a_request,
                    dut.m_ifaces[0].a_grant,
                    dut.m_ifaces[0].a_grant_valid,
                    dut.m_ifaces[0].a_grant_encoded);
            end

            if (s_axi_awvalid[0] && s_axi_awready[0]) begin
                $display("[%0t] S0 AW handshake id=%h", $time, s_axi_awid[0*S_ID_WIDTH +: S_ID_WIDTH]);
            end
            if (s_axi_awvalid[1] && s_axi_awready[1]) begin
                $display("[%0t] S1 AW handshake id=%h", $time, s_axi_awid[1*S_ID_WIDTH +: S_ID_WIDTH]);
            end

            if (m_axi_awvalid[0] && m_axi_awready[0]) begin
                $display("[%0t] M0 AW handshake m_awid=%h src_port=S%0d original_id=%h addr=%h",
                    $time,
                    m_axi_awid[0*M_ID_WIDTH +: M_ID_WIDTH],
                    m_axi_awid[0*M_ID_WIDTH+S_ID_WIDTH +: $clog2(S_COUNT)],
                    m_axi_awid[0*M_ID_WIDTH +: S_ID_WIDTH],
                    m_axi_awaddr[0*ADDR_WIDTH +: ADDR_WIDTH]);
            end

            if (m_axi_wvalid[0] && m_axi_wready[0]) begin
                $display("[%0t] M0 W handshake data=%h last=%0d",
                    $time, m_axi_wdata[0*DATA_WIDTH +: DATA_WIDTH], m_axi_wlast[0]);
            end

            if (s_axi_bvalid[0] && s_axi_bready[0]) begin
                s_b_count <= s_b_count + 1;
                $display("[%0t] S0 B handshake bid=%h resp=%b",
                    $time, s_axi_bid[0*S_ID_WIDTH +: S_ID_WIDTH], s_axi_bresp[0*2 +: 2]);
            end
            if (s_axi_bvalid[1] && s_axi_bready[1]) begin
                s_b_count <= s_b_count + 1;
                $display("[%0t] S1 B handshake bid=%h resp=%b",
                    $time, s_axi_bid[1*S_ID_WIDTH +: S_ID_WIDTH], s_axi_bresp[1*2 +: 2]);
            end
        end
    end

    initial begin
        $dumpfile("tb_axi_crossbar_wr_arb.vcd");
        $dumpvars(0, tb_axi_crossbar_wr_arb);

        repeat (4) @(posedge clk);
        rst = 1'b0;
        @(posedge clk);

        fork
            issue_one_write(0, 8'h10, 32'hAAAA_0000);
            issue_one_write(1, 8'h20, 32'hBBBB_0001);
        join

        wait (s_b_count == 2);
        repeat (5) @(posedge clk);

        $display("PASS tb_axi_crossbar_wr_arb");
        $finish;
    end

    initial begin
        #2000;
        $display("FAIL timeout in tb_axi_crossbar_wr_arb");
        $fatal;
    end

endmodule
