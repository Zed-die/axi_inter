`timescale 1ns / 1ps

module tb_axi_ic_apb_cfg;

    localparam S_COUNT = 2;
    localparam M_COUNT = 2;
    localparam ADDR_WIDTH = 32;

    logic clk = 1'b0;
    logic rst = 1'b1;

    logic [11:0] s_apb_paddr = '0;
    logic s_apb_psel = 1'b0;
    logic s_apb_penable = 1'b0;
    logic s_apb_pwrite = 1'b0;
    logic [31:0] s_apb_pwdata = '0;
    wire [31:0] s_apb_prdata;
    wire s_apb_pready;
    wire s_apb_pslverr;

    logic [S_COUNT-1:0] stat_write_req_pulse = '0;
    logic [S_COUNT-1:0] stat_read_req_pulse = '0;
    logic [S_COUNT-1:0] stat_write_decerr_pulse = '0;
    logic [S_COUNT-1:0] stat_read_decerr_pulse = '0;

    logic fault_valid = 1'b0;
    logic [7:0] fault_code = '0;
    logic [7:0] fault_src_port = '0;
    logic [7:0] fault_dst_port = '0;
    logic [7:0] fault_id = '0;
    logic [ADDR_WIDTH-1:0] fault_addr = '0;

    wire core_enable;
    wire [S_COUNT-1:0] master_enable;
    wire [S_COUNT-1:0] master_allow_reads;
    wire [S_COUNT-1:0] master_allow_writes;
    wire [M_COUNT-1:0] target_enable;

    axi_ic_apb_cfg #(
        .S_COUNT(S_COUNT),
        .M_COUNT(M_COUNT),
        .ADDR_WIDTH(ADDR_WIDTH),
        .M_TARGET_TYPE(2'b01)
    )
    dut (
        .clk(clk),
        .rst(rst),
        .s_apb_paddr(s_apb_paddr),
        .s_apb_psel(s_apb_psel),
        .s_apb_penable(s_apb_penable),
        .s_apb_pwrite(s_apb_pwrite),
        .s_apb_pwdata(s_apb_pwdata),
        .s_apb_prdata(s_apb_prdata),
        .s_apb_pready(s_apb_pready),
        .s_apb_pslverr(s_apb_pslverr),
        .stat_write_req_pulse(stat_write_req_pulse),
        .stat_read_req_pulse(stat_read_req_pulse),
        .stat_write_decerr_pulse(stat_write_decerr_pulse),
        .stat_read_decerr_pulse(stat_read_decerr_pulse),
        .fault_valid(fault_valid),
        .fault_code(fault_code),
        .fault_src_port(fault_src_port),
        .fault_dst_port(fault_dst_port),
        .fault_id(fault_id),
        .fault_addr(fault_addr),
        .core_enable(core_enable),
        .master_enable(master_enable),
        .master_allow_reads(master_allow_reads),
        .master_allow_writes(master_allow_writes),
        .target_enable(target_enable)
    );

    always #5 clk = ~clk;

    task automatic apb_write(input [11:0] addr, input [31:0] data);
    begin
        @(negedge clk);
        s_apb_paddr = addr;
        s_apb_pwdata = data;
        s_apb_pwrite = 1'b1;
        s_apb_psel = 1'b1;
        s_apb_penable = 1'b0;
        @(negedge clk);
        s_apb_penable = 1'b1;
        @(posedge clk);
        wait (s_apb_pready);
        @(negedge clk);
        s_apb_psel = 1'b0;
        s_apb_penable = 1'b0;
        s_apb_pwrite = 1'b0;
        s_apb_paddr = '0;
        s_apb_pwdata = '0;
    end
    endtask

    task automatic apb_read(input [11:0] addr, output [31:0] data);
    begin
        @(negedge clk);
        s_apb_paddr = addr;
        s_apb_pwrite = 1'b0;
        s_apb_psel = 1'b1;
        s_apb_penable = 1'b0;
        @(negedge clk);
        s_apb_penable = 1'b1;
        @(posedge clk);
        wait (s_apb_pready);
        data = s_apb_prdata;
        @(negedge clk);
        s_apb_psel = 1'b0;
        s_apb_penable = 1'b0;
        s_apb_paddr = '0;
    end
    endtask

    task automatic pulse_counter(input [1:0] counter_sel, input integer idx);
    begin
        @(posedge clk);
        case (counter_sel)
            2'd0: stat_write_req_pulse[idx] <= 1'b1;
            2'd1: stat_read_req_pulse[idx] <= 1'b1;
            2'd2: stat_write_decerr_pulse[idx] <= 1'b1;
            default: stat_read_decerr_pulse[idx] <= 1'b1;
        endcase
        @(posedge clk);
        case (counter_sel)
            2'd0: stat_write_req_pulse[idx] <= 1'b0;
            2'd1: stat_read_req_pulse[idx] <= 1'b0;
            2'd2: stat_write_decerr_pulse[idx] <= 1'b0;
            default: stat_read_decerr_pulse[idx] <= 1'b0;
        endcase
    end
    endtask

    task automatic pulse_fault(
        input [7:0] code,
        input [7:0] src,
        input [7:0] dst,
        input [7:0] id,
        input [ADDR_WIDTH-1:0] addr
    );
    begin
        @(posedge clk);
        fault_code <= code;
        fault_src_port <= src;
        fault_dst_port <= dst;
        fault_id <= id;
        fault_addr <= addr;
        fault_valid <= 1'b1;
        @(posedge clk);
        fault_valid <= 1'b0;
        fault_code <= '0;
        fault_src_port <= '0;
        fault_dst_port <= '0;
        fault_id <= '0;
        fault_addr <= '0;
    end
    endtask

    initial begin
        #2000;
        $display("FAIL timeout in tb_axi_ic_apb_cfg");
        $fatal;
    end

    initial begin
        logic [31:0] rdata;

        repeat (4) @(posedge clk);
        rst <= 1'b0;

        if (!core_enable || master_enable !== 2'b11 || master_allow_reads !== 2'b11 || master_allow_writes !== 2'b11 || target_enable !== 2'b11) begin
            $display("FAIL default APB config outputs incorrect");
            $fatal;
        end

        apb_write(12'h000, 32'h0000_0000);
        if (core_enable !== 1'b0) begin
            $display("FAIL core_enable should clear via APB write");
            $fatal;
        end

        apb_write(12'h024, 32'h0000_0005);
        if (master_enable[1] !== 1'b1 || master_allow_reads[1] !== 1'b0 || master_allow_writes[1] !== 1'b1) begin
            $display("FAIL MASTER1_CTRL should update policy bits");
            $fatal;
        end

        apb_write(12'h040, 32'h0000_0000);
        if (target_enable[0] !== 1'b0) begin
            $display("FAIL TARGET0_CTRL should disable target 0");
            $fatal;
        end

        pulse_counter(2'd0, 1);
        pulse_counter(2'd1, 1);
        pulse_counter(2'd2, 1);
        pulse_counter(2'd3, 0);

        apb_read(12'h164, rdata);
        if (rdata !== 32'd1) begin
            $display("FAIL MASTER1_WRITE_REQ_COUNT should increment");
            $fatal;
        end
        apb_read(12'h184, rdata);
        if (rdata !== 32'd1) begin
            $display("FAIL MASTER1_READ_REQ_COUNT should increment");
            $fatal;
        end
        apb_read(12'h1A4, rdata);
        if (rdata !== 32'd1) begin
            $display("FAIL MASTER1_WRITE_DECERR_COUNT should increment");
            $fatal;
        end
        apb_read(12'h1C0, rdata);
        if (rdata !== 32'd1) begin
            $display("FAIL MASTER0_READ_DECERR_COUNT should increment");
            $fatal;
        end

        pulse_fault(8'h05, 8'h02, 8'h01, 8'hA5, 32'h1234_5678);
        apb_read(12'h108, rdata);
        if (rdata[0] !== 1'b1) begin
            $display("FAIL FAULT_STATUS should report sticky fault");
            $fatal;
        end
        apb_read(12'h10C, rdata);
        if (rdata !== 32'h1234_5678) begin
            $display("FAIL LAST_FAULT_ADDR should capture address");
            $fatal;
        end
        apb_read(12'h110, rdata);
        if (rdata !== 32'hA5_01_02_05) begin
            $display("FAIL LAST_FAULT_INFO should capture code, ports, and id");
            $fatal;
        end

        apb_write(12'h004, 32'h0000_0001);
        apb_read(12'h108, rdata);
        if (rdata[0] !== 1'b0) begin
            $display("FAIL FAULT_CLEAR should clear sticky fault");
            $fatal;
        end

        apb_read(12'h140, rdata);
        if (rdata[1:0] !== 2'b10) begin
            $display("FAIL TARGET0_CTRL should expose enable and bridge status");
            $fatal;
        end

        $display("PASS tb_axi_ic_apb_cfg");
        $finish;
    end

endmodule
