`timescale 1ns / 1ps

module tb_axi_ic_egress_axi2ahb;

    localparam DATA_WIDTH = 64;
    localparam ADDR_WIDTH = 32;
    localparam STRB_WIDTH = DATA_WIDTH/8;
    localparam ID_WIDTH = 10;

    logic clk = 1'b0;
    logic rst = 1'b1;

    logic [ID_WIDTH-1:0] s_axi_awid = '0;
    logic [ADDR_WIDTH-1:0] s_axi_awaddr = '0;
    logic [7:0] s_axi_awlen = '0;
    logic [2:0] s_axi_awsize = '0;
    logic [1:0] s_axi_awburst = '0;
    logic s_axi_awlock = 1'b0;
    logic [3:0] s_axi_awcache = '0;
    logic [2:0] s_axi_awprot = '0;
    logic [3:0] s_axi_awqos = '0;
    logic [3:0] s_axi_awregion = '0;
    logic s_axi_awvalid = 1'b0;
    wire s_axi_awready;
    logic [DATA_WIDTH-1:0] s_axi_wdata = '0;
    logic [STRB_WIDTH-1:0] s_axi_wstrb = '0;
    logic s_axi_wlast = '0;
    logic s_axi_wvalid = '0;
    wire s_axi_wready;
    wire [ID_WIDTH-1:0] s_axi_bid;
    wire [1:0] s_axi_bresp;
    wire s_axi_bvalid;
    logic s_axi_bready = 1'b1;
    logic [ID_WIDTH-1:0] s_axi_arid = '0;
    logic [ADDR_WIDTH-1:0] s_axi_araddr = '0;
    logic [7:0] s_axi_arlen = '0;
    logic [2:0] s_axi_arsize = '0;
    logic [1:0] s_axi_arburst = '0;
    logic s_axi_arlock = 1'b0;
    logic [3:0] s_axi_arcache = '0;
    logic [2:0] s_axi_arprot = '0;
    logic [3:0] s_axi_arqos = '0;
    logic [3:0] s_axi_arregion = '0;
    logic s_axi_arvalid = 1'b0;
    wire s_axi_arready;
    wire [ID_WIDTH-1:0] s_axi_rid;
    wire [DATA_WIDTH-1:0] s_axi_rdata;
    wire [1:0] s_axi_rresp;
    wire s_axi_rlast;
    wire s_axi_rvalid;
    logic s_axi_rready = 1'b1;

    wire [ID_WIDTH-1:0] m_axi_awid;
    wire [ADDR_WIDTH-1:0] m_axi_awaddr;
    wire [7:0] m_axi_awlen;
    wire [2:0] m_axi_awsize;
    wire [1:0] m_axi_awburst;
    wire m_axi_awlock;
    wire [3:0] m_axi_awcache;
    wire [2:0] m_axi_awprot;
    wire [3:0] m_axi_awqos;
    wire [3:0] m_axi_awregion;
    wire m_axi_awvalid;
    logic m_axi_awready = 1'b0;
    wire [DATA_WIDTH-1:0] m_axi_wdata;
    wire [STRB_WIDTH-1:0] m_axi_wstrb;
    wire m_axi_wlast;
    wire m_axi_wvalid;
    logic m_axi_wready = 1'b0;
    logic [ID_WIDTH-1:0] m_axi_bid = '0;
    logic [1:0] m_axi_bresp = '0;
    logic m_axi_bvalid = 1'b0;
    wire m_axi_bready;
    wire [ID_WIDTH-1:0] m_axi_arid;
    wire [ADDR_WIDTH-1:0] m_axi_araddr;
    wire [7:0] m_axi_arlen;
    wire [2:0] m_axi_arsize;
    wire [1:0] m_axi_arburst;
    wire m_axi_arlock;
    wire [3:0] m_axi_arcache;
    wire [2:0] m_axi_arprot;
    wire [3:0] m_axi_arqos;
    wire [3:0] m_axi_arregion;
    wire m_axi_arvalid;
    logic m_axi_arready = 1'b0;
    logic [ID_WIDTH-1:0] m_axi_rid = '0;
    logic [DATA_WIDTH-1:0] m_axi_rdata = '0;
    logic [1:0] m_axi_rresp = '0;
    logic m_axi_rlast = '0;
    logic m_axi_rvalid = '0;
    wire m_axi_rready;

    wire [31:0] ahb_haddr;
    wire [1:0] ahb_htrans;
    wire ahb_hwrite;
    wire [2:0] ahb_hsize;
    wire [2:0] ahb_hburst;
    wire [63:0] ahb_hwdata;
    wire ahb_hbusreq;
    wire ahb_hlock;
    logic [63:0] ahb_hrdata = 64'h1234_5678_9ABC_DEF0;
    logic ahb_hready = 1'b1;
    logic [1:0] ahb_hresp = 2'b00;
    logic ahb_hgrant = 1'b1;
    logic [3:0] ahb_hmaster = 4'h0;

    logic seen_ahb_write = 1'b0;
    logic seen_ahb_read = 1'b0;
    logic [ID_WIDTH-1:0] first_rid = '0;
    logic [ID_WIDTH-1:0] second_rid = '0;
    logic [DATA_WIDTH-1:0] first_rdata = '0;
    logic [DATA_WIDTH-1:0] second_rdata = '0;
    integer read_count = 0;

    axi_ic_egress #(
        .DATA_WIDTH(DATA_WIDTH),
        .ADDR_WIDTH(ADDR_WIDTH),
        .STRB_WIDTH(STRB_WIDTH),
        .ID_WIDTH(ID_WIDTH),
        .TARGET_TYPE(1)
    )
    dut (
        .clk(clk),
        .rst(rst),
        .cfg_target_enable(1'b1),
        .s_axi_awid(s_axi_awid),
        .s_axi_awaddr(s_axi_awaddr),
        .s_axi_awlen(s_axi_awlen),
        .s_axi_awsize(s_axi_awsize),
        .s_axi_awburst(s_axi_awburst),
        .s_axi_awlock(s_axi_awlock),
        .s_axi_awcache(s_axi_awcache),
        .s_axi_awprot(s_axi_awprot),
        .s_axi_awqos(s_axi_awqos),
        .s_axi_awregion(s_axi_awregion),
        .s_axi_awuser(1'b0),
        .s_axi_awvalid(s_axi_awvalid),
        .s_axi_awready(s_axi_awready),
        .s_axi_wdata(s_axi_wdata),
        .s_axi_wstrb(s_axi_wstrb),
        .s_axi_wlast(s_axi_wlast),
        .s_axi_wuser(1'b0),
        .s_axi_wvalid(s_axi_wvalid),
        .s_axi_wready(s_axi_wready),
        .s_axi_bid(s_axi_bid),
        .s_axi_bresp(s_axi_bresp),
        .s_axi_buser(),
        .s_axi_bvalid(s_axi_bvalid),
        .s_axi_bready(s_axi_bready),
        .s_axi_arid(s_axi_arid),
        .s_axi_araddr(s_axi_araddr),
        .s_axi_arlen(s_axi_arlen),
        .s_axi_arsize(s_axi_arsize),
        .s_axi_arburst(s_axi_arburst),
        .s_axi_arlock(s_axi_arlock),
        .s_axi_arcache(s_axi_arcache),
        .s_axi_arprot(s_axi_arprot),
        .s_axi_arqos(s_axi_arqos),
        .s_axi_arregion(s_axi_arregion),
        .s_axi_aruser(1'b0),
        .s_axi_arvalid(s_axi_arvalid),
        .s_axi_arready(s_axi_arready),
        .s_axi_rid(s_axi_rid),
        .s_axi_rdata(s_axi_rdata),
        .s_axi_rresp(s_axi_rresp),
        .s_axi_rlast(s_axi_rlast),
        .s_axi_ruser(),
        .s_axi_rvalid(s_axi_rvalid),
        .s_axi_rready(s_axi_rready),
        .m_axi_awid(m_axi_awid),
        .m_axi_awaddr(m_axi_awaddr),
        .m_axi_awlen(m_axi_awlen),
        .m_axi_awsize(m_axi_awsize),
        .m_axi_awburst(m_axi_awburst),
        .m_axi_awlock(m_axi_awlock),
        .m_axi_awcache(m_axi_awcache),
        .m_axi_awprot(m_axi_awprot),
        .m_axi_awqos(m_axi_awqos),
        .m_axi_awregion(m_axi_awregion),
        .m_axi_awuser(),
        .m_axi_awvalid(m_axi_awvalid),
        .m_axi_awready(m_axi_awready),
        .m_axi_wdata(m_axi_wdata),
        .m_axi_wstrb(m_axi_wstrb),
        .m_axi_wlast(m_axi_wlast),
        .m_axi_wuser(),
        .m_axi_wvalid(m_axi_wvalid),
        .m_axi_wready(m_axi_wready),
        .m_axi_bid(m_axi_bid),
        .m_axi_bresp(m_axi_bresp),
        .m_axi_buser(1'b0),
        .m_axi_bvalid(m_axi_bvalid),
        .m_axi_bready(m_axi_bready),
        .m_axi_arid(m_axi_arid),
        .m_axi_araddr(m_axi_araddr),
        .m_axi_arlen(m_axi_arlen),
        .m_axi_arsize(m_axi_arsize),
        .m_axi_arburst(m_axi_arburst),
        .m_axi_arlock(m_axi_arlock),
        .m_axi_arcache(m_axi_arcache),
        .m_axi_arprot(m_axi_arprot),
        .m_axi_arqos(m_axi_arqos),
        .m_axi_arregion(m_axi_arregion),
        .m_axi_aruser(),
        .m_axi_arvalid(m_axi_arvalid),
        .m_axi_arready(m_axi_arready),
        .m_axi_rid(m_axi_rid),
        .m_axi_rdata(m_axi_rdata),
        .m_axi_rresp(m_axi_rresp),
        .m_axi_rlast(m_axi_rlast),
        .m_axi_ruser(1'b0),
        .m_axi_rvalid(m_axi_rvalid),
        .m_axi_rready(m_axi_rready),
        .ahb_haddr(ahb_haddr),
        .ahb_htrans(ahb_htrans),
        .ahb_hwrite(ahb_hwrite),
        .ahb_hsize(ahb_hsize),
        .ahb_hburst(ahb_hburst),
        .ahb_hwdata(ahb_hwdata),
        .ahb_hbusreq(ahb_hbusreq),
        .ahb_hlock(ahb_hlock),
        .ahb_hrdata(ahb_hrdata),
        .ahb_hready(ahb_hready),
        .ahb_hresp(ahb_hresp),
        .ahb_hgrant(ahb_hgrant),
        .ahb_hmaster(ahb_hmaster),
        .stat_write_decerr_pulse(),
        .stat_read_decerr_pulse(),
        .fault_valid(),
        .fault_code(),
        .fault_addr(),
        .fault_id(),
        .fault_src_port(),
        .fault_dst_port()
    );

    always #5 clk = ~clk;

    always @(posedge clk) begin
        if (!rst) begin
            if (s_axi_awvalid && s_axi_awready) begin
                $display("[%0t] AW handshake id=%h addr=%h", $time, s_axi_awid, s_axi_awaddr);
            end
            if (s_axi_wvalid && s_axi_wready) begin
                $display("[%0t] W handshake data=%h last=%0d", $time, s_axi_wdata, s_axi_wlast);
            end
            if (s_axi_bvalid && s_axi_bready) begin
                $display("[%0t] B handshake id=%h resp=%b", $time, s_axi_bid, s_axi_bresp);
            end
            if (s_axi_arvalid && s_axi_arready) begin
                $display("[%0t] AR handshake id=%h addr=%h", $time, s_axi_arid, s_axi_araddr);
            end
            if (s_axi_rvalid && s_axi_rready) begin
                $display("[%0t] R handshake id=%h data=%h last=%0d", $time, s_axi_rid, s_axi_rdata, s_axi_rlast);
            end
            if (ahb_htrans != 2'b00 && ahb_hwrite) begin
                seen_ahb_write <= 1'b1;
                $display("[%0t] AHB write haddr=%h hwdata=%h", $time, ahb_haddr, ahb_hwdata);
            end
            if (ahb_htrans != 2'b00 && !ahb_hwrite) begin
                seen_ahb_read <= 1'b1;
                $display("[%0t] AHB read haddr=%h", $time, ahb_haddr);
            end
            if (s_axi_rvalid && s_axi_rready) begin
                read_count <= read_count + 1;
                if (read_count == 0) begin
                    first_rid <= s_axi_rid;
                    first_rdata <= s_axi_rdata;
                end else if (read_count == 1) begin
                    second_rid <= s_axi_rid;
                    second_rdata <= s_axi_rdata;
                end
            end
        end
    end

    task automatic send_write(input [ID_WIDTH-1:0] id, input [31:0] addr, input [63:0] data);
    begin
        @(posedge clk);
        s_axi_awid <= id;
        s_axi_awaddr <= addr;
        s_axi_awlen <= 8'd0;
        s_axi_awsize <= 3'd3;
        s_axi_awburst <= 2'b01;
        s_axi_awvalid <= 1'b1;
        wait (s_axi_awready);
        @(posedge clk);
        s_axi_awvalid <= 1'b0;

        s_axi_wdata <= data;
        s_axi_wstrb <= 8'hFF;
        s_axi_wlast <= 1'b1;
        s_axi_wvalid <= 1'b1;
        wait (s_axi_wready);
        @(posedge clk);
        s_axi_wvalid <= 1'b0;
        s_axi_wlast <= 1'b0;
    end
    endtask

    task automatic send_read(input [ID_WIDTH-1:0] id, input [31:0] addr);
    begin
        @(posedge clk);
        s_axi_arid <= id;
        s_axi_araddr <= addr;
        s_axi_arlen <= 8'd0;
        s_axi_arsize <= 3'd3;
        s_axi_arburst <= 2'b01;
        s_axi_arvalid <= 1'b1;
        wait (s_axi_arready);
        @(posedge clk);
        s_axi_arvalid <= 1'b0;
    end
    endtask

    initial begin
        #4000;
        $display("FAIL timeout in tb_axi_ic_egress_axi2ahb");
        $fatal;
    end

    initial begin
        repeat (4) @(posedge clk);
        rst <= 1'b0;

        send_write(10'h3AA, 32'h0000_1000, 64'hCAFE_BABE_1234_5678);
        wait (s_axi_bvalid);
        if (s_axi_bid !== 10'h3AA || s_axi_bresp !== 2'b00) begin
            $display("FAIL write response must restore full ID");
            $fatal;
        end
        if (!seen_ahb_write) begin
            $display("FAIL write should drive AHB bus");
            $fatal;
        end

        send_read(10'h155, 32'h0000_2000);
        send_read(10'h255, 32'h0000_3000);
        wait (read_count == 2);

        if (!seen_ahb_read) begin
            $display("FAIL read should drive AHB bus");
            $fatal;
        end
        if (first_rid !== 10'h155) begin
            $display("FAIL first read response must restore full ID 0x155");
            $fatal;
        end
        if (second_rid !== 10'h255) begin
            $display("FAIL second read response must restore full ID 0x255");
            $fatal;
        end
        if (first_rdata !== 64'h1234_5678_9ABC_DEF0 || second_rdata !== 64'h1234_5678_9ABC_DEF0) begin
            $display("FAIL read data must come back from bridge");
            $fatal;
        end

        $display("PASS tb_axi_ic_egress_axi2ahb");
        $finish;
    end

endmodule
