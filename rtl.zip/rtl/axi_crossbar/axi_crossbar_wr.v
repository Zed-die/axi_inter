/*

Copyright (c) 2018 Alex Forencich

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

*/

// Language: Verilog 2001

`resetall
`timescale 1ns / 1ps
`default_nettype none

/*
 * AXI4 crossbar (write)
 */
module axi_crossbar_wr #
(
    // Number of AXI inputs (slave interfaces)
    parameter S_COUNT = 4,
    // Number of AXI outputs (master interfaces)
    parameter M_COUNT = 4,
    // Width of data bus in bits
    parameter DATA_WIDTH = 32,
    // Width of address bus in bits
    parameter ADDR_WIDTH = 32,
    // Width of wstrb (width of data bus in words)
    parameter STRB_WIDTH = (DATA_WIDTH/8),
    // Input ID field width (from AXI masters)
    parameter S_ID_WIDTH = 8,
    // Output ID field width (towards AXI slaves)
    // Additional bits required for response routing
    parameter M_ID_WIDTH = S_ID_WIDTH + $clog2(S_COUNT),  //输出端口的ID为输入端口的索引加输入侧的ID的值
    // Propagate awuser signal
    parameter AWUSER_ENABLE = 0,
    // Width of awuser signal
    parameter AWUSER_WIDTH = 1,
    // Propagate wuser signal
    parameter WUSER_ENABLE = 0,
    // Width of wuser signal
    parameter WUSER_WIDTH = 1,
    // Propagate buser signal
    parameter BUSER_ENABLE = 0,
    // Width of buser signal
    parameter BUSER_WIDTH = 1,
    // Number of concurrent unique IDs for each slave interface
    // S_COUNT concatenated fields of 32 bits
    parameter S_THREADS = {S_COUNT{32'd2}},
    // Number of concurrent operations for each slave interface
    // S_COUNT concatenated fields of 32 bits
    parameter S_ACCEPT = {S_COUNT{32'd16}},
    // Number of regions per master interface
    parameter M_REGIONS = 1,
    // Master interface base addresses
    // M_COUNT concatenated fields of M_REGIONS concatenated fields of ADDR_WIDTH bits
    // set to zero for default addressing based on M_ADDR_WIDTH
    parameter M_BASE_ADDR = 0,
    // Master interface address widths
    // M_COUNT concatenated fields of M_REGIONS concatenated fields of 32 bits
    parameter M_ADDR_WIDTH = {M_COUNT{{M_REGIONS{32'd24}}}},
    // Write connections between interfaces
    // M_COUNT concatenated fields of S_COUNT bits
    parameter M_CONNECT = {M_COUNT{{S_COUNT{1'b1}}}},
    // Number of concurrent operations for each master interface
    // M_COUNT concatenated fields of 32 bits
    parameter M_ISSUE = {M_COUNT{32'd4}},
    // Secure master (fail operations based on awprot/arprot)
    // M_COUNT bits
    parameter M_SECURE = {M_COUNT{1'b0}},
    // Slave interface AW channel register type (input)
    // 0 to bypass, 1 for simple buffer, 2 for skid buffer
    parameter S_AW_REG_TYPE = {S_COUNT{2'd0}},
    // Slave interface W channel register type (input)
    // 0 to bypass, 1 for simple buffer, 2 for skid buffer
    parameter S_W_REG_TYPE = {S_COUNT{2'd0}},
    // Slave interface B channel register type (output)
    // 0 to bypass, 1 for simple buffer, 2 for skid buffer
    parameter S_B_REG_TYPE = {S_COUNT{2'd1}},
    // Master interface AW channel register type (output)
    // 0 to bypass, 1 for simple buffer, 2 for skid buffer
    parameter M_AW_REG_TYPE = {M_COUNT{2'd1}},
    // Master interface W channel register type (output)
    // 0 to bypass, 1 for simple buffer, 2 for skid buffer
    parameter M_W_REG_TYPE = {M_COUNT{2'd2}},
    // Master interface B channel register type (input)
    // 0 to bypass, 1 for simple buffer, 2 for skid buffer
    parameter M_B_REG_TYPE = {M_COUNT{2'd0}}
)
(
    input  wire                             clk,
    input  wire                             rst,

    /*
     * AXI slave interfaces
     */
    input  wire [S_COUNT*S_ID_WIDTH-1:0]    s_axi_awid,
    input  wire [S_COUNT*ADDR_WIDTH-1:0]    s_axi_awaddr,
    input  wire [S_COUNT*8-1:0]             s_axi_awlen,
    input  wire [S_COUNT*3-1:0]             s_axi_awsize,
    input  wire [S_COUNT*2-1:0]             s_axi_awburst,
    input  wire [S_COUNT-1:0]               s_axi_awlock,
    input  wire [S_COUNT*4-1:0]             s_axi_awcache,
    input  wire [S_COUNT*3-1:0]             s_axi_awprot,
    input  wire [S_COUNT*4-1:0]             s_axi_awqos,
    input  wire [S_COUNT*AWUSER_WIDTH-1:0]  s_axi_awuser,
    input  wire [S_COUNT-1:0]               s_axi_awvalid,
    output wire [S_COUNT-1:0]               s_axi_awready,
    input  wire [S_COUNT*DATA_WIDTH-1:0]    s_axi_wdata,
    input  wire [S_COUNT*STRB_WIDTH-1:0]    s_axi_wstrb,
    input  wire [S_COUNT-1:0]               s_axi_wlast,
    input  wire [S_COUNT*WUSER_WIDTH-1:0]   s_axi_wuser,
    input  wire [S_COUNT-1:0]               s_axi_wvalid,
    output wire [S_COUNT-1:0]               s_axi_wready,
    output wire [S_COUNT*S_ID_WIDTH-1:0]    s_axi_bid,
    output wire [S_COUNT*2-1:0]             s_axi_bresp,
    output wire [S_COUNT*BUSER_WIDTH-1:0]   s_axi_buser,
    output wire [S_COUNT-1:0]               s_axi_bvalid,
    input  wire [S_COUNT-1:0]               s_axi_bready,

    /*
     * AXI master interfaces
     */
    output wire [M_COUNT*M_ID_WIDTH-1:0]    m_axi_awid,
    output wire [M_COUNT*ADDR_WIDTH-1:0]    m_axi_awaddr,
    output wire [M_COUNT*8-1:0]             m_axi_awlen,
    output wire [M_COUNT*3-1:0]             m_axi_awsize,
    output wire [M_COUNT*2-1:0]             m_axi_awburst,
    output wire [M_COUNT-1:0]               m_axi_awlock,
    output wire [M_COUNT*4-1:0]             m_axi_awcache,
    output wire [M_COUNT*3-1:0]             m_axi_awprot,
    output wire [M_COUNT*4-1:0]             m_axi_awqos,
    output wire [M_COUNT*4-1:0]             m_axi_awregion,
    output wire [M_COUNT*AWUSER_WIDTH-1:0]  m_axi_awuser,
    output wire [M_COUNT-1:0]               m_axi_awvalid,
    input  wire [M_COUNT-1:0]               m_axi_awready,
    output wire [M_COUNT*DATA_WIDTH-1:0]    m_axi_wdata,
    output wire [M_COUNT*STRB_WIDTH-1:0]    m_axi_wstrb,
    output wire [M_COUNT-1:0]               m_axi_wlast,
    output wire [M_COUNT*WUSER_WIDTH-1:0]   m_axi_wuser,
    output wire [M_COUNT-1:0]               m_axi_wvalid,
    input  wire [M_COUNT-1:0]               m_axi_wready,
    input  wire [M_COUNT*M_ID_WIDTH-1:0]    m_axi_bid,
    input  wire [M_COUNT*2-1:0]             m_axi_bresp,
    input  wire [M_COUNT*BUSER_WIDTH-1:0]   m_axi_buser,
    input  wire [M_COUNT-1:0]               m_axi_bvalid,
    output wire [M_COUNT-1:0]               m_axi_bready
);

parameter CL_S_COUNT = $clog2(S_COUNT);
parameter CL_M_COUNT = $clog2(M_COUNT);
parameter M_COUNT_P1 = M_COUNT+1;  //B可能来自任意一个输出端口，也可能来自当前输入端口的地址解码模块，所以需要加1
parameter CL_M_COUNT_P1 = $clog2(M_COUNT_P1);

integer i;

// check configuration
initial begin
    if (M_ID_WIDTH < S_ID_WIDTH+$clog2(S_COUNT)) begin
        $error("Error: M_ID_WIDTH must be at least $clog2(S_COUNT) larger than S_ID_WIDTH (instance %m)");
        $finish;
    end

    for (i = 0; i < M_COUNT*M_REGIONS; i = i + 1) begin
        if (M_ADDR_WIDTH[i*32 +: 32] && (M_ADDR_WIDTH[i*32 +: 32] < 12 || M_ADDR_WIDTH[i*32 +: 32] > ADDR_WIDTH)) begin
            $error("Error: value out of range (instance %m)");
            $finish;
        end
    end
end

wire [S_COUNT*S_ID_WIDTH-1:0]    int_s_axi_awid;
wire [S_COUNT*ADDR_WIDTH-1:0]    int_s_axi_awaddr;
wire [S_COUNT*8-1:0]             int_s_axi_awlen;
wire [S_COUNT*3-1:0]             int_s_axi_awsize;
wire [S_COUNT*2-1:0]             int_s_axi_awburst;
wire [S_COUNT-1:0]               int_s_axi_awlock;
wire [S_COUNT*4-1:0]             int_s_axi_awcache;
wire [S_COUNT*3-1:0]             int_s_axi_awprot;
wire [S_COUNT*4-1:0]             int_s_axi_awqos;
wire [S_COUNT*4-1:0]             int_s_axi_awregion;
wire [S_COUNT*AWUSER_WIDTH-1:0]  int_s_axi_awuser;
wire [S_COUNT-1:0]               int_s_axi_awvalid;
wire [S_COUNT-1:0]               int_s_axi_awready;

// 下面这几组矩阵信号描述 crossbar 内部的端口到端口连接关系：
// int_axi_awvalid[m*M_COUNT+n] 表示 S[m] -> M[n] 的 AW valid。
// int_axi_awready[n*S_COUNT+m] 表示 M[n] -> S[m] 的 AW ready。
// W/B 通道也采用相同思路，只是索引展开方向随 valid/ready 的回传方向不同。
wire [S_COUNT*M_COUNT-1:0]       int_axi_awvalid;    //输入对应输出端口的valid，S个M输出端口的1维展开
wire [M_COUNT*S_COUNT-1:0]       int_axi_awready;   //输出到输入的ready

wire [S_COUNT*DATA_WIDTH-1:0]    int_s_axi_wdata;
wire [S_COUNT*STRB_WIDTH-1:0]    int_s_axi_wstrb;
wire [S_COUNT-1:0]               int_s_axi_wlast;
wire [S_COUNT*WUSER_WIDTH-1:0]   int_s_axi_wuser;
wire [S_COUNT-1:0]               int_s_axi_wvalid;
wire [S_COUNT-1:0]               int_s_axi_wready;

wire [S_COUNT*M_COUNT-1:0]       int_axi_wvalid;
wire [M_COUNT*S_COUNT-1:0]       int_axi_wready;

wire [M_COUNT*M_ID_WIDTH-1:0]    int_m_axi_bid;
wire [M_COUNT*2-1:0]             int_m_axi_bresp;
wire [M_COUNT*BUSER_WIDTH-1:0]   int_m_axi_buser;
wire [M_COUNT-1:0]               int_m_axi_bvalid;
wire [M_COUNT-1:0]               int_m_axi_bready;

wire [M_COUNT*S_COUNT-1:0]       int_axi_bvalid;
wire [S_COUNT*M_COUNT-1:0]       int_axi_bready;

generate

    genvar m, n;

    // 为每个输入端口生成一套独立逻辑：
    // 1. 对 AW 地址做译码，决定目标 M 端口；
    // 2. 锁存 W 通道后续应跟随的目标端口；
    // 3. 将来自各 M 端口的 B 响应仲裁后返回当前 S 端口。
    for (m = 0; m < S_COUNT; m = m + 1) begin : s_ifaces
        // address decode and admission control
        // a_select 是当前 S 端口这笔 AW 译码后命中的目标 M 端口编号。
        wire [CL_M_COUNT-1:0] a_select;

        wire m_axi_avalid;
        // 当前 S 端口只关心“被 a_select 选中的那个 M 端口”返回的 AW ready。
        wire m_axi_aready;

        wire [CL_M_COUNT-1:0] m_wc_select;
        wire m_wc_decerr;
        wire m_wc_valid;
        wire m_wc_ready;

        wire m_rc_decerr;
        wire m_rc_valid;
        wire m_rc_ready;

        wire [S_ID_WIDTH-1:0] s_cpl_id;
        wire s_cpl_valid;

        // 每个输入端口各实例化一个地址译码/准入控制模块。
        // 它负责根据 AWADDR 等信息确定目标 M 端口，
        // 同时输出 W 通道路由命令以及错误响应命令。
        axi_crossbar_addr #(
            .S              (m                    ),     // 当前 Slave 接口 index
            .S_COUNT        (S_COUNT              ),
            .M_COUNT        (M_COUNT              ),
            .ADDR_WIDTH     (ADDR_WIDTH           ),
            .ID_WIDTH       (S_ID_WIDTH           ),
            .S_THREADS      (S_THREADS[m*32 +: 32]),
            .S_ACCEPT       (S_ACCEPT[m*32 +: 32] ),
            .M_REGIONS      (M_REGIONS            ),
            .M_BASE_ADDR    (M_BASE_ADDR          ),
            .M_ADDR_WIDTH   (M_ADDR_WIDTH         ),
            .M_CONNECT      (M_CONNECT            ),
            .M_SECURE       (M_SECURE             ),
            .WC_OUTPUT      (1                    )
        )
        addr_inst (
            .clk(clk),
            .rst(rst),

            /*
             * Address input
             */
            .s_axi_aid      (int_s_axi_awid[m*S_ID_WIDTH +: S_ID_WIDTH]  ),
            .s_axi_aaddr    (int_s_axi_awaddr[m*ADDR_WIDTH +: ADDR_WIDTH]),
            .s_axi_aprot    (int_s_axi_awprot[m*3 +: 3]                  ),
            .s_axi_aqos     (int_s_axi_awqos[m*4 +: 4]                   ),
            .s_axi_avalid   (int_s_axi_awvalid[m]                        ),
            // 译码模块看到的是经过 S 侧寄存器切片后的 AW 握手。
            .s_axi_aready   (int_s_axi_awready[m]                        ),//模块输出给上游端口

            /*
             * Address output
             */
            .m_axi_aregion  (int_s_axi_awregion[m*4 +: 4]),//用过地址译码得到的 Region 信息
            .m_select       (a_select    ),//地址译码选中的输出目标 M 端口
            .m_axi_avalid   (m_axi_avalid),
            .m_axi_aready   (m_axi_aready),

            /*
             * Write command output  写数据通道路由
             */
            .m_wc_select    (m_wc_select),
            .m_wc_decerr    (m_wc_decerr),
            .m_wc_valid     (m_wc_valid ),
            .m_wc_ready     (m_wc_ready ),     

            /*
             * Response command output
             */
            .m_rc_decerr    (m_rc_decerr),
            .m_rc_valid     (m_rc_valid ),//事务无译码错误时，此valid信号不会拉高
            .m_rc_ready     (m_rc_ready ),

            /*
             * Completion input
             */
            .s_cpl_id       (s_cpl_id   ),
            .s_cpl_valid    (s_cpl_valid)
        );

        // 把当前 S[m] 的 AW valid 变成 one-hot，仅送到 a_select 指向的 M 端口。
        assign int_axi_awvalid[m*M_COUNT +: M_COUNT] = m_axi_avalid << a_select;  //生成与输出侧握手的valid信号，左移解码出的输出端口索引
        // m_axi_aready 只取回“当前这笔地址实际要去的那个 M 端口”的 ready。
        // 这也是上游看到的 AW 是否能握手成功的直接来源。
        assign m_axi_aready = int_axi_awready[a_select*S_COUNT + m];  //输出端口到输入端口的ready信号

        // W 通道路由以及丢弃锁存
        // AW 和 W 是独立握手的，所以要把本次地址译码得到的目标端口锁存下来，
        // 让后续整个 W burst 都跟着同一个 M 端口走，直到 WLAST 完成。
        reg [CL_M_COUNT-1:0] w_select_reg = 0, w_select_next;  //用于记录当前S端口的数据要发给哪个M
        reg w_drop_reg = 1'b0, w_drop_next;
        reg w_select_valid_reg = 1'b0, w_select_valid_next;

        // 只有当前没有待发送的 W burst 时，才接受新的写命令。
        assign m_wc_ready = !w_select_valid_reg;

        always @* begin
            w_select_next = w_select_reg;
            w_drop_next = w_drop_reg && !(int_s_axi_wvalid[m] && int_s_axi_wready[m] && int_s_axi_wlast[m]);//直到握手完最后一拍数据才拉低w_drop
            w_select_valid_next = w_select_valid_reg && !(int_s_axi_wvalid[m] && int_s_axi_wready[m] && int_s_axi_wlast[m]);  //握手完最后一拍数据拉低w_select_valid_next

            if (m_wc_valid && m_wc_ready) begin   //握手成功锁存W路由通道
                w_select_next = m_wc_select;
                w_drop_next = m_wc_decerr;
                w_select_valid_next = m_wc_valid;
            end
        end

        always @(posedge clk) begin
            if (rst) begin
                w_select_valid_reg <= 1'b0;
            end else begin
                w_select_valid_reg <= w_select_valid_next;
            end

            //依旧只复位控制通路
            w_select_reg <= w_select_next;    //对于每个输入端口都单独寄存译码得到的输出端口号
            w_drop_reg <= w_drop_next;     
        end

        // write data forwarding
        // 如果地址译码失败，w_drop_reg 会置位，此时 W 数据不会真正送往任何 M 端口，
        // 而是直接把 ready 返回给上游，将这段数据吞掉并等待本地 DECERR 响应。
        assign int_axi_wvalid[m*M_COUNT +: M_COUNT] = (int_s_axi_wvalid[m] && w_select_valid_reg && !w_drop_reg) << w_select_reg; //路由内部wvalid信号,当数据无需丢弃时将w通道的valid路由给输出端口
        assign int_s_axi_wready[m] = int_axi_wready[w_select_reg*S_COUNT+m] || w_drop_reg;  //或上w_drop_reg是为了吸收错误数据防止上游一直等待ready卡死

        //decode error handling
        //锁存解码错误信息
        reg [S_ID_WIDTH-1:0]  decerr_m_axi_bid_reg = {S_ID_WIDTH{1'b0}}, decerr_m_axi_bid_next;
        reg                   decerr_m_axi_bvalid_reg = 1'b0, decerr_m_axi_bvalid_next;
        // CHANGE: Hold a local DECERR response until the dropped W burst reaches WLAST.
        reg                   decerr_pending_reg = 1'b0, decerr_pending_next;
        wire                  decerr_m_axi_bready;
        // CHANGE: Detect completion of the write data burst that belongs to a decode error.
        wire                  decerr_wlast_hs;

        // CHANGE: Only release DECERR into B arbitration after the error WLAST is accepted.
        assign decerr_wlast_hs = w_drop_reg && int_s_axi_wvalid[m] && int_s_axi_wready[m] && int_s_axi_wlast[m]; //hs为handshake，即握手的意思
        // CHANGE: Block another local decode-error response while one is pending or valid.
        assign m_rc_ready = !decerr_pending_reg && !decerr_m_axi_bvalid_reg;
            
        always @* begin
            decerr_m_axi_bid_next = decerr_m_axi_bid_reg;
            decerr_m_axi_bvalid_next = decerr_m_axi_bvalid_reg;
            // CHANGE: Default pending state is held unless a new error starts or WLAST completes it.
            decerr_pending_next = decerr_pending_reg;

            if (decerr_m_axi_bvalid_reg) begin
                if (decerr_m_axi_bready) begin
                    decerr_m_axi_bvalid_next = 1'b0; //握手成功valid置0
                end
            end 
            // CHANGE: Pending DECERR becomes a real B response only after dropped WLAST handshakes.
            else if (decerr_pending_reg) begin
                if (decerr_wlast_hs) begin
                    decerr_pending_next = 1'b0;
                    decerr_m_axi_bvalid_next = 1'b1;
                end
            end
            else if (m_rc_valid && m_rc_ready) begin
                decerr_m_axi_bid_next = int_s_axi_awid[m*S_ID_WIDTH +: S_ID_WIDTH];  //记录地址解码错误的ID编号
                // CHANGE: Record the error first; do not assert BVALID before the W burst is dropped.
                decerr_pending_next = 1'b1;
            end
        end

        always @(posedge clk) begin
            if (rst) begin
                decerr_m_axi_bvalid_reg <= 1'b0;
                // CHANGE: Clear delayed DECERR state on reset.
                decerr_pending_reg <= 1'b0;
            end else begin
                decerr_m_axi_bvalid_reg <= decerr_m_axi_bvalid_next;
                // CHANGE: Register delayed DECERR state alongside BVALID.
                decerr_pending_reg <= decerr_pending_next;
            end

            decerr_m_axi_bid_reg <= decerr_m_axi_bid_next;
        end

        // write response arbitration
        // 对当前 S 端口而言，B 响应可能来自任意一个 M 端口，
        // 也可能来自本地生成的 DECERR，因此这里需要统一仲裁。
        wire [M_COUNT_P1-1:0] b_request;
        wire [M_COUNT_P1-1:0] b_acknowledge;
        wire [M_COUNT_P1-1:0] b_grant;
        wire b_grant_valid;
        wire [CL_M_COUNT_P1-1:0] b_grant_encoded;

        //同于仲裁输入端口该响应哪个输入端口的B信号
        arbiter #(
            .PORTS(M_COUNT_P1),
            .ARB_TYPE_ROUND_ROBIN(1),
            .ARB_BLOCK(1),
            .ARB_BLOCK_ACK(1),
            .ARB_LSB_HIGH_PRIORITY(1)
        )
        b_arb_inst (
            .clk(clk),
            .rst(rst),
            .request(b_request),
            .acknowledge(b_acknowledge),
            .grant(b_grant), 
            .grant_valid(b_grant_valid),
            .grant_encoded(b_grant_encoded)
        );

        // write response mux
        // 将“来自所有 M 的真实响应”与“本地 DECERR 响应”拼在一起后复用，本地DECERR在高位，M响应在低位。
        wire [S_ID_WIDTH-1:0]  m_axi_bid_mux    = {decerr_m_axi_bid_reg, int_m_axi_bid} >> b_grant_encoded*M_ID_WIDTH;
        wire [1:0]             m_axi_bresp_mux  = {2'b11, int_m_axi_bresp} >> b_grant_encoded*2;   //2'b11代表DECERR（Decode Error，地址解码错误）
        wire [BUSER_WIDTH-1:0] m_axi_buser_mux  = {{BUSER_WIDTH{1'b0}}, int_m_axi_buser} >> b_grant_encoded*BUSER_WIDTH;
        wire                   m_axi_bvalid_mux = ({decerr_m_axi_bvalid_reg, int_m_axi_bvalid} >> b_grant_encoded) & b_grant_valid;
        wire                   m_axi_bready_mux;

        assign int_axi_bready[m*M_COUNT +: M_COUNT] = (b_grant_valid && m_axi_bready_mux) << b_grant_encoded;   
        assign decerr_m_axi_bready = (b_grant_valid && m_axi_bready_mux) && (b_grant_encoded == M_COUNT_P1-1);  //输入端口已完成B通道握手，要将这个ready信号路由回输出端口侧


        //来自输出端口的req
        for (n = 0; n < M_COUNT; n = n + 1) begin
            assign b_request[n] = int_axi_bvalid[n*S_COUNT+m] && !b_grant[n];   //当前输出端口确实有resp发往该输入端口且这个请求没有被响应
            assign b_acknowledge[n] = b_grant[n] && int_axi_bvalid[n*S_COUNT+m] && m_axi_bready_mux;
        end

        //来自本地DECERR的req
        assign b_request[M_COUNT_P1-1] = decerr_m_axi_bvalid_reg && !b_grant[M_COUNT_P1-1];   
        assign b_acknowledge[M_COUNT_P1-1] = b_grant[M_COUNT_P1-1] && decerr_m_axi_bvalid_reg && m_axi_bready_mux;

        assign s_cpl_id = m_axi_bid_mux;
        // Local DECERR writes were never counted as forwarded transactions.
        // Do not let their B response underflow the address tracker's counters.
        assign s_cpl_valid = m_axi_bvalid_mux && m_axi_bready_mux &&
            (b_grant_encoded != M_COUNT_P1-1);

        // S side register
        // S 侧寄存器切片用于切断组合路径，其中 AW 和 W 为bypass，B为simple buffer。
        axi_register_wr #(
            .DATA_WIDTH(DATA_WIDTH),
            .ADDR_WIDTH(ADDR_WIDTH),
            .STRB_WIDTH(STRB_WIDTH),
            .ID_WIDTH(S_ID_WIDTH),
            .AWUSER_ENABLE(AWUSER_ENABLE),
            .AWUSER_WIDTH(AWUSER_WIDTH),
            .WUSER_ENABLE(WUSER_ENABLE),
            .WUSER_WIDTH(WUSER_WIDTH),
            .BUSER_ENABLE(BUSER_ENABLE),
            .BUSER_WIDTH(BUSER_WIDTH),
            .AW_REG_TYPE(S_AW_REG_TYPE[m*2 +: 2]),
            .W_REG_TYPE(S_W_REG_TYPE[m*2 +: 2]),
            .B_REG_TYPE(S_B_REG_TYPE[m*2 +: 2])
        )
        reg_inst (
            .clk(clk),
            .rst(rst),
            .s_axi_awid(s_axi_awid[m*S_ID_WIDTH +: S_ID_WIDTH]),
            .s_axi_awaddr(s_axi_awaddr[m*ADDR_WIDTH +: ADDR_WIDTH]),
            .s_axi_awlen(s_axi_awlen[m*8 +: 8]),
            .s_axi_awsize(s_axi_awsize[m*3 +: 3]),
            .s_axi_awburst(s_axi_awburst[m*2 +: 2]),
            .s_axi_awlock(s_axi_awlock[m]),
            .s_axi_awcache(s_axi_awcache[m*4 +: 4]),
            .s_axi_awprot(s_axi_awprot[m*3 +: 3]),
            .s_axi_awqos(s_axi_awqos[m*4 +: 4]),
            .s_axi_awregion(4'd0),                      //不使用region信号标识，使用addr去解码出具体的region的值
            .s_axi_awuser(s_axi_awuser[m*AWUSER_WIDTH +: AWUSER_WIDTH]),
            .s_axi_awvalid(s_axi_awvalid[m]),
            .s_axi_awready(s_axi_awready[m]),
            .s_axi_wdata(s_axi_wdata[m*DATA_WIDTH +: DATA_WIDTH]),
            .s_axi_wstrb(s_axi_wstrb[m*STRB_WIDTH +: STRB_WIDTH]),
            .s_axi_wlast(s_axi_wlast[m]),
            .s_axi_wuser(s_axi_wuser[m*WUSER_WIDTH +: WUSER_WIDTH]),
            .s_axi_wvalid(s_axi_wvalid[m]),
            .s_axi_wready(s_axi_wready[m]),
            .s_axi_bid(s_axi_bid[m*S_ID_WIDTH +: S_ID_WIDTH]),
            .s_axi_bresp(s_axi_bresp[m*2 +: 2]),
            .s_axi_buser(s_axi_buser[m*BUSER_WIDTH +: BUSER_WIDTH]),
            .s_axi_bvalid(s_axi_bvalid[m]),
            .s_axi_bready(s_axi_bready[m]),
            .m_axi_awid(int_s_axi_awid[m*S_ID_WIDTH +: S_ID_WIDTH]),
            .m_axi_awaddr(int_s_axi_awaddr[m*ADDR_WIDTH +: ADDR_WIDTH]),    // 输出给 crossbar 核心的内部 AW 地址
            .m_axi_awlen(int_s_axi_awlen[m*8 +: 8]),
            .m_axi_awsize(int_s_axi_awsize[m*3 +: 3]),
            .m_axi_awburst(int_s_axi_awburst[m*2 +: 2]),
            .m_axi_awlock(int_s_axi_awlock[m]),
            .m_axi_awcache(int_s_axi_awcache[m*4 +: 4]),
            .m_axi_awprot(int_s_axi_awprot[m*3 +: 3]),
            .m_axi_awqos(int_s_axi_awqos[m*4 +: 4]),
            .m_axi_awregion(),
            .m_axi_awuser(int_s_axi_awuser[m*AWUSER_WIDTH +: AWUSER_WIDTH]),
            .m_axi_awvalid(int_s_axi_awvalid[m]),
            .m_axi_awready(int_s_axi_awready[m]),  //input signal
            .m_axi_wdata(int_s_axi_wdata[m*DATA_WIDTH +: DATA_WIDTH]),
            .m_axi_wstrb(int_s_axi_wstrb[m*STRB_WIDTH +: STRB_WIDTH]),
            .m_axi_wlast(int_s_axi_wlast[m]),
            .m_axi_wuser(int_s_axi_wuser[m*WUSER_WIDTH +: WUSER_WIDTH]),
            .m_axi_wvalid(int_s_axi_wvalid[m]),
            .m_axi_wready(int_s_axi_wready[m]),
            .m_axi_bid(m_axi_bid_mux),
            .m_axi_bresp(m_axi_bresp_mux),
            .m_axi_buser(m_axi_buser_mux),
            .m_axi_bvalid(m_axi_bvalid_mux),
            .m_axi_bready(m_axi_bready_mux)
        );
    end // s_ifaces


    //---------------------------------------------------------------------------------------------------------
    //
    // M interfaces  输出端口
    //
    //---------------------------------------------------------------------------------------------------------

    // 为每个输出端口生成一套独立逻辑：
    // 1. 在所有 S 端口之间仲裁 AW；
    // 2. 锁定与该 AW 对应的 W burst 来源；
    // 3. 根据扩展后的 BID 将 B 响应路由回原始 S 端口。
    for (n = 0; n < M_COUNT; n = n + 1) begin : m_ifaces   // 输出端口generate
        // in-flight transaction count
        // 统计当前 M 端口当前有多少笔已发出但尚未收到 B 的写事务。
        wire trans_start;
        wire trans_complete;
        reg [$clog2(M_ISSUE[n*32 +: 32]+1)-1:0] trans_count_reg = 0;

        // 达到并发上限后，暂停继续接受新的 AW 请求。 
        wire trans_limit = trans_count_reg >= M_ISSUE[n*32 +: 32] && !trans_complete;   //与输入端口的limit使用的参数不同，这里使用的是代表输出端口最大能够接收的事务数

        always @(posedge clk) begin
            if (rst) begin
                trans_count_reg <= 0;
            end else begin
                if (trans_start && !trans_complete) begin
                    trans_count_reg <= trans_count_reg + 1;
                end else if (!trans_start && trans_complete) begin        
                    trans_count_reg <= trans_count_reg - 1;
                end
            end
        end

        // address arbitration
        // 当前 M[n] 可能同时被多个 S 端口请求，这里通过轮询仲裁选择其一。
        reg [CL_S_COUNT-1:0] w_select_reg = 0, w_select_next;  //用于记录当前M端口的数据要接收哪个S端口的数据
        reg w_select_valid_reg = 1'b0, w_select_valid_next;
        reg w_select_new_reg = 1'b0, w_select_new_next;

        wire [S_COUNT-1:0] a_request;
        wire [S_COUNT-1:0] a_acknowledge;
        wire [S_COUNT-1:0] a_grant;
        wire a_grant_valid;
        wire [CL_S_COUNT-1:0] a_grant_encoded;


        //同于仲裁输出端口该响应哪个输入端口的AW信号
        arbiter #(
            .PORTS(S_COUNT),
            .ARB_TYPE_ROUND_ROBIN(1),
            .ARB_BLOCK(1),
            .ARB_BLOCK_ACK(1),
            .ARB_LSB_HIGH_PRIORITY(1)
        )
        a_arb_inst (
            .clk(clk),
            .rst(rst),
            .request(a_request),
            .acknowledge(a_acknowledge),
            .grant(a_grant),                    //独热码输出
            .grant_valid(a_grant_valid),
            .grant_encoded(a_grant_encoded)    //响应的输入端口的二进制index编码输出
        );

        // address mux
        // 送往 M 端口的 AWID 会额外拼接源 S 端口编号，
        // 这样 B 返回时就能根据 BID 高位反查原始来源
        wire [M_ID_WIDTH-1:0]   s_axi_awid_mux     = int_s_axi_awid[a_grant_encoded*S_ID_WIDTH +: S_ID_WIDTH] | (a_grant_encoded << S_ID_WIDTH);//拼接输出ID{输出端口号,源ID}
        wire [ADDR_WIDTH-1:0]   s_axi_awaddr_mux   = int_s_axi_awaddr[a_grant_encoded*ADDR_WIDTH +: ADDR_WIDTH];
        wire [7:0]              s_axi_awlen_mux    = int_s_axi_awlen[a_grant_encoded*8 +: 8];
        wire [2:0]              s_axi_awsize_mux   = int_s_axi_awsize[a_grant_encoded*3 +: 3];
        wire [1:0]              s_axi_awburst_mux  = int_s_axi_awburst[a_grant_encoded*2 +: 2];
        wire                    s_axi_awlock_mux   = int_s_axi_awlock[a_grant_encoded];
        wire [3:0]              s_axi_awcache_mux  = int_s_axi_awcache[a_grant_encoded*4 +: 4];
        wire [2:0]              s_axi_awprot_mux   = int_s_axi_awprot[a_grant_encoded*3 +: 3];
        wire [3:0]              s_axi_awqos_mux    = int_s_axi_awqos[a_grant_encoded*4 +: 4];
        wire [3:0]              s_axi_awregion_mux = int_s_axi_awregion[a_grant_encoded*4 +: 4];
        wire [AWUSER_WIDTH-1:0] s_axi_awuser_mux   = int_s_axi_awuser[a_grant_encoded*AWUSER_WIDTH +: AWUSER_WIDTH];
        wire                    s_axi_awvalid_mux  = int_axi_awvalid[a_grant_encoded*M_COUNT+n] && a_grant_valid;   //只给控制信号valid,数据位不管
        wire                    s_axi_awready_mux;  //当前输出端口的ready信号

        // 只有仲裁获胜的那个 S 端口能收到当前 M[n] 返回的 ready，将ready路由回仲裁成功的输入端口
        assign int_axi_awready[n*S_COUNT +: S_COUNT] = (a_grant_valid && s_axi_awready_mux) << a_grant_encoded; //s_axi_awready_mux为当前输出端口给入的ready信号，将该ready路由给仲裁胜利的输入端口

        for (m = 0; m < S_COUNT; m = m + 1) begin
            assign a_request[m] = int_axi_awvalid[m*M_COUNT+n] && !a_grant[m] && !trans_limit && !w_select_valid_next;  //当该m输入端口向n输出端口有请求，并且没有被仲裁轮到，outstanding数没受限，且当前输出端口没有W通道数据传输
            assign a_acknowledge[m] = a_grant[m] && int_axi_awvalid[m*M_COUNT+n] && s_axi_awready_mux;   //握手成功代表请求已被处理
        end

        assign trans_start = s_axi_awvalid_mux && s_axi_awready_mux && a_grant_valid;  //握手成功代表请求被接受传输开始

        // write data mux
        // W 通道不能重新仲裁，必须严格跟随前面已获胜的 AW 来源。
        wire [DATA_WIDTH-1:0]  s_axi_wdata_mux   = int_s_axi_wdata[w_select_reg*DATA_WIDTH +: DATA_WIDTH];    //数据通路始终锁定在解码出的端口
        wire [STRB_WIDTH-1:0]  s_axi_wstrb_mux   = int_s_axi_wstrb[w_select_reg*STRB_WIDTH +: STRB_WIDTH];
        wire                   s_axi_wlast_mux   = int_s_axi_wlast[w_select_reg];
        wire [WUSER_WIDTH-1:0] s_axi_wuser_mux   = int_s_axi_wuser[w_select_reg*WUSER_WIDTH +: WUSER_WIDTH];
        wire                   s_axi_wvalid_mux  = int_axi_wvalid[w_select_reg*M_COUNT+n] && w_select_valid_reg;
        wire                   s_axi_wready_mux;

        assign int_axi_wready[n*S_COUNT +: S_COUNT] = (w_select_valid_reg && s_axi_wready_mux) << w_select_reg;  //将当前输出端口的ready信号路由到接收输入端口

        // write data routing
        // 锁定当前 M[n] 正在服务的 S 端口，直到该 burst 的最后一拍 WLAST 完成。
        always @* begin
            w_select_next = w_select_reg;
            w_select_valid_next = w_select_valid_reg && !(s_axi_wvalid_mux && s_axi_wready_mux && s_axi_wlast_mux); //只要没有传输到最后一拍 w_select_valid_next 就一直有效
            w_select_new_next = w_select_new_reg || !a_grant_valid || a_acknowledge;//该信号主要用于处理valid持续拉高下的仲裁端口变化的情况
            /*
                当前本来就已经允许新装载
                当前还没有有效的 AW grant，所以还得继续等
                当前 AW grant 已经被成功握手确认，因此可以重新打开下一次新装载资格
            */
            //只有 w_select_new_reg=1 时，当前 AW 仲裁结果才允许被“装载”为新的 W 通道来源
            if (a_grant_valid && !w_select_valid_reg && w_select_new_reg) begin  //只有当前有 AW grant，当前还没有有效 W 选择，当前许可接新选择才能所锁存新的事务请求
                w_select_next = a_grant_encoded;    //锁定当前输出端口正在服务的输入端口端口
                w_select_valid_next = a_grant_valid;
                w_select_new_next = 1'b0;
            end
        end 

        always @(posedge clk) begin
            if (rst) begin
                w_select_valid_reg <= 1'b0;
                w_select_new_reg <= 1'b1;
            end else begin
                w_select_valid_reg <= w_select_valid_next;
                w_select_new_reg <= w_select_new_next;
            end

            w_select_reg <= w_select_next;
        end

        // write response forwarding
        // 从扩展后的 BID 中提取源 S 端口编号，再把响应只送回对应输入端口。
        // wire [CL_S_COUNT-1:0] b_select = m_axi_bid[n*M_ID_WIDTH +: M_ID_WIDTH]  >> S_ID_WIDTH;   Alex 原代码
        wire [CL_S_COUNT-1:0] b_select = int_m_axi_bid[n*M_ID_WIDTH +: M_ID_WIDTH] >> S_ID_WIDTH; //根据BID得到路由回去的源端口编号,在bresp被接收之前,这个值都不会改变所以不需要锁存

        assign int_axi_bvalid[n*S_COUNT +: S_COUNT] = int_m_axi_bvalid[n] << b_select;  //展开得到每个输出端口应该将resp信号路由到的输入端口
        assign int_m_axi_bready[n] = int_axi_bready[b_select*M_COUNT+n];

        assign trans_complete = int_m_axi_bvalid[n] && int_m_axi_bready[n];   //当前输出端口的事务完成标识

        // M side register
        // AW 采用simple buffer，W 采用skid buffer，B 采用bypass
        axi_register_wr #(
            .DATA_WIDTH(DATA_WIDTH),
            .ADDR_WIDTH(ADDR_WIDTH),
            .STRB_WIDTH(STRB_WIDTH),
            .ID_WIDTH(M_ID_WIDTH),
            .AWUSER_ENABLE(AWUSER_ENABLE),
            .AWUSER_WIDTH(AWUSER_WIDTH),
            .WUSER_ENABLE(WUSER_ENABLE),
            .WUSER_WIDTH(WUSER_WIDTH),
            .BUSER_ENABLE(BUSER_ENABLE),
            .BUSER_WIDTH(BUSER_WIDTH),
            .AW_REG_TYPE(M_AW_REG_TYPE[n*2 +: 2]),
            .W_REG_TYPE(M_W_REG_TYPE[n*2 +: 2]),
            .B_REG_TYPE(M_B_REG_TYPE[n*2 +: 2])
        )
        reg_inst (
            .clk(clk),
            .rst(rst),
            .s_axi_awid(s_axi_awid_mux),
            .s_axi_awaddr(s_axi_awaddr_mux),
            .s_axi_awlen(s_axi_awlen_mux),
            .s_axi_awsize(s_axi_awsize_mux),
            .s_axi_awburst(s_axi_awburst_mux),
            .s_axi_awlock(s_axi_awlock_mux),
            .s_axi_awcache(s_axi_awcache_mux),
            .s_axi_awprot(s_axi_awprot_mux),
            .s_axi_awqos(s_axi_awqos_mux),
            .s_axi_awregion(s_axi_awregion_mux),
            .s_axi_awuser(s_axi_awuser_mux),
            .s_axi_awvalid(s_axi_awvalid_mux),
            .s_axi_awready(s_axi_awready_mux),
            .s_axi_wdata(s_axi_wdata_mux),
            .s_axi_wstrb(s_axi_wstrb_mux),
            .s_axi_wlast(s_axi_wlast_mux),
            .s_axi_wuser(s_axi_wuser_mux),
            .s_axi_wvalid(s_axi_wvalid_mux),
            .s_axi_wready(s_axi_wready_mux),
            .s_axi_bid(int_m_axi_bid[n*M_ID_WIDTH +: M_ID_WIDTH]),
            .s_axi_bresp(int_m_axi_bresp[n*2 +: 2]),
            .s_axi_buser(int_m_axi_buser[n*BUSER_WIDTH +: BUSER_WIDTH]),
            .s_axi_bvalid(int_m_axi_bvalid[n]),
            .s_axi_bready(int_m_axi_bready[n]),
            .m_axi_awid(m_axi_awid[n*M_ID_WIDTH +: M_ID_WIDTH]),
            .m_axi_awaddr(m_axi_awaddr[n*ADDR_WIDTH +: ADDR_WIDTH]),
            .m_axi_awlen(m_axi_awlen[n*8 +: 8]),
            .m_axi_awsize(m_axi_awsize[n*3 +: 3]),
            .m_axi_awburst(m_axi_awburst[n*2 +: 2]),
            .m_axi_awlock(m_axi_awlock[n]),
            .m_axi_awcache(m_axi_awcache[n*4 +: 4]),
            .m_axi_awprot(m_axi_awprot[n*3 +: 3]),
            .m_axi_awqos(m_axi_awqos[n*4 +: 4]),
            .m_axi_awregion(m_axi_awregion[n*4 +: 4]),
            .m_axi_awuser(m_axi_awuser[n*AWUSER_WIDTH +: AWUSER_WIDTH]),
            .m_axi_awvalid(m_axi_awvalid[n]),
            .m_axi_awready(m_axi_awready[n]),
            .m_axi_wdata(m_axi_wdata[n*DATA_WIDTH +: DATA_WIDTH]),
            .m_axi_wstrb(m_axi_wstrb[n*STRB_WIDTH +: STRB_WIDTH]),
            .m_axi_wlast(m_axi_wlast[n]),
            .m_axi_wuser(m_axi_wuser[n*WUSER_WIDTH +: WUSER_WIDTH]),
            .m_axi_wvalid(m_axi_wvalid[n]),
            .m_axi_wready(m_axi_wready[n]),
            .m_axi_bid(m_axi_bid[n*M_ID_WIDTH +: M_ID_WIDTH]),
            .m_axi_bresp(m_axi_bresp[n*2 +: 2]),
            .m_axi_buser(m_axi_buser[n*BUSER_WIDTH +: BUSER_WIDTH]),
            .m_axi_bvalid(m_axi_bvalid[n]),
            .m_axi_bready(m_axi_bready[n])
        );
    end // m_ifaces

endgenerate

endmodule

`resetall
