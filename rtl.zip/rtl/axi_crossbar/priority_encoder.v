/*

Copyright (c) 2014-2021 Alex Forencich

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

*/

// Language: Verilog 2001

`resetall
`timescale 1ns / 1ps
`default_nettype none

/*
 * Priority encoder module
 */
 //在一个多位宽的输入信号中，找出优先级最高的那一个 1，然后输出它的二进制索引号和独热码。
 //支持通过参数化配置到底是LSB还是MSB
module priority_encoder #
(
    parameter WIDTH = 4,
    // LSB priority selection
    parameter LSB_HIGH_PRIORITY = 0
)
(
    input  wire [WIDTH-1:0]         input_unencoded,
    output wire                     output_valid,    //编码有效标识
    output wire [$clog2(WIDTH)-1:0] output_encoded,   //二进制index输出
    output wire [WIDTH-1:0]         output_unencoded   //独热码输出
);

parameter LEVELS = WIDTH > 2 ? $clog2(WIDTH) : 1;   //如果位宽大于2才能用$clog2(WIDTH)(对于2来说结果是1)
parameter W = 2**LEVELS;

//将输入拓展为2^N位宽的信号
wire [W-1:0] input_padded = {{W-WIDTH{1'b0}}, input_unencoded};  

wire [W/2-1:0] stage_valid[LEVELS-1:0];
wire [W/2-1:0] stage_enc[LEVELS-1:0];

/*
    stage_enc 存的是局部编码结果。
    在第 l 层，每个节点对应的编码宽度是：l+1，最高层是LEVELS-1，所以编码宽度为LEVELS
*/

/*
=============================================================================================
                           8-Bit Priority Encoder (Binary Tree)
=============================================================================================

                                    [ Stage 2 (Root) ]
                                 (output_valid, output_encoded)
                                    V: ___  |  E: ___
                                         /       \
                                       /           \
                                     /               \
                                   /                   \
                                 /                       \
                 [ Stage 1, n=1 ]                         [ Stage 1, n=0 ]
                V: ___  |  E: __                         V: ___  |  E: __
                   /         \                              /         \
                 /             \                          /             \
               /                 \                      /                 \
             /                     \                  /                     \
 [ Stage 0, n=3 ]           [ Stage 0, n=2 ]  [ Stage 0, n=1 ]           [ Stage 0, n=0 ]
   V: _  |  E: _              V: _  |  E: _     V: _  |  E: _              V: _  |  E: _
      /   \                      /   \             /   \                      /   \
    /       \                  /       \         /       \                  /       \
  /           \              /           \     /           \              /           \
Bit 7       Bit 6          Bit 5       Bit 4 Bit 3       Bit 2          Bit 1       Bit 0




=============================================================================================
                           8-Bit Priority Encoder (Input: 10110100)
                                      Mode: LSB Priority
=============================================================================================

                                    [ Stage 2 (Root) ]
                                 (output_valid, output_encoded)
                                    V: 1  |  E: 010  (即十进制 2)
                                         /       \
                                       /           \
                                     /               \
                                   /                   \
                                 /                       \
                 [ Stage 1, n=1 ]                         [ Stage 1, n=0 ]
                V: 1  |  E: 00                           V: 1  |  E: 10
                   /         \                              /         \
                 /             \                          /             \
               /                 \                      /                 \
             /                     \                  /                     \
 [ Stage 0, n=3 ]           [ Stage 0, n=2 ]  [ Stage 0, n=1 ]           [ Stage 0, n=0 ]
   V: 1  |  E: 1              V: 1  |  E: 0     V: 1  |  E: 0              V: 0  |  E: 1 (Don't care)
      /   \                      /   \             /   \                      /   \
    /       \                  /       \         /       \                  /       \
  /           \              /           \     /           \              /           \
B7(1)       B6(0)          B5(1)       B4(1) B3(0)       B2(1)          B1(0)       B0(0)

==============================================================================================

==============================================================================================
*/

generate
    genvar l, n;

    // process input bits; generate valid bit and encoded bit for each pair
    for (n = 0; n < W/2; n = n + 1) begin : loop_in
        assign stage_valid[0][n] = |input_padded[n*2+1:n*2];   //计算Level0各个节点的值，初赛有效性报告（“这组有人来参赛吗？”）
        if (LSB_HIGH_PRIORITY) begin
            // bit 0 is highest priority
            assign stage_enc[0][n] = !input_padded[n*2+0];  //偶数节点取反，对于8个节点分为4组，76，54，32，10，对于LSB编码，比较结果输出的值恰好是0，2，4，6的取反
        end else begin
            // bit 0 is lowest priority
            assign stage_enc[0][n] = input_padded[n*2+1];  //奇数节点，比较结果恰好是1，3，5，7，对于MSB来说
        end
    end

    // compress down to single valid bit and encoded bus
    for (l = 1; l < LEVELS; l = l + 1) begin : loop_levels
        for (n = 0; n < W/(2*2**l); n = n + 1) begin : loop_compress        //W/(2*2**l) 是用来计算在当前层级 l 中，二叉树包含的节点总数（W / 2^(l+1)),也就是 8/2^2, 8/2^3
            assign stage_valid[l][n] = |stage_valid[l-1][n*2+1:n*2];   //判断当前Level的各个节点下方的2个子节点是否有人参赛
            if (LSB_HIGH_PRIORITY) begin
                // bit 0 is highest priority
                assign stage_enc[l][(n+1)*(l+1)-1:n*(l+1)] = stage_valid[l-1][n*2+0] ? {1'b0, stage_enc[l-1][(n*2+1)*l-1:(n*2+0)*l]} : {1'b1, stage_enc[l-1][(n*2+2)*l-1:(n*2+1)*l]};  
                /*

                    当 LSB 优先，如果右侧子节点有效，为{0，右侧enc[l-1]}，否则为{1，左侧enc[l-1]}

                */
            end else begin
                // bit 0 is lowest priority
                assign stage_enc[l][(n+1)*(l+1)-1:n*(l+1)] = stage_valid[l-1][n*2+1] ? {1'b1, stage_enc[l-1][(n*2+2)*l-1:(n*2+1)*l]} : {1'b0, stage_enc[l-1][(n*2+1)*l-1:(n*2+0)*l]};
                /*

                    如果 MSB 优先，那么左右两个子节点都可能有命中时，优先选右子节点。

                */
            end
        end
    end
endgenerate

assign output_valid = stage_valid[LEVELS-1];
assign output_encoded = stage_enc[LEVELS-1];  //结果取最高level数值
assign output_unencoded = 1 << output_encoded;  //独热码表现

endmodule

`resetall
