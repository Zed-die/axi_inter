/*

Copyright (c) 2018 Alex Forencich

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

*/

// Language: Verilog 2001

`resetall
`timescale 1ns / 1ps
`default_nettype none

/*
 * AXI4 crossbar address decode and admission control
 * AXI4 交叉开关：地址译码与准入控制模块
 */
module axi_crossbar_addr #
(
    // 当前输入端口（Slave接口）的索引编号
    // 用于在拓扑掩码中提取属于自己的连接权限
    parameter S = 0,
    
    // AXI 输入端口数量（连接到上游 Master 的数量）
    parameter S_COUNT = 4,
    
    // AXI 输出端口数量（连接到下游 Slave 的数量）
    parameter M_COUNT = 4,
    
    // 地址总线的位宽
    parameter ADDR_WIDTH = 32,
    
    // AXI ID 信号的位宽
    parameter ID_WIDTH = 8,
    
    // 允许并发追踪的唯一 ID 种类数（即防乱序追踪表的槽位深度/线程数），及对于同一个Master发送的同一ID能够接收最大数量的不同目的地
    parameter S_THREADS = 32'd2,
    
    // 允许并发的事务总数（即该端口的最大 Outstanding 数量/超前传输上限）
    parameter S_ACCEPT = 32'd16,
    
    // 每个输出端口支持的不连续地址区域数量
    parameter M_REGIONS = 1,    //每个主口能够对应的Region最大值
    
    // 各输出端口的基地址映射表
    // 数据结构：M_COUNT 个 (M_REGIONS 个 ADDR_WIDTH 位宽的字段) 的长拼接向量
    // 若全部设为 0，底层将根据 M_ADDR_WIDTH 全自动分配连续且对齐的基地址
    parameter M_BASE_ADDR = 0,  //// {第0个输出端口的第0个Region基地址, 第0个输出端口的第1个Region基地址, 第1个输出端口的第0个Region基地址, 第1个输出端口的第1个Region基地址, ...}
    
    // 各输出端口的地址空间大小（用位宽表示，例如 24 代表 16MB 空间）
    // 数据结构：M_COUNT 个 (M_REGIONS 个 32 位宽的字段) 的长拼接向量
    parameter M_ADDR_WIDTH = {M_COUNT{{M_REGIONS{32'd24}}}},   //下游有M_COUNT个Slave，每个Slave有M_REGIONS个区域，配置为32'd24代表2^24也就是16MB空间
    
    // 端口连通性拓扑掩码矩阵（用于配置全交叉或稀疏矩阵，优化布线资源）
    // 数据结构：M_COUNT 个 S_COUNT 位的拼接向量
    parameter M_CONNECT = {M_COUNT{{S_COUNT{1'b1}}}},   // {第 0 个输出端口对应 S_COUNT 个输入端口的连接，第 1 个输出端口对应 S_COUNT 个输入端口的连接...}
    
    /*
        如果 M_SECURE[i] == 0
        说明这个目标端口不是 secure 设备，直接允许通过
        如果 M_SECURE[i] == 1
        说明这个目标端口是 secure 设备，这时还要满足 s_axi_aprot[1] == 0 才允许访问，s_axi_aprot的第1位为安全访问标识
    */
    parameter M_SECURE = {M_COUNT{1'b0}},  
    
    // 启用写命令同步输出（架构复用开关）
    // 用于 AW 通道时设为 1（输出令牌指挥 W 数据通道），用于 AR 通道时设为 0
    parameter WC_OUTPUT = 0
)
(
    input  wire                       clk,
    input  wire                       rst,

    /*
     * Address input
     */
    input  wire [ID_WIDTH-1:0]        s_axi_aid,
    input  wire [ADDR_WIDTH-1:0]      s_axi_aaddr,
    input  wire [2:0]                 s_axi_aprot,
    input  wire [3:0]                 s_axi_aqos,
    input  wire                       s_axi_avalid,
    output wire                       s_axi_aready,

    /*
     * Address output
     */
    output wire [3:0]                 m_axi_aregion,   //访问的地址Region区域
    output wire [$clog2(M_COUNT)-1:0] m_select,       //路由分配的端口号
    output wire                       m_axi_avalid,  
    input  wire                       m_axi_aready,   //下游路由来的ready信号

    /*
     * Write command output 只有当此模块用作 写地址 (AW) 通道 （此时 WC_OUTPUT = 1） 时，这组信号才有意义
     */
    output wire [$clog2(M_COUNT)-1:0] m_wc_select,   //通知W矩阵写数据的流向端口Index，与路由分配的端口号相同
    output wire                       m_wc_decerr,  //访问地址非法时，返回错误
    output wire                       m_wc_valid,
    input  wire                       m_wc_ready,

    /*
     * Reply command output
     */
    output wire                       m_rc_decerr,  //返回解码错误标识
    output wire                       m_rc_valid,   //返回reply信号有效，只有当解码出错时才会拉高
    input  wire                       m_rc_ready,

    /*
     * Completion input 从机完成信号
     */
    input  wire [ID_WIDTH-1:0]        s_cpl_id,      //完成事务ID
    input  wire                       s_cpl_valid  //有效信号
);

parameter CL_S_COUNT = $clog2(S_COUNT);
parameter CL_M_COUNT = $clog2(M_COUNT);

parameter S_INT_THREADS = S_THREADS > S_ACCEPT ? S_ACCEPT : S_THREADS;   //S_THREADS不应该超过S_ACCEPT
parameter CL_S_INT_THREADS = $clog2(S_INT_THREADS);
parameter CL_S_ACCEPT = $clog2(S_ACCEPT);

// 默认地址，全自动分配连续Slave地址
// default address computation
function [M_COUNT*M_REGIONS*ADDR_WIDTH-1:0] calcBaseAddrs(input [31:0] dummy);
    integer i;
    reg [ADDR_WIDTH-1:0] base;
    reg [ADDR_WIDTH-1:0] width;
    reg [ADDR_WIDTH-1:0] size;
    reg [ADDR_WIDTH-1:0] mask;
    begin
        calcBaseAddrs = {M_COUNT*M_REGIONS*ADDR_WIDTH{1'b0}};
        base = 0;
        for (i = 0; i < M_COUNT*M_REGIONS; i = i + 1) begin
            width = M_ADDR_WIDTH[i*32 +: 32];
            mask = {ADDR_WIDTH{1'b1}} >> (ADDR_WIDTH - width);
            size = mask + 1;
            if (width > 0) begin
                if ((base & mask) != 0) begin
                   base = base + size - (base & mask); // align
                end
                calcBaseAddrs[i * ADDR_WIDTH +: ADDR_WIDTH] = base;
                base = base + size; // increment
            end
        end
    end
endfunction

parameter M_BASE_ADDR_INT = M_BASE_ADDR ? M_BASE_ADDR : calcBaseAddrs(0);

integer i, j;

// check configuration
initial begin
    if (S_ACCEPT < 1) begin
        $error("Error: need at least 1 accept (instance %m)");
        $finish;
    end

    if (S_THREADS < 1) begin
        $error("Error: need at least 1 thread (instance %m)");
        $finish;
    end

    if (S_THREADS > S_ACCEPT) begin
        $warning("Warning: requested thread count larger than accept count; limiting thread count to accept count (instance %m)");
    end

    if (M_REGIONS < 1) begin
        $error("Error: need at least 1 region (instance %m)");
        $finish;
    end

    for (i = 0; i < M_COUNT*M_REGIONS; i = i + 1) begin
        if (M_ADDR_WIDTH[i*32 +: 32] && (M_ADDR_WIDTH[i*32 +: 32] < 12 || M_ADDR_WIDTH[i*32 +: 32] > ADDR_WIDTH)) begin
            $error("Error: address width out of range (instance %m)");
            $finish;
        end
    end

    $display("Addressing configuration for axi_crossbar_addr instance %m");
    for (i = 0; i < M_COUNT*M_REGIONS; i = i + 1) begin
        if (M_ADDR_WIDTH[i*32 +: 32]) begin
            $display("%2d (%2d): %x / %02d -- %x-%x",
                i/M_REGIONS, i%M_REGIONS,
                M_BASE_ADDR_INT[i*ADDR_WIDTH +: ADDR_WIDTH],
                M_ADDR_WIDTH[i*32 +: 32],
                M_BASE_ADDR_INT[i*ADDR_WIDTH +: ADDR_WIDTH] & ({ADDR_WIDTH{1'b1}} << M_ADDR_WIDTH[i*32 +: 32]),
                M_BASE_ADDR_INT[i*ADDR_WIDTH +: ADDR_WIDTH] | ({ADDR_WIDTH{1'b1}} >> (ADDR_WIDTH - M_ADDR_WIDTH[i*32 +: 32]))
            );
        end
    end

    for (i = 0; i < M_COUNT*M_REGIONS; i = i + 1) begin
        if ((M_BASE_ADDR_INT[i*ADDR_WIDTH +: ADDR_WIDTH] & (2**M_ADDR_WIDTH[i*32 +: 32]-1)) != 0) begin
            $display("Region not aligned:");
            $display("%2d (%2d): %x / %2d -- %x-%x",
                i/M_REGIONS, i%M_REGIONS,
                M_BASE_ADDR_INT[i*ADDR_WIDTH +: ADDR_WIDTH],
                M_ADDR_WIDTH[i*32 +: 32],
                M_BASE_ADDR_INT[i*ADDR_WIDTH +: ADDR_WIDTH] & ({ADDR_WIDTH{1'b1}} << M_ADDR_WIDTH[i*32 +: 32]),
                M_BASE_ADDR_INT[i*ADDR_WIDTH +: ADDR_WIDTH] | ({ADDR_WIDTH{1'b1}} >> (ADDR_WIDTH - M_ADDR_WIDTH[i*32 +: 32]))
            );
            $error("Error: address range not aligned (instance %m)");
            $finish;
        end
    end

    for (i = 0; i < M_COUNT*M_REGIONS; i = i + 1) begin
        for (j = i+1; j < M_COUNT*M_REGIONS; j = j + 1) begin
            if (M_ADDR_WIDTH[i*32 +: 32] && M_ADDR_WIDTH[j*32 +: 32]) begin
                if (((M_BASE_ADDR_INT[i*ADDR_WIDTH +: ADDR_WIDTH] & ({ADDR_WIDTH{1'b1}} << M_ADDR_WIDTH[i*32 +: 32])) <= (M_BASE_ADDR_INT[j*ADDR_WIDTH +: ADDR_WIDTH] | ({ADDR_WIDTH{1'b1}} >> (ADDR_WIDTH - M_ADDR_WIDTH[j*32 +: 32]))))
                        && ((M_BASE_ADDR_INT[j*ADDR_WIDTH +: ADDR_WIDTH] & ({ADDR_WIDTH{1'b1}} << M_ADDR_WIDTH[j*32 +: 32])) <= (M_BASE_ADDR_INT[i*ADDR_WIDTH +: ADDR_WIDTH] | ({ADDR_WIDTH{1'b1}} >> (ADDR_WIDTH - M_ADDR_WIDTH[i*32 +: 32]))))) begin
                    $display("Overlapping regions:");
                    $display("%2d (%2d): %x / %2d -- %x-%x",
                        i/M_REGIONS, i%M_REGIONS,
                        M_BASE_ADDR_INT[i*ADDR_WIDTH +: ADDR_WIDTH],
                        M_ADDR_WIDTH[i*32 +: 32],
                        M_BASE_ADDR_INT[i*ADDR_WIDTH +: ADDR_WIDTH] & ({ADDR_WIDTH{1'b1}} << M_ADDR_WIDTH[i*32 +: 32]),
                        M_BASE_ADDR_INT[i*ADDR_WIDTH +: ADDR_WIDTH] | ({ADDR_WIDTH{1'b1}} >> (ADDR_WIDTH - M_ADDR_WIDTH[i*32 +: 32]))
                    );
                    $display("%2d (%2d): %x / %2d -- %x-%x",
                        j/M_REGIONS, j%M_REGIONS,
                        M_BASE_ADDR_INT[j*ADDR_WIDTH +: ADDR_WIDTH],
                        M_ADDR_WIDTH[j*32 +: 32],
                        M_BASE_ADDR_INT[j*ADDR_WIDTH +: ADDR_WIDTH] & ({ADDR_WIDTH{1'b1}} << M_ADDR_WIDTH[j*32 +: 32]),
                        M_BASE_ADDR_INT[j*ADDR_WIDTH +: ADDR_WIDTH] | ({ADDR_WIDTH{1'b1}} >> (ADDR_WIDTH - M_ADDR_WIDTH[j*32 +: 32]))
                    );
                    $error("Error: address ranges overlap (instance %m)");
                    $finish;
                end
            end
        end
    end
end

localparam [2:0]
    STATE_IDLE = 3'd0,
    STATE_DECODE = 3'd1;

reg [2:0] state_reg = STATE_IDLE, state_next;

reg s_axi_aready_reg = 0, s_axi_aready_next;

reg [3:0] m_axi_aregion_reg = 4'd0, m_axi_aregion_next;
reg [CL_M_COUNT-1:0] m_select_reg = 0, m_select_next;
reg m_axi_avalid_reg = 1'b0, m_axi_avalid_next;
reg m_decerr_reg = 1'b0, m_decerr_next;
reg m_wc_valid_reg = 1'b0, m_wc_valid_next;
reg m_rc_valid_reg = 1'b0, m_rc_valid_next;

assign s_axi_aready = s_axi_aready_reg;

assign m_axi_aregion = m_axi_aregion_reg;
assign m_select = m_select_reg;
assign m_axi_avalid = m_axi_avalid_reg;

assign m_wc_select = m_select_reg;
assign m_wc_decerr = m_decerr_reg;
assign m_wc_valid = m_wc_valid_reg;

assign m_rc_decerr = m_decerr_reg;
assign m_rc_valid = m_rc_valid_reg;

reg match;
reg trans_start;
reg trans_complete;  //对应ID完成标识

reg [$clog2(S_ACCEPT+1)-1:0] trans_count_reg = 0;
wire trans_limit = trans_count_reg >= S_ACCEPT && !trans_complete;   //当线上跑的ID数量超过参数化限制并且没有完成信号返回时，不能够再接收新的事务请求

// transfer ID thread tracking
reg [ID_WIDTH-1:0] thread_id_reg[S_INT_THREADS-1:0];
reg [CL_M_COUNT-1:0] thread_m_reg[S_INT_THREADS-1:0];    //记录当前Tag要被路由到的Master接口索引
reg [3:0] thread_region_reg[S_INT_THREADS-1:0];
reg [$clog2(S_ACCEPT+1)-1:0] thread_count_reg[S_INT_THREADS-1:0];

wire [S_INT_THREADS-1:0] thread_active;
wire [S_INT_THREADS-1:0] thread_match;
wire [S_INT_THREADS-1:0] thread_match_dest;
wire [S_INT_THREADS-1:0] thread_cpl_match;
wire [S_INT_THREADS-1:0] thread_trans_start;
wire [S_INT_THREADS-1:0] thread_trans_complete;


//创建CAM逻辑，全并行内容可寻址存储器
generate
    genvar n;

    for (n = 0; n < S_INT_THREADS; n = n + 1) begin
        initial begin
            thread_count_reg[n] <= 0;  //仿真的初始化，真实上板根据rst的值确定
        end

        assign thread_active[n] = thread_count_reg[n] != 0;  //当前count值不为0，表示当前槽位被占用
        assign thread_match[n] = thread_active[n] && thread_id_reg[n] == s_axi_aid;   //当前输入ID是否命中CAM表(并且当前ID已有事务正在传输)
        assign thread_match_dest[n] = thread_match[n] && thread_m_reg[n] == m_select_next && (M_REGIONS < 2 || thread_region_reg[n] == m_axi_aregion_next);  
        /*
        目的地址命中判定：
            当前输入 ID 命中了第 n 个槽位后，该槽位应该是被启用的槽位
            还要检查当前新请求解码出来的目标端口 m_select_next 是否和该槽位原来记录的目标端口 thread_m_reg[n] 相同
            Region为1无需做Region判定，如果系统支持多个 region，还要再检查 region 是否一致，必须Region与目标端口都一致才能进行记录，否则记录为不匹配
        */
        assign thread_cpl_match[n] = thread_active[n] && thread_id_reg[n] == s_cpl_id;  //当前返回完成的事务 ID(s_cpl_id) 是否命中第 n 个槽位
        assign thread_trans_start[n] = (thread_match[n] || (!thread_active[n] && !thread_match && !(thread_trans_start & ({S_INT_THREADS{1'b1}} >> (S_INT_THREADS-n))))) && trans_start;
        /*
            这笔新来事务最终归属到哪个thread槽位”的 one-hot 选择信号产生:
                trans_start 在地址译码成功、事务数没超限、并且 thread 条件通过时才拉高
                1) thread_match[n]
                   如果当前请求 ID 已经命中这个槽位，
                   那么这次事务继续归属到这个已有槽位，老 ID 复用老槽位

                2) (!thread_active[n] && !thread_match && !(thread_trans_start & ({S_INT_THREADS{1'b1}} >> (S_INT_THREADS-n))))
                   当前槽位空闲，且当前输入的 s_axi_aid 没有命中任何一个活动槽位
                   并且只有当编号比 n 小的槽位里，没有任何一个已经被选中时，n 才有资格被选中，所以他会优先给一个n最小的槽位
                   因为n是从0开始向上递增的，所以当n以下的槽位被选中时，n就无法被选中了

                3) !(thread_trans_start & mask)，这里不会综合为锁存器，因为它只是用了thread_trans_start的低[n-1:0]位，不引用自己这一位和最高位，综合称为一个优先级链
                   检查在当前槽位 n 前面的那些槽位里，有没有谁已经被选中了，如果有被选中的，自身就不会被选中，实现一个优先级选择的功能
        */
        assign thread_trans_complete[n] = thread_cpl_match[n] && trans_complete;  //当前槽位中的ID事务完成信号标识


        //对每个槽位进行记录
        always @(posedge clk) begin
            if (rst) begin
                thread_count_reg[n] <= 0;  //记录当前槽位进行中的事务数量
            end else begin
                if (thread_trans_start[n] && !thread_trans_complete[n]) begin  //当前槽位有新事务且无事务完成
                    thread_count_reg[n] <= thread_count_reg[n] + 1;
                end else if (!thread_trans_start[n] && thread_trans_complete[n]) begin  //当前槽位无新事务且有事务完成
                    thread_count_reg[n] <= thread_count_reg[n] - 1;
                end
            end

            if (thread_trans_start[n]) begin         //当前槽位有新事务
                thread_id_reg[n] <= s_axi_aid;         //记录事务ID
                thread_m_reg[n] <= m_select_next;        //记录事务解码路由Master端口号
                thread_region_reg[n] <= m_axi_aregion_next;  //记录事务Region区域号
            end
        end
    end
endgenerate

always @* begin
    state_next = STATE_IDLE;

    match = 1'b0;
    trans_start = 1'b0;
    trans_complete = 1'b0;

    s_axi_aready_next = 1'b0;

    m_axi_aregion_next = m_axi_aregion_reg;
    m_select_next = m_select_reg;
    m_axi_avalid_next = m_axi_avalid_reg && !m_axi_aready;    //只要下游没有握手成功，就继续valid就继续保持为1
    m_decerr_next = m_decerr_reg;
    m_wc_valid_next = m_wc_valid_reg && !m_wc_ready;
    m_rc_valid_next = m_rc_valid_reg && !m_rc_ready;  //只要握手成功就清0，也就是说m_axi_avalid_next，m_wc_valid_next，m_rc_valid_next均只拉高一拍

    case (state_reg)
        STATE_IDLE: begin
            // idle state, store values
            s_axi_aready_next = 1'b0;

            if (s_axi_avalid && !s_axi_aready) begin
                match = 1'b0;
                //在所有端口和Region下寻找匹配
                for (i = 0; i < M_COUNT; i = i + 1) begin
                    for (j = 0; j < M_REGIONS; j = j + 1) begin
                        if (M_ADDR_WIDTH[(i*M_REGIONS+j)*32 +: 32] && (!M_SECURE[i] || !s_axi_aprot[1]) && (M_CONNECT & (1 << (S+i*S_COUNT))) && (s_axi_aaddr >> M_ADDR_WIDTH[(i*M_REGIONS+j)*32 +: 32]) == (M_BASE_ADDR_INT[(i*M_REGIONS+j)*ADDR_WIDTH +: ADDR_WIDTH] >> M_ADDR_WIDTH[(i*M_REGIONS+j)*32 +: 32])) begin
                            /*
                                译码条件:
                                1)当前Region值有效(不为0)
                                2)当端口没设置为安全访问直接通过，设置为安全访问需要s_axi_aprot的第一位为0（代表安全访问）才能通过请求
                                3)判断当前输入端口S是否连接第i个输出端口
                                4)判断当前输入地址 s_axi_aaddr 是否落在第 i 个输出端口的第 j 个 region 里
                            */
                            m_select_next = i;          //命中的输出端口号
                            m_axi_aregion_next = j;     //命中的Region号
                            match = 1'b1;               //地址译码成功标识
                        end
                    end
                end

                if (match) begin      //如果译码成功    
                    // address decode successful
                    if (!trans_limit && (thread_match_dest || (!(&thread_active) && !thread_match))) begin 
                        //outstanding数没溢出并且（地址命中槽位或者当前事务没有命中任何槽位但是有空槽位可用），总结就是当前这笔新事务，在 thread 跟踪表里有合法的归宿。
                        //transaction limit not reached
                        m_axi_avalid_next = 1'b1;
                        m_decerr_next = 1'b0;     
                        m_wc_valid_next = WC_OUTPUT;     //告知 W 数据通路后续流向
                        m_rc_valid_next = 1'b0;         //事务完全合法时，m_rc_valid是不会拉高的
                        trans_start = 1'b1;            //新事务传输标识
                        state_next = STATE_DECODE;    //译码成功且事务有效
                    end 
                    else begin
                        // transaction limit reached; block in idle
                        state_next = STATE_IDLE;
                    end
                end 
                
                else begin
                    // decode error
                    m_axi_avalid_next = 1'b0;
                    m_decerr_next = 1'b1;     //解码错误标识
                    m_wc_valid_next = WC_OUTPUT; 
                    m_rc_valid_next = 1'b1;
                    state_next = STATE_DECODE;
                end
            end 
            
            else begin
                state_next = STATE_IDLE;
            end
        end
        
        STATE_DECODE: begin  //只有当数据全部被接收完毕的时候再输出ready信号完成握手
            if (!m_axi_avalid_next && (!m_wc_valid_next || !WC_OUTPUT) && !m_rc_valid_next) begin
                s_axi_aready_next = 1'b1; //译码输出端口握手完成，W通道握手完成或者本模块用于读，reply握手完成
                state_next = STATE_IDLE;
            end else begin
                state_next = STATE_DECODE;
            end
        end
    endcase

    // manage completions
    trans_complete = s_cpl_valid;
end


//数据平面
always @(posedge clk) begin
    if (rst) begin
        state_reg <= STATE_IDLE;
        s_axi_aready_reg <= 1'b0;
        m_axi_avalid_reg <= 1'b0;
        m_wc_valid_reg <= 1'b0;
        m_rc_valid_reg <= 1'b0;

        trans_count_reg <= 0;
    end else begin
        state_reg <= state_next;
        s_axi_aready_reg <= s_axi_aready_next;
        m_axi_avalid_reg <= m_axi_avalid_next;
        m_wc_valid_reg <= m_wc_valid_next;
        m_rc_valid_reg <= m_rc_valid_next;

        //记录当前线上存在的事务数
        if (trans_start && !trans_complete) begin
            trans_count_reg <= trans_count_reg + 1;    //有新事物且无完成事务，加1
        end else if (!trans_start && trans_complete) begin
            trans_count_reg <= trans_count_reg - 1;         //无新事物且有完成事务，减1
        end 
    end

    m_axi_aregion_reg <= m_axi_aregion_next;
    m_select_reg <= m_select_next;
    m_decerr_reg <= m_decerr_next;
end

endmodule

`resetall
