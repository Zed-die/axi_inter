`timescale 1ns/1ps

/*
 * Small synchronous ready/valid FIFO used by the AXI4 to AHB-Lite bridge.
 */

module axi4_to_ahb_lite_fifo #
(
    parameter WIDTH = 8,
    parameter DEPTH = 2
)
(
    input  wire             clk,
    input  wire             rst,

    input  wire [WIDTH-1:0] in_data,
    input  wire             in_valid,
    output wire             in_ready,

    output wire [WIDTH-1:0] out_data,
    output wire             out_valid,
    input  wire             out_ready
);

localparam PTR_WIDTH = (DEPTH <= 2) ? 1 : $clog2(DEPTH);
localparam CNT_WIDTH = $clog2(DEPTH+1);

localparam [PTR_WIDTH-1:0] PTR_ZERO = {PTR_WIDTH{1'b0}};
localparam [CNT_WIDTH-1:0] CNT_ZERO = {CNT_WIDTH{1'b0}};
localparam [CNT_WIDTH-1:0] CNT_DEPTH = DEPTH[CNT_WIDTH-1:0];

reg [WIDTH-1:0]     mem [0:DEPTH-1];
reg [PTR_WIDTH-1:0] wr_ptr_reg = PTR_ZERO;
reg [PTR_WIDTH-1:0] rd_ptr_reg = PTR_ZERO;
reg [CNT_WIDTH-1:0] count_reg  = CNT_ZERO;

wire push = in_valid && in_ready;   //写标识
wire pop  = out_valid && out_ready;   //读标识

assign in_ready = (count_reg < CNT_DEPTH);   //只要 FIFO 当前还没满，就允许上游继续写入
assign out_valid = (count_reg != CNT_ZERO);    //有数据就valid
assign out_data = mem[rd_ptr_reg];              //fwft，组合直接输出
 
always @(posedge clk) begin
    if (rst) begin
        wr_ptr_reg <= PTR_ZERO;
        rd_ptr_reg <= PTR_ZERO;
        count_reg <= CNT_ZERO;
    end else begin
        if (push) begin
            mem[wr_ptr_reg] <= in_data;
            if (wr_ptr_reg == DEPTH-1)
                wr_ptr_reg <= PTR_ZERO;
            else
                wr_ptr_reg <= wr_ptr_reg + 1'b1;
        end

        if (pop) begin
            if (rd_ptr_reg == DEPTH-1)
                rd_ptr_reg <= PTR_ZERO;
            else
                rd_ptr_reg <= rd_ptr_reg + 1'b1;
        end

        case ({push, pop})
            2'b10: count_reg <= count_reg + 1'b1;
            2'b01: count_reg <= count_reg - 1'b1;
            default: count_reg <= count_reg;      //记录内部计数值
        endcase
    end
end

endmodule

