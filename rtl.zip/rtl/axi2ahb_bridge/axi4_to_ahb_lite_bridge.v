`timescale 1ns/1ps

/*
 * First-stage AXI4 burst to AHB-Lite bridge.
 *
 * This version buffers AW, AR, and W channels at the AXI ingress, then executes
 * one buffered AXI burst at a time on the AHB-Lite side.  The AXI capture
 * layer, burst address generator, AHB executor, and response layer are kept
 * separate so deeper outstanding support can be added without rewriting the
 * AHB side.
 */

module axi4_to_ahb_lite_bridge #
(
    parameter AXI_ID_WIDTH = 8,
    parameter ADDR_WIDTH = 32,
    parameter DATA_WIDTH = 32,
    parameter MAX_BURST_LEN = 256,
    parameter REQ_BUFFER_DEPTH = 2,
    parameter W_BUFFER_DEPTH = MAX_BURST_LEN*2
)
(
    input  wire                         clk,
    input  wire                         rst,

    input  wire [AXI_ID_WIDTH-1:0]      s_axi_awid,
    input  wire [ADDR_WIDTH-1:0]        s_axi_awaddr,
    input  wire [7:0]                   s_axi_awlen,
    input  wire [2:0]                   s_axi_awsize,
    input  wire [1:0]                   s_axi_awburst,
    input  wire                         s_axi_awvalid,
    output wire                         s_axi_awready,

    input  wire [DATA_WIDTH-1:0]        s_axi_wdata,
    input  wire [DATA_WIDTH/8-1:0]      s_axi_wstrb,
    input  wire                         s_axi_wlast,
    input  wire                         s_axi_wvalid,
    output wire                         s_axi_wready,

    output wire [AXI_ID_WIDTH-1:0]      s_axi_bid,
    output wire [1:0]                   s_axi_bresp,
    output wire                         s_axi_bvalid,
    input  wire                         s_axi_bready,

    input  wire [AXI_ID_WIDTH-1:0]      s_axi_arid,
    input  wire [ADDR_WIDTH-1:0]        s_axi_araddr,
    input  wire [7:0]                   s_axi_arlen,
    input  wire [2:0]                   s_axi_arsize,
    input  wire [1:0]                   s_axi_arburst,
    input  wire                         s_axi_arvalid,
    output wire                         s_axi_arready,

    output wire [AXI_ID_WIDTH-1:0]      s_axi_rid,
    output wire [DATA_WIDTH-1:0]        s_axi_rdata,
    output wire [1:0]                   s_axi_rresp,
    output wire                         s_axi_rlast,
    output wire                         s_axi_rvalid,
    input  wire                         s_axi_rready,

    output wire [ADDR_WIDTH-1:0]        m_ahb_haddr,
    output wire [1:0]                   m_ahb_htrans,
    output wire                         m_ahb_hwrite,
    output wire [2:0]                   m_ahb_hsize,   //可以使用size去模拟掩码操作
    output wire [2:0]                   m_ahb_hburst,
    output wire [3:0]                   m_ahb_hprot,     //描述访问属性，目前固定为 4'b0011
    output wire                         m_ahb_hmastlock,   //描述是否锁总线，多用于原子操作，一个主机完整进行了所有操作之后才释放总线
    output wire [DATA_WIDTH-1:0]        m_ahb_hwdata,
    input  wire [DATA_WIDTH-1:0]        m_ahb_hrdata,
    input  wire                         m_ahb_hready,
    input  wire                         m_ahb_hresp
);

localparam STRB_WIDTH = DATA_WIDTH/8;
localparam SIZE_WIDTH = (STRB_WIDTH <= 1) ? 1 : $clog2(STRB_WIDTH);
localparam REQ_WIDTH = AXI_ID_WIDTH + ADDR_WIDTH + 8 + 3 + 2;
localparam W_FIFO_WIDTH = DATA_WIDTH + STRB_WIDTH + 1;

localparam AXI_RESP_OKAY   = 2'b00;
localparam AXI_RESP_SLVERR = 2'b10;
localparam AXI_RESP_DECERR = 2'b11;

localparam AXI_BURST_FIXED = 2'b00;
localparam AXI_BURST_INCR  = 2'b01;
localparam AXI_BURST_WRAP  = 2'b10;

//AHB trans类型，不需要BUSY状态，主机为桥接器全权控制
localparam HTRANS_IDLE     = 2'b00;
localparam HTRANS_NONSEQ   = 2'b10;
localparam HTRANS_SEQ      = 2'b11;

//AHB burst类型
localparam HBURST_SINGLE   = 3'b000;
localparam HBURST_INCR     = 3'b001;
localparam HBURST_WRAP4    = 3'b010;
localparam HBURST_INCR4    = 3'b011;
localparam HBURST_WRAP8    = 3'b100;
localparam HBURST_INCR8    = 3'b101;
localparam HBURST_WRAP16   = 3'b110;
localparam HBURST_INCR16   = 3'b111;

localparam ST_IDLE         = 4'd0; // 空闲状态，从 AW/AR FIFO 中取下一笔请求
localparam ST_WR_RECV      = 4'd1; // 正常写请求，接收并缓存完整 AXI W burst
localparam ST_WR_DRAIN     = 4'd2; // 写地址非法时丢弃对应 W burst，等待 WLAST 后返回错误
localparam ST_WR_AHB       = 4'd3; // full-width/full-strobe 写请求，向 AHB-Lite 发起 burst 写
localparam ST_WR_PART_ADDR = 4'd4; // partial write 拆分后的 AHB byte 写地址 phase
localparam ST_WR_PART_DATA = 4'd5; // partial write 拆分后的 AHB byte 写数据/响应 phase
localparam ST_WR_RESP      = 4'd6; // 返回 AXI B 通道写响应
localparam ST_RD_AHB       = 4'd7; // 向 AHB-Lite 发起读 burst 并缓存 HRDATA/HRESP
localparam ST_RD_RESP      = 4'd8; // 将缓存的读数据通过 AXI R 通道逐拍返回
localparam ST_RD_DECERR    = 4'd9; // 读地址非法时不访问 AHB，直接返回 DECERR R burst

reg [3:0] state_reg = ST_IDLE;

reg [AXI_ID_WIDTH-1:0]  active_id_reg = {AXI_ID_WIDTH{1'b0}};
reg [ADDR_WIDTH-1:0]    active_addr_reg = {ADDR_WIDTH{1'b0}};
reg [7:0]               active_len_reg = 8'd0;
reg [2:0]               active_size_reg = 3'd0;
reg [1:0]               active_burst_reg = 2'd0;

reg [DATA_WIDTH-1:0]    wdata_buf [0:MAX_BURST_LEN-1];
reg [STRB_WIDTH-1:0]    wstrb_buf [0:MAX_BURST_LEN-1];
reg [DATA_WIDTH-1:0]    rdata_buf [0:MAX_BURST_LEN-1];
reg [1:0]               rresp_buf [0:MAX_BURST_LEN-1];

reg [8:0]               recv_count_reg = 9'd0;
reg                     all_full_strobe_reg = 1'b1;

reg [8:0]               ahb_addr_index_reg = 9'd0;
reg [8:0]               ahb_data_index_reg = 9'd0;
reg                     ahb_data_phase_valid_reg = 1'b0;
reg                     ahb_error_reg = 1'b0;

reg [8:0]               part_beat_reg = 9'd0;
reg [2:0]               part_lane_reg = 3'd0;

reg [8:0]               resp_index_reg = 9'd0;
reg [1:0]               bresp_reg = AXI_RESP_OKAY;

wire [REQ_WIDTH-1:0]    aw_fifo_in_data;
wire [REQ_WIDTH-1:0]    aw_fifo_out_data;
wire                    aw_fifo_valid;
wire                    aw_fifo_ready;
wire                    aw_fifo_pop;
wire [AXI_ID_WIDTH-1:0] aw_fifo_id;
wire [ADDR_WIDTH-1:0]   aw_fifo_addr;
wire [7:0]              aw_fifo_len;
wire [2:0]              aw_fifo_size;
wire [1:0]              aw_fifo_burst;

wire [REQ_WIDTH-1:0]    ar_fifo_in_data;
wire [REQ_WIDTH-1:0]    ar_fifo_out_data;
wire                    ar_fifo_valid;
wire                    ar_fifo_ready;
wire                    ar_fifo_pop;
wire [AXI_ID_WIDTH-1:0] ar_fifo_id;
wire [ADDR_WIDTH-1:0]   ar_fifo_addr;
wire [7:0]              ar_fifo_len;
wire [2:0]              ar_fifo_size;
wire [1:0]              ar_fifo_burst;

wire [W_FIFO_WIDTH-1:0] w_fifo_in_data;
wire [W_FIFO_WIDTH-1:0] w_fifo_out_data;
wire                    w_fifo_valid;
wire                    w_fifo_ready;
wire                    w_fifo_pop;
wire [DATA_WIDTH-1:0]   w_fifo_data;
wire [STRB_WIDTH-1:0]   w_fifo_strb;
wire                    w_fifo_last;


//存储 AW 信号
assign aw_fifo_in_data = {s_axi_awid, s_axi_awaddr, s_axi_awlen, s_axi_awsize, s_axi_awburst};   //汇总AW信息
assign {aw_fifo_id, aw_fifo_addr, aw_fifo_len, aw_fifo_size, aw_fifo_burst} = aw_fifo_out_data;   //分流读出的fifo信息
assign aw_fifo_pop = (state_reg == ST_IDLE) && aw_fifo_valid;    //

//存储 AR 信号
assign ar_fifo_in_data = {s_axi_arid, s_axi_araddr, s_axi_arlen, s_axi_arsize, s_axi_arburst};
assign {ar_fifo_id, ar_fifo_addr, ar_fifo_len, ar_fifo_size, ar_fifo_burst} = ar_fifo_out_data;
assign ar_fifo_pop = (state_reg == ST_IDLE) && !aw_fifo_valid && ar_fifo_valid;   //优先处理AXI写突发，写突发无效时才能进行数据读出

//存储 W 信号
assign w_fifo_in_data = {s_axi_wdata, s_axi_wstrb, s_axi_wlast};
assign {w_fifo_data, w_fifo_strb, w_fifo_last} = w_fifo_out_data;
assign w_fifo_pop = ((state_reg == ST_WR_RECV) || (state_reg == ST_WR_DRAIN)) && w_fifo_valid;


//用于缓存AW信息的握手式fifo
axi4_to_ahb_lite_fifo #(
    .WIDTH(REQ_WIDTH),
    .DEPTH(REQ_BUFFER_DEPTH)
) aw_req_fifo (
    .clk(clk),
    .rst(rst),
    .in_data(aw_fifo_in_data),
    .in_valid(s_axi_awvalid),  
    .in_ready(aw_fifo_ready),
    .out_data(aw_fifo_out_data),
    .out_valid(aw_fifo_valid),
    .out_ready(aw_fifo_pop)
);

//用于缓存AR信息的握手式fifo
axi4_to_ahb_lite_fifo #(
    .WIDTH(REQ_WIDTH),
    .DEPTH(REQ_BUFFER_DEPTH)
) ar_req_fifo (
    .clk(clk),
    .rst(rst),
    .in_data(ar_fifo_in_data),
    .in_valid(s_axi_arvalid),
    .in_ready(ar_fifo_ready),
    .out_data(ar_fifo_out_data),
    .out_valid(ar_fifo_valid),
    .out_ready(ar_fifo_pop)
);

//用于缓存W信息的握手式fifo
axi4_to_ahb_lite_fifo #(
    .WIDTH(W_FIFO_WIDTH),
    .DEPTH(W_BUFFER_DEPTH)
) w_data_fifo (
    .clk(clk),
    .rst(rst),
    .in_data(w_fifo_in_data),
    .in_valid(s_axi_wvalid),
    .in_ready(w_fifo_ready),
    .out_data(w_fifo_out_data),
    .out_valid(w_fifo_valid),
    .out_ready(w_fifo_pop)
);

wire [8:0] active_beats = {1'b0, active_len_reg} + 9'd1;
wire [8:0] ahb_current_index = ahb_addr_index_reg;
wire       ahb_addr_valid = (state_reg == ST_WR_AHB || state_reg == ST_RD_AHB) && (ahb_addr_index_reg < active_beats);

wire [ADDR_WIDTH-1:0] ahb_burst_addr = calc_burst_addr(active_addr_reg, ahb_current_index[7:0], active_size_reg, active_burst_reg, active_len_reg);

wire [ADDR_WIDTH-1:0] part_base_addr = calc_burst_addr(active_addr_reg, part_beat_reg[7:0], active_size_reg, active_burst_reg, active_len_reg);

wire [2:0] active_ahb_burst = map_ahb_burst(active_burst_reg, active_len_reg);
wire       active_full_width = (active_size_reg == SIZE_WIDTH[2:0]);

wire [STRB_WIDTH-1:0] first_part_strobe = (recv_count_reg == 9'd0) ? w_fifo_strb : wstrb_buf[0];
wire [2:0] next_part_lane = next_strb_lane(wstrb_buf[part_beat_reg], part_lane_reg + 3'd1);

assign s_axi_awready = aw_fifo_ready;
assign s_axi_arready = ar_fifo_ready;
assign s_axi_wready  = w_fifo_ready;

assign s_axi_bid    = active_id_reg;
assign s_axi_bresp  = bresp_reg;
assign s_axi_bvalid = (state_reg == ST_WR_RESP);

assign s_axi_rid    = active_id_reg;
assign s_axi_rdata  = (state_reg == ST_RD_DECERR) ? {DATA_WIDTH{1'b0}} : rdata_buf[resp_index_reg];
assign s_axi_rresp  = (state_reg == ST_RD_DECERR) ? AXI_RESP_DECERR : rresp_buf[resp_index_reg];
assign s_axi_rlast  = (resp_index_reg == {1'b0, active_len_reg});
assign s_axi_rvalid = (state_reg == ST_RD_RESP) || (state_reg == ST_RD_DECERR);

assign m_ahb_haddr = (state_reg == ST_WR_PART_ADDR || state_reg == ST_WR_PART_DATA)? (part_base_addr + {{(ADDR_WIDTH-3){1'b0}}, part_lane_reg}): ahb_burst_addr;

assign m_ahb_htrans = ahb_addr_valid ?((ahb_addr_index_reg == 0) ? HTRANS_NONSEQ : HTRANS_SEQ): ((state_reg == ST_WR_PART_ADDR) ? HTRANS_NONSEQ : HTRANS_IDLE);

assign m_ahb_hwrite = (state_reg == ST_WR_AHB) || (state_reg == ST_WR_PART_ADDR) || (state_reg == ST_WR_PART_DATA);

assign m_ahb_hsize = (state_reg == ST_WR_PART_ADDR || state_reg == ST_WR_PART_DATA) ? 3'd0 : active_size_reg;

assign m_ahb_hburst = (state_reg == ST_WR_PART_ADDR || state_reg == ST_WR_PART_DATA) ? HBURST_SINGLE :
                      ((ahb_addr_valid || ahb_data_phase_valid_reg) ? active_ahb_burst : HBURST_SINGLE);

assign m_ahb_hprot = 4'b0011;
assign m_ahb_hmastlock = 1'b0;   //消除总线锁定信号

assign m_ahb_hwdata = (state_reg == ST_WR_PART_ADDR || state_reg == ST_WR_PART_DATA) ? wdata_buf[part_beat_reg] :
                      ((state_reg == ST_WR_AHB && ahb_data_phase_valid_reg) ? wdata_buf[ahb_data_index_reg] : {DATA_WIDTH{1'b0}});


// 计算 AXI FIXED/INCR/WRAP burst 在指定 beat 上对应的 AHB 访问地址
function [ADDR_WIDTH-1:0] calc_burst_addr;
    input [ADDR_WIDTH-1:0] base_addr;
    input [7:0]            beat;
    input [2:0]            size;
    input [1:0]            burst;
    input [7:0]            len;

    reg [ADDR_WIDTH-1:0] beat_bytes;
    reg [ADDR_WIDTH-1:0] byte_offset;
    reg [ADDR_WIDTH-1:0] linear_addr;
    reg [ADDR_WIDTH-1:0] wrap_bytes;
    reg [ADDR_WIDTH-1:0] wrap_mask;
    reg [ADDR_WIDTH-1:0] wrap_base;

    begin
        beat_bytes = {{(ADDR_WIDTH-1){1'b0}}, 1'b1} << size;   //使用ADDR_WIDTH来衡量单个beat字节数
        byte_offset = beat_bytes * beat;
        linear_addr = base_addr + byte_offset;
        wrap_bytes = beat_bytes * ({{(ADDR_WIDTH-8){1'b0}}, len} + 1'b1);   //计算WRAP模式下的总字节数
        wrap_mask = wrap_bytes - 1'b1;
        wrap_base = base_addr & ~wrap_mask;  //计算WRAP burst下的lower address

        if (burst == AXI_BURST_FIXED) begin
            calc_burst_addr = base_addr;   //fixed模式下的固定不变
        end else if (burst == AXI_BURST_WRAP) begin
            calc_burst_addr = wrap_base | (linear_addr & wrap_mask);  //linear_addr & wrap_mask 等价于 linear_addr % wrap_bytes,得到的值一定
        end else begin
            calc_burst_addr = linear_addr;    //INCR模式下线性增长
        end
    end
endfunction

// 将 AXI burst 类型和长度映射为 AHB-Lite HBURST 编码
function [2:0] map_ahb_burst;
    input [1:0] burst;
    input [7:0] len;
    begin
        if (len == 8'd0) begin
            map_ahb_burst = HBURST_SINGLE;
        end else if (burst == AXI_BURST_WRAP) begin
            if (len == 8'd3)
                map_ahb_burst = HBURST_WRAP4;
            else if (len == 8'd7)
                map_ahb_burst = HBURST_WRAP8;
            else
                map_ahb_burst = HBURST_WRAP16;

        end else if (burst == AXI_BURST_INCR) begin
            if (len == 8'd3)
                map_ahb_burst = HBURST_INCR4;
            else if (len == 8'd7)
                map_ahb_burst = HBURST_INCR8;
            else if (len == 8'd15)
                map_ahb_burst = HBURST_INCR16;
            else
                map_ahb_burst = HBURST_INCR;   //大于固定长度的突发长度使用固定增长模式的突发

        end else begin
            map_ahb_burst = HBURST_SINGLE;
        end
    end
endfunction

// 检查 AXI 请求是否合法，包括 burst 类型、size、WRAP 长度和 4KB 边界
function invalid_request;
    input [ADDR_WIDTH-1:0] addr;
    input [7:0]            len;
    input [2:0]            size;
    input [1:0]            burst;
    reg [ADDR_WIDTH-1:0] beat_bytes;
    reg [ADDR_WIDTH-1:0] total_bytes;
    reg [ADDR_WIDTH-1:0] last_addr;
    reg wrap_len_ok;
    begin
        beat_bytes = {{(ADDR_WIDTH-1){1'b0}}, 1'b1} << size;
        total_bytes = beat_bytes * ({{(ADDR_WIDTH-8){1'b0}}, len} + 1'b1);
        last_addr = addr + total_bytes - 1'b1;   //计算最后一拍突发的地址
        wrap_len_ok = (len == 8'd3) || (len == 8'd7) || (len == 8'd15);  //AXI支持2，4，8，16的WRAP burst，但是AHB不支持burst2

        invalid_request = 1'b0;
        // AXI burst 类型 2'b11 为保留编码，桥接器不能转换为合法 AHB 访问
        if (burst == 2'b11)
            invalid_request = 1'b1;
        // AXI 单拍传输字节数超过 AHB-Lite 数据总线宽度，无法用一次 AHB beat 承载
        if (size > SIZE_WIDTH[2:0])
            invalid_request = 1'b1;
        // WRAP burst 只能映射到 AHB WRAP4/WRAP8/WRAP16，因此只接受 4/8/16 拍
        if (burst == AXI_BURST_WRAP && !wrap_len_ok)
            invalid_request = 1'b1;
        // AXI burst 不允许跨越 4KB 边界，首地址和末地址必须位于同一个 4KB 页内
        if (addr[ADDR_WIDTH-1:12] != last_addr[ADDR_WIDTH-1:12])  //判断首拍beat的地址与最后一个beat的地址的高位是否相同
            invalid_request = 1'b1;
    end
endfunction

// 从指定 byte lane 开始查找下一个置位的 WSTRB lane，用于 partial write 拆分
function [2:0] next_strb_lane;
    input [STRB_WIDTH-1:0] strb;
    input [2:0] start_lane;
    integer idx;
    reg found;
    begin
        next_strb_lane = STRB_WIDTH[2:0];
        found = 1'b0;
        for (idx = 0; idx < STRB_WIDTH; idx = idx + 1) begin
            if (!found && idx[2:0] >= start_lane && strb[idx]) begin
                next_strb_lane = idx[2:0];
                found = 1'b1;
            end
        end
    end
endfunction

integer init_idx;

always @(posedge clk) begin
    if (rst) begin
        state_reg                <= ST_IDLE;
        active_id_reg            <= {AXI_ID_WIDTH{1'b0}};
        active_addr_reg          <= {ADDR_WIDTH{1'b0}};
        active_len_reg           <= 8'd0;
        active_size_reg          <= 3'd0;
        active_burst_reg         <= AXI_BURST_INCR;
        recv_count_reg           <= 9'd0;
        all_full_strobe_reg      <= 1'b1;
        ahb_addr_index_reg       <= 9'd0;
        ahb_data_index_reg       <= 9'd0;
        ahb_data_phase_valid_reg <= 1'b0;
        ahb_error_reg            <= 1'b0;
        part_beat_reg            <= 9'd0;
        part_lane_reg            <= 3'd0;
        resp_index_reg           <= 9'd0;
        bresp_reg                <= AXI_RESP_OKAY;
        for (init_idx = 0; init_idx < MAX_BURST_LEN; init_idx = init_idx + 1) begin
            wdata_buf[init_idx] <= {DATA_WIDTH{1'b0}};
            wstrb_buf[init_idx] <= {STRB_WIDTH{1'b0}};
            rdata_buf[init_idx] <= {DATA_WIDTH{1'b0}};
            rresp_buf[init_idx] <= AXI_RESP_OKAY;
        end
    end else begin
        case (state_reg)
            ST_IDLE: begin
                ahb_addr_index_reg <= 9'd0;
                ahb_data_index_reg <= 9'd0;
                ahb_data_phase_valid_reg <= 1'b0;
                ahb_error_reg <= 1'b0;
                recv_count_reg <= 9'd0;
                all_full_strobe_reg <= 1'b1;
                resp_index_reg <= 9'd0;
                bresp_reg <= AXI_RESP_OKAY;

                if (aw_fifo_valid) begin
                    active_id_reg <= aw_fifo_id;
                    active_addr_reg <= aw_fifo_addr;
                    active_len_reg <= aw_fifo_len;
                    active_size_reg <= aw_fifo_size;
                    active_burst_reg <= aw_fifo_burst;
                    if (invalid_request(aw_fifo_addr, aw_fifo_len, aw_fifo_size, aw_fifo_burst)) begin
                        bresp_reg <= AXI_RESP_DECERR;
                        state_reg <= ST_WR_DRAIN;
                    end else begin
                        state_reg <= ST_WR_RECV;
                    end
                end else if (ar_fifo_valid) begin
                    active_id_reg <= ar_fifo_id;
                    active_addr_reg <= ar_fifo_addr;
                    active_len_reg <= ar_fifo_len;
                    active_size_reg <= ar_fifo_size;
                    active_burst_reg <= ar_fifo_burst;
                    if (invalid_request(ar_fifo_addr, ar_fifo_len, ar_fifo_size, ar_fifo_burst)) begin
                        resp_index_reg <= 9'd0;
                        state_reg <= ST_RD_DECERR;
                    end else begin
                        ahb_addr_index_reg <= 9'd0;
                        ahb_data_index_reg <= 9'd0;
                        ahb_data_phase_valid_reg <= 1'b0;
                        state_reg <= ST_RD_AHB;
                    end
                end
            end

            ST_WR_DRAIN: begin
                if (w_fifo_valid && (w_fifo_last || recv_count_reg == {1'b0, active_len_reg})) begin
                    state_reg <= ST_WR_RESP;
                end
                if (w_fifo_valid)
                    recv_count_reg <= recv_count_reg + 1'b1;
            end

            ST_WR_RECV: begin
                if (w_fifo_valid) begin
                    wdata_buf[recv_count_reg] <= w_fifo_data;
                    wstrb_buf[recv_count_reg] <= w_fifo_strb;
                    all_full_strobe_reg <= all_full_strobe_reg && (w_fifo_strb == {STRB_WIDTH{1'b1}});

                    if (w_fifo_last || recv_count_reg == {1'b0, active_len_reg}) begin
                        if (w_fifo_last != (recv_count_reg == {1'b0, active_len_reg})) begin
                            bresp_reg <= AXI_RESP_DECERR;
                            state_reg <= ST_WR_RESP;
                        end else if ((all_full_strobe_reg && (w_fifo_strb == {STRB_WIDTH{1'b1}})) &&
                                     (active_size_reg == SIZE_WIDTH[2:0])) begin
                            ahb_addr_index_reg <= 9'd0;
                            ahb_data_index_reg <= 9'd0;
                            ahb_data_phase_valid_reg <= 1'b0;
                            ahb_error_reg <= 1'b0;
                            state_reg <= ST_WR_AHB;
                        end else begin
                            part_beat_reg <= 9'd0;
                            part_lane_reg <= next_strb_lane(first_part_strobe, 3'd0);
                            ahb_error_reg <= 1'b0;
                            state_reg <= ST_WR_PART_ADDR;
                        end
                    end
                    recv_count_reg <= recv_count_reg + 1'b1;
                end
            end

            ST_WR_AHB: begin
                if (m_ahb_hready) begin
                    if (ahb_data_phase_valid_reg) begin
                        ahb_error_reg <= ahb_error_reg | m_ahb_hresp;
                        if (ahb_data_index_reg == {1'b0, active_len_reg} && !ahb_addr_valid) begin
                            bresp_reg <= (ahb_error_reg | m_ahb_hresp) ? AXI_RESP_SLVERR : AXI_RESP_OKAY;
                            ahb_data_phase_valid_reg <= 1'b0;
                            state_reg <= ST_WR_RESP;
                        end else begin
                            ahb_data_index_reg <= ahb_data_index_reg + 1'b1;
                        end
                    end

                    if (ahb_addr_valid) begin
                        ahb_addr_index_reg <= ahb_addr_index_reg + 1'b1;
                        ahb_data_phase_valid_reg <= 1'b1;
                    end
                end
            end

            ST_WR_PART_ADDR: begin
                if (part_lane_reg >= STRB_WIDTH[2:0]) begin
                    if (part_beat_reg == {1'b0, active_len_reg}) begin
                        bresp_reg <= ahb_error_reg ? AXI_RESP_SLVERR : AXI_RESP_OKAY;
                        state_reg <= ST_WR_RESP;
                    end else begin
                        part_beat_reg <= part_beat_reg + 1'b1;
                        part_lane_reg <= next_strb_lane(wstrb_buf[part_beat_reg + 1'b1], 3'd0);
                    end
                end else if (m_ahb_hready) begin
                    state_reg <= ST_WR_PART_DATA;
                end
            end

            ST_WR_PART_DATA: begin
                if (m_ahb_hready) begin
                    ahb_error_reg <= ahb_error_reg | m_ahb_hresp;
                    if (next_part_lane < STRB_WIDTH[2:0]) begin
                        part_lane_reg <= next_part_lane;
                        state_reg <= ST_WR_PART_ADDR;
                    end else if (part_beat_reg == {1'b0, active_len_reg}) begin
                        bresp_reg <= (ahb_error_reg | m_ahb_hresp) ? AXI_RESP_SLVERR : AXI_RESP_OKAY;
                        state_reg <= ST_WR_RESP;
                    end else begin
                        part_beat_reg <= part_beat_reg + 1'b1;
                        part_lane_reg <= next_strb_lane(wstrb_buf[part_beat_reg + 1'b1], 3'd0);
                        state_reg <= ST_WR_PART_ADDR;
                    end
                end
            end

            ST_WR_RESP: begin
                if (s_axi_bvalid && s_axi_bready)
                    state_reg <= ST_IDLE;
            end

            ST_RD_AHB: begin
                if (m_ahb_hready) begin
                    if (ahb_data_phase_valid_reg) begin
                        rdata_buf[ahb_data_index_reg] <= m_ahb_hrdata;
                        rresp_buf[ahb_data_index_reg] <= m_ahb_hresp ? AXI_RESP_SLVERR : AXI_RESP_OKAY;
                        if (ahb_data_index_reg == {1'b0, active_len_reg} && !ahb_addr_valid) begin
                            resp_index_reg <= 9'd0;
                            ahb_data_phase_valid_reg <= 1'b0;
                            state_reg <= ST_RD_RESP;
                        end else begin
                            ahb_data_index_reg <= ahb_data_index_reg + 1'b1;
                        end
                    end

                    if (ahb_addr_valid) begin
                        ahb_addr_index_reg <= ahb_addr_index_reg + 1'b1;
                        ahb_data_phase_valid_reg <= 1'b1;
                    end
                end
            end

            ST_RD_RESP: begin
                if (s_axi_rvalid && s_axi_rready) begin
                    if (resp_index_reg == {1'b0, active_len_reg})
                        state_reg <= ST_IDLE;
                    else
                        resp_index_reg <= resp_index_reg + 1'b1;
                end
            end

            ST_RD_DECERR: begin
                if (s_axi_rvalid && s_axi_rready) begin
                    if (resp_index_reg == {1'b0, active_len_reg})
                        state_reg <= ST_IDLE;
                    else
                        resp_index_reg <= resp_index_reg + 1'b1;
                end
            end

            default: begin
                state_reg <= ST_IDLE;
            end
        endcase
    end
end

endmodule
