# AXI Crossbar Write Decode Error Bookkeeping Design

**Date:** 2026-04-20

## Goal

Add a focused simulation that reproduces the current decode-error bookkeeping bug through the full `axi_crossbar_wr + axi_crossbar_addr` write return path.

## Scope

This slice adds:

- one standalone SystemVerilog testbench under `sim/`
- one directed scenario that shows a decode-error write can underflow `trans_count_reg`
- one directed scenario that shows a decode-error write with the same ID can prematurely clear the active thread for a normal in-flight write
- self-checks that observe both external AXI behavior and the internal bookkeeping state through hierarchical references

This slice does not add:

- any RTL fixes
- any read-path coverage
- any randomized stimulus or reusable verification framework

## Test Topology

The testbench instantiates a minimal `axi_crossbar_wr` with `S_COUNT=1` and `M_COUNT=1`.

This keeps the path complete while removing unrelated arbitration noise:

- `AW` requests still enter `axi_crossbar_addr`
- decode errors still flow through `m_rc_valid`
- local DECERR responses still become `decerr_m_axi_bvalid_reg`
- the local DECERR source still competes in the `B` response arbiter and feeds back into `s_cpl_valid`

Because the DUT is small, the testbench can directly inspect:

- `dut.s_ifaces[0].addr_inst.trans_count_reg`
- `dut.s_ifaces[0].addr_inst.thread_count_reg[0]`
- `dut.s_ifaces[0].addr_inst.thread_id_reg[0]`

## Scenarios

### Scenario 1: Isolated Decode Error Underflow

Drive one write transaction to an unmapped address and complete its `W` beat so the local DECERR response is generated and consumed.

Expected external behavior:

- no downstream `AW` or `W` transfer occurs
- upstream receives a local `B` response with `BRESP=DECERR`

Expected internal buggy behavior:

- `trans_start` never happens for the decode-error request
- `s_cpl_valid` still fires on the local DECERR completion
- `trans_count_reg` decrements from zero and wraps

### Scenario 2: Same-ID Thread Premature Release

First send one valid write with `ID=3` and hold the downstream `B` response so its thread remains active. Then send one decode-error write with the same `ID=3`, complete its `W` beat, and consume the local DECERR response before the normal write completes.

Expected external behavior:

- the first write is accepted downstream and remains outstanding
- the second write returns local `DECERR`

Expected internal buggy behavior:

- the active thread for `ID=3` is matched only by `s_cpl_id`
- the decode-error completion decrements the live thread count
- `thread_count_reg[0]` drops to zero even though the normal write has not completed yet

## Verification

The testbench must:

- drive all stimulus on `posedge clk`
- fail with `$fatal` if either buggy condition does not reproduce
- print clear PASS messages once both buggy states are observed

Target compile and run commands:

```powershell
iverilog -g2012 -o sim\\tb_axi_crossbar_wr_decode_err_count.vvp axi_crossbar\\priority_encoder.v axi_crossbar\\arbiter.v axi_crossbar\\axi_register_wr.v axi_crossbar\\axi_crossbar_addr.v axi_crossbar\\axi_crossbar_wr.v sim\\tb_axi_crossbar_wr_decode_err_count.sv
vvp sim\\tb_axi_crossbar_wr_decode_err_count.vvp
```
