# AXI Interconnect APB Config Design

**Date:** 2026-04-14

## Goal

Add an APB configuration and status plane to `axi_interconnect_core` so software can control basic runtime policy and inspect faults and traffic counters without changing the existing crossbar structure.

## Scope

This slice adds:

- an APB slave block for configuration and status
- global interconnect enable control
- per-master runtime policy: `enable`, `allow_reads`, `allow_writes`
- per-target runtime policy: `enable`
- fault capture registers for the most recent locally detected fault
- per-master request and local-DECERR counters

This slice does not add:

- runtime address remapping
- runtime outstanding-depth reconfiguration inside `axi_crossbar`
- APB-driven arbitration/QoS rewrites
- read interleaving
- asynchronous APB clock crossing

## Runtime Policy Model

The APB block controls only policy that can be enforced at the wrappers already surrounding `axi_crossbar`.

- ingress write policy is enforced in `axi_ic_write_guard`
- ingress read policy is enforced in `axi_ic_read_guard`
- egress target enable policy is enforced in `axi_ic_egress`

This keeps the `axi_crossbar` itself unchanged.

## APB Clocking

The APB interface shares `clk` and `rst` with `axi_interconnect_core` in this slice. There is no separate APB clock domain.

## Register Map

The implementation uses a compact 4 KB APB window with separate write-only control and read-only status regions. Unmapped addresses or accesses with the wrong direction return `PSLVERR`.

- `0x0000` `CORE_CTRL_W` (WO)
  - bit 0: `core_enable`
- `0x0004` `FAULT_CLEAR_W` (WO)
  - bit 0: write `1` to clear sticky fault pending
- `0x0020 + n*0x4` `MASTERn_CTRL_W` (WO)
  - bit 0: `enable`
  - bit 1: `allow_reads`
  - bit 2: `allow_writes`
- `0x0040 + m*0x4` `TARGETm_CTRL_W` (WO)
  - bit 0: `enable`
- `0x0100` `VERSION_R` (RO)
- `0x0104` `CORE_STATUS_R` (RO)
  - bit 0: `core_enable`
- `0x0108` `FAULT_STATUS_R` (RO)
  - bit 0: sticky fault pending
- `0x010C` `LAST_FAULT_ADDR_R` (RO)
- `0x0110` `LAST_FAULT_INFO_R` (RO)
  - bits `7:0`: fault code
  - bits `15:8`: source port
  - bits `23:16`: target port
  - bits `31:24`: request ID low byte
- `0x0120 + n*0x4` `MASTERn_STATUS_R` (RO)
  - bit 0: `enable`
  - bit 1: `allow_reads`
  - bit 2: `allow_writes`
- `0x0140 + m*0x4` `TARGETm_STATUS_R` (RO)
  - bit 0: `enable`
  - bit 1: `is_bridge` (RO mirror of `M_TARGET_TYPE`)
- `0x0160 + n*0x4` `MASTERn_WRITE_REQ_COUNT_R` (RO)
- `0x0180 + n*0x4` `MASTERn_READ_REQ_COUNT_R` (RO)
- `0x01A0 + n*0x4` `MASTERn_WRITE_DECERR_COUNT_R` (RO)
- `0x01C0 + n*0x4` `MASTERn_READ_DECERR_COUNT_R` (RO)

## Fault Sources

The APB block records the latest fault from:

- invalid write bursts detected at ingress
- disabled write masters detected at ingress
- invalid read bursts detected at ingress
- disabled read masters detected at ingress
- disabled targets detected at egress

Fault capture is last-writer-wins and sticky until cleared.

## Fault Codes

- `8'h01`: invalid write burst
- `8'h02`: write disabled by policy
- `8'h03`: invalid read burst
- `8'h04`: read disabled by policy
- `8'h05`: target write disabled
- `8'h06`: target read disabled

## Egress Disable Behavior

When a target is disabled:

- writes are accepted at the egress boundary, `W` beats are consumed locally, and `B` returns `DECERR`
- reads are accepted at the egress boundary and return a single-beat `DECERR`

This feature is intended for debug, isolation, and bring-up. Runtime target-disable changes are safest when software applies them while traffic is quiesced.

## Verification

This slice must include:

- unit test for the APB config block register behavior
- integration test proving APB can disable a master read/write path
- integration test proving APB can disable a target path at egress
- regression of the current guard, egress bridge, direct smoke, read out-of-order, and bridge smoke tests
