# AXI Interconnect Core-First Design

**Date:** 2026-04-14

## Goal

Build a reusable AXI interconnect core around the existing `axi_crossbar` fabric. Phase 1 focuses on the interconnect core itself and defers `AXI2AHB bridge` integration and `APB config` to later phases.

## Phase 1 Scope

Phase 1 must provide:

- Multiple outstanding transactions
- `INCR` burst support
- `WRAP` burst support
- Different-ID out-of-order completion
- Same-ID in-order behavior
- 4 KB boundary handling
- Error responses for unsupported or illegal bursts

Phase 1 does not yet provide:

- Read interleaving
- Full APB configuration plane
- Final AXI-to-AHB egress integration

## Architecture

Phase 1 keeps `axi_crossbar` as the switching fabric and wraps it with small adapter modules:

- `axi_ic_write_guard`
- `axi_ic_read_guard`
- `axi_ic_egress`
- `axi_ic_burst_guard`
- `axi_interconnect_core`

The write and read guards sit on each slave-side ingress port. They validate bursts before traffic enters `axi_crossbar`. Valid transactions pass through unchanged. Invalid transactions are terminated locally with `DECERR`.

The egress wrapper is a phase-1 passthrough shell that reserves a clean insertion point for target capability checks, `AXI2AHB` bridge attachment, and width or clock adaptation.

## Responsibilities

### `axi_ic_burst_guard`

Pure combinational helper for:

- burst legality checks
- beat count interpretation
- wrap length legality checks
- address span calculation
- 4 KB boundary check

### `axi_ic_write_guard`

Per-ingress write-side protection:

- validate `AW` burst before entering fabric
- pass valid `AW/W/B` traffic through
- swallow `W` beats for invalid bursts until `WLAST`
- return local `B` response with `DECERR`

### `axi_ic_read_guard`

Per-ingress read-side protection:

- validate `AR` burst before entering fabric
- pass valid `AR/R` traffic through
- generate local `R` burst with `DECERR` for invalid requests

### `axi_ic_egress`

Per-egress phase-1 wrapper:

- transparent AXI passthrough
- parameter hooks for future capability filtering
- future insertion point for `AXI2AHB` and protocol adapters

### `axi_interconnect_core`

Top-level wrapper:

- instantiate ingress write and read guards for each slave-side port
- instantiate `axi_crossbar`
- instantiate egress passthrough wrapper for each master-side port
- preserve existing `axi_crossbar` outstanding and response routing behavior

## Ordering and Outstanding Model

Outstanding and different-ID out-of-order behavior continue to come from `axi_crossbar`.

Phase 1 does not add a second transaction scheduler on top of the fabric. Instead it preserves the existing fabric behavior and ensures the new guard logic does not serialize valid traffic.

Invalid transactions may temporarily occupy their local ingress guard until their error response completes. This affects only the invalid path and does not reduce valid-path concurrency through the fabric.

## 4 KB Boundary Policy

Phase 1 policy is strict reject:

- valid `FIXED`, `INCR`, and legal `WRAP` bursts that remain within one 4 KB region are accepted
- bursts that cross a 4 KB boundary return `DECERR`
- malformed `WRAP` bursts return `DECERR`

Phase 1 does not split bursts across boundaries.

## Wrap Policy

Phase 1 supports legal AXI `WRAP` bursts and forwards them through the fabric unchanged. Downstream target adaptation is deferred to a later phase.

## Future Phases

### Phase 2

- attach `axi2ahb_bridge_top` behind selected egress ports
- add egress capability policy

### Phase 3

- add APB configuration registers
- expose status and control for target capability and error policy

### Phase 4

- optional read interleaving enhancement in the read fabric and wrappers
