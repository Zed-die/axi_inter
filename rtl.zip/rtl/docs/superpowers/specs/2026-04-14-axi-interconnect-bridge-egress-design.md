# AXI Interconnect Bridge Egress Design

**Date:** 2026-04-14

## Goal

Add a selectable `AXI2AHB` egress mode to the new `axi_interconnect_core` so a crossbar output port can terminate on the existing `axi2ahb_bridge_top`.

## Scope

This slice adds:

- per-egress mode select: direct AXI passthrough or `AXI2AHB`
- AHB top-level ports on `axi_interconnect_core`
- local full-ID restoration around the bridge
- write `WID` generation from AXI4 write ordering
- bridge-mode verification for write, read, and ordered outstanding behavior

This slice does not add:

- generic width conversion
- separate AXI and AHB clock domains
- APB configuration
- bridge-side out-of-order behavior

## Key Constraints

The existing `axi2ahb_bridge_top` is not a generic AXI4 target. The wrapper must treat it as a constrained target:

- `ADDR_WIDTH` must be `32`
- `DATA_WIDTH` must be `64`
- `STRB_WIDTH` must be `8`
- bridge AXI ID width is fixed at `8`
- bridge uses `WID`
- bridge responses are treated as in-order

Bridge-mode egress will fail configuration checks if these constraints are not met.

## Architecture

`axi_ic_egress` gains a per-instance bridge mode. In direct mode it keeps the current AXI passthrough behavior. In bridge mode it:

- ties bridge `aclk` and `hclk` to the interconnect `clk`
- ties bridge `aresetn` and `hresetn` to `~rst`
- truncates outgoing AXI IDs to `8` bits for the bridge
- records full internal IDs locally so responses sent back toward `axi_crossbar` keep the complete `M_ID_WIDTH`

The wrapper uses three small local trackers:

- write-data ID FIFO: stores low 8-bit IDs in AW order so `WID` can be driven for each write burst
- write-response ID FIFO: stores full IDs in AW order so `BID` can be restored on bridge write responses
- read-response ID FIFO/context: stores full IDs in AR order so `RID` can be restored across all beats of each read burst

## Ordering Model

Bridge-mode egress assumes the bridge returns write and read responses in request order. This matches the bridge README and avoids adding a reorder buffer outside the bridge.

The wider interconnect can still support different-ID out-of-order behavior on direct AXI egress ports. The bridge egress itself remains ordered.

## Top-Level Integration

`axi_interconnect_core` adds AHB ports for every egress slot. Each port can independently be configured as:

- direct AXI output
- bridged AHB output

Direct AXI egress ports drive their AHB outputs idle. Bridge egress ports drive their AXI master outputs idle.

## Verification

The new verification slice must include:

- unit test for `axi_ic_egress` bridge mode
- top-level smoke test for `axi_interconnect_core` with one bridge-configured egress port
- regression of the existing burst guard, read guard, write guard, direct core smoke, and read out-of-order tests
