# AXI Interconnect Read Outstanding Demo Design

**Date:** 2026-04-14

## Goal

Add a dedicated simulation that clearly demonstrates the current `axi_interconnect_core` can hold multiple read transactions outstanding from two upstream AXI source ports at the same time before any read response returns.

## Scope

This slice adds:

- one standalone testbench focused on read outstanding behavior
- explicit tracking of accepted `AR` transactions from both source ports
- explicit tracking of the number of read responses still pending
- a controlled response schedule that delays all `R` traffic until multiple reads are already in flight
- pass/fail checks for per-source peak outstanding depth and end-to-end response completion

This slice does not add:

- any RTL changes to `axi_interconnect_core`
- new APB policy behavior
- read interleaving support
- write outstanding coverage

## Scenario

The testbench drives several single-beat `AR` requests from both source port 0 and source port 1 toward two different downstream targets.

Each source port injects two requests. The downstream side accepts each `AR` immediately but withholds all `R` responses until all four requests have been accepted. The testbench counts accepted reads and returned reads for each source and computes:

- `current_outstanding[src] = accepted_reads[src] - completed_reads[src]`
- `max_outstanding[src] = max(current_outstanding[src])`

The test passes only if:

- each source reaches at least two accepted `AR` requests before its first `R` response
- `max_outstanding[0] >= 2`
- `max_outstanding[1] >= 2`
- all four responses eventually return with the expected source-local IDs and data

## Reuse Strategy

The new testbench should reuse the same structural style as `tb/tb_axi_interconnect_core_read_ooo.sv`:

- direct instantiation of `axi_interconnect_core`
- simple downstream response model driven from the testbench
- no scoreboard framework or reusable verification library

This keeps the demo lightweight and easy to inspect in waveforms.

## Verification

This slice must include:

- one new read-outstanding-focused testbench
- a red phase where the new test is introduced and run
- a green phase where the testbench is completed so the new test passes
- a targeted regression re-running `tb_axi_interconnect_core_read_ooo`
