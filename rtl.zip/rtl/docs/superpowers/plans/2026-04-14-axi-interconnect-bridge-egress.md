# AXI Interconnect Bridge Egress Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a selectable `AXI2AHB` egress mode to `axi_interconnect_core` and verify bridge-mode request and response behavior.

**Architecture:** Extend `axi_ic_egress` so each port can run in direct AXI mode or bridge mode. Bridge mode wraps `axi2ahb_bridge_top`, tracks full internal IDs locally, and exports AHB pins through `axi_interconnect_core`.

**Tech Stack:** Verilog 2001 RTL, SystemVerilog testbenches, Icarus Verilog simulation, existing `axi2ahb` bridge RTL

---

### Task 1: Add failing bridge-mode egress test

**Files:**
- Create: `f:\codex_proj\axi_inter\rtl\tb\tb_axi_ic_egress_axi2ahb.sv`
- Verify: `f:\codex_proj\axi_inter\rtl\axi_interconnect_core\axi_ic_egress.v`

- [ ] Step 1: Write the failing unit test for bridge-mode write and read completion with full ID restoration
- [ ] Step 2: Run the bridge-mode egress test to verify it fails against the current passthrough-only egress shell

### Task 2: Implement bridge mode in `axi_ic_egress`

**Files:**
- Modify: `f:\codex_proj\axi_inter\rtl\axi_interconnect_core\axi_ic_egress.v`

- [ ] Step 1: Add mode-select parameters, bridge configuration guards, and new AHB-side ports
- [ ] Step 2: Add local ID tracking for write-data, write-response, and read-response paths
- [ ] Step 3: Instantiate `axi2ahb_bridge_top` in bridge mode and keep passthrough behavior in direct mode
- [ ] Step 4: Re-run the bridge-mode egress test to verify it passes

### Task 3: Export AHB ports at the core top

**Files:**
- Modify: `f:\codex_proj\axi_inter\rtl\axi_interconnect_core\axi_interconnect_core.v`
- Modify: `f:\codex_proj\axi_inter\rtl\tb\tb_axi_interconnect_core_smoke.sv`
- Modify: `f:\codex_proj\axi_inter\rtl\tb\tb_axi_interconnect_core_read_ooo.sv`

- [ ] Step 1: Add per-port bridge enable parameters and AHB ports on `axi_interconnect_core`
- [ ] Step 2: Thread the new signals through each egress instance while preserving direct AXI mode
- [ ] Step 3: Update existing direct-mode testbenches so they compile against the expanded core port list
- [ ] Step 4: Re-run the direct-mode smoke and read out-of-order tests to verify no regression

### Task 4: Add top-level bridge smoke coverage

**Files:**
- Create: `f:\codex_proj\axi_inter\rtl\tb\tb_axi_interconnect_core_bridge_smoke.sv`

- [ ] Step 1: Write the failing top-level smoke test for one bridge-configured egress port
- [ ] Step 2: Run the bridge smoke test to verify it fails before the top-level integration is complete
- [ ] Step 3: Make any minimal RTL fixes needed to satisfy the new smoke coverage
- [ ] Step 4: Re-run the bridge smoke test to verify it passes

### Task 5: Re-run the phase regression

**Files:**
- Verify: `f:\codex_proj\axi_inter\rtl\tb\tb_axi_ic_burst_guard.sv`
- Verify: `f:\codex_proj\axi_inter\rtl\tb\tb_axi_ic_write_guard.sv`
- Verify: `f:\codex_proj\axi_inter\rtl\tb\tb_axi_ic_read_guard.sv`
- Verify: `f:\codex_proj\axi_inter\rtl\tb\tb_axi_ic_egress_axi2ahb.sv`
- Verify: `f:\codex_proj\axi_inter\rtl\tb\tb_axi_interconnect_core_smoke.sv`
- Verify: `f:\codex_proj\axi_inter\rtl\tb\tb_axi_interconnect_core_read_ooo.sv`
- Verify: `f:\codex_proj\axi_inter\rtl\tb\tb_axi_interconnect_core_bridge_smoke.sv`

- [ ] Step 1: Run the burst-guard test
- [ ] Step 2: Run the write-guard test
- [ ] Step 3: Run the read-guard test
- [ ] Step 4: Run the bridge-mode egress unit test
- [ ] Step 5: Run the direct-mode core smoke test
- [ ] Step 6: Run the direct-mode read out-of-order test
- [ ] Step 7: Run the top-level bridge smoke test
- [ ] Step 8: Report the actual command results and any remaining bridge-mode limitations
