# AXI Crossbar Write Decode Error Bookkeeping Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a focused self-checking testbench that reproduces the write-path decode-error bookkeeping bug through the full `axi_crossbar_wr` return path.

**Architecture:** Create one standalone `sim/tb_axi_crossbar_wr_decode_err_count.sv` testbench around a minimal `S_COUNT=1, M_COUNT=1` `axi_crossbar_wr` instance. Use two directed write scenarios and hierarchical checks on `axi_crossbar_addr` bookkeeping registers to prove the current buggy behavior.

**Tech Stack:** Verilog/SystemVerilog, `iverilog`, `vvp`

---

### Task 1: Add the failing reproduction testbench

**Files:**
- Create: `sim/tb_axi_crossbar_wr_decode_err_count.sv`
- Test: `axi_crossbar/priority_encoder.v`
- Test: `axi_crossbar/arbiter.v`
- Test: `axi_crossbar/axi_register_wr.v`
- Test: `axi_crossbar/axi_crossbar_addr.v`
- Test: `axi_crossbar/axi_crossbar_wr.v`

- [ ] **Step 1: Write the failing testbench**

```systemverilog
module tb_axi_crossbar_wr_decode_err_count;
    // instantiate axi_crossbar_wr with S_COUNT=1 and M_COUNT=1
    // add clock/reset
    // add posedge-aligned tasks for AW, W, and B handshakes
    // scenario 1: isolated decode error causes trans_count_reg wrap
    // scenario 2: same-ID decode error clears active thread_count_reg[0]
    // use hierarchical checks and $fatal on missing reproduction
endmodule
```

- [ ] **Step 2: Run compile to verify the testbench builds**

Run: `iverilog -g2012 -o sim\\tb_axi_crossbar_wr_decode_err_count.vvp axi_crossbar\\priority_encoder.v axi_crossbar\\arbiter.v axi_crossbar\\axi_register_wr.v axi_crossbar\\axi_crossbar_addr.v axi_crossbar\\axi_crossbar_wr.v sim\\tb_axi_crossbar_wr_decode_err_count.sv`
Expected: compile succeeds with exit code 0

- [ ] **Step 3: Run simulation to confirm the buggy behavior is reproduced**

Run: `vvp sim\\tb_axi_crossbar_wr_decode_err_count.vvp`
Expected: both decode-error scenarios print PASS for bug reproduction and the test ends cleanly
