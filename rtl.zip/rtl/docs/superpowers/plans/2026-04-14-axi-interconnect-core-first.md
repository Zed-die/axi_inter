# AXI Interconnect Core-First Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a phase-1 AXI interconnect core around the existing `axi_crossbar` with burst validation and local error handling.

**Architecture:** Per-port ingress guards validate bursts before entering the existing crossbar. Valid traffic passes through the fabric unchanged; invalid traffic returns local `DECERR`. Per-port egress wrappers are passthrough shells for future bridge and target adaptation.

**Tech Stack:** Verilog 2001 RTL, SystemVerilog testbenches, Icarus Verilog for simulation

---

### Task 1: Add burst validation helper

**Files:**
- Create: `f:\codex_proj\axi_inter\rtl\axi_interconnect_core\axi_ic_burst_guard.v`
- Test: `f:\codex_proj\axi_inter\rtl\tb\tb_axi_ic_burst_guard.sv`

- [ ] Step 1: Write a failing test for valid and invalid burst classification
- [ ] Step 2: Run the burst-guard test to verify it fails
- [ ] Step 3: Implement minimal burst guard logic
- [ ] Step 4: Re-run the burst-guard test to verify it passes

### Task 2: Add write ingress guard

**Files:**
- Create: `f:\codex_proj\axi_inter\rtl\axi_interconnect_core\axi_ic_write_guard.v`
- Test: `f:\codex_proj\axi_inter\rtl\tb\tb_axi_ic_write_guard.sv`

- [ ] Step 1: Write a failing test for valid pass-through and invalid local `DECERR`
- [ ] Step 2: Run the write-guard test to verify it fails
- [ ] Step 3: Implement minimal write-guard logic
- [ ] Step 4: Re-run the write-guard test to verify it passes

### Task 3: Add read ingress guard

**Files:**
- Create: `f:\codex_proj\axi_inter\rtl\axi_interconnect_core\axi_ic_read_guard.v`
- Test: `f:\codex_proj\axi_inter\rtl\tb\tb_axi_ic_read_guard.sv`

- [ ] Step 1: Write a failing test for valid pass-through and invalid local `DECERR` read burst generation
- [ ] Step 2: Run the read-guard test to verify it fails
- [ ] Step 3: Implement minimal read-guard logic
- [ ] Step 4: Re-run the read-guard test to verify it passes

### Task 4: Add egress shell and top-level interconnect core

**Files:**
- Create: `f:\codex_proj\axi_inter\rtl\axi_interconnect_core\axi_ic_egress.v`
- Create: `f:\codex_proj\axi_inter\rtl\axi_interconnect_core\axi_interconnect_core.v`
- Test: `f:\codex_proj\axi_inter\rtl\tb\tb_axi_interconnect_core_smoke.sv`

- [ ] Step 1: Write a failing smoke test that instantiates the new top-level wrapper
- [ ] Step 2: Run the smoke test to verify it fails
- [ ] Step 3: Implement the egress shell and top-level wrapper
- [ ] Step 4: Re-run the smoke test to verify it passes

### Task 5: Verify the phase-1 slice

**Files:**
- Verify: `f:\codex_proj\axi_inter\rtl\axi_interconnect_core\*.v`
- Verify: `f:\codex_proj\axi_inter\rtl\tb\*.sv`

- [ ] Step 1: Run the burst-guard test
- [ ] Step 2: Run the write-guard test
- [ ] Step 3: Run the read-guard test
- [ ] Step 4: Run the smoke test
- [ ] Step 5: Report actual pass and fail status with command output evidence
