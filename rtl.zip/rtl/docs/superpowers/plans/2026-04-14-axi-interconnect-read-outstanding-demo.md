# AXI Interconnect Read Outstanding Demo Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a simulation that visibly proves `axi_interconnect_core` can sustain multiple read transactions outstanding from two source ports at the same time before any read response is returned.

**Architecture:** Update the standalone outstanding-demo testbench so both source ports inject reads in parallel using the existing direct-response style from the read out-of-order test. Instrument request acceptance and response completion per source so the bench can assert that both sources independently build outstanding depth before any response returns.

**Tech Stack:** Verilog/SystemVerilog, `iverilog`, `vvp`

---

### Task 1: Update the outstanding-demo testbench for concurrent dual-source injection

**Files:**
- Modify: `tb/tb_axi_interconnect_core_read_outstanding.sv`
- Test: `tb/tb_axi_interconnect_core_read_outstanding.sv`

- [ ] **Step 1: Write the failing test**

Change the bench so it expects:

- two `AR` requests from source port 0
- two `AR` requests from source port 1
- per-source `accepted_reads`, `completed_reads`, `accepted_before_first_r`, and `max_outstanding`
- final checks for `max_outstanding[0] >= 2` and `max_outstanding[1] >= 2`

Leave the old single-source stimulus in place for the red phase so the new checks fail.

- [ ] **Step 2: Run test to verify it fails**

Run: `iverilog -g2012 -o tb_read_outstanding.vvp axi_crossbar/priority_encoder.v axi_crossbar/arbiter.v axi_crossbar/axi_register_wr.v axi_crossbar/axi_register_rd.v axi_crossbar/axi_crossbar_addr.v axi_crossbar/axi_crossbar_wr.v axi_crossbar/axi_crossbar_rd.v axi_crossbar/axi_crossbar.v axi_interconnect_core/axi_ic_burst_guard.v axi_interconnect_core/axi_ic_write_guard.v axi_interconnect_core/axi_ic_read_guard.v axi_interconnect_core/axi_ic_apb_cfg.v axi_interconnect_core/axi_ic_egress.v axi2ahb/*.v axi_interconnect_core/axi_interconnect_core.v tb/tb_axi_interconnect_core_read_outstanding.sv`

Run: `vvp tb_read_outstanding.vvp`

Expected: FAIL because the bench still only injects requests on one source port.

- [ ] **Step 3: Write minimal implementation**

Complete the bench with:

- source-parameterized `send_ar` support so both source ports can inject concurrently
- two rounds of `fork/join` request injection so `S0` and `S1` drive reads in the same time window
- per-source counters for accepted reads, completed reads, current outstanding, and max outstanding
- captured downstream IDs per target so responses can be returned correctly
- final assertions for both sources, first-response timing per source, and successful completion of all four responses

- [ ] **Step 4: Run test to verify it passes**

Run the same `iverilog` and `vvp` commands from Step 2.

Expected: PASS with a message showing the observed peak outstanding depth for both sources.

### Task 2: Re-run the closest existing regression

**Files:**
- Test: `tb/tb_axi_interconnect_core_read_ooo.sv`

- [ ] **Step 1: Run the existing read out-of-order test**

Run: `iverilog -g2012 -o tb_read_ooo.vvp axi_crossbar/priority_encoder.v axi_crossbar/arbiter.v axi_crossbar/axi_register_wr.v axi_crossbar/axi_register_rd.v axi_crossbar/axi_crossbar_addr.v axi_crossbar/axi_crossbar_wr.v axi_crossbar/axi_crossbar_rd.v axi_crossbar/axi_crossbar.v axi_interconnect_core/axi_ic_burst_guard.v axi_interconnect_core/axi_ic_write_guard.v axi_interconnect_core/axi_ic_read_guard.v axi_interconnect_core/axi_ic_apb_cfg.v axi_interconnect_core/axi_ic_egress.v axi2ahb/*.v axi_interconnect_core/axi_interconnect_core.v tb/tb_axi_interconnect_core_read_ooo.sv`

Run: `vvp tb_read_ooo.vvp`

Expected: PASS

- [ ] **Step 2: Summarize results**

Record the observed outstanding peak for both sources and confirm the existing read out-of-order test still passes without RTL changes.
