# Arbiter Testbench Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a self-checking `arbiter` testbench under `sim/` that matches the parameterization used by `axi_crossbar_wr`.

**Architecture:** Create one standalone SystemVerilog testbench that instantiates two `arbiter` DUTs: one with `PORTS=S_COUNT` for `a_arb_inst` behavior and one with `PORTS=M_COUNT+1` for `b_arb_inst` behavior. Drive directed request/acknowledge sequences and check `grant`, `grant_valid`, and `grant_encoded` on every scenario.

**Tech Stack:** Verilog/SystemVerilog, `iverilog`, `vvp`

---

### Task 1: Add the directed self-checking testbench

**Files:**
- Create: `sim/tb_arbiter.sv`
- Test: `rtl/axi_crossbar/priority_encoder.v`
- Test: `rtl/axi_crossbar/arbiter.v`

- [ ] **Step 1: Write the testbench**

```systemverilog
module tb_arbiter;
    localparam int S_COUNT = 4;
    localparam int M_COUNT = 4;
    localparam int M_COUNT_P1 = M_COUNT+1;

    // instantiate two arbiters with the same parameters used in axi_crossbar_wr
    // drive reset, request, and acknowledge
    // check reset state, LSB-first round-robin selection, grant hold, ack release, and wraparound
endmodule
```

- [ ] **Step 2: Run compile to verify the testbench builds**

Run: `iverilog -g2012 -o %TEMP%\\tb_arbiter.vvp rtl/axi_crossbar/priority_encoder.v rtl/axi_crossbar/arbiter.v sim/tb_arbiter.sv`
Expected: compile succeeds with exit code 0

- [ ] **Step 3: Run simulation and verify all checks pass**

Run: `vvp %TEMP%\\tb_arbiter.vvp`
Expected: PASS messages for each directed scenario followed by a final completion message

