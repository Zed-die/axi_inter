# AXI4 to AHB-Lite Bridge Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a first-stage protocol-correct AXI4 burst slave to AHB-Lite master bridge.

**Architecture:** The first implementation accepts one AXI burst at a time, serializes read/write execution through a single AHB-Lite FSM, restores AXI IDs on B/R, and keeps the internal request record isolated so later AW/AR/W FIFOs can be added without rewriting the AHB executor.

**Tech Stack:** Verilog/SystemVerilog, `iverilog`, `vvp`

---

### Task 1: Verification Harness

**Files:**
- Create: `sim/tb_axi4_to_ahb_lite_bridge.sv`
- Create: `rtl/axi2ahb_bridge/axi4_to_ahb_lite_bridge.v`

- [ ] **Step 1: Write the failing test**

Create a TB that instantiates `axi4_to_ahb_lite_bridge` and checks:

- 4-beat AXI INCR write maps to AHB-Lite transfers and stores memory data.
- 4-beat AXI WRAP read returns the wrapped data sequence with the original AXI ID.
- A partial-strobe write uses byte AHB transfers and updates only selected byte lanes.

- [ ] **Step 2: Run RED**

Run:

```powershell
iverilog -g2012 -o sim\tb_axi4_to_ahb_lite_bridge.vvp rtl\axi2ahb_bridge\axi4_to_ahb_lite_bridge.v sim\tb_axi4_to_ahb_lite_bridge.sv
```

Expected: fail because the RTL module is not implemented yet.

### Task 2: Bridge RTL

**Files:**
- Modify: `rtl/axi2ahb_bridge/axi4_to_ahb_lite_bridge.v`

- [ ] **Step 1: Implement module interface**

Use parameters `AXI_ID_WIDTH`, `ADDR_WIDTH`, `DATA_WIDTH`, and `MAX_BURST_LEN`. Default to 8-bit ID, 32-bit address, 32-bit data, and 256 beats.

- [ ] **Step 2: Implement write path**

Accept one AW, drain/store the complete W burst, reject malformed bursts with DECERR after WLAST, then execute the write on AHB-Lite. Full-word writes may use INCR/WRAP bursts; partial writes are split into byte transfers.

- [ ] **Step 3: Implement read path**

Accept one AR, execute AHB-Lite reads into an internal buffer, then stream AXI R beats with correct RID/RLAST/RRESP.

- [ ] **Step 4: Implement error paths**

Reject unsupported burst type, invalid WRAP length, and 4KB boundary crossing. Reads return zero-data DECERR beats; writes drain W beats before B DECERR.

### Task 3: Verification

**Files:**
- Test: `sim/tb_axi4_to_ahb_lite_bridge.sv`

- [ ] **Step 1: Run GREEN**

Run:

```powershell
iverilog -g2012 -o sim\tb_axi4_to_ahb_lite_bridge.vvp rtl\axi2ahb_bridge\axi4_to_ahb_lite_bridge.v sim\tb_axi4_to_ahb_lite_bridge.sv
vvp sim\tb_axi4_to_ahb_lite_bridge.vvp
```

Expected: PASS with no TB errors.
