/*
* Copyright (c) 2024 Beijing Institute of Open Source Chip
* OpenNoC is licensed under Mulan PSL v2.
* You can use this software according to the terms and conditions of the Mulan PSL v2.
* You may obtain a copy of Mulan PSL v2 at:
*          http://license.coscl.org.cn/MulanPSL2
* THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
* MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
* See the Mulan PSL v2 for more details.
*
* Author:
*    Ziqing Li <liziqing@bosc.ac.cn>
*    Wenhao Li <liwenhao@bosc.ac.cn>
*/

`include "../include/axi4_defines.v"
`include "../include/chie_defines.v"
`include "../include/rni_defines.v"
`include "../include/rni_param.v"

module rni_arctrl
    `RNI_PARAM
        (
            clk_i
            ,rst_i

            // AXI AR0 channel
            ,AR_CH_S0
            ,ARVALID0
            ,ARREADY0

            // txreq outputs
            ,arctrl_txreqflitv_s4_o
            ,arctrl_txreqflit_s4_o
            ,arctrl_txreqflit_sent_s4_i

            // rxrsp inputs
            ,rxrspflitv_d1_i
            ,rxrspflit_d1_i

            // rxdat inputs
            ,rxdatflitv_d1_i
            ,rxdatflit_txnid_d1_i
            ,rxdatflit_dataid_d1_i

            // s0 rdata dispatch
            ,rp_fifo_acpt_d4_i
            ,arctrl_rb_valid_d4_o
            ,arctrl_rb_ctmask_d4_o
            ,arctrl_rb_rlast_d4_o
            ,arctrl_rb_rid_d4_o
            ,arctrl_rb_idx_d4_o
            ,arctrl_rb_bc_d4_o

            ,pcrdgnt_pkt_v_d2_i
            ,pcrdgnt_pkt_d2_i
            ,arctrl_pcrdgnt_h_present_d3_o
            ,arctrl_pcrdgnt_l_present_d3_o
            ,ar_pcrdgnt_h_win_d3_i
            ,ar_pcrdgnt_l_win_d3_i
        );

    input  wire                                       clk_i; // 时钟信号
    input  wire                                       rst_i; // 复位信号，高有效

    input  wire [`AXI4_AR_WIDTH-1:0]                  AR_CH_S0;     //输入读AXI bus
    input  wire                                       ARVALID0;     // AXI AR 通道 valid
    output wire                                       ARREADY0;     // AXI AR 通道 ready

    output wire                                       arctrl_txreqflitv_s4_o;       // AR 控制器输出的 TXREQ valid，发送 ReadOnce 请求
    output wire [`CHIE_REQ_FLIT_WIDTH-1:0]            arctrl_txreqflit_s4_o;        // AR 控制器输出的 TXREQ flit payload
    input  wire                                       arctrl_txreqflit_sent_s4_i;   // 与arctrl_txreqflitv_s4_o握手表示 link 层已经真正接收/发送该 REQ flit

    input  wire                                       rxdatflitv_d1_i;              // D1 阶段 RXDAT flit valid 输入
    input  wire [`CHIE_DAT_FLIT_TXNID_WIDTH-1:0]      rxdatflit_txnid_d1_i;         // RXDAT TxnID，用于定位读 entry
    input  wire [`CHIE_DAT_FLIT_DATAID_WIDTH-1:0]     rxdatflit_dataid_d1_i;        // RXDAT DataID，用于定位返回数据片段

    //rsp flit输入
    input  wire                                       rxrspflitv_d1_i;              // D1 阶段 RXRSP flit valid 输入
    input  wire [`CHIE_RSP_FLIT_WIDTH-1:0]            rxrspflit_d1_i;               // D1 阶段 RXRSP flit 输入

    input  wire                                       rp_fifo_acpt_d4_i;            // rd_buffer 已接收 arctrl 的读返回数据,相当于ready信号
    output wire                                       arctrl_rb_valid_d4_o;         // arctrl 调度 rd_buffer 返回读数据 valid
    output wire [`RNI_DMASK_CT_WIDTH-1:0]             arctrl_rb_ctmask_d4_o;        // arctrl 输出的读返回 chunk mask
    output wire                                       arctrl_rb_rlast_d4_o;         // arctrl 输出的 AXI RLAST 指示
    output wire [`AXI4_ARID_WIDTH-1:0]                arctrl_rb_rid_d4_o;           // arctrl 输出的 AXI RID
    output wire [`RNI_AR_ENTRIES_WIDTH-1:0]           arctrl_rb_idx_d4_o;           // arctrl 输出的读 entry index
    output wire [`RNI_BC_WIDTH-1:0]                   arctrl_rb_bc_d4_o;            // arctrl 输出的读返回 beat count 信息

    input  wire                                       pcrdgnt_pkt_v_d2_i;           // PCRDGrant packet valid 输入
    input  wire [`PCRDGRANT_PKT_WIDTH-1:0]            pcrdgnt_pkt_d2_i;             // PCRDGrant packet 输入，包含 PCRDType/SrcID/TgtID
    output wire                                       arctrl_pcrdgnt_h_present_d3_o;// AR 侧存在 high-QoS PCRDGrant 匹配项
    output wire                                       arctrl_pcrdgnt_l_present_d3_o;// AR 侧存在 low-QoS PCRDGrant 匹配项
    input  wire                                       ar_pcrdgnt_h_win_d3_i;        // AR high-QoS PCRDGrant 仲裁获胜输入
    input  wire                                       ar_pcrdgnt_l_win_d3_i;        // AR low-QoS PCRDGrant 仲裁获胜输入


    //RNI_AR_ENTRIES_NUM_PARAM代表最高能够存储多少segment分片请求
    wire alloc_busy_s1_w;
    wire [`AXI4_AR_WIDTH-1:0] arlink_arbus_s1_w;
    wire arlink_valid_s1_w;
    wire [`AXI4_ARADDR_WIDTH-1:0] arlink_addr_s1_w;
    wire [`RNI_BCVEC_WIDTH-1:0] arlink_bc_vec_s2_w;
    wire [`RNI_DMASK_WIDTH-1:0] arlink_dmask_s2_w;
    wire [`AXI4_ARSIZE_WIDTH-1:0] arlink_size_s2_w;
    wire [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_alloc_ptr_s1_w;
    wire [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_entry_rdy_s1_w;
    wire [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_entry_v_ns_w;
    wire arctrl_new_entry_req_dep_w;
    wire [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_entry_is_req_dep_v_ns_w;
    wire [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_entry_req_dep_v_ns_w;
    wire [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_req_dep_chain_young_ns_w;
    wire arctrl_new_entry_rdata_dep_w;
    wire [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_entry_is_rdata_dep_v_ns_w;
    wire [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_entry_rdata_dep_v_ns_w;
    wire [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_rdata_dep_chain_young_ns_w;
    wire [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_req_retry_ready_w;
    wire [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_entry_req_hi_retry_rdy_w;
    wire [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_entry_req_lo_retry_rdy_w;
    wire [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_req_new_rdy_w;
    wire [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_entry_req_hi_new_rdy_w;
    wire [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_entry_req_lo_new_rdy_w;
    wire [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_entry_req_select_vec_ns_w;
    wire [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_entry_req_hi_retry_dec_w;
    wire arctrl_req_hi_retry_found_w;
    wire [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_entry_req_lo_retry_dec_w;
    wire arctrl_req_lo_retry_found_w;
    wire [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_entry_req_hi_new_dec_w;
    wire arctrl_req_hi_new_found_w;
    wire [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_entry_req_lo_new_dec_w;
    wire arctrl_req_lo_new_found_w;
    wire [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_entry_req_ptr_ns_w;
    wire arctrl_entry_req_select_success_flag_w;
    wire [CHIE_NID_WIDTH_PARAM-1:0] ar_tx_send_nid_w;
    wire [`CHIE_RSP_FLIT_TGTID_WIDTH-1:0] arctrl_entry_rxrsp_tgtid_w;
    wire [`CHIE_RSP_FLIT_SRCID_WIDTH-1:0] arctrl_entry_rxrsp_srcid_w;
    wire [`CHIE_RSP_FLIT_TXNID_WIDTH-1:0] arctrl_entry_rxrsp_txnid_w;
    wire [`CHIE_RSP_FLIT_OPCODE_WIDTH-1:0] arctrl_entry_rxrsp_opcode_w;
    wire [`CHIE_RSP_FLIT_PCRDTYPE_WIDTH-1:0] arctrl_entry_rxrsp_pcrdtype_w;
    wire ar_rxrsp_correct_w;
    wire rxrsp_retryack_recv_flag_w;
    wire [RNI_AR_ENTRIES_NUM_PARAM-1:0] rxrsp_retryack_recv_vec_w;
    wire [RNI_AR_ENTRIES_NUM_PARAM-1:0] rxrsp_retryack_recv_vec_ns_w;
    wire rxrsp_pcrdgrant_recv_flag_w;
    wire rxrsp_pcrdtype_hi_select_w;
    wire rxrsp_pcrdtype_lo_select_w;
    wire [RNI_AR_ENTRIES_NUM_PARAM-1:0] rxrsp_pcrdgrant_hi_upd_ptr_ns_w;
    wire [RNI_AR_ENTRIES_NUM_PARAM-1:0] rxrsp_pcrdgrant_lo_upd_ptr_ns_w;
    wire [RNI_AR_ENTRIES_NUM_PARAM-1:0] rxrsp_pcrdgrant_recv_vec_ns_w;
    wire [RNI_AR_ENTRIES_NUM_PARAM-1:0] rxrsp_pcrdgrant_hi_recv_vec_d2_w;
    wire rxrsp_pcrdtype_hi_match_d2_w;
    wire [RNI_AR_ENTRIES_NUM_PARAM-1:0] rxrsp_pcrdgrant_lo_recv_vec_d2_w;
    wire rxrsp_pcrdtype_lo_match_d2_w;
    wire [`RNI_DMASK_PD_WIDTH-1:0] arctrl_rdat_pdmask_ns_w;
    wire rxdat_recv_done_flag_w;
    wire rdata_select_adv_w;
    wire [`RNI_DMASK_CT_WIDTH-1:0] arctrl_rdat_ctmask_ns_w;
    wire [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_rdata_select_w;
    wire [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_entry_dealloc_vec_w;
    wire arctrl_entry_dealloc_v_w;

    reg arctrl_entry_full_r;
    reg [`AXI4_ARID_WIDTH-1:0] arctrl_arid_s2_r;
    reg [`AXI4_ARADDR_WIDTH-1:0] arctrl_araddr_s2_r;
    reg [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_same_req_chain_vec_d2_r;
    reg [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_entry_is_req_dep_num_r;
    reg [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_sameid_rdata_chain_vec_d2_r;
    reg [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_entry_is_rdata_dep_num_r;
    reg [`CHIE_REQ_FLIT_TXNID_WIDTH-1:0] ar_txreq_txnid_r;
    reg [`CHIE_REQ_FLIT_WIDTH-1:0] ar_txreqflit_info_r;
    reg [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_rxrsp_ptr_r;
    reg [RNI_AR_ENTRIES_NUM_PARAM-1:0] rxrsp_pcrdgrant_hi_rdy_vec_r;
    reg [RNI_AR_ENTRIES_NUM_PARAM-1:0] rxrsp_pcrdgrant_lo_rdy_vec_r;
    reg [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_rxdat_ptr_r;
    reg [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_rdata_rdy_r;
    reg [`RNI_BCVEC_WIDTH-1:0] arctrl_rdata_bc_r;
    reg arctrl_rdata_bc_break_r;
    reg [`RNI_AR_ENTRIES_WIDTH-1:0] arctrl_rdata_entry_idx_r;
    reg [RNI_AR_ENTRIES_NUM_PARAM-1:0] rxdat_recv_done_vec_r;
    reg [`RNI_DMASK_CT_WIDTH-1:0] arctrl_rdat_ctmask_r;
    reg [`RNI_DMASK_PD_WIDTH-1:0] arctrl_rdat_pdmask_r;
    reg [`RNI_DMASK_LS_WIDTH-1:0] arctrl_rdat_lsmask_r;
    reg [`AXI4_ARID_WIDTH-1:0] arctrl_rdat_axid_r;
    reg [`RNI_BCVEC_WIDTH-1:0] arctrl_rdat_bcvec_r;

    reg [`AXI4_AR_WIDTH-1:0] arctrl_entry_info_q[RNI_AR_ENTRIES_NUM_PARAM-1:0];   //用于存储AR BUS的信息
    reg [`AXI4_ARADDR_WIDTH-1:0] arctrl_entry_addr_q[RNI_AR_ENTRIES_NUM_PARAM-1:0];
    reg [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_entry_qos_hi_q;


    reg [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_entry_v_q;
    reg arlink_valid_s2_q;
    reg [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_alloc_ptr_s2_q;
    reg [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_entry_req_select_rdy_q;
    reg [`AXI4_ARSIZE_WIDTH-1:0] arctrl_entry_size_q[RNI_AR_ENTRIES_NUM_PARAM-1:0];
    reg [`RNI_DMASK_LS_WIDTH-1:0] arctrl_entry_lsmask_q[RNI_AR_ENTRIES_NUM_PARAM-1:0];
    reg [`RNI_BCVEC_WIDTH-1:0] arctrl_entry_bcvec_q[RNI_AR_ENTRIES_NUM_PARAM-1:0];

    
    reg [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_entry_is_req_dep_v_q;
    reg [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_entry_req_dep_v_q;
    reg [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_entry_is_req_dep_num_q[RNI_AR_ENTRIES_NUM_PARAM-1:0];
    reg [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_req_dep_chain_young_q;
    reg [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_entry_is_rdata_dep_v_q;
    reg [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_entry_rdata_dep_v_q;
    reg [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_entry_is_rdata_dep_num_q[RNI_AR_ENTRIES_NUM_PARAM-1:0];
    reg [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_rdata_dep_chain_young_q;
    reg [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_entry_req_ptr_q;
    reg arctrl_entry_req_select_success_q;
    reg [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_entry_req_select_vec_q;
    reg arctrl_entry_req_select_retry_flag_q;
    reg ar_txreqflitv_s5_q;
    reg [`CHIE_REQ_FLIT_WIDTH-1:0] ar_txreqflit_s5_q;
    reg ar_txreqflit_sent_s5_q;
    reg rxrsp_pcrdtype_hi_match_d3_q;
    reg [RNI_AR_ENTRIES_NUM_PARAM-1:0] rxrsp_pcrdgrant_hi_recv_vec_d3_q;
    reg rxrsp_pcrdtype_lo_match_d3_q;
    reg [RNI_AR_ENTRIES_NUM_PARAM-1:0] rxrsp_pcrdgrant_lo_recv_vec_d3_q;
    reg [`CHIE_RSP_FLIT_PCRDTYPE_WIDTH-1:0] rxrsp_retryack_pcrdtype_q[RNI_AR_ENTRIES_NUM_PARAM-1:0];
    reg [RNI_AR_ENTRIES_NUM_PARAM-1:0] rxrsp_retryack_recv_vec_q;
    reg [RNI_AR_ENTRIES_NUM_PARAM-1:0] rxrsp_pcrdgrant_hi_upd_ptr_q;
    reg [RNI_AR_ENTRIES_NUM_PARAM-1:0] rxrsp_pcrdgrant_lo_upd_ptr_q;
    reg [RNI_AR_ENTRIES_NUM_PARAM-1:0] rxrsp_pcrdgrant_recv_vec_q;
    reg rxdat_flitv_q;
    reg [`CHIE_DAT_FLIT_TXNID_WIDTH-1:0] rxdat_txnid_q;
    reg [`CHIE_DAT_FLIT_DATAID_WIDTH-1:0] rxdat_dataid_q;
    reg [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_rdata_start_ptr_q;
    reg [RNI_AR_ENTRIES_NUM_PARAM-1:0] arctrl_rdata_send_q;

    reg [`RNI_DMASK_RV_WIDTH-1:0] arctrl_entry_rvmask_q[RNI_AR_ENTRIES_NUM_PARAM-1:0];
    reg [`RNI_DMASK_CT_WIDTH-1:0] arctrl_entry_ctmask_q[RNI_AR_ENTRIES_NUM_PARAM-1:0];
    reg [`RNI_DMASK_PD_WIDTH-1:0] arctrl_entry_pdmask_q[RNI_AR_ENTRIES_NUM_PARAM-1:0];

    genvar entry;
    integer i;
    /////////////////////////////////////////////////////////////
    // txreq s1
    /////////////////////////////////////////////////////////////
    rni_arlink rni_arlink_u0
               (
                    .clk_i                         (clk_i                  ),
                    .rst_i                         (rst_i                  ),
                    .ARVALID                       (ARVALID0               ),
                    .AR_CH_S0                      (AR_CH_S0               ),
                    .ARREADY                       (ARREADY0               ),
                    .alloc_busy_s1_i               (alloc_busy_s1_w        ),//所有entry全满，无法接收新的CHI segment
                    .arlink_arbus_s1_o             (arlink_arbus_s1_w      ),//S1
                    .arlink_valid_s1_o             (arlink_valid_s1_w      ),//S1
                    .arlink_addr_s1_o              (arlink_addr_s1_w       ),//S1
                    .arlink_bc_vec_s2_o            (arlink_bc_vec_s2_w     ),//S2
                    .arlink_dmask_s2_o             (arlink_dmask_s2_w      ),//S2
                    .arlink_size_s2_o              (arlink_size_s2_w       ),//S2  无作用
                    .arlink_lock_s2_o              (                       )
               );

    poll_with_start_entry
        #(
            .ENTRIES_NUM   (RNI_AR_ENTRIES_NUM_PARAM                           )
        )
        arctrl_entry_alloc(
            .entry_vec     (arctrl_entry_rdy_s1_w[RNI_AR_ENTRIES_NUM_PARAM-1:0]),//在可写入的entry中做仲裁，只会在arlink_valid_s1_w拉高的时候有效
            .start_entry   ({RNI_AR_ENTRIES_NUM_PARAM{1'b0}}                   ),
            .entry_ptr_sel (arctrl_alloc_ptr_s1_w[RNI_AR_ENTRIES_NUM_PARAM-1:0]),//仲裁得到的值，以独热码给出，与输入同拍输出
            .found         (                                                   )
        );


    assign alloc_busy_s1_w = &arctrl_entry_v_q;
    assign arctrl_entry_rdy_s1_w[RNI_AR_ENTRIES_NUM_PARAM-1:0] = ~arctrl_entry_v_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] & {RNI_AR_ENTRIES_NUM_PARAM{arlink_valid_s1_w}};//计算哪个entry为空可写入
    
    //代表entry的valid的向量的下一拍状态，当前的加上仲裁得到的再减去释放的entry
    assign arctrl_entry_v_ns_w[RNI_AR_ENTRIES_NUM_PARAM-1:0] = (arctrl_entry_v_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] | arctrl_alloc_ptr_s1_w[RNI_AR_ENTRIES_NUM_PARAM-1:0]) & ~arctrl_entry_dealloc_vec_w[RNI_AR_ENTRIES_NUM_PARAM-1:0];

    //存储当前AR bus的信息
    generate
        for (entry=0; entry < RNI_AR_ENTRIES_NUM_PARAM; entry=entry+1) begin: txn_info
            always @(posedge clk_i or posedge rst_i) begin
                if (rst_i == 1'b1)begin
                    arctrl_entry_info_q[entry][`AXI4_AR_WIDTH-1:0] <= {`AXI4_AR_WIDTH{1'b0}};
                end
                else begin
                    if(arctrl_alloc_ptr_s1_w[entry] == 1'b1)begin
                        arctrl_entry_info_q[entry][`AXI4_AR_WIDTH-1:0] <= arlink_arbus_s1_w[`AXI4_AR_WIDTH-1:0];
                    end
                end
            end

            always @(posedge clk_i or posedge rst_i) begin
                if (rst_i == 1'b1)begin
                    arctrl_entry_addr_q[entry][`AXI4_ARADDR_WIDTH-1:0] <= {`AXI4_ARADDR_WIDTH{1'b0}};
                end
                else begin
                    if(arctrl_alloc_ptr_s1_w[entry] == 1'b1)begin
                        arctrl_entry_addr_q[entry][`AXI4_ARADDR_WIDTH-1:0] <= arlink_addr_s1_w[`AXI4_ARADDR_WIDTH-1:0];//这里保存的地址是被切片过后的segment的地址
                    end
                end
            end

            always @(posedge clk_i or posedge rst_i) begin
                if (rst_i == 1'b1)begin
                    arctrl_entry_qos_hi_q[entry] <= 1'b0;
                end
                else begin
                    if(arctrl_alloc_ptr_s1_w[entry] == 1'b1)begin
                        arctrl_entry_qos_hi_q[entry] <= (arlink_arbus_s1_w[`AXI4_ARQOS_RANGE] == 4'b1111);
                    end
                end
            end
        end
    endgenerate
    
    //更新entry状态
    always @(posedge clk_i or posedge rst_i) begin
        if (rst_i == 1'b1)begin
            arctrl_entry_v_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] <= {RNI_AR_ENTRIES_NUM_PARAM{1'b0}};
        end
        else begin
            //当有新的 AR segment 到来，或者有 entry 被释放时，更新当前 entry valid 向量 
            if(arlink_valid_s1_w | arctrl_entry_dealloc_v_w)begin
                arctrl_entry_v_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] <= arctrl_entry_v_ns_w[RNI_AR_ENTRIES_NUM_PARAM-1:0];
            end
        end
    end

    //生成S2阶段的数据的valid信号
    always @(posedge clk_i or posedge rst_i) begin
        if (rst_i == 1'b1)begin
            arlink_valid_s2_q <= 1'b0;
        end
        else begin
            arlink_valid_s2_q <= arlink_valid_s1_w;  
        end
    end

    //生成S2阶段的数据的仲裁结果，打一拍，保持与S1一致
    always @(posedge clk_i or posedge rst_i) begin
        if (rst_i == 1'b1)begin
            arctrl_alloc_ptr_s2_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] <= {RNI_AR_ENTRIES_NUM_PARAM{1'b0}};
        end
        else begin
            arctrl_alloc_ptr_s2_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] <= arctrl_alloc_ptr_s1_w[RNI_AR_ENTRIES_NUM_PARAM-1:0];
        end
    end

    
    /////////////////////////////////////////////////////////////
    // txreq s2
    /////////////////////////////////////////////////////////////
    
    //得到S2阶段分配的AR ID
    always@* begin
        arctrl_arid_s2_r[`AXI4_ARID_WIDTH-1:0] = {`AXI4_ARID_WIDTH{1'b0}};
        for (i=0; i < RNI_AR_ENTRIES_NUM_PARAM; i=i+1) //不会锁存因为给了初始值
            arctrl_arid_s2_r[`AXI4_ARID_WIDTH-1:0] = arctrl_arid_s2_r[`AXI4_ARID_WIDTH-1:0] | ({`AXI4_ARID_WIDTH{arctrl_alloc_ptr_s2_q[i]}} & arctrl_entry_info_q[i][`AXI4_ARID_RANGE]);
            //使用 | 的原因是因为如果arctrl_alloc_ptr_s2_q是中间bit位有效，由于for循环会运行到最后，后面会将前面的结果覆盖，使用 | 可以保留结果
    end
    
    //得到S2阶段分配的AR ADDR，与上面相同
    always@* begin
        arctrl_araddr_s2_r[`AXI4_ARADDR_WIDTH-1:0] = {`AXI4_ARADDR_WIDTH{1'b0}};
        for (i=0; i < RNI_AR_ENTRIES_NUM_PARAM; i=i+1)
            arctrl_araddr_s2_r[`AXI4_ARADDR_WIDTH-1:0] = arctrl_araddr_s2_r[`AXI4_ARADDR_WIDTH-1:0] | ({`AXI4_ARADDR_WIDTH{arctrl_alloc_ptr_s2_q[i]}} & arctrl_entry_addr_q[i][`AXI4_ARADDR_WIDTH-1:0]);
    end

    //标记某个 entry 已经可以参与 TXREQ 仲裁选择了
    always @(posedge clk_i or posedge rst_i) begin
        if (rst_i == 1'b1)begin
            arctrl_entry_req_select_rdy_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] <= {RNI_AR_ENTRIES_NUM_PARAM{1'b0}};
        end
        else begin
            arctrl_entry_req_select_rdy_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] <= arctrl_entry_v_q[RNI_AR_ENTRIES_NUM_PARAM-1:0];
        end
    end

    //存储S2阶段产生的segment信息
    generate
        for (entry=0; entry < RNI_AR_ENTRIES_NUM_PARAM; entry=entry+1) begin: txn_size_info
            always @(posedge clk_i or posedge rst_i) begin
                if (rst_i == 1'b1)begin
                    arctrl_entry_size_q[entry][`AXI4_ARSIZE_WIDTH-1:0] <= {`AXI4_ARSIZE_WIDTH{1'b0}};
                end
                else begin
                    if(arctrl_alloc_ptr_s2_q[entry] == 1'b1)begin
                        arctrl_entry_size_q[entry][`AXI4_ARSIZE_WIDTH-1:0] <= arlink_size_s2_w[`AXI4_ARSIZE_WIDTH-1:0];
                    end
                end
            end

            always @(posedge clk_i or posedge rst_i) begin
                if (rst_i == 1'b1)begin
                    arctrl_entry_lsmask_q[entry][`RNI_DMASK_LS_WIDTH-1:0] <={`RNI_DMASK_LS_WIDTH{1'b0}};
                end
                else begin
                    if(arctrl_alloc_ptr_s2_q[entry] == 1'b1)begin
                        arctrl_entry_lsmask_q[entry][`RNI_DMASK_LS_WIDTH-1:0] <= arlink_dmask_s2_w[`RNI_DMASK_LS_RANGE];
                    end
                end
            end

            always @(posedge clk_i or posedge rst_i) begin
                if (rst_i == 1'b1)begin
                    arctrl_entry_bcvec_q[entry][`RNI_BCVEC_WIDTH-1:0] <= {`RNI_BCVEC_WIDTH{1'b0}};
                end
                else begin
                    if(arctrl_alloc_ptr_s2_q[entry] == 1'b1)begin
                        arctrl_entry_bcvec_q[entry][`RNI_BCVEC_WIDTH-1:0] <= arlink_bc_vec_s2_w[`RNI_BCVEC_WIDTH-1:0];
                    end
                end
            end
        end
    endgenerate

    //request chain
    assign arctrl_new_entry_req_dep_w = |arctrl_same_req_chain_vec_d2_r[RNI_AR_ENTRIES_NUM_PARAM-1:0];//标识当前 S2 新分配的 AR entry 是否依赖别的 entry
   
    //当前entry是否依赖别人
    assign arctrl_entry_req_dep_v_ns_w[RNI_AR_ENTRIES_NUM_PARAM-1:0] = (arctrl_entry_req_dep_v_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] | ({RNI_AR_ENTRIES_NUM_PARAM{(arctrl_new_entry_req_dep_w)}} & arctrl_alloc_ptr_s2_q[RNI_AR_ENTRIES_NUM_PARAM-1:0])) & ~arctrl_entry_is_req_dep_num_r[RNI_AR_ENTRIES_NUM_PARAM-1:0];
    assign arctrl_req_dep_chain_young_ns_w[RNI_AR_ENTRIES_NUM_PARAM-1:0] = ((arctrl_req_dep_chain_young_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] | arctrl_alloc_ptr_s2_q[RNI_AR_ENTRIES_NUM_PARAM-1:0]) & ~arctrl_same_req_chain_vec_d2_r[RNI_AR_ENTRIES_NUM_PARAM-1:0]) & ~rxdat_recv_done_vec_r[RNI_AR_ENTRIES_NUM_PARAM-1:0];
    //arctrl_req_dep_chain_young_q表示“当前每条 chain 的最新 entry 是谁”。
    generate
        for (entry=0; entry < RNI_AR_ENTRIES_NUM_PARAM; entry=entry+1) begin:axid_req_same
            always@* begin
                //比较的前提，不是自身/entry有效/entry中的请求未收集完data，L3_CACHELINE_OFFSET = 6
                //与上 arctrl_req_dep_chain_young_q[entry] 的作用是：只允许新请求依赖同一条 request chain 里“最年轻”的那个旧 entry，也就是链尾
                if((arctrl_alloc_ptr_s2_q[entry] == 1'b0) && (arctrl_entry_v_q[entry] == 1'b1) && (rxdat_recv_done_vec_r[entry] == 1'b0))begin
                    //arctrl_same_req_chain_vec_d2_r表示“当前新 entry 接到了哪个旧 entry 后面”，这个旧entry一定要是当前的chain最新的，链的构成：同ARID，同cache line（高位相同）
                    //&& arctrl_req_dep_chain_young_q[entry]可以理解为
                    arctrl_same_req_chain_vec_d2_r[entry] = arlink_valid_s2_q && (arctrl_arid_s2_r[`AXI4_ARID_WIDTH-1:0] == arctrl_entry_info_q[entry][`AXI4_ARID_RANGE]) &&
                                                  (arctrl_araddr_s2_r[`AXI4_ARADDR_WIDTH-1:`L3_CACHELINE_OFFSET] == arctrl_entry_addr_q[entry][`AXI4_ARADDR_WIDTH-1:`L3_CACHELINE_OFFSET]) && arctrl_req_dep_chain_young_q[entry];
                end
                else begin
                    arctrl_same_req_chain_vec_d2_r[entry] = 1'b0;
                end
            end
        end
    endgenerate

    //根据 rxdat_recv_done_vec_r，找出哪些 entry 的 request dependency 可以被解除
    always@* begin
        arctrl_entry_is_req_dep_num_r[RNI_AR_ENTRIES_NUM_PARAM-1:0] = {RNI_AR_ENTRIES_NUM_PARAM{1'b0}};
        for (i=0; i < RNI_AR_ENTRIES_NUM_PARAM; i=i+1)
            arctrl_entry_is_req_dep_num_r[RNI_AR_ENTRIES_NUM_PARAM-1:0] = arctrl_entry_is_req_dep_num_r[RNI_AR_ENTRIES_NUM_PARAM-1:0] | ({RNI_AR_ENTRIES_NUM_PARAM{rxdat_recv_done_vec_r[i]}} & arctrl_entry_is_req_dep_num_q[i][RNI_AR_ENTRIES_NUM_PARAM-1:0]);
    end

    //每个 entry 是否存在 request dependency，也就是是否依赖前面的 entry。
    always @(posedge clk_i or posedge rst_i) begin
        if (rst_i == 1'b1)begin
            arctrl_entry_req_dep_v_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] <= {RNI_AR_ENTRIES_NUM_PARAM{1'b0}};
        end
        else begin
            if((arlink_valid_s2_q && arctrl_new_entry_req_dep_w) | rxdat_recv_done_flag_w)begin
                arctrl_entry_req_dep_v_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] <= arctrl_entry_req_dep_v_ns_w[RNI_AR_ENTRIES_NUM_PARAM-1:0];
            end
        end
    end

    //arctrl_entry_is_req_dep_num_q标识这个旧 entry 被谁直接依赖,如果当前entry收集完毕,无需再记录谁依赖我
    generate
        for (entry=0; entry < RNI_AR_ENTRIES_NUM_PARAM; entry=entry+1) begin:req_dep_num
            always @(posedge clk_i or posedge rst_i) begin
                if (rst_i == 1'b1)begin
                    arctrl_entry_is_req_dep_num_q[entry][RNI_AR_ENTRIES_NUM_PARAM-1:0] <= {RNI_AR_ENTRIES_NUM_PARAM{1'b0}};
                end
                else begin
                    if(rxdat_recv_done_vec_r[entry])begin   //优先释放
                        arctrl_entry_is_req_dep_num_q[entry][RNI_AR_ENTRIES_NUM_PARAM-1:0] <= {RNI_AR_ENTRIES_NUM_PARAM{1'b0}};
                    end
                    else if((arlink_valid_s2_q && arctrl_same_req_chain_vec_d2_r[entry]))begin
                        arctrl_entry_is_req_dep_num_q[entry][RNI_AR_ENTRIES_NUM_PARAM-1:0] <= arctrl_alloc_ptr_s2_q[RNI_AR_ENTRIES_NUM_PARAM-1:0];
                    end
                end
            end
        end
    endgenerate

    //更新每条chain的尾部entry信息
    always @(posedge clk_i or posedge rst_i) begin
        if (rst_i == 1'b1)begin
            arctrl_req_dep_chain_young_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] <= {RNI_AR_ENTRIES_NUM_PARAM{1'b0}};
        end
        else begin
            if(arlink_valid_s2_q | rxdat_recv_done_flag_w)begin
                arctrl_req_dep_chain_young_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] <= arctrl_req_dep_chain_young_ns_w[RNI_AR_ENTRIES_NUM_PARAM-1:0];
            end
        end
    end

    //rdata chain，主要作用保证同一个 AXI ARID 的多个 read entry，AXI RDATA 返回时不能乱序，与req chain的产生相似但只依赖ARID   
    assign arctrl_new_entry_rdata_dep_w = |arctrl_sameid_rdata_chain_vec_d2_r[RNI_AR_ENTRIES_NUM_PARAM-1:0];
    assign arctrl_entry_is_rdata_dep_v_ns_w[RNI_AR_ENTRIES_NUM_PARAM-1:0] = (arctrl_entry_is_rdata_dep_v_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] | arctrl_sameid_rdata_chain_vec_d2_r[RNI_AR_ENTRIES_NUM_PARAM-1:0]) & ~arctrl_entry_dealloc_vec_w[RNI_AR_ENTRIES_NUM_PARAM-1:0];
    assign arctrl_entry_rdata_dep_v_ns_w[RNI_AR_ENTRIES_NUM_PARAM-1:0] = (arctrl_entry_rdata_dep_v_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] | ({RNI_AR_ENTRIES_NUM_PARAM{(arctrl_new_entry_rdata_dep_w)}} & arctrl_alloc_ptr_s2_q[RNI_AR_ENTRIES_NUM_PARAM-1:0])) & ~arctrl_entry_is_rdata_dep_num_r[RNI_AR_ENTRIES_NUM_PARAM-1:0];
    assign arctrl_rdata_dep_chain_young_ns_w[RNI_AR_ENTRIES_NUM_PARAM-1:0] = ((arctrl_rdata_dep_chain_young_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] | arctrl_alloc_ptr_s2_q[RNI_AR_ENTRIES_NUM_PARAM-1:0]) & ~arctrl_sameid_rdata_chain_vec_d2_r[RNI_AR_ENTRIES_NUM_PARAM-1:0]) & ~arctrl_entry_dealloc_vec_w[RNI_AR_ENTRIES_NUM_PARAM-1:0];

    generate
        for (entry=0; entry < RNI_AR_ENTRIES_NUM_PARAM; entry=entry+1) begin:axid_rdata_same
            always@* begin
                if((arctrl_alloc_ptr_s2_q[entry] == 1'b0) && (arctrl_entry_v_q[entry] == 1'b1) && (arctrl_entry_dealloc_vec_w[entry] == 1'b0))begin
                    arctrl_sameid_rdata_chain_vec_d2_r[entry] = (arlink_valid_s2_q && arctrl_arid_s2_r[`AXI4_ARID_WIDTH-1:0] == arctrl_entry_info_q[entry][`AXI4_ARID_RANGE]) && arctrl_rdata_dep_chain_young_q[entry];
                end
                else begin
                    arctrl_sameid_rdata_chain_vec_d2_r[entry] = 1'b0;
                end
            end
        end
    endgenerate

    always@* begin
        arctrl_entry_is_rdata_dep_num_r[RNI_AR_ENTRIES_NUM_PARAM-1:0] = {RNI_AR_ENTRIES_NUM_PARAM{1'b0}};
        for (i=0; i < RNI_AR_ENTRIES_NUM_PARAM; i=i+1)
            arctrl_entry_is_rdata_dep_num_r[RNI_AR_ENTRIES_NUM_PARAM-1:0] = arctrl_entry_is_rdata_dep_num_r[RNI_AR_ENTRIES_NUM_PARAM-1:0] | ({RNI_AR_ENTRIES_NUM_PARAM{arctrl_entry_dealloc_vec_w[i]}} & arctrl_entry_is_rdata_dep_num_q[i][RNI_AR_ENTRIES_NUM_PARAM-1:0]);
    end

    always @(posedge clk_i or posedge rst_i) begin
        if (rst_i == 1'b1)begin
            arctrl_entry_is_rdata_dep_v_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] <= {RNI_AR_ENTRIES_NUM_PARAM{1'b0}};
        end
        else begin
            if(arlink_valid_s2_q | arctrl_entry_dealloc_v_w)begin
                arctrl_entry_is_rdata_dep_v_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] <= arctrl_entry_is_rdata_dep_v_ns_w[RNI_AR_ENTRIES_NUM_PARAM-1:0];
            end
        end
    end

    always @(posedge clk_i or posedge rst_i) begin
        if (rst_i == 1'b1)begin
            arctrl_entry_rdata_dep_v_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] <= {RNI_AR_ENTRIES_NUM_PARAM{1'b0}};
        end
        else begin
            if((arlink_valid_s2_q & arctrl_new_entry_rdata_dep_w) | arctrl_entry_dealloc_v_w)begin
                arctrl_entry_rdata_dep_v_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] <= arctrl_entry_rdata_dep_v_ns_w[RNI_AR_ENTRIES_NUM_PARAM-1:0];
            end
        end
    end

    generate
        for (entry=0; entry < RNI_AR_ENTRIES_NUM_PARAM; entry=entry+1) begin:rdata_dep_num
            always @(posedge clk_i or posedge rst_i) begin
                if (rst_i == 1'b1)begin
                    arctrl_entry_is_rdata_dep_num_q[entry][RNI_AR_ENTRIES_NUM_PARAM-1:0] <= {RNI_AR_ENTRIES_NUM_PARAM{1'b0}};
                end
                else begin
                    if(arctrl_entry_dealloc_vec_w[entry])begin
                        arctrl_entry_is_rdata_dep_num_q[entry][RNI_AR_ENTRIES_NUM_PARAM-1:0] <= {RNI_AR_ENTRIES_NUM_PARAM{1'b0}};
                    end
                    else if((arlink_valid_s2_q && arctrl_sameid_rdata_chain_vec_d2_r[entry]))begin
                        arctrl_entry_is_rdata_dep_num_q[entry][RNI_AR_ENTRIES_NUM_PARAM-1:0] <= arctrl_alloc_ptr_s2_q[RNI_AR_ENTRIES_NUM_PARAM-1:0];
                    end
                end
            end
        end
    endgenerate

    always @(posedge clk_i or posedge rst_i) begin
        if (rst_i == 1'b1)begin
            arctrl_rdata_dep_chain_young_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] <= {RNI_AR_ENTRIES_NUM_PARAM{1'b0}};
        end
        else begin
            if(arlink_valid_s2_q | arctrl_entry_dealloc_v_w)begin
                arctrl_rdata_dep_chain_young_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] <= arctrl_rdata_dep_chain_young_ns_w[RNI_AR_ENTRIES_NUM_PARAM-1:0];
            end
        end
    end

    /////////////////////////////////////////////////////////////
    // txreq select
    /////////////////////////////////////////////////////////////
    
    //给出各个仲裁的参与人，arctrl_entry_qos_hi_q标记着每一个entry的优先级大小
    assign arctrl_req_retry_ready_w[RNI_AR_ENTRIES_NUM_PARAM-1:0] = arctrl_entry_v_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] & arctrl_entry_req_select_rdy_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] & rxrsp_pcrdgrant_recv_vec_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] & ~arctrl_entry_req_select_vec_q[RNI_AR_ENTRIES_NUM_PARAM-1:0];
    assign arctrl_entry_req_hi_retry_rdy_w[RNI_AR_ENTRIES_NUM_PARAM-1:0] = arctrl_req_retry_ready_w[RNI_AR_ENTRIES_NUM_PARAM-1:0] & arctrl_entry_qos_hi_q[RNI_AR_ENTRIES_NUM_PARAM-1:0];
    assign arctrl_entry_req_lo_retry_rdy_w[RNI_AR_ENTRIES_NUM_PARAM-1:0] = arctrl_req_retry_ready_w[RNI_AR_ENTRIES_NUM_PARAM-1:0] & ~arctrl_entry_qos_hi_q[RNI_AR_ENTRIES_NUM_PARAM-1:0];
    
    assign arctrl_req_new_rdy_w[RNI_AR_ENTRIES_NUM_PARAM-1:0] = arctrl_entry_v_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] & arctrl_entry_req_select_rdy_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] & ~arctrl_entry_req_dep_v_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] & ~rxrsp_retryack_recv_vec_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] & ~arctrl_entry_req_select_vec_q[RNI_AR_ENTRIES_NUM_PARAM-1:0];
    assign arctrl_entry_req_hi_new_rdy_w[RNI_AR_ENTRIES_NUM_PARAM-1:0] = arctrl_req_new_rdy_w[RNI_AR_ENTRIES_NUM_PARAM-1:0] & arctrl_entry_qos_hi_q[RNI_AR_ENTRIES_NUM_PARAM-1:0];
    assign arctrl_entry_req_lo_new_rdy_w[RNI_AR_ENTRIES_NUM_PARAM-1:0] = arctrl_req_new_rdy_w[RNI_AR_ENTRIES_NUM_PARAM-1:0] & ~arctrl_entry_qos_hi_q[RNI_AR_ENTRIES_NUM_PARAM-1:0];
    //deassert select_vec when receiving ，维护哪些 entry 的 TXREQ 已经被 select 成功过
    assign arctrl_entry_req_select_vec_ns_w[RNI_AR_ENTRIES_NUM_PARAM-1:0] = (arctrl_entry_req_select_vec_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] | ({RNI_AR_ENTRIES_NUM_PARAM{arctrl_entry_req_select_success_flag_w}} & arctrl_entry_req_ptr_ns_w[RNI_AR_ENTRIES_NUM_PARAM-1:0])) & ~rxrsp_retryack_recv_vec_w[RNI_AR_ENTRIES_NUM_PARAM-1:0] & ~arctrl_entry_dealloc_vec_w[RNI_AR_ENTRIES_NUM_PARAM-1:0];

    // 高 QoS 的 retry 请求
    poll_with_start_entry
        #(
            .ENTRIES_NUM(RNI_AR_ENTRIES_NUM_PARAM)
        )
        req_retry_hi( 
            .entry_vec(arctrl_entry_req_hi_retry_rdy_w[RNI_AR_ENTRIES_NUM_PARAM-1:0])
            ,.start_entry(arctrl_entry_req_ptr_q[RNI_AR_ENTRIES_NUM_PARAM-1:0])
            ,.entry_ptr_sel(arctrl_entry_req_hi_retry_dec_w[RNI_AR_ENTRIES_NUM_PARAM-1:0])
            ,.found(arctrl_req_hi_retry_found_w)
        );

    //低 QoS 的 retry 请求
    poll_with_start_entry
        #(
            .ENTRIES_NUM(RNI_AR_ENTRIES_NUM_PARAM)
        )
        req_retry_lo(
            .entry_vec(arctrl_entry_req_lo_retry_rdy_w[RNI_AR_ENTRIES_NUM_PARAM-1:0])
            ,.start_entry(arctrl_entry_req_ptr_q[RNI_AR_ENTRIES_NUM_PARAM-1:0])
            ,.entry_ptr_sel(arctrl_entry_req_lo_retry_dec_w[RNI_AR_ENTRIES_NUM_PARAM-1:0])
            ,.found(arctrl_req_lo_retry_found_w)
        );

    // 高 QoS 的新请求
    poll_with_start_entry
        #(
            .ENTRIES_NUM(RNI_AR_ENTRIES_NUM_PARAM)
        )
        req_new_hi(
            .entry_vec(arctrl_entry_req_hi_new_rdy_w[RNI_AR_ENTRIES_NUM_PARAM-1:0])
            ,.start_entry(arctrl_entry_req_ptr_q[RNI_AR_ENTRIES_NUM_PARAM-1:0])
            ,.entry_ptr_sel(arctrl_entry_req_hi_new_dec_w[RNI_AR_ENTRIES_NUM_PARAM-1:0])
            ,.found(arctrl_req_hi_new_found_w)
        );

    // 低 QoS 的新请求
    poll_with_start_entry
        #(
            .ENTRIES_NUM(RNI_AR_ENTRIES_NUM_PARAM)
        )
        req_new_lo(
            .entry_vec(arctrl_entry_req_lo_new_rdy_w[RNI_AR_ENTRIES_NUM_PARAM-1:0])
            ,.start_entry(arctrl_entry_req_ptr_q[RNI_AR_ENTRIES_NUM_PARAM-1:0])
            ,.entry_ptr_sel(arctrl_entry_req_lo_new_dec_w[RNI_AR_ENTRIES_NUM_PARAM-1:0])
            ,.found(arctrl_req_lo_new_found_w)
        );

    //SP仲裁，hi retry > hi new > lo retry > lo new
    assign arctrl_entry_req_ptr_ns_w[RNI_AR_ENTRIES_NUM_PARAM-1:0] = arctrl_req_hi_retry_found_w ? arctrl_entry_req_hi_retry_dec_w[RNI_AR_ENTRIES_NUM_PARAM-1:0]:
           arctrl_req_hi_new_found_w ? arctrl_entry_req_hi_new_dec_w[RNI_AR_ENTRIES_NUM_PARAM-1:0]:
           arctrl_req_lo_retry_found_w ? arctrl_entry_req_lo_retry_dec_w[RNI_AR_ENTRIES_NUM_PARAM-1:0]:
           arctrl_entry_req_lo_new_dec_w[RNI_AR_ENTRIES_NUM_PARAM-1:0];

    //表示本拍 TXREQ 仲裁真正成功选中了一个 entry，并且 TXREQ 输出通道允许装入这个新 flit。
    assign arctrl_entry_req_select_success_flag_w = (arctrl_req_hi_retry_found_w | arctrl_req_hi_new_found_w | arctrl_req_lo_retry_found_w | arctrl_req_lo_new_found_w) & (arctrl_txreqflit_sent_s4_i | ~arctrl_txreqflitv_s4_o);

    //当前已经仲裁成功、准备用来组 TXREQ flit 的 entry 指针
    always @(posedge clk_i or posedge rst_i) begin
        if (rst_i == 1'b1)begin
            arctrl_entry_req_ptr_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] <= {RNI_AR_ENTRIES_NUM_PARAM{1'b0}};
        end
        else begin
            if(arctrl_entry_req_select_success_flag_w)begin
                arctrl_entry_req_ptr_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] <= arctrl_entry_req_ptr_ns_w[RNI_AR_ENTRIES_NUM_PARAM-1:0];
            end
        end
    end

    //相当于arctrl_entry_req_ptr_q的valid信号
    always @(posedge clk_i or posedge rst_i) begin
        if (rst_i == 1'b1)begin
            arctrl_entry_req_select_success_q <= 1'b0;
        end
        else begin
            arctrl_entry_req_select_success_q <= arctrl_entry_req_select_success_flag_w;
        end
    end

    //当某个entry选举成功 or 某个entry接收到retry or 某个entry被释放时更新
    always @(posedge clk_i or posedge rst_i) begin
        if (rst_i == 1'b1)begin
            arctrl_entry_req_select_vec_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] <= {RNI_AR_ENTRIES_NUM_PARAM{1'b0}};
        end
        else begin
            if(arctrl_entry_req_select_success_flag_w | rxrsp_retryack_recv_flag_w | arctrl_entry_dealloc_v_w)begin
                arctrl_entry_req_select_vec_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] <= arctrl_entry_req_select_vec_ns_w[RNI_AR_ENTRIES_NUM_PARAM-1:0];
            end
        end
    end

    //记录当前要组包发送的 TXREQ 是 retry 请求，还是 new 请求，与arctrl_entry_req_ptr_q，arctrl_entry_req_select_success_q同拍输出
    always @(posedge clk_i or posedge rst_i) begin
        if (rst_i == 1'b1)begin
            arctrl_entry_req_select_retry_flag_q <= 1'b0;
        end
        else begin
            if(arctrl_entry_req_select_success_flag_w)begin
                arctrl_entry_req_select_retry_flag_q <= arctrl_req_hi_retry_found_w | arctrl_req_lo_retry_found_w;
            end
        end
    end

    /////////////////////////////////////////////////////////////
    // txreq send
    /////////////////////////////////////////////////////////////

    //目标节点NODE ID
    assign ar_tx_send_nid_w[CHIE_NID_WIDTH_PARAM-1:0] = HNF_NID_PARAM;

    //生成TXN ID, TxnID 最高位 = 0，表示 read/AR entry,TxnID 低位表示 entry index，注意参数化一个是CHIE_REQ_FLIT_TXNID_WIDTH，一个是RNI_AR_ENTRIES_WIDTH
    always@* begin
        ar_txreq_txnid_r[`CHIE_REQ_FLIT_TXNID_WIDTH-1:0] = {`CHIE_REQ_FLIT_TXNID_WIDTH{1'b0}};
        ar_txreq_txnid_r[`CHIE_REQ_FLIT_TXNID_WIDTH-1] = 1'b0;  //0表示这是一个读请求
        for (i=0; i < RNI_AR_ENTRIES_NUM_PARAM; i=i+1)
            ar_txreq_txnid_r[`RNI_AR_ENTRIES_WIDTH-1:0] = ar_txreq_txnid_r[`RNI_AR_ENTRIES_WIDTH-1:0] | ({`RNI_AR_ENTRIES_WIDTH{arctrl_entry_req_ptr_q[i]}} & i);
    end

    //如果当前参数配置下 REQ flit 存在 RSVDC 字段，就把这个字段固定填 0，这个字段是预留给用户或具体实现自定义使用的字段
    generate
        if(CHIE_REQ_RSVDC_WIDTH_PARAM != 0)begin
            always @*begin
                ar_txreqflit_info_r[`CHIE_REQ_FLIT_RSVDC_RANGE] = {`CHIE_REQ_FLIT_RSVDC_WIDTH{1'b0}};
            end
        end
    endgenerate

    /*
        QOS        : [3:0],    4bit,  来自 AXI ARQOS
        TGTID      : [14:4],   11bit, HNF_NID_PARAM
        SRCID      : [25:15],  11bit, RNI_NID_PARAM
        TXNID      : [37:26],  12bit, {read标志0, entry index}
        ReturnNID  : [48:38],  11bit, 0
        Endian     : [49],     1bit,  0
        ReturnTxnID: [61:50],  12bit, 0
        Opcode     : [68:62],  7bit,  CHIE_READONCE
        Size       : [71:69],  3bit,  3'b110
        Addr       : [115:72], 44bit, 当前 segment 地址
        NS         : [116],    1bit,  0
        LikelyShared: [117],   1bit,  0
        AllowRetry : [118],    1bit,  new 请求为 1，retry 请求为 0
        Order      : [120:119],2bit,  2'b00
        PCRDType   : [124:121],4bit,  retry 请求使用 RetryAck 记录的 PCRDType，new 请求为 0
        MemAttr    : [128:125],4bit,  {Allocate, Cacheable, Device, EarlyWrAck}
        EarlyWrAck : [125],    1bit,  1
        Device     : [126],    1bit,  0
        Cacheable  : [127],    1bit,  1
        Allocate   : [128],    1bit,  来自 AXI ARCACHE
        SnpAttr    : [129],    1bit,  1
        LPID       : [137:130],8bit,  0
        Excl       : [138],    1bit,  0
        ExpCompAck : [139],    1bit,  0
        TagOp      : [141:140],2bit,  0
        TraceTag   : [142],    1bit,  0
        RSVDC      : 无,       0bit,  CHIE_REQ_RSVDC_WIDTH_PARAM = 0
    */
    always@* begin
        ar_txreqflit_info_r[`CHIE_REQ_FLIT_WIDTH-1:0] = {`CHIE_REQ_FLIT_WIDTH{1'b0}};//先全给0
        ar_txreqflit_info_r[`CHIE_REQ_FLIT_TGTID_RANGE] = ar_tx_send_nid_w[CHIE_NID_WIDTH_PARAM-1:0];
        ar_txreqflit_info_r[`CHIE_REQ_FLIT_SRCID_RANGE] = RNI_NID_PARAM;
        ar_txreqflit_info_r[`CHIE_REQ_FLIT_TXNID_RANGE] = ar_txreq_txnid_r[`CHIE_REQ_FLIT_TXNID_WIDTH-1:0];
        ar_txreqflit_info_r[`CHIE_REQ_FLIT_OPCODE_RANGE] = `CHIE_READONCE;   //固定发出传输为readonce请求
        ar_txreqflit_info_r[`CHIE_REQ_FLIT_ALLOWRETRY_RANGE] = ~arctrl_entry_req_select_retry_flag_q;
        ar_txreqflit_info_r[`CHIE_REQ_FLIT_ORDER_RANGE] = 2'b00;
        ar_txreqflit_info_r[`CHIE_REQ_FLIT_MEMATTR_EARLYWRACK_RANGE] = 1'b1;
        ar_txreqflit_info_r[`CHIE_REQ_FLIT_MEMATTR_DEVICE_RANGE] = 1'b0;
        ar_txreqflit_info_r[`CHIE_REQ_FLIT_MEMATTR_CACHEABLE_RANGE] = 1'b1;
        ar_txreqflit_info_r[`CHIE_REQ_FLIT_SNPATTR_RANGE] = 1'b1;
        ar_txreqflit_info_r[`CHIE_REQ_FLIT_LPID_RANGE] = {`CHIE_REQ_FLIT_LPID_WIDTH{1'b0}};
        ar_txreqflit_info_r[`CHIE_REQ_FLIT_SIZE_RANGE] = 3'b110;   //固定请求大小为64B
        ar_txreqflit_info_r[`CHIE_REQ_FLIT_EXPCOMPACK_RANGE] = 1'b0;
        for (i=0; i < RNI_AR_ENTRIES_NUM_PARAM; i=i+1)begin  //从entry中取有效信息
            ar_txreqflit_info_r[`CHIE_REQ_FLIT_QOS_RANGE] = ar_txreqflit_info_r[`CHIE_REQ_FLIT_QOS_RANGE] | ({`AXI4_ARQOS_WIDTH{arctrl_entry_req_ptr_q[i]}} & arctrl_entry_info_q[i][`AXI4_ARQOS_RANGE]);
            ar_txreqflit_info_r[`CHIE_REQ_FLIT_ADDR_RANGE] = ar_txreqflit_info_r[`CHIE_REQ_FLIT_ADDR_RANGE] | ({`AXI4_ARADDR_WIDTH{arctrl_entry_req_ptr_q[i]}} & arctrl_entry_addr_q[i][`AXI4_ARADDR_WIDTH-1:0]);
            ar_txreqflit_info_r[`CHIE_REQ_FLIT_PCRDTYPE_RANGE] = ~arctrl_entry_req_select_retry_flag_q ? {`CHIE_REQ_FLIT_PCRDTYPE_WIDTH{1'b0}} :
                               ar_txreqflit_info_r[`CHIE_REQ_FLIT_PCRDTYPE_RANGE] | ({`CHIE_RSP_FLIT_PCRDTYPE_WIDTH{arctrl_entry_req_ptr_q[i]}} & rxrsp_retryack_pcrdtype_q[i][`CHIE_RSP_FLIT_PCRDTYPE_WIDTH-1:0]);
            ar_txreqflit_info_r[`CHIE_REQ_FLIT_MEMATTR_ALLOCATE_RANGE] = ar_txreqflit_info_r[`CHIE_REQ_FLIT_MEMATTR_ALLOCATE_RANGE] | (arctrl_entry_req_ptr_q[i] & arctrl_entry_info_q[i][`AXI4_ARCACHE_MSB-1]);
        end
    end

    //如果下游没有接收当前 TXREQ flit，就在下一拍继续输出同一个 flit；如果下游已经接收，或者当前没有 pending flit，就可以输出新 flit。
    assign arctrl_txreqflitv_s4_o = arctrl_entry_req_select_success_q | (~ar_txreqflit_sent_s5_q & ar_txreqflitv_s5_q);//当前拍能不能输出取决于上一拍的状态

    //当前拍的数据是否保持取决于上一拍的状态，上一拍 S4 输出了有效 TXREQ flit，但上一拍没有被下游接收
    assign arctrl_txreqflit_s4_o[`CHIE_REQ_FLIT_WIDTH-1:0] = (~ar_txreqflit_sent_s5_q & ar_txreqflitv_s5_q) ? ar_txreqflit_s5_q[`CHIE_REQ_FLIT_WIDTH-1:0] : ar_txreqflit_info_r[`CHIE_REQ_FLIT_WIDTH-1:0];

    always @(posedge clk_i or posedge rst_i) begin
        if (rst_i == 1'b1)begin
            ar_txreqflitv_s5_q <= 1'b0;
        end
        else begin
            ar_txreqflitv_s5_q <= arctrl_txreqflitv_s4_o;
        end
    end

    always @(posedge clk_i or posedge rst_i) begin
        if (rst_i == 1'b1)begin
            ar_txreqflit_s5_q[`CHIE_REQ_FLIT_WIDTH-1:0] <= {`CHIE_REQ_FLIT_WIDTH{1'b0}};
        end
        else begin
            ar_txreqflit_s5_q[`CHIE_REQ_FLIT_WIDTH-1:0]<= arctrl_txreqflit_s4_o[`CHIE_REQ_FLIT_WIDTH-1:0];
        end
    end

    always @(posedge clk_i or posedge rst_i) begin
        if (rst_i == 1'b1)begin
            ar_txreqflit_sent_s5_q <= 1'b0;
        end
        else begin
            ar_txreqflit_sent_s5_q<= arctrl_txreqflit_sent_s4_i;
        end
    end

    /////////////////////////////////////////////////////////////
    // rxrsp
    /////////////////////////////////////////////////////////////
    assign arctrl_entry_rxrsp_tgtid_w[`CHIE_RSP_FLIT_TGTID_WIDTH-1:0]       = rxrspflit_d1_i[`CHIE_RSP_FLIT_TGTID_RANGE];
    assign arctrl_entry_rxrsp_srcid_w[`CHIE_RSP_FLIT_SRCID_WIDTH-1:0]       = rxrspflit_d1_i[`CHIE_RSP_FLIT_SRCID_RANGE];
    assign arctrl_entry_rxrsp_txnid_w[`CHIE_RSP_FLIT_TXNID_WIDTH-1:0]       = rxrspflit_d1_i[`CHIE_RSP_FLIT_TXNID_RANGE];
    assign arctrl_entry_rxrsp_opcode_w[`CHIE_RSP_FLIT_OPCODE_WIDTH-1:0]     = rxrspflit_d1_i[`CHIE_RSP_FLIT_OPCODE_RANGE];
    assign arctrl_entry_rxrsp_pcrdtype_w[`CHIE_RSP_FLIT_PCRDTYPE_WIDTH-1:0] = rxrspflit_d1_i[`CHIE_RSP_FLIT_PCRDTYPE_RANGE];

    //resp数据有效，且为读请求，且这个 RXRSP 的目标节点是当前 RNI，代表响应flit有效
    assign ar_rxrsp_correct_w = rxrspflitv_d1_i & ~arctrl_entry_rxrsp_txnid_w[`CHIE_RSP_FLIT_TXNID_WIDTH-1] & (arctrl_entry_rxrsp_tgtid_w[`CHIE_RSP_FLIT_TGTID_WIDTH-1:0] == RNI_NID_PARAM);
    
    //当前flit是一个retry响应
    assign rxrsp_retryack_recv_flag_w = ar_rxrsp_correct_w & (arctrl_entry_rxrsp_opcode_w[`CHIE_RSP_FLIT_OPCODE_WIDTH-1:0] == `CHIE_RETRYACK);
    
    //标记当前拍哪个 AR entry 收到了 RetryAck
    assign rxrsp_retryack_recv_vec_w[RNI_AR_ENTRIES_NUM_PARAM-1:0] = {RNI_AR_ENTRIES_NUM_PARAM{rxrsp_retryack_recv_flag_w}} & arctrl_rxrsp_ptr_r[RNI_AR_ENTRIES_NUM_PARAM-1:0];

    //标记已经收到 RetryAck、并且当前仍处于等待 PCRDGrant / retry 状态的 entry 集合
    assign rxrsp_retryack_recv_vec_ns_w[RNI_AR_ENTRIES_NUM_PARAM-1:0] = (rxrsp_retryack_recv_vec_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] | rxrsp_retryack_recv_vec_w[RNI_AR_ENTRIES_NUM_PARAM-1:0]) & ~arctrl_entry_dealloc_vec_w[RNI_AR_ENTRIES_NUM_PARAM-1:0];

    //表示来了 PCRDGrant
    assign rxrsp_pcrdgrant_recv_flag_w = pcrdgnt_pkt_v_d2_i;

    //告诉外部 PCRDGrant 仲裁逻辑：AR 侧当前有 high-QoS entry 匹配到了 PCRDGrant
    assign arctrl_pcrdgnt_h_present_d3_o = rxrsp_pcrdtype_hi_match_d3_q;  

    //告诉外部 PCRDGrant 仲裁逻辑：AR 侧当前有 low-QoS entry 匹配到了 PCRDGrant
    assign arctrl_pcrdgnt_l_present_d3_o = rxrsp_pcrdtype_lo_match_d3_q;

    //表示 AR 侧 high-QoS 的 PCRDGrant 匹配项最终被外部仲裁选中了
    assign rxrsp_pcrdtype_hi_select_w = ar_pcrdgnt_h_win_d3_i & rxrsp_pcrdtype_hi_match_d3_q;

    //表示 AR 侧 low-QoS 的 PCRDGrant 匹配项最终被外部仲裁选中了
    assign rxrsp_pcrdtype_lo_select_w = ar_pcrdgnt_l_win_d3_i & rxrsp_pcrdtype_lo_match_d3_q;

    //high-QoS PCRDGrant 匹配选择器的下一轮 start_entry
    assign rxrsp_pcrdgrant_hi_upd_ptr_ns_w[RNI_AR_ENTRIES_NUM_PARAM-1:0] = {RNI_AR_ENTRIES_NUM_PARAM{rxrsp_pcrdtype_hi_select_w}} & rxrsp_pcrdgrant_hi_recv_vec_d3_q[RNI_AR_ENTRIES_NUM_PARAM-1:0];
    
    //low-QoS PCRDGrant 匹配选择器的下一轮 start_entry
    assign rxrsp_pcrdgrant_lo_upd_ptr_ns_w[RNI_AR_ENTRIES_NUM_PARAM-1:0] = {RNI_AR_ENTRIES_NUM_PARAM{rxrsp_pcrdtype_lo_select_w}} & rxrsp_pcrdgrant_lo_recv_vec_d3_q[RNI_AR_ENTRIES_NUM_PARAM-1:0];

    //哪些 entry 已经拿到了 PCRDGrant，可以进入 retry TXREQ 发送流程，高优先级加高优先级，低优先级加低优先级，释放的entry清0
    assign rxrsp_pcrdgrant_recv_vec_ns_w[RNI_AR_ENTRIES_NUM_PARAM-1:0] = (rxrsp_pcrdgrant_recv_vec_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] |
            (({RNI_AR_ENTRIES_NUM_PARAM{rxrsp_pcrdtype_hi_select_w}} & rxrsp_pcrdgrant_hi_recv_vec_d3_q[RNI_AR_ENTRIES_NUM_PARAM-1:0]) |
             ({RNI_AR_ENTRIES_NUM_PARAM{rxrsp_pcrdtype_lo_select_w}} & rxrsp_pcrdgrant_lo_recv_vec_d3_q[RNI_AR_ENTRIES_NUM_PARAM-1:0]))) &
           ~arctrl_entry_dealloc_vec_w[RNI_AR_ENTRIES_NUM_PARAM-1:0];

    //判断当前resp flit对应哪个entry
    generate
        for (entry=0; entry < RNI_AR_ENTRIES_NUM_PARAM; entry=entry+1) begin:rxrsp_ptr
            always@* begin
                if(entry == arctrl_entry_rxrsp_txnid_w[`RNI_AR_ENTRIES_WIDTH-1:0])begin
                    arctrl_rxrsp_ptr_r[entry] = 1'b1;
                end
                else begin
                    arctrl_rxrsp_ptr_r[entry] = 1'b0;
                end
            end
        end
    endgenerate

    //找出匹配的PCRDGrant type的entry，准备分别进行仲裁发送
    generate
        for (entry=0; entry < RNI_AR_ENTRIES_NUM_PARAM; entry=entry+1) begin:pcrdtype_match
            always@* begin  
                //收到PCRDgrant，已经收到retryAck的entry，当前 entry 还没有收到过 PCRDGrant且本周期也还没有被标记要收到PCRDGrant
                if(rxrsp_pcrdgrant_recv_flag_w & rxrsp_retryack_recv_vec_q[entry] & ~(rxrsp_pcrdgrant_recv_vec_q[entry] | rxrsp_pcrdgrant_recv_vec_ns_w[entry]))begin
                    //PCRDGrant type要匹配，sourceID要匹配下游HN NODE id，targetID要匹配本地RN NODE id，并且为高优先级队列
                    rxrsp_pcrdgrant_hi_rdy_vec_r[entry] = (pcrdgnt_pkt_d2_i[`PCRDGRANT_PKT_PCRDTYPE_RANGE] == rxrsp_retryack_pcrdtype_q[entry][`CHIE_RSP_FLIT_PCRDTYPE_WIDTH-1:0]) &&
                                                (pcrdgnt_pkt_d2_i[`PCRDGRANT_PKT_SRCID_RANGE] == ar_tx_send_nid_w[CHIE_NID_WIDTH_PARAM-1:0]) &&
                                                (pcrdgnt_pkt_d2_i[`PCRDGRANT_PKT_TGTID_RANGE] == RNI_NID_PARAM) && arctrl_entry_qos_hi_q[entry];
                end
                else begin
                    rxrsp_pcrdgrant_hi_rdy_vec_r[entry] = 1'b0;
                end
            end

            //低优先级队列
            always@* begin
                if(rxrsp_pcrdgrant_recv_flag_w & rxrsp_retryack_recv_vec_q[entry] & ~(rxrsp_pcrdgrant_recv_vec_q[entry] | rxrsp_pcrdgrant_recv_vec_ns_w[entry]))begin
                    rxrsp_pcrdgrant_lo_rdy_vec_r[entry] = (pcrdgnt_pkt_d2_i[`PCRDGRANT_PKT_PCRDTYPE_RANGE] == rxrsp_retryack_pcrdtype_q[entry][`CHIE_RSP_FLIT_PCRDTYPE_WIDTH-1:0]) &&
                                                (pcrdgnt_pkt_d2_i[`PCRDGRANT_PKT_SRCID_RANGE] == ar_tx_send_nid_w[CHIE_NID_WIDTH_PARAM-1:0]) &&
                                                (pcrdgnt_pkt_d2_i[`PCRDGRANT_PKT_TGTID_RANGE] == RNI_NID_PARAM) && ~arctrl_entry_qos_hi_q[entry];
                end
                else begin
                    rxrsp_pcrdgrant_lo_rdy_vec_r[entry] = 1'b0;
                end
            end
        end
    endgenerate

    
    // s2 selects entry, s3 knows whether it is successful, and s4 updates rxrsp_pcrdgrant_hi_upd_ptr_q/rxrsp_pcrdgrant_recv_vec_q,
    // it is necessary to consider the situation of two consecutive beats.
    
    //表示所有 high-QoS、且匹配当前 PCRDGrant 的 entry 集合
    poll_with_start_entry
        #(
            .ENTRIES_NUM(RNI_AR_ENTRIES_NUM_PARAM)
        )
        pcrdtype_hi_select(
            .entry_vec(rxrsp_pcrdgrant_hi_rdy_vec_r[RNI_AR_ENTRIES_NUM_PARAM-1:0])
            ,.start_entry(rxrsp_pcrdtype_hi_select_w ? rxrsp_pcrdgrant_hi_upd_ptr_ns_w[RNI_AR_ENTRIES_NUM_PARAM-1:0] : rxrsp_pcrdgrant_hi_upd_ptr_q[RNI_AR_ENTRIES_NUM_PARAM-1:0])
            ,.entry_ptr_sel(rxrsp_pcrdgrant_hi_recv_vec_d2_w[RNI_AR_ENTRIES_NUM_PARAM-1:0])
            ,.found(rxrsp_pcrdtype_hi_match_d2_w)
        );

    //表示所有 low-QoS、且匹配当前 PCRDGrant 的 entry 集合
    poll_with_start_entry
        #(
            .ENTRIES_NUM(RNI_AR_ENTRIES_NUM_PARAM)
        )
        pcrdtype_lo_select(
            .entry_vec(rxrsp_pcrdgrant_lo_rdy_vec_r[RNI_AR_ENTRIES_NUM_PARAM-1:0])
            ,.start_entry(rxrsp_pcrdtype_lo_select_w ? rxrsp_pcrdgrant_lo_upd_ptr_ns_w[RNI_AR_ENTRIES_NUM_PARAM-1:0] : rxrsp_pcrdgrant_lo_upd_ptr_q[RNI_AR_ENTRIES_NUM_PARAM-1:0])
            ,.entry_ptr_sel(rxrsp_pcrdgrant_lo_recv_vec_d2_w[RNI_AR_ENTRIES_NUM_PARAM-1:0])
            ,.found(rxrsp_pcrdtype_lo_match_d2_w)
        );


    //打一拍存储仲裁结果与valid标识
    always @(posedge clk_i or posedge rst_i) begin
        if (rst_i == 1'b1)begin
            rxrsp_pcrdtype_hi_match_d3_q <= 1'b0;
        end
        else begin
            rxrsp_pcrdtype_hi_match_d3_q <= rxrsp_pcrdtype_hi_match_d2_w;
        end
    end

    always @(posedge clk_i or posedge rst_i) begin
        if (rst_i == 1'b1)begin
            rxrsp_pcrdgrant_hi_recv_vec_d3_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] <= {RNI_AR_ENTRIES_NUM_PARAM{1'b0}};
        end
        else begin
            rxrsp_pcrdgrant_hi_recv_vec_d3_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] <= rxrsp_pcrdgrant_hi_recv_vec_d2_w[RNI_AR_ENTRIES_NUM_PARAM-1:0];
        end
    end

    always @(posedge clk_i or posedge rst_i) begin
        if (rst_i == 1'b1)begin
            rxrsp_pcrdtype_lo_match_d3_q <= 1'b0;
        end
        else begin
            rxrsp_pcrdtype_lo_match_d3_q <= rxrsp_pcrdtype_lo_match_d2_w;
        end
    end

    always @(posedge clk_i or posedge rst_i) begin
        if (rst_i == 1'b1)begin
            rxrsp_pcrdgrant_lo_recv_vec_d3_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] <= {RNI_AR_ENTRIES_NUM_PARAM{1'b0}};
        end
        else begin
            rxrsp_pcrdgrant_lo_recv_vec_d3_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] <= rxrsp_pcrdgrant_lo_recv_vec_d2_w[RNI_AR_ENTRIES_NUM_PARAM-1:0];
        end
    end

    //如果某个entry 接收到 RetryAck 了，需要记录 RetryAck 中的 PCRDType；后续收到 PCRDGrant 时，用这个 PCRDType 做匹配；retry 重新发送 TXREQ 时，也要把这个 PCRDType 带回 REQ flit。
    generate
        for (entry=0; entry < RNI_AR_ENTRIES_NUM_PARAM; entry=entry+1) begin:rxrsp_info
            always @(posedge clk_i or posedge rst_i) begin
                if (rst_i == 1'b1)begin
                    rxrsp_retryack_pcrdtype_q[entry][`CHIE_RSP_FLIT_PCRDTYPE_WIDTH-1:0] <= {`CHIE_RSP_FLIT_PCRDTYPE_WIDTH{1'b0}};
                end
                else begin
                    if(rxrsp_retryack_recv_vec_w[entry])begin
                        rxrsp_retryack_pcrdtype_q[entry][`CHIE_RSP_FLIT_PCRDTYPE_WIDTH-1:0] <= arctrl_entry_rxrsp_pcrdtype_w[`CHIE_RSP_FLIT_PCRDTYPE_WIDTH-1:0];
                    end
                    else if(arctrl_entry_dealloc_vec_w[entry])begin  //entry被释放时清0
                        rxrsp_retryack_pcrdtype_q[entry][`CHIE_RSP_FLIT_PCRDTYPE_WIDTH-1:0] <= {`CHIE_RSP_FLIT_PCRDTYPE_WIDTH{1'b0}};
                    end
                end
            end
        end
    endgenerate

    //时序逻辑更新寄存器的数值
    //哪些 entry 已经收到 RetryAck，并且还没释放
    always @(posedge clk_i or posedge rst_i) begin
        if (rst_i == 1'b1)begin
            rxrsp_retryack_recv_vec_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] <= {RNI_AR_ENTRIES_NUM_PARAM{1'b0}};
        end
        else begin
            if(rxrsp_retryack_recv_flag_w | arctrl_entry_dealloc_v_w)begin
                rxrsp_retryack_recv_vec_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] <= rxrsp_retryack_recv_vec_ns_w[RNI_AR_ENTRIES_NUM_PARAM-1:0];
            end
        end
    end

    //high-QoS PCRDGrant 匹配仲裁的轮询起点
    always @(posedge clk_i or posedge rst_i) begin
        if (rst_i == 1'b1)begin
            rxrsp_pcrdgrant_hi_upd_ptr_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] <= {RNI_AR_ENTRIES_NUM_PARAM{1'b0}};
        end
        else begin
            if(rxrsp_pcrdtype_hi_select_w)begin
                rxrsp_pcrdgrant_hi_upd_ptr_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] <= rxrsp_pcrdgrant_hi_upd_ptr_ns_w[RNI_AR_ENTRIES_NUM_PARAM-1:0];
            end
        end
    end

    //low-QoS PCRDGrant 匹配仲裁的轮询起点
    always @(posedge clk_i or posedge rst_i) begin
        if (rst_i == 1'b1)begin
            rxrsp_pcrdgrant_lo_upd_ptr_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] <= {RNI_AR_ENTRIES_NUM_PARAM{1'b0}};
        end
        else begin
            if(rxrsp_pcrdtype_lo_select_w)begin
                rxrsp_pcrdgrant_lo_upd_ptr_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] <= rxrsp_pcrdgrant_lo_upd_ptr_ns_w[RNI_AR_ENTRIES_NUM_PARAM-1:0];
            end
        end
    end
    
    //哪些 entry 已经收到匹配的 PCRDGrant，可以 retry 发送 TXREQ
    always @(posedge clk_i or posedge rst_i) begin
        if (rst_i == 1'b1)begin
            rxrsp_pcrdgrant_recv_vec_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] <= {RNI_AR_ENTRIES_NUM_PARAM{1'b0}};
        end
        else begin
            if(rxrsp_pcrdtype_hi_select_w | rxrsp_pcrdtype_lo_select_w | arctrl_entry_dealloc_v_w)begin
                rxrsp_pcrdgrant_recv_vec_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] <= rxrsp_pcrdgrant_recv_vec_ns_w[RNI_AR_ENTRIES_NUM_PARAM-1:0];
            end
        end
    end

    /////////////////////////////////////////////////////////////
    // rdata
    /////////////////////////////////////////////////////////////
    assign arctrl_rdat_pdmask_ns_w[`RNI_DMASK_PD_WIDTH-1:0] = arctrl_rdat_pdmask_r[`RNI_DMASK_PD_WIDTH-1:0] & (~arctrl_rdat_ctmask_r[`RNI_DMASK_CT_WIDTH-1:0]);
    assign rxdat_recv_done_flag_w = |rxdat_recv_done_vec_r[RNI_AR_ENTRIES_NUM_PARAM-1:0];
    assign rdata_select_adv_w = rp_fifo_acpt_d4_i | (!arctrl_rb_valid_d4_o);
    
        
    assign arctrl_rb_valid_d4_o = |arctrl_rdata_send_q[RNI_AR_ENTRIES_NUM_PARAM-1:0];
    assign arctrl_rb_ctmask_d4_o[`RNI_DMASK_CT_WIDTH-1:0] = arctrl_rdat_ctmask_r[`RNI_DMASK_CT_WIDTH-1:0];
    assign arctrl_rb_rlast_d4_o = |(arctrl_rdat_ctmask_r[`RNI_DMASK_CT_WIDTH-1:0] & arctrl_rdat_lsmask_r[`RNI_DMASK_LS_WIDTH-1:0]); //两个独热码一掩就得到last
    assign arctrl_rb_rid_d4_o[`AXI4_ARID_WIDTH-1:0] = arctrl_rdat_axid_r[`AXI4_ARID_WIDTH-1:0];
    assign arctrl_rb_idx_d4_o[`RNI_AR_ENTRIES_WIDTH-1:0] = arctrl_rdata_entry_idx_r[`RNI_AR_ENTRIES_WIDTH-1:0];
    assign arctrl_rb_bc_d4_o[`RNI_BC_WIDTH-1:0] = arctrl_rdata_bc_r[`RNI_BC_WIDTH-1:0];

    //得到下一个返回的Bank Index，arctrl_rdat_pdmask_r 的含义是当前被 arctrl_rdata_send_q 选中的 entry，还需要返回给 AXI R 通道的 bank mask。
    poll_with_start_entry
        #(
            .ENTRIES_NUM(`RNI_DMASK_CT_WIDTH)
        )
        arctrl_ctmask_ns(
            .entry_vec(arctrl_rdat_pdmask_r[`RNI_DMASK_PD_WIDTH-1:0] & (~arctrl_rdat_ctmask_r[`RNI_DMASK_CT_WIDTH-1:0]))
            ,.start_entry({`RNI_DMASK_CT_WIDTH{1'b0}})
            ,.entry_ptr_sel(arctrl_rdat_ctmask_ns_w[`RNI_DMASK_CT_WIDTH-1:0])
            ,.found()
        );

    //从所有entry中仲裁出要输出给AXI Rdata通道的entry
    poll_with_start_entry
        #(
            .ENTRIES_NUM(RNI_AR_ENTRIES_NUM_PARAM)
        )
        arctrl_rdata_entry(
            .entry_vec(arctrl_rdata_rdy_r[RNI_AR_ENTRIES_NUM_PARAM-1:0])
            ,.start_entry(arctrl_rdata_start_ptr_q[RNI_AR_ENTRIES_NUM_PARAM-1:0])
            ,.entry_ptr_sel(arctrl_rdata_select_w[RNI_AR_ENTRIES_NUM_PARAM-1:0])
            ,.found()
        );

    generate
        for (entry=0; entry < RNI_AR_ENTRIES_NUM_PARAM; entry=entry+1) begin:rxdat_ptr
            //根据当前收到的 RXDAT flit 的 TxnID，解码出它属于哪个 AR entry
            always@* begin
                if((entry == rxdat_txnid_q[`RNI_AR_ENTRIES_WIDTH-1:0]) && rxdat_flitv_q)begin
                    arctrl_rxdat_ptr_r[entry] = 1'b1;
                end
                else begin
                    arctrl_rxdat_ptr_r[entry] = 1'b0;
                end
            end

            //arctrl_rdata_rdy_r用于标识 entry 当前是否可以参与 RDATA 返回仲裁，arctrl_entry_rdata_dep_v_q用于RDATA chain锁定
            //arctrl_entry_rdata_dep_v_q信号用于标识本entry的data是否依赖别的entry
            always@* begin
                if(|(arctrl_entry_rvmask_q[entry] & ((arctrl_rdat_ctmask_ns_w[`RNI_DMASK_CT_WIDTH-1:0] & {`RNI_DMASK_CT_WIDTH{rp_fifo_acpt_d4_i & arctrl_rdata_send_q[entry]}}) |
                                                     (arctrl_entry_ctmask_q[entry] & {`RNI_DMASK_CT_WIDTH{~rp_fifo_acpt_d4_i}}))) && (~arctrl_entry_rdata_dep_v_q[entry]))begin
                    arctrl_rdata_rdy_r[entry] = 1'b1;
                end
                else begin
                    arctrl_rdata_rdy_r[entry] = 1'b0;
                end
            end
        end
    endgenerate

    
    always@* begin
        arctrl_rdata_bc_r[`RNI_BCVEC_WIDTH-1:0] = arctrl_rdat_bcvec_r[`RNI_BCVEC_WIDTH-1:0];
        arctrl_rdata_bc_break_r = 1'b0;
        for (i=0; i < `RNI_DMASK_CT_WIDTH; i=i+1)begin
            if((!arctrl_rdat_ctmask_r[i]) && (!arctrl_rdata_bc_break_r))begin
                arctrl_rdata_bc_r[`RNI_BCVEC_WIDTH-1:0] = arctrl_rdata_bc_r[`RNI_BCVEC_WIDTH-1:0] >> `RNI_BC_WIDTH;
                arctrl_rdata_bc_break_r = 1'b0;
            end
            else begin
                arctrl_rdata_bc_r[`RNI_BCVEC_WIDTH-1:0] =  arctrl_rdata_bc_r[`RNI_BCVEC_WIDTH-1:0];
                arctrl_rdata_bc_break_r = 1'b1;
            end
        end
    end

    //表示当前哪个 arctrl_entry 正在向 rni_rd_buffer 发起 RDATA 返回调度
    always@* begin
        arctrl_rdata_entry_idx_r[`RNI_AR_ENTRIES_WIDTH-1:0] = {`RNI_AR_ENTRIES_WIDTH{1'b0}};
        for (i=0; i < RNI_AR_ENTRIES_NUM_PARAM; i=i+1)begin
            if(arctrl_rdata_send_q[i])begin
                arctrl_rdata_entry_idx_r[`RNI_AR_ENTRIES_WIDTH-1:0] = i;
            end
        end
    end

    //rxdat_recv_done_vec_r用于标识 entry 的 RXDAT 是否已经收齐
    always@* begin
        rxdat_recv_done_vec_r[RNI_AR_ENTRIES_NUM_PARAM-1:0] = {RNI_AR_ENTRIES_NUM_PARAM{1'b0}};
        for (i=0; i < RNI_AR_ENTRIES_NUM_PARAM; i=i+1)begin
            if(arctrl_rxdat_ptr_r[i])begin
                //表示这个 entry 之前已经收到哪些 16B bank/ 表示当前这个 RXDAT flit 带回来的是哪半条 cacheline 
                //判断当前已收到的 bank，是否已经覆盖了这个 entry 需要的所有 bank，rxdat_dataid_q[1]=1表示高32B，rxdat_dataid_q[1]=0表示低32B
                rxdat_recv_done_vec_r[i] = (((arctrl_entry_rvmask_q[i][`RNI_DMASK_RV_WIDTH-1:0] | {{2{rxdat_dataid_q[1]}},{2{~rxdat_dataid_q[1]}}}) &
                                             arctrl_entry_pdmask_q[i][`RNI_DMASK_PD_WIDTH-1:0]) == arctrl_entry_pdmask_q[i][`RNI_DMASK_PD_WIDTH-1:0]);  //&arctrl_entry_pdmask_q的作用是DAT通道可能返回过量的数据，掩掉无用数据
            end
        end
    end

    //从当前被 arctrl_rdata_send_q 选中的 entry 中取出RDATA返回所需的信息
    always@* begin
        arctrl_rdat_ctmask_r[`RNI_DMASK_CT_WIDTH-1:0] = {`RNI_DMASK_CT_WIDTH{1'b0}};
        arctrl_rdat_pdmask_r[`RNI_DMASK_PD_WIDTH-1:0] = {`RNI_DMASK_PD_WIDTH{1'b0}};
        arctrl_rdat_lsmask_r[`RNI_DMASK_LS_WIDTH-1:0] = {`RNI_DMASK_LS_WIDTH{1'b0}};
        arctrl_rdat_axid_r[`AXI4_ARID_WIDTH-1:0] = {`AXI4_ARID_WIDTH{1'b0}};
        arctrl_rdat_bcvec_r[`RNI_BCVEC_WIDTH-1:0] = {`RNI_BCVEC_WIDTH{1'b0}};
        for (i=0; i < RNI_AR_ENTRIES_NUM_PARAM; i=i+1)begin
            arctrl_rdat_ctmask_r[`RNI_DMASK_CT_WIDTH-1:0] = arctrl_rdat_ctmask_r[`RNI_DMASK_CT_WIDTH-1:0] | ({`RNI_DMASK_CT_WIDTH{arctrl_rdata_send_q[i]}} & arctrl_entry_ctmask_q[i][`RNI_DMASK_CT_WIDTH-1:0]);
            arctrl_rdat_pdmask_r[`RNI_DMASK_PD_WIDTH-1:0] = arctrl_rdat_pdmask_r[`RNI_DMASK_PD_WIDTH-1:0] | ({`RNI_DMASK_PD_WIDTH{arctrl_rdata_send_q[i]}} & arctrl_entry_pdmask_q[i][`RNI_DMASK_PD_WIDTH-1:0]);
            arctrl_rdat_lsmask_r[`RNI_DMASK_LS_WIDTH-1:0] = arctrl_rdat_lsmask_r[`RNI_DMASK_LS_WIDTH-1:0] | ({`RNI_DMASK_LS_WIDTH{arctrl_rdata_send_q[i]}} & arctrl_entry_lsmask_q[i][`RNI_DMASK_LS_WIDTH-1:0]);
            arctrl_rdat_axid_r[`AXI4_ARID_WIDTH-1:0] = arctrl_rdat_axid_r[`AXI4_ARID_WIDTH-1:0] | ({`AXI4_ARID_WIDTH{arctrl_rdata_send_q[i]}} & arctrl_entry_info_q[i][`AXI4_ARID_RANGE]);
            arctrl_rdat_bcvec_r[`RNI_BCVEC_WIDTH-1:0] = arctrl_rdat_bcvec_r[`RNI_BCVEC_WIDTH-1:0] | ({`RNI_BCVEC_WIDTH{arctrl_rdata_send_q[i]}} & arctrl_entry_bcvec_q[i][`RNI_BCVEC_WIDTH-1:0]);
        end
    end

    //分别对rxdatflitv_d1_i，rxdatflit_txnid_d1_i，rxdatflit_dataid_d1_i信号进行打拍寄存
    always @(posedge clk_i or posedge rst_i) begin
        if (rst_i == 1'b1)begin
            rxdat_flitv_q <= 1'b0;
        end
        else begin
            rxdat_flitv_q <= rxdatflitv_d1_i;
        end
    end

    always @(posedge clk_i or posedge rst_i) begin
        if (rst_i == 1'b1)begin
            rxdat_txnid_q[`CHIE_DAT_FLIT_TXNID_WIDTH-1:0] <= {`CHIE_DAT_FLIT_TXNID_WIDTH{1'b0}};
        end
        else begin
            rxdat_txnid_q[`CHIE_DAT_FLIT_TXNID_WIDTH-1:0] <= rxdatflit_txnid_d1_i[`CHIE_DAT_FLIT_TXNID_WIDTH-1:0];
        end
    end

    always @(posedge clk_i or posedge rst_i) begin
        if (rst_i == 1'b1)begin
            rxdat_dataid_q[`CHIE_DAT_FLIT_DATAID_WIDTH-1:0] <= {`CHIE_DAT_FLIT_DATAID_WIDTH{1'b0}};
        end
        else begin
            rxdat_dataid_q[`CHIE_DAT_FLIT_DATAID_WIDTH-1:0] <= rxdatflit_dataid_d1_i[`CHIE_DAT_FLIT_DATAID_WIDTH-1:0];
        end
    end

    //用于仲裁结果更新
    always @(posedge clk_i or posedge rst_i) begin
        if (rst_i == 1'b1)begin
            arctrl_rdata_start_ptr_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] <= {RNI_AR_ENTRIES_NUM_PARAM{1'b0}};
        end
        else if(rdata_select_adv_w)begin
            arctrl_rdata_start_ptr_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] <= arctrl_rdata_select_w[RNI_AR_ENTRIES_NUM_PARAM-1:0];
        end
    end

    //当前正在输出哪个entry的rdata
    always @(posedge clk_i or posedge rst_i) begin
        if (rst_i == 1'b1)begin
            arctrl_rdata_send_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] <= {RNI_AR_ENTRIES_NUM_PARAM{1'b0}};
        end
        else if(rdata_select_adv_w)begin
            arctrl_rdata_send_q[RNI_AR_ENTRIES_NUM_PARAM-1:0] <= arctrl_rdata_select_w[RNI_AR_ENTRIES_NUM_PARAM-1:0];
        end
    end

    generate
        for (entry=0; entry < RNI_AR_ENTRIES_NUM_PARAM; entry=entry+1) begin:arctrl_mask
            //标识已经接收的数据bank
            always @(posedge clk_i or posedge rst_i) begin
                if (rst_i == 1'b1)begin
                    arctrl_entry_rvmask_q[entry][`RNI_DMASK_RV_WIDTH-1:0] <={`RNI_DMASK_RV_WIDTH{1'b0}};
                end
                else begin
                    if(arctrl_alloc_ptr_s2_q[entry] == 1'b1)begin
                        arctrl_entry_rvmask_q[entry][`RNI_DMASK_RV_WIDTH-1:0] <= arlink_dmask_s2_w[`RNI_DMASK_RV_RANGE];//初始清0
                    end
                    else if(arctrl_rxdat_ptr_r[entry])begin //根据收到的entry信息进行RVMASK的更新
                        arctrl_entry_rvmask_q[entry][`RNI_DMASK_RV_WIDTH-1:0] <= arctrl_entry_rvmask_q[entry][`RNI_DMASK_RV_WIDTH-1:0] | {{2{rxdat_dataid_q[1]}},{2{~rxdat_dataid_q[1]}}};
                    end

                end
            end

            always @(posedge clk_i or posedge rst_i) begin
                if (rst_i == 1'b1)begin
                    arctrl_entry_ctmask_q[entry][`RNI_DMASK_CT_WIDTH-1:0] <={`RNI_DMASK_CT_WIDTH{1'b0}};
                end
                else begin
                    //锁存S2吐出的CTMASK信息
                    if(arctrl_alloc_ptr_s2_q[entry] == 1'b1)begin
                        arctrl_entry_ctmask_q[entry][`RNI_DMASK_CT_WIDTH-1:0] <= arlink_dmask_s2_w[`RNI_DMASK_CT_RANGE];
                    end
                    //更新各个entry的CTMASK信息
                    else if(arctrl_rdata_send_q[entry] && rp_fifo_acpt_d4_i)begin
                        arctrl_entry_ctmask_q[entry][`RNI_DMASK_CT_WIDTH-1:0] <= arctrl_rdat_ctmask_ns_w[`RNI_DMASK_CT_WIDTH-1:0];
                    end
                end
            end

            always @(posedge clk_i or posedge rst_i) begin
                if (rst_i == 1'b1)begin
                    arctrl_entry_pdmask_q[entry][`RNI_DMASK_PD_WIDTH-1:0] <={`RNI_DMASK_PD_WIDTH{1'b0}};
                end
                else begin
                    //锁存S2吐出的PDMASK信息
                    if(arctrl_alloc_ptr_s2_q[entry] == 1'b1)begin
                        arctrl_entry_pdmask_q[entry][`RNI_DMASK_PD_WIDTH-1:0] <= arlink_dmask_s2_w[`RNI_DMASK_PD_RANGE];
                    end
                    //这个 entry 下一次 AXI RDATA 应该返回哪个 16B bank
                    else if(arctrl_rdata_send_q[entry] && rp_fifo_acpt_d4_i)begin
                        arctrl_entry_pdmask_q[entry][`RNI_DMASK_PD_WIDTH-1:0] <= arctrl_rdat_pdmask_ns_w[`RNI_DMASK_PD_WIDTH-1:0];
                    end
                end
            end
        end
    endgenerate

    /////////////////////////////////////////////////////////////
    // dealloc
    /////////////////////////////////////////////////////////////
    
    //entry的释放向量,多bit
    assign arctrl_entry_dealloc_vec_w[RNI_AR_ENTRIES_NUM_PARAM-1:0] = {RNI_AR_ENTRIES_NUM_PARAM{rp_fifo_acpt_d4_i && !(|arctrl_rdat_pdmask_ns_w[`RNI_DMASK_PD_WIDTH-1:0])}} & arctrl_rdata_send_q;
    
    //是否有任何一个entry被释放,单bit
    assign arctrl_entry_dealloc_v_w = |arctrl_entry_dealloc_vec_w[RNI_AR_ENTRIES_NUM_PARAM-1:0];  
    
endmodule
