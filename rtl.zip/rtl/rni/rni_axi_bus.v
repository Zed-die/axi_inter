/*
* Copyright (c) 2024 Beijing Institute of Open Source Chip
* OpenNoC is licensed under Mulan PSL v2.
* You can use this software according to the terms and conditions of the Mulan PSL v2.
* You may obtain a copy of Mulan PSL v2 at:
*          http://license.coscl.org.cn/MulanPSL2
* THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
* MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
* See the Mulan PSL v2 for more details.
*
* Author:
*    Ziqing Li <liziqing@bosc.ac.cn>
*    Wenhao Li <liwenhao@bosc.ac.cn>
*/

`include "../include/rni_param.v"
`include "../include/axi4_defines.v"

//总线聚合模块
module rni_axi_bus `RNI_PARAM
    (
        // AW Channel0
        AWID0
        ,AWADDR0
        ,AWLEN0
        ,AWSIZE0
        ,AWBURST0
        ,AWLOCK0
        ,AWCACHE0
        ,AWPROT0
        ,AWQOS0
        ,AWREGION0
        ,AW_CH_S0

        // W Channel0
        ,WDATA0
        ,WSTRB0
        ,WLAST0
        ,W_CH_S0

        // B Channel0
        ,BID0
        ,BRESP0
        ,B_CH_S0

        // AR Channel0
        ,ARID0
        ,ARADDR0
        ,ARLEN0
        ,ARSIZE0
        ,ARBURST0
        ,ARLOCK0
        ,ARCACHE0
        ,ARPROT0
        ,ARQOS0
        ,ARREGION0
        ,AR_CH_S0

        // R Channel0
        ,RID0
        ,RDATA0
        ,RRESP0
        ,RLAST0
        ,R_CH_S0
    );
    // AW Channel0
    input  wire [`AXI4_AWID_WIDTH-1:0]        AWID0; // AXI AW 通道写事务 ID
    input  wire [`AXI4_AWADDR_WIDTH-1:0]      AWADDR0; // AXI AW 通道写地址
    input  wire [`AXI4_AWLEN_WIDTH-1:0]       AWLEN0; // AXI AW burst 长度编码，实际拍数为 AWLEN+1
    input  wire [`AXI4_AWSIZE_WIDTH-1:0]      AWSIZE0; // AXI AW 单拍传输字节数编码
    input  wire [`AXI4_AWBURST_WIDTH-1:0]     AWBURST0; // AXI AW burst 类型，FIXED/INCR/WRAP
    input  wire [`AXI4_AWLOCK_WIDTH-1:0]      AWLOCK0; // AXI AW lock/exclusive 属性
    input  wire [`AXI4_AWCACHE_WIDTH-1:0]     AWCACHE0; // AXI AW cache 属性
    input  wire [`AXI4_AWPROT_WIDTH-1:0]      AWPROT0; // AXI AW 保护属性
    input  wire [`AXI4_AWQOS_WIDTH-1:0]       AWQOS0; // AXI AW QoS 优先级
    input  wire [`AXI4_AWREGION_WIDTH-1:0]    AWREGION0; // AXI AW region 属性
    output wire [`AXI4_AW_WIDTH-1:0]          AW_CH_S0; // 打包后的 AXI AW 通道总线

    // W Channel0     
    input  wire [`AXI4_WDATA_WIDTH-1:0]       WDATA0; // AXI W 通道写数据
    input  wire [`AXI4_WSTRB_WIDTH-1:0]       WSTRB0; // AXI W 通道字节使能
    input  wire [`AXI4_WLAST_WIDTH-1:0]       WLAST0; // AXI W burst 最后一拍标志
    output wire [`AXI4_W_WIDTH-1:0]           W_CH_S0; // 打包后的 AXI W 通道总线

    // B Channel0     
    output wire [`AXI4_BID_WIDTH-1:0]         BID0; // AXI B 通道响应 ID
    output wire [`AXI4_BRESP_WIDTH-1:0]       BRESP0; // AXI B 通道写响应编码
    input  wire [`AXI4_B_WIDTH-1:0]           B_CH_S0; // 打包后的 AXI B 通道总线

    // AR Channel0    
    input  wire [`AXI4_ARID_WIDTH-1:0]        ARID0; // AXI AR 通道读事务 ID
    input  wire [`AXI4_ARADDR_WIDTH-1:0]      ARADDR0; // AXI AR 通道读地址
    input  wire [`AXI4_ARLEN_WIDTH-1:0]       ARLEN0; // AXI AR burst 长度编码，实际拍数为 ARLEN+1
    input  wire [`AXI4_ARSIZE_WIDTH-1:0]      ARSIZE0; // AXI AR 单拍传输字节数编码
    input  wire [`AXI4_ARBURST_WIDTH-1:0]     ARBURST0; // AXI AR burst 类型，FIXED/INCR/WRAP
    input  wire [`AXI4_ARLOCK_WIDTH-1:0]      ARLOCK0; // AXI AR lock/exclusive 属性
    input  wire [`AXI4_ARCACHE_WIDTH-1:0]     ARCACHE0; // AXI AR cache 属性
    input  wire [`AXI4_ARPROT_WIDTH-1:0]      ARPROT0; // AXI AR 保护属性
    input  wire [`AXI4_ARQOS_WIDTH-1:0]       ARQOS0; // AXI AR QoS 优先级
    input  wire [`AXI4_ARREGION_WIDTH-1:0]    ARREGION0; // AXI AR region 属性
    output wire [`AXI4_AR_WIDTH-1:0]          AR_CH_S0; // 打包后的 AXI AR 通道总线

    // R Channel0     
    output wire [`AXI4_RID_WIDTH-1:0]         RID0; // AXI R 通道响应 ID
    output wire [`AXI4_RDATA_WIDTH-1:0]       RDATA0; // AXI R 通道读数据
    output wire [`AXI4_RRESP_WIDTH-1:0]       RRESP0; // AXI R 通道读响应编码
    output wire [`AXI4_RLAST_WIDTH-1:0]       RLAST0; // AXI R burst 最后一拍标志
    input  wire [`AXI4_R_WIDTH-1:0]           R_CH_S0; // 打包后的 AXI R 通道总线

    // main function
    assign AW_CH_S0[`AXI4_AWID_RANGE]         = AWID0;
    assign AW_CH_S0[`AXI4_AWADDR_RANGE]       = AWADDR0;
    assign AW_CH_S0[`AXI4_AWLEN_RANGE]        = AWLEN0;
    assign AW_CH_S0[`AXI4_AWSIZE_RANGE]       = AWSIZE0;
    assign AW_CH_S0[`AXI4_AWBURST_RANGE]      = AWBURST0;
    assign AW_CH_S0[`AXI4_AWLOCK_RANGE]       = AWLOCK0;
    assign AW_CH_S0[`AXI4_AWCACHE_RANGE]      = AWCACHE0;
    assign AW_CH_S0[`AXI4_AWPROT_RANGE]       = AWPROT0;
    assign AW_CH_S0[`AXI4_AWQOS_RANGE]        = AWQOS0;
    assign AW_CH_S0[`AXI4_AWREGION_RANGE]     = AWREGION0;
 
    assign W_CH_S0[`AXI4_WDATA_RANGE]         = WDATA0;
    assign W_CH_S0[`AXI4_WSTRB_RANGE]         = WSTRB0;
    assign W_CH_S0[`AXI4_WLAST_RANGE]         = WLAST0;
 
    assign AR_CH_S0[`AXI4_ARID_RANGE]         = ARID0;
    assign AR_CH_S0[`AXI4_ARADDR_RANGE]       = ARADDR0;
    assign AR_CH_S0[`AXI4_ARLEN_RANGE]        = ARLEN0;
    assign AR_CH_S0[`AXI4_ARSIZE_RANGE]       = ARSIZE0;
    assign AR_CH_S0[`AXI4_ARBURST_RANGE]      = ARBURST0;
    assign AR_CH_S0[`AXI4_ARLOCK_RANGE]       = ARLOCK0;
    assign AR_CH_S0[`AXI4_ARCACHE_RANGE]      = ARCACHE0;
    assign AR_CH_S0[`AXI4_ARPROT_RANGE]       = ARPROT0;
    assign AR_CH_S0[`AXI4_ARQOS_RANGE]        = ARQOS0;
    assign AR_CH_S0[`AXI4_ARREGION_RANGE]     = ARREGION0;

    assign BID0   = B_CH_S0[`AXI4_BID_RANGE];
    assign BRESP0 = B_CH_S0[`AXI4_BRESP_RANGE];

    assign RID0   = R_CH_S0[`AXI4_RID_RANGE];
    assign RDATA0 = R_CH_S0[`AXI4_RDATA_RANGE];
    assign RRESP0 = R_CH_S0[`AXI4_RRESP_RANGE];
    assign RLAST0 = R_CH_S0[`AXI4_RLAST_RANGE];

endmodule
